# Testing 1.3.99

The current release gate contains 27 tests. The 26 inherited 1.3.98 release
cases remain unchanged and pass. `test_dense_mixed_coordinatefact_1399.sh`
adds an end-to-end compile/run proof for a non-power-of-two dense Rank-N shape
and asserts that the production compiler contains the generic mixed-radix
CoordinateFact authority without any benchmark-name matcher.

Additional sampled `n=64,127,128,256,1024` Strict outputs of the dense
permuted all-pairs probe are bit-identical to the 1.3.98 compiler.
