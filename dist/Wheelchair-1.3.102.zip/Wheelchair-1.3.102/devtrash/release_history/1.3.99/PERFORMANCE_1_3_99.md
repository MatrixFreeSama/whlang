# Performance 1.3.99

Probe: dense permuted all-pairs, `n=8192`, static axes 127 x 127, 132,128,768
pair interactions, 100% connectivity, irregular reversible index permutations.
CPU affinity: 0-3. Nine interleaved measured rounds after warmup.

| implementation | wall median | CPU median | four-slot occupancy |
|---|---:|---:|---:|
| Wheelchair 1.3.98 Strict | 641.747 ms | 2190 ms | 85.3% |
| Wheelchair 1.3.99 Strict | **259.110 ms** | **880 ms** | 84.9% |
| C Strict | 222.339 ms | 780 ms | 87.7% |
| Fortran Strict | 230.461 ms | 850 ms | 92.2% |
| Wheelchair 1.3.98 Fast | 660.481 ms | 2180 ms | 82.5% |
| Wheelchair 1.3.99 Fast | **257.937 ms** | **860 ms** | 83.4% |
| C Fast | 208.940 ms | 730 ms | 87.3% |
| Fortran Fast | 215.541 ms | 770 ms | 89.3% |

Strict speedup over 1.3.98: **2.477x**; wall reduction: **59.6%**.
Fast speedup over 1.3.98: **2.561x**; wall reduction: **60.9%**.

The residual gap is not hidden: 1.3.99 remains 16.5% slower than C Strict and
12.4% slower than Fortran Strict in these medians. No benchmark-specific path
is added to erase that gap.

Raw evidence is under `devtrash/benchmarks/dense_mixed_coordinatefact_1399/`.
