# Wheelchair charter 1.3.99

The objective remains convergence of real physical work toward the
mathematical-physical lower bound. Parallelism is a consequence of causal
structure, never the language identity and never an occupancy target.

Compiler evolution must first remove duplicated work, transport, rematerialized
state, and compatibility-shaped execution modes. 1.3.99 therefore does not add
a dense-irregular optimizer family. Non-power-of-two static coordinates join
existing CoordinateFact ownership, and proven-u32 constant div/mod drops the
floating reciprocal materialization.

No source kernel language, worker pool, ready queue, work stealing, runtime
radix selector, benchmark route, fixed shape threshold, or second semantic IR
is admitted.
