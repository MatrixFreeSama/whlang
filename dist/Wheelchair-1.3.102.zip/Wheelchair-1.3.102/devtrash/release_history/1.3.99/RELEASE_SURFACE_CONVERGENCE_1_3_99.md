# Release surface convergence 1.3.99

Root release names refer only to 1.3.99. The former 1.3.98 root release
materials are archived under `devtrash/release_history/1.3.98/`.

`bin/` remains the executable authority. Generated `build/` material is not
shipped in the archive. The new regression is folded into the existing release
test list rather than creating a parallel test runner.
