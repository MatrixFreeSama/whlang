# Pure assembly release proof 1.3.99

Production compiler/runtime authority remains handwritten x86-64 assembly and
direct static ELF emission. `build.sh` rejects Python in production compiler,
runtime, surface, and build authority. The 1.3.99 CoordinateFact repair is in
`compiler/tensor_derived_frontend_x86_64.S`; no C/C++, Rust, LLVM, MLIR, JIT,
bytecode VM, or generated DSL backend was introduced.
