# Wheelchair 1.3.99

1.3.99 closes the non-power-of-two mixed-radix CoordinateFact hole exposed by
dense irregular Rank-N programs. The source semantics and Physical DAG model do
not change.

For vector integer division/modulo whose physical value domain is proven below
2^32, the derived Tensor frontend now uses one exact integer relation:

```
m = floor(2^32 / d)
q0 = high32(x * m)
r = x - q0*d
q = q0 + [r >= d]
```

The correction is emitted as integer vector arithmetic. The previous
integer->double reciprocal->integer materialization is no longer present in
that proven domain. Wider proven domains retain the existing exact authority.

Static mixed-radix coordinates such as `q % 127`, `(q / 127) % 127`, and
`q / 16129` are now persistent CoordinateFacts for a physical episode instead
of being reconstructed independently by sibling expressions. Literal-scaled
coordinates reuse the existing scaled CoordinateFact ownership table. There is
no benchmark name matcher, radix table, runtime selector, source-visible
kernel, worker model, second Tensor IR, or DSL backend.

On 9 interleaved four-core rounds of the 8192 x 127 x 127 dense permuted
all-pairs probe:

| implementation | Strict median | Fast median |
|---|---:|---:|
| Wheelchair 1.3.98 | 641.747 ms | 660.481 ms |
| Wheelchair 1.3.99 | **259.110 ms** | **257.937 ms** |
| C | 222.339 ms | 208.940 ms |
| Fortran | 230.461 ms | 215.541 ms |

1.3.99 / 1.3.98 throughput is 2.477x Strict and 2.561x Fast. CPU-slot
occupancy remains approximately 85%/83%; the improvement comes from deleting
coordinate rematerialization rather than increasing occupancy.
