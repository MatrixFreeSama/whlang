# Release surface convergence 1.3.98

`bin/` remains the sole shipped executable authority. Generated `build/`
content is excluded from the archive. The previous 1.3.97 root release
materials are retained only under `devtrash/release_history/1.3.97/`; root
release names refer only to 1.3.98.

The two previous current General tests are converged into one
`test_general_physical_reality_1398.sh`. It retains the 1.3.96 wide-register and
residency proofs, the 1.3.97 whole-FP-generation authority proof, and the new
1.3.98 constant-modulo proof. The current release authority therefore contains
26 tests rather than preserving duplicated version-shaped General test shells.
