# Testing 1.3.98

The current release authority contains **26 tests**. The General current surface
is consolidated into `test_general_physical_reality_1398.sh`; the older
1.3.96/1.3.97 General scripts remain historical evidence but are no longer
separate current authorities.

The consolidated General test verifies:

- compiler-wide wide-register geometry and removal of old constant/CSE cliffs;
- whole-generation FP fixed-point authority with unchanged Strict reference bits;
- one constant-modulo reciprocal authority and zero power-of-two compatibility branch;
- identical native relation for `%16` and `%1000003` witnesses;
- exact outputs for those witnesses; and
- absence of a workload route or second backend.

A separate semantic sweep checked divisors 1, 2, 3, 7, 16, 97, 1000003,
2^63 and 2^64-1 across multiple seeds and iteration counts. All current release
tests passed; the long suite was executed in continuation batches because the
external execution harness imposes a per-call time limit. The repository's
`./test.sh release` remains the single uninterrupted release command outside
that harness.
