# Wheelchair 1.3.98

General integer Physical Reality now realizes every nonzero compile-time `u64`
modulo ConstantFact through one exact reciprocal relation. A power-of-two
divisor no longer owns a compatibility mask path or a separate admission rule;
powers of two and arbitrary constants enter the same physical lowering.

The change closes the previous `mod` hole in the register-native integer DAG.
An expression such as `(x*x+k) % const` no longer forces the whole iterate
episode back to the generic semantic stack merely because the final operator is
modulo. `RDX` is reserved as the implicit high-half scratch for x86 unsigned
wide multiply, while the third persistent integer output authority moves to
`RCX`. No workload matcher, divisor table, runtime selector, second General
backend, source-visible kernel, worker model, or DSL surface is added.

The exact remainder proof uses `m=floor(2^64/d)`, `q0=high(n*m)`, followed by
one branchless correction. Dedicated semantic sweeps cover divisors 1, 2, 3,
7, 16, 97, 1000003, 2^63 and 2^64-1. Existing Strict FP General probes
`mass3`, `chem6`, and `rigid7` remain generated-hot-code byte-identical to
1.3.97.

On the same host, 21 interleaved 20:1 wait-slow rounds improve from 187.395 ms
in 1.3.97 to 119.934 ms in 1.3.98: 1.5625x throughput, or 36.0% lower wall
time. In that probe 1.3.98 also measures below the manually asynchronous C and
Fortran controls at 137.212 ms and 139.161 ms respectively.
