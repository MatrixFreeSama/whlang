# Performance 1.3.98

The release performance witness targets the General integer constant-modulo
hole isolated during disassembly of the rotating wait-slow benchmark.

Host observed for this run: Intel Xeon Platinum 8573C under KVM, CPUs 0-3
pinned, four-CPU quota. The authoritative comparison is 21 interleaved rounds
using the same inputs and the same mathematical output.

| implementation | median wall | median CPU |
|---|---:|---:|
| Wheelchair 1.3.97 | 187.395 ms | 717.388 ms |
| Wheelchair 1.3.98 | **119.934 ms** | **456.339 ms** |
| C async | 137.212 ms | 526.749 ms |
| Fortran async | 139.161 ms | 532.124 ms |

1.3.98 / 1.3.97 throughput: **1.5625x**. Wall-time reduction: **36.0%**.
Relative to the manually asynchronous controls in this probe, 1.3.98 has
1.144x the C throughput and 1.160x the Fortran throughput.

The disassembly change is structural and local. The 1.3.97 hot recurrence uses
hardware integer division for `% 1000003`; 1.3.98 emits reciprocal wide
multiply, multiply/subtract and one branchless correction, while the iterate
state remains register-native. Representative generated-segment counts fell
from 35 `div/idiv` occurrences to 3 and from 1655 `push/pop` occurrences to
1015; the recurrence hot loop itself contains no integer division.

This result is not generalized to all integer workloads. It establishes that
removing the constant-modulo rollback closes a measured General code-generation
hole without changing the surrounding causal architecture.

Raw evidence: `devtrash/benchmarks/general_const_mod_1398/ab21.csv`.
