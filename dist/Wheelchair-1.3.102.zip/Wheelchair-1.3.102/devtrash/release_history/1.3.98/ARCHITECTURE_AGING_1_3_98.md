# Architecture aging 1.3.98

1.3.98 ages the existing General integer Physical Reality instead of adding an
optimizer layer. Compile-time constant modulo becomes another physical relation
inside the same register-native integer DAG.

The old behavior had an architectural discontinuity: `add`, `sub`, and `mul`
could remain register-native, while a trailing `mod` caused the complete
iterate expression to fall back to the generic semantic path. That boundary is
removed for every nonzero `u64` ConstantFact.

One exact reciprocal construction owns the entire constant-divisor set. Powers
of two are deliberately not recognized as a special family. There is no mask
compatibility branch, divisor-size threshold, workload name, benchmark route,
runtime selector, or alternate backend. Division by zero remains outside the
native proof and therefore keeps the existing checked semantic path.
