#!/bin/sh
set -eu
[ "$#" -eq 3 ] || [ "$#" -eq 4 ] || { echo 'usage: generate_general_parallel_release_offsets.sh ELF BIN OUT_JSON [OUT_INC]' >&2; exit 64; }
ELF=$1
BIN=$2
OUT=$3
INC=${4:-}
need='gr_release_base gr_node_count gr_edge_count gr_indegree gr_first_out gr_edge_v gr_next_edge gr_entry_offsets gr_template_end'
value() {
  name=$1
  v=$(nm -n "$ELF" | awk -v n="$name" '$3==n {print $1; exit}')
  [ -n "$v" ] || { echo "missing blind-release symbol: $name" >&2; exit 1; }
  printf '%d' "$((0x$v))"
}
BASE=$(value gr_release_base)
[ "$BASE" -eq 0 ] || { echo "gr_release_base must link at offset zero, got $BASE" >&2; exit 1; }
END=$(value gr_template_end)
SIZE=$(wc -c < "$BIN" | tr -d ' ')
[ "$SIZE" -eq "$END" ] || { echo "raw template size $SIZE != gr_template_end $END" >&2; exit 1; }
NODE=$(value gr_node_count)
EDGE=$(value gr_edge_count)
INDEG=$(value gr_indegree)
FIRST=$(value gr_first_out)
EV=$(value gr_edge_v)
NEXT=$(value gr_next_edge)
ENTRY=$(value gr_entry_offsets)
cat > "$OUT" <<EOF
{
  "format": "wheelchair.general_parallel_release_offsets/1",
  "max_edges": 1024,
  "max_nodes": 256,
  "offsets": {
    "gr_edge_count": $EDGE,
    "gr_edge_v": $EV,
    "gr_entry_offsets": $ENTRY,
    "gr_first_out": $FIRST,
    "gr_indegree": $INDEG,
    "gr_next_edge": $NEXT,
    "gr_node_count": $NODE,
    "gr_release_base": 0,
    "gr_template_end": $END
  },
  "program_slot_capacity": 131072,
  "template_size": $SIZE
}
EOF

if [ -n "$INC" ]; then
cat > "$INC" <<EOF
.equ GR_NODE_COUNT_OFF, $NODE
.equ GR_EDGE_COUNT_OFF, $EDGE
.equ GR_INDEGREE_OFF, $INDEG
.equ GR_FIRST_OUT_OFF, $FIRST
.equ GR_EDGE_V_OFF, $EV
.equ GR_NEXT_EDGE_OFF, $NEXT
.equ GR_ENTRY_OFFSETS_OFF, $ENTRY
.equ GR_TEMPLATE_SIZE, $SIZE
EOF
fi
echo 'GENERAL_PARALLEL_RELEASE_OFFSETS=DERIVED_WITHOUT_PYTHON'
