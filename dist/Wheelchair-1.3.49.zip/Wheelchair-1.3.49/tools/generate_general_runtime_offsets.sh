#!/bin/sh
set -eu
BIN=${1:-build/general_runtime_template}
OUT=${2:-compiler/general_runtime_offsets.inc}
BASE=0x400000
sym() { nm -n "$BIN" | awk -v n="$1" '$3==n {print "0x" $1; exit}'; }
need() { v=$(sym "$1"); [ -n "$v" ] || { echo "missing symbol: $1" >&2; exit 1; }; printf '%s' "$v"; }
va_program=$(need program_slot)
va_in_count=$(need input_count_patch)
va_out_count=$(need output_count_patch)
va_in_type=$(need input_type_patch)
va_out_type=$(need output_type_patch)
va_in_values=$(need input_values)
va_in_aux=$(need input_aux)
va_bind=$(need binding_mailboxes)
va_state=$(need state_pages)
va_state_temp=$(need state_temp_mailboxes)
va_out_values=$(need output_pages)
va_rankn_input=$(need rankn_fp_input_pages)
va_rankn_temp=$(need rankn_fp_temp_pages)
va_rankn_from_u64=$(need rankn_fp_from_u64)
va_rankn_from_i64=$(need rankn_fp_from_i64)
va_rankn_from_f64=$(need rankn_fp_from_f64_bits)
va_rankn_convert=$(need rankn_fp_convert)
va_rankn_to_f64=$(need rankn_fp_to_f64_bits)
va_rankn_add=$(need rankn_fp_add)
va_rankn_sub=$(need rankn_fp_sub)
va_rankn_mul=$(need rankn_fp_mul)
va_rankn_div=$(need rankn_fp_div)
va_rankn_neg=$(need rankn_fp_neg)
va_rankn_abs=$(need rankn_fp_abs)
va_rankn_cmp=$(need rankn_fp_cmp)
va_rankn_sqrt=$(need rankn_fp_sqrt)
va_rankn_exp=$(need rankn_fp_exp)
va_rankn_log=$(need rankn_fp_log)
va_rankn_sin=$(need rankn_fp_sin)
va_rankn_cos=$(need rankn_fp_cos)
size=$(stat -c %s "$BIN")
to_off() { printf '0x%x' $(( $1 - BASE )); }
cat > "$OUT" <<EOT
.equ GENERAL_RUNTIME_SIZE, $size
.equ GENERAL_PROGRAM_OFF, $(to_off "$va_program")
.equ GENERAL_INPUT_COUNT_OFF, $(to_off "$va_in_count")
.equ GENERAL_OUTPUT_COUNT_OFF, $(to_off "$va_out_count")
.equ GENERAL_INPUT_TYPE_OFF, $(to_off "$va_in_type")
.equ GENERAL_OUTPUT_TYPE_OFF, $(to_off "$va_out_type")
.equ GENERAL_INPUT_VALUES_VA, $va_in_values
.equ GENERAL_INPUT_AUX_VA, $va_in_aux
.equ GENERAL_BINDING_MAILBOXES_VA, $va_bind
.equ GENERAL_STATE_PAGES_VA, $va_state
.equ GENERAL_STATE_TEMP_MAILBOXES_VA, $va_state_temp
.equ GENERAL_OUTPUT_PAGES_VA, $va_out_values
.equ GENERAL_RANKN_FP_INPUT_VA, $va_rankn_input
.equ GENERAL_RANKN_FP_TEMP_VA, $va_rankn_temp
.equ GENERAL_RANKN_FP_FROM_U64_VA, $va_rankn_from_u64
.equ GENERAL_RANKN_FP_FROM_I64_VA, $va_rankn_from_i64
.equ GENERAL_RANKN_FP_FROM_F64_VA, $va_rankn_from_f64
.equ GENERAL_RANKN_FP_CONVERT_VA, $va_rankn_convert
.equ GENERAL_RANKN_FP_TO_F64_VA, $va_rankn_to_f64
.equ GENERAL_RANKN_FP_ADD_VA, $va_rankn_add
.equ GENERAL_RANKN_FP_SUB_VA, $va_rankn_sub
.equ GENERAL_RANKN_FP_MUL_VA, $va_rankn_mul
.equ GENERAL_RANKN_FP_DIV_VA, $va_rankn_div
.equ GENERAL_RANKN_FP_NEG_VA, $va_rankn_neg
.equ GENERAL_RANKN_FP_ABS_VA, $va_rankn_abs
.equ GENERAL_RANKN_FP_CMP_VA, $va_rankn_cmp
.equ GENERAL_RANKN_FP_SQRT_VA, $va_rankn_sqrt
.equ GENERAL_RANKN_FP_EXP_VA, $va_rankn_exp
.equ GENERAL_RANKN_FP_LOG_VA, $va_rankn_log
.equ GENERAL_RANKN_FP_SIN_VA, $va_rankn_sin
.equ GENERAL_RANKN_FP_COS_VA, $va_rankn_cos
EOT
