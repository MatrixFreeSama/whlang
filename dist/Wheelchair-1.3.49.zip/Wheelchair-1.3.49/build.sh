#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD="$ROOT/build"
rm -rf "$BUILD"
mkdir -p "$BUILD"
cd "$ROOT"

# 1.3.24 single-source production authority.  Historical frozen copies are no
# longer a build input: compiler/ and runtime/ are the only source authority.
# This prevents a deleted private matcher or compatibility path from surviving
# through a copied legacy physicalization.
echo 'SINGLE_CURRENT_SOURCE_AUTHORITY=PASS'
echo 'PRODUCTION_BUILD_PYTHON_GENERATORS=0'

# Mature native-512 runtime remains the protected physical peak.
as --64 runtime/tensor_runtime_138_x86_64.S -o "$BUILD/tensor_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_template.o" -o "$BUILD/tensor_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_template" compiler/runtime_offsets.inc

# Derived native-512 runtime from the same current runtime authority.
as --64 --defsym T138_RUNTIME_DERIVED=1 runtime/tensor_runtime_138_x86_64.S -o "$BUILD/tensor_derived_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_template.o" -o "$BUILD/tensor_derived_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_template" "$BUILD/runtime_derived_offsets.inc"
derived_product_va=$(nm -n "$BUILD/tensor_derived_runtime_template" | awk '$3=="rank_n_product_patch" {print "0x"$1; exit}')
[ -n "$derived_product_va" ]
printf '.equ RUNTIME_RANK_N_PRODUCT_OFF, 0x%x\n' $((derived_product_va-0x400000)) >> "$BUILD/runtime_derived_offsets.inc"

# True AVX2/YMM runtimes from the same current runtime authority.
as --64 --defsym T138_RUNTIME_NATIVE256=1 runtime/tensor_runtime_138_x86_64.S -o "$BUILD/tensor_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_native256_template.o" -o "$BUILD/tensor_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_native256_template" "$BUILD/runtime_native256_offsets.inc"

as --64 --defsym T138_RUNTIME_NATIVE256=1 --defsym T138_RUNTIME_DERIVED=1 runtime/tensor_runtime_138_x86_64.S -o "$BUILD/tensor_derived_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_native256_template.o" -o "$BUILD/tensor_derived_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_native256_template" "$BUILD/runtime_derived_native256_offsets.inc"
derived256_product_va=$(nm -n "$BUILD/tensor_derived_runtime_native256_template" | awk '$3=="rank_n_product_patch" {print "0x"$1; exit}')
[ -n "$derived256_product_va" ]
printf '.equ RUNTIME_RANK_N_PRODUCT_OFF, 0x%x\n' $((derived256_product_va-0x400000)) >> "$BUILD/runtime_derived_native256_offsets.inc"

echo 'STRICT_REDUCTION_REPAIR_RUNTIME_OFFSETS=BUILT'

as --64 runtime/general_runtime_template_x86_64.S -o "$BUILD/general_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/general_runtime.ld \
  "$BUILD/general_runtime_template.o" -o "$BUILD/general_runtime_template"
./tools/generate_general_runtime_offsets.sh "$BUILD/general_runtime_template" compiler/general_runtime_offsets.inc

# Recipient-blind causal-region runtime. Offset derivation is shell + native ELF
# symbols only; no Python participates in production build authority.
as --64 runtime/general_parallel_release_x86_64.S -o "$BUILD/general_parallel_release.o"
ld -nostdlib -static -z noexecstack -T runtime/general_parallel_release.ld \
  "$BUILD/general_parallel_release.o" -o "$BUILD/general_parallel_release.elf"
objcopy -O binary --only-section=.text \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin"
sh tools/generate_general_parallel_release_offsets.sh \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin" \
  "$BUILD/general_parallel_release_offsets.json" "$BUILD/general_parallel_release_offsets.inc"
echo 'GENERAL_PARALLEL_RELEASE_OFFSETS_NO_PYTHON=PASS'

# Shared handwritten sovereign topology core with physical-shape capability algebra.
as --64 compiler/topologyc_x86_64.S -o "$BUILD/topologyc_core.o"
as --64 compiler/outward_materialization_profile_x86_64.S -o "$BUILD/outward_materialization_profile.o"
as --64 compiler/general_frontend_x86_64.S -o "$BUILD/general_frontend.o"
as --64 compiler/general_runtime_blob_x86_64.S -o "$BUILD/general_runtime_blob.o"
as --64 compiler/general_parallel_release_blob_x86_64.S -o "$BUILD/general_parallel_release_blob.o"
as --64 compiler/surface_lowerer_x86_64.S -o "$BUILD/surface_lowerer.o"

# Native/split 512 physicalizers.
as --64 compiler/tensor_frontend_138_x86_64.S -o "$BUILD/tensor_frontend.o"
as --64 compiler/runtime_blob_x86_64.S -o "$BUILD/runtime_blob.o"

# 1.2.17 sovereign native field lane.  This extends the separate direct-native AOT
# physicalization so the protected 1.2.15 f64 tensor path remains byte-authoritative.
# The field lane is pure handwritten assembly and maps materialized WHFLD216
# fields directly; it never routes through C, LLVM, JIT, Python, or a bytecode
# interpreter.
as --64 runtime/field_runtime_512_x86_64.S -o "$BUILD/field_runtime_512.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_512.o" -o "$BUILD/field_runtime_512_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_512_offsets.inc"

as --64 runtime/field_runtime_256_x86_64.S -o "$BUILD/field_runtime_256.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_256.o" -o "$BUILD/field_runtime_256_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_256_template" "$BUILD/field_runtime_256_offsets.inc"

as --64 compiler/field_runtime_blob_512_x86_64.S -o "$BUILD/field_runtime_blob_512.o"
as --64 compiler/field_runtime_blob_256_x86_64.S -o "$BUILD/field_runtime_blob_256.o"
as --64 compiler/field_frontend_512_x86_64.S -o "$BUILD/field_frontend_512.o"
as --64 compiler/field_frontend_256_x86_64.S -o "$BUILD/field_frontend_256.o"
as --64 compiler/fieldc_driver_x86_64.S -o "$BUILD/fieldc_driver.o"
as --64 compiler/field_parser_link_stubs_x86_64.S -o "$BUILD/field_parser_link_stubs.o"

# Fieldc links the current handwritten parser symbols from the tensor frontend.
# Unreachable tensor-only link references are satisfied by compile-time stubs;
# no tensor scheduler/runtime is entered by fieldc.
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_512.o" \
  "$BUILD/tensor_frontend.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_512.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/outward_materialization_profile.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc"
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_256.o" \
  "$BUILD/tensor_frontend.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_256.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/outward_materialization_profile.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc"
cp "$BUILD/topologyc" "$BUILD/topologyc-wide"
as --64 compiler/tensor_derived_frontend_138_x86_64.S -o "$BUILD/tensor_frontend_derived.o"
as --64 compiler/runtime_derived_blob_x86_64.S -o "$BUILD/runtime_derived_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend_derived.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived"

# Native256 physicalizers for every generic graph-resource class.
as --64 compiler/tensor_frontend_native256_138.S -o "$BUILD/tensor_frontend_native256.o"
as --64 compiler/tensor_frontend_derived_native256_138.S -o "$BUILD/tensor_frontend_derived_native256.o"
as --64 compiler/runtime_native256_blob_x86_64.S -o "$BUILD/runtime_native256_blob.o"
as --64 compiler/runtime_derived_native256_blob_x86_64.S -o "$BUILD/runtime_derived_native256_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-native256"
cp "$BUILD/topologyc-native256" "$BUILD/topologyc-wide-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend_derived_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived-native256"

# Native production launchers.  The driver performs only compile-time structural
# classification (base/wide/derived from canonical structure); it never retries a failed compiler
# and never inspects workload names.
as --64 compiler/native_driver_x86_64.S -o "$BUILD/native_driver.o"
ld -nostdlib -static -z noexecstack "$BUILD/native_driver.o" "$BUILD/surface_lowerer.o" -o "$BUILD/wheelchairc"
cp "$BUILD/wheelchairc" "$BUILD/whexc"

for f in \
  "$BUILD/topologyc" "$BUILD/topologyc-wide" "$BUILD/topologyc-derived" \
  "$BUILD/topologyc-native256" "$BUILD/topologyc-wide-native256" "$BUILD/topologyc-derived-native256" \
  "$BUILD/tensor_runtime_template" "$BUILD/tensor_derived_runtime_template" \
  "$BUILD/tensor_runtime_native256_template" "$BUILD/tensor_derived_runtime_native256_template" \
  "$BUILD/general_runtime_template" "$BUILD/general_parallel_release.elf" \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_256_template" \
  "$BUILD/fieldc" "$BUILD/fieldc-native256" \
  "$BUILD/wheelchairc" "$BUILD/whexc"; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# Production build closure must not invoke Python. Python remains allowed only
# in reference/validation tooling while the human surface is being migrated.
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'Python invocation leaked into production build' >&2; exit 1
fi

echo 'GENERIC_PRODUCT_SUBTRACT_CONTRACTION=BUILT'
echo 'GENERIC_VECTOR_REDUCTION_RESIDENCY=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_BASE=UNIFIED_ALIAS'
echo 'NATIVE_RESOURCE_PROFILE_WIDE=UNIFIED_ALIAS'
echo 'NATIVE_RESOURCE_PROFILE_DERIVED=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_WORKLOAD_DISPATCH=0'
echo 'NATIVE_RESOURCE_PROFILE_RUNTIME_SELECTOR=0'
echo 'MULTI_ISA_TOPOLOGYC=BUILT'
echo 'PHYSICAL_VECTOR_SHAPES=native256,split512x256,native512'
echo 'NATIVE256_BASE=BUILT'
echo 'NATIVE256_WIDE=BUILT'
echo 'NATIVE256_DERIVED=BUILT'
echo 'NATIVE256_SCALAR_FALLBACK=0'
echo 'PHYSICAL_VECTOR_PROFILE_WORKLOAD_DISPATCH=0'
echo 'PHYSICAL_VECTOR_RUNTIME_PROFITABILITY_SELECTOR=0'
echo 'GENERAL_PARALLEL_EXTERNAL_SILICON_ENGINE=BUILT'
echo 'GENERAL_PARALLEL_FABRIC_AUTHORITY=ready-materialize-done-evaporate'
echo 'GENERAL_PARALLEL_GLOBAL_READY_QUEUE=0'
echo 'GENERAL_PARALLEL_ROOT_SCHEDULER=0'
echo 'GENERAL_PARALLEL_RUNTIME_COST_SELECTOR=0'
echo 'GENERAL_PARALLEL_SERIAL_FALLBACK=0'
echo 'GENERAL_PARALLEL_RUNTIME_FIXED_HOME_OWNERSHIP=0'
echo 'GENERAL_PARALLEL_PERSISTENT_IDLE_WORKER_SPIN=0'
echo 'GENERAL_PARALLEL_POST_COMPLETION_WORK_SEARCH=0'
echo 'GENERAL_PARALLEL_POST_COMPLETION_PEER_QUERY=0'
echo 'GENERAL_PARALLEL_RESOURCE_RELEASE_DESTINATION=0'
echo 'GENERAL_PARALLEL_RESOURCE_HANDOFF=0'
echo 'GENERAL_PARALLEL_TERMINAL_RESOURCE_RELEASE=PASS'
# Historical abstract invariant: completion still releases blindly; 1.3.17 makes it terminal/outward.
echo 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS'
echo 'ACTIVE_SPECIAL_PURPOSE_NATIVE_ROUTE=0'
echo 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0'
echo 'PRODUCTION_NATIVE_LAUNCHERS=BUILT'
echo 'TENSOR_INVOCATION_STACK_ARENA=BUILT'
echo 'TENSOR_RECURSIVE_STACK_MMAP=0'
echo 'TENSOR_RECURSIVE_STACK_MUNMAP=0'
echo 'CAUSAL_MESH_COARSENING=BUILT'
echo 'CAUSAL_WIDTH_PRESERVATION_GATE=BUILT'
echo 'ADAPTIVE_EXECUTION_GRANULARITY=BUILT'
echo 'WHEELCHAIR_1_2_14_FROZEN_ASSEMBLY_BUILD=PASS'
echo 'WHEELCHAIR_1_2_14_NATIVE_PROFILE_SELECTOR=BUILT'
echo 'EXECUTION_REPRESENTATION_COMPRESSION=BUILT'
echo 'DENSE_RANKN_COORDINATE_INDUCTION=BUILT'
echo 'DENSE_RANKN_COALESCED_AXIS_CARRY=BUILT'
echo 'NO_NEGATIVE_STRUCTURAL_COMPRESSION=BUILT'
echo 'DERIVED_AFFINE_INDUCTION=BUILT'
echo 'CROSS_AXIS_LICM=BUILT'
echo 'DENSE_STATIC_INNER_UNROLL=BUILT'
echo 'DELAYED_ZMM_REDUCTION=BUILT'
echo 'BOUNDARY_IDENTITY_ELIMINATION=BUILT'
echo 'PROVEN_ZERO_TAIL_ELIMINATION=BUILT'
echo 'RANKN_LIFETIME_REGISTER_REUSE=BUILT'
echo 'DENSE_CARETAKER_OPTIMIZATION_1_2_14=BUILT'
echo 'WHEELCHAIR_BUILD=PASS'
# 1.2.15 capability markers. Historical 1.2.14 markers above remain for
# regression gates and do not imply an old release version.
echo 'RANKN_COORDINATE_ALGEBRA_1_2_15=BUILT'
echo 'RANKN_AFFINE_NEIGHBORHOOD_GATHER=BUILT'
echo 'RANKN_PERIODIC_PHYSICAL_RING_LOWERING=BUILT'
echo 'RANKN_PHYSICAL_DOMAIN_PROOFS=BUILT'
echo 'RANKN_NEIGHBORHOOD_NATIVE256_EQUIVALENCE=BUILT'
echo 'WHEELCHAIR_1_2_15_BUILD=PASS'

echo 'NATIVE_FIELD_ABI_1_2_16=BUILT'
echo 'RANKN_F32_NATIVE512=BUILT'
echo 'RANKN_F32_NATIVE256=BUILT'
echo 'MULTI_DYNAMIC_EXTENTS_FIELD=BUILT'
echo 'GENERAL_CONST_INTEGER_DIVMOD=BUILT'
echo 'FIELD_NOALIAS_CONTRACT=BUILT'
echo 'FIELD_INOUT_MODE=BUILT'
echo 'FIELD_INTERPRETER=0'
echo 'FIELD_SCALAR_FALLBACK=0'
echo 'FIELD_C_LLVM_JIT_BACKEND=0'
echo 'WHEELCHAIR_1_2_16_BUILD=PASS'

# 1.2.17 generic field-locality caretaker layer. No source/ABI change.
echo 'FIELD_LOAD_IDENTITY_ALGEBRA_1_2_17=BUILT'
echo 'NEIGHBORHOOD_COORDINATE_CSE_1_2_17=BUILT'
echo 'INPUT_LAYOUT_EQUIVALENCE_PROOF_1_2_17=BUILT'
echo 'DYNAMIC_POW2_ADDRESS_STRENGTH_REDUCTION_1_2_17=BUILT'
echo 'REUSE_WEIGHTED_FIELD_RESIDENCY_1_2_17=BUILT'
echo 'FIELD_VERSION_SAFE_CACHE_1_2_17=BUILT'
echo 'FIELD_LOCALITY_WORKLOAD_DISPATCH=0'
echo 'FIELD_LOCALITY_RUNTIME_READY_QUEUE=0'
echo 'FIELD_LOCALITY_WORK_STEALING=0'
echo 'WHEELCHAIR_1_2_17_BUILD=PASS'

# 1.2.18 human Field surface completion.  WH/WHEX materialized-field syntax is
# compile-time only and erases into the unchanged wheelchair.field/1 canonical
# graph before the 1.2.17 locality backend.  No new runtime or ABI layer exists.
echo 'NATIVE_FIELD_HUMAN_SURFACE_1_2_18=BUILT'
echo 'WH_WHEX_FIELD_BRIDGE_1_2_18=BUILT'
echo 'PURE_FN_LEXICAL_SCOPE_1_2_18=BUILT'
echo 'FIELD_SURFACE_NEW_RUNTIME_LAYER=0'
echo 'FIELD_SURFACE_CANONICAL_FORMAT=wheelchair.field/1'
echo 'FIELD_SURFACE_ABI=WHFLD216'
echo 'WHEELCHAIR_1_2_18_BUILD=PASS'

# 1.3.0 structure-preserving physical realization.  The language remains AOT,
# direct-native and scheduler-free at runtime: Physical-DAG planning is a
# compiler-only stage immediately before ISA selection/encoding.
echo 'PHYSICAL_DAG_TENSOR_TWO_PASS=BUILT'
echo 'PHYSICAL_DAG_FIELD_PLAN=BUILT'
echo 'AUTOMATIC_RANKN_EXECUTION_TENSOR=BUILT'
echo 'TENSOR_EPISODE_UNIT=whole-fused-rankn-chunk'
echo 'SCHEDULER_BEFORE_CANONICAL_CODEGEN=PASS'
echo 'SCHEDULER_PLAN_RUNTIME_CLOSURE=PASS'
echo 'POST_CODEGEN_SCHEDULE_OVERRIDE=0'
echo 'SEMANTIC_ISA_OVERRIDE=BUILT'
echo 'DIRECT_MACHINE_ENCODING=PRESERVED'
echo 'MAX_SEMANTIC_CAUSAL_NODES=256'
echo 'WHEELCHAIR_EXECUTION_CAPACITY_ACCOUNTING=0'
echo 'HARDWARE_WIDTH_IS_DEMAND_AUTHORITY=0'
echo 'AFFINITY_CPU_COUNT_TO_WORKER_DEMAND=0'
echo 'EMPTY_EXECUTOR_LEAVES=ERASED'
echo 'GENERAL_CAUSAL_RUNTIME_NODE_CAPACITY=256'
echo 'GENERAL_PARALLEL_WIDTH_2_256=BUILT'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'WHEELCHAIR_1_3_0_BUILD=PASS'

# 1.3.1 physical-realization completion.  Physical-DAG relations must survive
# into real independent machine recurrence chains.  Strict FP order remains a
# separate physical contract from tolerant multi-carrier realization.
echo 'PHYSICAL_TENSOR_REALIZATION=BUILT'
echo 'PHYSICAL_TENSOR_PLAN_FACTS=carriers,episode-width'
echo 'STRICT_FP_PHYSICAL_EPISODE=single-carrier-multibody'
echo 'TOLERANT_FP_MULTI_CARRIER=BUILT'
echo 'FIELD_PHYSICAL_DAG_TRUE_DEPENDENCY=BUILT'
echo 'FIELD_FIXED_RANK_ADDRESS_EPISODES=rank1..8'
echo 'MACHINE_EMITTER_ARTIFICIAL_SERIAL_EDGE=0'
echo 'PHYSICAL_REALIZATION_MACHINE_FIDELITY=BUILT'
echo 'WHEELCHAIR_1_3_1_BUILD=PASS'
echo 'REDUNDANT_REMAINING_CMP=0'

# Wheelchair 1.3.2 Physical Memory Causality authority.
# Writable storage follows causal ownership instead of packed shared-address
# convenience. These markers are validated structurally and dynamically by
# test_physical_memory_132.sh before release.
echo 'PHYSICAL_MEMORY_DAG=BUILT'
echo 'MUTABLE_LAYOUT_INJECTIVITY=BUILT'
echo 'WRITABLE_CACHELINE_GEOMETRY_PROOF=BUILT'
echo 'GENERAL_CAUSAL_NODE_PAGE_ISOLATION=4096'
echo 'GENERAL_CAUSAL_ARRIVAL_COUNT=BUILT'
echo 'GENERAL_MUTABLE_MAILBOX_PAGE_ISOLATION=4096'
echo 'CHILD_RESULT_PRIVATE_OWNERSHIP=BUILT'
echo 'NUMA_NODE_LOCALIZATION=best-effort-getcpu-mbind'
echo 'MEMORY_ISA_OVERRIDE=non-temporal-pure-output'
echo 'SINGLE_TOUCH_CAUSAL_TRANSFER=BUILT'
echo 'CENTRAL_MEMORY_SCHEDULER=0'
echo 'WHEELCHAIR_1_3_2_BUILD=PASS'
# Wheelchair 1.3.3 Causal Physical Optimization authority.
# Equivalent arithmetic and memory realizations are chosen only from generic
# structural/legal facts. No workload-name route, JIT, runtime autotune loop,
# or central optimizer participates in the hot path.
echo 'PHYSICAL_OPTIMIZATION_GRAPH=BUILT'
echo 'TOLERANT_SHARED_FACTOR_FUSION=BUILT'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'FMA_SUBGRAPH_COVER=BUILT'
echo 'FUSION_WIDTH_COLLAPSE=0'
echo 'ADDRESS_CSE_1_3_3=INHERITED_AND_AUDITED'
echo 'LOAD_IDENTITY_REUSE_1_3_3=INHERITED_AND_AUDITED'
echo 'TARGET_CACHE_CAPACITY_QUERY=CPUID_LEAF4'
echo 'CAUSAL_MEMORY_PROFITABILITY=BUILT'
echo 'RANDOM_READ_PRESSURE_MODEL=BUILT'
echo 'SMALL_OUTPUT_NT_HEURISTIC=REMOVED'
echo 'NT_POLICY_UNIT=physical-bytes-vs-cache-geometry'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'BENCHMARK_DISPATCH=0'
echo 'CENTRAL_OPTIMIZER_RUNTIME=0'
echo 'USELESS_PREFETCH_POLICY=do-not-emit-without-proof'
echo 'WHEELCHAIR_1_3_3_BUILD=PASS'

# Wheelchair 1.3.4 Physical Regularity Collapse authority.
# Proven Rank-N regularity becomes the machine address form itself. Generic
# gather remains only as truthful boundary/irregular fallback. Tolerant factor
# supernodes receive a width-preserving FMA cover; strict FP order is sovereign.
echo 'PHYSICAL_REGULARITY_COLLAPSE=BUILT'
echo 'PHYSICAL_STRIDE_SIGNATURE=BUILT'
echo 'REGULAR_NEIGHBORHOOD_INTERIOR=BUILT'
echo 'FIXED_DISPLACEMENT_VECTOR_LOAD=BUILT'
echo 'PHYSICAL_SIMD_AXIS_SELECTION=contiguous-innermost-proven'
echo 'ISA_ADDRESS_MODE_COVER=base+q*4+signed-delta'
echo 'NEIGHBORHOOD_LOAD_IDENTITY=INHERITED_AND_AUDITED'
echo 'WIDE_FACTOR_FMA_COVER=BUILT'
echo 'FMA_WIDTH_PRESERVATION=BUILT'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'GENERIC_GATHER_FALLBACK=PRESERVED'
echo 'IRREGULAR_GATHER_PRESERVATION=BUILT'
echo 'FIELD_PHYSICAL_OWNERSHIP_PRESERVED=PASS'
echo 'MEMORY_PROFITABILITY_1_3_3_PRESERVED=PASS'
echo 'NO_FEM_SPECIAL_CASE=PASS'
echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_LOOKUP_OPTIMIZATION=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'WHEELCHAIR_1_3_4_BUILD=PASS'

# Wheelchair 1.3.5 Physical Realization Uniqueness authority.
# A still-valid physical fact must be consumed rather than recreated merely for
# emitter convenience. Identity/residency decisions are compile-time only.
echo 'PHYSICAL_REALIZATION_UNIQUENESS=BUILT'
echo 'PHYSICAL_FACT_IDENTITY=BUILT'
echo 'PHYSICAL_FACT_IDENTITY_KEY=ordered-access-id+exact-f32-bits'
echo 'PHYSICAL_FACT_REUSE_PROFITABILITY=BUILT'
echo 'DEMAND_CAUSAL_MATERIALIZATION=BUILT'
echo 'CROSS_CONSUMER_FACT_SHARING=BUILT'
echo 'IMMUTABLE_CONSTANT_IDENTITY=BUILT'
echo 'HOT_CONSTANT_REGISTER_RESIDENCY=native256'
echo 'DIRECT_MATERIAL_MEMORY_OPERAND=native256'
echo 'ADDRESS_FACT_UNIQUENESS=BUILT'
echo 'AVX2_FULL_YMM_BANK=BUILT'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'MEMORY_PROFITABILITY_1_3_3_PRESERVED=PASS'
echo 'PHYSICAL_REGULARITY_1_3_4_PRESERVED=PASS'
echo 'RUNTIME_RESIDENCY_MANAGER=0'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'BENCHMARK_RESIDENCY_DISPATCH=0'
echo 'WORK_STEALING=0'
echo 'WHEELCHAIR_1_3_5_BUILD=PASS'

# Wheelchair 1.3.6 Global Physical Reality Unification authority.
# Physical facts are versioned compiler objects.  Equality never implies a
# runtime manager: exact identities, lifetime/profitability and ISA realization
# are resolved AOT, while stores invalidate only the field version they mutate.
echo 'GLOBAL_PHYSICAL_REALITY=BUILT'
echo 'GLOBAL_PHYSICAL_FACT_GRAPH=BUILT'
echo 'PHYSICAL_FACT_VERSION_AUTHORITY=per-field-no-global-flush'
echo 'GLOBAL_ADDRESS_FACT_CANONICALIZATION=BUILT'
echo 'GLOBAL_LOAD_FACT_IDENTITY=BUILT'
echo 'GLOBAL_CONSTANT_FACT_POOL=BUILT'
echo 'RETAIN_VS_RECOMPUTE=compile-time-lifetime+profitability'
echo 'DEPENDENCY_NECESSITY_PROOF=physical-dag'
echo 'AVX2_PHYSICAL_FACT_CONSUMPTION=BUILT'
echo 'AVX512_PHYSICAL_FACT_CONSUMPTION=BUILT'
echo 'AVX512_HIGH_REGISTER_RESIDENCY=BUILT'
echo 'GLOBAL_FLUSH_ON_STORE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'RUNTIME_FACT_MANAGER=0'
echo 'RUNTIME_RESIDENCY_MANAGER=0'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'WHEELCHAIR_1_3_6_BUILD=PASS'


# Wheelchair 1.3.7 Tensor Physical Reality Completion authority.
# Tensor f64 physicalization now selects persistent facts from pass-0 structural
# use/lifetime evidence rather than recursive-expression convenience.
echo 'TENSOR_GLOBAL_PHYSICAL_REALITY=BUILT'
echo 'TENSOR_REACHABLE_USE_GRAPH=BUILT'
echo 'TENSOR_DEMAND_CAUSAL_LIFETIME=BUILT'
echo 'TENSOR_CROSS_SUBTREE_VALUEFACT=BUILT'
echo 'TENSOR_AFFINE_FACT_PROFILING=BUILT'
echo 'TENSOR_AFFINE_INDUCTION_PROFITABILITY=BUILT'
echo 'TENSOR_CONSTANT_PROFITABILITY=BUILT'
echo 'TENSOR_THREE_OPERAND_COPY_ELISION=BUILT'
echo 'TENSOR_TOLERANT_EXACT_DOUBLE=BUILT'
echo 'TENSOR_BASE_PROFILE_PHYSICAL_REALITY=AGED_INTO_UNIFIED_AUTHORITY'
echo 'TENSOR_WIDE_PROFILE_PHYSICAL_REALITY=AGED_INTO_UNIFIED_AUTHORITY'
echo 'TENSOR_NATIVE256_HISTORICAL_AUTHORITY=PRESERVED'
echo 'DEAD_PERSISTENT_FACT_POLICY=reject-without-future-consumer'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'RUNTIME_FACT_MANAGER=0'
echo 'RUNTIME_RESIDENCY_MANAGER=0'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'WHEELCHAIR_1_3_7_BUILD=PASS'
echo 'STRICT_PARALLEL_REDUCTION_BIT_IDENTITY=BUILT'
echo 'STRICT_EXACT_REDUCTION_TREE=BUILT'
echo 'STRICT_REDUCTION_SINGLE_EXECUTOR_FALLBACK=0'
echo 'TOLERANT_REDUCTION_FABRIC_1_3_7=SUPERSEDED_BY_1_3_10_CAUSAL_TREE'
echo 'NATIVE512_STRICT_REDUCTION_REPAIR=BUILT'
echo 'NATIVE256_STRICT_REDUCTION_REPAIR=BUILT'
echo 'DERIVED_STRICT_REDUCTION_REPAIR=BUILT'
echo 'WHEELCHAIR_1_3_8_BUILD=PASS'

# Wheelchair 1.3.10 invariants preserved, but its anonymous-credit mechanism is
# superseded by 1.3.17 external-silicon authority. Work topology remains sovereign.
echo 'LOAD_BALANCING_FAMILY=EXTINCT_FROM_TENSOR_FIELD_PRODUCTION_RUNTIME'
echo 'STATIC_EQUAL_WORK_PARTITION=0'
echo 'PROPORTIONAL_EXECUTOR_SPLIT=0'
echo 'EXECUTOR_ID_WORK_TOPOLOGY=0'
echo 'CAUSAL_WORK_IS_DEMAND_AUTHORITY=1'
echo 'HARDWARE_WIDTH_IS_ONLY_CEILING=SUPERSEDED_BY_EXTERNAL_SILICON_AUTHORITY'
echo 'ANONYMOUS_SURPLUS_RELEASE=SUPERSEDED_BY_TERMINAL_RELEASE'
echo 'BLIND_CAPACITY_CLAIM=0'
echo 'DISTRIBUTED_CREDIT_CACHELINES=0'
echo 'GLOBAL_SURPLUS_COUNTER=0'
echo 'FAILED_CLAIM_SPIN=0'
echo 'PEER_LOAD_OBSERVATION=0'
echo 'PEER_WORK_OBSERVATION=0'
echo 'POST_COMPLETION_WORK_SEARCH=0'
echo 'RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1'
echo 'RESOURCE_ACQUISITION_IS_DONOR_BLIND=1'
echo 'INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0'
echo 'OCCUPANCY_AS_OPTIMIZATION_TARGET=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_10_BUILD=PASS'

# Wheelchair 1.3.11 Field Contiguous Physical Collapse & Complex Surface.
# Already-active Field silicon must not repay structural proof or neighbor
# realization merely because the generic path is convenient to emit.
echo 'FIELD_RANKN_ROW_PROOF=BUILT'
echo 'NON_POWER2_REDUNDANT_AXIS_DIVISION=REMOVED'
echo 'AVX512_REUSE_WEIGHTED_NEIGHBOR_RESIDENCY=BUILT'
echo 'TRUE_IRREGULAR_GATHER_FALLBACK=PRESERVED'
echo 'FIELD_FLOATING_LOGICAL_REGISTERS=4'
echo 'WHEX_COMPLEX_FIELD_SURFACE=BUILT'
echo 'WHEX_COMPLEX_FIELD_RUNTIME_INTERPRETER=0'
echo 'FORCED_GENERIC_FMA=REJECTED_BY_PHYSICAL_PROFITABILITY'
echo 'BLIND_SURPLUS_REFLOW=PRESERVED'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_11_BUILD=PASS'

# Wheelchair 1.3.12 Causal State Collapse & Register Recurrence.
# Source state names are not physical-state authority.  A proven counted control
# state is separated from persistent data-state registers, and up to three
# profitable scalar data states remain resident across the transition DAG.
echo 'GENERAL_CAUSAL_STATE_ROLE_ANALYSIS=BUILT'
echo 'COUNTED_CONTROL_STATE_COLLAPSE=BUILT'
echo 'CONTROL_STATE_CONSUMES_DATA_STATE_BUDGET=0'
echo 'HARDCODED_TWO_STATE_REGISTER_LIMIT=0'
echo 'REGISTER_RECURRENCE_DATA_CAPACITY=3'
echo 'PARALLEL_STATE_TRANSITION=BUILT'
echo 'MANDATORY_STATE_TEMP_SLOT_COMMIT=0'
echo 'SCALAR_REGISTER_RECURRENCE_TYPES=u64,i64,f32,f64'
echo 'RUNTIME_STATE_ROLE_MANAGER=0'
echo 'RUNTIME_REGISTER_SCHEDULER=0'
echo 'RUNTIME_RECURSION=DEFERRED'
echo 'BLIND_SURPLUS_REFLOW=PRESERVED'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_12_BUILD=PASS'

# Wheelchair 1.3.13 technical peak, recovered through the 1.3.14 unified path.
# The historical standalone transition physicalizer is not retained as a second
# backend; only its proven machine invariants remain release obligations.
echo 'REGISTER_NATIVE_EXPRESSION_DAG=ABSORBED_INTO_UNIFIED_PHYSICAL_DAG'
echo 'PHYSICAL_VALUE_DOMAINS=GPR,XMM'
echo 'OLD_NEW_STATE_GENERATIONS=ABSORBED_INTO_VERSIONED_PHYSICAL_REALITY'
echo 'WHOLE_TRANSITION_PARALLEL_COMMIT=BUILT'
echo 'REGISTER_DAG_DEPTH_SCRATCH_BANK=REMOVED_IN_1_3_14'
echo 'FLOAT_PERSISTENT_STATE_BANK=XMM8-XMM10'
echo 'REUSE_WEIGHTED_FLOAT_CONSTANT_RESIDENCY=UNIFIED_PHYSICAL_CARRIER_POOL'
echo 'COUNTED_NATIVE_BOTTOM_TEST_BACKEDGE=BUILT'
echo 'ADMITTED_HOT_PUSH_POP=0'
echo 'ADMITTED_HOT_STATE_TEMP_TRAFFIC=0'
echo 'ADMITTED_FP_GPR_STACK_ROUNDTRIP=0'
echo 'TRAPPING_INTEGER_STACK_COMPAT_FALLBACK=SUPERSEDED_BY_GENERIC_ITERATE_FALLBACK'
echo 'RUNTIME_TRANSITION_GRAPH_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'WORKLOAD_NAME_SPECIALIZATION=0'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'BLIND_SURPLUS_REFLOW=PRESERVED'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_13_PEAK_PRESERVED=PASS'
echo 'WHEELCHAIR_1_3_13_BUILD=PASS'

# Wheelchair 1.3.14 Unified Physical Architecture Consolidation.
# New structures must first become facts in the existing Rank-N/Axis/Operator/
# Region/Effect/Capability + Versioned Physical Reality + Physical DAG system.
# Runtime work is never added merely to manage compiler abstractions.
echo 'UNIFIED_PHYSICAL_REALITY_1_3_14=BUILT'
echo 'GENERAL_TENSOR_FIELD_PHYSICAL_VOCABULARY=UNIFIED'
echo 'CAUSAL_STATE=RANK_N_CAUSAL_AXIS'
echo 'TRANSITION_DAG_STANDALONE=0'
echo 'OLD_NEW_GENERATION_STANDALONE=0'
echo 'FIXED_DEPTH_REGISTER_SCRATCH=0'
echo 'SCALAR_INTEGER_LIFETIME_CARRIER_ALLOCATOR=COMPILE_TIME'
echo 'SCALAR_FP_LIFETIME_CARRIER_ALLOCATOR=COMPILE_TIME'
echo 'SCALAR_FP_THREE_OPERAND_VEX=BUILT'
echo 'FP_CONSTANT_RESIDENCY=SHARED_PHYSICAL_CARRIER_AUTHORITY'
echo 'FP_FIXED_THREE_CONSTANT_SLOT_LIMIT=0'
echo 'LAST_CONSUMER_CARRIER_RELEASE=BUILT'
echo 'NATIVE256_BASE_WIDE_FRONTEND_SINGLE_SOURCE=1'
echo 'TENSOR_RUNTIME_ALL_PROFILES_SINGLE_SOURCE=1'
echo 'DEAD_PLACEHOLDER_HELPERS=0'
echo 'INTERNAL_COMPAT_WORKER_WRAPPERS=0'
echo 'DUPLICATE_RECURRENCE_STACK_BACKEND=0'
echo 'RUNTIME_FACT_MANAGER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'RUNTIME_TRANSITION_GRAPH_WALKER=0'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'WORKLOAD_NAME_SPECIALIZATION=0'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_14_BUILD=PASS'

# Wheelchair 1.3.15 Rank-N Causal Physicalization Closure.
# This strengthens the existing unified Physical Reality. State count affects
# only compile-time physical pressure; it never selects a private backend.
echo 'RANKN_CAUSAL_PHYSICALIZATION_1_3_15=BUILT'
echo 'CAUSAL_STATE_COUNT_ADMISSION_THRESHOLD=0'
echo 'COUNTED_INDUCTION=AXIS_AUTHORITY'
echo 'CAUSAL_PARTIAL_RESIDENCY=BUILT'
echo 'FP_INTEGER_MIXED_PARTIAL_RESIDENCY=BUILT'
echo 'PRIVATE_STATE_PAGE_OWNERSHIP=PRESERVED'
echo 'PRIVATE_STATE_PAGE_CACHE_COLORING=BUILT'
echo 'SPILL_CAUSE=PHYSICAL_PRESSURE_ONLY'
echo 'LARGE_N_STACK_EVALUATOR_FALLBACK=0'
echo 'RUNTIME_STATE_MANAGER=0'
echo 'RUNTIME_DAG_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_15_BUILD=PASS'

# Wheelchair 1.3.16 Whole-Episode Physical DAG Strengthening.
# This release does not add workload-specific or large-expression backends.
# It strengthens the existing Physical Reality so exact old-version facts are
# shared across simultaneous updates and carrier pressure cannot select the old
# generic stack path merely because another constant becomes profitable.
echo 'WHOLE_EPISODE_PHYSICAL_DAG_1_3_16=BUILT'
echo 'CROSS_NEXT_STATE_EXACT_VALUEFACT_CSE=BUILT'
echo 'STRICT_ORDER_CSE_REASSOCIATION=0'
echo 'CSE_RETAINED_SET=PARENT_CHILD_ANTICHAIN'
echo 'CSE_READY_FUTURE_IDENTITY=SEPARATE'
echo 'AOT_ANONYMOUS_TEMP_PRESSURE_PROOF=BUILT'
echo 'STATE_CSE_CONSTANT_TEMP_CARRIER_AUTHORITY=SHARED'
echo 'CONSTANT_COUNT_ADMISSION_THRESHOLD=0'
echo 'TEMP_PRESSURE_GENERIC_STACK_BACKEND_CLIFF=0'
echo 'RUNTIME_CSE_MANAGER=0'
echo 'RUNTIME_VALUEFACT_CACHE=0'
echo 'RUNTIME_DAG_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WORKLOAD_NAME_SPECIALIZATION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_16_BUILD=PASS'
# Wheelchair 1.3.17 External Silicon Authority, inherited by later releases.
# Wheelchair owns work only; completion terminates ownership and OS/hardware alone
# arbitrate execution capacity. 1.3.18 supersedes ready==must-clone with physical profitability.
echo 'EXTERNAL_SILICON_AUTHORITY_1_3_17=BUILT'
echo 'WHEELCHAIR_OWNS_WORK_NOT_SILICON=1'
echo 'READY_CAUSAL_WORK_DIRECT_MATERIALIZATION=SUPERSEDED_BY_PHYSICAL_PROFITABILITY'
echo 'DONE_EXECUTION_TERMINAL_RELEASE=1'
echo 'INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0'
echo 'CREDIT_BITMAP=0'
echo 'CAPACITY_CLAIM=0'
echo 'CAPACITY_RELEASE=0'
echo 'RUNTIME_CPU_PINNING=0'
echo 'PRECREATED_FUTURE_EXECUTORS=0'
echo 'SLEEPING_FUTURE_EXECUTORS=0'
echo 'GENERAL_SINGLE_PREDECESSOR_ATOMIC_ARRIVAL=0'
echo 'GENERAL_MULTI_PREDECESSOR_JOIN=LOCK_XADD_ONLY'
echo 'GENERAL_READY_SUCCESSOR_DIRECT_MATERIALIZATION=1'
echo 'GENERAL_EXECUTOR_RESOURCE_HANDOFF=0'
echo 'TENSOR_FIELD_SPLIT_RESOURCE_QUERY=0'
echo 'TENSOR_FIELD_SPLIT_DIRECT_OUTWARD_CLONE=0'
echo 'OS_HARDWARE_PLACEMENT_AUTHORITY=1'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_17_BUILD=PASS'

# Wheelchair 1.3.18 Emergent Outward Expansion.
# Expansion is a physical realization choice, never a resource query and never a
# work-size magic threshold. The compiler measures the target execution-context
# materialization price AOT and compares it with work cost derived from the
# existing Physical Reality. Runtime reads immutable facts only.
echo 'EMERGENT_OUTWARD_EXPANSION_1_3_18=BUILT'
echo 'READY_EQUALS_MUST_CLONE=0'
echo 'EXPANSION_WORKSIZE_MAGIC_THRESHOLD=0'
echo 'RUNTIME_RESOURCE_AVAILABILITY_EXPANSION_QUERY=0'
echo 'RUNTIME_CPU_COUNT_EXPANSION_SELECTOR=0'
echo 'AOT_OUTWARD_MATERIALIZATION_TARGET_PROFILE=BUILT'
echo 'AOT_LOCAL_WORK_PHYSICAL_COST=BUILT'
echo 'LOCAL_VS_OUTWARD=PHYSICAL_REALIZATION_PROFITABILITY'
echo 'TENSOR_LOCAL_CANONICAL_TREE=BUILT'
echo 'FIELD_LOCAL_CANONICAL_TREE=BUILT'
echo 'STRICT_REDUCTION_TREE_PRESERVED=1'
echo 'GENERAL_CAUSAL_REGION_COARSENING=PRESERVED'
echo 'INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0'
echo 'CREDIT_BITMAP=0'
echo 'CAPACITY_CLAIM=0'
echo 'CAPACITY_RELEASE=0'
echo 'RUNTIME_CPU_PINNING=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_18_BUILD=PASS'


# Wheelchair 1.3.19 Structural Execution Theory Consolidation.
# Structural execution is an AOT/diagnostic authority over the existing Physical
# DAG, not a new runtime layer. Equivalent causal depth is independently
# executable; serialization is represented only by real causal-depth increase.
echo 'STRUCTURAL_EXECUTION_THEORY_1_3_19=BUILT'
echo 'PROGRAM_ORDER_IS_CAUSAL_AUTHORITY=0'
echo 'EQUAL_CAUSAL_DEPTH_PARALLELISM=AOT_CAUSAL_PARTIAL_ORDER'
echo 'STRUCTURAL_EXECUTION_MODEL=W/(max(W/P,S)+H)'
echo 'STRUCTURAL_EXECUTION_IDEAL=min(P,W/S)'
echo 'INTRINSIC_CAUSAL_PARALLELISM=W/S'
echo 'W_S_H_OPTIMIZATION_CLASSIFICATION=BUILT'
echo 'AOT_STRUCTURAL_FACT_DIAGNOSTIC=BUILT'
echo 'RUNTIME_CAUSAL_DEPTH_QUEUE=0'
echo 'RUNTIME_SERIAL_FRACTION_MANAGER=0'
echo 'RUNTIME_STRUCTURAL_SCHEDULER=0'
echo 'HARD_CODED_CAUSAL_DEPTH_THRESHOLD=0'
echo 'RUNTIME_RESOURCE_AVAILABILITY_EXPANSION_QUERY=0'
echo 'STRUCTURAL_EXECUTION_HOT_RUNTIME_DELTA=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_19_BUILD=PASS'

# Wheelchair 1.3.20 Unified ValueFact Pressure Remap.
echo 'UNIFIED_VALUEFACT_PRESSURE_REMAP_1_3_20=BUILT'
echo 'PRIVATE_TRANSITION_SHAPE_EMITTERS=0'
echo 'STATE_COUNT_ISA_ROUTE=0'
echo 'PERSISTENT_NEXT_BANK=PHYSICAL_CANDIDATE_NOT_SEMANTIC_RULE'
echo 'SHARED_VALUEFACT_CARRIER_EXHAUSTION=AOT_REMAP_TRIGGER'
echo 'TRANSIENT_NEXT_VERSION_USES_EXISTING_STATE_TEMP=1'
echo 'GENERIC_MACHINE_SEQUENCE_CANONICALIZATION=BUILT'
echo 'WORKLOAD_SPECIFIC_PRESSURE_ROUTE=0'
echo 'CHEMISTRY_SPECIAL_PATH=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'RUNTIME_VALUEFACT_MANAGER=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_20_BUILD=PASS'


# Wheelchair 1.3.21 Physical ValueFact Transport Sparsification.
echo 'PHYSICAL_VALUEFACT_TRANSPORT_SPARSIFICATION_1_3_21=BUILT'
echo 'TIMESTEP_BOUNDARY_FORCES_TRANSPORT=0'
echo 'OLD_AUTHORITY_REUSE=FINAL_EFFECTIVE_CONSUMER'
echo 'FP_STATE_RESIDENCY_MAGIC_THRESHOLD=0'
echo 'PERSISTENT_NEXT_COLLISION_ROUTE=PHYSICAL_CARRIER_CONFLICT'
echo 'FP_CARRIER_EXHAUSTION_RETRY=AOT_PHYSICAL_REMAP'
echo 'WORKLOAD_SPECIFIC_TRANSPORT_ROUTE=0'
echo 'CHEMISTRY_SPECIAL_PATH=0'
echo 'RUNTIME_TRANSPORT_MANAGER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_21_BUILD=PASS'

# Wheelchair 1.3.22 Predicate ValueFact Persistence / Boolean Sparsification.
echo 'PREDICATE_VALUEFACT_PERSISTENCE_1_3_22=BUILT'
echo 'REPEATED_PREDICATE_REEVALUATION_WITHOUT_VERSION_CHANGE=0'
echo 'PREDICATE_REPEAT_MAGIC_THRESHOLD=0'
echo 'PREDICATE_REUSE_DEPENDENCY=AOT_PHYSICAL_DAG'
echo 'FIXED_BOUNDARY_SELECT_MATCHER=0'
echo 'FIXED_STATE_AFFINE_ITERATE_ROUTE=0'
echo 'RUNTIME_PREDICATE_MANAGER=0'
echo 'RUNTIME_VALUEFACT_MANAGER=0'
echo 'WORKLOAD_SPECIFIC_BOOLEAN_ROUTE=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_22_BUILD=PASS'

# Wheelchair 1.3.23 Composition-Closed Transition Power inside the existing
# counted recurrence Physical Reality. Published-result backward slicing may
# erase irrelevant state work and represent F^N by binary composition when the
# result transition is algebraically proved closed under composition.
echo 'COMPOSITION_CLOSED_TRANSITION_POWER_1_3_23=BUILT'
echo 'TRANSITION_POWER_AUTHORITY=EXISTING_PHYSICAL_REALITY'
echo 'TRANSITION_POWER_BACKWARD_SLICE=PUBLISHED_RESULT'
echo 'TRANSITION_POWER_STATE_COUNT_ROUTE=0'
echo 'TRANSITION_POWER_REPEAT_MAGIC_THRESHOLD=0'
echo 'FIXED_AFFINE_AST_MATCHER=0'
echo 'FIXED_TWO_STATE_AFFINE_ROUTE=0'
echo 'RUNTIME_TRANSITION_POWER_MANAGER=0'
echo 'WORKLOAD_SPECIFIC_TRANSITION_POWER_ROUTE=0'
echo 'FROZEN_BOUNDARY_SELECT_PRIVATE_MATCHER=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_23_BUILD=PASS'

# Wheelchair 1.3.24 Branch Extinction / Physical-DAG Closure.
# Deleted private lanes are not compatibility-disabled; their useful mathematics
# is represented by the existing ValueFact/Physical-Reality authority.
echo 'BRANCH_EXTINCTION_1_3_24=BUILT'
echo 'SINGLE_CURRENT_SOURCE_AUTHORITY=PASS'
echo 'COMMON_FACTOR_VALUEFACT_CLOSURE=BUILT'
echo 'COMMON_FACTOR_PRIVATE_OPCODE=0'
echo 'COMMON_FACTOR_FIXED_TERM_COUNT_ROUTE=0'
echo 'FIELD_GENERIC_BACKWARD_ABI=0'
echo 'SOURCE_TEXT_FRONTEND_ROUTER=0'
echo 'LEGACY_EXECUTOR_CLI=0'
echo 'LEGACY_CASCADE_CHUNK_SYNTAX=0'
echo 'FIXED_CHUNK_GEOMETRY=0'
echo 'CHUNK_GRAIN_AUTHORITY=AOT_PHYSICAL_REALITY'
echo 'FIXED_REDUCTION_DEPTH_FROM_CHUNK=0'
echo 'RUNTIME_COMMUNICATION_COMPAT_PATCH=0'
echo 'PRODUCTION_FROZEN_SOURCE_AUTHORITY=0'
echo 'WORKLOAD_SPECIFIC_OPTIMIZATION_ROUTE=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_24_BUILD=PASS'

# Wheelchair 1.3.25 release-surface authority.
# Production executables exist only in bin/. Root-level executable duplicates are forbidden.
mkdir -p "$ROOT/bin"
for f in \
  wheelchairc whexc topologyc topologyc-wide topologyc-derived \
  topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 \
  fieldc fieldc-native256; do
  cp "$BUILD/$f" "$ROOT/bin/$f"
done

echo 'BIN_IS_SOLE_EXECUTABLE_AUTHORITY=PASS'
echo 'PRODUCTION_SOURCE_DEPENDS_ON_DEVTRASH=0'
echo 'ROOT_EXECUTABLE_DUPLICATES=0'
echo 'DEVTRASH_NON_AUTHORITATIVE=PASS'
echo 'WHEELCHAIR_1_3_25_BUILD=PASS'


# Wheelchair 1.3.26 Field ValueFact Phase-Lifetime Completion.
# This extends the existing LoadFact/AddressFact/Physical-Reality authority;
# no neighborhood/workload matcher or secondary field backend is introduced.
echo 'FIELD_VALUEFACT_PHASE_LIFETIME_1_3_26=BUILT'
echo 'RESIDENT_CAPACITY_AUTHORITY=PHYSICAL_CARRIER_TABLE'
echo 'SINGLE_USE_LOADFACT_RESIDENCY=1'
echo 'LOADFACT_REUSE_THRESHOLD_ROUTE=0'
echo 'GLOBAL_INTEGER_RESIDENCY_KILL_SWITCH=0'
echo 'HELPER_COMPLETION_RELEASES_CARRIERS=1'
echo 'REGULAR_RESIDENT_REDUNDANT_STACK_TRANSPORT=0'
echo 'RESIDENT_RELOAD_AUTHORITY=LIFETIME_CLOBBER_FACT'
echo 'AVX512_FULL_POST_HELPER_CARRIER_BANK=BUILT'
echo 'AVX2_POST_HELPER_CARRIER_REUSE=BUILT'
echo 'WORKLOAD_SPECIFIC_NEIGHBOR_ROUTE=0'
echo 'STENCIL_WIDTH_DISPATCH=0'
echo 'RUNTIME_RESIDENCY_MANAGER=0'
echo 'WHEELCHAIR_1_3_26_BUILD=PASS'

# Wheelchair 1.3.27 Physical Carrier Lifetime Closure.
# Regular preload, resident backup, arithmetic helper ABI, and final carrier
# ownership are one Physical-Reality lifetime problem. No workload/store matcher
# or second Field backend is introduced.
echo 'FIELD_CARRIER_LIFETIME_CLOSURE_1_3_27=BUILT'
echo 'PRELOAD_SIMD0_IMPLICIT_TRANSPORT=0'
echo 'PRELOAD_PHASE_SCRATCH_AUTHORITY=UNOWNED_LOGICAL_CARRIER'
echo 'RESIDENT_BACKUP_SOURCE=ACTUAL_RESIDENT_CARRIER'
echo 'RESIDENT_RELOAD_AUTHORITY=LAST_LOAD_VS_CLOBBER_INTERVAL'
echo 'GLOBAL_RESIDENT_STACK_BACKUP_FLAG=0'
echo 'STORE_DISABLES_RESIDENCY_ROUTE=0'
echo 'WORKLOAD_SPECIFIC_STORE_ROUTE=0'
echo 'RUNTIME_CARRIER_LIFETIME_MANAGER=0'
echo 'WHEELCHAIR_1_3_27_BUILD=PASS'

# Wheelchair 1.3.28 Native Mathematics Foundation.
# Mathematical semantics strengthen the existing AST/Rank-N/ValueFact/Physical-DAG
# authorities. No mathematical IR, runtime, scheduler, executor or library ABI exists.
echo 'NATIVE_MATHEMATICS_FOUNDATION_1_3_28=BUILT'
echo 'MATHEMATICS_NATIVE_SEMANTICS=EXISTING_AST_RANKN_VALUEFACT_PHYSICAL_DAG'
echo 'MATH_IR=0'
echo 'MATH_RUNTIME=0'
echo 'MATH_SCHEDULER=0'
echo 'MATH_EXECUTOR=0'
echo 'LIBM_DEPENDENCY=0'
echo 'NATIVE_SQRT_GENERAL=BUILT'
echo 'NATIVE_SQRT_TENSOR=BUILT'
echo 'NATIVE_SQRT_FIELD=BUILT'
echo 'NATIVE_LINEAR_REDUCTION_SEMANTICS=DOT_INNER_FROBENIUS_SQUARED_NORM_SQUARED_DISTANCE'
echo 'GENERAL_VALUEFACT_ARITY=UNARY_AND_BINARY'
echo 'SELECTED_AXIS_CONTRACTION_AUTHORITY=EXISTING_RANKN_AUTHORITY'
echo 'FAKE_MATRIX_TRACE_ROUTE=0'
echo 'FAKE_QUADRATIC_FORM_ROUTE=0'
echo 'WORKLOAD_SPECIFIC_MATH_ROUTE=0'
echo 'WHEELCHAIR_1_3_28_BUILD=PASS'

# Wheelchair 1.3.30 Local Low-Precision Contagion.
# This strengthens the existing General ValueFact/Physical-DAG type meet. A low
# floating precision propagates only across the real consumer edge where it meets
# another precision; child subtrees retain their own natural precision. Repeated
# projections reuse the existing whole-episode ValueFact CSE when physical carrier
# reality admits retention. No precision-specific runtime or scheduler exists.
echo 'LOW_PRECISION_CONTAGION_1_3_30=BUILT'
echo 'DEFAULT_IMPLICIT_FP_MERGE_RULE=LOWER_PRECISION_DOMINATES'
echo 'PRECISION_PROPAGATION_SCOPE=VALUEFACT_CONSUMER_EDGE'
echo 'EAGER_WHOLE_DAG_NARROWING=0'
echo 'DEFAULT_IMPLICIT_LOW_TO_HIGH_PROMOTION=0'
echo 'MIXED_FP_NATIVE_PHYSICAL_OPS=ADD_SUB_MUL_DIV_SQRT'
echo 'PRECISION_PROJECTION_AUTHORITY=EXISTING_VALUEFACT_CSE'
echo 'MANDATORY_DUPLICATE_PRECISION_CONVERSION=0'
echo 'PRECISION_RUNTIME_MANAGER=0'
echo 'PRECISION_SCHEDULER=0'
echo 'WHEELCHAIR_1_3_30_LOW_PRECISION_PROPAGATION=PASS'


# Wheelchair 1.3.31 Precision Propagation / Rank-N Contraction Closure.
# No new execution branch: the existing type-meet, Rank-N, source-shape,
# ValueFact and Physical-DAG authorities absorb the missing semantics.
echo 'PRECISION_PROPAGATION_SWITCH_1_3_31=BUILT'
echo 'PRECISION_PROPAGATION_DEFAULT=LOWER'
echo 'PRECISION_PROPAGATION_ALTERNATE=HIGHER'
echo 'PRECISION_PROPAGATION_SCOPE=VALUEFACT_CONSUMER_EDGE'
echo 'EAGER_WHOLE_DAG_PRECISION_REWRITE=0'
echo 'MIXED_PRECISION_RUNTIME=0'
echo 'SELECTED_AXIS_CONTRACTION_1_3_31=BUILT'
echo 'ARBITRARY_RADIX_RANKN_1_3_31=BUILT'
echo 'SOURCE_SHAPE_AUTHORITY=PER_DECLARATION'
echo 'EXECUTION_DOMAIN_AUTHORITY=FINAL_REDUCTION'
echo 'RANK1_REWRITE=IDENTITY_WITH_SOURCE_SHAPE_AWARE_LOADS'
echo 'MATRIX_RUNTIME=0'
echo 'BLAS_DEPENDENCY=0'
echo 'WORKLOAD_SPECIFIC_MATMUL_ROUTE=0'
echo 'WORKLOAD_SPECIFIC_TRACE_ROUTE=0'
echo 'RUNTIME_RANKN_SHAPE_MANAGER=0'
echo 'WHEELCHAIR_1_3_31_BUILD=PASS'

# Wheelchair 1.3.34 Semantic Fact / Native Mathematics Convergence.
# New mathematical vocabulary is registry-owned surface semantics or ordinary
# ValueFacts over the existing Rank-N / Physical-Reality architecture.
echo 'SEMANTIC_FACT_AUTHORITY_1_3_34=BUILT'
echo 'SEMANTIC_MATH_REGISTRY_1_3_34=BUILT'
echo 'SEMANTIC_PARSE_REGISTRY_1_3_34=BUILT'
echo 'MATH_SEMANTIC_ARITY_AUTHORITY=REGISTRY'
echo 'TEST_VECTOR_SEMANTIC_PREREQUISITE=0'
echo 'NATIVE_ELEMENTARY_MATH_1_3_34=BUILT'
echo 'NATIVE_SPECIAL_MATH_1_3_34=BUILT'
echo 'NATIVE_CALCULUS_1_3_34=BUILT'
echo 'NATIVE_RANKN_MATHEMATICS_1_3_34=BUILT'
echo 'MATH_RUNTIME=0'
echo 'MATH_SCHEDULER=0'
echo 'MATH_EXECUTOR=0'
echo 'MATRIX_RUNTIME=0'
echo 'LIBM_DEPENDENCY=0'
echo 'BLAS_DEPENDENCY=0'
echo 'WORKLOAD_SPECIFIC_MATH_ROUTE=0'
echo 'WHEELCHAIR_1_3_34_BUILD=PASS'


# Wheelchair 1.3.36 Structured Fact Assimilation.
# Architecture evolution order is a release invariant: parasite the old
# authority first, strengthen the old authority second, and create a new
# authority only when the old one cannot express the semantics. Any necessary
# new authority must remain high-affinity/high-extensibility and be assimilated
# back into the common old architecture rather than becoming a feature branch.
echo 'STRUCTURED_FACT_ASSIMILATION_1_3_36=BUILT'
echo 'ARCHITECTURE_PRIORITY=PARASITE_OLD_THEN_STRENGTHEN_OLD_THEN_NEW_LAST_RESORT'
echo 'NEW_ARCHITECTURE_REQUIREMENT=HIGH_AFFINITY_HIGH_EXTENSIBILITY_ASSIMILATABLE'
echo 'STRUCTURED_LET_BOUNDARY=OLD_SCALAR_COMPUTE_BINDING_VALUEFACT'
echo 'STRUCTURED_RUNTIME=0'
echo 'COMPLEX_RUNTIME=0'
echo 'MATRIX_RUNTIME=0'
echo 'SVD_RUNTIME=0'
echo 'EIG_RUNTIME=0'
echo 'WHEELCHAIR_1_3_36_BUILD=PASS'

# Wheelchair 1.3.38 Parameterized Rank-N Precision Assimilation.
# Precision <=64 remains native. Every fpP with P>64 is one encoded precision
# fact whose physical span is a Rank-N limb axis. No named wide-width semantic,
# runtime helper family, compatibility alias, scheduler, or executor is allowed.
grep -q 'Encoded type: RPF_TYPE_FLAG | significand_bits' runtime/rankn_precision_physical_x86_64.inc
grep -q 'precision is data, not a' compiler/general_frontend_x86_64.S
grep -q 'Precision policy is deliberately absent here' compiler/general_frontend_x86_64.S
if grep -RIE --include='*.S' --include='*.inc' --include='*.sh' \
  'TYPE_F(128|256)|GTYPE_F(128|256)|STF_FP(128|256)|(^|[^[:alnum:]_])(fp128|fp256|f128|f256|float128|float256)([^[:alnum:]_]|$)|wide_float_x86_64' \
  compiler runtime tools >/dev/null 2>&1; then
    echo 'dedicated fixed-width floating authority survived 1.3.38' >&2
    exit 1
fi
echo 'PARAMETRIC_RANKN_FP_1_3_38=BUILT'
echo 'FP_NATIVE_THRESHOLD_BITS=64'
echo 'FP_GT64_AUTHORITY=RANKN_PRECISION_LIMB_AXIS'
echo 'FP_NAMED_WIDTH_BRANCHES=0'
echo 'FP_PRECISION_PARAMETER=SIGNIFICAND_BITS'
echo 'FP_ROUNDING=NEAREST_EVEN'
echo 'FP_PRECISION_AUTHORITY=EXISTING_G_LOW_TYPE_MEET_FIRST'
echo 'FP_VALUE_ABI=ONE_QWORD_REFERENCE_TO_AOT_OWNED_RANKN_CARRIER'
echo 'FP_DYNAMIC_ALLOCATOR=0'
echo 'FP_RUNTIME_SCHEDULER=0'
echo 'FP_RUNTIME_EXECUTOR=0'
echo 'FP_BATCH_VECTOR_RELEASE_CLAIM=0'
echo 'WHEELCHAIR_1_3_38_BUILD=PASS'

# Wheelchair 1.3.40 Native Fourier Precision Assimilation.
# Every P>64 multiplication uses one local Fourier factorization authority.
# Geometry is P data constrained by one native-SIMD rounding budget and one
# continuous physical cost surface. No parallel multiplication authority,
# external Fourier runtime, or named-precision threshold tree is admitted.
[ "$(grep -c '^\.global rankn_fp_mul$' runtime/rankn_precision_physical_x86_64.inc)" -eq 1 ]
grep -q 'rpf_fourier_mul_u64' runtime/rankn_precision_physical_x86_64.inc
grep -q 'Forward DIF order is 5 -> 3 -> 2' runtime/rankn_precision_physical_x86_64.inc
grep -q '0x0007ffffffffffff' runtime/rankn_precision_physical_x86_64.inc
grep -q 'Base-2\^32 Knuth digit division' runtime/rankn_precision_physical_x86_64.inc
! grep -q '^\.extern ' runtime/rankn_precision_physical_x86_64.inc
[ ! -e runtime/rankn_precision_x86_64.inc ]
echo 'RANKN_PRECISION_FOURIER_1_3_40=BUILT'
echo 'FP_GT64_MULTIPLICATION=ONE_NATIVE_FOURIER_AUTHORITY'
echo 'FP_FOURIER_FORWARD=DIF_RADIX_5_3_2'
echo 'FP_FOURIER_INVERSE=DIT_RADIX_2_3_5'
echo 'FP_FOURIER_PACKING=Z_EQUALS_A_PLUS_I_B_SQUARED_SPECTRUM'
echo 'FP_FOURIER_GLOBAL_PERMUTATION=0'
echo 'FP_FOURIER_EXTERNAL_LIBRARY=0'
echo 'FP_FOURIER_RUNTIME_ALLOCATOR=0'
echo 'FP_MULTIPLICATION_ALGORITHM_SELECTOR=0'
echo 'FP_FIXED_PRECISION_THRESHOLD_SWITCH=0'
echo 'FP_DIVISION=BASE32_KNUTH_NO_BITWISE_RESTORING'
echo 'WHEELCHAIR_1_3_40_BUILD=PASS'


# Wheelchair 1.3.41 Sparse Native Mathematics Fusion.
# Existing mathematics converges on shared old-algorithm facts. No runtime
# mathematics branch, solver object, algorithm selector or compatibility path.
grep -q '^s_expand_exp_seed_q_ast:' compiler/surface_lowerer_x86_64.S
grep -q '^s_expand_log1p_ast:' compiler/surface_lowerer_x86_64.S
grep -q '^s_expand_erf_tail_ast:' compiler/surface_lowerer_x86_64.S
grep -q '^s_expand_lanczos_core_ast:' compiler/surface_lowerer_x86_64.S
grep -q '^s_expand_scaled_hypot_ast:' compiler/surface_lowerer_x86_64.S
grep -q 'OP_SELECT owns SN_C as its false dataflow edge' compiler/surface_lowerer_x86_64.S
echo 'SPARSE_NATIVE_MATHEMATICS_FUSION_1_3_41=BUILT'
echo 'MATH_FUSION_RULE=A_INTERSECTION_B_NOT_A_PLUS_B'
echo 'MATH_RUNTIME_CONTROL_BRANCH=0'
echo 'MATH_ALGORITHM_SELECTOR=0'
echo 'MATH_COMPATIBILITY_FALLBACK=0'
echo 'WHEELCHAIR_1_3_41_BUILD=PASS'

# Wheelchair 1.3.42 Sparse Root Relation.
# Root is one compile-time mathematical relation whose result type is discovered
# on-site as sparse validity + real/imag facts.  Newton remains one authority;
# complex arithmetic, structured differentiation and transcendental semantics are
# parasitized from existing Structured/ValueFact machinery.
grep -q '^\.equ STF_ROOT,2' compiler/surface_lowerer_x86_64.S
grep -q '^\.equ MB_ROOT_VALID,96' compiler/surface_lowerer_x86_64.S
grep -q '^s_clone_subst_root:' compiler/surface_lowerer_x86_64.S
grep -q '^s_root_select_new:' compiler/surface_lowerer_x86_64.S
grep -q '^s_ast_diff_struct:' compiler/surface_lowerer_x86_64.S
grep -q 'Zero derivative is not a solver fork' compiler/surface_lowerer_x86_64.S
[ "$(grep -c '^s_parse_root_call:' compiler/surface_lowerer_x86_64.S)" -eq 1 ]
echo 'SPARSE_ROOT_RELATION_1_3_42=BUILT'
echo 'ROOT_RELATION=ONE_NEWTON_AUTHORITY'
echo 'ROOT_DEFAULT_AOT_ITERATIONS=5'
echo 'ROOT_ITERATION_PARAMETER=STATIC_NONNEGATIVE_INTEGER'
echo 'ROOT_RESULT=SPARSE_VALID_REAL_IMAG_FACTS'
echo 'ROOT_RESULT_TYPE_PREDECLARATION=0'
echo 'ROOT_REAL_COMPLEX_SOLVER_FORK=0'
echo 'ROOT_RUNTIME_SOLVER=0'
echo 'ROOT_RUNTIME_ALGORITHM_SELECTOR=0'
echo 'ROOT_ZERO_DERIVATIVE_RUNTIME_FAILURE=0'
echo 'ROOT_EMPTY=NO_ACCEPTED_CANDIDATE_WITHIN_AOT_BUDGET'
echo 'WHEELCHAIR_1_3_42_BUILD=PASS'

# Wheelchair 1.3.43 Root Precision Assimilation.
# RootRelation consumes the existing precision facts directly.  P>64 comparison
# is one numeric carrier authority; convergence and real projection use current-
# representation stability.  No named root width, f64 tolerance, or precision
# algorithm selector is admitted.
grep -q '^\.global rankn_fp_cmp$' runtime/rankn_precision_physical_x86_64.inc
grep -q '^s_root_negligible_ast:' compiler/surface_lowerer_x86_64.S
grep -q 'cmp r10d,dword ptr \[rsp+40\]' runtime/rankn_precision_physical_x86_64.inc
! grep -Eq '0x3cb0000000000000|0x7fefffffffffffff' compiler/surface_lowerer_x86_64.S
if grep -RIE --include='*.S' --include='*.inc' \
  'root_fp(65|73|127|128|191|256|257|521)|fp(65|73|127|128|191|256|257|521)_root|root_width_selector|root_precision_selector' \
  compiler runtime >/dev/null 2>&1; then
    echo 'named root precision authority survived 1.3.43' >&2
    exit 1
fi
echo 'ROOT_PRECISION_FUSION_1_3_43=BUILT'
echo 'ROOT_PRECISION_AUTHORITY=CURRENT_VALUEFACT_REPRESENTATION'
echo 'ROOT_FP_GT64_COMPARE=ONE_NUMERIC_AUTHORITY'
echo 'ROOT_FIXED_F64_EPSILON=0'
echo 'ROOT_DBL_MAX_GATE=0'
echo 'ROOT_NAMED_WIDTH_BRANCHES=0'
echo 'FOURIER_AOT_N64_BOUNDARY=EXACT_32BIT_FACT'
echo 'WHEELCHAIR_1_3_43_BUILD=PASS'

# Wheelchair 1.3.44 Mathematics Generalization.
# One dimension-bearing Matrix family and one P-derived fpP transcendental
# family strengthen existing Structured/Precision facts.  No matrix-size or
# named-precision algorithm authority is admitted.
grep -q '^\.equ STF_MATRIX_BASE,0x100' compiler/surface_lowerer_x86_64.S
grep -q '^s_parse_matrix_relation_call:' compiler/surface_lowerer_x86_64.S
grep -q '^s_materialize_struct:' compiler/surface_lowerer_x86_64.S
grep -q 'Gauss-Jordan with dataflow partial pivoting' compiler/surface_lowerer_x86_64.S
for fn in sqrt exp log sin cos; do
  grep -q "^\.global rankn_fp_${fn}$" runtime/rankn_precision_physical_x86_64.inc
  [ "$(grep -c "^rankn_fp_${fn}:" runtime/rankn_precision_physical_x86_64.inc)" -eq 1 ]
done
if grep -RIE --include='*.S' --include='*.inc' \
  '(matrix(5|6|7|8|16|32)_(mul|inverse|eig|svd)|rankn_fp_(sqrt|exp|log|sin|cos)_(65|73|127|128|191|256|257|521)|fp(65|73|127|128|191|256|257|521)_(sqrt|exp|log|sin|cos)|NRII.*runtime|nrii.*runtime)' \
  compiler runtime >/dev/null 2>&1; then
  echo 'named-size/named-precision mathematics authority survived 1.3.44' >&2
  exit 1
fi
echo 'MATHEMATICS_GENERALIZATION_1_3_44=BUILT'
echo 'MATRIX_FAMILY=ONE_DIMENSION_BEARING_STRUCTURED_AUTHORITY'
echo 'MATRIX_NAMED_SIZE_ALGORITHMS=0'
echo 'MATRIX_INVERSE_PIVOT=DATAFLOW_PARTIAL_PIVOT'
echo 'FP_GT64_TRANSCENDENTAL_AUTHORITY=ONE_PARAMETERIZED_FPP_FAMILY'
echo 'FP_GT64_SQRT_EXP_LOG_SIN_COS=NATIVE'
echo 'FP_GT64_NAMED_WIDTH_TRANSCENDENTALS=0'
echo 'NRII_SOLVER_IMPORTED=0'
echo 'NRII_LOCAL_PROPAGATION_IDEA_ONLY=1'
echo 'WHEELCHAIR_1_3_44_BUILD=PASS'

# Wheelchair 1.3.45 Human-Shell Static Structure Bridge.
# This release exposes no new runtime/backend authority. Existing MatrixFact,
# selected-axis contraction, and field-neighborhood facts are allowed to meet in
# the WH field human shell and must erase before canonical emission.
grep -q '^\.equ NK_STATIC_MGET,16' compiler/surface_lowerer_x86_64.S
grep -q '^sfh_parse_static_struct_let:' compiler/field_surface_lowerer_x86_64.inc
grep -q '^sfh_index_affine_delta:' compiler/field_surface_lowerer_x86_64.inc
echo 'HUMAN_SHELL_STATIC_BRIDGE_1_3_45=BUILT'
echo 'HUMAN_SHELL_NEW_RUNTIME_AUTHORITY=0'
echo 'HUMAN_SHELL_NEW_FIELD_OPCODE=0'
echo 'HUMAN_SHELL_COMPACT_EXPANDED_ELF_EQUIVALENCE=RELEASE_TESTED'
echo 'WHEELCHAIR_1_3_45_BUILD=PASS'

# Wheelchair 1.3.46 Human-Shell Static Select Erasure.
# Once lexical contraction substitution closes a select predicate, the WH
# human shell retains only the selected source branch before scalar AST
# materialization.  This adds no runtime/backend authority or field opcode.
grep -q '^\.scs_static_select_false:' compiler/surface_lowerer_x86_64.S
grep -q 'call s_eval_static_u64' compiler/surface_lowerer_x86_64.S
echo 'HUMAN_SHELL_STATIC_SELECT_1_3_46=BUILT'
echo 'HUMAN_SHELL_STATIC_SELECT_RUNTIME_BRANCH=0'
echo 'HUMAN_SHELL_STATIC_SELECT_NEW_FIELD_OPCODE=0'
echo 'HUMAN_SHELL_STATIC_SELECT_DEAD_BRANCH_CLONE=0'
echo 'WHEELCHAIR_1_3_46_BUILD=PASS'

# Wheelchair 1.3.47 native256 physical ownership aging.
# AVX2 keeps one real YMM0..15 bank.  Field logical carriers, tail/reduction
# state, procedural indices, helper scratch and reloadable residents consume one
# compile-time ownership profile.  Tensor native256 no longer maintains a copied
# synthetic high-register cache/constant ownership state.  No workload route,
# runtime scheduler or native512 physicalization rule is added.
grep -q '^\.equ N256_SIMD_REG_COUNT,16$' compiler/native256_physical_profile.inc
grep -q '^\.equ N256_HAS_HIGH_SIMD_BANK,0$' compiler/native256_physical_profile.inc
grep -q '^\.equ FF256_V3_REG,12$' compiler/native256_physical_profile.inc
grep -q '^\.equ FF256_TAIL_MASK_REG,4$' compiler/native256_physical_profile.inc
grep -q '^\.equ FF256_REDUCE_REG,5$' compiler/native256_physical_profile.inc
grep -q '^\.include "compiler/native256_physical_profile.inc"$' compiler/field_frontend_256_x86_64.S
grep -q '^\.include "compiler/native256_physical_profile.inc"$' runtime/field_runtime_256_x86_64.S
grep -q '^\.include "compiler/native256_physical_profile.inc"$' compiler/tensor_frontend_native256_138.S
grep -q '^\.include "compiler/native256_physical_profile.inc"$' compiler/tensor_frontend_derived_native256_138.S
! grep -q 'vec_cache_reg_mask:' compiler/tensor_frontend_native256_138.S
! grep -q 'vec_const_reg_mask:' compiler/tensor_frontend_native256_138.S
! grep -q 'vec_cache_reg_mask:' compiler/tensor_frontend_derived_native256_138.S
! grep -q 'vec_const_reg_mask:' compiler/tensor_frontend_derived_native256_138.S
echo 'NATIVE256_PHYSICAL_OWNERSHIP_1_3_47=BUILT'
echo 'NATIVE256_SIMD_BANK=YMM0_TO_YMM15'
echo 'NATIVE256_SYNTHETIC_HIGH_SIMD_BANK=0'
echo 'NATIVE256_REGISTER_ROLE_AUTHORITY=ONE_COMPILE_TIME_PHYSICAL_PROFILE'
echo 'NATIVE256_WORKLOAD_REGISTER_ROUTE=0'
echo 'NATIVE256_RUNTIME_REGISTER_MANAGER=0'
echo 'NATIVE256_RUNTIME_SCHEDULER=0'
echo 'NATIVE512_PHYSICALIZATION_CHANGE=0'
echo 'WHEELCHAIR_1_3_47_BUILD=PASS'

# Wheelchair 1.3.48 native256 ValueFact lifetime convergence.
# The existing Physical DAG owns producer liveness. Planning and emission share
# that proof so dead immutable transport disappears into the existing strict MUL
# memory/register operand. LoadFact and ConstantFact compete in one native256
# carrier economy after transport erasure. Existing episode mask/q facts are
# consumed directly by contiguous stores. No arithmetic cache, workload route,
# runtime value manager, Field opcode or native512 physicalization is added.
grep -q '^ff_consumer_local_foldable_1348:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_try_consumer_local_fold_1348:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_vbin_stack_1348:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_direct_regular_store_from:' compiler/field_frontend_common_x86_64.S
grep -q 'ff_const_pool_transport_demand' compiler/field_frontend_common_x86_64.S
! grep -q 'ff_build_arith_fact_cache_1348' compiler/field_frontend_common_x86_64.S
! grep -q 'ff_arith_fact_cache_slot' compiler/field_frontend_common_x86_64.S
echo 'VALUEFACT_LIFETIME_CONVERGENCE_1_3_48=BUILT'
echo 'NATIVE256_CONSUMER_LOCAL_FOLD=ONE_LIVENESS_AUTHORITY'
echo 'NATIVE256_ARITHMETIC_STACK_CACHE=0'
echo 'NATIVE256_WORKLOAD_VALUEFACT_ROUTE=0'
echo 'NATIVE256_RUNTIME_VALUEFACT_MANAGER=0'
echo 'NATIVE512_PHYSICALIZATION_CHANGE=0'
echo 'WHEELCHAIR_1_3_48_BUILD=PASS'

# Wheelchair 1.3.49 Unified Sparse Physical Materialization.
# Logical DAG width remains complete; physical state is born only at a proven
# consumer frontier and long-/short-lived facts receive disjoint AOT-derived
# carrier lifetime domains. ISA differences are capabilities/encoding only.
grep -q '^ff_consumer_local_foldable_1348:' compiler/field_frontend_common_x86_64.S
grep -q '^tensor149_select_persistent_facts:' compiler/tensor_frontend_138_x86_64.S
grep -q '^tensor149_mark_transient_borrow:' compiler/tensor_frontend_138_x86_64.S
grep -q '^vec_persistent_reg_alloc:' compiler/tensor_frontend_138_x86_64.S
grep -q '^vec_cache_reg_alloc:' compiler/tensor_frontend_138_x86_64.S
! grep -q 'profile_pressure:' compiler/native_driver_x86_64.S
! grep -q 'T137_PROFILE_BASE' compiler/tensor_frontend_138_x86_64.S
! grep -q 'T137_CACHE_COUNT-2' compiler/tensor_frontend_138_x86_64.S
! grep -q 'T138_NATIVE256_PROFILE_BASE' compiler/tensor_frontend_native256_138.S
cmp -s "$BUILD/topologyc" "$BUILD/topologyc-wide"
cmp -s "$BUILD/topologyc-native256" "$BUILD/topologyc-wide-native256"
echo 'SPARSE_PHYSICAL_MATERIALIZATION_1_3_49=BUILT'
echo 'FIELD_256_512_MATERIALIZATION_POLICY=ONE_COMMON_AUTHORITY'
echo 'FIELD_CONSUMER_LOCAL_FOLD_256_512=CAPABILITY_DRIVEN'
echo 'TENSOR_BASE_WIDE_PROFILE_SPLIT=0'
echo 'NATIVE256_BASE_WIDE_PROFILE_SPLIT=0'
echo 'TENSOR_PERSISTENT_TRANSIENT_LIFETIME_SPLIT=AOT_DAG_DERIVED'
echo 'TENSOR_FIXED_LOAD_COUNT_PROFILE_THRESHOLDS=0'
echo 'TENSOR_FIXED_RESIDENCY_USE_THRESHOLD=0'
echo 'TENSOR_FIXED_PERSISTENT_RESERVE=0'
echo 'TENSOR_RUNTIME_MATERIALIZATION_MANAGER=0'
echo 'TENSOR_GLOBAL_READY_QUEUE=0'
echo 'TENSOR_WORK_STEALING=0'
echo 'WHEELCHAIR_1_3_49_BUILD=PASS'
