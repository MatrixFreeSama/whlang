#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

rm -rf build
./build.sh > .release_build_1316.log 2>&1
for marker in \
 WHEELCHAIR_1_3_15_BUILD=PASS \
 WHOLE_EPISODE_PHYSICAL_DAG_1_3_16=BUILT \
 CROSS_NEXT_STATE_EXACT_VALUEFACT_CSE=BUILT \
 STRICT_ORDER_CSE_REASSOCIATION=0 \
 CSE_RETAINED_SET=PARENT_CHILD_ANTICHAIN \
 CSE_READY_FUTURE_IDENTITY=SEPARATE \
 AOT_ANONYMOUS_TEMP_PRESSURE_PROOF=BUILT \
 STATE_CSE_CONSTANT_TEMP_CARRIER_AUTHORITY=SHARED \
 CONSTANT_COUNT_ADMISSION_THRESHOLD=0 \
 TEMP_PRESSURE_GENERIC_STACK_BACKEND_CLIFF=0 \
 RUNTIME_CSE_MANAGER=0 \
 RUNTIME_VALUEFACT_CACHE=0 \
 RUNTIME_DAG_WALKER=0 \
 RUNTIME_REGISTER_ALLOCATOR=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 RESOURCE_RECIPIENT_SELECTION=0 \
 WORKLOAD_NAME_SPECIALIZATION=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_16_BUILD=PASS
 do grep -q "^$marker$" .release_build_1316.log; done

echo 'BUILD_1_3_16_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_release_native_1315.sh >/dev/null
echo 'COMPLETE_1_3_15_RELEASE_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_whole_episode_physical_1316.sh

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -R -Eqi '\b(chem6|mass_action|rigid7|cseprobe|mass3_chain|reaction_rate_cache)\b' compiler runtime; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_16.md \
 RELEASE_NOTES_1_3_16.md \
 RELEASE_GATES_1_3_16.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_16.md \
 PERFORMANCE_1_3_16_WHOLE_EPISODE_PHYSICAL_DAG.md \
 PERFORMANCE_1_3_16_SIMULATION.csv \
 PERFORMANCE_1_3_16_PHYSICAL_DAG.csv \
 test_whole_episode_physical_1316.sh \
 test_release_native_1316.sh
 do test -s "$f"; done

echo 'NO_WORKLOAD_NAME_SPECIALIZATION=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'RUNTIME_CSE_MANAGER=0'
echo 'RUNTIME_VALUEFACT_CACHE=0'
echo 'RUNTIME_DAG_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'BLIND_SURPLUS_REFLOW_PRESERVED=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_16_RELEASE=PASS'
