#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.34" ]
! find . -type f -name '*.py' -print | grep -q .
! grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1
! grep -n 'devtrash/' build.sh >/dev/null 2>&1
./build.sh > /tmp/wheelchair_1334_release_build.log
grep -q '^SEMANTIC_FACT_AUTHORITY_1_3_34=BUILT$' /tmp/wheelchair_1334_release_build.log
grep -q '^SEMANTIC_MATH_REGISTRY_1_3_34=BUILT$' /tmp/wheelchair_1334_release_build.log
grep -q '^TEST_VECTOR_SEMANTIC_PREREQUISITE=0$' /tmp/wheelchair_1334_release_build.log
grep -q '^MATH_RUNTIME=0$' /tmp/wheelchair_1334_release_build.log
grep -q '^MATRIX_RUNTIME=0$' /tmp/wheelchair_1334_release_build.log
grep -q '^LIBM_DEPENDENCY=0$' /tmp/wheelchair_1334_release_build.log
grep -q '^BLAS_DEPENDENCY=0$' /tmp/wheelchair_1334_release_build.log
grep -q '^WHEELCHAIR_1_3_34_BUILD=PASS$' /tmp/wheelchair_1334_release_build.log
bash devtrash/release_tests/test_precision_policy_1334.sh
bash devtrash/release_tests/test_native_mathematics_1334.sh
bash devtrash/release_tests/test_rankn_mathematics_1334.sh
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
./build/whexc surface/examples/lcg64_iterate_wrap.wh -o "$TMP/lcg" >/dev/null
[ "$("$TMP/lcg" 42 10)" = 'out00_bits=0x06593f7b1358c594' ]
cat >"$TMP/no_test.wh" <<'SRC'
program no_test_metadata
let x: f64 = sin(1.0)
output x = x
SRC
./build/wheelchairc "$TMP/no_test.wh" -o "$TMP/no_test" >/dev/null
[ "$("$TMP/no_test")" = 'out00_bits=0x3feaed548f090cee' ]
echo WHEELCHAIR_1_3_34_FINAL_RELEASE=PASS
