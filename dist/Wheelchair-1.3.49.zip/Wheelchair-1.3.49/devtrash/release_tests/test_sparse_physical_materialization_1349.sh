#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair1349_sparse_materialization_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh > "$T/build.log"
for marker in \
 SPARSE_PHYSICAL_MATERIALIZATION_1_3_49=BUILT \
 FIELD_256_512_MATERIALIZATION_POLICY=ONE_COMMON_AUTHORITY \
 FIELD_CONSUMER_LOCAL_FOLD_256_512=CAPABILITY_DRIVEN \
 TENSOR_BASE_WIDE_PROFILE_SPLIT=0 \
 NATIVE256_BASE_WIDE_PROFILE_SPLIT=0 \
 TENSOR_PERSISTENT_TRANSIENT_LIFETIME_SPLIT=AOT_DAG_DERIVED \
 TENSOR_FIXED_LOAD_COUNT_PROFILE_THRESHOLDS=0 \
 TENSOR_FIXED_RESIDENCY_USE_THRESHOLD=0 \
 TENSOR_FIXED_PERSISTENT_RESERVE=0 \
 TENSOR_RUNTIME_MATERIALIZATION_MANAGER=0 \
 TENSOR_GLOBAL_READY_QUEUE=0 \
 TENSOR_WORK_STEALING=0 \
 WHEELCHAIR_1_3_49_BUILD=PASS
 do grep -Fqx "$marker" "$T/build.log"; done

echo SPARSE_PHYSICAL_MATERIALIZATION_BUILD=PASS

# One physical strategy, ISA-specific capability/encoding only.
F=compiler/field_frontend_common_x86_64.S
grep -q '^ff_consumer_local_foldable_1348:' "$F"
grep -q '^ff_try_consumer_local_fold_1348:' "$F"
grep -q '^ff_emit_vbin_stack_1348:' "$F"
grep -q '^ff_emit_direct_regular_store_from:' "$F"
# The policy must not be disabled merely because the width is 512.
! sed -n '/^ff_consumer_local_foldable_1348:/,/^ff_try_consumer_local_fold_1348:/p' "$F" | grep -q 'FIELD_LANES == 16'

echo FIELD_ONE_MATERIALIZATION_POLICY=PASS

# Tensor base/wide profile zoo is gone. Compatibility names are byte aliases.
cmp -s build/topologyc build/topologyc-wide
cmp -s build/topologyc-native256 build/topologyc-wide-native256
! grep -q 'profile_pressure:' compiler/native_driver_x86_64.S
! grep -q 'T137_PROFILE_BASE' compiler/tensor_frontend_138_x86_64.S
! grep -q 'T137_CACHE_COUNT-2' compiler/tensor_frontend_138_x86_64.S
! grep -q 'T138_NATIVE256_PROFILE_BASE' compiler/tensor_frontend_native256_138.S
! grep -q 'minimum winning use count' compiler/tensor_frontend_138_x86_64.S
! grep -q 'Selection stops below four' compiler/tensor_frontend_138_x86_64.S
grep -q '^tensor149_select_persistent_facts:' compiler/tensor_frontend_138_x86_64.S
grep -q '^tensor149_mark_transient_borrow:' compiler/tensor_frontend_138_x86_64.S
grep -q '^vec_persistent_reg_alloc:' compiler/tensor_frontend_138_x86_64.S
grep -q '^vec_cache_reg_alloc:' compiler/tensor_frontend_138_x86_64.S
grep -q 'vec_persistent_reg_mask:' compiler/tensor_frontend_138_x86_64.S
grep -q 'tensor149_transient_peak:' compiler/tensor_frontend_138_x86_64.S

echo TENSOR_PROFILE_ZOO_AGED_OUT=PASS
echo TENSOR_DAG_DERIVED_LIFETIME_DOMAINS=PASS

# Strict Field: identical arithmetic contract and byte-identical outputs through
# both physical widths. Both widths may consume stack-backed ValueFacts directly.
FD=devtrash/tests/field_1216
for C in fieldc fieldc-native256; do
  build/$C "$FD/fem_hex8_full.json" -o "$T/$C-hex8" >/dev/null
  for u in 0 1 2; do cp "$FD/fem_out${u}_3x5x7.whfld" "$T/$C-o${u}.whfld"; done
  "$T/$C-hex8" \
    "$FD/fem_lambda_3x5x7.whfld" "$FD/fem_mu_3x5x7.whfld" \
    "$FD/fem_p0_3x5x7.whfld" "$FD/fem_p1_3x5x7.whfld" "$FD/fem_p2_3x5x7.whfld" \
    "$T/$C-o0.whfld" "$T/$C-o1.whfld" "$T/$C-o2.whfld" >/dev/null
  for u in 0 1 2; do cmp "$T/$C-o${u}.whfld" "$FD/fem_expected_out${u}_3x5x7.whfld"; done
  tools/disassemble_generated.sh "$T/$C-hex8" > "$T/$C.dis"
  [ "$(grep -c '\bvmulps\b' "$T/$C.dis")" -eq 2304 ]
  grep -q 'vmulps.*\[rsp' "$T/$C.dis"
  ! grep -Eq '\bvfmadd|\bvfnmadd' "$T/$C.dis"
done
for u in 0 1 2; do cmp "$T/fieldc-o${u}.whfld" "$T/fieldc-native256-o${u}.whfld"; done

echo FIELD_STRICT_256_512_BYTES=PASS
echo FIELD_STRICT_ARITHMETIC_REASSOCIATION=0

# Tensor tolerant semantics remain within the existing ULP contract. The unified
# 512 compiler must preserve at least the old wide machine-work envelope.
J=devtrash/benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
for C in topologyc topologyc-wide topologyc-native256 topologyc-wide-native256; do
  build/$C "$J" -o "$T/$C" >/dev/null
  [ "$("$T/$C" 4)" = 'checksum_bits=0x3fb2acf007b0d71c' ]
done
ulp_hex() { v=${1#checksum_bits=0x}; printf '%d' "0x$v"; }
for n in 31 100000; do
  a=$("$T/topologyc" "$n"); b=$("$T/topologyc-wide" "$n"); c=$("$T/topologyc-native256" "$n")
  ad=$(ulp_hex "$a"); bd=$(ulp_hex "$b"); cd=$(ulp_hex "$c")
  max=$ad; min=$ad; [ "$bd" -gt "$max" ] && max=$bd; [ "$cd" -gt "$max" ] && max=$cd
  [ "$bd" -lt "$min" ] && min=$bd; [ "$cd" -lt "$min" ] && min=$cd
  [ $((max-min)) -le 32 ]
done
line=$(readelf -lW "$T/topologyc" | grep 'LOAD.*R E' | tail -n 1)
set -- $line; off=$2; sz=$5
dd if="$T/topologyc" of="$T/hot.bin" bs=1 skip=$((off)) count=$((sz)) status=none
objdump -D -b binary -m i386:x86-64 -M intel --insn-width=32 "$T/hot.bin" > "$T/hot.S" 2>/dev/null
vpmullq=$(grep -Ec '\bvpmullq\b' "$T/hot.S" || true)
vmov=$(grep -Ec '\bvmovdqa64\b' "$T/hot.S" || true)
bcast=$(grep -Ec '\bvpbroadcastq\b' "$T/hot.S" || true)
[ "$vpmullq" -le 20 ]
[ "$vmov" -le 50 ]
[ "$bcast" -le 55 ]
echo "TENSOR_PROBE_VPMULLQ_SITES=$vpmullq"
echo "TENSOR_PROBE_VMOVDQA64_SITES=$vmov"
echo "TENSOR_PROBE_VPBROADCASTQ_SITES=$bcast"
echo TENSOR_TOLERANT_WIDTH_AUTHORITY=PASS
echo TENSOR_MACHINE_WORK_COMPRESSION=PASS

# No benchmark/workload selector or hidden serial coordinator enters the new authority.
if grep -RniE 'taichi|hex8|64\^3|64x64|benchmark[_ -]*mode' \
  compiler/field_frontend_common_x86_64.S compiler/tensor_frontend_138_x86_64.S \
  compiler/native_driver_x86_64.S compiler/physical_cost_ticks.inc >/dev/null 2>&1; then
  echo SPARSE_MATERIALIZATION_WORKLOAD_SPECIALIZATION=FAIL >&2; exit 1
fi
! grep -RniE 'work[ _-]*steal|global[ _-]*ready[ _-]*queue|central[ _-]*scheduler' \
  compiler/field_frontend_common_x86_64.S compiler/tensor_frontend_138_x86_64.S \
  compiler/native_driver_x86_64.S >/dev/null 2>&1

echo SPARSE_MATERIALIZATION_WORKLOAD_SPECIALIZATION=0
echo SPARSE_MATERIALIZATION_RUNTIME_SCHEDULER=0
echo WHEELCHAIR_SPARSE_PHYSICAL_MATERIALIZATION_1_3_49=PASS
