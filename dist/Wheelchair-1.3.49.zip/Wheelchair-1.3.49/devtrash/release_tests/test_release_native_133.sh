#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"

case "$(cat VERSION)" in 1.3.3|1.3.7|1.3.8|1.3.10|1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_133.log 2>&1
for marker in \
 WHEELCHAIR_1_3_1_BUILD=PASS \
 WHEELCHAIR_1_3_2_BUILD=PASS \
 WHEELCHAIR_1_3_3_BUILD=PASS \
 PHYSICAL_TENSOR_REALIZATION=BUILT \
 PHYSICAL_MEMORY_DAG=BUILT \
 PHYSICAL_OPTIMIZATION_GRAPH=BUILT \
 TOLERANT_SHARED_FACTOR_FUSION=BUILT \
 STRICT_FP_REASSOCIATION=0 \
 FMA_SUBGRAPH_COVER=BUILT \
 FUSION_WIDTH_COLLAPSE=0 \
 TARGET_CACHE_CAPACITY_QUERY=CPUID_LEAF4 \
 CAUSAL_MEMORY_PROFITABILITY=BUILT \
 RANDOM_READ_PRESSURE_MODEL=BUILT \
 SMALL_OUTPUT_NT_HEURISTIC=REMOVED \
 RUNTIME_AUTOTUNE_LOOP=0 \
 BENCHMARK_DISPATCH=0 \
 CENTRAL_OPTIMIZER_RUNTIME=0 \
 MAX_SEMANTIC_CAUSAL_NODES=256 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
do grep -q "$marker" .release_build_133.log; done
echo 'BUILD_1_3_3_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_execution_granularity_1212.sh
echo 'HISTORICAL_TENSOR_CAUSAL_GATES=PASS'
devtrash/release_tests/test_neighborhood_semantics_1215.sh
echo 'HISTORICAL_NEIGHBORHOOD_GATES=PASS'
devtrash/release_tests/test_field_native_1216.sh
echo 'HISTORICAL_FIELD_NATIVE_GATES=PASS'
devtrash/release_tests/test_field_locality_1217.sh
echo 'HISTORICAL_FIELD_LOCALITY_GATES=PASS'
devtrash/release_tests/test_field_surface_1218.sh
echo 'HISTORICAL_FIELD_SURFACE_GATES=PASS'
devtrash/release_tests/test_physical_realization_131.sh
echo 'PHYSICAL_REALIZATION_1_3_1_PRESERVED=PASS'
devtrash/release_tests/test_physical_memory_132.sh
echo 'PHYSICAL_MEMORY_1_3_2_PRESERVED=PASS'
devtrash/release_tests/test_causal_physical_optimization_133.sh

T=${TMPDIR:-/tmp}/wheelchair133_release_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
build/wheelchairc devtrash/tests/general_parallel_126/iterate_probe.wh -o "$T/iterate256" >/dev/null
[ "$("$T/iterate256" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ]
echo 'GENERAL_ITERATE_Q256=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -RniE 'work[ _-]*steal|global[ _-]*(ready|memory)[ _-]*queue|central[ _-]*memory[ _-]*scheduler' \
  runtime compiler \
  | grep -v -E 'There is no|no .*work|CENTRAL_MEMORY_SCHEDULER|comment|Red line|PR13[78]_(GLOBAL_READY_QUEUE|WORK_STEALING),0' >/dev/null 2>&1; then
  echo 'FORBIDDEN_CENTRAL_COORDINATOR=FAIL' >&2; exit 1
fi
if grep -RniE 'Taichi|SPGrid|compute_Ap|benchmark[_ -]*mode' compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
(cd devtrash/frozen_native && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
echo 'FROZEN_NATIVE_AUTHORITY=PASS'

for f in WHEELCHAIR_CHARTER_1_3_3.md RELEASE_NOTES_1_3_3.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_3.md RELEASE_GATES_1_3_3.txt; do test -s "$f"; done
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_CENTRAL_OPTIMIZER_RUNTIME=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'WHEELCHAIR_1_3_3_RELEASE=PASS'
