#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1347_avx2_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh > "$T/build.log"
for marker in \
 NATIVE256_PHYSICAL_OWNERSHIP_1_3_47=BUILT \
 NATIVE256_SIMD_BANK=YMM0_TO_YMM15 \
 NATIVE256_SYNTHETIC_HIGH_SIMD_BANK=0 \
 NATIVE256_REGISTER_ROLE_AUTHORITY=ONE_COMPILE_TIME_PHYSICAL_PROFILE \
 NATIVE256_WORKLOAD_REGISTER_ROUTE=0 \
 NATIVE256_RUNTIME_REGISTER_MANAGER=0 \
 NATIVE256_RUNTIME_SCHEDULER=0 \
 NATIVE512_PHYSICALIZATION_CHANGE=0 \
 WHEELCHAIR_1_3_47_BUILD=PASS
 do grep -Fqx "$marker" "$T/build.log"; done

echo 'NATIVE256_1347_BUILD_AUTHORITY=PASS'

PROFILE=compiler/native256_physical_profile.inc
grep -Fqx '.equ N256_SIMD_REG_COUNT,16' "$PROFILE"
grep -Fqx '.equ N256_SIMD_REG_LAST,15' "$PROFILE"
grep -Fqx '.equ N256_HAS_HIGH_SIMD_BANK,0' "$PROFILE"
grep -Fqx '.equ FF256_V3_REG,12' "$PROFILE"
grep -Fqx '.equ FF256_TAIL_MASK_REG,4' "$PROFILE"
grep -Fqx '.equ FF256_REDUCE_REG,5' "$PROFILE"
grep -Fqx '.equ FF256_I0_REG,13' "$PROFILE"
grep -Fqx '.equ FF256_I1_REG,14' "$PROFILE"
grep -Fqx '.equ FF256_PHASE_SCRATCH_REG,15' "$PROFILE"
for f in compiler/tensor_frontend_native256_138.S compiler/tensor_frontend_derived_native256_138.S; do
  ! grep -q 'vec_cache_reg_mask:' "$f"
  ! grep -q 'vec_const_reg_mask:' "$f"
  ! grep -q 'N256_CACHE_LAST' "$f"
  ! grep -q 'N256_CONST_BASE' "$f"
done
echo 'NATIVE256_SYNTHETIC_HIGH_BANK_STATE=0'

# Generic four-ValueFact tail/reduction collision probe.  In <=1.3.46 logical
# v3 shared YMM4 with the tail mask.  This fixture contains no benchmark name or
# application coefficient and therefore protects the physical ownership law.
cat > "$T/v3_tail.json" <<'JSON'
{
  "format":"wheelchair.field/1",
  "contracts":{"floating_point":"strict"},
  "fields":[
    {"mode":"input","type":"f32","rank":3},
    {"mode":"output","type":"f32","rank":3}
  ],
  "accesses":[{"field":0,"delta":[0,0,0]}],
  "ops":[
    {"op":"load","access":0,"dst":0},
    {"op":"const","value":1.0,"dst":1},
    {"op":"add","a":0,"b":1,"dst":3},
    {"op":"store","field":1,"src":3},
    {"op":"reduce","src":3}
  ]
}
JSON
build/fieldc "$T/v3_tail.json" -o "$T/v3_512" >/dev/null
build/fieldc-native256 "$T/v3_tail.json" -o "$T/v3_256" >/dev/null
cp devtrash/tests/field_1216/fem_out0_3x5x7.whfld "$T/out512.whfld"
cp devtrash/tests/field_1216/fem_out0_3x5x7.whfld "$T/out256.whfld"
IN=devtrash/tests/field_1216/a_3x5x7.whfld
[ "$("$T/v3_512" "$IN" "$T/out512.whfld")" = 'checksum_f32_bits=0x45b13000' ]
[ "$("$T/v3_256" "$IN" "$T/out256.whfld")" = 'checksum_f32_bits=0x45b13000' ]
cmp "$T/out512.whfld" "$T/out256.whfld"
tools/disassemble_generated.sh "$T/v3_256" > "$T/v3_256.dis"
grep -q 'ymm12' "$T/v3_256.dis"
! grep -q 'zmm' "$T/v3_256.dis"
echo 'NATIVE256_V3_TAIL_MASK_OWNERSHIP=PASS'

# Procedural-index helpers, hidden reduction and gather scratch must coexist in
# the same physical profile without aliases.
for C in fieldc fieldc-native256; do
  build/$C devtrash/tests/field_1216/integer_divmod.json -o "$T/$C-int" >/dev/null
  [ "$("$T/$C-int" "$IN")" = 'checksum_f32_bits=0x45c02800' ]
  build/$C devtrash/tests/field_1216/sum.json -o "$T/$C-sum" >/dev/null
  [ "$("$T/$C-sum" "$IN")" = 'checksum_f32_bits=0x45ade800' ]
done
echo 'NATIVE256_INDEX_REDUCTION_HELPER_OWNERSHIP=PASS'

# Existing high-pressure and irregular Field authorities remain the oracle.
sh devtrash/release_tests/test_field_native_1216.sh >/dev/null
sh devtrash/release_tests/test_field_locality_1217.sh >/dev/null
sh devtrash/release_tests/test_physical_regularity_134.sh >/dev/null
echo 'NATIVE256_FIELD_EXISTING_AUTHORITY=PASS'

# Tensor native256 must consume only the real AVX2 bank.  The aged zero-capacity
# high-bank authority falls through the old direct-load/RIP-pool realization.
cat > "$T/tensor.whex" <<'SRC'
program avx2_profile_tensor
input n: u64 range 4..4
field x[i in n]: f64 = cast(f64, i) + 1.0
field y[i in n]: f64 = sqrt(x[i])
sum checksum[i in n]: f64 = y[i]
output checksum
test (4) => { checksum = 6.146264369941973 }
SRC
build/topologyc-native256 "$T/tensor.whex" -o "$T/tensor256" >/dev/null
[ "$("$T/tensor256" 4)" = 'checksum_bits=0x401895c653b5e21e' ]
tools/disassemble_generated.sh "$T/tensor256" > "$T/tensor256.dis"
grep -q 'vsqrtpd.*ymm' "$T/tensor256.dis"
! grep -q 'zmm' "$T/tensor256.dis"
echo 'NATIVE256_TENSOR_REAL_BANK_ONLY=PASS'

# No workload/named-size route was admitted by the repair.
if grep -RniE 'taichi|hex8|elasticity|64\^3|64x64|v3_tail' \
  compiler/field_frontend_256_x86_64.S compiler/field_frontend_common_x86_64.S \
  runtime/field_runtime_256_x86_64.S compiler/native256_physical_profile.inc >/dev/null 2>&1; then
  echo 'NATIVE256_WORKLOAD_SPECIALIZATION=FAIL' >&2; exit 1
fi
echo 'NATIVE256_WORKLOAD_SPECIALIZATION=0'
echo 'NATIVE256_NEW_RUNTIME_BRANCH_FAMILY=0'
echo 'WHEELCHAIR_AVX2_PHYSICAL_OWNERSHIP_1_3_47=PASS'
