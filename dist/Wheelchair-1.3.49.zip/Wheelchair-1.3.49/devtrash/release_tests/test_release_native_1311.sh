#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1311.log 2>&1
for marker in \
 WHEELCHAIR_1_3_10_BUILD=PASS \
 FIELD_RANKN_ROW_PROOF=BUILT \
 NON_POWER2_REDUNDANT_AXIS_DIVISION=REMOVED \
 AVX512_REUSE_WEIGHTED_NEIGHBOR_RESIDENCY=BUILT \
 TRUE_IRREGULAR_GATHER_FALLBACK=PRESERVED \
 FIELD_FLOATING_LOGICAL_REGISTERS=4 \
 WHEX_COMPLEX_FIELD_SURFACE=BUILT \
 WHEX_COMPLEX_FIELD_RUNTIME_INTERPRETER=0 \
 FORCED_GENERIC_FMA=REJECTED_BY_PHYSICAL_PROFITABILITY \
 BLIND_SURPLUS_REFLOW=PRESERVED \
 LOAD_BALANCING_FAMILY=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_11_BUILD=PASS
 do grep -q "^$marker$" .release_build_1311.log; done
echo 'BUILD_1_3_11_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Preserve the complete 1.3.10 architecture and historical chain first.
devtrash/release_tests/test_release_native_1310.sh
echo 'COMPLETE_1_3_10_RELEASE_AUTHORITY_PRESERVED=PASS'

# Then require the new complex Field authority.
devtrash/release_tests/test_field_contiguous_collapse_1311.sh

echo 'FIELD_1_3_11_AUTHORITY=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -R -Eqi '\b(CVRD3D|cvrd3d)\b' \
 compiler/field_frontend_common_x86_64.S \
 compiler/field_surface_lowerer_x86_64.inc \
 runtime/field_runtime_512_x86_64.S \
 runtime/field_runtime_256_x86_64.S; then
  echo 'CVRD3D_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi

echo 'NO_CVRD3D_SPECIALIZATION=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_11.md \
 RELEASE_NOTES_1_3_11.md \
 RELEASE_GATES_1_3_11.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_11.md \
 PERFORMANCE_1_3_11_FIELD_CONTIGUOUS_COLLAPSE.md \
 test_field_contiguous_collapse_1311.sh \
 test_release_native_1311.sh
 do test -s "$f"; done

echo 'BLIND_SURPLUS_REFLOW_PRESERVED=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_11_RELEASE=PASS'
