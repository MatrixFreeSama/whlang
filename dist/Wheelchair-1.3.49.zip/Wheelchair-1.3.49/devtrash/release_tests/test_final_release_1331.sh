#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.31" ]
./build.sh >/tmp/wheelchair_1331_release_build.log
bash devtrash/release_tests/test_precision_propagation_1331.sh
bash devtrash/release_tests/test_low_precision_contagion_1330.sh
bash devtrash/release_tests/test_rankn_contraction_1331.sh
./bin/whexc surface/examples/lcg64_iterate_wrap.wh -o /tmp/wheelchair_1331_lcg >/dev/null
[ "$(/tmp/wheelchair_1331_lcg 42 10)" = 'out00_bits=0x06593f7b1358c594' ]
grep -q '^WHEELCHAIR_1_3_31_BUILD=PASS$' /tmp/wheelchair_1331_release_build.log
echo WHEELCHAIR_1_3_31_FINAL_RELEASE=PASS
