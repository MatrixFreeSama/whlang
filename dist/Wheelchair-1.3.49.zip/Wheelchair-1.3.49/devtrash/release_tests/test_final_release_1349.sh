#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

for t in \
 test_precision_policy_1334.sh \
 test_native_mathematics_1334.sh \
 test_rankn_mathematics_1334.sh \
 test_structured_mathematics_1336.sh \
 test_parametric_rankn_fp_1340.sh \
 test_rankn_precision_fourier_1340.sh \
 test_math_fusion_1341.sh \
 test_root_relation_1342.sh \
 test_root_precision_fusion_1343.sh \
 test_math_generalization_1344.sh \
 test_field_human_shell_1345.sh \
 test_field_human_shell_1346.sh \
 test_avx2_physical_ownership_1347.sh \
 test_valuefact_lifetime_1348.sh \
 test_tensor_physical_reality_137.sh \
 test_sparse_physical_materialization_1349.sh; do
  "$ROOT/devtrash/release_tests/$t" >/dev/null
done

# Keep the mature Field locality proof explicitly visible in the final release.
"$ROOT/devtrash/release_tests/test_field_locality_1217.sh" >/dev/null

grep -q '^1\.3\.49$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_49_BUILD=PASS' "$ROOT/build.sh"
grep -q 'SPARSE_PHYSICAL_MATERIALIZATION_1_3_49=BUILT' "$ROOT/build.sh"
grep -q '^# Wheelchair 1\.3\.49' "$ROOT/README.md"
for f in \
 RELEASE_NOTES_1_3_49.md SPARSE_PHYSICAL_MATERIALIZATION_1_3_49.md \
 CORRECTNESS_1_3_49_SPARSE_PHYSICAL_MATERIALIZATION.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_49.md WHEELCHAIR_CHARTER_1_3_49.md; do
  [ -s "$ROOT/$f" ]
done
[ -s "$ROOT/devtrash/release_history/1.3.48/RELEASE_NOTES_1_3_48.md" ]

# Historical compatibility compiler names must be exactly the same implementation.
cmp -s "$ROOT/bin/topologyc" "$ROOT/bin/topologyc-wide"
cmp -s "$ROOT/bin/topologyc-native256" "$ROOT/bin/topologyc-wide-native256"

# Production compilers are static native executables.
for f in \
 "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc" "$ROOT/bin/fieldc" \
 "$ROOT/bin/fieldc-native256" "$ROOT/bin/topologyc" "$ROOT/bin/topologyc-native256"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

# No Python production generator may enter the live compiler/runtime tree.
if find "$ROOT/compiler" "$ROOT/runtime" -type f \( -name '*.py' -o -name '*.pyc' \) 2>/dev/null | grep -q .; then
  echo PYTHON_PRODUCTION_GENERATOR=FAIL >&2; exit 1
fi

[ ! -d "$ROOT/build" ] || [ "${ALLOW_BUILD_DIR:-0}" = 1 ]
echo WHEELCHAIR_1_3_49_FINAL_RELEASE=PASS
