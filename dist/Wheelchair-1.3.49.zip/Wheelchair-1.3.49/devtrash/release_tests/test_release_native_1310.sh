#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.10|1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1310.log 2>&1
for marker in \
 WHEELCHAIR_1_3_7_BUILD=PASS \
 WHEELCHAIR_1_3_8_BUILD=PASS \
 LOAD_BALANCING_FAMILY=EXTINCT_FROM_TENSOR_FIELD_PRODUCTION_RUNTIME \
 STATIC_EQUAL_WORK_PARTITION=0 \
 PROPORTIONAL_EXECUTOR_SPLIT=0 \
 EXECUTOR_ID_WORK_TOPOLOGY=0 \
 CAUSAL_WORK_IS_DEMAND_AUTHORITY=1 \
 HARDWARE_WIDTH_IS_ONLY_CEILING=SUPERSEDED_BY_EXTERNAL_SILICON_AUTHORITY \
 ANONYMOUS_SURPLUS_RELEASE=SUPERSEDED_BY_TERMINAL_RELEASE \
 BLIND_CAPACITY_CLAIM=0 \
 DISTRIBUTED_CREDIT_CACHELINES=0 \
 GLOBAL_SURPLUS_COUNTER=0 \
 FAILED_CLAIM_SPIN=0 \
 PEER_LOAD_OBSERVATION=0 \
 PEER_WORK_OBSERVATION=0 \
 POST_COMPLETION_WORK_SEARCH=0 \
 RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1 \
 RESOURCE_ACQUISITION_IS_DONOR_BLIND=1 \
 INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0 \
 OCCUPANCY_AS_OPTIMIZATION_TARGET=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 RESOURCE_RECIPIENT_SELECTION=0 \
 RUNTIME_FACT_MANAGER=0 \
 RUNTIME_RESIDENCY_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 STRICT_FP_REASSOCIATION=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0 \
 WHEELCHAIR_1_3_10_BUILD=PASS
 do grep -q "^$marker$" .release_build_1310.log; done
echo 'BUILD_1_3_10_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Preserve the complete 1.3.7 historical authority. The 1.3.8 release script
# itself froze the now-extinct tolerant balanced fabric, so 1.3.10 preserves
# the 1.3.8 numerical repair through its dedicated strict gate instead of
# resurrecting that obsolete implementation authority.
devtrash/release_tests/test_release_native_137.sh
echo 'COMPLETE_1_3_7_RELEASE_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_strict_parallel_reduction_138.sh
echo 'STRICT_1_3_8_NUMERICAL_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_blind_surplus_reflow_1310.sh

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -R -Eqi '\b(fluid|solid|fsi)\b' \
 runtime/tensor_runtime_138_x86_64.S \
 runtime/tensor_runtime_138_x86_64.S \
 runtime/tensor_runtime_138_x86_64.S \
 runtime/tensor_runtime_138_x86_64.S \
 runtime/field_runtime_512_x86_64.S \
 runtime/field_runtime_256_x86_64.S; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'NO_WORKLOAD_SPECIALIZATION=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_10.md \
 RELEASE_NOTES_1_3_10.md \
 RELEASE_GATES_1_3_10.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_10.md \
 PERFORMANCE_1_3_10_BLIND_SURPLUS_REFLOW.md \
 LOAD_BALANCING_EXTINCTION_1_3_10.md \
 test_blind_surplus_reflow_1310.sh \
 test_release_native_1310.sh
 do test -s "$f"; done

echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_RUNTIME_FACT_MANAGER=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_10_RELEASE=PASS'
