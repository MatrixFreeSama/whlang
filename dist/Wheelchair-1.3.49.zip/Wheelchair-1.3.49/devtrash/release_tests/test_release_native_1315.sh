#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

rm -rf build
./build.sh > .release_build_1315.log 2>&1
for marker in \
 WHEELCHAIR_1_3_14_BUILD=PASS \
 RANKN_CAUSAL_PHYSICALIZATION_1_3_15=BUILT \
 CAUSAL_STATE_COUNT_ADMISSION_THRESHOLD=0 \
 COUNTED_INDUCTION=AXIS_AUTHORITY \
 CAUSAL_PARTIAL_RESIDENCY=BUILT \
 FP_INTEGER_MIXED_PARTIAL_RESIDENCY=BUILT \
 PRIVATE_STATE_PAGE_OWNERSHIP=PRESERVED \
 PRIVATE_STATE_PAGE_CACHE_COLORING=BUILT \
 SPILL_CAUSE=PHYSICAL_PRESSURE_ONLY \
 LARGE_N_STACK_EVALUATOR_FALLBACK=0 \
 RUNTIME_STATE_MANAGER=0 \
 RUNTIME_DAG_WALKER=0 \
 RUNTIME_REGISTER_ALLOCATOR=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 RESOURCE_RECIPIENT_SELECTION=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_15_BUILD=PASS
 do grep -q "^$marker$" .release_build_1315.log; done

echo 'BUILD_1_3_15_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_release_native_1314.sh >/dev/null
echo 'COMPLETE_1_3_14_RELEASE_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_rankn_causal_1315.sh

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -R -Eqi '\b(fibonacci|fib_iter|lucas|tribonacci|thermal4|two_mass|ring32|int8_ring|mixed8)\b' compiler runtime; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_15.md \
 RELEASE_NOTES_1_3_15.md \
 RELEASE_GATES_1_3_15.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_15.md \
 PERFORMANCE_1_3_15_STATE_CONTINUITY.csv \
 PERFORMANCE_1_3_15_SIMULATION.csv \
 test_rankn_causal_1315.sh \
 test_release_native_1315.sh
 do test -s "$f"; done

echo 'NO_WORKLOAD_NAME_SPECIALIZATION=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'RUNTIME_STATE_MANAGER=0'
echo 'RUNTIME_DAG_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'BLIND_SURPLUS_REFLOW_PRESERVED=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_15_RELEASE=PASS'
