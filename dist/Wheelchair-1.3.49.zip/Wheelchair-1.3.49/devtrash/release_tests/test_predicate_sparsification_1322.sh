#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
TMP=${TMPDIR:-/tmp}/wheelchair_predicate_1322_$$
trap 'rm -rf "$TMP"' EXIT INT TERM
mkdir -p "$TMP"

G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc

grep -q 'PR138_PREDICATE_VALUEFACT_PERSISTENCE,1' "$P"
grep -q 'PR138_PREDICATE_REEVALUATE_WITHOUT_VERSION_CHANGE,0' "$P"
grep -q 'PR138_PREDICATE_REPEAT_THRESHOLD,0' "$P"
grep -q 'PR138_RUNTIME_PREDICATE_MANAGER,0' "$P"
grep -q '^g_phys_predicate_equal:' "$G"
grep -q '^g_find_materialized_predicate_fact:' "$G"
grep -q '^g_note_fragment_dependency:' "$G"

# Deleted private routes must stay physically absent from source.
! grep -R -q 'g_try_emit_affine_iterate\|g_match_affine_update\|gc_affine_' compiler --include='*.S' --include='*.inc'
! grep -R -q 'vec_select_interior_false\|expr_is_axis_delta1' compiler --include='*.S' --include='*.inc'

cat > "$TMP/pred.wh" <<'EOF'
program pred_repeat
input x: f64
input y: f64
let p1: bool = x < y
let a: f64 = select(x < y, x + 1.0, y + 1.0)
let b: f64 = select(x < y, x + 2.0, y + 2.0)
let p2: bool = x < y
output p1=p1
output a=a
output b=b
output p2=p2
test () => { p1=false,a=1.0,b=2.0,p2=false }
EOF

./build/wheelchairc "$TMP/pred.wh" -o "$TMP/pred" >/dev/null
A=$($TMP/pred 1.0 2.0)
B=$($TMP/pred 2.0 1.0)
printf '%s\n' "$A" | grep -Fqx 'out00_bits=0x0000000000000001'
printf '%s\n' "$A" | grep -Fqx 'out01_bits=0x4000000000000000'
printf '%s\n' "$A" | grep -Fqx 'out02_bits=0x4008000000000000'
printf '%s\n' "$A" | grep -Fqx 'out03_bits=0x0000000000000001'
printf '%s\n' "$B" | grep -Fqx 'out00_bits=0x0000000000000000'
printf '%s\n' "$B" | grep -Fqx 'out01_bits=0x4000000000000000'
printf '%s\n' "$B" | grep -Fqx 'out02_bits=0x4008000000000000'
printf '%s\n' "$B" | grep -Fqx 'out03_bits=0x0000000000000000'

objdump -d -Mintel "$TMP/pred" > "$TMP/pred.dis"
C=$(grep -c 'ucomisd' "$TMP/pred.dis" || true)
S=$(grep -c -E '\bsetb\b' "$TMP/pred.dis" || true)
[ "$C" -eq 1 ]
[ "$S" -eq 1 ]

echo 'PREDICATE_REPEAT_4_TO_1=PASS'
echo 'PREDICATE_SEMANTICS_BOTH_DIRECTIONS=PASS'
echo 'PREDICATE_REUSE_CAUSAL_DEPENDENCY=PASS'
echo 'PREDICATE_REPEAT_MAGIC_THRESHOLD=0'
echo 'RUNTIME_PREDICATE_MANAGER=0'
echo 'FIXED_BOUNDARY_SELECT_MATCHER=0'
echo 'FIXED_STATE_AFFINE_ITERATE_ROUTE=0'
echo 'WHEELCHAIR_PREDICATE_SPARSIFICATION_1_3_22=PASS'
