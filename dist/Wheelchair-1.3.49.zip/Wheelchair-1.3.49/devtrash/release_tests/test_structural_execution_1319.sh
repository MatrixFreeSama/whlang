#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.19 ]
T=${TMPDIR:-/tmp}/wheelchair1319_struct_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

if [ "${WC1319_REUSE_BUILD:-0}" = 1 ] && [ -s .release_build_1319.log ]; then
  cp .release_build_1319.log "$T/build.log"
else
  ./build.sh > "$T/build.log" 2>&1
fi
for m in \
 STRUCTURAL_EXECUTION_THEORY_1_3_19=BUILT \
 PROGRAM_ORDER_IS_CAUSAL_AUTHORITY=0 \
 EQUAL_CAUSAL_DEPTH_PARALLELISM=AOT_CAUSAL_PARTIAL_ORDER \
 'STRUCTURAL_EXECUTION_MODEL=W/(max(W/P,S)+H)' \
 'STRUCTURAL_EXECUTION_IDEAL=min(P,W/S)' \
 INTRINSIC_CAUSAL_PARALLELISM=W/S \
 W_S_H_OPTIMIZATION_CLASSIFICATION=BUILT \
 AOT_STRUCTURAL_FACT_DIAGNOSTIC=BUILT \
 RUNTIME_CAUSAL_DEPTH_QUEUE=0 \
 RUNTIME_SERIAL_FRACTION_MANAGER=0 \
 RUNTIME_STRUCTURAL_SCHEDULER=0 \
 HARD_CODED_CAUSAL_DEPTH_THRESHOLD=0 \
 RUNTIME_RESOURCE_AVAILABILITY_EXPANSION_QUERY=0 \
 STRUCTURAL_EXECUTION_HOT_RUNTIME_DELTA=0 \
 WHEELCHAIR_1_3_19_BUILD=PASS
 do grep -Fqx "$m" "$T/build.log"; done
echo 'STRUCTURAL_EXECUTION_BUILD_AUTHORITY=PASS'

# Theory may not mutate the production hot physicalizer/runtime sources.
sha256sum -c TECHNICAL_PEAK_1_3_18_PRODUCTION_SHA256 >/dev/null
echo 'STRUCTURAL_EXECUTION_HOT_RUNTIME_DELTA=0'

# No runtime implementation of causal-depth/serial-fraction management is allowed.
if grep -R -n -E 'causal[_ -]?depth[_ -]?(queue|scheduler|manager)|serial[_ -]?fraction[_ -]?(queue|scheduler|manager)' \
  runtime compiler --include='*.S' >/dev/null 2>&1; then
  echo 'RUNTIME_STRUCTURAL_MANAGER_LEAK=FAIL' >&2; exit 1
fi
echo 'RUNTIME_CAUSAL_DEPTH_QUEUE=0'
echo 'RUNTIME_SERIAL_FRACTION_MANAGER=0'

json_field() {
  printf '%s\n' "$1" | sed -n 's/.*"'"$2"'":\([0-9][0-9]*\).*/\1/p'
}
# Falsifiable algebraic invariants.
a=$(tools/structural_execution_model.sh raw 1000000 1000000 0 5)
[ "$(json_field "$a" model_speedup_milli)" = 1000 ]
b=$(tools/structural_execution_model.sh raw 1000000 1 0 5)
[ "$(json_field "$b" model_speedup_milli)" = 5000 ]
[ "$(json_field "$b" ideal_speedup_milli)" = 5000 ]
c=$(tools/structural_execution_model.sh raw 1000000 500000 0 5)
d=$(tools/structural_execution_model.sh raw 1000000 500000 100000 5)
[ "$(json_field "$c" model_speedup_milli)" -ge "$(json_field "$d" model_speedup_milli)" ]
echo 'STRUCTURAL_MODEL_MONOTONICITY=PASS'
echo 'FULL_CAUSAL_CHAIN_SPEEDUP_ONE=PASS'
echo 'ZERO_OVERHEAD_INDEPENDENCE_APPROACHES_P=PASS'

# Existing AOT Physical Reality facts feed the structural model. --executors is
# deliberately irrelevant to the structural graph and must not change the image.
SRC=devtrash/tests/whex/emergent_light_reduction_1318.whex
build/topologyc "$SRC" -o "$T/light1" >/dev/null
build/topologyc "$SRC" -o "$T/light256" >/dev/null
cmp "$T/light1" "$T/light256"
r1=$(tools/structural_execution_model.sh tensor "$T/light1" 1000000 5)
r2=$(tools/structural_execution_model.sh tensor "$T/light1" 100000000 5)
p1=$(json_field "$r1" intrinsic_parallelism_milli)
p2=$(json_field "$r2" intrinsic_parallelism_milli)
[ -n "$p1" ] && [ -n "$p2" ] && [ "$p2" -gt "$p1" ]
[ "$(json_field "$r2" W)" -gt "$(json_field "$r1" W)" ]
echo "$r1" > "$T/model_1m.json"
echo "$r2" > "$T/model_100m.json"
echo 'AOT_STRUCTURAL_FACT_DIAGNOSTIC=PASS'
echo 'INTRINSIC_CAUSAL_PARALLELISM_W_OVER_S=PASS'
echo 'RESOURCE_OPTION_STRUCTURAL_INDEPENDENCE=PASS'

# Structural theory inherits rather than replaces the 1.3.18 outward realization.
if [ "${WC1319_REUSE_BUILD:-0}" = 1 ]; then
  echo 'EMERGENT_OUTWARD_EXPANSION_1_3_18_PRESERVED=PASS'
else
  devtrash/release_tests/test_emergent_outward_expansion_1318.sh >/dev/null
  echo 'EMERGENT_OUTWARD_EXPANSION_1_3_18_PRESERVED=PASS'
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_19.md RELEASE_NOTES_1_3_19.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_19.md RELEASE_GATES_1_3_19.txt \
 PERFORMANCE_1_3_19_STRUCTURAL_EXECUTION.md PERFORMANCE_1_3_19_STRUCTURAL_SCALING.csv \
 PERFORMANCE_1_3_19_FSI_STRONG_RAW.csv PERFORMANCE_1_3_19_FSI_WEAK_RAW.csv \
 PERFORMANCE_1_3_19_REMATCH_SUMMARY.csv tools/structural_execution_model.sh \
 TECHNICAL_PEAK_1_3_18_PRODUCTION_SHA256
 do test -s "$f"; done

echo 'PROGRAM_ORDER_IS_NOT_CAUSAL_AUTHORITY=PASS'
echo 'EQUAL_CAUSAL_DEPTH_PARALLELISM=PASS'
echo 'STRUCTURAL_EXECUTION_W_S_H_MODEL=PASS'
echo 'W_S_H_OPTIMIZATION_CLASSIFICATION=PASS'
echo 'WHEELCHAIR_STRUCTURAL_EXECUTION_1_3_19=PASS'
