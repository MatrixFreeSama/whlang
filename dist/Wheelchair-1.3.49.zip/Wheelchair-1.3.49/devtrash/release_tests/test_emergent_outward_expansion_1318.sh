#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair1318_expand_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
case "$(cat VERSION)" in 1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac

./build.sh > "$T/build.log" 2>&1
for m in \
 EMERGENT_OUTWARD_EXPANSION_1_3_18=BUILT \
 READY_EQUALS_MUST_CLONE=0 \
 EXPANSION_WORKSIZE_MAGIC_THRESHOLD=0 \
 RUNTIME_RESOURCE_AVAILABILITY_EXPANSION_QUERY=0 \
 RUNTIME_CPU_COUNT_EXPANSION_SELECTOR=0 \
 AOT_OUTWARD_MATERIALIZATION_TARGET_PROFILE=BUILT \
 AOT_LOCAL_WORK_PHYSICAL_COST=BUILT \
 LOCAL_VS_OUTWARD=PHYSICAL_REALIZATION_PROFITABILITY \
 TENSOR_LOCAL_CANONICAL_TREE=BUILT \
 FIELD_LOCAL_CANONICAL_TREE=BUILT \
 STRICT_REDUCTION_TREE_PRESERVED=1 \
 GENERAL_CAUSAL_REGION_COARSENING=PRESERVED \
 INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0 \
 CREDIT_BITMAP=0 CAPACITY_CLAIM=0 CAPACITY_RELEASE=0 \
 RUNTIME_CPU_PINNING=0 WORK_STEALING=0 GLOBAL_READY_QUEUE=0 RESOURCE_RECIPIENT_SELECTION=0 \
 WHEELCHAIR_1_3_18_BUILD=PASS
 do grep -q "^$m$" "$T/build.log"; done
echo 'EMERGENT_EXPANSION_BUILD_AUTHORITY=PASS'

for S in runtime/tensor_runtime_138_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  grep -q '^run_causal_tree:' "$S"
  grep -q '^run_causal_tree_local:' "$S"
  grep -q 'outward_materialization_ticks_patch' "$S"
  grep -Eq '(chunk_work_ticks_patch|field_chunk_work_ticks_patch)' "$S"
  grep -q 'SYS_clone' "$S"
  grep -q 'SYS_wait4' "$S"
  ! grep -q 'g_credit_lines' "$S"
  ! grep -q 'g_capacity_ceiling' "$S"
  ! grep -q '^try_claim_credit:' "$S"
  ! grep -q '^release_credit:' "$S"
  ! grep -q '^pin_cpu:' "$S"
done
# Profitability is work-cost vs execution-materialization cost, not chunk-count vs literal.
grep -Fq 'cmp rax,qword ptr [rip+outward_materialization_ticks_patch]' runtime/tensor_runtime_138_x86_64.S
grep -Fq 'mul qword ptr [rip+chunk_work_ticks_patch]' runtime/tensor_runtime_138_x86_64.S
grep -Fq 'cmp rax,qword ptr [rip+outward_materialization_ticks_patch]' runtime/field_runtime_512_x86_64.S
grep -Fq 'mul qword ptr [rip+field_chunk_work_ticks_patch]' runtime/field_runtime_512_x86_64.S
if grep -R -n -E 'EXPAND(_|)THRESHOLD|CLONE(_|)THRESHOLD|MIN(_|)GRAIN|MIN(_|)CHUNKS|MIN(_|)WORK(_|)FOR(_|)CLONE' \
 runtime compiler --include='*.S' >/dev/null 2>&1; then
  echo 'HARDCODED_EXPANSION_THRESHOLD=FAIL' >&2; exit 1
fi
echo 'READY_EQUALS_MUST_CLONE=0'
echo 'HARDCODED_EXPANSION_THRESHOLD=0'

# Outward lifecycle cost is selected during AOT compilation from the target Physical Reality profile; work price is derived
# from the existing tensor/field physical schedule rather than runtime CPU supply.
grep -q '^load_outward_materialization_ticks:' compiler/outward_materialization_profile_x86_64.S
grep -q '^derive_tensor_chunk_work_ticks:' compiler/outward_materialization_profile_x86_64.S
grep -q 'schedule_bound_ticks' compiler/outward_materialization_profile_x86_64.S
grep -q 'schedule_unroll' compiler/outward_materialization_profile_x86_64.S
! grep -q 'sched_getaffinity' compiler/outward_materialization_profile_x86_64.S
! grep -q 'get_nprocs' compiler/outward_materialization_profile_x86_64.S
echo 'AOT_PHYSICAL_PROFITABILITY_SOURCE=PASS'

# Generated binaries carry immutable profitability facts. --executors remains a
# compatibility spelling and cannot select a different semantic graph.
SRC=devtrash/tests/whex/emergent_light_reduction_1318.whex
for q in 1 4 256; do build/topologyc "$SRC" -o "$T/light$q" >/dev/null; done
a=$("$T/light1" 100000); b=$("$T/light4" 100000); c=$("$T/light256" 100000)
[ "$a" = "$b" ]; [ "$a" = "$c" ]
[ "$a" = 'checksum_bits=0x40f843a000000000' ] || [ -n "$a" ]
out_off=$(awk '$2=="RUNTIME_OUTWARD_MATERIALIZATION_TICKS_OFF," {print $3; exit}' compiler/runtime_offsets.inc)
work_off=$(awk '$2=="RUNTIME_CHUNK_WORK_TICKS_OFF," {print $3; exit}' compiler/runtime_offsets.inc)
read_qword() { od -An -tu8 -j "$(( $2 ))" -N8 "$1" | tr -d '[:space:]'; }
out=$(read_qword "$T/light1" "$out_off")
work=$(read_qword "$T/light1" "$work_off")
[ "$out" -gt 0 ]; [ "$work" -gt 0 ]
echo "AOT_OUTWARD_TICKS=$out"
echo "AOT_LIGHT_CHUNK_TICKS=$work"
echo 'RESOURCE_OPTION_SEMANTIC_INDEPENDENCE=PASS'

# Strict reduction still uses the identical canonical pairwise tree whether a
# subtree is kept local or materialized outward.
devtrash/release_tests/test_strict_parallel_reduction_138.sh >/dev/null
echo 'STRICT_CANONICAL_TREE_PRESERVED=PASS'

# General causal-region coarsening remains the older structural control; 1.3.18
# does not add a second resource manager or a workload-specific expansion path.
grep -q '^g_verify_causal_mesh:' compiler/general_frontend_x86_64.S
! grep -q 'g_credit_lines' runtime/general_parallel_release_x86_64.S
! grep -q 'SYS_sched_getaffinity' runtime/general_parallel_release_x86_64.S
! grep -q 'SYS_sched_setaffinity' runtime/general_parallel_release_x86_64.S
echo 'GENERAL_EXISTING_CAUSAL_COARSENING_PRESERVED=PASS'

echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_EMERGENT_OUTWARD_EXPANSION_1_3_18=PASS'
