#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.28 ]

if find compiler runtime surface tools -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_PRODUCTION_SOURCE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
echo 'PURE_ASSEMBLY_PRODUCTION_AUTHORITY=PASS'

sh devtrash/release_tests/test_release_surface_1328.sh >/dev/null
echo 'RELEASE_SURFACE_FIREWALL=PASS'
sh devtrash/release_tests/test_native_mathematics_1328.sh >/dev/null
echo 'NATIVE_MATHEMATICS_1328=PASS'

# Inherited architectural gates whose version guards admit 1.3.28.
for t in \
 test_physical_realization_131.sh \
 test_physical_memory_132.sh \
 test_causal_physical_optimization_133.sh \
 test_physical_regularity_134.sh \
 test_physical_realization_uniqueness_135.sh \
 test_global_physical_reality_136.sh \
 test_tensor_physical_reality_137.sh \
 test_strict_parallel_reduction_138.sh \
 test_blind_surplus_reflow_1310.sh \
 test_field_contiguous_collapse_1311.sh \
 test_causal_state_collapse_1312.sh \
 test_register_native_transition_1313.sh \
 test_unified_physical_reality_1314.sh \
 test_rankn_causal_1315.sh \
 test_whole_episode_physical_1316.sh \
 test_external_silicon_authority_1317.sh \
 test_emergent_outward_expansion_1318.sh \
 test_unified_valuefact_pressure_1320.sh \
 test_transport_sparsification_1321.sh \
 test_predicate_sparsification_1322.sh \
 test_transition_power_1323.sh \
 test_execution_granularity_1212.sh \
 test_neighborhood_semantics_1215.sh \
 test_field_native_1216.sh \
 test_field_locality_1217.sh \
 test_field_surface_1218.sh \
 test_branch_extinction_1324.sh \
 test_field_valuefact_lifetime_1326.sh \
 test_carrier_lifetime_1327.sh
 do
   sh "devtrash/release_tests/$t" >/dev/null
   echo "$t=PASS"
 done

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

echo 'MATH_IR=0'
echo 'MATH_RUNTIME=0'
echo 'MATH_SCHEDULER=0'
echo 'MATH_EXECUTOR=0'
echo 'LIBM_DEPENDENCY=0'
echo 'SELECTED_AXIS_CONTRACTION_AUTHORITY=DEFERRED_OLD_ARCHITECTURE_DEBT'
echo 'WHEELCHAIR_1_3_28_RELEASE=PASS'
