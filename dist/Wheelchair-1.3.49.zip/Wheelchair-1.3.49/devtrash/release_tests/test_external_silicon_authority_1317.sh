#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair1317_silicon_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
case "$(cat VERSION)" in 1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac

./build.sh > "$T/build.log" 2>&1
for m in \
 EXTERNAL_SILICON_AUTHORITY_1_3_17=BUILT \
 WHEELCHAIR_OWNS_WORK_NOT_SILICON=1 \
 DONE_EXECUTION_TERMINAL_RELEASE=1 \
 INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0 \
 CREDIT_BITMAP=0 \
 CAPACITY_CLAIM=0 \
 CAPACITY_RELEASE=0 \
 RUNTIME_CPU_PINNING=0 \
 PRECREATED_FUTURE_EXECUTORS=0 \
 SLEEPING_FUTURE_EXECUTORS=0 \
 GENERAL_SINGLE_PREDECESSOR_ATOMIC_ARRIVAL=0 \
 GENERAL_MULTI_PREDECESSOR_JOIN=LOCK_XADD_ONLY \
 GENERAL_READY_SUCCESSOR_DIRECT_MATERIALIZATION=1 \
 TENSOR_FIELD_SPLIT_RESOURCE_QUERY=0 \
 OS_HARDWARE_PLACEMENT_AUTHORITY=1 \
 WHEELCHAIR_1_3_17_BUILD=PASS
 do grep -q "^$m$" "$T/build.log"; done
echo 'EXTERNAL_SILICON_BUILD_AUTHORITY=PASS'

RUNTIMES="runtime/tensor_runtime_138_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S"
for S in $RUNTIMES; do
  grep -q '^run_causal_tree:' "$S"
  grep -q 'SYS_clone' "$S"
  grep -q 'SYS_wait4' "$S"
  ! grep -q 'g_credit_lines' "$S"
  ! grep -q 'g_capacity_ceiling' "$S"
  ! grep -q '^try_claim_credit:' "$S"
  ! grep -q '^release_credit:' "$S"
  ! grep -q '^pin_cpu:' "$S"
  ! grep -q 'SYS_sched_setaffinity' "$S"
  ! grep -q 'SYS_sched_getaffinity' "$S"
  ! grep -q 'lock btr' "$S"
  ! grep -q 'lock bts' "$S"
done
echo 'TENSOR_FIELD_INTERNAL_SILICON_POOL=0'

grep -q '^gr_materialize_node:' runtime/general_parallel_release_x86_64.S
grep -q 'CLONE_OUTWARD_SUCCESSOR' runtime/general_parallel_release_x86_64.S
grep -Fq 'lock xadd dword ptr [rdi],eax' runtime/general_parallel_release_x86_64.S
! grep -q 'SYS_futex' runtime/general_parallel_release_x86_64.S
! grep -q '^gr_run_node_tree:' runtime/general_parallel_release_x86_64.S
! grep -q 'SYS_sched_setaffinity' runtime/general_parallel_release_x86_64.S
! grep -q 'SYS_sched_getaffinity' runtime/general_parallel_release_x86_64.S
! grep -Fq 'lock add dword ptr [rdi],1' runtime/general_parallel_release_x86_64.S
echo 'GENERAL_FUTURE_EXECUTOR_FABRIC=0'
echo 'GENERAL_READY_ONLY_EXECUTION=PASS'

# Resource compatibility spelling cannot change Tensor work existence or result.
SRC=devtrash/tests/whex/strength_probe.whex
for q in 1 4 256; do build/topologyc "$SRC" -o "$T/tensor$q" >/dev/null; done
a=$("$T/tensor1" 100000); b=$("$T/tensor4" 100000); c=$("$T/tensor256" 100000)
[ "$a" = "$b" ]; [ "$a" = "$c" ]
echo 'TENSOR_RESOURCE_OPTION_SEMANTIC_INDEPENDENCE=PASS'

# General graph topology/result likewise does not depend on a silicon width claim.
for q in 1 4 256; do build/wheelchairc devtrash/tests/general_parallel_126/causal_mesh_probe.wh -o "$T/mesh$q" >/dev/null; done
for q in 1 4 256; do [ "$("$T/mesh$q" 1)" = 'out00_bits=0x0000000000000018' ]; done
echo 'GENERAL_RESOURCE_OPTION_SEMANTIC_INDEPENDENCE=PASS'

# Current/frozen production sources must not retain a regeneratable old pool.
if grep -R -n -E '^(try_claim_credit:|release_credit:)|g_credit_lines|g_capacity_ceiling|^pin_cpu:' \
 runtime devtrash/frozen_native/generated_derived devtrash/frozen_native/generated_native256 --include='*.S' > "$T/oldpool" 2>/dev/null; then
  cat "$T/oldpool" >&2; exit 1
fi

echo 'OLD_RESOURCE_POOL_LOGIC_DELETED=PASS'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_OWNS_WORK_NOT_SILICON=PASS'
echo 'WHEELCHAIR_EXTERNAL_SILICON_AUTHORITY_1_3_17=PASS'
