#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = 1.3.25 ]

# Root describes the present. Build is allowed as reproducible scratch while testing.
for p in * .*; do
  case "$p" in
    .|..|.git|build|bin|compiler|runtime|surface|tools|devtrash|README.md|VERSION|build.sh|SHA256SUMS|\
    RELEASE_NOTES_1_3_25.md|WHEELCHAIR_CHARTER_1_3_25.md|PURE_ASSEMBLY_RELEASE_PROOF_1_3_25.md|\
    PERFORMANCE_1_3_25_RELEASE_SURFACE.md|PRODUCTION_BIN_SHA256_1_3_25.txt) ;;
    *) echo "ROOT_SURFACE_LEAK=$p" >&2; exit 1 ;;
  esac
done

echo 'CURRENT_RELEASE_ROOT_ONLY=PASS'

# bin/ is the sole production executable authority.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  test -x "bin/$f"
  test ! -e "$f"
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 10 ]
echo 'BIN_SOLE_EXECUTABLE_AUTHORITY=PASS'

# Archived development material must not be a production source dependency.
for d in compiler runtime surface tools; do
  if grep -R -nF 'devtrash/' "$d" >/dev/null 2>&1; then
    echo "PRODUCTION_DEVTRASH_PATH_DEPENDENCY=$d" >&2; exit 1
  fi
done
if grep -nF 'devtrash/' build.sh >/dev/null 2>&1; then
  echo 'BUILD_DEVTRASH_PATH_DEPENDENCY=FAIL' >&2; exit 1
fi
if find compiler runtime surface tools -type l -print | grep -q .; then
  echo 'PRODUCTION_SYMLINK_AUTHORITY=FAIL' >&2; exit 1
fi
echo 'PRODUCTION_DEVTRASH_PATH_DEPENDENCY=0'

# Strong proof: physically remove devtrash and require a complete production build.
OFF=".devtrash_absent_1325_$$"
cleanup() {
  if [ -d "$OFF" ] && [ ! -e devtrash ]; then mv "$OFF" devtrash; fi
}
trap cleanup EXIT HUP INT TERM
mv devtrash "$OFF"
rm -rf build
./build.sh > .release_build_1325_surface.log 2>&1
cleanup
trap - EXIT HUP INT TERM
grep -Fqx 'WHEELCHAIR_1_3_25_BUILD=PASS' .release_build_1325_surface.log
rm -f .release_build_1325_surface.log

echo 'BUILD_WITH_DEVTRASH_PHYSICALLY_ABSENT=PASS'

# Build output and bin authority must be exact copies.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "bin/$f"
done

echo 'BUILD_BIN_IDENTITY=PASS'

# 1.3.25 is intentionally machine-code identical to 1.3.24.
sha256sum -c devtrash/release_history/PRODUCTION_BIN_SHA256_1_3_24.txt >/dev/null
sha256sum -c PRODUCTION_BIN_SHA256_1_3_25.txt >/dev/null
echo 'PRODUCTION_BINARY_IDENTITY_WITH_1_3_24=PASS'

echo 'DEVTRASH_NON_AUTHORITATIVE=PASS'
echo 'WHEELCHAIR_RELEASE_SURFACE_1_3_25=PASS'
