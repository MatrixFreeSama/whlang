#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
cat >"$TMP/low.wh" <<'SRC'
program precision_low
precision_propagation 0
let a: f32 = cast(f32, 16777216.0)
let b: f64 = 1.0
let c: f32 = a + b
output c = c
SRC
cat >"$TMP/high.wh" <<'SRC'
program precision_high
precision_propagation 1
let a: f32 = cast(f32, 16777216.0)
let b: f64 = 1.0
let c: f64 = a + b
output c = c
SRC
"$CC" "$TMP/low.wh" -o "$TMP/low" >/dev/null
"$CC" "$TMP/high.wh" -o "$TMP/high" >/dev/null
[ "$("$TMP/low")" = 'out00_bits=0x000000004b800000' ]
[ "$("$TMP/high")" = 'out00_bits=0x4170000010000000' ]
objdump -d -M intel "$TMP/low" >"$TMP/low.dis"
objdump -d -M intel "$TMP/high" >"$TMP/high.dis"
grep -q 'cvtsd2ss' "$TMP/low.dis"
grep -Eq 'addss' "$TMP/low.dis"
grep -q 'cvtss2sd' "$TMP/high.dis"
grep -Eq 'addsd' "$TMP/high.dis"
echo PRECISION_POLICY_1_3_34=PASS
