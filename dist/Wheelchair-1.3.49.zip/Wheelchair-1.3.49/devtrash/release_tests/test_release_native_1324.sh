#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.24|1.3.25|1.3.26|1.3.27) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
echo 'PURE_ASSEMBLY_SOURCE_AUTHORITY=PASS'

rm -rf build
./build.sh > .release_build_1324.log 2>&1
for marker in \
 WHEELCHAIR_1_3_23_BUILD=PASS \
 BRANCH_EXTINCTION_1_3_24=BUILT \
 SINGLE_CURRENT_SOURCE_AUTHORITY=PASS \
 COMMON_FACTOR_VALUEFACT_CLOSURE=BUILT \
 COMMON_FACTOR_PRIVATE_OPCODE=0 \
 COMMON_FACTOR_FIXED_TERM_COUNT_ROUTE=0 \
 FIELD_GENERIC_BACKWARD_ABI=0 \
 SOURCE_TEXT_FRONTEND_ROUTER=0 \
 LEGACY_EXECUTOR_CLI=0 \
 LEGACY_CASCADE_CHUNK_SYNTAX=0 \
 FIXED_CHUNK_GEOMETRY=0 \
 CHUNK_GRAIN_AUTHORITY=AOT_PHYSICAL_REALITY \
 FIXED_REDUCTION_DEPTH_FROM_CHUNK=0 \
 RUNTIME_COMMUNICATION_COMPAT_PATCH=0 \
 PRODUCTION_FROZEN_SOURCE_AUTHORITY=0 \
 WORKLOAD_SPECIFIC_OPTIMIZATION_ROUTE=0 \
 WHEELCHAIR_1_3_24_BUILD=PASS
 do grep -Fqx "$marker" .release_build_1324.log; done

echo 'BUILD_1_3_24_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

for t in \
 test_physical_realization_131.sh \
 test_physical_memory_132.sh \
 test_causal_physical_optimization_133.sh \
 test_physical_regularity_134.sh \
 test_physical_realization_uniqueness_135.sh \
 test_global_physical_reality_136.sh \
 test_tensor_physical_reality_137.sh \
 test_strict_parallel_reduction_138.sh \
 test_blind_surplus_reflow_1310.sh \
 test_field_contiguous_collapse_1311.sh \
 test_causal_state_collapse_1312.sh \
 test_register_native_transition_1313.sh \
 test_unified_physical_reality_1314.sh \
 test_rankn_causal_1315.sh \
 test_whole_episode_physical_1316.sh \
 test_external_silicon_authority_1317.sh \
 test_emergent_outward_expansion_1318.sh \
 test_unified_valuefact_pressure_1320.sh \
 test_transport_sparsification_1321.sh \
 test_predicate_sparsification_1322.sh \
 test_transition_power_1323.sh \
 test_execution_granularity_1212.sh \
 test_neighborhood_semantics_1215.sh \
 test_field_native_1216.sh \
 test_field_locality_1217.sh \
 test_field_surface_1218.sh \
 test_branch_extinction_1324.sh
 do
  sh "devtrash/release_tests/$t" >/dev/null
  echo "$t=PASS"
 done

! grep -R -nE 'OP_FACTOR2_ACC|OP_FACTOR_GROUP|vec_select_interior_false|expr_is_axis_delta1|g_try_emit_affine_iterate|g_match_affine_update|gc_affine_' compiler runtime --include='*.S' --include='*.inc' >/dev/null 2>&1
! grep -R -nE 'CHUNK_SHIFT[[:space:]]*,[[:space:]]*(14|16)|CHUNK_SIZE[[:space:]]*,[[:space:]]*(16384|65536)' compiler runtime >/dev/null 2>&1
! grep -R -nE 'communication_elimination_patch|RUNTIME_COMM_ELIM_OFF|executor_count_patch|gr_cpu_width' compiler runtime tools >/dev/null 2>&1
! grep -n '\$FROZEN\|cp .*devtrash/frozen_native' build.sh >/dev/null 2>&1
echo 'DELETED_PRIVATE_AND_COMPATIBILITY_ROUTES=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_24.md RELEASE_NOTES_1_3_24.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_24.md \
 PERFORMANCE_1_3_24_BRANCH_EXTINCTION.md \
 test_branch_extinction_1324.sh test_release_native_1324.sh
 do test -s "$f"; done

echo 'COMMON_FACTOR_PRIVATE_OPCODE=0'
echo 'COMMON_FACTOR_FIXED_TERM_COUNT_ROUTE=0'
echo 'SOURCE_TEXT_FRONTEND_ROUTER=0'
echo 'FIXED_CHUNK_GEOMETRY=0'
echo 'LEGACY_EXECUTOR_CLI=0'
echo 'LEGACY_CASCADE_CHUNK_SYNTAX=0'
echo 'RUNTIME_COMMUNICATION_COMPAT_PATCH=0'
echo 'PRODUCTION_FROZEN_SOURCE_AUTHORITY=0'
echo 'WORKLOAD_SPECIFIC_OPTIMIZATION_ROUTE=0'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WHEELCHAIR_1_3_24_RELEASE=PASS'
