#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1313.log 2>&1
for marker in \
 WHEELCHAIR_1_3_12_BUILD=PASS \
 REGISTER_NATIVE_EXPRESSION_DAG=BUILT \
 PHYSICAL_VALUE_DOMAINS=GPR,XMM \
 OLD_NEW_STATE_GENERATIONS=BUILT \
 WHOLE_TRANSITION_PARALLEL_COMMIT=BUILT \
 FLOAT_PERSISTENT_STATE_BANK=XMM8-XMM10 \
 REUSE_WEIGHTED_FLOAT_CONSTANT_RESIDENCY=XMM2-XMM4 \
 TRANSITION_PATTERN_SWAP_ADD2=XADD \
 TRANSITION_PATTERN_SHIFT_ADD3=BUILT \
 COUNTED_NATIVE_BOTTOM_TEST_BACKEDGE=BUILT \
 ADMITTED_HOT_PUSH_POP=0 \
 ADMITTED_HOT_STATE_TEMP_TRAFFIC=0 \
 ADMITTED_FP_GPR_STACK_ROUNDTRIP=0 \
 TRAPPING_INTEGER_STACK_COMPAT_FALLBACK=PRESERVED \
 RUNTIME_TRANSITION_GRAPH_WALKER=0 \
 RUNTIME_REGISTER_ALLOCATOR=0 \
 WORKLOAD_NAME_SPECIALIZATION=0 \
 STRICT_FP_REASSOCIATION=0 \
 BLIND_SURPLUS_REFLOW=PRESERVED \
 LOAD_BALANCING_FAMILY=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_13_BUILD=PASS
 do grep -q "^$marker$" .release_build_1313.log; done

echo 'BUILD_1_3_13_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_release_native_1312.sh
echo 'COMPLETE_1_3_12_RELEASE_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_register_native_transition_1313.sh
echo 'GENERAL_1_3_13_AUTHORITY=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -R -Eqi '\b(fibonacci|fib_iter|lucas|tribonacci)\b' compiler runtime; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_13.md \
 RELEASE_NOTES_1_3_13.md \
 RELEASE_GATES_1_3_13.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_13.md \
 PERFORMANCE_1_3_13_REGISTER_NATIVE_DAG.md \
 test_register_native_transition_1313.sh \
 test_release_native_1313.sh
 do test -s "$f"; done

echo 'NO_WORKLOAD_NAME_SPECIALIZATION=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'RUNTIME_TRANSITION_GRAPH_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'BLIND_SURPLUS_REFLOW_PRESERVED=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_13_RELEASE=PASS'
