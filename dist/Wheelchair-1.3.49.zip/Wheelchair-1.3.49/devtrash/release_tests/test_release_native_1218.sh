#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"

[ "$(cat VERSION)" = '1.2.18' ]
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1218.log 2>&1
grep -q 'WHEELCHAIR_1_2_18_BUILD=PASS' .release_build_1218.log
grep -q 'NATIVE_FIELD_HUMAN_SURFACE_1_2_18=BUILT' .release_build_1218.log
grep -q 'WH_WHEX_FIELD_BRIDGE_1_2_18=BUILT' .release_build_1218.log
grep -q 'PURE_FN_LEXICAL_SCOPE_1_2_18=BUILT' .release_build_1218.log
grep -q 'FIELD_SURFACE_NEW_RUNTIME_LAYER=0' .release_build_1218.log
grep -q 'FIELD_SURFACE_CANONICAL_FORMAT=wheelchair.field/1' .release_build_1218.log
grep -q 'FIELD_SURFACE_ABI=WHFLD216' .release_build_1218.log
grep -q 'WHEELCHAIR_1_2_17_BUILD=PASS' .release_build_1218.log
grep -q 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS' .release_build_1218.log
grep -q 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0' .release_build_1218.log

# Shipped compilers are exactly the current production build.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Human-source completion must not perturb the already-proven field backend/runtime.
echo '3083e2120af01223b6affea58b7067565e2167f45ee38c8034b3a1fc3e427842  compiler/field_frontend_common_x86_64.S' | sha256sum -c - >/dev/null
echo '1f8536355823b7dac64943130abccc8f32e7a56cb153669f1459a6eea414da40  compiler/field_frontend_512_x86_64.S' | sha256sum -c - >/dev/null
echo '0ea82e9800f20d30bf9716913a750a46a46e38f5492f2f8739a080e4af47a6f1  compiler/field_frontend_256_x86_64.S' | sha256sum -c - >/dev/null
echo 'd83f14db990fde85b066f22f4da0c2835ecdb20049e043eb18d3125e81659813  runtime/field_runtime_512_x86_64.S' | sha256sum -c - >/dev/null
echo '7c3168a28744daff748c135c41603143ec837055bd1310d4d7c719047dfeb76f  runtime/field_runtime_256_x86_64.S' | sha256sum -c - >/dev/null
echo 'FIELD_BACKEND_1_2_17_FROZEN=PASS'
echo 'FIELD_RUNTIME_1_2_17_FROZEN=PASS'

# Historical authorities plus the new top-level surface authority.
devtrash/release_tests/test_release_native_1214.sh
devtrash/release_tests/test_neighborhood_semantics_1215.sh
devtrash/release_tests/test_field_native_1216.sh
devtrash/release_tests/test_field_locality_1217.sh
devtrash/release_tests/test_field_surface_1218.sh

# Direct-native closure.
for f in build/fieldc build/fieldc-native256 build/field_runtime_512_template build/field_runtime_256_template build/whexc; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# The surface is compile-time only.  It may not create a third language/runtime
# or introduce a conventional parallel scheduler into the field lane.
if grep -RniE 'FieldLang|field[ _-]?interpreter|bytecode[ _-]?dispatcher' compiler/field_surface_lowerer_x86_64.inc compiler/fieldc_driver_x86_64.S >/dev/null 2>&1; then
  echo 'FIELD_SURFACE_NEW_LANGUAGE_OR_RUNTIME=FAIL' >&2; exit 1
fi
if grep -RniE 'work[ _-]?steal|global[ _-]?ready[ _-]?queue|central[ _-]?scheduler|post[ _-]?completion[ _-]?peer' \
  compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'FIELD_SURFACE_PARALLEL_RED_LINE=FAIL' >&2; exit 1
fi

# ABI/canonical compatibility remains the 1.2.16 contract.
grep -q '`WHFLD216`' FIELD_ABI_1_2_16.md
if grep -RIlE 'WHFLD218|wheelchair\.field/2' compiler runtime tests tools >/dev/null 2>&1; then
  echo 'FIELD_SURFACE_UNNECESSARY_ABI_OR_CANONICAL_BREAK=FAIL' >&2; exit 1
fi

# Only the compiler surface files may contain the new 1.2.18 human-lowering logic.
if grep -RIl 'surface_field_lower_to_json' runtime >/dev/null 2>&1; then
  echo 'FIELD_SURFACE_RUNTIME_LEAK=FAIL' >&2; exit 1
fi

echo 'FIELD_ABI_1_2_16_COMPATIBLE=PASS'
echo 'FIELD_CANONICAL_1_COMPATIBLE=PASS'
echo 'NO_NEW_RUNTIME_LAYER=PASS'
echo 'NO_FIELDLANG=PASS'
echo 'NO_C_LLVM_JIT=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'BLIND_RELEASE_PRESERVED=PASS'
echo 'WHEELCHAIR_1_2_18_RELEASE=PASS'
