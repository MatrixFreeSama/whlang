#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

# -----------------------------------------------------------------------------
# One dimension-bearing Matrix family. matrix2/3/4 remain surface aliases only.
# A 5x5 case crosses the historical sixteen-component boundary and therefore
# proves that construction, structured checkpointing and basic algebra no longer
# depend on a fixed small-matrix scratch tier.
# -----------------------------------------------------------------------------
cat >"$T/m5.wh" <<'SRC'
program matrix_family_5
let A = matrix(5,
1.0,2.0,3.0,4.0,5.0,
6.0,7.0,8.0,9.0,10.0,
11.0,12.0,13.0,14.0,15.0,
16.0,17.0,18.0,19.0,20.0,
21.0,22.0,23.0,24.0,25.0)
let T = transpose(A)
let H = hadamard(A,A)
let B = A * T
let x: f64 = mget(T,4,1)
let y: f64 = mget(H,2,3)
let z: f64 = mget(B,0,0)
let q: f64 = matrix_trace(A)
output x=x
output y=y
output z=z
output q=q
SRC
"$CC" "$T/m5.wh" -o "$T/m5" >/dev/null
[ "$("$T/m5")" = $'out00_bits=0x4024000000000000\nout01_bits=0x4068800000000000\nout02_bits=0x404b800000000000\nout03_bits=0x4050400000000000' ]

# Partial pivoting is dataflow inside the one inverse implementation.  The old
# zero-first-pivot matrix must invert without a second algorithm surface.
cat >"$T/pivot.wh" <<'SRC'
program pivot_inverse
let A = matrix2(0.0,1.0,1.0,0.0)
let I = matrix_inverse(A)
let a: f64 = mget(I,0,1)
let b: f64 = mget(I,1,0)
output a=a
output b=b
SRC
"$CC" "$T/pivot.wh" -o "$T/pivot" >/dev/null
[ "$("$T/pivot")" = $'out00_bits=0x3ff0000000000000\nout01_bits=0x3ff0000000000000' ]

# Decompositions whose old fixed workset has not yet been generalized must
# reject an oversized MatrixFact rather than indexing past compile-time scratch.
cat >"$T/ch5.wh" <<'SRC'
program cholesky_oversize_safe_reject
let A = matrix(5,
4.0,0.0,0.0,0.0,0.0,
0.0,4.0,0.0,0.0,0.0,
0.0,0.0,4.0,0.0,0.0,
0.0,0.0,0.0,4.0,0.0,
0.0,0.0,0.0,0.0,4.0)
let L = cholesky(A)
let x: f64 = mget(L,0,0)
output x=x
SRC
set +e
"$CC" "$T/ch5.wh" -o "$T/ch5" >/dev/null 2>"$T/ch5.err"
st=$?
set -e
[ "$st" -eq 65 ]
! grep -qi 'segmentation\|core dumped' "$T/ch5.err"

# -----------------------------------------------------------------------------
# P>64 native mathematics. All widths consume the same fpP algebraic authority.
# The local-propagation relations are checked against independent high-precision
# RNE anchors. Current release contract is <=4 ulp on these representative
# points; this is deliberately not a universal correctly-rounded claim.
# -----------------------------------------------------------------------------
for p in 65 127 521; do
cat >"$T/math_$p.wh" <<SRC
program math_$p
precision_propagation 1
let one = cast(fp$p, 1)
let two = cast(fp$p, 2)
let a = sqrt(two)
let b = exp(one)
let c = log(two)
let d = sin(one)
let e = cos(one)
output a=a
output b=b
output c=c
output d=d
output e=e
SRC
"$CC" "$T/math_$p.wh" -o "$T/math_$p" >/dev/null
done

python3 - "$T" <<'PY'
from pathlib import Path
import subprocess,sys
T=Path(sys.argv[1])
EXPECTED={
65:[(0,0x16a09e667f3bcc909),(1,0x15bf0a8b145769535),(-1,0x162e42fefa39ef358),(-1,0x1aed548f090cee042),(-1,0x114a280fb5068b924)],
127:[(0,0x5a827999fcef32422cbec4d9baa55f50),(1,0x56fc2a2c515da54d57ee2b10139e9e79),(-1,0x58b90bfbe8e7bcd5e4f1d9cc01f97b58),(-1,0x6bb5523c2433b8106374f484e2879e19),(-1,0x4528a03ed41a2e48e12336cbb438de95)],
521:[(0,int('16a09e667f3bcc908b2fb1366ea957d3e3adec17512775099da2f590b0667322a95f90608757145875163fcdfb907b6721ee950bc8738f694f0090e6c7bf44ed1a4',16)),(1,int('15bf0a8b1457695355fb8ac404e7a79e3b1738b079c5a6d2b53c26c8228c867f799273b9c49367df2fa5fc6c6c618ebb1ed0364055d88c2f5a7be3dababfacac248',16)),(-1,int('162e42fefa39ef35793c7673007e5ed5e81e6864ce5316c5b141a2eb71755f457cf70ec40dbd75930ab2aa5f695f43621da5d5c6b827042884eae765222d3704a7d',16)),(-1,int('1aed548f090cee0418dd3d2138a1e786513ca22265ea3169bdf6d94bfad8c937bf617b3fe3db9a8aeecab6b04d47a76a184c6aac6bbfa19d7fd134c4a19d6082e52',16)),(-1,int('114a280fb5068b923848cdb2ed0e37a53446e75129f2d876fe46004816ec1cdf52d5288614a5a1d3c87e68a1c771ff33792688083b70404092c0df446a568c6eaf7',16))],
}
def signed64(x): return x-(1<<64) if x>>63 else x
def parse(line):
    _,v=line.split('=',1)
    if not _.endswith('_rankn_fp'): raise AssertionError(line)
    typ,sign,exp,n,sig=v[2:].split(':')
    return int(typ,16),int(sign,16),signed64(int(exp,16)),int(n,16),int(sig,16)
for p in (65,127,521):
    lines=subprocess.check_output([str(T/f'math_{p}')],text=True).splitlines()
    assert len(lines)==5,(p,lines)
    for i,(line,(ee,esig)) in enumerate(zip(lines,EXPECTED[p])):
        typ,sg,e,n,sig=parse(line)
        assert typ==(0x40000000|p) and sg==0 and e==ee,(p,i,line)
        assert abs(sig-esig)<=4,(p,i,hex(sig),hex(esig),sig-esig)
print('FP_NATIVE_MATH_LOCAL_ORACLE_1_3_44=PASS')
PY

# Domain failures stay deterministic and do not fall back to f64.
cat >"$T/sqrt_neg.wh" <<'SRC'
program sqrt_negative
precision_propagation 1
let x = cast(fp127, -1)
let y = sqrt(x)
output y=y
SRC
cat >"$T/log_zero.wh" <<'SRC'
program log_zero
precision_propagation 1
let x = cast(fp127, 0)
let y = log(x)
output y=y
SRC
for f in sqrt_neg log_zero; do
  "$CC" "$T/$f.wh" -o "$T/$f" >/dev/null
  set +e; "$T/$f" >/dev/null 2>&1; st=$?; set -e
  [ "$st" -eq 65 ]
done

S="$ROOT/compiler/surface_lowerer_x86_64.S"
G="$ROOT/compiler/general_frontend_x86_64.S"
R="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
grep -q '^\.equ STF_MATRIX_BASE,0x100' "$S"
grep -q '^s_parse_matrix_relation_call:' "$S"
grep -q '^s_matrix_dim:' "$S"
grep -q 'dimension-derived scratch' "$S"
grep -q 'Gauss-Jordan with dataflow partial pivoting' "$S"
grep -q 'component vector follows the structure itself' "$S"
grep -q 'Checkpoint storage is derived' "$S"
! grep -q '^\.equ STF_MAT5' "$S"
for f in sqrt exp log sin cos; do
  [ "$(grep -c "^\.global rankn_fp_$f$" "$R")" -eq 1 ]
done
grep -q 'local value and the' "$R"
grep -q '^g_emit_rankn_fp_math_unary_top:' "$G"
! grep -RIEqi --include='*.S' --include='*.inc' \
  '(sqrt|exp|log|sin|cos)_fp(65|113|127|128|191|256|521)|fp(65|113|127|128|191|256|521)_(sqrt|exp|log|sin|cos)|math_precision_selector|transcendental_width_selector' \
  "$ROOT/compiler" "$ROOT/runtime"

echo MATRIX_PRECISION_GENERALIZATION_1_3_44=PASS
