#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair136_reality_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

case "$(cat VERSION)" in 1.3.6|1.3.7|1.3.8|1.3.10|1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac
./build.sh > "$T/build.log" 2>&1
for m in \
 GLOBAL_PHYSICAL_REALITY=BUILT \
 GLOBAL_PHYSICAL_FACT_GRAPH=BUILT \
 PHYSICAL_FACT_VERSION_AUTHORITY=per-field-no-global-flush \
 GLOBAL_ADDRESS_FACT_CANONICALIZATION=BUILT \
 GLOBAL_LOAD_FACT_IDENTITY=BUILT \
 GLOBAL_CONSTANT_FACT_POOL=BUILT \
 RETAIN_VS_RECOMPUTE=compile-time-lifetime+profitability \
 DEPENDENCY_NECESSITY_PROOF=physical-dag \
 AVX2_PHYSICAL_FACT_CONSUMPTION=BUILT \
 AVX512_PHYSICAL_FACT_CONSUMPTION=BUILT \
 AVX512_HIGH_REGISTER_RESIDENCY=BUILT \
 GLOBAL_FLUSH_ON_STORE=0 \
 RESOURCE_RECIPIENT_SELECTION=0 \
 RUNTIME_FACT_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 STRICT_FP_REASSOCIATION=0 \
 WHEELCHAIR_1_3_6_BUILD=PASS
do grep -q "^$m$" "$T/build.log"; done
echo 'GLOBAL_PHYSICAL_REALITY_BUILD_AUTHORITY=PASS'

# Historical 1.3.5 physical-fact authority must remain intact.
devtrash/release_tests/test_physical_realization_uniqueness_135.sh > "$T/135.log" 2>&1
grep -q '^WHEELCHAIR_PHYSICAL_REALIZATION_UNIQUENESS_1_3_5=PASS$' "$T/135.log"
echo 'PHYSICAL_REALIZATION_UNIQUENESS_1_3_5_PRESERVED=PASS'

# Semantic cross-output width is no longer the old three-output magic number.
# Four independent epochs exercise two physical windows (3 + 1) on both ISAs.
for C in fieldc-native256 fieldc; do
  build/$C devtrash/tests/field_136/cross4_tolerant.json -o "$T/$C-cross4" >/dev/null
  for i in 0 1 2 3; do cp devtrash/tests/field_133/factor_out_3x5x7.whfld "$T/$C-o$i.whfld"; done
  "$T/$C-cross4" \
    devtrash/tests/field_133/factor_a_3x5x7.whfld \
    devtrash/tests/field_133/factor_b_3x5x7.whfld \
    devtrash/tests/field_133/factor_x_3x5x7.whfld \
    "$T/$C-o0.whfld" "$T/$C-o1.whfld" "$T/$C-o2.whfld" "$T/$C-o3.whfld" >/dev/null
  for i in 0 1 2 3; do cmp "$T/$C-o$i.whfld" devtrash/tests/field_133/factor_expected_tolerant_3x5x7.whfld; done
done
echo 'CROSS_OUTPUT_WIDTH_4_AVX2_AVX512=PASS'

# Two syntax-level accesses describe one exact physical address and one exact
# strict LoadFact. Output is frozen from 1.3.5 semantics; 1.3.6 may remove only
# repeated realization, never alter the value.
for C in fieldc-native256 fieldc; do
  build/$C devtrash/tests/field_136/duplicate_load_strict.json -o "$T/$C-dup" >/dev/null
  cp devtrash/tests/field_1216/out_3x5x7.whfld "$T/$C-dup-out.whfld"
  "$T/$C-dup" devtrash/tests/field_1216/a_3x5x7.whfld "$T/$C-dup-out.whfld" >/dev/null
  cmp "$T/$C-dup-out.whfld" devtrash/tests/field_136/duplicate_load_expected_3x5x7.whfld
done
# Machine proof: the native256 generated region contains one invariant address
# materialization although the source declares two identical access records.
dd if="$T/fieldc-native256-dup" of="$T/dup.bin" bs=1 skip=$((0x8000)) status=none
objdump -D -b binary -m i386:x86-64 -Mintel "$T/dup.bin" > "$T/dup.S" 2>/dev/null
addr_births=$(grep -Eci 'mov[[:space:]]+r11,QWORD PTR \[rip' "$T/dup.S" || true)
[ "$addr_births" -eq 1 ]
echo "CANONICAL_ADDRESS_FACT_MATERIALIZATIONS=$addr_births"
echo 'GLOBAL_ADDRESS_FACT_UNIQUENESS=PASS'
echo 'GLOBAL_LOAD_FACT_REUSE=PASS'

# A write changes only that field version. A following load of the same address
# must observe the new version rather than an old cached LoadFact.
for C in fieldc-native256 fieldc; do
  build/$C devtrash/tests/field_136/versioned_inout_strict.json -o "$T/$C-ver" >/dev/null
  cp devtrash/tests/field_1216/a_3x5x7.whfld "$T/$C-ver-io.whfld"
  "$T/$C-ver" "$T/$C-ver-io.whfld" >/dev/null
  cmp "$T/$C-ver-io.whfld" devtrash/tests/field_136/versioned_inout_expected_3x5x7.whfld
done
echo 'VERSIONED_LOAD_INVALIDATION=PASS'
echo 'NO_GLOBAL_FACT_FLUSH=PASS'

# ISA realization proof on the canonical high-pressure tolerant graph.
J=devtrash/tests/field_1216/fem_hex8_full_tolerant_133.json
JS=devtrash/tests/field_1216/fem_hex8_full.json
build/fieldc "$J" -o "$T/tol512" >/dev/null
build/fieldc-native256 "$J" -o "$T/tol256" >/dev/null
build/fieldc "$JS" -o "$T/strict512" >/dev/null
for b in tol512 tol256 strict512; do
  dd if="$T/$b" of="$T/$b.bin" bs=1 skip=$((0x8000)) status=none
  objdump -D -b binary -m i386:x86-64 -Mintel "$T/$b.bin" > "$T/$b.S" 2>/dev/null
done
zmm_high=$(grep -Eci 'zmm(8|9|1[0-5])' "$T/tol512.S" || true)
zmm_memfma=$(grep -Eci 'vfmadd[^[:cntrl:]]*ZMMWORD PTR \[rsp' "$T/tol512.S" || true)
zmm_fma=$(grep -ci 'vfmadd' "$T/tol512.S" || true)
ymm_high=$(grep -Eci 'ymm(8|9|1[0-5])' "$T/tol256.S" || true)
strict_fma=$(grep -ci 'vfmadd' "$T/strict512.S" || true)
[ "$zmm_high" -ge 100 ]
[ "$zmm_fma" -ge 1000 ]
[ "$ymm_high" -ge 100 ]
[ "$strict_fma" -eq 0 ]
echo "AVX512_HIGH_ZMM_REFERENCES=$zmm_high"
echo "AVX512_DIRECT_MEMORY_FMA_SITES=$zmm_memfma"
echo "AVX512_TOLERANT_FMA_SITES=$zmm_fma"
echo "AVX2_HIGH_YMM_REFERENCES=$ymm_high"
echo 'AVX512_PHYSICAL_FACT_REALIZATION=PASS'
echo 'STRICT_FP_REASSOCIATION=0'

# Source authority: identity, version and address/load/value concepts are
# separate compile-time objects; physical width follows the register bank.
S=compiler/field_frontend_common_x86_64.S
grep -q '^ff_build_global_physical_reality_136:' "$S"
grep -q '^ff_global_intern_fact_136:' "$S"
grep -q 'ff_access_address_fact' "$S"
grep -q 'ff_field_version_136' "$S"
grep -q 'ff_field_written_136' "$S"
grep -q '^ff_contract_common_factors_1324:' "$S"
if grep -qE 'OP_FACTOR2_ACC|OP_FACTOR_GROUP|ff_wide_term_|ff_cross_|CROSS_PHYSICAL_WINDOW|CROSS_OUTPUT_STORAGE' "$S"; then
  echo 'PRIVATE_CROSS_OUTPUT_ROUTE=FAIL' >&2; exit 1
fi
echo 'GLOBAL_FACT_SOURCE_AUTHORITY=PASS'
echo 'PRIVATE_CROSS_OUTPUT_ROUTE=0'
echo 'COMMON_FACTOR_VALUEFACT_CLOSURE=PASS' 

# No runtime fact manager, scheduler, autotuner, peer-query or stealing fabric.
if grep -RniE 'runtime[ _-]*fact[ _-]*manager|runtime[ _-]*residency[ _-]*manager|runtime[ _-]*autotun|work[ _-]*steal|global[ _-]*ready[ _-]*queue' \
  compiler runtime | grep -v -E 'No |no |RUNTIME_|WORK_STEALING|runtime autotun|comment|Red line|PR137_|PR138_' >/dev/null 2>&1; then
  echo 'FORBIDDEN_RUNTIME_PHYSICAL_MANAGER=FAIL' >&2; exit 1
fi
if grep -RniE 'Taichi|SPGrid|compute_Ap|elasticity|fem_hex8|benchmark[_ -]*mode' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'NO_RUNTIME_FACT_MANAGER=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_GLOBAL_PHYSICAL_REALITY_1_3_6=PASS'
