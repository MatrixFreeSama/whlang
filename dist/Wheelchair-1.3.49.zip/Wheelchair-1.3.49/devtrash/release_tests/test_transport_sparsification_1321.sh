#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1321_transport_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc

# Same Physical Reality, no transport backend or state-count magic threshold.
grep -q 'PR138_VALUEFACT_TRANSPORT_SPARSIFICATION,1' "$P"
grep -q 'PR138_TIMESTEP_BOUNDARY_FORCES_TRANSPORT,0' "$P"
grep -q 'PR138_OLD_AUTHORITY_REUSE_AT_LAST_CONSUMER,1' "$P"
grep -q 'PR138_FP_STATE_RESIDENCY_MAGIC_THRESHOLD,0' "$P"
grep -q '^g_phys_build_state_last_use:' "$G"
grep -q '^g_phys_note_effective_state_uses:' "$G"
! grep -q 'G_PHYS_FP_RESIDENT_MAX' "$G"
! grep -Eqi '^g_.*(chem|reaction|rigid|ring8|mass3).*:' "$G"

echo 'TIMESTEP_BOUNDARY_FORCES_TRANSPORT=0'
echo 'FP_STATE_RESIDENCY_MAGIC_THRESHOLD=0'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]
  objdump -d -Mintel "$T/$name" > "$T/$name.dis"
  awk '
    /cmp    rbx,rbp/ && !seen { seen=1; next }
    seen && /movabs ds:0x422100/ { exit }
    seen { print }
  ' "$T/$name.dis" > "$T/$name.hot"
  test -s "$T/$name.hot"
  ! grep -Eq '(^|[[:space:]])(push|pop)([[:space:]]|$)' "$T/$name.hot"
}

S=devtrash/benchmarks/general_whole_episode_1316
compile_run "$S/chem6.wh" chem 100000 'out00_bits=0x3fad4117d563218b'
[ "$(grep -c 'vmulsd' "$T/chem.hot")" -eq 15 ]
# No state mailbox handoff remains in the steady-state chem6 loop.
! grep -q 'movabs ds:' "$T/chem.hot"
[ "$(grep -cE '^ +[0-9a-f]+:' "$T/chem.hot")" -le 59 ]

echo 'CHEM6_STATE_TRANSPORT_ERASED=PASS'

R=devtrash/tests/general_rankn_causal_1315
compile_run "$R/ring8.wh" ring8 100000 'out00_bits=0x3fecf46d818b3308'
[ "$(grep -c 'vmulsd' "$T/ring8.hot")" -eq 8 ]
# One remaining memory authority is allowed when actual ring causality requires it,
# but the old fixed six-state policy must not force broad transport.
[ "$(grep -c 'movabs ds:' "$T/ring8.hot" || true)" -le 1 ]
[ "$(grep -cE '^ +[0-9a-f]+:' "$T/ring8.hot")" -le 42 ]

echo 'RING8_CARRIER_GEOMETRY_RESIDENCY=PASS'

# Unrelated mature arithmetic peaks remain protected.
compile_run "$S/mass3.wh" mass 100000 'out00_bits=0x3fa90c89b2e19b14'
compile_run "$S/rigid7.wh" rigid 100000 'out00_bits=0x3fd72fe2f4bace4b'
compile_run "$S/rigid7_cseprobe.wh" rigidcse 100000 'out00_bits=0x3fd92ec02dbff083'
[ "$(grep -c 'vmulsd' "$T/mass.hot")" -eq 18 ]
[ "$(grep -c 'vmulsd' "$T/rigid.hot")" -eq 41 ]
[ "$(grep -c 'vmulsd' "$T/rigidcse.hot")" -eq 38 ]

echo 'UNRELATED_ARITHMETIC_PEAKS_PRESERVED=PASS'
echo 'WORKLOAD_SPECIFIC_TRANSPORT_ROUTE=0'
echo 'RUNTIME_TRANSPORT_MANAGER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'WHEELCHAIR_TRANSPORT_SPARSIFICATION_1_3_21=PASS'
