#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.23 ]

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
echo 'PURE_ASSEMBLY_SOURCE_AUTHORITY=PASS'

rm -rf build
./build.sh > .release_build_1323.log 2>&1
for marker in \
 WHEELCHAIR_1_3_22_BUILD=PASS \
 COMPOSITION_CLOSED_TRANSITION_POWER_1_3_23=BUILT \
 TRANSITION_POWER_AUTHORITY=EXISTING_PHYSICAL_REALITY \
 TRANSITION_POWER_BACKWARD_SLICE=PUBLISHED_RESULT \
 TRANSITION_POWER_STATE_COUNT_ROUTE=0 \
 TRANSITION_POWER_REPEAT_MAGIC_THRESHOLD=0 \
 FIXED_AFFINE_AST_MATCHER=0 \
 FIXED_TWO_STATE_AFFINE_ROUTE=0 \
 RUNTIME_TRANSITION_POWER_MANAGER=0 \
 WORKLOAD_SPECIFIC_TRANSITION_POWER_ROUTE=0 \
 FROZEN_BOUNDARY_SELECT_PRIVATE_MATCHER=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_23_BUILD=PASS
 do grep -Fqx "$marker" .release_build_1323.log; done

echo 'BUILD_1_3_23_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

for t in \
 test_physical_realization_131.sh \
 test_physical_memory_132.sh \
 test_causal_physical_optimization_133.sh \
 test_physical_regularity_134.sh \
 test_physical_realization_uniqueness_135.sh \
 test_global_physical_reality_136.sh \
 test_tensor_physical_reality_137.sh \
 test_strict_parallel_reduction_138.sh \
 test_blind_surplus_reflow_1310.sh \
 test_field_contiguous_collapse_1311.sh \
 test_causal_state_collapse_1312.sh \
 test_register_native_transition_1313.sh \
 test_unified_physical_reality_1314.sh \
 test_rankn_causal_1315.sh \
 test_whole_episode_physical_1316.sh \
 test_external_silicon_authority_1317.sh \
 test_emergent_outward_expansion_1318.sh \
 test_unified_valuefact_pressure_1320.sh \
 test_transport_sparsification_1321.sh \
 test_predicate_sparsification_1322.sh \
 test_transition_power_1323.sh \
 test_execution_granularity_1212.sh \
 test_neighborhood_semantics_1215.sh \
 test_field_native_1216.sh \
 test_field_locality_1217.sh \
 test_field_surface_1218.sh
 do
  sh "devtrash/release_tests/$t" >/dev/null
  echo "$t=PASS"
 done

G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc
grep -q '^g_try_emit_transition_power_slice:' "$G"
grep -q '^g_collect_u64_transition_affine:' "$G"
grep -q 'PR138_TRANSITION_POWER_CLOSED_FAMILY,1' "$P"
grep -q 'PR138_TRANSITION_POWER_STATE_COUNT_ROUTE,0' "$P"
! grep -R -q 'g_try_emit_affine_iterate\|g_match_affine_update\|gc_affine_' compiler devtrash/frozen_native --include='*.S' --include='*.inc'
! grep -R -q 'vec_select_interior_false\|expr_is_axis_delta1' compiler devtrash/frozen_native --include='*.S' --include='*.inc'
echo 'PRIVATE_RECURRENCE_AND_BOUNDARY_ROUTES_ERASED=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_23.md RELEASE_NOTES_1_3_23.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_23.md \
 PERFORMANCE_1_3_23_TRANSITION_POWER.md \
 test_transition_power_1323.sh test_release_native_1323.sh
 do test -s "$f"; done

echo 'TRANSITION_POWER_STATE_COUNT_ROUTE=0'
echo 'TRANSITION_POWER_REPEAT_MAGIC_THRESHOLD=0'
echo 'FIXED_TWO_STATE_AFFINE_ROUTE=0'
echo 'FIXED_AFFINE_AST_MATCHER=0'
echo 'RUNTIME_TRANSITION_POWER_MANAGER=0'
echo 'WORKLOAD_SPECIFIC_TRANSITION_POWER_ROUTE=0'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WHEELCHAIR_1_3_23_RELEASE=PASS'
