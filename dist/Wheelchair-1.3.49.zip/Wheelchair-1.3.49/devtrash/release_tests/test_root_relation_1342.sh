#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

run_root() {
  local name=$1 expr=$2 expected=$3
  cat >"$T/$name.wh" <<SRC
program root_$name
let r = $expr
let valid = root_valid(r)
let re: f64 = real(r)
let im: f64 = imag(r)
output valid = valid
output re = re
output im = im
SRC
  "$CC" "$T/$name.wh" -o "$T/$name" >/dev/null
  [ "$("$T/$name")" = "$expected" ]
}

# Omitted budget is exactly five AOT Newton generations.  Root type is not an
# input declaration: one sparse RootFact reports validity plus real/imag facts.
run_root real_default 'root(x, x*x - 2.0, 1.0)' $'out00_bits=0x0000000000000001\nout01_bits=0x3ff6a09e667f3bcc\nout02_bits=0x0000000000000000'
run_root real_explicit5 'root(x, x*x - 2.0, 1.0, 5)' $'out00_bits=0x0000000000000001\nout01_bits=0x3ff6a09e667f3bcc\nout02_bits=0x0000000000000000'

# A relation that has no real root grows on-site into the already existing
# complex Structured Fact authority.  Five generations are insufficient and
# therefore remain sparse-empty; eight generations produce +i.
run_root complex_budget5 'root(x, x*x + 1.0, 1.0)' $'out00_bits=0x0000000000000000\nout01_bits=0x0000000000000000\nout02_bits=0x0000000000000000'
run_root complex_budget8 'root(x, x*x + 1.0, 1.0, 8)' $'out00_bits=0x0000000000000001\nout01_bits=0x0000000000000000\nout02_bits=0x3ff0000000000000'

# No-candidate work is empty rather than a divide-by-zero runtime failure.
run_root constant_empty 'root(x, 1.0, 0.0, 8)' $'out00_bits=0x0000000000000000\nout01_bits=0x0000000000000000\nout02_bits=0x0000000000000000'

# Existing native transcendental semantics are parasitized, not reimplemented
# in root.  exp has no accepted root; sin around 3 reaches the nearest f64 pi in default budget.
run_root exp_empty 'root(x, exp(x), 0.0)' $'out00_bits=0x0000000000000000\nout01_bits=0x0000000000000000\nout02_bits=0x0000000000000000'
run_root sin_pi 'root(x, sin(x), 3.0)' $'out00_bits=0x0000000000000001\nout01_bits=0x400921fb54442d18\nout02_bits=0x0000000000000000'

SRC="$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^\.equ STF_ROOT,2' "$SRC"
grep -q '^\.equ MB_ROOT_VALID,96' "$SRC"
grep -q '^s_clone_subst_root:' "$SRC"
grep -q '^s_root_select_new:' "$SRC"
grep -q '^s_ast_diff_struct:' "$SRC"
grep -q 'root(x,expr,guess\[,iterations\])' "$SRC"
grep -q 'mov qword ptr \[rsp+40\],5' "$SRC"
grep -q 'call s_eval_static_u64' "$SRC"
grep -q 's_materialize_struct' "$SRC"
grep -q 'DBL_EPSILON' "$SRC"
grep -q 'Zero derivative is not a solver fork' "$SRC"
grep -q 'RootFact stores' "$SRC"

# The release must have one root relation and no parallel real/complex/fallback
# solver family or runtime root scheduler.
[ "$(grep -c '^s_parse_root_call:' "$SRC")" -eq 1 ]
! grep -RIE --include='*.S' --include='*.inc' \
  '(^|[^[:alnum:]_])(real_root|complex_root|root_fallback|root_algorithm_selector|root_scheduler|root_runtime)([^[:alnum:]_]|$)' \
  "$ROOT/compiler" "$ROOT/runtime" >/dev/null 2>&1 || exit 1

echo SPARSE_ROOT_RELATION_1_3_42=PASS
