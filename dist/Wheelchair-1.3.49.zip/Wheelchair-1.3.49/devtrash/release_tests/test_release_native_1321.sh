#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.21 ]

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

echo 'PURE_ASSEMBLY_SOURCE_AUTHORITY=PASS'

rm -rf build
./build.sh > .release_build_1321.log 2>&1
for marker in \
 WHEELCHAIR_1_3_20_BUILD=PASS \
 PHYSICAL_VALUEFACT_TRANSPORT_SPARSIFICATION_1_3_21=BUILT \
 TIMESTEP_BOUNDARY_FORCES_TRANSPORT=0 \
 OLD_AUTHORITY_REUSE=FINAL_EFFECTIVE_CONSUMER \
 FP_STATE_RESIDENCY_MAGIC_THRESHOLD=0 \
 PERSISTENT_NEXT_COLLISION_ROUTE=PHYSICAL_CARRIER_CONFLICT \
 FP_CARRIER_EXHAUSTION_RETRY=AOT_PHYSICAL_REMAP \
 WORKLOAD_SPECIFIC_TRANSPORT_ROUTE=0 \
 CHEMISTRY_SPECIAL_PATH=0 \
 RUNTIME_TRANSPORT_MANAGER=0 \
 RUNTIME_REGISTER_ALLOCATOR=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_21_BUILD=PASS
 do grep -Fqx "$marker" .release_build_1321.log; done

echo 'BUILD_1_3_21_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

for t in \
 test_physical_realization_131.sh \
 test_physical_memory_132.sh \
 test_causal_physical_optimization_133.sh \
 test_physical_regularity_134.sh \
 test_physical_realization_uniqueness_135.sh \
 test_global_physical_reality_136.sh \
 test_tensor_physical_reality_137.sh \
 test_strict_parallel_reduction_138.sh \
 test_blind_surplus_reflow_1310.sh \
 test_field_contiguous_collapse_1311.sh \
 test_causal_state_collapse_1312.sh \
 test_register_native_transition_1313.sh \
 test_unified_physical_reality_1314.sh \
 test_rankn_causal_1315.sh \
 test_whole_episode_physical_1316.sh \
 test_external_silicon_authority_1317.sh \
 test_emergent_outward_expansion_1318.sh \
 test_unified_valuefact_pressure_1320.sh \
 test_transport_sparsification_1321.sh \
 test_execution_granularity_1212.sh \
 test_neighborhood_semantics_1215.sh \
 test_field_native_1216.sh \
 test_field_locality_1217.sh \
 test_field_surface_1218.sh
 do
  sh "devtrash/release_tests/$t" >/dev/null
  echo "$t=PASS"
 done

G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc
! grep -q 'G_PHYS_FP_RESIDENT_MAX' "$G"
grep -q '^g_phys_build_state_last_use:' "$G"
grep -q '^g_phys_note_effective_state_uses:' "$G"
grep -q 'PR138_VALUEFACT_TRANSPORT_SPARSIFICATION,1' "$P"
grep -q 'PR138_TIMESTEP_BOUNDARY_FORCES_TRANSPORT,0' "$P"
if grep -Eqi '^g_.*(chem|reaction|rigid|ring8|mass3).*:' "$G"; then
  echo 'WORKLOAD_SPECIFIC_TRANSPORT_ROUTE=FAIL' >&2; exit 1
fi
echo 'OLD_FIXED_FP_RESIDENCY_POLICY_ERASED=PASS'
echo 'TRANSPORT_LIFETIME_AUTHORITY=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_21.md RELEASE_NOTES_1_3_21.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_21.md \
 PERFORMANCE_1_3_21_TRANSPORT_SPARSIFICATION.md \
 test_transport_sparsification_1321.sh test_release_native_1321.sh
 do test -s "$f"; done

echo 'WORKLOAD_SPECIFIC_TRANSPORT_ROUTE=0'
echo 'CHEMISTRY_SPECIAL_PATH=0'
echo 'FP_STATE_RESIDENCY_MAGIC_THRESHOLD=0'
echo 'RUNTIME_TRANSPORT_MANAGER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WHEELCHAIR_1_3_21_RELEASE=PASS'
