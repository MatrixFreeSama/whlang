#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

rm -rf build
./build.sh > .release_build_1317.log 2>&1
for marker in \
 WHEELCHAIR_1_3_16_BUILD=PASS \
 EXTERNAL_SILICON_AUTHORITY_1_3_17=BUILT \
 WHEELCHAIR_OWNS_WORK_NOT_SILICON=1 \
 DONE_EXECUTION_TERMINAL_RELEASE=1 \
 INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0 \
 CREDIT_BITMAP=0 CAPACITY_CLAIM=0 CAPACITY_RELEASE=0 \
 RUNTIME_CPU_PINNING=0 PRECREATED_FUTURE_EXECUTORS=0 SLEEPING_FUTURE_EXECUTORS=0 \
 GENERAL_SINGLE_PREDECESSOR_ATOMIC_ARRIVAL=0 \
 GENERAL_MULTI_PREDECESSOR_JOIN=LOCK_XADD_ONLY \
 GENERAL_READY_SUCCESSOR_DIRECT_MATERIALIZATION=1 \
 GENERAL_EXECUTOR_RESOURCE_HANDOFF=0 \
 TENSOR_FIELD_SPLIT_RESOURCE_QUERY=0 \
 OS_HARDWARE_PLACEMENT_AUTHORITY=1 \
 WORK_STEALING=0 GLOBAL_READY_QUEUE=0 RESOURCE_RECIPIENT_SELECTION=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_17_BUILD=PASS
 do grep -q "^$marker$" .release_build_1317.log; done

echo 'BUILD_1_3_17_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_release_native_1316.sh >/dev/null
echo 'COMPLETE_1_3_16_RELEASE_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_external_silicon_authority_1317.sh

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

# Active and current frozen authorities must not be able to regenerate the retired pool model.
if grep -R -n -E '^(try_claim_credit:|release_credit:)|g_credit_lines|g_capacity_ceiling|^pin_cpu:|SYS_sched_setaffinity' \
  runtime compiler devtrash/frozen_native --include='*.S' >/dev/null 2>&1; then
  echo 'INTERNAL_SILICON_OWNERSHIP_LEAK=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_17.md \
 RELEASE_NOTES_1_3_17.md \
 RELEASE_GATES_1_3_17.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_17.md \
 test_external_silicon_authority_1317.sh \
 test_release_native_1317.sh
 do test -s "$f"; done

echo 'NO_INTERNAL_SILICON_POOL=PASS'
echo 'NO_RUNTIME_CPU_PINNING=PASS'
echo 'NO_PRECREATED_SLEEPING_FUTURE_EXECUTORS=PASS'
echo 'TRUE_CAUSAL_JOIN_PRESERVED=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_17_RELEASE=PASS'
