# Wheelchair 1.3.128 — Canonical Packet CoordinateFact Aging

Wheelchair 1.3.128 removes a native256 generic-Field physical redundancy exposed by the 1.3.127 paper experiment.

- A generic AVX2 packet now owns one canonical Rank-N CoordinateFact. Register pressure changes its physical carrier to compact execution-local storage; it no longer causes every AddressFact to rediscover `q -> coordinates`.
- AddressFacts consume the same packet CoordinateFact and perform only their necessary delta / periodic-wrap / physical-stride realization.
- The obsolete AVX2 coordinate-offset stack transport and generic `field_load_f32` runtime authority are deleted rather than retained as compatibility paths.
- No stencil or workload matcher, extent threshold/class, non-power-of-two backend, JIT, scheduler, parallel DSL surface, or benchmark-specific branch is introduced.
- Direct Region execution, Strict floating-point order, RankFact, RegionFact, GroupFact, Physical DAG, execution admission, and heterogeneous-silicon authorities remain unchanged.
- Strict 1.3.127 -> 1.3.128 checksums are bit-identical across the retained miniAMR-27 / miniFE-21 shape sweep.

The release is an architecture-aging repair: one semantic fact is materialized once and shared; carrier scarcity may alter placement but not multiply mathematical work.
