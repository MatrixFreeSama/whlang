# Wheelchair / WHEX General True-Parallel Charter — 1.1.0

## Highest rule

A higher abstraction is acceptable only when it preserves or improves the proven
machine topology. Wheelchair does not pay abstraction tax merely because the source
language becomes richer.

```text
human abstraction rises
        +
compile-time structural knowledge rises
        ->
false dependencies fall
runtime objects fall
serial work does not appear
```

The release contract is:

```text
FeatureComplete = Correct && Erased && Parallel && NonRegressive
```

## Structural path

```text
Human Semantic Layer
    -> Axis Algebra
    -> Region / Ownership Algebra
    -> Effect Algebra
    -> Operator / Relation Algebra
    -> Dependency / Control Topology
    -> Parallelism Preservation Proof
    -> Resource Plan
    -> ISA Capability Realization
    -> Native Code
```

Syntax is not allowed to jump directly to a sequential machine loop.

## No hidden von-Neumann spine

Unless source semantics contain a real causal dependency, a lowering pass may not
introduce:

- a central fetch/dispatch loop;
- a global task queue;
- a root spawn-all loop;
- a root wait-all loop;
- a root sequential reduction sweep;
- a global barrier;
- a scalar boundary path;
- a scalar tail;
- a scalar tensor fallback;
- an implicit global lock;
- an implicit runtime borrow table that serializes independent work.

No dependency edge means no synchronization edge.

## Parallelism preservation

Every structural pass must preserve the independent domain width unless it proves
that the corresponding work is mathematically unnecessary.

Mathematical elimination is not serialization. Examples include:

- canceled operator directions;
- identical pure-map common subexpressions;
- periodic relation collapse;
- predicate erasure in proven interior regions;
- irrelevant Rank-N axis elimination.

A resource shortage may select another vector recipe or reject compilation. It may
not select scalar tensor execution.

## Effect and ownership discipline

The pure lane is immutable and race-free by construction. Future mutable semantics
must be expressed through Region/Effect relations and must prove disjointness,
atomicity, or causal ordering. Failure to prove one of those conditions is a compile
rejection, not permission for the compiler to insert a hidden global lock.

## Control discipline

Source `if`, `match`, `select`, or future loop syntax describes semantic control, not
a required central program-counter sequence. Lowering first attempts predicate/dataflow,
state graph, recurrence, scan, reduction, wavefront, or independent-axis structure.
Only a genuinely causal source relation may survive as ordered execution.

## Runtime erasure

Any fact known at compile time must remain compile-time knowledge unless runtime
publication is semantically observable. Shape metadata, region names, pure structural
functions, record containers, effect annotations, dependency metadata, and proven
axis relations are not runtime objects in the current WHEX lane.

## Performance preservation

A language-semantic release may not regress existing native kernels. 1.1.0 therefore
requires old WHEX canonical graphs and native ELFs to remain byte-identical. New
high-level abstractions are compared against manually inlined equivalents and must
also erase to byte-identical native output.

A future release that intentionally improves native code may update the frozen
machine-code baseline only after numerical, topology, and performance gates establish
that the change is an improvement rather than abstraction overhead.

## No benchmark specialization

Optimization decisions may depend on algebraic, axis, region, effect, dependency,
capability, or machine-resource properties. They may not depend on workload, solver,
benchmark, language-opponent, or file names.

## Rank-N rule

Dimensional information is preserved through proof. It must not be flattened early
for implementation convenience. When an axis is mathematically irrelevant it may be
eliminated before native realization. When a used Rank-N structure lacks a physical
realizer, compilation rejects explicitly rather than fabricating a hidden serial nest.

## Release gates

Every mature semantic feature must provide:

1. semantic correctness evidence;
2. abstraction-erasure evidence;
3. dependency/parallelism evidence;
4. serial-introduction report;
5. old-performance baseline preservation;
6. no-workload-dispatch audit;
7. explicit rejection evidence for unsupported semantics.

The goal is not to make Wheelchair resemble a conventional language with more SIMD.
The goal is to let the source language become more general while preserving the
structural information required to remain in the hand-tuned machine-code performance
regime.
