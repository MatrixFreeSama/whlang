# Wheelchair Charter 1.3.111

Wheelchair remains a whole-progress static AOT language. Parallel and serial realization arise from causal structure and Physical Reality, not from a source-visible parallel DSL.

For P>64, precision is data and Rank-N remains the one high-precision route. Local Propagation means that a semantic relation carries only the facts forced by that relation and does not globally reorganize information merely to maintain a prettier intermediate representation.

1.3.111 applies that rule by compacting division's logical digits, retaining quotient geometry already known by the producer, and deriving scratch capacity from actual physical facts. No algorithm zoo, named-width backend or compatibility branch is admitted.
