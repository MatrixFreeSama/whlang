#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP=${TMPDIR:-/tmp}/wheelchair_tensor13102_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
SRC="$ROOT/compiler/tensor_derived_frontend_x86_64.S"

# Existing arbitrary-radix CoordinateFact recurrence stays the sole coordinate authority.
grep -q '^vec_mixed_chain_preflight:' "$SRC"
grep -q '^vec_mixed_emit_step_chain:' "$SRC"
grep -q '^vec_mixed_find_direct_residue:' "$SRC"
grep -q '^vec_mixed_emit_step:' "$SRC"
grep -q '^vec_mixed_scaled_refresh:' "$SRC"

# 1.3.102: logical scaled-fact identity survives physical register allocation.
grep -q 'mov r13d,ecx.*logical scaled-fact slot survives physical-reg allocation' "$SRC"
grep -q 'lea eax,\[r13d+1\]; mov dword ptr \[rip+vec_dense_scaled_count\],eax' "$SRC"

# Tolerance consumes one explicit reciprocal relation; Strict never calls it.
grep -q '^recip_tolerant_f64_bits:' "$SRC"
grep -q 'cmp dword ptr \[rip+tensor_tolerant_fp\],0' "$SRC"
grep -q 'call recip_tolerant_f64_bits' "$SRC"
! grep -Eq 'dense_irregular_allpairs127|waitslow|mass3|chem6|rigid7' "$SRC"

cat > "$TMP/strict.whex" <<'WH'
program tensor_fact_probe
strict
input n: u64 range 64..65536
field x[b in n, i in 127]: f64 = -0.375 + cast(f64, (b * 31 + i * 17 + 5) % 2048) / 1024.0
field y[b in n, i in 127]: f64 = 0.25 + cast(f64, (b * 19 + i * 23 + 7) % 1024) / 1536.0
sum checksum[b in n, i in 127, j in 127]: f64 =
    x[b, i] * y[b, (j * 37 + i * 13 + b * 7 + 11) % 127] * (0.75 + cast(f64, (i * 29 + j * 43 + b * 3 + 17) % 257) / 512.0)
  + 0.03125 * x[b, (j * 19 + i * 5 + b * 11 + 23) % 127] * x[b, i]
  - 0.015625 * y[b, j] * y[b, (i * 41 + j * 17 + b * 13 + 31) % 127]
output checksum
WH
sed 's/^strict$/tolerance 1e-10/' "$TMP/strict.whex" > "$TMP/fast.whex"
"$ROOT/bin/whexc" "$TMP/strict.whex" -o "$TMP/strict" >/dev/null
"$ROOT/bin/whexc" "$TMP/fast.whex" -o "$TMP/fast" >/dev/null
CPU1=$(python3 -c 'import os; print(min(os.sched_getaffinity(0)))')
CPUS=$(python3 -c 'import os; print(",".join(map(str,sorted(os.sched_getaffinity(0))[:4])))')
[ "$("$TMP/strict" 64)" = 'checksum_bits=0x411761c7a7f92980' ]
[ "$("$TMP/strict" 127)" = 'checksum_bits=0x41272d5ac3e2792e' ]
# Tolerance permits reassociation across ownership cardinalities. Pin its
# numerical smoke check to one admitted execution instead of manufacturing an
# accidental executor-count contract.
[ "$(taskset -c "$CPU1" "$TMP/fast" 64)" = 'checksum_bits=0x411761c7a7f92978' ]
# The same Strict image must retain one mathematical reduction tree when the
# invocation is externally admitted to a different execution cardinality.
ONE=$(taskset -c "$CPU1" "$TMP/strict" 127)
MANY=$(taskset -c "$CPUS" "$TMP/strict" 127)
[ "$ONE" = 'checksum_bits=0x41272d5ac3e2792e' ]
[ "$MANY" = "$ONE" ]
printf '%s\n' \
  'MIXED_RADIX_CARRY_RECURRENCE=PASS' \
  'SCALED_FACT_LOGICAL_PHYSICAL_ALIAS=0' \
  'TOLERANT_LITERAL_DIV_RECIPROCAL=PASS' \
  'STRICT_REDUCTION_EXECUTION_CARDINALITY_INVARIANT=PASS' \
  'RUNTIME_RADIX_SELECTOR=0' \
  'DENSE_MIXED_WORKLOAD_MATCHER=0' \
  'SECOND_TENSOR_IR=0' \
  'WHEELCHAIR_TENSOR_FACT_AGING_1_3_102=PASS'
