# Performance 1.3.102

The principal performance repair is execution-admission correctness rather than a new hot kernel.

On Dense Cross-Axis Rank-3, the diagnostic candidate compiled on a 5-CPU environment but invoked on four CPUs previously kept five-way ownership. Refreshing admission to four raised measured four-core slot occupancy from about 84% to about 94% and reduced the same candidate wall time from about 823.7 ms to 751.0 ms (1.097x) before the final Strict canonical-reduction repair.

In the final release, Fast/Tolerance retains balanced arbitrary-cardinality ownership and a five-round precise A/B against 1.3.101 measured about 1.054x on the same Cross-Axis probe (816.95 -> 773.17 ms medians in that run).

Strict is not reported as a like-for-like speedup against 1.3.101 because 1.3.101 let compile-time execution admission change the reduction tree. 1.3.102 deliberately fixes that semantic defect: one generated Strict image produced identical Cross-Axis checksums under 1, 2, 3, 4 and 5 admitted CPUs.

The low-arithmetic, high-entropy permutation workload remains a strong structural case after the stricter reduction repair. A fresh three-round four-core check at n=50,000,000 measured medians of roughly 71.1 ms for Wheelchair 1.3.102 Strict, 181.8 ms for C Strict and 216.9 ms for Fortran Strict, with bit-identical checksums in that run.

These measurements are same-host diagnostics, not universal performance claims.
