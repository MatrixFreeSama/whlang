# Wheelchair 1.3.102 Release Notes

1.3.102 ages execution expansion into invocation-bound Physical Reality.

- Execution admission is refreshed once from the invocation affinity domain. Compile-host width is no longer runtime authority.
- AOT static placement may narrow the invocation domain but can never expand it.
- Tensor and Field launch exposure use arbitrary-cardinality balanced ownership geometry; the old power-of-two launch frontier is deleted.
- Strict Tensor reduction is invariant to execution cardinality. Execution ownership may change, the canonical pairwise arithmetic tree may not.
- General exposes ready siblings completion-locally before consuming a local continuation, removing the old head-of-line exposure gap without a global ready queue, worker pool or work stealing.
- Raw clone/exit/wait4 lifecycle remains the execution realization. Completed work returns capacity to the OS rather than transferring it to another Wheelchair task.

No workload matcher, benchmark route, runtime idle-CPU query, worker pool, JIT path, source-visible parallel kernel, second Tensor IR, or DSL execution surface is introduced.
