# Architecture Aging 1.3.102

The release removes three stale identities from expansion.

1. Compile-host execution width is not an image authority. Invocation affinity is sampled once as an admitted execution-domain fact.
2. Static placement is locality information only. It intersects the caller's domain and cannot escape it.
3. Launch geometry is not arithmetic geometry. Arbitrary-K ownership exposure is separate from Strict's immutable pairwise reduction tree.

General execution also removes completion-time sibling head-of-line blocking while retaining no global scheduler, ready queue, stealing path or persistent worker pool.

The release therefore narrows execution realization toward one chain:

`Physical DAG -> invocation admission -> profitable ownership exposure -> raw execution lifecycle -> OS return`
