# Architecture aging 1.3.99

The repair extends existing CoordinateFact ownership instead of creating a
Dense-127 optimizer or a second execution model.

The aging direction is:

```
flat Rank-N root
    -> one proved static mixed-radix relation
    -> persistent CoordinateFact
    -> shared literal-scaled CoordinateFact
    -> physical uses
```

The `<2^32` constant-div/mod realization is pure integer AVX-512F arithmetic.
It deletes repeated conversion through floating-point reciprocal arithmetic in
that proven physical domain. The selector is compile-time proof of the value
domain, not source shape, benchmark identity, vendor identity, or runtime load.

Power-of-two coordinate recurrence remains an algebraic strength reduction of
the same coordinate semantics. Non-power-of-two radices no longer fall out of
CoordinateFact ownership and rebuild themselves at each use.
