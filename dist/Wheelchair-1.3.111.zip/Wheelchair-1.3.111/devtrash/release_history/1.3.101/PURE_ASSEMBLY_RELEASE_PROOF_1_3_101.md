# Pure assembly release proof 1.3.101

Both compiler repairs live in `compiler/tensor_derived_frontend_x86_64.S`, the existing handwritten x86-64 Tensor derived frontend.

Scaled-fact slot preservation is compile-time assembly bookkeeping. Tolerant reciprocal generation is performed at AOT compile time with scalar machine arithmetic and emitted through the existing native vector multiply/FMA machinery. There is no C/C++ helper, JIT compiler, bytecode VM, external optimizer, runtime reciprocal selector, or second Tensor IR.

Release guards reject known benchmark/workload identities from the production frontend.
