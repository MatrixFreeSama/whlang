# Performance 1.3.101

Probe: Dense Permuted All-Pairs 127, `n=8192`, `127 x 127` pair interactions per batch, 100% connectivity. All Wheelchair runs are whole-program AOT executables pinned to CPU 0-3.

## Release-to-release A/B

| Mode | 1.3.100 median | 1.3.101 median | Paired speedup median |
|---|---:|---:|---:|
| Strict, 31 pairs | 249.973 ms | 243.187 ms | **1.005x** |
| Tolerance, 25 pairs | 231.083 ms | 221.466 ms | **1.084x** |

Strict is intentionally a small change: the repair restores scaled-fact identity without changing floating-point semantics. Five single-core interleaved rounds measure 749.714 ms -> 740.505 ms.

Tolerance removes all six generated `vdivpd` instructions in this probe. Seven single-core paired rounds measure 757.966 ms -> 681.198 ms, with a paired speedup near **1.111x**.

## Same-run controls

Nine interleaved four-core rounds on the shared EPYC 9V74 environment:

| Variant | Median |
|---|---:|
| Wheelchair 1.3.101 Strict | 233.465 ms |
| C Strict | 189.394 ms |
| Fortran Strict | 222.293 ms |
| Wheelchair 1.3.101 Tolerance | 218.729 ms |
| C Fast | 191.363 ms |
| Fortran Fast | 200.596 ms |

C/Fortran Strict are compiled with `-O3 -march=native -fopenmp -fno-fast-math -ffp-contract=off`; the explicit `-ffp-contract=off` is required because GCC otherwise permits FMA contraction even with `-fno-fast-math`. Fast controls use `-ffast-math`.

Shared-host frequency variance is visible, so release-to-release paired A/B is the version-speed authority.
