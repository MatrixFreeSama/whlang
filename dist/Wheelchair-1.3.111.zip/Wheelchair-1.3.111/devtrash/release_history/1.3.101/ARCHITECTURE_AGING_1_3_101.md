# Architecture aging 1.3.101

1.3.101 removes two cases where an already-proven fact was physically rebuilt under a different identity.

First, the scaled `CoordinateFact` table had allowed the physical ZMM allocator to overwrite the logical table index in a caller-saved register. The table could therefore report a full logical count while containing holes. The repair preserves logical slot identity across physical-register allocation. It creates no new carrier family and no compatibility route.

Second, tolerant floating-point division by a finite normal compile-time literal no longer keeps a hardware divide after tolerance has already authorized reciprocal scaling. The compiler computes the reciprocal once at AOT time and reuses the existing multiply/FMA realization. Strict mode never calls this relation and retains its original rounding boundary.

The resulting architecture remains one Tensor derived backend, one `CoordinateFact` ownership pool, and the existing Strict/Tolerance semantic split. There is no workload matcher, JIT path, hot-kernel surface, radix selector, worker model, or second Tensor IR.
