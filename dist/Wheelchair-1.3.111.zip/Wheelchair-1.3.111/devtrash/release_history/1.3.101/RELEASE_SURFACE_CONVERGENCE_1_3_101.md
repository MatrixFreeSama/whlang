# Release surface convergence 1.3.101

The public surface is unchanged. 1.3.101 adds no pragma, kernel boundary, tuning knob, parallel construct, radix mode, workload route, or runtime selector.

Current release authority remains 27 tests. The 1.3.100 mixed-radix current test is aged into one 1.3.101 Tensor Fact test covering carry recurrence, scaled-fact logical/physical identity, and tolerant literal reciprocal realization. The 1.3.100 current scripts are archived rather than kept as a second active compatibility layer.
