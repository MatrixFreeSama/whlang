# Wheelchair charter 1.3.101

Wheelchair remains a whole-program static AOT language. Causal structure and Physical Reality determine serial or concurrent realization; source-visible kernel offload is not an architectural authority.

A logical mathematical fact must not acquire a second identity merely because physical allocation uses the same scratch register. A semantic permission already granted by Tolerance should be consumed directly rather than leaving a more expensive physical operation in place. Strict semantics are not weakened to obtain benchmark speed.
