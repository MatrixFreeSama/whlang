# Wheelchair 1.3.101

1.3.101 is a compiler aging release. It repairs fact identity and consumes an already-existing tolerance permission; it does not introduce an optimization family.

## Scaled CoordinateFact identity

`vec_dense_scaled_get_reg` previously kept the logical scaled-fact count in `ECX`, then called the physical ZMM allocator, which also returns its free-register bit index through `ECX`. The clobbered value could be reused as the logical table slot/count, creating holes while the table reported a larger live count.

1.3.101 preserves the logical slot before allocation and derives the new count from that logical slot. Previously unused ZMM22-ZMM25 become valid members of the existing shared ownership pool when facts require them. Sampled Strict outputs remain bit-identical to 1.3.100.

## Tolerant literal division

Tolerance mode now realizes division by a finite normal compile-time f64 literal as one AOT reciprocal relation followed by the existing multiply/FMA path. Strict never enters this relation and keeps source rounding order. On the dense probe the generated Tolerance image changes from six `vdivpd` instructions to zero.

No `fast-math` bundle is imported. The permission is one explicit semantic relation under the existing tolerance switch.

## Performance

On the same dense irregular probe, paired four-core A/B measures a conservative **1.005x** median Strict speedup and **1.084x** median Tolerance speedup. Single-core medians improve 749.714 -> 740.505 ms in Strict and 757.966 -> 681.198 ms in Tolerance.

Current release tests remain **27/27 PASS**.
