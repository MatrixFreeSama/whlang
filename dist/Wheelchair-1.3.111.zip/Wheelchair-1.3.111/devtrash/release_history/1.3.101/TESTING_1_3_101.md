# Testing 1.3.101

- Current release tests: **27/27 PASS**.
- Strict dense probe is bit-identical to 1.3.100 at `n=64,127,128,256,1024,8192`.
- Tolerance dense probe is sampled at the same dimensions and remains within the declared tolerance; on this probe the resulting checksum is also bit-identical.
- The current Tensor Fact test verifies arbitrary-radix carry recurrence, logical scaled-slot preservation across physical register allocation, and the tolerance-only reciprocal relation.
- Existing General modulo, CoordinateFact, Physical DAG, silicon-placement, transport, and execution-admission authorities remain PASS.

See `RELEASE_TEST_LOG_1_3_101.txt` and `PRODUCTION_BIN_SHA256_1_3_101.txt`.
