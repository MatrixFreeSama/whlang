# Performance 1.3.106

Pinned direct-core measurements compare 1.3.106 with the unmodified 1.3.105 Rank-N runtime and GMP 6.3.0 `mpf` on the same host. They are diagnostic, not universal performance claims.

Against 1.3.105:

- Rank-N add improves about 1.24x to 1.46x across the sampled 128-bit to 1,048,576-bit range.
- Rank-N multiply improves about 2.96x at 128 bits, 2.58x at 256 bits, 2.74x at 512 bits, 1.99x at 1024 bits, and approaches parity with the old release at very large widths where Fourier work dominates.
- Rank-N division improves about 1.20x at 128 bits, 1.13x at 256 bits, 1.11x at 512 bits, and is nearly unchanged at large widths. Division remains a major optimization frontier.

Against GMP 6.3.0 `mpf`, Wheelchair does not win overall. In the sampled multiplication points, 524288-bit multiplication is about 1.15x faster than GMP, while 262144-bit and 1048576-bit points are slower. Add and division remain substantially slower than GMP.

Decimal ingress changes much more dramatically because 1.3.105 performed a Rank-N Fourier multiply for each decimal digit. For a diagnostic fp4096 multiply with two roughly 900-digit decimal inputs, whole-process median wall time changed from 102.55 ms to 0.407 ms, about 252x. This includes process startup/output and therefore measures removal of parser redundancy rather than the multiplication kernel alone.
