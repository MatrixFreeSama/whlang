# Testing 1.3.106

Current release authority contains 29 tests, all passing.

The current Rank-N gate is `test_rankn_physical_aging_13106.sh`. It proves:

1. The historical 30-bit precision wall remains absent and `fp1073741824` still compiles normally.
2. Rank-N multiplication executes with one type-level Physical Fact and no per-value geometry field or runtime Fourier planner.
3. Decimal ingress contains no per-digit call to Rank-N multiply/add and uses the single raw `D = 10D + digit` recurrence.
4. Production sources contain no old precision flag/mask, stored limb-count field, `RPF_GEOM`, runtime geometry planner, named-width backend, or second Rank-N backend.

An independent GMP integer oracle validates exact product rounding for 65, 73, 113, 127, 191, 257, 521, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, and 1048576 bits.
