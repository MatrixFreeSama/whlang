# Release Surface Convergence 1.3.106

The public language surface is unchanged. `fpP` remains the only parameterized floating syntax.

1.3.106 removes internal duplicate physical work rather than adding source controls. There is no user-facing Fourier selector, precision tier, multiplication mode, parser mode, scheduler directive, worker count, or compatibility switch.
