# Architecture Aging 1.3.106

Rank-N high precision retains one arithmetic authority:

`fpP -> TypePhysicalFact{P, Fourier geometry} -> compact ValueFacts -> one Rank-N arithmetic path -> one RNE authority`

Fourier geometry is a property of the type's physical realization, not of an individual numeric value. The previous path planned geometry at AOT time, stored it in a destination object, cleared it during object initialization, and could plan it again at runtime. 1.3.106 collapses those authorities into one AOT fact and deletes the runtime planner.

The remaining changes follow the same rule: move or derive a fact once, then reuse it. Same-P copy becomes a carrier clone; exponent shifts become one relocation; decimal source digits accumulate in one integer relation; destination initialization occurs only at final commit; normalized zero is read from its invariant top bit.

No precision tier selects an algorithm. Precision changes geometry and storage cardinality only. Existing division and Fourier realizations remain visible physical frontiers rather than spawning alternate backends.
