# Wheelchair 1.3.106 Release Notes

1.3.106 ages the existing Rank-N arithmetic path by deleting repeated physical work. It does not add a second high-precision algorithm family.

- Each interned `fpP` now owns one 16-byte type-level Physical Fact: u64 precision plus packed Fourier geometry. Geometry is planned once by AOT, not copied into every ValueFact.
- The runtime Fourier geometry planner and the per-value `RPF_GEOM` state are deleted. Multiplication consumes the type fact directly.
- Exponent alignment uses one word+bit relocation with sticky accumulation instead of repeating a full limb scan once per shifted bit.
- Same-precision copies are direct carrier clones. `abs`/`neg` no longer route through conversion; the former in-place `abs(x,x)` alias hazard is removed.
- Decimal ingress uses the integer recurrence `D = 10D + digit` and performs Rank-N normalization/division only after the decimal sequence is complete. Per-digit Fourier multiply/add is deleted.
- `from_u64` and `from_f64_bits` deposit a normalized source into at most two limbs rather than probing all 64 source bits.
- Add/mul/div no longer initialize the destination before the final RNE commit. Round, add, and division paths remove redundant clears and repeated cardinality work.
- Normalized zero classification is O(1); comparison no longer scans both significands merely to discover zero.
- Division removes redundant V/Q/Q64 clears and writes packed base-2^32 quotient words directly.

No schoolbook/Karatsuba/Toom threshold tree, named-width backend, workload matcher, JIT, kernel-offload surface, runtime scheduler, worker pool, or source-visible parallel mechanism is introduced.

The x87 Fourier re-anchor remains every 16 values. A trial at 256 reduced work but failed the independent exact GMP oracle at 32768 bits and was rejected rather than retained as a fast compatibility path.
