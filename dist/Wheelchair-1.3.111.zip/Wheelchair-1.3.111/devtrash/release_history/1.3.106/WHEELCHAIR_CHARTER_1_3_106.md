# Wheelchair Charter 1.3.106

Wheelchair remains a whole-program AOT, HPC- and simulation-first general-purpose language.

High precision follows the same project rule as ordinary execution: mathematical structure determines necessary work; Physical Reality determines realization; duplicate authorities and idle bookkeeping are removed rather than hidden behind tuning switches.

1.3.106 therefore improves Rank-N by aging one existing path. It does not become a high-precision DSL, a kernel-offload language, a runtime algorithm zoo, or a source-visible parallel language.
