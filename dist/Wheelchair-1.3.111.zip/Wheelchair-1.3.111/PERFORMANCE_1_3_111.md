# Performance 1.3.111

All ratios below compare the final 1.3.111 candidate with a freshly rebuilt 1.3.110 baseline on the same host. Ratios above 1.0 mean 1.3.111 is faster.

## Big/big Rank-N division, direct runtime authority

| Precision | 1.3.110 ns/op | 1.3.111 ns/op | Speedup |
|---:|---:|---:|---:|
| 4096 | 31,666 | 26,038 | 1.216x |
| 8192 | 116,150 | 86,608 | 1.341x |
| 16384 | 438,430 | 374,839 | 1.170x |
| 65536 | 6,922,180 | 5,362,712 | 1.291x |
| 131072 | 27,565,746 | 22,708,876 | 1.214x |
| 262144 | 110,921,347 | 90,652,538 | 1.224x |

The stable gain comes from compact u32 quotient/remainder digits plus reuse of the quotient high-water fact. No new division algorithm is selected.

## Advanced mathematics, whole-process median

Outputs were bit-identical to 1.3.110 for the measured programs.

| Precision | Function | Speedup |
|---:|---|---:|
| 4096 | sqrt | 1.095x |
| 4096 | exp | 1.030x |
| 4096 | log | 1.022x |
| 4096 | sin | 1.013x |
| 4096 | cos | 1.032x |
| 8192 | sqrt | 1.159x |
| 8192 | exp | 0.973x |
| 8192 | log | 0.992x |
| 8192 | sin | 1.077x |
| 8192 | cos | 0.977x |

The low-single-digit entries are treated as process/system noise rather than a universal speed claim. `sqrt` is the clearest downstream beneficiary because its Newton relation repeatedly uses big/big division.

## What is not claimed

1.3.111 does not claim a multiplication speedup. An exact P+GRS reconstruction experiment was removed because it regressed some large-precision multiplication measurements. The release favors a smaller set of proven improvements over retaining a theoretically attractive but physically weaker branch.
