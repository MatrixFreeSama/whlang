# Release Surface Convergence 1.3.111

1.3.111 changes no source-language syntax and introduces no compatibility spelling.

The user-visible P>64 contract remains `fpP` plus the existing PrecisionFact propagation semantics. The work in this release is entirely physical: compact division digits, reuse of a fact already produced by the quotient recurrence, and PrecisionFact-derived scratch geometry.

Field remains WHFLD217 with dynamic RankFact from 1.3.110. No WHFLD216 reader or fixed-rank compatibility path is restored.
