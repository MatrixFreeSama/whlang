# Wheelchair 1.3.126 Release Surface Convergence

The production surface remains the same eight executables. RegionSet support adds no user-visible syntax and no runtime backend family.

- Support cardinality is source-derived data, not a build/profile choice.
- One interval and empty support are degenerate RegionSets; no compatibility interval backend remains.
- Runtime generated support probes are cold direct AOT code; there is no interpreter or JIT.
- `build/` remains reproducible output and is excluded from the final release archive.
- Historical benchmark and release evidence remains under `devtrash/`.
