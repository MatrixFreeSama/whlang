# Wheelchair 1.3.126 Performance

Retained real Level-Set / VOF narrow-band source: a 1D slice through a closed interface has two physical crossings and therefore two disjoint compact-support bands. `n=8,000,000`; active support is about 0.1% of the domain. No artificial remap/depth chain is present.

## Pinned one CPU, 15 interleaved rounds

| implementation | median |
|---|---:|
| Wheelchair 1.3.126 | 0.939 ms |
| Wheelchair 1.3.125 | 7.236 ms |
| C natural serial | 10.717 ms |
| Fortran natural serial | 11.062 ms |
| C hand-bounded two-band ceiling | 1.381 ms |
| Fortran hand-bounded two-band ceiling | 1.716 ms |

The same Wheelchair source is **7.70x faster than 1.3.125**, **11.41x faster than natural C**, and **11.78x faster than natural Fortran** in this run. The hand-bounded controls use problem-specific analytic knowledge of the two interface bands; Wheelchair reaches 1.47x / 1.83x their whole-process throughput without such a workload route.

Strict checksum at `n=8,000,000` remains `0x4077ffffe6d58c8e`, exactly matching 1.3.125.

## Four available CPUs, 9 interleaved rounds

| implementation | median |
|---|---:|
| Wheelchair 1.3.126 | 0.911 ms |
| Wheelchair 1.3.125 | 7.204 ms |
| C natural OpenMP | 6.357 ms |
| Fortran natural OpenMP | 6.620 ms |

The surviving support is small enough that Physical Reality no longer needs to hide a full-domain scan with extra CPU width.

## Domain-size probe

The 1.3.125 path grows with total domain size; 1.3.126 stays near process/startup and support cost while strict results remain bit-identical:

| n | 1.3.126 | 1.3.125 |
|---:|---:|---:|
| 4M | 0.813 ms | 3.959 ms |
| 8M | 0.776 ms | 7.353 ms |
| 16M | 0.848 ms | 15.602 ms |

The measurements are host-noisy at the sub-2-ms scale, so the key result is the loss of `T proportional to n`, not small ordering differences among the three 1.3.126 points.
