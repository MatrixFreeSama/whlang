# Wheelchair 1.3.126 Pure Assembly Release Proof

The 1.3.126 production compiler/runtime remains handwritten GNU x86-64 assembly and native shell build glue. RegionSet analysis and discovery are implemented in the existing Tensor assembly authorities.

Production RegionSet invariants:

- `support_count_terms` derives Region cardinality from the ValueFact DAG;
- generated cold probe dispatch has source cardinality and no fixed region table;
- runtime interval storage is allocated from the patched source term count;
- sort/merge canonicalizes Regions in place;
- `support_range_class` feeds the existing reduction tree directly;
- no workload matcher, second Support IR, active-set manager, or JIT exists.
