# Wheelchair 1.3.126 Architecture Aging

## SupportFact becomes a RegionSet instead of an interval case

1.3.125 closed `PredicateFact -> SupportFact` for one contiguous support. 1.3.126 removes that cardinality assumption. Primitive zero-false basin leaves contribute Regions; ADD/SUB performs the conservative support union; runtime canonicalizes the source-derived set into sorted, disjoint `[lo,hi)` Regions.

There is no `SUPPORT_TWO_INTERVALS`, fixed Region array, or count-specific execution route. Region count is source data. Overlap and adjacency are merged in-place; execution ownership uses the sum of surviving disjoint canonical quanta.

## Reduction consumes RegionSet directly

The reduction tree no longer compares one `[lo,hi)` pair. Every canonical subtree is classified against the RegionSet as dead, dense, or partial. Dead subtrees become exact +0. Dense subtrees reuse the existing direct evaluator. Partial strict subtrees split at the existing q=1 mathematical boundary, so no new reduction order is introduced.

## Cold discovery remains the original semantics

Every primitive basin uses the same compiler-emitted IEEE predicate/basin witness introduced in 1.3.125. The runtime discovers each exact interval in logarithmic cold work, then sorts and merges. No analytic interface geometry, root formula, density estimate, or workload identity enters the compiler.

## Old interval state removed

The previous `g_support_chunk_lo/g_support_chunk_hi` runtime authority is deleted. Single support and empty support are now ordinary degenerate RegionSets, not parallel compatibility paths.
