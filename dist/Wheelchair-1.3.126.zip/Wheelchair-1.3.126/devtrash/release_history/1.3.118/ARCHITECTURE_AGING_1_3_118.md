# Architecture Aging 1.3.118

1.3.118 removes a structured-domain seam that existed despite the surrounding facts already being mature:

```text
Surface comparison/select
        -> Rank-N PredicateFact
        -> existing vector/scalar physical carrier
        -> typed f64 select ValueFact
        -> existing Field/Tensor Physical DAG
```

Before this release, General already owned FP PredicateFacts and Guarded Regions, while Field/Tensor already owned CoordinateFacts, integer equality masks, boundary regions, and vector mask machinery. A Field value such as `select(x[i] < 0, a, b)` nevertheless fell out of the structured physicalizer because FP relational PredicateFacts and f64 value selection were not in that closure.

The fix does not create a Field-specific boolean language. Comparison choice is one relation family, operand type selects only the physical compare realization, and all four structured physicalizers expose the same source semantics. Exact selection is a value relation over the existing predicate carrier.

The release intentionally stops before dynamic support-set compaction. Predicate truth over a Rank-N domain is now representable and executable, but the support set is not yet a sparse Physical Region whose false elements vanish. That later convergence must reuse PredicateFact/Region authority rather than become an `active_set` subsystem.
