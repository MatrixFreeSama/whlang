# Wheelchair 1.3.118 Release Notes

1.3.118 closes the missing Rank-N value-predicate relation instead of adding an active-set DSL or workload route.

- Structured FP `eq/ne/lt/le/gt/ge` now produce the same PredicateFact relation across scalar tails and AVX-512/native256 vector realization.
- `select(P, f64, f64)` is now a normal typed ValueFact relation in Field/Tensor code. It consumes the predicate carrier and preserves the exact true/false bit patterns through the existing vector bit relation.
- AVX-512, native256, derived, and derived-native256 physicalizers share the same semantic closure. No physicalizer-specific source language or second boolean IR is introduced.
- General PredicateFact, structured CoordinateFact, and SIMD predicate substrate are therefore joined at the value relation that was previously missing. The release does not invent `contact`, `gap`, `active_set`, or benchmark identities.
- Dynamic support-set compaction is deliberately not claimed. Inactive lanes are not yet removed from later Physical Regions; this release closes predicate/value-select expression authority only.

In the retained 100,000,000-element exact benchmark, the predicate-only direct case places Wheelchair near ordinary C scale (95.40 ms vs 90.08 ms on one CPU). Adding nonconforming CoordinateFact remaps moves the same predicate program to **159.55 ms vs 407.39 ms C / 422.86 ms Fortran**, or **2.553x / 2.650x** faster on one CPU. On four allowed CPUs the medians are **55.75 / 104.89 / 107.67 ms**, or **1.881x / 1.931x**. This is evidence of compositional structure value, not a claim that predicates alone are intrinsically faster.
