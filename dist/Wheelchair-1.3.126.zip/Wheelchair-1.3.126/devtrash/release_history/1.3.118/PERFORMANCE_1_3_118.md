# Performance 1.3.118

## Rank-N value-predicate closure

Strict 100,000,000-element Field benchmark, 12 interleaved rounds, exact checksums.

### Predicate only, direct coordinates

| CPUs | Wheelchair | GCC C | GFortran |
|---:|---:|---:|---:|
| 1 | **95.40 ms** | 90.08 ms | 106.37 ms |
| 4 | **38.10 ms** | 30.74 ms | 43.39 ms |

The new relation is not presented as a standalone speed trick: on one CPU Wheelchair is about 5.9% slower than C and 10.3% faster than Fortran.

### Predicate + nonconforming CoordinateFact remap

| CPUs | Wheelchair | GCC C | GFortran |
|---:|---:|---:|---:|
| 1 | **159.55 ms** | 407.39 ms | 422.86 ms |
| 4 | **55.75 ms** | 104.89 ms | 107.67 ms |

One CPU: **2.553x C / 2.650x Fortran**. Four CPUs: **1.881x / 1.931x**. Four-CPU median total CPU work is **159.01 ms** for Wheelchair versus **406.31 / 416.98 ms**.

About 3.1% of elements satisfy the predicate. 1.3.118 still evaluates both f64 select arms before exact-bit blending and does not compact the support set, so these numbers must not be interpreted as sparse active-set elimination.
