# Wheelchair Charter 1.3.118

Wheelchair remains an AOT, general-purpose, simulation/HPC-first language in which mathematical relations become Physical Reality without requiring source-visible parallel or domain-specific execution syntax.

A PredicateFact is a relation, not a scalar-only feature. Rank-N coordinates do not require a second boolean language: structured comparisons and value selection must consume the same semantic relation and differ only in their physical realization. Likewise, eventual sparse support must be a consequence of PredicateFact plus Region truth, not a named active-set subsystem.

Compile-time Fact richness should disappear into ISA relations whenever possible. Missing structured closure is repaired by extending the existing authority, not by compatibility routing or workload-specific branches.

No compatibility execution authority, contact DSL, active-set runtime, JIT, scheduler, worker pool, kernel-offload backend, or second Predicate IR is introduced.
