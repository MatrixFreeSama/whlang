# Testing 1.3.118

The release authority remains the 29 tests in `devtrash/release_tests/current.list`. The final version-switched release gate passed all **29/29** tests.

`test_tensor_fact_aging_13104.sh` now also proves Rank-N value-predicate closure across AVX-512, native256, derived, and derived-native256 physicalizers with the same strict source program and exact checksums at two domain sizes. It also asserts the shared FP PredicateFact comparison and relation vocabulary in each production structured physicalizer.

The retained benchmark is under `devtrash/benchmarks/rankn_predicate_13118/`. Production code contains no contact/active-set/Mandelbrot/mortar workload route.
