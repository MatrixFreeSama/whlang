# Release Surface Convergence 1.3.118

1.3.118 adds no source-visible parallel or active-set surface. Existing comparison and `select` syntax is admitted consistently when its values live over a Field/Tensor domain.

No contact primitive, active-set container, mask annotation, thread API, SIMD width directive, sparse-control DSL, JIT/offload selector, compatibility syntax, workload matcher, or second structured language is added.
