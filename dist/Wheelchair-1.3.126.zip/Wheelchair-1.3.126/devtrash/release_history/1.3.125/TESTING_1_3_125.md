# Wheelchair 1.3.125 Testing

The current release authority contains 35 tests and passes 35/35 when executed individually in the release work tree.

1.3.125 adds `test_supportfact_domain_contraction_13125.sh`. It checks:

- PredicateFact -> SupportFact -> execution-domain contraction authority exists;
- prefix and suffix monotone supports preserve exact strict results;
- a one-basin quadratic support preserves exact strict results;
- empty support closes to exact reduction identity;
- literal `sum 0.0` closes to exact reduction identity;
- no contact/Hertz/numeric benchmark matcher is present;
- no second active-set backend is introduced.

The previous ShapeFact, CoordinateFact, parallel-source, periodic-integer and periodic-affine gates all remain current and pass unchanged.
