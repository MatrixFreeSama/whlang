# Wheelchair 1.3.125 Release Notes

1.3.125 closes the missing edge from `PredicateFact` to execution support. A zero-false reduction whose predicate proves one contiguous axis support no longer scans the complete ShapeFact domain just to rediscover that most packets are empty. The compiler proves support topology AOT, emits the original basin/predicate only as one cold IEEE witness, and the runtime locates the exact discrete support boundaries in O(log N). Physical Region ownership is then repriced from surviving canonical leaves rather than dead exterior work.

Strict semantics remain authoritative. Boundary packets execute the original predicate unchanged. For strict reductions, partially intersected canonical subtrees are recursively split according to the existing q=1 reduction tree; only mathematically proven all-zero subtrees collapse to exact +0. Empty support, including a literal `sum 0.0`, terminates directly at the reduction identity. Tolerant reductions may clip directly to the support intersection.

There is no contact/Hertz primitive, active-set container, density threshold, support-size threshold, workload matcher, second reduction backend, JIT, scheduler, or source-visible sparse/parallel DSL. Unsupported predicate topology simply retains the existing full-domain realization.

The current release gate is 35/35 PASS.
