# Wheelchair 1.3.125 Charter

Wheelchair remains a general-purpose AOT language whose execution follows mathematical and physical facts rather than programmer-authored parallel or sparse schedules. 1.3.125 makes a predicate's proven zero exterior physically nonexistent without exposing an active-set DSL.

The release rejects contact-specific geometry, density thresholds, workload routes, compatibility evaluators and new scheduling surfaces. Existing facts are composed until only mathematically necessary regions retain execution ownership.
