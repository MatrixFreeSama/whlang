# Wheelchair 1.3.125 Architecture Aging

## Predicate facts finally contract execution space

Before 1.3.125, `select(P,F,+0)` could erase `F` for an empty AVX-512 packet, but ShapeFact `[0,n)` still owned the execution domain. Predicate information therefore reduced value work without reducing traversal work. 1.3.125 closes the existing fact chain:

`PredicateFact -> SupportFact -> RegionFact -> execution ownership -> reduction identity`.

The compiler proves only topology: constant, monotone, or one-basin relations that imply one contiguous true interval. It does not solve a workload geometry. Indexed CoordinateFacts are not guessed through.

## Exact boundaries remain the original semantics

Support topology is static, while runtime `n` may determine the exact discrete endpoints. One cold compiler-emitted witness evaluates the original IEEE basin and predicate. Binary search locates the discrete basin minimum and true interval in O(log N). This avoids analytic root formulas and their rounding seams. Boundary canonical leaves keep the original vector predicate, so support contraction never substitutes an approximate geometric boundary for source semantics.

## Strict reduction keeps its immutable tree

A strict full-domain reduction cannot merely start at the first active leaf because that would change addition order. The runtime therefore preserves the existing canonical q=1 tree: wholly dead subtrees become exact +0; partial subtrees recursively split at the same canonical boundary; dense surviving subtrees reuse the existing evaluator. Tolerant mode may clip directly.

## Physical ownership is repriced after erasure

Once dead exterior leaves disappear, outward materialization is repriced from active canonical quanta using the existing lifecycle-payback relation. Sparse support can therefore naturally reduce execution multiplicity without a density or size threshold.
