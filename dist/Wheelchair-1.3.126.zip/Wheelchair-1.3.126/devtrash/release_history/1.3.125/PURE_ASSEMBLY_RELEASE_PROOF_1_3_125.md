# Wheelchair 1.3.125 Pure Assembly Release Proof

The repair remains entirely in the existing handwritten assembly compiler/runtime. `PredicateFact`, `SupportFact`, `RegionFact`, execution ownership and reduction identity remain one AOT fact chain. The cold support witness is emitted by the existing tensor machine emitter and calls no C/C++ runtime.

No analytic contact routine, active-set library, generated compatibility frontend, JIT, workload matcher, second reduction engine, or source-level scheduling/sparsity surface is introduced. Final production binaries are rebuilt from a release staging tree with no pre-existing `build/` directory.
