# Wheelchair 1.3.125 Release Surface Convergence

1.3.125 adds no source syntax, support keyword, active-set object, runtime user mode, scheduler, JIT interface, contact primitive, benchmark selector, or compatibility evaluator. The repair closes existing semantic and physical facts below the source surface.

Historical evidence remains under `devtrash/`; canonical production executables remain under `bin/`. The generated `build/` tree is not release payload and is removed after clean staging verification.
