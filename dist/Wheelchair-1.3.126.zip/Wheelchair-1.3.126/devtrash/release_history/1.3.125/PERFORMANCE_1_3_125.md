# Wheelchair 1.3.125 Performance

Real narrow-phase penalty contact, `n=8,000,000`. A rigid cylindrical profile presses a discrete line. Only about 4473 candidate points are actually in contact; the useful physics is a thin gap/penalty update. No artificial remap or source-depth chain is present.

## Pinned one CPU

Eleven interleaved rounds. C/Fortran controls here are compiled `-O3 -march=native` without OpenMP linkage.

| implementation | median |
|---|---:|
| Wheelchair 1.3.125 | 0.886 ms |
| Wheelchair 1.3.124 | 6.638 ms |
| C natural serial | 8.842 ms |
| Fortran natural serial | 7.819 ms |
| C hand-bounded support | 1.344 ms |
| Fortran hand-bounded support | 1.753 ms |

Against 1.3.124 the same Wheelchair source is **7.49x faster**. It is **9.98x faster than natural serial C** and **8.82x faster than natural serial Fortran**. The hand-bounded C/Fortran programs use problem-specific analytic support geometry; Wheelchair reaches 1.52x / 1.98x their whole-process throughput without such a workload-specific route.

The 1.3.124 and 1.3.125 Wheelchair executables produce identical strict checksum `0x410232798d10f51c` at `n=8,000,000`.

## Four available CPUs

Seven interleaved rounds:

| implementation | median |
|---|---:|
| Wheelchair 1.3.125 | 0.858 ms |
| Wheelchair 1.3.124 | 2.340 ms |
| C natural OpenMP | 3.406 ms |
| Fortran natural OpenMP | 3.780 ms |
| C hand-bounded support OpenMP | 1.576 ms |
| Fortran hand-bounded support OpenMP | 1.893 ms |

After support contraction, Physical Reality reprices the much smaller surviving work instead of blindly preserving full-domain execution multiplicity. 1.3.125 is 2.73x faster than 1.3.124 in this four-CPU invocation.
