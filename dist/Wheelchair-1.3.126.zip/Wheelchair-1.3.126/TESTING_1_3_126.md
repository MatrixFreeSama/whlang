# Wheelchair 1.3.126 Testing

Current release authority: **36/36 PASS**.

The new RegionSet gate verifies:

- ADD/SUB support-union closure;
- source-derived RegionSet cardinality with no fixed count class;
- order-independent interval sorting;
- overlap/adjacency canonicalization;
- strict reduction zero-subtree erasure;
- exact checksums for the retained two-interface source at 4M, 8M and 16M;
- absence of Level-Set, narrow-band, two-region, or fixed-capacity production matchers.

The full current gate also retains all earlier human-shell, ShapeFact, CoordinateFact, Physical DAG, periodic exact, periodic-affine aging, and single-Support regression tests.
