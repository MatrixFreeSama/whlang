# Wheelchair 1.3.126 Release Notes

1.3.126 removes the single-interval assumption from Tensor SupportFact. A reduction may now derive a source-sized RegionSet from additive/subtractive zero-false support leaves. Each primitive basin still uses the original IEEE predicate as the exact cold boundary witness; runtime sorts and merges the resulting intervals into one canonical disjoint RegionSet, then reduction ownership and outward execution are priced from the sum of surviving canonical quanta.

The change is algebraic, not workload-specific. `supp(a +/- b)` is conservatively represented by `supp(a) union supp(b)`; overlap and adjacency are canonicalized. There is no two-region mode, region-count threshold, Level-Set primitive, VOF primitive, narrow-band matcher, active-set cache, second reduction backend, or source-visible sparse/parallel DSL.

Strict reduction order remains authoritative. The canonical q=1 tree is traversed against the RegionSet: wholly dead subtrees become exact +0, wholly live subtrees reuse the dense evaluator, and partial subtrees split only at canonical reduction boundaries. The existing single-basin and empty-support paths are therefore degenerate RegionSets rather than compatibility backends.

The retained real Level-Set / VOF two-interface benchmark changes from full-domain scaling to approximately support-size scaling while preserving the exact 1.3.125 strict checksum at 4M, 8M and 16M domains.

The current release gate is 36/36 PASS.
