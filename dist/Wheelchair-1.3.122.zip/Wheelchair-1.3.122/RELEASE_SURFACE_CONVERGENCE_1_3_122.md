# Wheelchair 1.3.122 Release Surface Convergence

The release surface distinguishes three things cleanly:

1. production source authorities (`compiler/`, `runtime/`, `surface/`, `tools/`),
2. canonical built commands (`bin/`),
3. historical evidence (`devtrash/`).

The generated `build/` directory is intentionally absent from the packaged release because `build.sh` deletes and recreates it. Shipping it duplicated binaries and intermediates already derivable from the source tree and `bin/`.

Historical experiments are not content-deduplicated merely because hashes match. Their directory placement is part of the project history. Only zero-information current production duplication is removed.
