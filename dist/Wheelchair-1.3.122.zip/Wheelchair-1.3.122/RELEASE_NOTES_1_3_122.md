# Wheelchair 1.3.122 Release Notes

1.3.122 removes parallel assembly source authorities without changing the produced machine code. Tensor's AVX-512/native256 and base/derived entry surfaces now consume one ISA/profile-independent common authority plus one compile-time physical-profile authority. Field runtime similarly shares only proof-neutral bodies; frontier, reduction, and other proof-bearing architectural anchors remain explicit rather than being hidden behind an abstraction layer.

The duplicate `runtime/field_runtime.ld` is removed and both Field and Tensor use the same runtime linker authority. Generated `build/` products are no longer part of the release package; `build.sh` recreates them from source. Historical `devtrash/` evidence is retained.

No runtime ISA/profile dispatcher, generated source clone, compatibility frontend, workload-specific route, scheduler, JIT, source-visible parallel primitive, or second Tensor IR/backend is introduced.

All eight production binaries are byte-identical to the pristine 1.3.121 build. The change therefore has zero intended runtime/codegen effect and strictly reduces parallel source maintenance.
