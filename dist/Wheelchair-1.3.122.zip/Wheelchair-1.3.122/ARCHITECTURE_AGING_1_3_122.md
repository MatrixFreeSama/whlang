# Wheelchair 1.3.122 Architecture Aging

## One authority per fact

The four historical Tensor frontend bodies had converged semantically but still duplicated large sections of parser, affine/CoordinateFact, code-emission, and physical bookkeeping assembly. 1.3.122 moves truly identical bodies into assembler-time common authorities and truly profile-shared physical bodies into one compile-time profile authority. Entry files retain labels and differences, not copies of identical logic.

Field runtime applies the same aging rule only where the body is proof-neutral. Architectural proof anchors such as frontier/reduction remain physically visible in each runtime surface. This deliberately avoids replacing obvious duplication with a new opaque compatibility layer.

## No new runtime branch

The common authorities are `.include`/macro-time source authorities. They do not create runtime ISA selection, virtual dispatch, a new IR, a generated-source stage, or a workload matcher. Final production binaries remain exactly identical to 1.3.121.

## Removed duplicate surfaces

- Duplicate Field runtime linker script: removed.
- Parallel Tensor body copies: collapsed into common/profile authorities.
- Proof-neutral AVX2/AVX-512 Field runtime body copies: collapsed into one authority.
- Generated `build/` tree: excluded from the release artifact; it remains reproducible output, not source authority.

Historical experiments remain in `devtrash/` because their paths and chronology carry information even when some inputs are byte-identical.
