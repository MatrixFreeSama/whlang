# Pure Assembly Release Proof 1.3.115

The production compiler/runtime remains handwritten x86-64 assembly with GNU-binutils AOT output.

General FP unary/minmax closure, integer bit/minmax closure, BOOL xor, ConstantFact sign-mask realization, and their carrier-pressure decisions live in `compiler/general_frontend_x86_64.S` and reuse the existing Physical-DAG authorities.

No C/LLVM/MLIR/JIT production backend, local generic-island compatibility backend, runtime scheduler, worker pool, kernel-offload backend, benchmark runtime, or source-visible parallel DSL is added.
