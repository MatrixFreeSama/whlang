# Performance 1.3.115

## General scalar operator closure

Fixed CPU, interleaved A/B measurements:

| diagnostic | Wheelchair 1.3.114 | Wheelchair 1.3.115 | 1.3.115 speedup |
|---|---:|---:|---:|
| `abs(f64)` recurrence | 74.54 ms | **35.30 ms** | **2.112x** |
| FP `min/max` recurrence | 158.03 ms | **46.60 ms** | **3.391x** |
| INT `min/max` recurrence | 74.99 ms | **29.59 ms** | **2.535x** |
| `select + neg` scalar | 226.21 ms | **89.16 ms** | **2.537x** |

The same `select + neg` C control is **60.24 ms**, so the current Wheelchair gap is **1.480x**, down from the generic-fallback regime near 3.8x.

The sign-mask realization itself is visible in generated code as `vxorps`/`vandps` over a resident ConstantFact rather than an XMM->GPR sign-bit round trip.

Strict scalar Mandelbrot is a control for unrelated effects: retained A/B median is 352.47 ms in 1.3.114 and 351.58 ms in 1.3.115 with identical checksum `0x00000000032e223d`. 1.3.115 makes no Mandelbrot speedup claim.
