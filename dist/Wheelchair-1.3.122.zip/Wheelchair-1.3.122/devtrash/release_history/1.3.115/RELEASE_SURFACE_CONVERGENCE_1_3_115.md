# Release Surface Convergence 1.3.115

1.3.115 adds no source surface. Existing scalar operators simply converge into the same Physical-DAG realization already used by mature arithmetic.

No compatibility syntax, physicalization annotation, benchmark switch, SIMD directive, parallel directive, JIT/offload selector, operator-cache option, or workload-specific knob is added.
