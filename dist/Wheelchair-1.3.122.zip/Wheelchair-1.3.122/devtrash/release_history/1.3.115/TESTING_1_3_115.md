# Testing 1.3.115

The current release authority remains the 29 tests in `devtrash/release_tests/current.list`. The final 1.3.115 release log records **29/29 PASS**.

Additional A/B checks:

- `abs(f64)`, FP `min/max`, and INT `min/max` retain bit-identical 1.3.114 outputs while moving into the native Physical DAG;
- the `select + neg` probe retains identical output while removing generic stack/state fallback;
- its generated hot loop contains resident XMM sign-mask realization (`vxorps`) rather than XMM->GPR sign-bit round trips;
- strict Mandelbrot retains checksum `0x00000000032e223d` and remains performance-neutral within run noise;
- four concurrent non-affine mutable iterate episodes remain bit-exact across 20/20 repetitions;
- release proof no longer treats forced R15 state traffic as an invariant when StateFacts are proven resident;
- added production compiler lines contain no Mandelbrot/fractal/pixel/probe workload identity.
