# Wheelchair 1.3.115 Release Notes

1.3.115 closes another General scalar Physical-DAG maturity gap. A basic pure ValueFact transformation may no longer eject a whole recurrence merely because the native emitter had not yet learned that operator.

- FP `neg`, `abs`, `min`, `max`, and same-domain scalar casts now remain in the existing Physical-DAG emitter.
- FP sign transformations use ordinary ConstantFact residency for sign masks. With a resident mask, negation/absolute value collapse to one XMM bitwise operation; pressure fallback stays inside the same Physical DAG rather than entering the generic evaluator.
- Integer `bit_not`, `bit_and`, `bit_or`, `bit_xor`, signed/unsigned `min/max`, and representation-preserving integer casts now use the existing GPR carrier authority.
- Integer `neg/abs` enter the native relation only where the declared wrap contract makes the operation total. Trap-visible cases remain proof-gated rather than being silently weakened.
- BOOL `xor` joins the existing Physical boolean relation.
- Dynamic shifts and other operations with language-visible failure conditions are not blindly admitted merely to enlarge benchmark coverage.
- The mutable-StateFact regression proof no longer requires redundant frame load/store traffic when all live StateFacts are proven resident. Execution-local frame authority and deterministic concurrent semantics remain required.
- No workload recognizer, benchmark dispatch, JIT, runtime scheduler, kernel-offload route, source-visible parallel DSL, or second scalar backend is added.

Pinned interleaved diagnostics versus 1.3.114: `abs(f64)` improves 2.112x, FP `min/max` 3.391x, INT `min/max` 2.535x, and the formerly generic `select + neg` scalar probe improves 2.537x. Against the same C probe it contracts from 3.755x slower to 1.480x slower. Strict Mandelbrot remains essentially neutral, confirming that the release is operator-closure aging rather than a Mandelbrot route.
