# Architecture Aging 1.3.115

The scalar semantic vocabulary and the Physical-DAG operator vocabulary converge further:

```text
Semantic ValueFact
      -> one Physical DAG
      -> carrier / immediate / ConstantFact realization
      -> minimum necessary ISA
```

A missing basic emitter operation is not repaired with a local generic island or compatibility bridge. That would force carrier spills, rebuild Fact identity across two evaluators, and preserve the very transport the compiler is meant to remove. Instead, pure transformations age into the same Physical relation already carrying their operands.

FP sign transforms demonstrate the rule directly. Their masks are not a private optimization table: they are ordinary ConstantFacts selected by the same whole-episode carrier pressure authority used by other scalar constants. Integer bit relations and min/max similarly reuse the existing GPR carrier authority.

Operations whose semantics include a visible failure edge remain proof-gated. Physical closure must preserve the declared semantics rather than redefine them for a benchmark.
