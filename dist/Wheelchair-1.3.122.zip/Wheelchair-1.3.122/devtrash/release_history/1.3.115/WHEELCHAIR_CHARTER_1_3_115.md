# Wheelchair Charter 1.3.115

Wheelchair remains an AOT, general-purpose, simulation/HPC-first language whose execution is derived from mathematical structure, causal facts and physical reality rather than a source-visible parallel programming model.

Semantic information may be rich at compile time, but it is not entitled to survive as runtime transport. A basic ValueFact transformation should age into the same Physical DAG until the generated machine work approaches the mathematical-physical minimum.

Compatibility is not preserved when it requires duplicate execution authorities. Missing Physical closure is repaired by extending the existing authority, not by introducing a second evaluator, workload route, DSL surface, or benchmark-specialized backend.
