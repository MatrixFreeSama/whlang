# Wheelchair 1.3.108 Release Notes

1.3.108 ages the existing high-precision advanced-function local propagation into the same Rank-N authority instead of adding function-specific fast paths.

- `exp`, `log`, and the shared `sin/cos` relation keep exact series denominators as u64 facts and consume one `rankn_fp_div_u64` quotient relation. They no longer materialize a full fpP denominator merely to invoke the general big/big Knuth divider.
- Advanced propagation convergence uses one `rpf_value_equal` authority because the only question is whether the current P-bit ValueFact changed; full numerical ordering is not performed for that predicate.
- `sqrt` keeps its true big/big Newton quotient and therefore receives no fake scalar shortcut.
- The fpP constant/cast compiler regression is repaired by giving binding kind stable stack-local lifetime across inference/type physicalization. The old caller-saved `r11d` lifetime is gone.
- Division zero identities are owned by the shared arithmetic relations. Exact zero numerators close directly; zero divisors remain rejection. This removes historical crash behavior for identities such as `log(1)` without adding transcendental special-case branches.
- The existing LocalExactCarrier add/sub path and single StrictClose/RNE authority remain unchanged.

No named-width transcendental backend, precision selector, algorithm threshold tree, JIT, kernel-offload surface, scheduler, worker pool, workload route, or source-visible parallel mechanism is added.
