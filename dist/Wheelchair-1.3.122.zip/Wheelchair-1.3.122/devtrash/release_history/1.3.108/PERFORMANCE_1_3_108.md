# Performance 1.3.108

The final A/B uses an unmodified 1.3.107 build and the final 1.3.108 candidate on the same host. Each published point is the median of seven whole-process runs after one warmup, using identical argv ingress/output paths. Small widths are intentionally not used for claims because process noise is a material fraction of runtime.

| P bits | sqrt | exp | log | sin | cos |
|---:|---:|---:|---:|---:|---:|
| 4096 | 0.85x | **3.39x** | **3.40x** | **5.27x** | **5.66x** |
| 8192 | 0.92x | **4.08x** | **4.81x** | **9.74x** | **11.32x** |

`sqrt` is a control: its dominant Newton step is a genuine Rank-N / Rank-N quotient and does not use the scalar-series relation introduced here. The larger gains in `sin/cos` follow directly from removing four full fpP denominator constructions/general divisions per propagation step; `exp/log` remove one each.

This release does not claim to beat MPFR. It removes avoidable Wheelchair work while retaining the existing mathematical relation. Representative MPFR RNDN probes at P=1024,4096,8192 produce exactly the same Wheelchair outputs as 1.3.107 at the tested points.

Raw data is retained in `devtrash/benchmarks/rankn_math_local_propagation_13108/`.
