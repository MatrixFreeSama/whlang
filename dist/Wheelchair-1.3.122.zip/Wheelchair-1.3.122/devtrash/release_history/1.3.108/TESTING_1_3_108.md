# Testing 1.3.108

The current release authority remains 29 tests. The 1.3.107 Rank-N Local-Strict aging gate is replaced, not stacked, by `test_rankn_math_local_propagation_13108.sh`; the test-closure authority is advanced to 1.3.108.

The new gate covers:

- fpP constant/cast materialization through the repaired declaration-kind lifetime;
- structural use of the single scalar quotient and ValueFact-silence authorities;
- established 65/127/521-bit advanced-function numerical anchors;
- shared zero identities `sqrt(0)`, `exp(0)`, `log(1)`, `sin(0)`, `cos(0)`;
- deterministic negative/domain rejection;
- absence of named-width transcendental routes, selectors, local-float dialects, JIT/offload routes, and second math backends.

Independent MPFR RNDN representative probes at 1024/4096/8192 bits confirm that the candidate is bit-identical to 1.3.107 at the sampled nonzero points. The current 29 release gates pass in full.
