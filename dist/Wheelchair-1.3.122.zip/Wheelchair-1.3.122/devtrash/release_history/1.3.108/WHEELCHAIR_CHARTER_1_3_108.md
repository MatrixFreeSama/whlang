# Wheelchair Charter 1.3.108

1. Mathematical semantics remain strict; physical representation and evaluation may be lazy only while no information is lost.
2. A local fact stays local. Do not inflate a scalar relation into a Rank-N ValueFact without mathematical necessity.
3. One relation has one authority. Remove redundant planners, comparators, conversion episodes and compatibility paths instead of adding selectors.
4. Precision is a fact, never a named-width backend choice.
5. Parallelism is a consequence of the Physical DAG and causal depth, not a source-language execution feature.
6. No JIT, hot-kernel DSL, worker-pool scheduler, workload matcher, or benchmark-specific route may substitute for whole-program AOT physical realization.
