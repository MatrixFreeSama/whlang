# Architecture Aging 1.3.108

The release removes two accidental expansions of local facts.

First, a binding kind is compiler control state, not a value that may survive arbitrary type-physicalization calls in a caller-saved register. It now has one stable local lifetime in `compile_general_source`.

Second, an integer series index is an integer fact. Advanced Rank-N mathematics no longer turns that scalar into a complete fpP ValueFact and then invokes general big/big division. One scalar quotient relation consumes the local integer directly and enters the existing strict RNE closure.

Representation silence is also one relation: equality of the complete current P-bit ValueFact. `sqrt`, `exp`, `log`, and `sincos` reuse that predicate rather than using full numeric comparison merely to ask whether propagation changed anything.

The architecture therefore converges rather than branches: one Rank-N type/precision authority, one strict closure, one scalar quotient relation, one ValueFact-silence predicate, and the existing per-function mathematical relations. No second transcendental backend or source-visible local mode exists.
