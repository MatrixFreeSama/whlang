# Release Surface Convergence 1.3.108

Current release tests remain 29. The 1.3.107 Rank-N aging entry is superseded by the 1.3.108 mathematical local-propagation authority rather than retained as another current branch.

The source language surface is unchanged. There is no `localfp`, transcendental precision mode, function-specific backend selector, or parallel DSL surface. `fpP` continues to denote precision; local integer coefficients and convergence predicates are internal Physical Reality facts only.

Root release material names only 1.3.108. The 1.3.107 root authority is retained under `devtrash/release_history/1.3.107/`.
