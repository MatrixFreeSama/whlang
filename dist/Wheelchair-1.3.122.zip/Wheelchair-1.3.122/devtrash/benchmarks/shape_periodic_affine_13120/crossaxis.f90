program crossaxis_f
  use iso_fortran_env, only: int64, real64
  use omp_lib
  implicit none
  integer(int64) :: n,b,i,b2,i2,ibits
  real(real64) :: sum,local
  character(len=64) :: arg
  n=1000000_int64
  if(command_argument_count()>=1) then
    call get_command_argument(1,arg); read(arg,*) n
  end if
  sum=0.0_real64
!$omp parallel do default(none) shared(n) private(b,i,b2,i2,local) reduction(+:sum) schedule(static)
  do b=0_int64,n-1_int64
    local=0.0_real64
    do i=0_int64,126_int64
      b2=mod(b*97_int64+i*13_int64+17_int64,n)
      i2=mod(i*37_int64+b*7_int64+11_int64,127_int64)
      local=local+real(mod(b2*31_int64+i2*17_int64+5_int64,4096_int64),real64)
    end do
    sum=sum+local
  end do
!$omp end parallel do
  ibits=transfer(sum,ibits)
  write(*,'("checksum_bits=0x",Z16.16)') ibits
end program
