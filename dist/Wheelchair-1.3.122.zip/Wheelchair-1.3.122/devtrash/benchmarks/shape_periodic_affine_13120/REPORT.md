# ShapeFact-N Periodic Affine Benchmark — Wheelchair 1.3.120

This benchmark is deliberately low-arithmetic and structurally dense. A dynamic high axis and a static mixed-radix axis are both remapped by affine periodic coordinates. 1.3.119 rejects this source; 1.3.120 closes the existing ShapeFact-N / CoordinateFact / physical-product ring so it compiles through the same structural tensor backend. No rank-2, radix-127, benchmark-name, DSL, scalar fallback, or second coordinate backend is present.

Machine: release validation container, GCC/GFortran 14.2, `-O3 -march=native -fopenmp`, n=1,000,000, five interleaved rounds, median wall time.

| Implementation | 1 CPU | 4 CPU |
|---|---:|---:|
| Wheelchair 1.3.120 | 275.990 ms | 72.337 ms |
| C literal structure | 265.415 ms | 72.784 ms |
| Fortran literal structure | 278.999 ms | 71.851 ms |
| C hand recurrence ceiling | 198.240 ms | 82.344 ms |
| Fortran hand recurrence ceiling | 246.708 ms | 73.153 ms |

All five implementations produce identical checksum bits `0x424e4587caf00000`. The Wheelchair output contains no `div`/`idiv`. The result is intentionally not presented as a speedup claim: the missing semantic closure is fixed, while hand-written dynamic cross-axis recurrence remains a physical-aging opportunity. That recurrence is not specialized into 1.3.120 merely to win this benchmark.
