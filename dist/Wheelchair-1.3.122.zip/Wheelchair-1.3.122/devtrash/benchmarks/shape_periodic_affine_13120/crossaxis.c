#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
static inline uint64_t bits(double x){ uint64_t u; memcpy(&u,&x,8); return u; }
int main(int argc,char**argv){
  uint64_t n=argc>1?strtoull(argv[1],0,10):1000000ULL;
  double sum=0.0;
  #pragma omp parallel for reduction(+:sum) schedule(static)
  for(uint64_t b=0;b<n;b++){
    double local=0.0;
    for(uint64_t i=0;i<127;i++){
      uint64_t b2=(b*97ULL+i*13ULL+17ULL)%n;
      uint64_t i2=(i*37ULL+b*7ULL+11ULL)%127ULL;
      local += (double)((b2*31ULL+i2*17ULL+5ULL)%4096ULL);
    }
    sum += local;
  }
  printf("checksum_bits=0x%016llx\n",(unsigned long long)bits(sum));
}
