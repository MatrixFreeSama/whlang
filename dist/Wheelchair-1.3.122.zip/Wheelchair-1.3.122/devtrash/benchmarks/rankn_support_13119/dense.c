#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static inline double xa(uint64_t i){ return -1.0 + (double)((i*37ull+11ull)%4096ull)/2048.0; }
static inline double xb(uint64_t i){ return -1.0 + (double)((i*53ull+19ull)%4096ull)/2048.0; }
int main(int argc,char**argv){uint64_t n=argc>1?strtoull(argv[1],0,10):10000; double s=0; unsigned long long a=0; for(uint64_t i=0;i<n;i++){double g=xa(i)-xb(i); double v=0; if(g<0){v=-0.75*g;a++;} s+=v;} uint64_t u; memcpy(&u,&s,8); printf("checksum_bits=0x%016llx active=%llu\n",(unsigned long long)u,a);}
