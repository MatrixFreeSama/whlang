# Rank-N Predicate Support Benchmark — Wheelchair 1.3.119

This benchmark retains the 1.3.118 Rank-N value-predicate program and measures the 1.3.119 Physical-DAG aging step: a floating PredicateFact may remain native AVX-512 mask authority, and an exact `+0.0` false support may become an empty guarded packet Region. There is no contact/workload matcher, density threshold, active-set DSL, worker queue, or second tensor IR. Native256 keeps the same source semantics through its existing exact-bit value relation instead of emulating AVX-512 support machinery.

The sparse direct/remap programs have about 3.1% active elements. 1.3.119 does **not** claim cross-packet active-set compaction: mixed packets still execute the true relation for the packet and mask inactive lanes. Only a fully empty packet makes the true Region not exist at runtime.

## Strict 100,000,000-element medians (12 interleaved rounds)

| Scenario | CPUs | 1.3.118 | 1.3.119 | C | Fortran | 1.3.118→1.3.119 | 1.3.119 vs C |
|---|---:|---:|---:|---:|---:|---:|---:|
| direct predicate | 1 | 96.663 ms | **74.200 ms** | 91.041 ms | 106.206 ms | **1.303×** | **1.227× faster** |
| direct predicate | 4 | 43.297 ms | **35.928 ms** | 27.160 ms | 31.627 ms | **1.205×** | 0.756× |
| predicate + nonconforming remap | 1 | 156.509 ms | **127.177 ms** | 400.431 ms | 399.939 ms | **1.231×** | **3.149× faster** |
| predicate + nonconforming remap | 4 | 58.338 ms | **45.367 ms** | 131.463 ms | 115.864 ms | **1.286×** | **2.898× faster** |

Checksums are bit-identical across old/new/C/Fortran in every retained round. Four-core Wheelchair uses fewer effective CPUs than C/Fortran, so this table is not a claim of superior executor saturation.

## Density regression

A separate one-CPU 9-round check prevents the support realization from becoming a sparse-only branch:

| Predicate density probe | 1.3.118 | 1.3.119 | C | 1.3.118→1.3.119 |
|---|---:|---:|---:|---:|
| ≈50% active | 95.047 ms | **81.213 ms** | 93.346 ms | **1.170×** |
| 100% active | 94.555 ms | **87.556 ms** | 89.188 ms | **1.080×** |

The dense improvement comes from removing PredicateFact mask/value round-trips. Empty-support skipping is an additional consequence when the mask is zero.

## Generated AVX-512 shape

The guarded zero-support path converges to the control relation directly:

```asm
vcmpltpd  k1, ...
kortestw  k1, k1
je         empty_support
... true relation ...
vmovapd    zmm0{k1}{z}, zmm0
...
empty_support:
vpxorq     zmm0, zmm0, zmm0
```

This replaces the older predicate route that materialized a qword mask vector and later reconstructed a k-mask. Cross-packet `vpcompress*` compaction is deliberately absent.
