# Rank-N physical aging 1.3.111

This directory keeps the final measurement tables used by the 1.3.111 release notes.

- `big_div_110_vs_111.csv`: direct `rankn_fp_div` authority, freshly built 1.3.110 vs final 1.3.111, interleaved repeated measurements, median ns/op.
- `advanced_math_110_vs_111.csv`: whole-process fp4096/fp8192 sqrt/exp/log/sin/cos comparison; corresponding outputs were bit-identical before timing.

Temporary harness binaries and rejected implementation experiments are intentionally not part of the release tree.
