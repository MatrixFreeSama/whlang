#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _OPENMP
#include <omp.h>
#endif
static inline double xa(uint64_t i){ return -1.0 + (double)((i*37ull+11ull)%4096ull)/2048.0; }
static inline double xb(uint64_t i){ return -1.0 + (double)((i*53ull+19ull)%4096ull)/2048.0; }
int main(int argc,char**argv){
 uint64_t n=argc>1?strtoull(argv[1],0,10):10000;
 double sum=0.0; unsigned long long active=0;
 #pragma omp parallel for schedule(static) reduction(+:sum,active)
 for(uint64_t i=0;i<n;i++){
 #ifdef REMAP
   uint64_t ia=(i*97ull+17ull)%n, ib=(i*193ull+31ull)%n;
 #else
   uint64_t ia=i, ib=i;
 #endif
   double gap=1.5 + xa(ia) - xb(ib);
   double impulse=0.0;
   if(gap<0.0){ impulse=-0.75*gap; active++; }
   sum += impulse;
 }
 uint64_t u; memcpy(&u,&sum,8);
 printf("checksum_bits=0x%016llx active=%llu\n",(unsigned long long)u,active);
 return 0;
}
