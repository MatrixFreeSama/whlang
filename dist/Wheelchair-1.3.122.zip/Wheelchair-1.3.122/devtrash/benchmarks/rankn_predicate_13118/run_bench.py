import subprocess, time, resource, csv, os, re, statistics
from pathlib import Path
base=Path('/mnt/data/active_contact_118')
n='100000000'
rounds=12
rows=[]
orders=[['wh','c','f'],['c','f','wh'],['f','wh','c'],['wh','f','c'],['c','wh','f'],['f','c','wh']]
for scenario in ['direct','remap']:
  for cores in [1,4]:
    cpus='0' if cores==1 else '0-3'
    exes={k:str(base/f'{scenario}_{k}') for k in ['wh','c','f']}
    for r in range(rounds):
      for impl in orders[r%len(orders)]:
        env=os.environ.copy()
        env['OMP_NUM_THREADS']=str(cores)
        env['OMP_PROC_BIND']='true'; env['OMP_PLACES']='cores'
        cmd=['taskset','-c',cpus,exes[impl],n]
        ru0=resource.getrusage(resource.RUSAGE_CHILDREN)
        t0=time.perf_counter_ns()
        p=subprocess.run(cmd,env=env,text=True,capture_output=True,check=True)
        t1=time.perf_counter_ns()
        ru1=resource.getrusage(resource.RUSAGE_CHILDREN)
        wall=(t1-t0)/1e6
        cpu=((ru1.ru_utime+ru1.ru_stime)-(ru0.ru_utime+ru0.ru_stime))*1000
        m=re.search(r'checksum_bits=0x([0-9A-Fa-f]+)',p.stdout)
        a=re.search(r'active=(\d+)',p.stdout)
        rows.append([scenario,cores,r,impl,wall,cpu,m.group(1).lower() if m else '',int(a.group(1)) if a else ''])
        print(scenario,cores,r,impl,f'{wall:.3f}',f'{cpu:.3f}',m.group(1) if m else '')
with open(base/'raw.csv','w',newline='') as f:
  w=csv.writer(f); w.writerow(['scenario','cores','round','impl','wall_ms','cpu_ms','checksum_hex','active']); w.writerows(rows)
summary=[]
for scenario in ['direct','remap']:
  for cores in [1,4]:
    sub=[x for x in rows if x[0]==scenario and x[1]==cores]
    meds={}
    for impl in ['wh','c','f']:
      xs=[x for x in sub if x[3]==impl]
      mw=statistics.median(x[4] for x in xs); mc=statistics.median(x[5] for x in xs)
      meds[impl]=(mw,mc)
    for impl in ['wh','c','f']:
      mw,mc=meds[impl]
      summary.append([scenario,cores,impl,mw,mc,mc/mw, mw/meds['wh'][0], meds[impl][0]/meds['wh'][0] if impl!='wh' else 1.0])
with open(base/'summary.csv','w',newline='') as f:
  w=csv.writer(f); w.writerow(['scenario','cores','impl','median_wall_ms','median_cpu_ms','effective_cores','wall_vs_wh','slower_than_wh']); w.writerows(summary)
print('SUMMARY')
for x in summary: print(x)
