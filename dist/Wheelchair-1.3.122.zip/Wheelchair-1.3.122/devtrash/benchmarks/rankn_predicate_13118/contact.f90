program contact
  use iso_fortran_env, only: int64, real64
  implicit none
  integer(int64) :: n, i, ia, ib, active, bits
  real(real64) :: s, gap, imp
  character(len=64) :: arg
  call get_command_argument(1,arg)
  if (len_trim(arg)==0) then
    n=10000_int64
  else
    read(arg,*) n
  endif
  s=0.0_real64; active=0_int64
!$omp parallel do default(none) shared(n) private(i,ia,ib,gap,imp) reduction(+:s,active) schedule(static)
  do i=0_int64,n-1_int64
#ifdef REMAP
    ia=mod(i*97_int64+17_int64,n)
    ib=mod(i*193_int64+31_int64,n)
#else
    ia=i; ib=i
#endif
    gap=1.5_real64 + xa(ia) - xb(ib)
    imp=0.0_real64
    if (gap < 0.0_real64) then
      imp=-0.75_real64*gap
      active=active+1_int64
    endif
    s=s+imp
  enddo
!$omp end parallel do
  bits=transfer(s,bits)
  write(*,'(A,Z16.16,A,I0)') 'checksum_bits=0x',bits,' active=',active
contains
  pure real(real64) function xa(j)
    integer(int64),intent(in)::j
    xa=-1.0_real64 + real(mod(j*37_int64+11_int64,4096_int64),real64)/2048.0_real64
  end function
  pure real(real64) function xb(j)
    integer(int64),intent(in)::j
    xb=-1.0_real64 + real(mod(j*53_int64+19_int64,4096_int64),real64)/2048.0_real64
  end function
end program
