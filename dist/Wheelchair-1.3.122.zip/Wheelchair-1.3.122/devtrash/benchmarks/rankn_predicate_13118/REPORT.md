# Rank-N PredicateFact benchmark — 1.3.118

This benchmark separates the newly closed Field/Tensor value-predicate relation from the already mature CoordinateFact path. All runs use `n=100000000`, strict FP semantics, 12 interleaved rounds, and bit-identical checksums across Wheelchair, GCC C, and GFortran.

The **direct** case contains a value-dependent predicate and f64 select but no irregular remap. It therefore measures the cost of the new Rank-N PredicateFact/value-select closure without giving Wheelchair a CoordinateFact advantage.

The **remap** case adds two runtime-domain nonconforming coordinate remaps before the same predicate. It measures composition of CoordinateFact and the new PredicateFact relation.

## Medians

| scenario | CPUs | implementation | wall ms | CPU ms | effective CPUs |
|---|---:|---|---:|---:|---:|
| direct | 1 | Wheelchair | 95.398 | 94.853 | 0.994 |
| direct | 1 | GCC C | 90.081 | 89.677 | 0.996 |
| direct | 1 | GFortran | 106.366 | 105.952 | 0.996 |
| direct | 4 | Wheelchair | 38.098 | 104.702 | 2.748 |
| direct | 4 | GCC C | 30.745 | 114.862 | 3.736 |
| direct | 4 | GFortran | 43.393 | 153.018 | 3.526 |
| remap | 1 | Wheelchair | 159.547 | 159.147 | 0.997 |
| remap | 1 | GCC C | 407.386 | 406.689 | 0.998 |
| remap | 1 | GFortran | 422.860 | 421.558 | 0.997 |
| remap | 4 | Wheelchair | 55.753 | 159.010 | 2.852 |
| remap | 4 | GCC C | 104.887 | 406.312 | 3.874 |
| remap | 4 | GFortran | 107.666 | 416.978 | 3.873 |

Direct PredicateFact-only performance is deliberately ordinary: Wheelchair is about 1.059x the C wall time on one CPU and 1.239x on four CPUs. This release therefore does not claim that a predicate by itself is an advantage.

With nonconforming remaps, Wheelchair is **2.553x faster than C / 2.650x faster than Fortran on one CPU**, and **1.881x / 1.931x** on four CPUs. Median total CPU work in the four-CPU remap case is 159.010 ms for Wheelchair versus 406.312 / 416.978 ms for C / Fortran.

The active fraction is about 3.1%. **1.3.118 does not yet compact the active support set.** Both f64 select arms are still vector-realized and exact-bit blended; the release closes the missing Rank-N predicate/value-select authority but does not claim that inactive elements cease to exist physically. There is no `vpcompress*` active-set backend, contact matcher, or source-visible sparse-control DSL.

Generated AVX-512 code contains `vcmpltpd`, `vpmovm2q`, and exact-bit `vpandq/vpandnq/vporq` selection in the retained Field path. The remap image retains zero scalar `div/idiv` in its generated segment.
