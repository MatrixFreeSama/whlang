# Rank-N mathematical local propagation benchmark, 1.3.108

The A/B baseline is an unmodified 1.3.107 build from the same host. Candidate executables are rebuilt from the final 1.3.108 source. Each row in `comparison.csv` is the median of seven whole-process runs after one warmup; inputs are sqrt(2), exp(1), log(2), sin(1), and cos(1). Whole-process timing intentionally includes the same argv ingress and output path on both sides.

At small P, process noise is a material fraction of runtime and is not used for release claims. The published performance summary uses P=4096 and P=8192, where the advanced relation dominates wall time.

`mpfr_ulp_probe.txt` records independent MPFR 6.x RNDN representative checks. Candidate and 1.3.107 baseline results are bit-identical at all listed nonzero points.
