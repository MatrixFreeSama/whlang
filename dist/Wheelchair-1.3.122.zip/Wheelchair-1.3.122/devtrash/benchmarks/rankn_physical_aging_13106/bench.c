#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <gmp.h>
extern int rankn_fp_add(void*,void*,void*,uint32_t);
extern int rankn_fp_mul(void*,void*,void*,uint32_t);
extern int rankn_fp_div(void*,void*,void*,uint32_t);
extern uint64_t bench_precision;
extern uint32_t bench_geometry;
#define TYPEID 103u
#define RPF_TYPE 0
#define RPF_GEOM 4
#define RPF_PREC 8
#define RPF_SIGN 16
#define RPF_EXP 24
#define RPF_DATA 32
static volatile uint64_t sink;
static double now_s(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void pin_one(void){cpu_set_t a,s;CPU_ZERO(&a);if(sched_getaffinity(0,sizeof(a),&a))return;int c=-1;for(int i=0;i<CPU_SETSIZE;i++)if(CPU_ISSET(i,&a)){c=i;break;}if(c<0)return;CPU_ZERO(&s);CPU_SET(c,&s);sched_setaffinity(0,sizeof(s),&s);}
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t span(unsigned p){uint64_t n=((uint64_t)p+63)/64; return (size_t)((512*n+4096+63)&~63ULL);}
static unsigned clog2u(uint64_t x){if(x<=1)return 0;return 64u-__builtin_clzll(x-1);}
static uint32_t choose_geom(unsigned p){
  uint64_t best=UINT64_MAX; uint32_t pack=0;
  for(int b=26;b>=1;b--){uint64_t n=((uint64_t)p+b-1)/(uint64_t)b,need=2*n-1,d=(1ULL<<b)-1,md2=d*d,b3=1;unsigned a3=0;
    while(b3<=2*need){uint64_t base=b3;unsigned a5=0;while(base<=2*need){uint64_t ratio=(need+base-1)/base;unsigned a2=clog2u(ratio);
      if(a2<=62&&base<=(UINT64_MAX>>a2)){uint64_t N=base<<a2;if(N>=need){unsigned L=clog2u(N);if(L){uint64_t lim=0x0007ffffffffffffULL/L;__uint128_t err=(__uint128_t)md2*n;if(err<lim){uint64_t w=100ULL*a2+120ULL*a3+180ULL*a5+10ULL*a3*a3+30ULL*a5*a5;__uint128_t cc=(__uint128_t)N*w+40ULL*n;if(cc<best){best=(uint64_t)cc;pack=(uint32_t)b|(a2<<8)|(a3<<16)|(a5<<24);}}}}}
      if(base>UINT64_MAX/5)break;base*=5;a5++;}if(b3>UINT64_MAX/3)break;b3*=3;a3++;}}return pack;}
static void init_obj(unsigned char*o,unsigned p,uint64_t seed){size_t z=span(p);memset(o,0,z);unsigned n=(p+63)/64;*(uint32_t*)(o+RPF_TYPE)=TYPEID;*(uint64_t*)(o+RPF_PREC)=p;*(uint64_t*)(o+RPF_SIGN)=0;*(int64_t*)(o+RPF_EXP)=p-1;uint64_t*L=(uint64_t*)(o+RPF_DATA);for(unsigned i=0;i<n;i++)L[i]=sm(&seed);unsigned top=p-64*(n-1);if(top<64)L[n-1]&=((1ULL<<top)-1);L[n-1]|=1ULL<<(top-1);}
static void to_mpf(mpf_t f,unsigned char*o,unsigned p){mpz_t z;mpz_init(z);size_t n=(p+63)/64;mpz_import(z,n,-1,8,0,0,o+RPF_DATA);mpf_set_z(f,z);mpz_clear(z);}
struct W{unsigned char*a,*b,*d;uint32_t type;};
struct G{mpf_t a,b,d;};
static void wa(void*x){struct W*w=x;if(rankn_fp_add(w->d,w->a,w->b,w->type))abort();}
static void wm(void*x){struct W*w=x;if(rankn_fp_mul(w->d,w->a,w->b,w->type))abort();}
static void wd(void*x){struct W*w=x;if(rankn_fp_div(w->d,w->a,w->b,w->type))abort();}
static void ga(void*x){struct G*g=x;mpf_add(g->d,g->a,g->b);} static void gm(void*x){struct G*g=x;mpf_mul(g->d,g->a,g->b);} static void gd(void*x){struct G*g=x;mpf_div(g->d,g->a,g->b);}
static long calibrate(void(*f)(void*),void*x){long n=1;for(;;){double s=now_s();for(long i=0;i<n;i++)f(x);double t=now_s()-s;if(t>.012||n>1000000){double per=t/n;long k=(long)(.035/(per>1e-12?per:1e-12));if(k<1)k=1;if(k>1000000)k=1000000;return k;}n*=2;}}
static double run(void(*f)(void*),void*x,long n){double s=now_s();for(long i=0;i<n;i++)f(x);return (now_s()-s)/n;}
static double med5(double*a){for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)if(a[j]<a[i]){double t=a[i];a[i]=a[j];a[j]=t;}return a[2];}
static double bench(void(*f)(void*),void*x){for(int i=0;i<3;i++)f(x);long n=calibrate(f,x);double v[5];for(int i=0;i<5;i++)v[i]=run(f,x,n);return med5(v);}
int main(){pin_one();unsigned ps[]={128,256,512,1024,4096,16384,65536,262144,524288,1048576};puts("p,wadd_ns,gadd_ns,add_ratio,wmul_ns,gmul_ns,mul_ratio,wdiv_ns,gdiv_ns,div_ratio");for(unsigned pi=0;pi<sizeof(ps)/sizeof(ps[0]);pi++){unsigned p=ps[pi];bench_precision=p;bench_geometry=choose_geom(p);if(!bench_geometry){fprintf(stderr,"GEOM FAIL p=%u\n",p);return 2;}size_t z=span(p);struct W w={(unsigned char*)aligned_alloc(64,z),(unsigned char*)aligned_alloc(64,z),(unsigned char*)aligned_alloc(64,z),TYPEID};if(!w.a||!w.b||!w.d)abort();init_obj(w.a,p,0x12345678ULL+p);init_obj(w.b,p,0x9abcdef0ULL^p);memset(w.d,0,z);struct G g;mpf_init2(g.a,p);mpf_init2(g.b,p);mpf_init2(g.d,p);to_mpf(g.a,w.a,p);to_mpf(g.b,w.b,p);
 double wa_t=bench(wa,&w),ga_t=bench(ga,&g),wm_t=bench(wm,&w),gm_t=bench(gm,&g);double wd_t=0,gd_t=0;if(p<=65536){wd_t=bench(wd,&w);gd_t=bench(gd,&g);} sink^=*(uint64_t*)(w.d+RPF_DATA)^mpf_get_ui(g.d);printf("%u,%.3f,%.3f,%.6f,%.3f,%.3f,%.6f,",p,wa_t*1e9,ga_t*1e9,wa_t/ga_t,wm_t*1e9,gm_t*1e9,wm_t/gm_t);if(p<=65536)printf("%.3f,%.3f,%.6f\n",wd_t*1e9,gd_t*1e9,wd_t/gd_t);else puts("NA,NA,NA");fflush(stdout);mpf_clears(g.a,g.b,g.d,NULL);free(w.a);free(w.b);free(w.d);}fprintf(stderr,"sink=%llu\n",(unsigned long long)sink);}
