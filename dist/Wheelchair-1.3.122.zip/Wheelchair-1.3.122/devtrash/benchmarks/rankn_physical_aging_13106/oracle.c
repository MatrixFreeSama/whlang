#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gmp.h>
extern int rankn_fp_mul(void*,void*,void*,uint32_t);
extern uint64_t bench_precision;
extern uint32_t bench_geometry;
#define TYPEID 103u
#define RPF_TYPE 0
#define RPF_GEOM 4
#define RPF_PREC 8
#define RPF_SIGN 16
#define RPF_EXP 24
#define RPF_DATA 32
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t span(unsigned p){size_t n=(p+63)/64;return (512*n+4096+63)&~63ull;}
static unsigned clog2u(uint64_t x){if(x<=1)return 0;return 64u-__builtin_clzll(x-1);}
static uint32_t choose_geom(unsigned p){
  uint64_t best=UINT64_MAX; uint32_t pack=0;
  for(int b=26;b>=1;b--){
    uint64_t n=((uint64_t)p+b-1)/(uint64_t)b, need=2*n-1;
    uint64_t d=(1ULL<<b)-1, md2=d*d;
    uint64_t b3=1; unsigned a3=0;
    while(b3<=2*need){
      uint64_t base=b3; unsigned a5=0;
      while(base<=2*need){
        uint64_t ratio=(need+base-1)/base; unsigned a2=clog2u(ratio);
        if(a2<=62 && base <= (UINT64_MAX>>a2)){
          uint64_t N=base<<a2;
          if(N>=need){
            unsigned L=clog2u(N);
            if(L){
              uint64_t lim=0x0007ffffffffffffULL/L;
              __uint128_t err=(__uint128_t)md2*n;
              if(err < lim){
                uint64_t w=100ULL*a2+120ULL*a3+180ULL*a5+10ULL*a3*a3+30ULL*a5*a5;
                __uint128_t cc=(__uint128_t)N*w+40ULL*n;
                if(cc<best){best=(uint64_t)cc;pack=(uint32_t)b|(a2<<8)|(a3<<16)|(a5<<24);}
              }
            }
          }
        }
        if(base>UINT64_MAX/5)break; base*=5; a5++;
      }
      if(b3>UINT64_MAX/3)break; b3*=3; a3++;
    }
  }
  return pack;
}
static void init(void*vv,unsigned p,uint64_t seed,int sign){unsigned char*o=vv;unsigned n=(p+63)/64;memset(o,0,span(p));*(uint32_t*)o=TYPEID;*(uint64_t*)(o+RPF_PREC)=p;*(uint64_t*)(o+RPF_SIGN)=sign;*(int64_t*)(o+RPF_EXP)=p-1;uint64_t*L=(uint64_t*)(o+RPF_DATA);for(unsigned i=0;i<n;i++)L[i]=sm(&seed);unsigned top=p-64*(n-1);if(top<64)L[n-1]&=((1ULL<<top)-1);L[n-1]|=1ULL<<(top-1);}
static void import_sig(mpz_t z,void*v,unsigned p){size_t n=(p+63)/64;mpz_import(z,n,-1,8,0,0,(char*)v+RPF_DATA);}
static int expected(void*out,void*a,void*b,unsigned p){mpz_t A,B,G,Q,R,H,LIM;mpz_inits(A,B,G,Q,R,H,LIM,NULL);import_sig(A,a,p);import_sig(B,b,p);mpz_mul(G,A,B);size_t bl=mpz_sizeinbase(G,2);long long e=(long long)bl-1;if(bl>p){unsigned long sh=bl-p;mpz_fdiv_q_2exp(Q,G,sh);mpz_fdiv_r_2exp(R,G,sh);mpz_set_ui(H,1);mpz_mul_2exp(H,H,sh-1);int c=mpz_cmp(R,H);if(c>0||(c==0&&mpz_odd_p(Q)))mpz_add_ui(Q,Q,1);mpz_set_ui(LIM,1);mpz_mul_2exp(LIM,LIM,p);if(mpz_cmp(Q,LIM)==0){mpz_fdiv_q_2exp(Q,Q,1);e++;}}else mpz_mul_2exp(Q,G,p-bl);uint64_t sign=*(uint64_t*)((char*)a+RPF_SIGN)^*(uint64_t*)((char*)b+RPF_SIGN);int ok=*(uint64_t*)((char*)out+RPF_SIGN)==sign && *(int64_t*)((char*)out+RPF_EXP)==e;size_t n=(p+63)/64;uint64_t*tmp=calloc(n,8);size_t c=0;mpz_export(tmp,&c,-1,8,0,0,Q);ok &= !memcmp(tmp,(char*)out+RPF_DATA,n*8);free(tmp);mpz_clears(A,B,G,Q,R,H,LIM,NULL);return ok;}
int main(){unsigned ps[]={65,73,113,127,191,257,521,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576};for(size_t k=0;k<sizeof(ps)/sizeof(ps[0]);k++){unsigned p=ps[k];bench_precision=p;bench_geometry=choose_geom(p);if(!bench_geometry){fprintf(stderr,"GEOM FAIL p=%u\n",p);return 2;}size_t z=span(p);for(int r=0;r<(p<=65536?8:2);r++){void*a=aligned_alloc(64,z),*b=aligned_alloc(64,z),*d=aligned_alloc(64,z);memset(d,0,z);init(a,p,0x1234+p*17+r*991,r&1);init(b,p,0x9876+p*29+r*313,(r>>1)&1);if(rankn_fp_mul(d,a,b,TYPEID)||!expected(d,a,b,p)){fprintf(stderr,"FAIL p=%u r=%d\n",p,r);return 1;}free(a);free(b);free(d);}printf("%u PASS\n",p);fflush(stdout);}puts("ORACLE=PASS");}
