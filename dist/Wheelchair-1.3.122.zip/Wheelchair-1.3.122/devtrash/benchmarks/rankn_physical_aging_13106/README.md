# Rank-N physical aging benchmark 1.3.106

`direct_core_1_3_105.csv` and `direct_core_1_3_106.csv` are pinned same-host Rank-N versus GMP 6.3.0 `mpf` direct-core samples. `gmp_exact_mul_oracle.log` records the independent exact integer product/RNE oracle through 1,048,576 bits.

The 524288-bit multiplication sample is a local crossover, not a universal GMP victory. Division remains substantially behind GMP.
