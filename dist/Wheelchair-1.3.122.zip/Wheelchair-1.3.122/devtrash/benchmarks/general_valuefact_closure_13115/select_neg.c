#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char**argv){ uint64_t n=strtoull(argv[1],0,10); double x=1.0; for(uint64_t i=0;i<n;i++) x=x>0.0 ? -x+0.25 : -x-0.25; uint64_t u; memcpy(&u,&x,8); printf("out00_bits=0x%016llx\n",(unsigned long long)u); }
