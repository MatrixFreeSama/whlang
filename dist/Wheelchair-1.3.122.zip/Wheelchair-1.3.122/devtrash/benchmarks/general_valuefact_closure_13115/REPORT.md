# General ValueFact Closure 1.3.115

1.3.115 removes basic scalar operator holes from the existing General Physical DAG. The benchmark probes are diagnostics, not compiler routes.

Pinned CPU, interleaved medians:

| probe | 1.3.114 | 1.3.115 | speedup |
|---|---:|---:|---:|
| `abs(f64)` recurrence | 74.54 ms | 35.30 ms | 2.112x |
| FP `min/max` recurrence | 158.03 ms | 46.60 ms | 3.391x |
| INT `min/max` recurrence | 74.99 ms | 29.59 ms | 2.535x |
| `select(predicate, neg(x)+c, neg(x)-c)` | 226.21 ms | 89.16 ms | 2.537x |

The select+neg C control is 60.24 ms, leaving Wheelchair 1.480x slower rather than the ~3.8x fallback regime. The new code remains inside the same register-native Physical DAG.

The strict scalar Mandelbrot control is intentionally almost unchanged (352.47 ms -> 351.58 ms median in the retained A/B) because 1.3.114 had already closed its compare/select operators. This release does not use unrelated workload gains as evidence.

FP sign transforms use the existing ConstantFact residency authority: a resident sign/absolute mask becomes one type-neutral XMM bitwise operation; when carrier pressure prevents residency, the same Physical DAG uses the existing transient bit carrier instead of switching evaluator.
