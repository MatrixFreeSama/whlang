# Whole-domain Mandelbrot 1.3.117

Purpose: test whether already-independent General roots become useful physical executions without changing source semantics or introducing a parallel DSL.

Configuration: 768x768, max 512 iterations, 16 exact causal scan roots, strict floating semantics, checksum `0x00000000032e223d`, fixed affinity 1 CPU and CPUs 0-3, 15 interleaved runs.

Final medians are recorded in `summary.csv`. The main result is 4-CPU Wheelchair **212.75 ms (1.3.116) -> 73.21 ms (1.3.117)** while one-CPU time changes only **212.42 -> 209.01 ms**. The change therefore repairs physical execution ownership of an already-proved root frontier rather than substituting another Mandelbrot algorithm.

C/Fortran are native OpenMP controls compiled with `-O3 -march=native -fno-fast-math -ffp-contract=off` and produce the same checksum. 1.3.117 remains slower than C/Fortran in this workload; the benchmark is retained as a regression witness for General root-frontier realization, not as a victory claim.
