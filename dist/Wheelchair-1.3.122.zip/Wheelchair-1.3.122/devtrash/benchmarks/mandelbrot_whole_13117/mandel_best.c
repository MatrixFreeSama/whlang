#include <stdint.h>
#include <stdio.h>
#include <omp.h>
int main(void){
 const int W=768,H=768; const double step=0.0039113428943937413;
 double cyrow[768]; double cy=-1.5; for(int y=0;y<H;y++){cyrow[y]=cy;cy+=step;}
 uint64_t total=0;
 #pragma omp parallel for schedule(dynamic,1) reduction(+:total)
 for(int py=0;py<H;py++){
   double cyv=cyrow[py],cx=-2.0; uint64_t rowsum=0;
   for(int px=0;px<W;px++){
    double zr=0.0,zi=0.0; uint64_t k=0;
    while(1){ double zr2=zr*zr,zi2=zi*zi; if(zr2+zi2>4.0 || k>=512) break; double nzi=2.0*zr*zi+cyv; double nzr=zr2-zi2+cx; zr=nzr;zi=nzi;k++; }
    rowsum+=k;cx+=step;
   }
   total+=rowsum;
 }
 printf("out00_bits=0x%016llx\n",(unsigned long long)total);
}
