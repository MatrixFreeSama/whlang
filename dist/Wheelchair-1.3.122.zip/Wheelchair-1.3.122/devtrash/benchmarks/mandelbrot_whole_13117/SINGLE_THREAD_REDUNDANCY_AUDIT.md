# Wheelchair 1.3.116 whole-domain Mandelbrot — single-thread redundancy audit

## Measurements

- Whole-domain Wheelchair, 1 CPU: median ~214–219 ms depending run batch.
- Nested-loop C, 1 CPU: median ~143–148 ms.
- Flat synchronous-state C, same checksum and same state-machine shape: median 150.67 ms.
- All produce checksum `0x00000000032e223d`.

The flat C control proves that the source-level synchronous state-machine shape alone does not explain Wheelchair's residual gap: GCC recovers a compact orbit/pixel/row hierarchy from the same flattened semantics.

## Ordinary non-escape orbit step

From fresh generated code:

- Wheelchair: ~52 dynamic instructions on the ordinary non-escape path.
- GCC C inner orbit: ~13 dynamic instructions.

Both execute essentially the same complex recurrence. The extra Wheelchair instructions are mainly control/state realization rather than additional mathematics.

## Main residuals

1. **Temporal-rate collapse**: `while py < bound` and `px == 767` are re-evaluated on every orbit microstep even though `py` and `px` change only on slower guarded events.
2. **PredicateFact data materialization**: `k>=512`, `px==767`, and `radius2>4` become `setcc -> movzx -> XMM`; boolean OR/AND then become vector bit operations followed by `vptest`.
3. **Guarded Region split into compute and commit phases**: the same guard is tested once to compute branch-local next facts and again later to commit those facts.
4. **Integer carrier hard cap**: `G_PHYS_INT_RESIDENT_MAX=3`; the fourth integer state (`checksum`) spills. Because Guarded Region admission requires a disjoint next carrier, checksum cannot join the shared guard. On a non-escape identity arm it still performs current->temp->current memory traffic.
5. **Strict guards not discharged by RangeFact**: `k+1` still emits an overflow branch although the false escape guard proves `k<512`.
6. **Authority copies remain**: ordinary non-escape commit still copies next `k/zr/zi` back into old-generation authorities.
7. **Compare operands are unnecessarily recopied**: resident `radius2` and constant 4.0 are copied to temporary XMMs before `vucomisd` instead of being consumed directly.
8. **Hard iterate limit stays in the steady path**: the 30M safety bound is checked and the global iteration counter incremented every microstep.
9. **Guard fusion is top-level only**: nested same-guard selects are not recursively Regionized; e.g. `Q=(px==767)` remains separately tested inside the `P` branch and in `P&&Q`.
10. **16 scan bodies are emitted as separate near-identical code copies**. This is mostly static/i-cache bloat, not the main dynamic cost.

## General, non-workload-specific convergence direction

The strongest unified fix is mutation-driven Region validity:

- A PredicateFact remains valid until one of its dependent StateFacts changes.
- State mutation frontiers induce temporal Regions automatically.
- For this program the graph would naturally become:
  - fast orbit Region: `zr, zi, k -> escape P`
  - pixel Region, entered only on `P`: `px, cx, checksum -> Q`
  - row Region, entered only on `P && Q`: `py, cy`
  - loop exit predicate depends on `py` and therefore only needs reconsideration when `py` changes.

This is not a Mandelbrot rule. It follows solely from StateFact dependencies and mutation epochs.

Other general convergence work:

- PredicateFact should support control-form authority (FLAGS/jcc) rather than default data materialization.
- A Guarded Region should own generation and authority transfer as one causal Region, avoiding a second guard test for commit.
- Replace fixed integer resident count with one GPR liveness/ABI geometry model.
- Allow spilled identity-arm states to participate in Guarded Regions, or eliminate the spill through unified allocation.
- Propagate branch-conditioned RangeFacts so Strict overflow checks disappear by proof.
- Emit comparisons directly from resident ValueFact/ConstantFact carriers.
- Prove inactive iterate safety bounds out of the steady path where possible.

No Mandelbrot/fractal/pixel/escape workload matcher exists in the audited compiler source.
