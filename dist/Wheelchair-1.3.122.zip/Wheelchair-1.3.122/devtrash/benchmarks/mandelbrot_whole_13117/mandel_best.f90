program mandel_best
 use omp_lib
 implicit none
 integer,parameter::W=768,H=768
 real(8),parameter::step=0.0039113428943937413d0
 real(8)::cyrow(0:767),cyv,cx,zr,zi,zr2,zi2,nzr,nzi,cy
 integer(8)::total,rowsum,k
 integer::py,px
 cy=-1.5d0
 do py=0,H-1; cyrow(py)=cy; cy=cy+step; end do
 total=0_8
!$omp parallel do schedule(dynamic,1) reduction(+:total) private(px,cyv,cx,zr,zi,zr2,zi2,nzr,nzi,rowsum,k)
 do py=0,H-1
  cyv=cyrow(py);cx=-2.0d0;rowsum=0_8
  do px=0,W-1
   zr=0.0d0;zi=0.0d0;k=0_8
   do
    zr2=zr*zr;zi2=zi*zi
    if(zr2+zi2>4.0d0 .or. k>=512_8) exit
    nzi=2.0d0*zr*zi+cyv;nzr=zr2-zi2+cx;zr=nzr;zi=nzi;k=k+1_8
   end do
   rowsum=rowsum+k;cx=cx+step
  end do
  total=total+rowsum
 end do
!$omp end parallel do
 write(*,'(A,Z16.16)') 'out00_bits=0x',total
end program mandel_best
