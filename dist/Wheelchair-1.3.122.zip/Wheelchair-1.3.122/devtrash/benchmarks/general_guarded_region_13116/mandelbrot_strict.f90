program mandel_strict
  use iso_fortran_env, only: int64, real64
  implicit none
  integer(int64) :: px, py, k, checksum
  real(real64) :: cx, cy, zr, zi, zr2, zi2, nr, ni
  real(real64), parameter :: d = 0.003911342894393741_real64
  checksum = 0_int64
  cy = -1.5_real64
  do py = 0_int64, 767_int64
    cx = -2.0_real64
    do px = 0_int64, 767_int64
      zr = 0.0_real64; zi = 0.0_real64; k = 0_int64
      do
        zr2 = zr * zr
        zi2 = zi * zi
        if ((zr2 + zi2 > 4.0_real64) .or. (k >= 512_int64)) exit
        nr = zr2 - zi2 + cx
        ni = 2.0_real64 * zr * zi + cy
        zr = nr; zi = ni; k = k + 1_int64
      end do
      checksum = checksum + k
      if (px /= 767_int64) cx = cx + d
    end do
    cy = cy + d
  end do
  write(*,'(A,Z16.16)') 'out00_bits=0x', checksum
end program
