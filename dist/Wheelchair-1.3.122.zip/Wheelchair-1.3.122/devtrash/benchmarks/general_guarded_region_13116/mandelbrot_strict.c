#include <stdint.h>
#include <stdio.h>
int main(void) {
    const double d = 0.003911342894393741;
    uint64_t checksum = 0;
    double cy = -1.5;
    for (uint64_t py = 0; py < 768; ++py) {
        double cx = -2.0;
        for (uint64_t px = 0; px < 768; ++px) {
            double zr = 0.0, zi = 0.0;
            uint64_t k = 0;
            for (;;) {
                double zr2 = zr * zr;
                double zi2 = zi * zi;
                if ((zr2 + zi2 > 4.0) || (k >= 512)) break;
                double nr = zr2 - zi2 + cx;
                double ni = 2.0 * zr * zi + cy;
                zr = nr; zi = ni; ++k;
            }
            checksum += k;
            if (px != 767) cx += d;
        }
        cy += d;
    }
    printf("out00_bits=0x%016llx\n", (unsigned long long)checksum);
    return 0;
}
