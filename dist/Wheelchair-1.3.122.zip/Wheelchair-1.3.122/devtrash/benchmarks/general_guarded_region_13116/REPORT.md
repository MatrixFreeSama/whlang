# General Guarded Physical Region 1.3.116

This is a General scalar-control maturity diagnostic, not a compiler workload route. The source is the retained strict scalar Mandelbrot program used since 1.3.113: 768x768, 512 orbit bound, scalar state machine, one fixed CPU, no SIMD.

C and Fortran are compiled with `-O3 -march=native -fno-tree-vectorize -ffp-contract=off -fno-fast-math`.

All implementations produce checksum `0x00000000032e223d`.

## 15-run pinned interleaved result

| implementation | median wall |
|---|---:|
| Wheelchair 1.3.115 | 359.70 ms |
| **Wheelchair 1.3.116** | **213.67 ms** |
| GCC C | 143.14 ms |
| GFortran | 144.82 ms |

1.3.116 is 1.683x faster than 1.3.115, reducing wall time by 40.60%. It remains 1.493x the C time and 1.475x the Fortran time.

## Machine-code contraction

Same generated-program trailer:

- bytes: 3193 -> 2926
- disassembly lines: 858 -> 791
- `movabs`: 27 -> 18
- `test`: 45 -> 31
- `jmp`: 35 -> 27
- `vucomisd`: 1 -> 1
- `vaddsd`: 5 -> 5
- `vmulsd`: 4 -> 4

The arithmetic DAG is intentionally unchanged. The contraction comes from predicate/control/state realization: shared guarded regions, direct BOOL carrier testing, BOOL DAG bit relations, and immediate integer operands.

## Regression controls

FP1 and FP2 pure scalar recurrences remain effectively neutral versus 1.3.115. The already-native `select + neg` probe is also effectively neutral. Separate semantic differential probes cover shared-guard state swapping, mixed INT/FP state, identity arms, cross-state old-generation dependencies and nested selects.

No Mandelbrot/fractal/pixel/workload identity appears in the production compiler additions.
