# Mandelbrot scalar-control diagnostic, 1.3.113

This is a maturity diagnostic, not a Wheelchair-specific workload route. The same 768x768 Mandelbrot set, 512-iteration bound and cumulative coordinate order are used across implementations. Runs are pinned to one CPU. C and Fortran use `-O3 -march=native -fno-tree-vectorize -ffp-contract=off -fno-fast-math`.

All implementations produce checksum `0x00000000032e223d` (Fortran prints uppercase hex digits).

## Wheelchair old/new

11 interleaved runs:

- 1.3.112 median: 2252.692260 ms
- 1.3.113 median: 523.440148 ms
- speedup: 4.303629x
- wall-time reduction: 76.7638%

## Fresh strict scalar baselines

11 interleaved runs:

- Wheelchair 1.3.113 median: 523.168208 ms
- GCC C median: 143.442246 ms
- GFortran median: 143.340636 ms

The release repairs the large control-to-generic rollback but does not claim C/Fortran scalar-control parity.

## Structural machine-code movement

For the same generated Wheelchair program trailer:

- disassembly lines: about 1458 -> 983
- static `push + pop`: 386 -> 82
- scalar multiply sites: 20 -> 8

The repair is General: compare/boolean/select become Physical-DAG values; strict integer-overflow edges remain strict; CSE and state liveness traverse control edges. There is no Mandelbrot/fractal/pixel matcher.
