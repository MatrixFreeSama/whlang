# Tensor Fact Aging 1.3.101 benchmark

Host: AMD EPYC 9V74 VM slice, 5 visible logical CPUs, Linux 6.18.44. GCC/GFortran 14.2.0.

Probe: Dense Permuted All-Pairs 127, n=8192, 100% connected.

Paired A/B:
- Strict: 1.3.100 median 249.973398 ms, 1.3.101 median 243.187497 ms; paired ratio median 1.005300x.
- Tolerance: 1.3.100 median 231.082843 ms, 1.3.101 median 221.466261 ms; paired ratio median 1.083803x.

Single core:
- Strict: 749.713542 -> 740.505076 ms.
- Tolerance: 757.966341 -> 681.198310 ms; paired ratio about 1.111x.

C/Fortran Strict flags include `-ffp-contract=off`; Fast controls use `-ffast-math`.
