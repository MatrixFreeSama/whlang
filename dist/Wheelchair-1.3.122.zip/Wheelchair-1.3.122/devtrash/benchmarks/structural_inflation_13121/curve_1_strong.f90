program curve
use iso_fortran_env, only: int64, real64
implicit none
integer(int64)::n,i,ibits
integer::stat
real(real64), allocatable :: a(:),b(:)
real(real64)::s
character(len=64)::arg
if(command_argument_count()>=1)then
 call get_command_argument(1,arg)
 read(arg,*)n
else
 n=8000000_int64
end if
allocate(a(0:n-1),b(0:n-1),stat=stat)
if(stat/=0)stop 2
do i=0,n-1
 a(i)=real(iand(i,4095_int64),real64)
end do
b(0:n-17-1)=a(17:n-1)
b(n-17:n-1)=a(0:17-1)
a(17:n-1)=b(0:n-17-1)
a(0:17-1)=b(n-17:n-1)
s=0.0_real64
do i=0,n-1
 s=s+a(i)
end do
ibits=transfer(s,ibits)
write(*,'("checksum_bits=0x",Z16.16)')ibits
end program curve
