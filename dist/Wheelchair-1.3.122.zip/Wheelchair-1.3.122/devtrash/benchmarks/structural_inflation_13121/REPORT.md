# Structural inflation curve 1.3.121

This benchmark holds the mathematical result and useful per-element arithmetic constant while increasing only the number of cancellable periodic coordinate maps.  Each pair applies a circular `+c` map and its exact `-c` inverse, so every depth is mathematically identical to depth zero.

The C reference uses two `memcpy` segments per circular shift; the Fortran reference uses contiguous array sections.  Neither reference pays integer division in the hot remap.  Wheelchair is compiled from the unchanged human surface.  Measurements below are same-host, one admitted CPU, `n=8,000,000`, median of interleaved runs; C/GFortran use `-O3 -march=native`.

| pairs | 1.3.120 ms | 1.3.121 candidate ms | C ms | Fortran ms | old/new |
|---:|---:|---:|---:|---:|---:|
| 0 | 99.018 | 99.487 | 35.876 | 32.499 | 1.00x |
| 1 | 114.788 | 99.881 | 67.047 | 71.639 | 1.15x |
| 2 | 132.008 | 102.043 | 84.420 | 79.671 | 1.29x |
| 4 | 162.779 | 100.963 | 114.273 | 110.978 | 1.61x |
| 6 | 211.861 | 102.064 | 130.140 | 134.809 | 2.08x |
| 8 | 272.056 | 99.063 | 153.922 | 149.383 | 2.75x |
| 10 | 327.551 | 98.158 | 164.679 | 169.239 | 3.34x |
| 12 | 394.124 | 99.541 | 199.103 | 200.410 | 3.96x |

The decisive invariant is emitted-code identity: depth 0, depth 12 and a separately generated depth-200 inverse chain all produce the same 8513-byte ELF and the same SHA-256.  The old 1.3.120 frontend rejects depth 13; the candidate accepts depth 200 without increasing code size.  `objdump` reports zero `div/idiv` in the retained depth-12/depth-200 images.

This is CoordinateFact algebra, not a workload route.  An independent non-identity probe confirms that 100 chained `+17 mod n` maps canonicalize to the same binary and checksum as one direct `+1700 mod n` map.  A negative terminal residue is normalized inside the same Z/nZ materializer rather than falling back to a per-layer index carrier.
