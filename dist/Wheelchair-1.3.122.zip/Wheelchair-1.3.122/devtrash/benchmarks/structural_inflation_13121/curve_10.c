#define _POSIX_C_SOURCE 200112L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static inline uint64_t bits(double x){uint64_t u; memcpy(&u,&x,8); return u;}
static inline void shift_fwd(double *restrict dst,const double *restrict src,size_t n,size_t c){memcpy(dst,src+c,(n-c)*sizeof(double));memcpy(dst+n-c,src,c*sizeof(double));}
static inline void shift_rev(double *restrict dst,const double *restrict src,size_t n,size_t c){memcpy(dst+c,src,(n-c)*sizeof(double));memcpy(dst,src+n-c,c*sizeof(double));}
int main(int argc,char**argv){size_t n=argc>1?strtoull(argv[1],0,10):8000000ULL; double *a=0,*b=0; if(posix_memalign((void**)&a,64,n*sizeof(double))||posix_memalign((void**)&b,64,n*sizeof(double))) return 2; for(size_t i=0;i<n;i++) a[i]=(double)(i&4095ULL);
shift_fwd(b,a,n,17ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,17ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,31ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,31ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,47ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,47ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,73ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,73ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,101ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,101ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,131ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,131ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,173ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,173ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,211ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,211ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,257ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,257ULL);{double*t=a;a=b;b=t;}
shift_fwd(b,a,n,307ULL);{double*t=a;a=b;b=t;}
shift_rev(b,a,n,307ULL);{double*t=a;a=b;b=t;}
double sum=0.0; for(size_t i=0;i<n;i++) sum+=a[i]; printf("checksum_bits=0x%016llx\n",(unsigned long long)bits(sum)); free(a);free(b);return 0;}
