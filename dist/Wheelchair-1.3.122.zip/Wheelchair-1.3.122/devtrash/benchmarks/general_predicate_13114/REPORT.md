# General PredicateFact Convergence 1.3.114

Diagnostic: strict scalar Mandelbrot, 768x768, 512 iteration bound, one fixed CPU, identical source semantics and checksum `0x00000000032e223d`.

15 interleaved runs:

| implementation | median wall | median CPU |
|---|---:|---:|
| Wheelchair 1.3.114 | 347.94 ms | 347.58 ms |
| Wheelchair 1.3.113 | 513.52 ms | 513.08 ms |
| GCC C strict scalar | 140.28 ms | 139.80 ms |
| GFortran strict scalar | 140.96 ms | 140.58 ms |

1.3.114 / 1.3.113 = 1.476x speedup; wall time is reduced by 32.24%.
Relative to the retained 1.3.112 median 2252.69 ms, the cumulative control-path convergence is 6.474x.

Generated trailer structural counts, 1.3.113 -> 1.3.114:

- bytes: 3661 -> 3193
- disassembly lines: 983 -> 858
- `vucomisd`: 8 -> 1
- `seta`: 8 -> 1
- `setae`: 8 -> 1
- `sete`: 4 -> 1
- `vaddsd`: 12 -> 5
- `movabs`: 44 -> 27
- `push`: 39 -> 36
- `pop`: 43 -> 40

The change contains no workload recognizer. Repeated BOOL predicates and repeated FP arithmetic use one episode ValueFact authority, and retained parent/child facts are limited by physical carrier pressure rather than an antichain convention.
