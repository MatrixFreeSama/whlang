# Rank-N Local-Strict 1.3.107 diagnostic

This experiment measures the 1.3.107 addition/subtraction physical aging against the unmodified 1.3.106 runtime on the same host. The benchmark pins one CPU, warms each operation, calibrates iteration count, takes five timing samples per point, and the published candidate/baseline CSVs are medians of three complete benchmark runs.

The change does not add a precision threshold or an alternate arithmetic algorithm. Each canonical Rank-N operand is projected once into an operation-local guard/sticky carrier, the local carrier is consumed by the existing add/sub relation, and the result is closed by the one strict RNE authority.

`add_sub_gmp_oracle.c` is test-only. It constructs exact signed integer values with GMP and checks Wheelchair add/sub bit-for-bit over arbitrary precisions, signs, exponent gaps, cancellation, and rounding boundaries. GMP is never linked into production.

The measured improvement is concentrated in Rank-N addition. Multiplication and division remain the 1.3.106 authorities and are reported only as controls. No claim of globally beating GMP is made.
