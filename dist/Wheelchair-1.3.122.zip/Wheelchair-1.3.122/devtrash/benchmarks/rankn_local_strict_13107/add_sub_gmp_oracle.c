#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gmp.h>
extern int rankn_fp_add(void*,void*,void*,uint32_t);
extern int rankn_fp_sub(void*,void*,void*,uint32_t);
extern uint64_t bench_precision;
#define TYPEID 103u
#define RPF_PREC 8
#define RPF_SIGN 16
#define RPF_EXP 24
#define RPF_DATA 32
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t span(unsigned p){size_t n=(p+63)/64;return (512*n+4096+63)&~63ull;}
static void init(void*vv,unsigned p,uint64_t seed,int sign,int64_t exp){unsigned char*o=vv;unsigned n=(p+63)/64;memset(o,0,span(p));*(uint32_t*)o=TYPEID;*(uint64_t*)(o+RPF_PREC)=p;*(uint64_t*)(o+RPF_SIGN)=sign;*(int64_t*)(o+RPF_EXP)=exp;uint64_t*L=(uint64_t*)(o+RPF_DATA);for(unsigned i=0;i<n;i++)L[i]=sm(&seed);unsigned top=p-64*(n-1);if(top<64)L[n-1]&=((1ULL<<top)-1);L[n-1]|=1ULL<<(top-1);}
static void import_sig(mpz_t z,void*v,unsigned p){size_t n=(p+63)/64;mpz_import(z,n,-1,8,0,0,(char*)v+RPF_DATA);}
static int expected(void*out,void*a,void*b,unsigned p,int sub){mpz_t A,B,Z,Q,R,H,LIM;mpz_inits(A,B,Z,Q,R,H,LIM,NULL);import_sig(A,a,p);import_sig(B,b,p);if(*(uint64_t*)((char*)a+RPF_SIGN))mpz_neg(A,A);if((*(uint64_t*)((char*)b+RPF_SIGN))^sub)mpz_neg(B,B);int64_t ka=*(int64_t*)((char*)a+RPF_EXP)-(int64_t)(p-1), kb=*(int64_t*)((char*)b+RPF_EXP)-(int64_t)(p-1), k=ka<kb?ka:kb;mpz_mul_2exp(A,A,(mp_bitcnt_t)(ka-k));mpz_mul_2exp(B,B,(mp_bitcnt_t)(kb-k));mpz_add(Z,A,B);unsigned char*o=out;if(mpz_sgn(Z)==0){int ok=*(uint64_t*)(o+RPF_SIGN)==0&&*(int64_t*)(o+RPF_EXP)==0;size_t n=(p+63)/64;for(size_t i=0;i<n;i++)ok&=((uint64_t*)(o+RPF_DATA))[i]==0;mpz_clears(A,B,Z,Q,R,H,LIM,NULL);return ok;}uint64_t sign=mpz_sgn(Z)<0;if(sign)mpz_neg(Z,Z);size_t bl=mpz_sizeinbase(Z,2);int64_t e=(int64_t)(bl-1)+k;if(bl>p){unsigned long sh=(unsigned long)(bl-p);mpz_fdiv_q_2exp(Q,Z,sh);mpz_fdiv_r_2exp(R,Z,sh);mpz_set_ui(H,1);mpz_mul_2exp(H,H,sh-1);int c=mpz_cmp(R,H);if(c>0||(c==0&&mpz_odd_p(Q)))mpz_add_ui(Q,Q,1);mpz_set_ui(LIM,1);mpz_mul_2exp(LIM,LIM,p);if(mpz_cmp(Q,LIM)==0){mpz_fdiv_q_2exp(Q,Q,1);e++;}}else mpz_mul_2exp(Q,Z,p-bl);int ok=*(uint64_t*)(o+RPF_SIGN)==sign&&*(int64_t*)(o+RPF_EXP)==e;size_t n=(p+63)/64;uint64_t*tmp=calloc(n,8);size_t c=0;mpz_export(tmp,&c,-1,8,0,0,Q);ok&=!memcmp(tmp,o+RPF_DATA,n*8);free(tmp);mpz_clears(A,B,Z,Q,R,H,LIM,NULL);return ok;}
int main(){unsigned ps[]={65,73,113,127,191,257,521,1024,2048,4096,16384,65536};int gaps[]={0,1,2,3,4,17,63,64,65,129,511,4097};for(size_t ip=0;ip<sizeof(ps)/sizeof(ps[0]);ip++){unsigned p=ps[ip];bench_precision=p;size_t z=span(p);for(int op=0;op<2;op++)for(int sg=0;sg<4;sg++)for(size_t ig=0;ig<sizeof(gaps)/sizeof(gaps[0]);ig++)for(int r=0;r<5;r++){void*a=aligned_alloc(64,z),*b=aligned_alloc(64,z),*d=aligned_alloc(64,z);int64_t ea=(int64_t)p-1+37, eb=ea-gaps[ig];init(a,p,0x1234+p*17+r*991+ig,sg&1,ea);init(b,p,0x9876+p*29+r*313+ig,(sg>>1)&1,eb);memset(d,0,z);int bad=op?rankn_fp_sub(d,a,b,TYPEID):rankn_fp_add(d,a,b,TYPEID);if(bad||!expected(d,a,b,p,op)){fprintf(stderr,"FAIL p=%u op=%d sg=%d gap=%d r=%d\n",p,op,sg,gaps[ig],r);return 1;}free(a);free(b);free(d);}printf("%u PASS\n",p);fflush(stdout);}puts("ADD_SUB_ORACLE=PASS");}
