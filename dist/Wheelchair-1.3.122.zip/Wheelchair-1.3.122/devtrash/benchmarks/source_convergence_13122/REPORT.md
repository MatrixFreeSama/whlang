# 1.3.122 parallel-source convergence diagnostic

The benchmark is intentionally secondary to the binary identity check. 1.3.122 removes source-level parallel authorities while retaining the same AOT machine code as 1.3.121.

## Machine-code identity

The retained 12-pair structural-inflation source was compiled independently by the pristine 1.3.121 compiler and the converged 1.3.122 compiler. Both outputs are 8513 bytes and have SHA-256:

`ab7667c9bca6a2b39449b41bd4cbf3f81045e50d192d1d3350d62cca9176a569`

All eight production compiler/runtime binaries also remain byte-identical to the pristine 1.3.121 build after source convergence. Therefore the expected runtime speed change of the refactor itself is exactly zero at the machine-code level.

## Interleaved A/B timing

One pinned CPU, 8,000,000 elements, eleven interleaved runs of the byte-identical generated program:

- 1.3.121 median: 5.400 ms
- 1.3.122 median: 5.343 ms
- apparent ratio: 1.0106x

Because the executables are byte-identical, the ~1.1% median difference is measurement noise, not a compiler performance claim.

## Current-host language comparison

A fresh local comparison of the retained 12-pair source gives medians:

- Wheelchair: 5.699 ms
- C (`-O3 -march=native`): 151.390 ms
- Fortran (`-O3 -march=native`): 152.982 ms

This is a host-local diagnostic only; it is not compared numerically with older runs from a different host/environment.

## Source convergence

- Tensor frontend authorities: 1,198,204 -> 844,573 bytes (-29.51%).
- Field runtime authorities: 123,690 -> 98,255 bytes (-20.56%).
- All production `.S/.inc`: 3,018,437 -> 2,639,371 bytes (-12.56%).

Common bodies are assembler-time macro/include authorities. There is no runtime ISA/profile selector, workload matcher, second Tensor frontend, or generated source copy.
