#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP=${TMPDIR:-/tmp}/wheelchair_shape_periodic_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
SRC="$ROOT/compiler/surface_lowerer_x86_64.S"

grep -q '^s_shapefact_affine_coord_collect:' "$SRC"
grep -q '^s_shapefact_dynamic_affine_mod:' "$SRC"
grep -q '(L mod n) \* S == (L\*S) mod P' "$SRC"
! grep -Eq 'crossaxis|mixed_axis_benchmark|rank2_127' "$SRC"

cat > "$TMP/cross.whex" <<'WH'
program shape_periodic_affine_probe
strict
input n: u64 range 1024..65536
field x[b in n, i in 127]: f64 = cast(f64, (b * 31 + i * 17 + 5) % 4096)
sum checksum[b in n, i in 127]: f64 =
    x[(b * 97 + i * 13 + 17) % n, (i * 37 + b * 7 + 11) % 127]
output checksum
WH
"$ROOT/bin/whexc" "$TMP/cross.whex" -o "$TMP/cross" >/dev/null
[ "$("$TMP/cross" 1024)" = 'checksum_bits=0x41affc3c00000000' ]
[ "$("$TMP/cross" 4093)" = 'checksum_bits=0x41cfbb5171000000' ]

cat > "$TMP/mul1.whex" <<'WH'
program shape_periodic_mul1_probe
strict
input n: u64 range 1024..65536
field x[b in n, i in 127]: f64 = cast(f64, (b * 31 + i * 17 + 5) % 4096)
sum checksum[b in n, i in 127]: f64 = x[(b * 1 + 17) % n, i]
output checksum
WH
"$ROOT/bin/whexc" "$TMP/mul1.whex" -o "$TMP/mul1" >/dev/null
"$TMP/mul1" 1024 >/dev/null

printf '%s\n' \
  'SHAPEFACT_PERIODIC_AFFINE_CLOSURE_1_3_120=PASS' \
  'DYNAMIC_AXIS_LITERAL_MULTIPLICATION_1_3_120=PASS' \
  'CROSS_AXIS_PERIODIC_COORDINATE_1_3_120=PASS' \
  'WORKLOAD_SPECIFIC_SHAPE_ROUTE_1_3_120=0' \
  'SECOND_COORDINATE_BACKEND_1_3_120=0'
