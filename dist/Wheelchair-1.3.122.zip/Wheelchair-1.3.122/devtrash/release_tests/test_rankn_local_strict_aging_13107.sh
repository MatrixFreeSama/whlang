#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

[ "$(cat "$ROOT/VERSION")" = "1.3.107" ]

# The historical 30-bit precision payload wall remains absent. Type admission
# does not depend on whether Fourier multiplication can be physically realized.
cat >"$TMP/wall.wh" <<'SRC'
program rankn_old_precision_wall
input x: fp1073741824
output x = x
SRC
"$CC" "$TMP/wall.wh" -o "$TMP/wall" >/dev/null
[ -x "$TMP/wall" ]

# One fpP type owns one AOT Physical Fact. Multiplication consumes it without a
# per-value geometry field or a runtime geometry planner.
cat >"$TMP/mul.wh" <<'SRC'
program rankn_type_physical_fact
input a: fp257
input b: fp257
let m = a * b
output m = m
SRC
"$CC" "$TMP/mul.wh" -o "$TMP/mul" >/dev/null
OUT=$("$TMP/mul" 1.5 2.25)
case "$OUT" in
  out00_rankn_fp=0x0000000000000101:*) ;;
  *) echo rankn_mul_runtime_failed >&2; exit 1;;
esac

# Decimal ingress is the one integer recurrence D=10D+d followed by final
# normalization/division, never a Fourier multiplication per source digit.
cat >"$TMP/decimal.wh" <<'SRC'
program rankn_decimal_ingress
input x: fp521
output x = x
SRC
"$CC" "$TMP/decimal.wh" -o "$TMP/decimal" >/dev/null
[[ "$("$TMP/decimal" 12345678901234567890.125)" == out00_rankn_fp=0x0000000000000209:* ]]

PROD=("$ROOT/compiler" "$ROOT/runtime" "$ROOT/tools")
! grep -RIE --include='*.S' --include='*.inc' --include='*.sh' \
  'GTYPE_RANKN_FP_(FLAG|MASK)|RPF_TYPE_(FLAG|MASK)|0x3fffffff|1073741823' "${PROD[@]}"
! grep -RIE --include='*.S' --include='*.inc' \
  '\bRPF_N\b|\bRPF_GEOM\b|rpf_nf_choose_geom|g_emit_rankn_fourier_geom_store' \
  "$ROOT/compiler" "$ROOT/runtime"

grep -q '^g_rankn_type_facts_ptr:.skip 8$' "$ROOT/compiler/general_frontend_x86_64.S"
grep -q '^rankn_physical_fact_ptr:' "$ROOT/runtime/general_runtime_template_x86_64.S"
grep -q '^rpf_raw_mul10_add:$' "$ROOT/runtime/rankn_precision_physical_x86_64.inc"
grep -q '^.equ RPF_PREC,8$' "$ROOT/runtime/rankn_precision_physical_x86_64.inc"
grep -q '^.equ RPF_TYPE_BASE,TYPE_STATIC_LAST+1$' "$ROOT/runtime/rankn_precision_physical_x86_64.inc"

# Local-Strict addition owns one projection relation.  The production add/sub
# core no longer composes copy + exact-left-shift + sticky-right-shift episodes.
RPF="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
grep -q '^rpf_project_local_carrier:$' "$RPF"
grep -q '^rpf_object_header_init:$' "$RPF"
sed -n '/^rpf_add_core:/,/^.global rankn_fp_add/p' "$RPF" >"$TMP/add.inc"
[ "$(grep -c 'call rpf_project_local_carrier' "$TMP/add.inc")" -eq 2 ]
! grep -Eq 'call rpf_(copy_limbs|shl_exact|shr_sticky)' "$TMP/add.inc"
grep -q 'call rpf_round_from_integer' "$TMP/add.inc"
# The generic strict closure initializes only semantic header state on the common
# overwrite path; zero-fill remains confined to the sparse left-deposit path.
sed -n '/^rpf_round_from_integer:/,/^# NOTE:/p' "$RPF" >"$TMP/round.inc"
grep -q 'call rpf_object_header_init' "$TMP/round.inc"

# No source-visible local-float dialect, precision-tier selector or second Rank-N
# backend is admitted by the aging.
! grep -RqsE 'localfp|local_float|rankn_local_backend|precision_tier_selector|local_strict_selector' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools"

# The parser itself must not call the wide multiplier/add per decimal digit.
sed -n '/^parse_rankn_fp:/,/^parse_rankn_fp_end:/p' "$ROOT/runtime/general_runtime_template_x86_64.S" >"$TMP/parse.inc"
! grep -Eq 'call[[:space:]]+rankn_fp_(mul|add)' "$TMP/parse.inc"
grep -q 'call rpf_raw_mul10_add' "$TMP/parse.inc"

printf '%s\n' \
  'RANKN_TYPE_PHYSICAL_FACT_1_3_107=PASS' \
  'RUNTIME_FOURIER_PLANNER_1_3_107=0' \
  'RANKN_VALUE_GEOMETRY_STATE_1_3_107=0' \
  'RANKN_DECIMAL_PER_DIGIT_FOURIER_1_3_107=0' \
  'RANKN_LOCAL_CARRIER_PROJECTION_1_3_107=PASS' \
  'RANKN_STRICT_CLOSE_AUTHORITY_1_3_107=PASS' \
  'SOURCE_VISIBLE_LOCAL_FLOAT_DIALECT_1_3_107=0' \
  'SECOND_RANKN_BACKEND_1_3_107=0' \
  'RANKN_LOCAL_STRICT_AGING_1_3_107=PASS'
