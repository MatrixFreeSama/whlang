#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

RPF="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
GF="$ROOT/compiler/general_frontend_x86_64.S"

# The fpP declaration kind is stable storage across inference/physicalization;
# no caller-saved register is allowed to carry it through the Rank-N type path.
sed -n '/^\.binding_decl_loop:/,/^\.binding_decl_done:/p' "$GF" >"$TMP/decl.inc"
grep -q 'mov dword ptr \[rsp\],eax' "$TMP/decl.inc"
grep -q 'mov edx,dword ptr \[rsp\]' "$TMP/decl.inc"
! grep -q 'mov r11d,eax' "$TMP/decl.inc"

# Constant/cast fpP materialization must survive the same general frontend path.
cat >"$TMP/cast.wh" <<'SRC'
program rankn_cast_regression
precision_propagation 1
let one = cast(fp127, 1)
let two: fp127 = 2
let y = one + two
output y=y
SRC
"$CC" "$TMP/cast.wh" -o "$TMP/cast" >/dev/null
[[ "$("$TMP/cast")" == out00_rankn_fp=0x000000000000007f:* ]]

# Advanced local propagation keeps scalar series denominators as scalar facts.
grep -q '^\.global rankn_fp_div_u64$' "$RPF"
grep -q '^rpf_value_equal:$' "$RPF"
sed -n '/^rankn_fp_exp:/,/^rankn_fp_log:/p' "$RPF" >"$TMP/exp.inc"
sed -n '/^rankn_fp_log:/,/^rpf_sincos_core:/p' "$RPF" >"$TMP/log.inc"
sed -n '/^rpf_sincos_core:/,/^rankn_fp_sin:/p' "$RPF" >"$TMP/sincos.inc"
[ "$(grep -c 'call rankn_fp_div_u64' "$TMP/exp.inc")" -eq 1 ]
[ "$(grep -c 'call rankn_fp_div_u64' "$TMP/log.inc")" -eq 1 ]
[ "$(grep -c 'call rankn_fp_div_u64' "$TMP/sincos.inc")" -eq 4 ]
grep -q 'call rpf_value_equal' "$TMP/exp.inc"
grep -q 'call rpf_value_equal' "$TMP/log.inc"
[ "$(grep -c 'call rpf_value_equal' "$TMP/sincos.inc")" -eq 2 ]

# Representative native mathematics remains within the established local
# propagation contract. Type identity is now the interned precision fact, not
# the retired encoded-width bit field.
for p in 65 127 521; do
cat >"$TMP/math_$p.wh" <<SRC
program math_$p
precision_propagation 1
let one = cast(fp$p, 1)
let two = cast(fp$p, 2)
let a = sqrt(two)
let b = exp(one)
let c = log(two)
let d = sin(one)
let e = cos(one)
output a=a
output b=b
output c=c
output d=d
output e=e
SRC
"$CC" "$TMP/math_$p.wh" -o "$TMP/math_$p" >/dev/null
done
python3 - "$TMP" <<'PY'
from pathlib import Path
import subprocess,sys
T=Path(sys.argv[1])
EXPECTED={
65:[(0,0x16a09e667f3bcc909),(1,0x15bf0a8b145769535),(-1,0x162e42fefa39ef358),(-1,0x1aed548f090cee042),(-1,0x114a280fb5068b924)],
127:[(0,0x5a827999fcef32422cbec4d9baa55f50),(1,0x56fc2a2c515da54d57ee2b10139e9e79),(-1,0x58b90bfbe8e7bcd5e4f1d9cc01f97b58),(-1,0x6bb5523c2433b8106374f484e2879e19),(-1,0x4528a03ed41a2e48e12336cbb438de95)],
521:[(0,int('16a09e667f3bcc908b2fb1366ea957d3e3adec17512775099da2f590b0667322a95f90608757145875163fcdfb907b6721ee950bc8738f694f0090e6c7bf44ed1a4',16)),(1,int('15bf0a8b1457695355fb8ac404e7a79e3b1738b079c5a6d2b53c26c8228c867f799273b9c49367df2fa5fc6c6c618ebb1ed0364055d88c2f5a7be3dababfacac248',16)),(-1,int('162e42fefa39ef35793c7673007e5ed5e81e6864ce5316c5b141a2eb71755f457cf70ec40dbd75930ab2aa5f695f43621da5d5c6b827042884eae765222d3704a7d',16)),(-1,int('1aed548f090cee0418dd3d2138a1e786513ca22265ea3169bdf6d94bfad8c937bf617b3fe3db9a8aeecab6b04d47a76a184c6aac6bbfa19d7fd134c4a19d6082e52',16)),(-1,int('114a280fb5068b923848cdb2ed0e37a53446e75129f2d876fe46004816ec1cdf52d5288614a5a1d3c87e68a1c771ff33792688083b70404092c0df446a568c6eaf7',16))],
}
def s64(x): return x-(1<<64) if x>>63 else x
def parse(line):
    _,v=line.split('=',1); typ,sg,e,n,sig=v[2:].split(':')
    return int(typ,16),int(sg,16),s64(int(e,16)),int(n,16),int(sig,16)
for p in (65,127,521):
    lines=subprocess.check_output([str(T/f'math_{p}')],text=True).splitlines()
    assert len(lines)==5,(p,lines)
    for i,(line,(ee,esig)) in enumerate(zip(lines,EXPECTED[p])):
        typ,sg,e,n,sig=parse(line)
        assert typ==p and sg==0 and e==ee,(p,i,line)
        assert abs(sig-esig)<=4,(p,i,sig-esig)
print('RANKN_MATH_LOCAL_ORACLE_1_3_109=PASS')
PY

# Zero relations close in the shared arithmetic primitives rather than growing
# per-function special cases.  These were crash cases in 1.3.107.
for spec in 'sqrt 0' 'exp 0' 'log 1' 'sin 0' 'cos 0'; do
  set -- $spec; f=$1; x=$2
  cat >"$TMP/id_${f}.wh" <<SRC
program id_${f}
precision_propagation 1
input x: fp127
let y = $f(x)
output y=y
SRC
  "$CC" "$TMP/id_${f}.wh" -o "$TMP/id_${f}" >/dev/null
  "$TMP/id_${f}" "$x" >/dev/null
done

# Domain rejection remains deterministic.
cat >"$TMP/sqrt_neg.wh" <<'SRC'
program sqrt_negative
precision_propagation 1
let x = cast(fp127, -1)
let y = sqrt(x)
output y=y
SRC
cat >"$TMP/log_zero.wh" <<'SRC'
program log_zero
precision_propagation 1
let x = cast(fp127, 0)
let y = log(x)
output y=y
SRC
for f in sqrt_neg log_zero; do
  "$CC" "$TMP/$f.wh" -o "$TMP/$f" >/dev/null
  set +e; "$TMP/$f" >/dev/null 2>&1; st=$?; set -e
  [ "$st" -eq 65 ]
done


# 1.3.109 removes physical rediscovery rather than adding arithmetic families.
for dead in rpf_limbs_from_object rpf_copy_limbs rpf_shl1 rpf_shr1 rpf_shr_sticky rpf_shl_exact rpf_highlen32; do
  ! grep -q "^${dead}:" "$RPF"
done
sed -n '/^rankn_fp_div:/,/^\.global rankn_fp_div_u64/p' "$RPF" >"$TMP/div.inc"
! grep -q 'call rpf_highlen32' "$TMP/div.inc"
grep -q 'qn32 carried from quotient production' "$TMP/div.inc"
sed -n '/^rpf_nf_make_tw:/,/^rpf_nf_dif2:/p' "$RPF" >"$TMP/tw.inc"
grep -q 'j=0 is the exact unit twiddle' "$TMP/tw.inc"
sed -n '/^.rpfsc_double:/,/^.rpfsc_output:/p' "$RPF" >"$TMP/double.inc"
! grep -q 'call rankn_fp_add' "$TMP/double.inc"
[ "$(grep -c 'call rankn_fp_neg' "$TMP/sincos.inc")" -eq 0 ]

# 1.3.111 removes two remaining physical envelopes without adding a new arithmetic family.
# Knuth base-2^32 digits are real dwords all the way through U/V/Q; only Q64 is widened
# for the existing StrictClose carrier.  Quotient production also hands its already-known
# high-water bit to the same closure instead of asking it to rediscover the top globally.
sed -n '/^rankn_fp_div:/,/^\.global rankn_fp_div_u64/p' "$RPF" >"$TMP/div111.inc"
grep -q 'compact U\[ucap\]u32' "$TMP/div111.inc"
grep -q 'dword ptr \[r10+r9\*4\]' "$TMP/div111.inc"
grep -q 'call rpf_round_from_integer_known_top' "$TMP/div111.inc"
[ "$(grep -c 'call rpf_round_from_integer_known_top' "$RPF")" -eq 1 ]

# Object scratch is no longer the historical 512*N+4096 blanket.  Compiler allocation,
# decimal ingress and advanced mathematics share PrecisionFact/Fourier-derived geometry.
grep -q '^rpf_object_span:$' "$RPF"
! grep -q '^rpf_math_object_span:$' "$RPF"
grep -q '^g_rankn_fp_object_span:$' "$GF"
grep -q 'call g_rankn_fp_object_span' "$GF"
grep -q 'call rpf_object_span' "$ROOT/runtime/general_runtime_template_x86_64.S"
! grep -RqsE 'imul[[:space:]]+rax,rax,512|imul[[:space:]]+r[a-z0-9]+,r[a-z0-9]+,512' \
  "$GF" "$RPF" "$ROOT/runtime/general_runtime_template_x86_64.S"

# 1.3.112 consumes the already-existing tolerance contract as a proof bound
# inside the same Rank-N mathematical relations. Strict arithmetic primitives
# stay unique; no tolerant add/mul/div backend or fast-math selector is admitted.
grep -q 'js_fp_tol_mid:.asciz ",\\"floating_tolerance\\":"' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^g_tolerance_exp_from_f64_bits:$' "$GF"
grep -q 'cmp r10d,7; je .spte_fail' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^rpf_abs_lt_pow2:$' "$RPF"
grep -q '^rpf_abs_ratio_lt_pow2:$' "$RPF"
sed -n '/^rankn_fp_add:/,/^\.global rankn_fp_mul/p' "$RPF" >"$TMP/basic112.inc"
! grep -q 'ToleranceFact\|tolerance-active\|rpf_abs_.*pow2' "$TMP/basic112.inc"
sed -n '/^rankn_fp_sqrt:/,/^\.global rankn_fp_exp/p' "$RPF" >"$TMP/sqrt112.inc"
sed -n '/^rankn_fp_exp:/,/^\.global rankn_fp_log/p' "$RPF" >"$TMP/exp112.inc"
sed -n '/^rankn_fp_log:/,/^rpf_sincos_core:/p' "$RPF" >"$TMP/log112.inc"
sed -n '/^rpf_sincos_core:/,/^\.global rankn_fp_sin/p' "$RPF" >"$TMP/sincos112.inc"
grep -q 'call rpf_abs_lt_pow2' "$TMP/sqrt112.inc"
grep -q 'call rpf_abs_ratio_lt_pow2' "$TMP/exp112.inc"
grep -q 'call rpf_abs_lt_pow2' "$TMP/log112.inc"
[ "$(grep -c 'call rpf_abs_lt_pow2' "$TMP/sincos112.inc")" -eq 2 ]

cat >"$TMP/tol_strict.wh" <<'SRC'
program rankn_tolerance_strict
strict
input x: fp521
let a = sqrt(x)
let b = exp(x)
let c = log(x)
let d = sin(x)
let e = cos(x)
output a=a
output b=b
output c=c
output d=d
output e=e
SRC
cat >"$TMP/tol_bound.wh" <<'SRC'
program rankn_tolerance_bound
tolerance 1e-10
input x: fp521
let a = sqrt(x)
let b = exp(x)
let c = log(x)
let d = sin(x)
let e = cos(x)
output a=a
output b=b
output c=c
output d=d
output e=e
SRC
"$CC" "$TMP/tol_strict.wh" -o "$TMP/tol_strict" >/dev/null
"$CC" "$TMP/tol_bound.wh" -o "$TMP/tol_bound" >/dev/null
python3 - "$TMP" <<'PY112'
from fractions import Fraction
from pathlib import Path
import subprocess,sys
T=Path(sys.argv[1])
def parse(line):
    _,v=line.split('=',1)
    typ,sg,e,n,sig=v[2:].split(':')
    P=int(typ,16); E=int(e,16); E=E-(1<<64) if E>>63 else E
    S=int(sig,16)
    if not S: return Fraction(0)
    q=E-(P-1)
    x=Fraction(S)*(1<<q) if q>=0 else Fraction(S,1<<(-q))
    return -x if int(sg,16) else x
sv=subprocess.check_output([str(T/'tol_strict'),'1.23456789'],text=True).splitlines()
tv=subprocess.check_output([str(T/'tol_bound'),'1.23456789'],text=True).splitlines()
assert len(sv)==len(tv)==5
budget=Fraction(1,10_000_000_000)
changed=False
for s,t in zip(sv,tv):
    a,b=parse(s),parse(t)
    if a!=b: changed=True
    assert abs(a-b) <= budget + budget*abs(a),(s,t)
assert changed
print('RANKN_TOLERANCE_BOUND_1_3_112=PASS')
PY112

# No new language surface, named-width route, selector, JIT or second backend.
! grep -RqsE 'localfp|local_float|rankn_local_backend|math_precision_selector|transcendental_width_selector|local_propagation_selector' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools"
! grep -RIEqi --include='*.S' --include='*.inc' \
  '(sqrt|exp|log|sin|cos)_fp(65|113|127|128|191|256|521)|fp(65|113|127|128|191|256|521)_(sqrt|exp|log|sin|cos)|rankn_(jit|kernel_offload)' \
  "$ROOT/compiler" "$ROOT/runtime"

cat >"$TMP/local_tol_fp.wh" <<'SRC'
program local_tol_fp
input a: fp521 ~(abs=0.0,rel=0.0000000001)
output y=a
SRC
if "$CC" "$TMP/local_tol_fp.wh" -o "$TMP/local_tol_fp" >/dev/null 2>&1; then
  echo "parameterized fpP type-local tolerance was silently admitted" >&2
  exit 1
fi

printf '%s\n' \
  'RANKN_DEAD_CARRIER_AUTHORITIES_1_3_109=0' \
  'RANKN_DIVISION_GEOMETRY_RESCAN_1_3_109=0' \
  'RANKN_RNE_OVERFLOW_FULL_SHIFT_1_3_109=0' \
  'RANKN_ZERO_TWIDDLE_TRIG_1_3_109=0' \
  'RANKN_SINCOS_NEGATIVE_COPY_1_3_109=0' \
  'RANKN_BINDING_KIND_LIFETIME_1_3_109=PASS' \
  'RANKN_SCALAR_QUOTIENT_RELATION_1_3_109=PASS' \
  'RANKN_VALUE_SILENCE_AUTHORITY_1_3_109=PASS' \
  'RANKN_ZERO_RELATION_CLOSURE_1_3_109=PASS' \
  'RANKN_ADVANCED_LOCAL_PROPAGATION_1_3_109=PASS' \
  'SECOND_RANKN_MATH_BACKEND_1_3_109=0' \
  'RANKN_COMPACT_DIVISION_DIGITS_1_3_111=PASS' \
  'RANKN_EXACT_OBJECT_SPAN_1_3_111=PASS' \
  'RANKN_DIVISION_TOP_FACT_REUSE_1_3_111=PASS' \
  'RANKN_TYPE_LOCAL_TOLERANCE_SILENT_NOOP_1_3_112=0' \
  'RANKN_TOLERANCE_FACT_1_3_112=PASS' \
  'RANKN_TOLERANCE_STRICT_FALLBACK_1_3_112=PASS' \
  'SECOND_RANKN_TOLERANT_BACKEND_1_3_112=0'
