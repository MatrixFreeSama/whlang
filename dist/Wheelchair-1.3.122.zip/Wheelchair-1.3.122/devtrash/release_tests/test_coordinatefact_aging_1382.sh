#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1382_coord_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'RANKFACT_AGING_BUILD=PASS'

PR=compiler/physical_reality.inc
SRC=compiler/field_frontend_common_x86_64.S
RT=runtime/field_runtime_512_x86_64.S
for law in \
  PR_RANKFACT_DYNAMIC_AXIS_GEOMETRY,1 \
  PR_COORDINATEFACT_FIXED_CARRIER_WIDTH,0 \
  PR_AVX512_COORDINATE_OFFSET_STACK_AUTHORITY,0 \
  PR_COORDINATEFACT_SECOND_IR,0 \
  PR_COORDINATE_WORKLOAD_MATCHER,0; do
  k=${law%,*}; v=${law#*,}
  grep -q "^.equ $k,$v$" "$PR"
done
grep -q '^field_compute_offsets_f32:$' "$RT"
grep -q '^ff_runtime_offsets_va_for_access:$' "$SRC"
! grep -RqsE 'FIELD_RUNTIME_RANK_CAP|MAX_RANK|field_(prepare_coords|compute_offsets_from_coords|advance_coords|compute_offsets|load|store)_f32_r[1-8]\b' compiler runtime tools
echo 'RANKFACT_DYNAMIC_AXIS_SINGLE_AUTHORITY=PASS'

# Cross both historical fixed widths: rank 8 and the old dword selected-axis mask.
python3 - "$T" <<'PY'
import json,struct,sys
from pathlib import Path
D=Path(sys.argv[1])
for rank in (9,17,33):
    j={"format":"wheelchair.field/1","contracts":{"floating_point":"strict"},
       "fields":[{"mode":"input","type":"f32","rank":rank}],
       "accesses":[{"field":0,"delta":[0]*rank}],
       "ops":[{"op":"load","access":0,"dst":0},{"op":"reduce","src":0}]}
    (D/f'sum{rank}.json').write_text(json.dumps(j))
    ext=[1]*(rank-1)+[37]; st=[0]*rank; x=4
    for i in range(rank-1,-1,-1): st[i]=x; x*=ext[i]
    data_off=((64+16*rank+63)//64)*64
    b=bytearray(data_off); b[:8]=b'WHFLD217'
    struct.pack_into('<II',b,8,2,1); struct.pack_into('<Q',b,16,rank)
    struct.pack_into('<Q',b,24,data_off); struct.pack_into('<Q',b,32,37)
    for i,v in enumerate(ext): struct.pack_into('<Q',b,64+8*i,v)
    so=64+8*rank
    for i,v in enumerate(st): struct.pack_into('<Q',b,so+8*i,v)
    (D/f'in{rank}.whfld').write_bytes(b+b''.join(struct.pack('<f',1.0) for _ in range(37)))
PY
for rank in 9 17 33; do
  build/fieldc "$T/sum${rank}.json" -o "$T/sum${rank}" >/dev/null
  [ "$("$T/sum${rank}" "$T/in${rank}.whfld")" = 'checksum_f32_bits=0x42140000' ]
  build/fieldc-native256 "$T/sum${rank}.json" -o "$T/sum${rank}_256" >/dev/null
  [ "$("$T/sum${rank}_256" "$T/in${rank}.whfld")" = 'checksum_f32_bits=0x42140000' ]
done
echo 'FIELD_RANKFACT_9_17_33=PASS'

# Non-power-of-two padded Rank-3 field forces generic mixed-radix coordinates.
python3 - "$T/padded.whfld" <<'PY'
import struct,sys
out=sys.argv[1]; rank=3; ext=(3,5,37); st=(1592,312,8); data_off=128
b=bytearray(data_off); b[:8]=b'WHFLD217'
struct.pack_into('<II',b,8,2,1); struct.pack_into('<Q',b,16,rank)
struct.pack_into('<Q',b,24,data_off); struct.pack_into('<Q',b,32,3*5*37)
for i,v in enumerate(ext): struct.pack_into('<Q',b,64+8*i,v)
for i,v in enumerate(st): struct.pack_into('<Q',b,64+8*rank+8*i,v)
span=(ext[0]-1)*st[0]+(ext[1]-1)*st[1]+(ext[2]-1)*st[2]+4
data=bytearray(span)
for i in range(ext[0]):
  for j in range(ext[1]):
    for k in range(ext[2]): struct.pack_into('<f',data,i*st[0]+j*st[1]+k*st[2],1.0)
open(out,'wb').write(b+data)
PY
build/fieldc devtrash/tests/field_1216/sum.json -o "$T/sum512" >/dev/null
[ "$("$T/sum512" "$T/padded.whfld")" = 'checksum_f32_bits=0x440ac000' ]
build/fieldc-native256 devtrash/tests/field_1216/sum.json -o "$T/sum256" >/dev/null
[ "$("$T/sum256" "$T/padded.whfld")" = 'checksum_f32_bits=0x440ac000' ]
echo 'NONPOW2_GENERIC_COORDINATE_RELATION=PASS'

# Genuine boundary access must still remain a gather, without zmm17 stack roundtrip.
build/fieldc devtrash/benchmarks/real_sparse_1326/miniamr7.json -o "$T/amr" >/dev/null
read off va sz <<EOF
$(readelf -lW "$T/amr" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOF
dd if="$T/amr" of="$T/gen.bin" bs=1 skip=$((off)) count=$((sz)) status=none
objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$T/gen.bin" > "$T/gen.dis"
grep -q 'vgatherdps' "$T/gen.dis"
! grep -Eq 'vmovups[[:space:]]+ZMMWORD PTR \[rsp[^]]*\],zmm17' "$T/gen.dis"
! grep -Eq 'vmovups[[:space:]]+zmm17,ZMMWORD PTR \[rsp' "$T/gen.dis"
echo 'AVX512_OFFSET_STACK_ROUNDTRIP=0'
echo 'TRUE_STRADDLING_GATHER_PRESERVED=PASS'

! grep -RqsE 'coordinate[ _-]*(optimizer|scheduler|manager)|boundary[ _-]*coordinate[ _-]*(route|matcher)|(^|[^A-Za-z])(poisson|stencil|miniAMR|miniFE)[_-]?(coordinate|matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'fixed[ _-]*coordinate[ _-]*(tile|window|chunk)|coordinate[ _-]*work[ _-]*steal' compiler runtime surface tools
echo 'COORDINATE_SECOND_OPTIMIZER=0'
echo 'COORDINATE_WORKLOAD_ROUTE=0'
echo 'WHEELCHAIR_RANKFACT_AGING_1_3_110=PASS'
