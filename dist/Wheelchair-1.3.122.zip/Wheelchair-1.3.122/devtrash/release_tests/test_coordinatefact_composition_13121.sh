#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
T=${TMPDIR:-/tmp}/wheelchair_coord13121_$$
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T"

BASE="$ROOT/compiler/tensor_frontend_x86_64.S"
BASE256="$ROOT/compiler/tensor_frontend_native256_x86_64.S"
DER="$ROOT/compiler/tensor_derived_frontend_x86_64.S"

# One CoordinateFact algebra owns strict indexed-map composition on both native widths.
for F in "$BASE" "$BASE256"; do
  grep -q '^vec_axis_compose_key:' "$F"
  grep -q '^vec_emit_periodic_key:' "$F"
  grep -q 'vec_axis_root_mod' "$F"
  ! grep -Eq 'structural_inflation|curve_12|deep_pairs|benchmark[_ -]?route' "$F"
done

# Arbitrary software slot partitions age into the real shared ZMM16..25 Fact pool.
grep -q '^.equ VEC_FACT_REG_FIRST,16$' "$DER"
grep -q '^.equ VEC_FACT_REG_LAST,25$' "$DER"
grep -q '^.equ DERIVED_PERSISTENT_FACT_CAP,VEC_FACT_REG_LAST-VEC_FACT_REG_FIRST+1$' "$DER"
! grep -Eq 'vec_(induct_coeff|dense_shift|dense_mask|dense_reg|mixed_stride|mixed_extent|mixed_reg|dense_scaled_slot|dense_scaled_coeff|dense_scaled_reg|dense_patch):.skip [26]\*' "$DER"
# Native256 carried a zero-count induction table with no producer; it is deleted rather than enlarged.
! grep -q 'vec_induct_' "$ROOT/compiler/tensor_derived_frontend_native256_x86_64.S"

# Retired heuristic/legacy constants do not survive under a new name.
! grep -Rqs 'front_end_budget' "$ROOT/compiler"
! grep -Rqs 'MUTABLE_SLOT_BYTES' "$ROOT/compiler" "$ROOT/runtime"
for F in "$ROOT/runtime/field_runtime_512_x86_64.S" "$ROOT/runtime/field_runtime_256_x86_64.S"; do
  ! grep -q '8388608' "$F"
  ! grep -q 'g_random_read_pressure' "$F"
  ! grep -q 'cmp r13d,32' "$F"
done

cat > "$T/zero.whex" <<'WH'
program coord_zero
strict
input n: u64 range 8192..20000000
field x0[i in n]: f64 = cast(f64, i % 4096)
sum checksum[i in n]: f64 = x0[i]
output checksum
WH

# 64 exact inverse pairs: source depth is not a physical-register cardinality.
{
  printf '%s\n' 'program coord_deep' 'strict' 'input n: u64 range 8192..20000000' 'field x0[i in n]: f64 = cast(f64, i % 4096)'
  k=0
  p=0
  while [ "$p" -lt 64 ]; do
    k=$((k+1)); printf 'field x%d[i in n]: f64 = x%d[(i + 17) %% n]\n' "$k" "$((k-1))"
    k=$((k+1)); printf 'field x%d[i in n]: f64 = x%d[(i + n - 17) %% n]\n' "$k" "$((k-1))"
    p=$((p+1))
  done
  printf 'sum checksum[i in n]: f64 = x%d[i]\noutput checksum\n' "$k"
} > "$T/deep.whex"

"$ROOT/bin/whexc" "$T/zero.whex" -o "$T/zero" >/dev/null
"$ROOT/bin/whexc" "$T/deep.whex" -o "$T/deep" >/dev/null
[ "$("$T/zero" 10000)" = "$("$T/deep" 10000)" ]
[ "$(sha256sum "$T/zero" | awk '{print $1}')" = "$(sha256sum "$T/deep" | awk '{print $1}')" ]

# Non-identity composition must also collapse: 32*(+17) == +544 in Z/nZ.
{
  printf '%s\n' 'program coord_chain' 'strict' 'input n: u64 range 8192..20000000' 'field x0[i in n]: f64 = cast(f64, i % 4096)'
  k=0
  while [ "$k" -lt 32 ]; do
    j=$((k+1)); printf 'field x%d[i in n]: f64 = x%d[(i + 17) %% n]\n' "$j" "$k"; k=$j
  done
  printf 'sum checksum[i in n]: f64 = x%d[i] * x0[i]\noutput checksum\n' "$k"
} > "$T/chain.whex"
cat > "$T/direct.whex" <<'WH'
program coord_direct
strict
input n: u64 range 8192..20000000
field x0[i in n]: f64 = cast(f64, i % 4096)
field x1[i in n]: f64 = x0[(i + 544) % n]
sum checksum[i in n]: f64 = x1[i] * x0[i]
output checksum
WH
"$ROOT/bin/whexc" "$T/chain.whex" -o "$T/chain" >/dev/null
"$ROOT/bin/whexc" "$T/direct.whex" -o "$T/direct" >/dev/null
[ "$("$T/chain" 10000)" = "$("$T/direct" 10000)" ]
[ "$(sha256sum "$T/chain" | awk '{print $1}')" = "$(sha256sum "$T/direct" | awk '{print $1}')" ]

# Signed residue representatives stay in the same ring materializer.
cat > "$T/negative.whex" <<'WH'
program coord_negative
strict
input n: u64 range 8192..20000000
field x0[i in n]: f64 = cast(f64, i % 4096)
field x1[i in n]: f64 = x0[(i + n - 17) % n]
sum checksum[i in n]: f64 = x1[i] * x0[i]
output checksum
WH
"$ROOT/bin/whexc" "$T/negative.whex" -o "$T/negative" >/dev/null
[ "$("$T/negative" 10000)" = 'checksum_bits=0x422618d85ec00000' ]

printf '%s\n' \
  'COORDINATEFACT_COMPOSITION_DEPTH_WALL=0' \
  'COORDINATEFACT_IDENTITY_ELIMINATION=PASS' \
  'COORDINATEFACT_NONIDENTITY_COMPOSITION=PASS' \
  'COORDINATEFACT_SIGNED_RESIDUE_NORMALIZATION=PASS' \
  'DERIVED_PRIVATE_6_2_SLOT_PARTITIONS=0' \
  'FRONTEND_SIMD_BYTE_BUDGET_ALIAS=0' \
  'FIELD_NT_8M_2X_4X_SELECTOR=0' \
  'WORKLOAD_SPECIFIC_COORDINATE_ROUTE=0' \
  'WHEELCHAIR_COORDINATEFACT_COMPOSITION_1_3_121=PASS'
