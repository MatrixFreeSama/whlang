#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair13104_execution_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
PR=compiler/physical_reality.inc
SR=compiler/silicon_reality.inc
for law in \
  PR_INVOCATION_AFFINITY_REFRESHES_EXECUTION_ADMISSION,1 \
  PR_COMPILE_HOST_WIDTH_IS_IMAGE_AUTHORITY,0 \
  PR_ADMISSION_FAILURE_USES_COMPILE_HOST_WIDTH,0 \
  PR_STATIC_PLACEMENT_INTERSECTS_INVOCATION_AFFINITY,1 \
  PR_STATIC_PLACEMENT_MAY_EXPAND_INVOCATION_AFFINITY,0 \
  PR_STRICT_REDUCTION_INVARIANT_TO_EXECUTION_CARDINALITY,1 \
  PR_ARBITRARY_CARDINALITY_LAUNCH_FRONTIER,1 \
  PR_POWER_OF_TWO_LAUNCH_FRONTIER,0 \
  PR_COMPLETION_LOCAL_SIBLING_EXPOSURE,1 \
  PR_GLOBAL_READY_QUEUE_FOR_SIBLING_EXPOSURE,0 \
  PR_READY_ROOT_FRONTIER_FUSED_BEFORE_MATERIALIZATION,1 \
  PR_FRONTIER_FUSION_BYPASSES_WORK_LIFECYCLE_COST,0 \
  PR_POST_MATERIALIZATION_ROOT_TRANSFER,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$PR"
done
for law in \
  SR_INVOCATION_AFFINITY_REFRESHES_EXECUTION_ADMISSION,1 \
  SR_COMPILE_HOST_WIDTH_IS_IMAGE_AUTHORITY,0 \
  SR_ADMISSION_FAILURE_USES_COMPILE_HOST_WIDTH,0 \
  SR_STATIC_PLACEMENT_INTERSECTS_INVOCATION_AFFINITY,1 \
  SR_STATIC_PLACEMENT_MAY_EXPAND_INVOCATION_AFFINITY,0 \
  SR_STRICT_REDUCTION_INVARIANT_TO_EXECUTION_CARDINALITY,1 \
  SR_ARBITRARY_CARDINALITY_LAUNCH_FRONTIER,1 \
  SR_POWER_OF_TWO_LAUNCH_FRONTIER,0 \
  SR_COMPLETION_LOCAL_SIBLING_EXPOSURE,1 \
  SR_RUNTIME_READY_QUEUE,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$SR"
done
[ -f runtime/execution_admission_refresh_x86_64.inc ]
grep -q '^.macro CONSTRAIN_STATIC_PLACEMENT_WITHIN_INVOCATION required, mask_bytes, mask$' runtime/execution_admission_refresh_x86_64.inc
grep -q '^.macro REFRESH_EXECUTION_ADMISSION target$' runtime/execution_admission_refresh_x86_64.inc
grep -q '^.equ RUNTIME_AFFINITY_SEED_BYTES,128$' runtime/execution_admission_refresh_x86_64.inc
grep -q 'cmp eax,-ERRNO_EINVAL' runtime/execution_admission_refresh_x86_64.inc
grep -q 'shl r10,1' runtime/execution_admission_refresh_x86_64.inc
! grep -q 'RUNTIME_AFFINITY_MASK_BYTES' runtime/execution_admission_refresh_x86_64.inc
grep -q '^sd_count_external_affinity:$' compiler/silicon_domain_probe_x86_64.S
grep -q 'SD_AFFINITY_SEED_BYTES' compiler/silicon_domain_probe_x86_64.S
for S in runtime/tensor_runtime_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  grep -q 'CONSTRAIN_STATIC_PLACEMENT_WITHIN_INVOCATION static_placement_required_patch, static_placement_mask_bytes_patch, static_placement_mask_patch' "$S"
  grep -q 'REFRESH_EXECUTION_ADMISSION execution_admission_patch' "$S"
  sed -n '/^run_region_frontier:/,/^# reduce_region_results/p' "$S" > "$T/frontier"
  ! grep -Eq '[[:space:]]bsr[[:space:]]' "$T/frontier"
  grep -q 'inc r8' "$T/frontier"
  grep -q 'shr r8,1' "$T/frontier"
done
grep -q '^gr_read_invocation_admission:$' runtime/general_parallel_release_x86_64.S
grep -q 'mov dword ptr \[rax+20\],ecx' runtime/general_parallel_release_x86_64.S
grep -q 'mov ecx,dword ptr \[rax+20\]' runtime/general_parallel_release_x86_64.S
grep -q '^.equ ST_NODE_LOCAL_NEXT, 8$' runtime/general_parallel_release_x86_64.S
grep -q '^.equ ST_NODE_FRONTIER_TAIL, 12$' runtime/general_parallel_release_x86_64.S
grep -q '^.equ ST_NODE_FRONTIER_ANCHOR_NEXT, 16$' runtime/general_parallel_release_x86_64.S
grep -q '^gr_materialize_chain:$' runtime/general_parallel_release_x86_64.S
grep -q '^gr_node_chain_task:$' runtime/general_parallel_release_x86_64.S
sed -n '/^.gr_root_count_cost:/,/^.gr_root_count_next:/p' runtime/general_parallel_release_x86_64.S > "$T/root_cost"
grep -q 'call gr_should_materialize' "$T/root_cost"
grep -q '^.gpc_ready_exposed:$' runtime/general_parallel_release_x86_64.S
! grep -q 'cmp dword ptr \[rip+execution_admission_capacity\],1' compiler/general_frontend_x86_64.S
! grep -RqsE 'runtime_(ready_queue|work_steal)|g_(ready_queue|work_steal)|worker_pool' compiler runtime surface tools
S=devtrash/tests/general_whole_episode_1316/mass3.wh
bin/wheelchairc "$S" -o "$T/full" >/dev/null
cpu=$(python3 -c 'import os; print(min(os.sched_getaffinity(0)))')
taskset -c "$cpu" bin/wheelchairc "$S" -o "$T/one" >/dev/null
[ "$(stat -c %s "$T/full")" = "$(stat -c %s "$T/one")" ]
[ "$("$T/full" 100000)" = 'out00_bits=0x3fa90c89b2e19b14' ]
[ "$("$T/one" 100000)" = 'out00_bits=0x3fa90c89b2e19b14' ]
printf '%s\n' \
  'INVOCATION_BOUND_EXECUTION_ADMISSION=PASS' \
  'COMPILE_HOST_WIDTH_IMAGE_AUTHORITY=0' \
  'STATIC_PLACEMENT_MAY_EXPAND_INVOCATION_AFFINITY=0' \
  'STRICT_REDUCTION_EXECUTION_CARDINALITY_INVARIANT=PASS' \
  'POWER_OF_TWO_LAUNCH_FRONTIER=0' \
  'ARBITRARY_CARDINALITY_LAUNCH_FRONTIER=PASS' \
  'COMPLETION_LOCAL_SIBLING_EXPOSURE=PASS' \
  'COST_GATED_ROOT_FRONTIER_FUSION=PASS' \
  'POST_MATERIALIZATION_ROOT_TRANSFER=0' \
  'GLOBAL_READY_QUEUE=0' \
  'WORK_STEALING=0' \
  'WHEELCHAIR_EXECUTION_REALIZATION_1_3_104=PASS'
