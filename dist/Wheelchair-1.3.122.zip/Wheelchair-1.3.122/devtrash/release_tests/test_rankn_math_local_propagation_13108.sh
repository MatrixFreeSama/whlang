#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

[ "$(cat "$ROOT/VERSION")" = "1.3.108" ]
RPF="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
GF="$ROOT/compiler/general_frontend_x86_64.S"

# The fpP declaration kind is stable storage across inference/physicalization;
# no caller-saved register is allowed to carry it through the Rank-N type path.
sed -n '/^\.binding_decl_loop:/,/^\.binding_decl_done:/p' "$GF" >"$TMP/decl.inc"
grep -q 'mov dword ptr \[rsp\],eax' "$TMP/decl.inc"
grep -q 'mov edx,dword ptr \[rsp\]' "$TMP/decl.inc"
! grep -q 'mov r11d,eax' "$TMP/decl.inc"

# Constant/cast fpP materialization must survive the same general frontend path.
cat >"$TMP/cast.wh" <<'SRC'
program rankn_cast_regression
precision_propagation 1
let one = cast(fp127, 1)
let two: fp127 = 2
let y = one + two
output y=y
SRC
"$CC" "$TMP/cast.wh" -o "$TMP/cast" >/dev/null
[[ "$("$TMP/cast")" == out00_rankn_fp=0x000000000000007f:* ]]

# Advanced local propagation keeps scalar series denominators as scalar facts.
grep -q '^\.global rankn_fp_div_u64$' "$RPF"
grep -q '^rpf_value_equal:$' "$RPF"
sed -n '/^rankn_fp_exp:/,/^rankn_fp_log:/p' "$RPF" >"$TMP/exp.inc"
sed -n '/^rankn_fp_log:/,/^rpf_sincos_core:/p' "$RPF" >"$TMP/log.inc"
sed -n '/^rpf_sincos_core:/,/^rankn_fp_sin:/p' "$RPF" >"$TMP/sincos.inc"
[ "$(grep -c 'call rankn_fp_div_u64' "$TMP/exp.inc")" -eq 1 ]
[ "$(grep -c 'call rankn_fp_div_u64' "$TMP/log.inc")" -eq 1 ]
[ "$(grep -c 'call rankn_fp_div_u64' "$TMP/sincos.inc")" -eq 4 ]
grep -q 'call rpf_value_equal' "$TMP/exp.inc"
grep -q 'call rpf_value_equal' "$TMP/log.inc"
[ "$(grep -c 'call rpf_value_equal' "$TMP/sincos.inc")" -eq 2 ]

# Representative native mathematics remains within the established local
# propagation contract. Type identity is now the interned precision fact, not
# the retired encoded-width bit field.
for p in 65 127 521; do
cat >"$TMP/math_$p.wh" <<SRC
program math_$p
precision_propagation 1
let one = cast(fp$p, 1)
let two = cast(fp$p, 2)
let a = sqrt(two)
let b = exp(one)
let c = log(two)
let d = sin(one)
let e = cos(one)
output a=a
output b=b
output c=c
output d=d
output e=e
SRC
"$CC" "$TMP/math_$p.wh" -o "$TMP/math_$p" >/dev/null
done
python3 - "$TMP" <<'PY'
from pathlib import Path
import subprocess,sys
T=Path(sys.argv[1])
EXPECTED={
65:[(0,0x16a09e667f3bcc909),(1,0x15bf0a8b145769535),(-1,0x162e42fefa39ef358),(-1,0x1aed548f090cee042),(-1,0x114a280fb5068b924)],
127:[(0,0x5a827999fcef32422cbec4d9baa55f50),(1,0x56fc2a2c515da54d57ee2b10139e9e79),(-1,0x58b90bfbe8e7bcd5e4f1d9cc01f97b58),(-1,0x6bb5523c2433b8106374f484e2879e19),(-1,0x4528a03ed41a2e48e12336cbb438de95)],
521:[(0,int('16a09e667f3bcc908b2fb1366ea957d3e3adec17512775099da2f590b0667322a95f90608757145875163fcdfb907b6721ee950bc8738f694f0090e6c7bf44ed1a4',16)),(1,int('15bf0a8b1457695355fb8ac404e7a79e3b1738b079c5a6d2b53c26c8228c867f799273b9c49367df2fa5fc6c6c618ebb1ed0364055d88c2f5a7be3dababfacac248',16)),(-1,int('162e42fefa39ef35793c7673007e5ed5e81e6864ce5316c5b141a2eb71755f457cf70ec40dbd75930ab2aa5f695f43621da5d5c6b827042884eae765222d3704a7d',16)),(-1,int('1aed548f090cee0418dd3d2138a1e786513ca22265ea3169bdf6d94bfad8c937bf617b3fe3db9a8aeecab6b04d47a76a184c6aac6bbfa19d7fd134c4a19d6082e52',16)),(-1,int('114a280fb5068b923848cdb2ed0e37a53446e75129f2d876fe46004816ec1cdf52d5288614a5a1d3c87e68a1c771ff33792688083b70404092c0df446a568c6eaf7',16))],
}
def s64(x): return x-(1<<64) if x>>63 else x
def parse(line):
    _,v=line.split('=',1); typ,sg,e,n,sig=v[2:].split(':')
    return int(typ,16),int(sg,16),s64(int(e,16)),int(n,16),int(sig,16)
for p in (65,127,521):
    lines=subprocess.check_output([str(T/f'math_{p}')],text=True).splitlines()
    assert len(lines)==5,(p,lines)
    for i,(line,(ee,esig)) in enumerate(zip(lines,EXPECTED[p])):
        typ,sg,e,n,sig=parse(line)
        assert typ==p and sg==0 and e==ee,(p,i,line)
        assert abs(sig-esig)<=4,(p,i,sig-esig)
print('RANKN_MATH_LOCAL_ORACLE_1_3_108=PASS')
PY

# Zero relations close in the shared arithmetic primitives rather than growing
# per-function special cases.  These were crash cases in 1.3.107.
for spec in 'sqrt 0' 'exp 0' 'log 1' 'sin 0' 'cos 0'; do
  set -- $spec; f=$1; x=$2
  cat >"$TMP/id_${f}.wh" <<SRC
program id_${f}
precision_propagation 1
input x: fp127
let y = $f(x)
output y=y
SRC
  "$CC" "$TMP/id_${f}.wh" -o "$TMP/id_${f}" >/dev/null
  "$TMP/id_${f}" "$x" >/dev/null
done

# Domain rejection remains deterministic.
cat >"$TMP/sqrt_neg.wh" <<'SRC'
program sqrt_negative
precision_propagation 1
let x = cast(fp127, -1)
let y = sqrt(x)
output y=y
SRC
cat >"$TMP/log_zero.wh" <<'SRC'
program log_zero
precision_propagation 1
let x = cast(fp127, 0)
let y = log(x)
output y=y
SRC
for f in sqrt_neg log_zero; do
  "$CC" "$TMP/$f.wh" -o "$TMP/$f" >/dev/null
  set +e; "$TMP/$f" >/dev/null 2>&1; st=$?; set -e
  [ "$st" -eq 65 ]
done

# No new language surface, named-width route, selector, JIT or second backend.
! grep -RqsE 'localfp|local_float|rankn_local_backend|math_precision_selector|transcendental_width_selector|local_propagation_selector' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools"
! grep -RIEqi --include='*.S' --include='*.inc' \
  '(sqrt|exp|log|sin|cos)_fp(65|113|127|128|191|256|521)|fp(65|113|127|128|191|256|521)_(sqrt|exp|log|sin|cos)|rankn_(jit|kernel_offload)' \
  "$ROOT/compiler" "$ROOT/runtime"

printf '%s\n' \
  'RANKN_BINDING_KIND_LIFETIME_1_3_108=PASS' \
  'RANKN_SCALAR_QUOTIENT_RELATION_1_3_108=PASS' \
  'RANKN_VALUE_SILENCE_AUTHORITY_1_3_108=PASS' \
  'RANKN_ZERO_RELATION_CLOSURE_1_3_108=PASS' \
  'RANKN_ADVANCED_LOCAL_PROPAGATION_1_3_108=PASS' \
  'SECOND_RANKN_MATH_BACKEND_1_3_108=0'
