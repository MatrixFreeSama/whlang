#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# Precision is a u64 program fact, not a payload hidden in the semantic type ID.
# The first value above the historical 30-bit mask must compile without a
# dedicated width route or a replacement larger precision constant.
cat >"$TMP/wall.wh" <<'SRC'
program rankn_old_precision_wall
input x: fp1073741824
output x = x
SRC
"$CC" "$TMP/wall.wh" -o "$TMP/wall" >/dev/null
[ -x "$TMP/wall" ]

# Runtime lookup consumes the exact program trailer and canonical output exposes
# precision itself rather than the compiler-internal interned type identity.
cat >"$TMP/p65.wh" <<'SRC'
program p65
input x: fp65
output x = x
SRC
"$CC" "$TMP/p65.wh" -o "$TMP/p65" >/dev/null
[[ "$("$TMP/p65" 1.5)" == out00_rankn_fp=0x0000000000000041:* ]]

# Multiple unrelated precisions coexist in one intern domain. Existing meet
# policy remains the sole propagation authority; no named-width selector is born.
cat >"$TMP/mixed.wh" <<'SRC'
program mixed_rankn_precision_facts
precision_propagation 1
input a: fp65
input b: fp521
let x = a + b
output x = x
SRC
"$CC" "$TMP/mixed.wh" -o "$TMP/mixed" >/dev/null
[[ "$("$TMP/mixed" 1 2)" == out00_rankn_fp=0x0000000000000209:* ]]

PROD=("$ROOT/compiler" "$ROOT/runtime" "$ROOT/tools")
if grep -RIE --include='*.S' --include='*.inc' --include='*.sh' \
  'GTYPE_RANKN_FP_(FLAG|MASK)|RPF_TYPE_(FLAG|MASK)|0x3fffffff|1073741823' "${PROD[@]}"; then
  echo rankn_precision_bitfield_ceiling_survived >&2
  exit 1
fi
if grep -RIE --include='*.S' --include='*.inc' '\bRPF_N\b' "$ROOT/runtime"; then
  echo stored_rankn_limb_count_survived >&2
  exit 1
fi

grep -q '^g_intern_rankn_precision:$' "$ROOT/compiler/general_frontend_x86_64.S"
grep -q '^g_rankn_type_precisions_ptr:.skip 8$' "$ROOT/compiler/general_frontend_x86_64.S"
grep -q '^rankn_type_count_patch:' "$ROOT/runtime/general_runtime_template_x86_64.S"
grep -q '^rankn_precision_ptr:' "$ROOT/runtime/general_runtime_template_x86_64.S"
grep -q '^.equ RPF_PREC,8$' "$ROOT/runtime/rankn_precision_physical_x86_64.inc"
grep -q '^.equ RPF_TYPE_BASE,TYPE_STATIC_LAST+1$' "$ROOT/runtime/rankn_precision_physical_x86_64.inc"

echo RANKN_PRECISION_FACT_AGING_1_3_105=PASS
