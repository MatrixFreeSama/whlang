#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"

TC=compiler/tensor_frontend_common_blocks.inc
TP=compiler/tensor_frontend_profile_blocks.inc
FC=runtime/field_runtime_common_blocks.inc
[ -f "$TC" ]
[ -f "$TP" ]
[ -f "$FC" ]

# One compile-time authority owns ISA/profile-independent Tensor bodies.
for F in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_derived_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  grep -q 'compiler/tensor_frontend_common_blocks.inc' "$F"
  grep -q 'compiler/tensor_frontend_profile_blocks.inc' "$F"
  grep -q '^json_parse_value:$' "$F"
  grep -q '^TFC_json_parse_value$' "$F"
  grep -q '^vec_linear_collect:$' "$F"
  grep -q '^TFC_vec_linear_collect$' "$F"
done
grep -q '^\.macro TFC_json_parse_value$' "$TC"
grep -q '^\.macro TFC_vec_linear_collect$' "$TC"

# Profile differences are compile-time physical facts, not four copied frontends.
grep -q '^\.macro TFP_02_emit_int_reg$' "$TP"
grep -q '^\.macro TFP_13_emit_int_reg$' "$TP"
! grep -RqsE 'runtime[ _-]*(isa|profile)[ _-]*(selector|dispatcher)|workload[ _-]*(isa|profile)[ _-]*(route|matcher)' \
  compiler/tensor_frontend*_x86_64.S "$TC" "$TP"

# Field runtime keeps proof-bearing frontier/reduction authorities explicit but
# shares proof-neutral 256/512 bodies exactly once.
for F in runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  grep -q 'runtime/field_runtime_common_blocks.inc' "$F"
  grep -q '^map_one_field:$' "$F"
  grep -q '^FRC_map_one_field$' "$F"
  grep -q '^run_region_frontier:$' "$F"
  grep -q '^reduce_region_results:$' "$F"
done
grep -q '^\.macro FRC_map_one_field$' "$FC"
! grep -q '^\.macro FRC_run_region_frontier$' "$FC"
! grep -q '^\.macro FRC_reduce_region_results$' "$FC"

# One runtime linker script is sufficient; build/ is generated, never a source authority.
[ ! -e runtime/field_runtime.ld ]
[ "$(grep -c -- '-T runtime/tensor_runtime.ld' build.sh)" -eq 6 ]
! find compiler runtime surface tools -type f -name '*.pre122' -print | grep -q .

printf '%s\n' \
  'TENSOR_PARALLEL_BODY_AUTHORITIES=1' \
  'TENSOR_RUNTIME_PROFILE_DISPATCH=0' \
  'FIELD_RUNTIME_PROOF_NEUTRAL_BODY_AUTHORITIES=1' \
  'DUPLICATE_FIELD_LINKER_SCRIPT=0' \
  'WORKLOAD_SPECIFIC_SOURCE_ROUTE=0' \
  'WHEELCHAIR_PARALLEL_SOURCE_CONVERGENCE_1_3_122=PASS'
