#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair13104_limits_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

D=compiler/native_driver_x86_64.S
A=runtime/execution_admission_refresh_x86_64.inc
S=compiler/surface_lowerer_x86_64.S
TOP=compiler/topologyc_x86_64.S

# Driver capacity is derived from process-start argv and mmap-sized path facts.
! grep -Eq 'argv_copy|exe_path:[[:space:]]*\.skip|selected_path:[[:space:]]*\.skip' "$D"
grep -q 'mov \[r13\],rax' "$D"
grep -q 'MAP_PRIVATE_ANON' "$D"
grep -q '^.nd_path_probe:$' "$D"

# Affinity width grows from a seed on kernel EINVAL; the seed is not a ceiling.
grep -q '^.equ RUNTIME_AFFINITY_SEED_BYTES,128$' "$A"
grep -q 'cmp eax,-ERRNO_EINVAL' "$A"
grep -q 'shl r10,1' "$A"
! grep -q 'RUNTIME_AFFINITY_MASK_BYTES' "$A"

# Architectural CPUID termination owns topology/cache enumeration.
sed -n '/^.dctopo_loop:/,/^.dctopo_fallback:/p' "$TOP" > "$T/topology"
! grep -Eq 'cmp r9d,[[:space:]]*8' "$T/topology"
sed -n '/^.dct_loop:/,/^.dct_pop:/p' "$TOP" > "$T/cache"
! grep -Eq 'cmp r9d,[[:space:]]*32' "$T/cache"

# Historical semantic walls are absent. Representation-derived frontiers remain explicit.
# Field rank is an invocation RankFact, not a fixed file/runtime/compiler width.
! grep -RqsE 'FIELD_RUNTIME_RANK_CAP|MAX_RANK|WHFLD216|field_(prepare_coords|compute_offsets_from_coords|advance_coords|compute_offsets|load|store)_f32_r[1-8]\b' compiler runtime tools
grep -q 'WHFLD217' runtime/field_runtime_512_x86_64.S
grep -q '^field_compute_offsets_f32:$' runtime/field_runtime_512_x86_64.S

! grep -q 'cmp rax,255' "$S"
! grep -q 'cmp eax,255' "$S"
! grep -q 'cmp edi,255' "$S"
sed -n '/^s_expand_zeta_ast:/,/^s_expand_polylog_ast:/p' "$S" > "$T/zeta_src"
! grep -Eq 'cmp rax,32|cmp r14d,32' "$T/zeta_src"
sed -n '/^s_expand_polylog_ast:/,/^s_expand_gamma_ast:/p' "$S" > "$T/poly_src"
! grep -Eq 'cmp rax,16|cmp r14d,16' "$T/poly_src"
sed -n '/^.semb_tetration:/,/^.semb_tetration_done:/p' "$S" > "$T/tetr_src"
! grep -Eq 'cmp rax,8|cmp r14d,8' "$T/tetr_src"

cat > "$T/zeta33.wh" <<'SRC'
program zeta33
let x: f64 = zeta(33)
output x = x
SRC
cat > "$T/poly17.wh" <<'SRC'
program poly17
let x: f64 = polylog(17,0.5)
output x = x
SRC
cat > "$T/tetr9.wh" <<'SRC'
program tetr9
let x: f64 = tetration(1.0,9)
output x = x
SRC
for n in zeta33 poly17 tetr9; do
  bin/wheelchairc "$T/$n.wh" -o "$T/$n" >/dev/null
  [ -x "$T/$n" ]
done
[ "$("$T/tetr9")" = 'out00_bits=0x3ff0000000000000' ]

printf '%s\n' \
  'FIXED_ARGV_CAPACITY=0' \
  'FIXED_PATH_CAPACITY=0' \
  'FIXED_AFFINITY_WIDTH=0' \
  'CPUID_ENUMERATION_FUSE=0' \
  'MATRIX_255_DIMENSION_WALL=0' \
  'ZETA_32_EXPONENT_WALL=0' \
  'POLYLOG_16_EXPONENT_WALL=0' \
  'TETRATION_8_HEIGHT_WALL=0' \
  'FIELD_FIXED_RANK_WALL=0' \
  'WHEELCHAIR_HARD_LIMIT_AGING_1_3_104=PASS'
