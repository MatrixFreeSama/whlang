#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP=${TMPDIR:-/tmp}/wheelchair_tensor13104_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
SRC="$ROOT/compiler/tensor_derived_frontend_x86_64.S"

# Existing arbitrary-radix CoordinateFact recurrence stays the sole coordinate authority.
grep -q '^vec_mixed_chain_preflight:' "$SRC"
grep -q '^vec_mixed_emit_step_chain:' "$SRC"
grep -q '^vec_mixed_find_direct_residue:' "$SRC"
grep -q '^vec_mixed_emit_step:' "$SRC"
grep -q '^vec_mixed_scaled_refresh:' "$SRC"

# 1.3.104: logical scaled-fact identity survives physical register allocation.
grep -q 'mov r13d,ecx.*logical scaled-fact slot survives physical-reg allocation' "$SRC"
grep -q 'lea eax,\[r13d+1\]; mov dword ptr \[rip+vec_dense_scaled_count\],eax' "$SRC"


# 1.3.104: profiling/CSE storage follows optimizer instance cardinality, not 16/64-slot tables.
for F in "$ROOT/compiler/tensor_frontend_x86_64.S" "$ROOT/compiler/tensor_derived_frontend_x86_64.S"; do
  grep -q 'tensor_optimizer_capacity' "$F"
  grep -q '^vec_cache_binding_ptr:.skip 8$' "$F"
  ! grep -Eq 'vec_cache_binding:.skip 64|vec_cache_key_[abc]:.skip 64' "$F"
done
grep -q '^tensor_affine_profile_coeff_ptr:.skip 8$' "$ROOT/compiler/tensor_frontend_x86_64.S"
grep -q '^tensor_const_profile_bits_ptr:.skip 8$' "$ROOT/compiler/tensor_frontend_x86_64.S"
! grep -Eq 'tensor_affine_profile_coeff:.skip 16|tensor_const_profile_bits:.skip 64' "$ROOT/compiler/tensor_frontend_x86_64.S"

# Tolerance consumes one explicit reciprocal relation; Strict never calls it.
grep -q '^recip_tolerant_f64_bits:' "$SRC"
grep -q 'cmp dword ptr \[rip+tensor_tolerant_fp\],0' "$SRC"
grep -q 'call recip_tolerant_f64_bits' "$SRC"
! grep -Eq 'dense_irregular_allpairs127|waitslow|mass3|chem6|rigid7' "$SRC"

cat > "$TMP/strict.whex" <<'WH'
program tensor_fact_probe
strict
input n: u64 range 64..65536
field x[b in n, i in 127]: f64 = -0.375 + cast(f64, (b * 31 + i * 17 + 5) % 2048) / 1024.0
field y[b in n, i in 127]: f64 = 0.25 + cast(f64, (b * 19 + i * 23 + 7) % 1024) / 1536.0
sum checksum[b in n, i in 127, j in 127]: f64 =
    x[b, i] * y[b, (j * 37 + i * 13 + b * 7 + 11) % 127] * (0.75 + cast(f64, (i * 29 + j * 43 + b * 3 + 17) % 257) / 512.0)
  + 0.03125 * x[b, (j * 19 + i * 5 + b * 11 + 23) % 127] * x[b, i]
  - 0.015625 * y[b, j] * y[b, (i * 41 + j * 17 + b * 13 + 31) % 127]
output checksum
WH
sed 's/^strict$/tolerance 1e-10/' "$TMP/strict.whex" > "$TMP/fast.whex"
"$ROOT/bin/whexc" "$TMP/strict.whex" -o "$TMP/strict" >/dev/null
"$ROOT/bin/whexc" "$TMP/fast.whex" -o "$TMP/fast" >/dev/null
CPU1=$(python3 -c 'import os; print(min(os.sched_getaffinity(0)))')
CPUS=$(python3 -c 'import os; print(",".join(map(str,sorted(os.sched_getaffinity(0))[:4])))')
[ "$("$TMP/strict" 64)" = 'checksum_bits=0x411761c7a7f92980' ]
[ "$("$TMP/strict" 127)" = 'checksum_bits=0x41272d5ac3e2792e' ]
# Tolerance permits reassociation across ownership cardinalities. Pin its
# numerical smoke check to one admitted execution instead of manufacturing an
# accidental executor-count contract.
[ "$(taskset -c "$CPU1" "$TMP/fast" 64)" = 'checksum_bits=0x411761c7a7f92978' ]
# The same Strict image must retain one mathematical reduction tree when the
# invocation is externally admitted to a different execution cardinality.
ONE=$(taskset -c "$CPU1" "$TMP/strict" 127)
MANY=$(taskset -c "$CPUS" "$TMP/strict" 127)
[ "$ONE" = 'checksum_bits=0x41272d5ac3e2792e' ]
[ "$MANY" = "$ONE" ]

# 1.3.118: Rank-N value predicates use the same PredicateFact relation on all
# structured physicalizers.  This is not an active-set DSL: the semantic fact
# is a domain-valued boolean relation and f64 select consumes it directly.
for F in \
  "$ROOT/compiler/tensor_frontend_x86_64.S" \
  "$ROOT/compiler/tensor_frontend_native256_x86_64.S" \
  "$ROOT/compiler/tensor_derived_frontend_x86_64.S" \
  "$ROOT/compiler/tensor_derived_frontend_native256_x86_64.S"; do
  grep -q '^expr_is_float_value:' "$F"
  grep -q '^vec_cmp_f64_maskvec:' "$F"
  grep -q 'v_lt:.ascii "lt"' "$F"
  grep -q 'v_ge:.ascii "ge"' "$F"
done
cat > "$TMP/rankn_predicate.whex" <<'WH'
program rankn_predicate_probe
strict
input n: u64 range 64..65536
field x[i in n]: f64 = -1.0 + cast(f64, (i * 37 + 11) % 4096) / 2048.0
field y[i in n]: f64 = select(x[i] < 0.0, -0.75 * x[i], 0.0)
sum checksum[i in n]: f64 = y[i]
output checksum
WH
for CC in \
  "$ROOT/bin/whexc" \
  "$ROOT/bin/topologyc-native256" \
  "$ROOT/bin/topologyc-derived" \
  "$ROOT/bin/topologyc-derived-native256"; do
  "$CC" "$TMP/rankn_predicate.whex" -o "$TMP/rankn_predicate" >/dev/null
  [ "$("$TMP/rankn_predicate" 1024)" = 'checksum_bits=0x4069413c00000000' ]
  [ "$("$TMP/rankn_predicate" 10000)" = 'checksum_bits=0x409d7ced00000000' ]
done

# 1.3.119: the same PredicateFact can remain a native AVX-512 control
# authority.  Exact +0.0 false support is an identity Region: an empty packet
# performs no true-arm work, while non-empty packets keep exact lane support.
# This is one Physical-DAG realization, not an active-set language/backend.
for F in \
  "$ROOT/compiler/tensor_frontend_x86_64.S" \
  "$ROOT/compiler/tensor_derived_frontend_x86_64.S"; do
  grep -q '^vec_cmp_f64_k1:' "$F"
  grep -q '^emit_vec_predicate_k1:' "$F"
  grep -q '^vec_kortest_k1:' "$F"
  grep -q '^vec_keep_k1_zero:' "$F"
done
! grep -REq 'contact[_ -]?matcher|active[_ -]?set[_ -]?backend|density[_ -]?threshold|vpcompress' \
  "$ROOT/compiler/tensor_frontend_x86_64.S" \
  "$ROOT/compiler/tensor_derived_frontend_x86_64.S"

printf '%s\n' \
  'MIXED_RADIX_CARRY_RECURRENCE=PASS' \
  'SCALED_FACT_LOGICAL_PHYSICAL_ALIAS=0' \
  'TOLERANT_LITERAL_DIV_RECIPROCAL=PASS' \
  'STRICT_REDUCTION_EXECUTION_CARDINALITY_INVARIANT=PASS' \
  'RUNTIME_RADIX_SELECTOR=0' \
  'DENSE_MIXED_WORKLOAD_MATCHER=0' \
  'SECOND_TENSOR_IR=0' \
  'RANKN_VALUE_PREDICATE_PHYSICAL_CLOSURE=PASS' \
  'RANKN_PREDICATE_SUPPORT_REGION=PASS' \
  'ACTIVE_SET_SECOND_BACKEND=0' \
  'WHEELCHAIR_TENSOR_FACT_AGING_1_3_119=PASS'
