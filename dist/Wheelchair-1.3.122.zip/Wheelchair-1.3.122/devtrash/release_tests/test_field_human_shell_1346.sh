#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
C="$ROOT/build/wheelchairc"
[ -x "$C" ] || C="$ROOT/bin/wheelchairc"
T="$ROOT/devtrash/tests/field_human_shell_1346"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

"$C" "$T/compact.wh" -o "$TMP/compact"
"$C" "$T/expanded.wh" -o "$TMP/expanded"
"$C" "$ROOT/devtrash/benchmarks/human_shell_1346/fem_hex8_compact.wh" -o "$TMP/fem_hex8_compact"

# WHFLD217 stores exactly RankFact extents/strides; no padded global axis width.
python3 - "$TMP" <<'PY'
import struct,sys
from pathlib import Path
D=Path(sys.argv[1])
def field(path, vals):
    ext=[3,1,1]; rank=len(ext); st=[0]*rank; x=4
    for i in range(rank-1,-1,-1): st[i]=x; x*=ext[i]
    data_off=((64+16*rank+63)//64)*64
    h=bytearray(data_off); h[:8]=b'WHFLD217'
    struct.pack_into('<II',h,8,2,1); struct.pack_into('<Q',h,16,rank)
    struct.pack_into('<Q',h,24,data_off); struct.pack_into('<Q',h,32,3)
    for i,v in enumerate(ext): struct.pack_into('<Q',h,64+8*i,v)
    so=64+8*rank
    for i,v in enumerate(st): struct.pack_into('<Q',h,so+8*i,v)
    Path(path).write_bytes(h+b''.join(struct.pack('<f',float(x)) for x in vals))
field(D/'in.whfld',[1,2,3])
field(D/'out_compact.whfld',[0,0,0])
field(D/'out_expanded.whfld',[0,0,0])
PY

"$TMP/compact" "$TMP/in.whfld" "$TMP/out_compact.whfld" >/dev/null
"$TMP/expanded" "$TMP/in.whfld" "$TMP/out_expanded.whfld" >/dev/null
cmp -s "$TMP/out_compact.whfld" "$TMP/out_expanded.whfld"

# Human syntax itself crosses the historical eighth-axis boundary.
cat > "$TMP/rank9.wh" <<'WH'
program rank9_field_probe
strict
input n0: u64
input n1: u64
input n2: u64
input n3: u64
input n4: u64
input n5: u64
input n6: u64
input n7: u64
input n8: u64
input field u[a0 in n0, a1 in n1, a2 in n2, a3 in n3, a4 in n4, a5 in n5, a6 in n6, a7 in n7, a8 in n8]: f32
output field out[a0 in n0, a1 in n1, a2 in n2, a3 in n3, a4 in n4, a5 in n5, a6 in n6, a7 in n7, a8 in n8]: f32
for a0 in n0, a1 in n1, a2 in n2, a3 in n3, a4 in n4, a5 in n5, a6 in n6, a7 in n7, a8 in n8 {
  out[a0,a1,a2,a3,a4,a5,a6,a7,a8] = u[a0,a1,a2,a3,a4,a5,a6,a7,a8]
}
WH
"$C" "$TMP/rank9.wh" -o "$TMP/rank9" >/dev/null
python3 - "$TMP" <<'PY'
import struct,sys
from pathlib import Path
D=Path(sys.argv[1]); rank=9; ext=[1]*8+[37]; st=[0]*rank; x=4
for i in range(rank-1,-1,-1): st[i]=x; x*=ext[i]
data_off=((64+16*rank+63)//64)*64
def field(name, vals):
    h=bytearray(data_off); h[:8]=b'WHFLD217'
    struct.pack_into('<II',h,8,2,1); struct.pack_into('<Q',h,16,rank)
    struct.pack_into('<Q',h,24,data_off); struct.pack_into('<Q',h,32,37)
    for i,v in enumerate(ext): struct.pack_into('<Q',h,64+8*i,v)
    so=64+8*rank
    for i,v in enumerate(st): struct.pack_into('<Q',h,so+8*i,v)
    (D/name).write_bytes(h+b''.join(struct.pack('<f',float(v)) for v in vals))
field('rank9_in.whfld',range(1,38)); field('rank9_out.whfld',[0]*37)
PY
"$TMP/rank9" "$TMP/rank9_in.whfld" "$TMP/rank9_out.whfld" >/dev/null
python3 - "$TMP/rank9_out.whfld" <<'PY'
import struct,sys
b=open(sys.argv[1],'rb').read(); off=struct.unpack_from('<Q',b,24)[0]
v=struct.unpack_from('<37f',b,off)
assert v == tuple(float(i) for i in range(1,38))
PY

grep -q '^\.scs_static_select_false:' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q 's_eval_static_u64' "$ROOT/compiler/surface_lowerer_x86_64.S"
echo FIELD_HUMAN_RANKFACT_N=PASS
echo FIELD_HUMAN_SHELL_STATIC_SELECT_1_3_46=PASS
