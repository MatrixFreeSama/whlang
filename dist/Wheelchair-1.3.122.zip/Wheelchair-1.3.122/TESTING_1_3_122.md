# Wheelchair 1.3.122 Testing

Current release gate: **32/32 PASS**.

The new `test_parallel_source_convergence_13122.sh` verifies that:

- all Tensor entry surfaces consume the common/profile authorities;
- common parser/CoordinateFact bodies exist once;
- no runtime ISA/profile selector or workload profile route appears;
- proof-neutral Field runtime bodies are shared while proof-bearing frontier/reduction authorities remain explicit;
- the duplicate Field linker script is gone;
- temporary pre-1.3.122 source backups are absent.

The complete release suite continues to cover the existing Human Shell, General, Field, Tensor, ShapeFact/CoordinateFact, Rank-N, Physical Reality, silicon/fabric, and hard-limit aging invariants.

The retained source-convergence A/B data and exact executable hash are stored in `devtrash/benchmarks/source_convergence_13122/`.
