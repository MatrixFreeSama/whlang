# Wheelchair 1.3.122 Performance

1.3.122 is intentionally performance-neutral. It removes source duplication while preserving the emitted machine code.

## Binary identity

All eight production binaries have the same SHA-256 as the pristine 1.3.121 build. The retained 12-pair structural-inflation source also produces the same 8513-byte ELF under 1.3.121 and 1.3.122:

`ab7667c9bca6a2b39449b41bd4cbf3f81045e50d192d1d3350d62cca9176a569`

Eleven interleaved pinned runs measure:

| compiler | median | mean |
|---|---:|---:|
| 1.3.121 | 5.400 ms | 5.368 ms |
| 1.3.122 | 5.343 ms | 5.386 ms |

The apparent ~1.1% median improvement is measurement noise because the generated executables are byte-identical. The correct refactor performance claim is therefore **0% machine-code change**.

A fresh current-host comparison of the same retained 12-pair workload gives 5.699 ms Wheelchair, 151.390 ms C `-O3 -march=native`, and 152.982 ms Fortran `-O3 -march=native` (26.56x / 26.84x on this host). This is a local diagnostic and is not numerically compared with older-host measurements.

## Source work removed

| source authority | 1.3.121 | 1.3.122 | reduction |
|---|---:|---:|---:|
| Tensor frontend | 1,198,204 B | 844,573 B | 29.51% |
| Field runtime | 123,690 B | 98,255 B | 20.56% |
| all production `.S/.inc` | 3,018,437 B | 2,639,371 B | 12.56% |

The compiler does less human-maintenance work without asking the target CPU to do anything different.
