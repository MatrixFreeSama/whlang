# Wheelchair 1.3.122 Pure Assembly Release Proof

The release remains a pure AOT assembly toolchain. Commonization is performed by the assembler source language itself through compile-time include/macro authorities.

Release invariants:

- Tensor common bodies have one source authority.
- Tensor physical-profile shared bodies have one compile-time authority.
- Field proof-neutral runtime bodies have one source authority.
- Runtime ISA/profile dispatch is absent.
- Generated-source cloning is absent.
- Workload-specific source routing is absent.
- `runtime/field_runtime.ld` is absent; one runtime linker authority remains.
- Production binaries are byte-identical to 1.3.121.
- `build/` is generated output and is not shipped as an independent source authority.
