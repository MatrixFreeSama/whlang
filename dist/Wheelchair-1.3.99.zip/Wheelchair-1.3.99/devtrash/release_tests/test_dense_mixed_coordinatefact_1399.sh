#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP=${TMPDIR:-/tmp}/wheelchair_mixed1399_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
SRC="$ROOT/compiler/tensor_derived_frontend_x86_64.S"

grep -q '^vec_vpmuludq_mem_const:' "$SRC"
grep -q '^expr_dense_mixed_coord_key:' "$SRC"
grep -q '^vec_mixed_scaled_refresh:' "$SRC"
if grep -q 'dense_irregular_allpairs127' "$SRC"; then
  echo 'benchmark matcher leaked into production compiler' >&2
  exit 1
fi

cat > "$TMP/probe.whex" <<'WH'
program mixed_coordinatefact_probe
strict
input n: u64 range 64..65536
field x[b in n, i in 127]: f64 = -0.375 + cast(f64, (b * 31 + i * 17 + 5) % 2048) / 1024.0
field y[b in n, i in 127]: f64 = 0.25 + cast(f64, (b * 19 + i * 23 + 7) % 1024) / 1536.0
sum checksum[b in n, i in 127, j in 127]: f64 =
    x[b, i] * y[b, (j * 37 + i * 13 + b * 7 + 11) % 127] * (0.75 + cast(f64, (i * 29 + j * 43 + b * 3 + 17) % 257) / 512.0)
  + 0.03125 * x[b, (j * 19 + i * 5 + b * 11 + 23) % 127] * x[b, i]
  - 0.015625 * y[b, j] * y[b, (i * 41 + j * 17 + b * 13 + 31) % 127]
output checksum
WH
"$ROOT/bin/whexc" "$TMP/probe.whex" -o "$TMP/probe" >/dev/null
out=$("$TMP/probe" 64)
[ "$out" = 'checksum_bits=0x411761c7a7f9297e' ]
echo 'DENSE_MIXED_COORDINATEFACT_1_3_99=PASS'
