#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.97" ]
G=compiler/general_frontend_x86_64.S
T=${TMPDIR:-/tmp}/wheelchair1396_general_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

# General scalar FP must consume the compiler-wide ISA capability authority.
grep -q '^\.include "compiler/isa_capabilities.inc"$' "$G"
grep -q '^g_phys_fp_geometry_refresh:' "$G"
grep -q 'ISA_CAP_WIDE_REGFILE' "$G"
grep -q '^g_emit_phys_evex_scalar3:' "$G"
! grep -q 'G_PHYS_FP_CARRIER_COUNT' "$G"
! grep -q 'G_PHYS_FP_TEMP_MASK_INIT' "$G"
! grep -q 'G_PHYS_FP_CONST_MAX' "$G"

# Constant/CSE residency no longer owns the old source-order eight-value cliff.
grep -q 'g_phys_const_candidate_bits:.skip G_PHYS_CSE_MAX\*8' "$G"
grep -q 'g_phys_cse_resident_expr:.skip G_PHYS_CSE_MAX\*8' "$G"
grep -q 'g_phys_const_resident_bits:.skip G_PHYS_CSE_MAX\*8' "$G"

S=devtrash/tests/general_whole_episode_1316
for n in mass3 chem6 rigid7; do
  build/wheelchairc "$S/$n.wh" -o "$T/$n" >/dev/null
  chmod +x "$T/$n"
done
[ "$("$T/mass3" 100000)" = 'out00_bits=0x3fa90c89b2e19b14' ]
[ "$("$T/chem6" 100000)" = 'out00_bits=0x3fad4117d563218b' ]
[ "$("$T/rigid7" 100000)" = 'out00_bits=0x3fd72fe2f4bace4b' ]

# On an actually wide-regfile host, the generated General code must use it.
if grep -qw avx512f /proc/cpuinfo 2>/dev/null; then
  off=$(od -An -tu8 -j $((0x4010)) -N8 "$T/mass3" | tr -d ' ')
  size=$(od -An -tu8 -j $((0x4018)) -N8 "$T/mass3" | tr -d ' ')
  rel=$(od -An -tu8 -j $((0x4020)) -N8 "$T/mass3" | tr -d ' ')
  dd if="$T/mass3" of="$T/code.bin" bs=1 skip=$((off+rel)) count=$((size-rel)) status=none
  objdump -D -b binary -mi386:x86-64 -Mintel "$T/code.bin" > "$T/code.dis"
  grep -Eq 'xmm(1[6-9]|2[0-9]|3[01])' "$T/code.dis"
fi

printf '%s\n' \
  'GENERAL_SCALAR_FP_SINGLE_PHYSICAL_REALITY=PASS' \
  'WIDE_REGFILE_CAPABILITY_AUTHORITY=PASS' \
  'SOURCE_ORDER_EIGHT_VALUE_CLIFF=0' \
  'STRICT_GENERAL_REFERENCE_BITS=PASS' \
  'WHEELCHAIR_GENERAL_SCALAR_PHYSICAL_REALITY_1_3_96=PASS'
