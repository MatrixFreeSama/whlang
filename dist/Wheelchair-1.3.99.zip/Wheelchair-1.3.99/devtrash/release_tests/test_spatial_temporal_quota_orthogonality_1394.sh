#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "spatial/temporal quota orthogonality 1.3.94: $*" >&2; exit 1; }

./build.sh >/dev/null
for law in \
  SR_EXECUTION_ADMISSION_FROM_AFFINITY_SET,1 \
  SR_CGROUP_CPU_QUOTA_IS_TEMPORAL_BUDGET_FACT,1 \
  SR_CGROUP_CPU_QUOTA_IS_MULTIPLICITY_AUTHORITY,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" compiler/silicon_reality.inc
done
for law in \
  PR_AFFINITY_SET_OWNS_X86_MULTIPLICITY_BOUND,1 \
  PR_CGROUP_QUOTA_OWNS_TEMPORAL_BUDGET,1 \
  PR_CGROUP_QUOTA_OWNS_MULTIPLICITY_BOUND,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" compiler/physical_reality.inc
done

grep -q '^sd_read_cgroup_cpu_temporal_budget:$' compiler/silicon_domain_probe_x86_64.S
! grep -RqsE 'cpu_quota_execution_capacity|sd_cpu_quota_capacity|sd_read_cgroup_cpu_quota_capacity' compiler runtime tools

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY1'
import json,os,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/10',D
allowed=len(os.sched_getaffinity(0))
assert D['allowed_execution_contexts']==allowed,(D['allowed_execution_contexts'],allowed)
assert D['execution_admission_capacity']==allowed,D
assert D['execution_admission_authority']=='affinity_set',D
assert D['cpu_quota_authority']=='temporal_budget_only',D
assert D['cpu_quota_is_multiplicity_authority'] is False,D
q=p=0
try:
    a=open('/sys/fs/cgroup/cpu.max').read().split()
    if len(a)>=2 and a[0] != 'max': q,p=map(int,a[:2])
except OSError:
    pass
assert D['cpu_quota_usec']==q,(D['cpu_quota_usec'],q)
assert D['cpu_period_usec']==p,(D['cpu_period_usec'],p)
print('SPATIAL_TEMPORAL_CONTRACT=PASS')
PY1

# Compile under an exact non-power-of-two affinity subset. A finite cpu.max must
# not erase a context from the compile-time admitted set.
python3 - "$T" <<'PY2'
import os,re,struct,subprocess,sys,json
T=sys.argv[1]; cpus=sorted(os.sched_getaffinity(0))
if len(cpus)<3:
    print('AFFINITY_MULTIPLICITY_BURN=SKIP_LT3')
    raise SystemExit
subset=set(cpus[:3])
def pin(): os.sched_setaffinity(0,subset)
out=f'{T}/fsi3'
subprocess.run(['bin/whexc','devtrash/tests/profile_1211/fsi_coupled.whex','-o',out],check=True,stdout=subprocess.DEVNULL,preexec_fn=pin)
inc=open('compiler/runtime_offsets.inc').read()
m=re.search(r'RUNTIME_EXECUTION_ADMISSION_OFF,\s*(0x[0-9a-fA-F]+|\d+)',inc); assert m
O=int(m.group(1),0); b=open(out,'rb').read(); got=struct.unpack_from('<I',b,O)[0]
assert got==3,(got,subset)
print('AFFINITY_MULTIPLICITY_BURN=PASS')
PY2

echo 'CPU_QUOTA_MULTIPLICITY_AUTHORITY=0'
echo 'POWER_OF_TWO_EXECUTION_ROUNDUP=0'
echo 'RUNTIME_IDLE_RESOURCE_QUERY=0'
echo 'WHEELCHAIR_SPATIAL_TEMPORAL_QUOTA_ORTHOGONALITY_1_3_94=PASS'
