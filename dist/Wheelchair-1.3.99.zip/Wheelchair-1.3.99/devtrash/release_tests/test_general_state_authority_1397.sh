#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.97" ]
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality.inc
T=${TMPDIR:-/tmp}/wheelchair1397_state_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

grep -q '^.equ PR_FP_GENERATION_FIXED_POINT_AUTHORITY,1$' "$P"
grep -q '^.equ PR_FP_GENERATION_PARTIAL_AUTHORITY_MIX,0$' "$P"
grep -q '^.equ PR_FP_GENERATION_WORKLOAD_MATCHER,0$' "$P"
grep -q '^.equ PR_FP_GENERATION_SECOND_BACKEND,0$' "$P"
grep -q '^g_phys_expr_effectively_uses_state:$' "$G"
grep -q '^g_phys_fp_can_birth_in_old_authority:$' "$G"
grep -q '^g_phys_prove_inplace_fp_epoch:$' "$G"
! grep -Eq 'mass3|chem6|rigid7' "$G"

S=devtrash/tests/general_whole_episode_1316
for n in mass3 chem6 rigid7; do
  build/wheelchairc "$S/$n.wh" -o "$T/$n" >/dev/null
  chmod +x "$T/$n"
done
[ "$("$T/mass3" 100000)" = 'out00_bits=0x3fa90c89b2e19b14' ]
[ "$("$T/chem6" 100000)" = 'out00_bits=0x3fad4117d563218b' ]
[ "$("$T/rigid7" 100000)" = 'out00_bits=0x3fd72fe2f4bace4b' ]

# On the wide-register host used by the release benchmark, chem6 is the generic
# witness whose complete FP generation proves one carrier fixed point. Its hot
# code must therefore contain no low-next -> high-old scalar transport tail.
if grep -qw avx512f /proc/cpuinfo 2>/dev/null; then
  off=$(od -An -tu8 -j $((0x4010)) -N8 "$T/chem6" | tr -d ' ')
  size=$(od -An -tu8 -j $((0x4018)) -N8 "$T/chem6" | tr -d ' ')
  rel=$(od -An -tu8 -j $((0x4020)) -N8 "$T/chem6" | tr -d ' ')
  dd if="$T/chem6" of="$T/code.bin" bs=1 skip=$((off+rel)) count=$((size-rel)) status=none
  objdump -D -b binary -mi386:x86-64 -Mintel "$T/code.bin" > "$T/code.dis"
  ! grep -Eq 'vmovsd[[:space:]]+xmm(1[6-9]|2[0-9]|3[01]),xmm(1[6-9]|2[0-9]|3[01]),xmm[1-9]' "$T/code.dis"
fi

printf '%s\n' \
  'FP_GENERATION_FIXED_POINT_AUTHORITY=PASS' \
  'PARTIAL_FP_GENERATION_AUTHORITY_MIX=0' \
  'STRICT_GENERAL_REFERENCE_BITS=PASS' \
  'GENERAL_WORKLOAD_ROUTE=0' \
  'WHEELCHAIR_GENERAL_STATE_AUTHORITY_1_3_97=PASS'
