#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "transport/issue orthogonality 1.3.93: $*" >&2; exit 1; }

./build.sh >/dev/null

for law in \
  PR_ISSUE_BOUND_OWNS_RECURRENCE_CARRIERS,1 \
  PR_TRAFFIC_OWNS_TOTAL_PHYSICAL_COST,1 \
  PR_TRAFFIC_OWNS_RECURRENCE_CARRIER_WIDTH,0 \
  PR_TRANSPORT_COMPUTE_AXIS_COLLAPSE,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" compiler/physical_reality.inc
done
for law in \
  SR_TRANSPORT_IS_TOTAL_COST_FACT,1 \
  SR_ISSUE_IS_RECURRENCE_WIDTH_FACT,1 \
  SR_TRANSPORT_IS_RECURRENCE_WIDTH_AUTHORITY,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" compiler/silicon_reality.inc
done

# The total schedule still admits traffic as a bottleneck, while recurrence
# width is derived from the pre-transport issue/dependency bound.
grep -q '^schedule_issue_bound_ticks:' compiler/topologyc_x86_64.S
grep -q 'mov dword ptr \[rip+schedule_issue_bound_ticks\], eax' compiler/topologyc_x86_64.S
grep -q 'mov ecx, dword ptr \[rip+schedule_issue_bound_ticks\]' compiler/topologyc_x86_64.S
grep -q 'PRC_TRAFFIC_LINE_TICKS' compiler/topologyc_x86_64.S
grep -q 'schedule_bound_ticks' compiler/outward_materialization_profile_x86_64.S

bin/topologyc --schedule 2 0 0 0 0 0 0 4 4 1 > "$T/schedule.json"
python3 - "$T/schedule.json" <<'PY1'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['bottleneck']=='traffic',D
assert D['group_carrier_factor']>1,D
assert D['group_body_factor']>1,D
print('TRAFFIC_TOTAL_COST_WITH_INDEPENDENT_CARRIERS=PASS')
PY1

# Regression witness: the historical lightweight reduction must retain more
# than one independent reduction carrier without changing semantics.
bin/whexc devtrash/tests/whex/emergent_light_reduction_1318.whex -o "$T/light" >/dev/null
out=$("$T/light" 100000)
case "$out" in checksum_bits=0x*) ;; *) fail output ;; esac
# The repaired dual-carrier image is larger than the collapsed 1.3.92 image;
# exact bytes are target-specific, so assert only the structural schedule above.

echo 'TRAFFIC_REALITY_REMOVED=0'
echo 'TRANSPORT_COMPUTE_AXIS_COLLAPSE=0'
echo 'WHEELCHAIR_TRANSPORT_ISSUE_ORTHOGONALITY_1_3_93=PASS'
