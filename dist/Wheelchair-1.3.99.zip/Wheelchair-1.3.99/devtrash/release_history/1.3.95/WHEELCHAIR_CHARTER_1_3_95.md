# Wheelchair charter 1.3.95

The 1.3.94 execution charter remains authoritative. 1.3.95 applies the same convergence rule to distribution: one shipped production executable authority, no reproducible scratch duplication, and no compatibility branch introduced to preserve old package shape.
