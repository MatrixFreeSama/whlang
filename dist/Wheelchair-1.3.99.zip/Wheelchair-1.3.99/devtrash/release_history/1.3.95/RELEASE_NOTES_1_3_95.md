# Wheelchair 1.3.95

1.3.95 is a release-surface convergence release. Compiler/runtime execution logic remains the 1.3.94 authority.

The generated `build/` workspace is no longer shipped. `bin/` is the only production executable authority in the archive. Reproducible benchmark ELF outputs were removed from `devtrash/benchmarks`; their sources and measured evidence remain. Exact duplicate scratch build logs were collapsed to their canonical release-history copies.

The 1.3.94 spatial/temporal quota orthogonality and 1.3.93 transport/issue orthogonality remain unchanged.
