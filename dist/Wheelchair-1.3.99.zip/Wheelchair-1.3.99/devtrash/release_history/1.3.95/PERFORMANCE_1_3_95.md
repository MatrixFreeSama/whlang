# Performance 1.3.95

1.3.95 contains no compiler/runtime execution change from 1.3.94, so the 1.3.94 same-host benchmark evidence remains the current performance authority. No new performance claim is created by release-surface cleanup.

The retained raw benchmark evidence is under `devtrash/benchmarks/spatial_temporal_quota_1394/` and the archived 1.3.94 performance document is under `devtrash/release_history/1.3.94/`.
