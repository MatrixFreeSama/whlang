
/tmp/tmp.4dvz6oXNBM:     file format binary


Disassembly of section .data:

0000000000402000 <.data>:
  402000:	4c 8b 14 24          	mov    r10,QWORD PTR [rsp]
  402004:	89 da                	mov    edx,ebx
  402006:	03 94 24 90 00 00 00 	add    edx,DWORD PTR [rsp+0x90]
  40200d:	83 ea 02             	sub    edx,0x2
  402010:	49 8b 04 d2          	mov    rax,QWORD PTR [r10+rdx*8]
  402014:	89 c0                	mov    eax,eax
  402016:	49 09 c1             	or     r9,rax
  402019:	4d 39 c8             	cmp    r8,r9
  40201c:	76 11                	jbe    0x40202f
  40201e:	48 ff 4c 24 40       	dec    QWORD PTR [rsp+0x40]
  402023:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
  402028:	48 01 44 24 48       	add    QWORD PTR [rsp+0x48],rax
  40202d:	eb 9f                	jmp    0x401fce
  40202f:	45 31 c0             	xor    r8d,r8d
  402032:	45 31 c9             	xor    r9d,r9d
  402035:	45 31 d2             	xor    r10d,r10d
  402038:	44 3b 84 24 90 00 00 	cmp    r8d,DWORD PTR [rsp+0x90]
  40203f:	00 
  402040:	73 45                	jae    0x402087
  402042:	4c 8b 5c 24 08       	mov    r11,QWORD PTR [rsp+0x8]
  402047:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
  40204c:	4b f7 24 c3          	mul    QWORD PTR [r11+r8*8]
  402050:	4c 01 c8             	add    rax,r9
  402053:	49 89 c1             	mov    r9,rax
  402056:	49 c1 e9 20          	shr    r9,0x20
  40205a:	89 c0                	mov    eax,eax
  40205c:	4c 01 d0             	add    rax,r10
  40205f:	4c 8b 1c 24          	mov    r11,QWORD PTR [rsp]
  402063:	89 da                	mov    edx,ebx
  402065:	44 01 c2             	add    edx,r8d
  402068:	49 8b 0c d3          	mov    rcx,QWORD PTR [r11+rdx*8]
  40206c:	89 c9                	mov    ecx,ecx
  40206e:	48 39 c1             	cmp    rcx,rax
  402071:	41 0f 92 c2          	setb   r10b
  402075:	45 0f b6 d2          	movzx  r10d,r10b
  402079:	48 29 c1             	sub    rcx,rax
  40207c:	89 c9                	mov    ecx,ecx
  40207e:	49 89 0c d3          	mov    QWORD PTR [r11+rdx*8],rcx
  402082:	41 ff c0             	inc    r8d
  402085:	eb b1                	jmp    0x402038
  402087:	4c 8b 1c 24          	mov    r11,QWORD PTR [rsp]
  40208b:	89 da                	mov    edx,ebx
  40208d:	03 94 24 90 00 00 00 	add    edx,DWORD PTR [rsp+0x90]
  402094:	49 8b 0c d3          	mov    rcx,QWORD PTR [r11+rdx*8]
  402098:	89 c9                	mov    ecx,ecx
  40209a:	4c 89 c8             	mov    rax,r9
  40209d:	4c 01 d0             	add    rax,r10
  4020a0:	48 39 c1             	cmp    rcx,rax
  4020a3:	41 0f 92 c0          	setb   r8b
  4020a7:	45 0f b6 c0          	movzx  r8d,r8b
  4020ab:	48 29 c1             	sub    rcx,rax
  4020ae:	89 c9                	mov    ecx,ecx
  4020b0:	49 89 0c d3          	mov    QWORD PTR [r11+rdx*8],rcx
  4020b4:	45 85 c0             	test   r8d,r8d
  4020b7:	74 56                	je     0x40210f
  4020b9:	48 ff 4c 24 40       	dec    QWORD PTR [rsp+0x40]
  4020be:	45 31 c9             	xor    r9d,r9d
  4020c1:	45 31 d2             	xor    r10d,r10d
  4020c4:	44 3b 94 24 90 00 00 	cmp    r10d,DWORD PTR [rsp+0x90]
  4020cb:	00 
  4020cc:	73 30                	jae    0x4020fe
  4020ce:	4c 8b 1c 24          	mov    r11,QWORD PTR [rsp]
  4020d2:	89 da                	mov    edx,ebx
  4020d4:	44 01 d2             	add    edx,r10d
  4020d7:	49 8b 04 d3          	mov    rax,QWORD PTR [r11+rdx*8]
  4020db:	89 c0                	mov    eax,eax
  4020dd:	48 8b 4c 24 08       	mov    rcx,QWORD PTR [rsp+0x8]
  4020e2:	4a 03 04 d1          	add    rax,QWORD PTR [rcx+r10*8]
  4020e6:	4c 01 c8             	add    rax,r9
  4020e9:	48 89 c1             	mov    rcx,rax
  4020ec:	89 c9                	mov    ecx,ecx
  4020ee:	49 89 0c d3          	mov    QWORD PTR [r11+rdx*8],rcx
  4020f2:	48 c1 e8 20          	shr    rax,0x20
  4020f6:	49 89 c1             	mov    r9,rax
  4020f9:	41 ff c2             	inc    r10d
  4020fc:	eb c6                	jmp    0x4020c4
  4020fe:	4c 8b 1c 24          	mov    r11,QWORD PTR [rsp]
  402102:	89 da                	mov    edx,ebx
  402104:	03 94 24 90 00 00 00 	add    edx,DWORD PTR [rsp+0x90]
  40210b:	4d 01 0c d3          	add    QWORD PTR [r11+rdx*8],r9
  40210f:	4c 8b 5c 24 10       	mov    r11,QWORD PTR [rsp+0x10]
  402114:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
  402119:	49 89 04 db          	mov    QWORD PTR [r11+rbx*8],rax
  40211d:	ff cb                	dec    ebx
  40211f:	e9 37 fe ff ff       	jmp    0x401f5b
  402124:	45 31 c0             	xor    r8d,r8d
  402127:	45 31 c9             	xor    r9d,r9d
  40212a:	4c 8b 14 24          	mov    r10,QWORD PTR [rsp]
  40212e:	44 3b 84 24 90 00 00 	cmp    r8d,DWORD PTR [rsp+0x90]
  402135:	00 
  402136:	73 09                	jae    0x402141
  402138:	4f 0b 0c c2          	or     r9,QWORD PTR [r10+r8*8]
  40213c:	41 ff c0             	inc    r8d
  40213f:	eb ed                	jmp    0x40212e
  402141:	4c 89 4c 24 68       	mov    QWORD PTR [rsp+0x68],r9
  402146:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  40214b:	8b 8c 24 8c 00 00 00 	mov    ecx,DWORD PTR [rsp+0x8c]
  402152:	e8 62 e8 ff ff       	call   0x4009b9
  402157:	89 44 24 6c          	mov    DWORD PTR [rsp+0x6c],eax
  40215b:	8b 44 24 6c          	mov    eax,DWORD PTR [rsp+0x6c]
  40215f:	83 c0 01             	add    eax,0x1
  402162:	d1 e8                	shr    eax,1
  402164:	83 c0 01             	add    eax,0x1
  402167:	89 44 24 64          	mov    DWORD PTR [rsp+0x64],eax
  40216b:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  402170:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  402175:	8b 4c 24 64          	mov    ecx,DWORD PTR [rsp+0x64]
  402179:	8b 54 24 6c          	mov    edx,DWORD PTR [rsp+0x6c]
  40217d:	e8 ae e8 ff ff       	call   0x400a30
  402182:	48 83 7c 24 68 00    	cmp    QWORD PTR [rsp+0x68],0x0
  402188:	74 09                	je     0x402193
  40218a:	4c 8b 54 24 18       	mov    r10,QWORD PTR [rsp+0x18]
  40218f:	49 83 0a 01          	or     QWORD PTR [r10],0x1
  402193:	4d 8b 45 18          	mov    r8,QWORD PTR [r13+0x18]
  402197:	4d 2b 46 18          	sub    r8,QWORD PTR [r14+0x18]
  40219b:	48 63 84 24 80 00 00 	movsxd rax,DWORD PTR [rsp+0x80]
  4021a2:	00 
  4021a3:	49 29 c0             	sub    r8,rax
  4021a6:	49 8b 4d 10          	mov    rcx,QWORD PTR [r13+0x10]
  4021aa:	49 33 4e 10          	xor    rcx,QWORD PTR [r14+0x10]
  4021ae:	4c 89 e7             	mov    rdi,r12
  4021b1:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  4021b6:	8b 54 24 64          	mov    edx,DWORD PTR [rsp+0x64]
  4021ba:	45 89 f9             	mov    r9d,r15d
  4021bd:	e8 65 e1 ff ff       	call   0x400327
  4021c2:	85 c0                	test   eax,eax
  4021c4:	75 04                	jne    0x4021ca
  4021c6:	31 c0                	xor    eax,eax
  4021c8:	eb 05                	jmp    0x4021cf
  4021ca:	b8 01 00 00 00       	mov    eax,0x1
  4021cf:	48 81 c4 a0 00 00 00 	add    rsp,0xa0
  4021d6:	41 5f                	pop    r15
  4021d8:	41 5e                	pop    r14
  4021da:	41 5d                	pop    r13
  4021dc:	41 5c                	pop    r12
  4021de:	41 5b                	pop    r11
  4021e0:	5d                   	pop    rbp
  4021e1:	5b                   	pop    rbx
  4021e2:	c3                   	ret
  4021e3:	53                   	push   rbx
  4021e4:	55                   	push   rbp
  4021e5:	41 53                	push   r11
  4021e7:	41 54                	push   r12
  4021e9:	41 55                	push   r13
  4021eb:	41 56                	push   r14
  4021ed:	41 57                	push   r15
  4021ef:	48 83 ec 10          	sub    rsp,0x10
  4021f3:	49 89 fc             	mov    r12,rdi
  4021f6:	49 89 f5             	mov    r13,rsi
  4021f9:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
  4021fe:	41 39 45 04          	cmp    DWORD PTR [r13+0x4],eax
  402202:	0f 85 bb 00 00 00    	jne    0x4022c3
  402208:	41 8b 5c 24 08       	mov    ebx,DWORD PTR [r12+0x8]
  40220d:	41 39 5d 08          	cmp    DWORD PTR [r13+0x8],ebx
  402211:	0f 85 ac 00 00 00    	jne    0x4022c3
  402217:	49 8d 7c 24 20       	lea    rdi,[r12+0x20]
  40221c:	89 d9                	mov    ecx,ebx
  40221e:	e8 f7 de ff ff       	call   0x40011a
  402223:	89 04 24             	mov    DWORD PTR [rsp],eax
  402226:	49 8d 7d 20          	lea    rdi,[r13+0x20]
  40222a:	89 d9                	mov    ecx,ebx
  40222c:	e8 e9 de ff ff       	call   0x40011a
  402231:	89 44 24 08          	mov    DWORD PTR [rsp+0x8],eax
  402235:	83 3c 24 ff          	cmp    DWORD PTR [rsp],0xffffffff
  402239:	75 10                	jne    0x40224b
  40223b:	83 7c 24 08 ff       	cmp    DWORD PTR [rsp+0x8],0xffffffff
  402240:	74 6f                	je     0x4022b1
  402242:	49 83 7d 10 00       	cmp    QWORD PTR [r13+0x10],0x0
  402247:	75 6c                	jne    0x4022b5
  402249:	eb 71                	jmp    0x4022bc
  40224b:	83 7c 24 08 ff       	cmp    DWORD PTR [rsp+0x8],0xffffffff
  402250:	75 0a                	jne    0x40225c
  402252:	49 83 7c 24 10 00    	cmp    QWORD PTR [r12+0x10],0x0
  402258:	75 62                	jne    0x4022bc
  40225a:	eb 59                	jmp    0x4022b5
  40225c:	49 8b 44 24 10       	mov    rax,QWORD PTR [r12+0x10]
  402261:	49 8b 4d 10          	mov    rcx,QWORD PTR [r13+0x10]
  402265:	48 39 c8             	cmp    rax,rcx
  402268:	74 07                	je     0x402271
  40226a:	48 85 c0             	test   rax,rax
  40226d:	75 4d                	jne    0x4022bc
  40226f:	eb 44                	jmp    0x4022b5
  402271:	49 8b 54 24 18       	mov    rdx,QWORD PTR [r12+0x18]
  402276:	4d 8b 45 18          	mov    r8,QWORD PTR [r13+0x18]
  40227a:	4c 39 c2             	cmp    rdx,r8
  40227d:	74 10                	je     0x40228f
  40227f:	77 07                	ja     0x402288
  402281:	48 85 c0             	test   rax,rax
  402284:	75 2f                	jne    0x4022b5
  402286:	eb 34                	jmp    0x4022bc
  402288:	48 85 c0             	test   rax,rax
  40228b:	75 2f                	jne    0x4022bc
  40228d:	eb 26                	jmp    0x4022b5
  40228f:	49 8d 7c 24 20       	lea    rdi,[r12+0x20]
  402294:	49 8d 75 20          	lea    rsi,[r13+0x20]
  402298:	89 d9                	mov    ecx,ebx
  40229a:	e8 a0 de ff ff       	call   0x40013f
  40229f:	85 c0                	test   eax,eax
  4022a1:	74 0e                	je     0x4022b1
  4022a3:	49 8b 4c 24 10       	mov    rcx,QWORD PTR [r12+0x10]
  4022a8:	48 85 c9             	test   rcx,rcx
  4022ab:	74 18                	je     0x4022c5
  4022ad:	f7 d8                	neg    eax
  4022af:	eb 14                	jmp    0x4022c5
  4022b1:	31 c0                	xor    eax,eax
  4022b3:	eb 10                	jmp    0x4022c5
  4022b5:	b8 01 00 00 00       	mov    eax,0x1
  4022ba:	eb 09                	jmp    0x4022c5
  4022bc:	b8 ff ff ff ff       	mov    eax,0xffffffff
  4022c1:	eb 02                	jmp    0x4022c5
  4022c3:	31 c0                	xor    eax,eax
  4022c5:	48 83 c4 10          	add    rsp,0x10
  4022c9:	41 5f                	pop    r15
  4022cb:	41 5e                	pop    r14
  4022cd:	41 5d                	pop    r13
  4022cf:	41 5c                	pop    r12
  4022d1:	41 5b                	pop    r11
  4022d3:	5d                   	pop    rbp
  4022d4:	5b                   	pop    rbx
  4022d5:	c3                   	ret
  4022d6:	53                   	push   rbx
  4022d7:	41 54                	push   r12
  4022d9:	41 55                	push   r13
  4022db:	49 89 fc             	mov    r12,rdi
  4022de:	49 89 f5             	mov    r13,rsi
  4022e1:	41 8b 5d 00          	mov    ebx,DWORD PTR [r13+0x0]
  4022e5:	4c 89 e7             	mov    rdi,r12
  4022e8:	4c 89 ee             	mov    rsi,r13
  4022eb:	89 da                	mov    edx,ebx
  4022ed:	e8 93 e4 ff ff       	call   0x400785
  4022f2:	85 d2                	test   edx,edx
  4022f4:	75 06                	jne    0x4022fc
  4022f6:	49 83 74 24 10 01    	xor    QWORD PTR [r12+0x10],0x1
  4022fc:	4c 89 e0             	mov    rax,r12
  4022ff:	41 5d                	pop    r13
  402301:	41 5c                	pop    r12
  402303:	5b                   	pop    rbx
  402304:	c3                   	ret
  402305:	41 54                	push   r12
  402307:	41 55                	push   r13
  402309:	49 89 fc             	mov    r12,rdi
  40230c:	49 89 f5             	mov    r13,rsi
  40230f:	41 8b 55 00          	mov    edx,DWORD PTR [r13+0x0]
  402313:	e8 6d e4 ff ff       	call   0x400785
  402318:	85 d2                	test   edx,edx
  40231a:	75 09                	jne    0x402325
  40231c:	49 c7 44 24 10 00 00 	mov    QWORD PTR [r12+0x10],0x0
  402323:	00 00 
  402325:	4c 89 e0             	mov    rax,r12
  402328:	41 5d                	pop    r13
  40232a:	41 5c                	pop    r12
  40232c:	c3                   	ret
  40232d:	e8 ac dd ff ff       	call   0x4000de
  402332:	85 c0                	test   eax,eax
  402334:	74 16                	je     0x40234c
  402336:	48 69 c0 00 02 00 00 	imul   rax,rax,0x200
  40233d:	48 05 00 10 00 00    	add    rax,0x1000
  402343:	48 83 c0 3f          	add    rax,0x3f
  402347:	48 83 e0 c0          	and    rax,0xffffffffffffffc0
  40234b:	c3                   	ret
  40234c:	31 c0                	xor    eax,eax
  40234e:	c3                   	ret
  40234f:	89 d0                	mov    eax,edx
  402351:	48 0f af c6          	imul   rax,rsi
  402355:	48 01 f8             	add    rax,rdi
  402358:	c3                   	ret
  402359:	53                   	push   rbx
  40235a:	55                   	push   rbp
  40235b:	41 53                	push   r11
  40235d:	41 54                	push   r12
  40235f:	41 55                	push   r13
  402361:	41 56                	push   r14
  402363:	41 57                	push   r15
  402365:	49 89 fc             	mov    r12,rdi
  402368:	41 89 f5             	mov    r13d,esi
  40236b:	49 89 d6             	mov    r14,rdx
  40236e:	4c 89 e7             	mov    rdi,r12
  402371:	44 89 ee             	mov    esi,r13d
  402374:	e8 5d df ff ff       	call   0x4002d6
  402379:	85 c0                	test   eax,eax
  40237b:	75 1e                	jne    0x40239b
  40237d:	4d 89 74 24 18       	mov    QWORD PTR [r12+0x18],r14
  402382:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
  402387:	ff c8                	dec    eax
  402389:	89 c2                	mov    edx,eax
  40238b:	c1 ea 06             	shr    edx,0x6
  40238e:	83 e0 3f             	and    eax,0x3f
  402391:	49 0f ab 44 d4 20    	bts    QWORD PTR [r12+rdx*8+0x20],rax
  402397:	31 c0                	xor    eax,eax
  402399:	eb 05                	jmp    0x4023a0
  40239b:	b8 01 00 00 00       	mov    eax,0x1
  4023a0:	41 5f                	pop    r15
  4023a2:	41 5e                	pop    r14
  4023a4:	41 5d                	pop    r13
  4023a6:	41 5c                	pop    r12
  4023a8:	41 5b                	pop    r11
  4023aa:	5d                   	pop    rbp
  4023ab:	5b                   	pop    rbx
  4023ac:	c3                   	ret
  4023ad:	57                   	push   rdi
  4023ae:	51                   	push   rcx
  4023af:	8b 4f 08             	mov    ecx,DWORD PTR [rdi+0x8]
  4023b2:	48 8d 7f 20          	lea    rdi,[rdi+0x20]
  4023b6:	e8 5f dd ff ff       	call   0x40011a
  4023bb:	85 c0                	test   eax,eax
  4023bd:	0f 98 c0             	sets   al
  4023c0:	0f b6 c0             	movzx  eax,al
  4023c3:	59                   	pop    rcx
  4023c4:	5f                   	pop    rdi
  4023c5:	c3                   	ret
  4023c6:	e8 ba e3 ff ff       	call   0x400785
  4023cb:	89 d0                	mov    eax,edx
  4023cd:	c3                   	ret
  4023ce:	53                   	push   rbx
  4023cf:	55                   	push   rbp
  4023d0:	41 53                	push   r11
  4023d2:	41 54                	push   r12
  4023d4:	41 55                	push   r13
  4023d6:	41 56                	push   r14
  4023d8:	41 57                	push   r15
  4023da:	48 83 ec 30          	sub    rsp,0x30
  4023de:	49 89 fc             	mov    r12,rdi
  4023e1:	49 89 f5             	mov    r13,rsi
  4023e4:	41 89 d6             	mov    r14d,edx
  4023e7:	44 89 f7             	mov    edi,r14d
  4023ea:	e8 3e ff ff ff       	call   0x40232d
  4023ef:	48 85 c0             	test   rax,rax
  4023f2:	0f 84 da 02 00 00    	je     0x4026d2
  4023f8:	49 89 c7             	mov    r15,rax
  4023fb:	45 39 75 00          	cmp    DWORD PTR [r13+0x0],r14d
  4023ff:	0f 85 cd 02 00 00    	jne    0x4026d2
  402405:	4c 89 ef             	mov    rdi,r13
  402408:	e8 a0 ff ff ff       	call   0x4023ad
  40240d:	85 c0                	test   eax,eax
  40240f:	0f 85 ad 02 00 00    	jne    0x4026c2
  402415:	49 83 7d 10 00       	cmp    QWORD PTR [r13+0x10],0x0
  40241a:	0f 85 b2 02 00 00    	jne    0x4026d2
  402420:	4c 89 e7             	mov    rdi,r12
  402423:	4c 89 fe             	mov    rsi,r15
  402426:	ba 01 00 00 00       	mov    edx,0x1
  40242b:	e8 1f ff ff ff       	call   0x40234f
  402430:	48 89 04 24          	mov    QWORD PTR [rsp],rax
  402434:	49 8b 55 18          	mov    rdx,QWORD PTR [r13+0x18]
  402438:	48 89 d0             	mov    rax,rdx
  40243b:	83 e0 01             	and    eax,0x1
  40243e:	48 01 c2             	add    rdx,rax
  402441:	48 d1 fa             	sar    rdx,1
  402444:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  402448:	44 89 f6             	mov    esi,r14d
  40244b:	e8 09 ff ff ff       	call   0x402359
  402450:	85 c0                	test   eax,eax
  402452:	0f 85 7a 02 00 00    	jne    0x4026d2
  402458:	4c 89 e7             	mov    rdi,r12
  40245b:	4c 89 fe             	mov    rsi,r15
  40245e:	ba 05 00 00 00       	mov    edx,0x5
  402463:	e8 e7 fe ff ff       	call   0x40234f
  402468:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  40246d:	48 89 c7             	mov    rdi,rax
  402470:	31 f6                	xor    esi,esi
  402472:	44 89 f2             	mov    edx,r14d
  402475:	e8 2d e1 ff ff       	call   0x4005a7
  40247a:	85 d2                	test   edx,edx
  40247c:	0f 85 50 02 00 00    	jne    0x4026d2
  402482:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
  402486:	83 c5 04             	add    ebp,0x4
  402489:	85 ed                	test   ebp,ebp
  40248b:	0f 84 00 02 00 00    	je     0x402691
  402491:	4c 89 e7             	mov    rdi,r12
  402494:	4c 89 fe             	mov    rsi,r15
  402497:	ba 02 00 00 00       	mov    edx,0x2
  40249c:	e8 ae fe ff ff       	call   0x40234f
  4024a1:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  4024a6:	48 89 c7             	mov    rdi,rax
  4024a9:	4c 89 ee             	mov    rsi,r13
  4024ac:	48 8b 14 24          	mov    rdx,QWORD PTR [rsp]
  4024b0:	44 89 f1             	mov    ecx,r14d
  4024b3:	e8 1a f8 ff ff       	call   0x401cd2
  4024b8:	85 c0                	test   eax,eax
  4024ba:	0f 85 12 02 00 00    	jne    0x4026d2
  4024c0:	4c 89 e7             	mov    rdi,r12
  4024c3:	4c 89 fe             	mov    rsi,r15
  4024c6:	ba 03 00 00 00       	mov    edx,0x3
  4024cb:	e8 7f fe ff ff       	call   0x40234f
  4024d0:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  4024d5:	48 89 c7             	mov    rdi,rax
  4024d8:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  4024dc:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
  4024e1:	44 89 f1             	mov    ecx,r14d
  4024e4:	e8 bd e4 ff ff       	call   0x4009a6
  4024e9:	85 c0                	test   eax,eax
  4024eb:	0f 85 e1 01 00 00    	jne    0x4026d2
  4024f1:	4c 89 e7             	mov    rdi,r12
  4024f4:	4c 89 fe             	mov    rsi,r15
  4024f7:	ba 04 00 00 00       	mov    edx,0x4
  4024fc:	e8 4e fe ff ff       	call   0x40234f
  402501:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
  402506:	48 89 c7             	mov    rdi,rax
  402509:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  40250e:	44 89 f2             	mov    edx,r14d
  402511:	e8 b0 fe ff ff       	call   0x4023c6
  402516:	85 c0                	test   eax,eax
  402518:	0f 85 b4 01 00 00    	jne    0x4026d2
  40251e:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
  402523:	e8 85 fe ff ff       	call   0x4023ad
  402528:	85 c0                	test   eax,eax
  40252a:	75 09                	jne    0x402535
  40252c:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
  402531:	48 ff 48 18          	dec    QWORD PTR [rax+0x18]
  402535:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
  40253a:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  40253e:	e8 a0 fc ff ff       	call   0x4021e3
  402543:	85 c0                	test   eax,eax
  402545:	0f 84 48 01 00 00    	je     0x402693
  40254b:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
  402550:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  402555:	e8 89 fc ff ff       	call   0x4021e3
  40255a:	85 c0                	test   eax,eax
  40255c:	74 39                	je     0x402597
  40255e:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  402563:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402567:	44 89 f2             	mov    edx,r14d
  40256a:	e8 57 fe ff ff       	call   0x4023c6
  40256f:	85 c0                	test   eax,eax
  402571:	0f 85 5b 01 00 00    	jne    0x4026d2
  402577:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  40257b:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  402580:	44 89 f2             	mov    edx,r14d
  402583:	e8 3e fe ff ff       	call   0x4023c6
  402588:	85 c0                	test   eax,eax
  40258a:	0f 85 42 01 00 00    	jne    0x4026d2
  402590:	ff cd                	dec    ebp
  402592:	e9 f2 fe ff ff       	jmp    0x402489
  402597:	4c 89 e7             	mov    rdi,r12
  40259a:	4c 89 fe             	mov    rsi,r15
  40259d:	ba 06 00 00 00       	mov    edx,0x6
  4025a2:	e8 a8 fd ff ff       	call   0x40234f
  4025a7:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  4025ac:	48 89 c7             	mov    rdi,rax
  4025af:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  4025b3:	48 8b 14 24          	mov    rdx,QWORD PTR [rsp]
  4025b7:	44 89 f1             	mov    ecx,r14d
  4025ba:	e8 48 f6 ff ff       	call   0x401c07
  4025bf:	85 c0                	test   eax,eax
  4025c1:	0f 85 0b 01 00 00    	jne    0x4026d2
  4025c7:	4c 89 e7             	mov    rdi,r12
  4025ca:	4c 89 fe             	mov    rsi,r15
  4025cd:	ba 07 00 00 00       	mov    edx,0x7
  4025d2:	e8 78 fd ff ff       	call   0x40234f
  4025d7:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  4025dc:	48 89 c7             	mov    rdi,rax
  4025df:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  4025e4:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
  4025e9:	44 89 f1             	mov    ecx,r14d
  4025ec:	e8 16 f6 ff ff       	call   0x401c07
  4025f1:	85 c0                	test   eax,eax
  4025f3:	0f 85 d9 00 00 00    	jne    0x4026d2
  4025f9:	4c 89 e7             	mov    rdi,r12
  4025fc:	4c 89 fe             	mov    rsi,r15
  4025ff:	ba 08 00 00 00       	mov    edx,0x8
  402604:	e8 46 fd ff ff       	call   0x40234f
  402609:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  40260e:	48 89 c7             	mov    rdi,rax
  402611:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  402616:	4c 89 ea             	mov    rdx,r13
  402619:	44 89 f1             	mov    ecx,r14d
  40261c:	e8 8d e3 ff ff       	call   0x4009ae
  402621:	85 c0                	test   eax,eax
  402623:	0f 85 a9 00 00 00    	jne    0x4026d2
  402629:	4c 89 e7             	mov    rdi,r12
  40262c:	4c 89 fe             	mov    rsi,r15
  40262f:	ba 09 00 00 00       	mov    edx,0x9
  402634:	e8 16 fd ff ff       	call   0x40234f
  402639:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  40263e:	48 89 c7             	mov    rdi,rax
  402641:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  402646:	4c 89 ea             	mov    rdx,r13
  402649:	44 89 f1             	mov    ecx,r14d
  40264c:	e8 5d e3 ff ff       	call   0x4009ae
  402651:	85 c0                	test   eax,eax
  402653:	75 7d                	jne    0x4026d2
  402655:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  40265a:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  40265f:	e8 a1 fc ff ff       	call   0x402305
  402664:	85 d2                	test   edx,edx
  402666:	75 6a                	jne    0x4026d2
  402668:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  40266d:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  402672:	e8 8e fc ff ff       	call   0x402305
  402677:	85 d2                	test   edx,edx
  402679:	75 57                	jne    0x4026d2
  40267b:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  402680:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  402685:	e8 59 fb ff ff       	call   0x4021e3
  40268a:	83 f8 00             	cmp    eax,0x0
  40268d:	7c 04                	jl     0x402693
  40268f:	eb 1a                	jmp    0x4026ab
  402691:	eb 18                	jmp    0x4026ab
  402693:	4c 89 e7             	mov    rdi,r12
  402696:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  40269b:	44 89 f2             	mov    edx,r14d
  40269e:	e8 23 fd ff ff       	call   0x4023c6
  4026a3:	85 c0                	test   eax,eax
  4026a5:	75 2b                	jne    0x4026d2
  4026a7:	31 c0                	xor    eax,eax
  4026a9:	eb 2c                	jmp    0x4026d7
  4026ab:	4c 89 e7             	mov    rdi,r12
  4026ae:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  4026b2:	44 89 f2             	mov    edx,r14d
  4026b5:	e8 0c fd ff ff       	call   0x4023c6
  4026ba:	85 c0                	test   eax,eax
  4026bc:	75 14                	jne    0x4026d2
  4026be:	31 c0                	xor    eax,eax
  4026c0:	eb 15                	jmp    0x4026d7
  4026c2:	4c 89 e7             	mov    rdi,r12
  4026c5:	4c 89 ee             	mov    rsi,r13
  4026c8:	44 89 f2             	mov    edx,r14d
  4026cb:	e8 f6 fc ff ff       	call   0x4023c6
  4026d0:	eb 05                	jmp    0x4026d7
  4026d2:	b8 01 00 00 00       	mov    eax,0x1
  4026d7:	48 83 c4 30          	add    rsp,0x30
  4026db:	41 5f                	pop    r15
  4026dd:	41 5e                	pop    r14
  4026df:	41 5d                	pop    r13
  4026e1:	41 5c                	pop    r12
  4026e3:	41 5b                	pop    r11
  4026e5:	5d                   	pop    rbp
  4026e6:	5b                   	pop    rbx
  4026e7:	c3                   	ret
  4026e8:	53                   	push   rbx
  4026e9:	55                   	push   rbp
  4026ea:	41 53                	push   r11
  4026ec:	41 54                	push   r12
  4026ee:	41 55                	push   r13
  4026f0:	41 56                	push   r14
  4026f2:	41 57                	push   r15
  4026f4:	48 83 ec 50          	sub    rsp,0x50
  4026f8:	49 89 fc             	mov    r12,rdi
  4026fb:	49 89 f5             	mov    r13,rsi
  4026fe:	41 89 d6             	mov    r14d,edx
  402701:	44 89 f7             	mov    edi,r14d
  402704:	e8 24 fc ff ff       	call   0x40232d
  402709:	48 85 c0             	test   rax,rax
  40270c:	0f 84 c4 02 00 00    	je     0x4029d6
  402712:	49 89 c7             	mov    r15,rax
  402715:	45 39 75 00          	cmp    DWORD PTR [r13+0x0],r14d
  402719:	0f 85 b7 02 00 00    	jne    0x4029d6
  40271f:	49 8b 45 10          	mov    rax,QWORD PTR [r13+0x10]
  402723:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
  402728:	4c 89 e7             	mov    rdi,r12
  40272b:	4c 89 fe             	mov    rsi,r15
  40272e:	ba 01 00 00 00       	mov    edx,0x1
  402733:	e8 17 fc ff ff       	call   0x40234f
  402738:	48 89 04 24          	mov    QWORD PTR [rsp],rax
  40273c:	48 89 c7             	mov    rdi,rax
  40273f:	4c 89 ee             	mov    rsi,r13
  402742:	44 89 f2             	mov    edx,r14d
  402745:	e8 7c fc ff ff       	call   0x4023c6
  40274a:	85 c0                	test   eax,eax
  40274c:	0f 85 84 02 00 00    	jne    0x4029d6
  402752:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
  402756:	48 c7 40 10 00 00 00 	mov    QWORD PTR [rax+0x10],0x0
  40275d:	00 
  40275e:	49 8b 5d 18          	mov    rbx,QWORD PTR [r13+0x18]
  402762:	48 85 db             	test   rbx,rbx
  402765:	7f 02                	jg     0x402769
  402767:	31 db                	xor    ebx,ebx
  402769:	48 89 5c 24 30       	mov    QWORD PTR [rsp+0x30],rbx
  40276e:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  402772:	e8 36 fc ff ff       	call   0x4023ad
  402777:	85 c0                	test   eax,eax
  402779:	75 08                	jne    0x402783
  40277b:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
  40277f:	48 29 58 18          	sub    QWORD PTR [rax+0x18],rbx
  402783:	4c 89 e7             	mov    rdi,r12
  402786:	4c 89 fe             	mov    rsi,r15
  402789:	ba 02 00 00 00       	mov    edx,0x2
  40278e:	e8 bc fb ff ff       	call   0x40234f
  402793:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  402798:	48 89 c7             	mov    rdi,rax
  40279b:	be 01 00 00 00       	mov    esi,0x1
  4027a0:	44 89 f2             	mov    edx,r14d
  4027a3:	e8 ff dd ff ff       	call   0x4005a7
  4027a8:	85 d2                	test   edx,edx
  4027aa:	0f 85 26 02 00 00    	jne    0x4029d6
  4027b0:	4c 89 e7             	mov    rdi,r12
  4027b3:	4c 89 fe             	mov    rsi,r15
  4027b6:	ba 03 00 00 00       	mov    edx,0x3
  4027bb:	e8 8f fb ff ff       	call   0x40234f
  4027c0:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  4027c5:	48 89 c7             	mov    rdi,rax
  4027c8:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  4027cd:	44 89 f2             	mov    edx,r14d
  4027d0:	e8 f1 fb ff ff       	call   0x4023c6
  4027d5:	85 c0                	test   eax,eax
  4027d7:	0f 85 f9 01 00 00    	jne    0x4029d6
  4027dd:	4c 89 e7             	mov    rdi,r12
  4027e0:	4c 89 fe             	mov    rsi,r15
  4027e3:	ba 04 00 00 00       	mov    edx,0x4
  4027e8:	e8 62 fb ff ff       	call   0x40234f
  4027ed:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  4027f2:	48 89 c7             	mov    rdi,rax
  4027f5:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  4027fa:	44 89 f2             	mov    edx,r14d
  4027fd:	e8 c4 fb ff ff       	call   0x4023c6
  402802:	85 c0                	test   eax,eax
  402804:	0f 85 cc 01 00 00    	jne    0x4029d6
  40280a:	48 c7 44 24 40 01 00 	mov    QWORD PTR [rsp+0x40],0x1
  402811:	00 00 
  402813:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
  402817:	83 c5 10             	add    ebp,0x10
  40281a:	85 ed                	test   ebp,ebp
  40281c:	0f 84 e2 00 00 00    	je     0x402904
  402822:	4c 89 e7             	mov    rdi,r12
  402825:	4c 89 fe             	mov    rsi,r15
  402828:	ba 05 00 00 00       	mov    edx,0x5
  40282d:	e8 1d fb ff ff       	call   0x40234f
  402832:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
  402837:	48 89 c7             	mov    rdi,rax
  40283a:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  40283f:	48 8b 14 24          	mov    rdx,QWORD PTR [rsp]
  402843:	44 89 f1             	mov    ecx,r14d
  402846:	e8 bc f3 ff ff       	call   0x401c07
  40284b:	85 c0                	test   eax,eax
  40284d:	0f 85 83 01 00 00    	jne    0x4029d6
  402853:	4c 89 e7             	mov    rdi,r12
  402856:	4c 89 fe             	mov    rsi,r15
  402859:	ba 06 00 00 00       	mov    edx,0x6
  40285e:	e8 ec fa ff ff       	call   0x40234f
  402863:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
  402868:	48 89 c7             	mov    rdi,rax
  40286b:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
  402870:	44 89 f2             	mov    edx,r14d
  402873:	e8 2f dd ff ff       	call   0x4005a7
  402878:	85 d2                	test   edx,edx
  40287a:	0f 85 56 01 00 00    	jne    0x4029d6
  402880:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  402885:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  40288a:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
  40288f:	44 89 f1             	mov    ecx,r14d
  402892:	e8 3b f4 ff ff       	call   0x401cd2
  402897:	85 c0                	test   eax,eax
  402899:	0f 85 37 01 00 00    	jne    0x4029d6
  40289f:	4c 89 e7             	mov    rdi,r12
  4028a2:	4c 89 fe             	mov    rsi,r15
  4028a5:	ba 07 00 00 00       	mov    edx,0x7
  4028aa:	e8 a0 fa ff ff       	call   0x40234f
  4028af:	48 89 c3             	mov    rbx,rax
  4028b2:	48 89 df             	mov    rdi,rbx
  4028b5:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  4028ba:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
  4028bf:	44 89 f1             	mov    ecx,r14d
  4028c2:	e8 df e0 ff ff       	call   0x4009a6
  4028c7:	85 c0                	test   eax,eax
  4028c9:	0f 85 07 01 00 00    	jne    0x4029d6
  4028cf:	48 89 df             	mov    rdi,rbx
  4028d2:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  4028d7:	e8 07 f9 ff ff       	call   0x4021e3
  4028dc:	85 c0                	test   eax,eax
  4028de:	74 24                	je     0x402904
  4028e0:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  4028e5:	48 89 de             	mov    rsi,rbx
  4028e8:	44 89 f2             	mov    edx,r14d
  4028eb:	e8 d6 fa ff ff       	call   0x4023c6
  4028f0:	85 c0                	test   eax,eax
  4028f2:	0f 85 de 00 00 00    	jne    0x4029d6
  4028f8:	48 ff 44 24 40       	inc    QWORD PTR [rsp+0x40]
  4028fd:	ff cd                	dec    ebp
  4028ff:	e9 16 ff ff ff       	jmp    0x40281a
  402904:	4c 89 e7             	mov    rdi,r12
  402907:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  40290c:	44 89 f2             	mov    edx,r14d
  40290f:	e8 b2 fa ff ff       	call   0x4023c6
  402914:	85 c0                	test   eax,eax
  402916:	0f 85 ba 00 00 00    	jne    0x4029d6
  40291c:	48 8b 6c 24 30       	mov    rbp,QWORD PTR [rsp+0x30]
  402921:	48 85 ed             	test   rbp,rbp
  402924:	74 43                	je     0x402969
  402926:	4c 89 e7             	mov    rdi,r12
  402929:	4c 89 fe             	mov    rsi,r15
  40292c:	ba 08 00 00 00       	mov    edx,0x8
  402931:	e8 19 fa ff ff       	call   0x40234f
  402936:	48 89 c3             	mov    rbx,rax
  402939:	48 89 df             	mov    rdi,rbx
  40293c:	4c 89 e6             	mov    rsi,r12
  40293f:	4c 89 e2             	mov    rdx,r12
  402942:	44 89 f1             	mov    ecx,r14d
  402945:	e8 bd f2 ff ff       	call   0x401c07
  40294a:	85 c0                	test   eax,eax
  40294c:	0f 85 84 00 00 00    	jne    0x4029d6
  402952:	4c 89 e7             	mov    rdi,r12
  402955:	48 89 de             	mov    rsi,rbx
  402958:	44 89 f2             	mov    edx,r14d
  40295b:	e8 66 fa ff ff       	call   0x4023c6
  402960:	85 c0                	test   eax,eax
  402962:	75 72                	jne    0x4029d6
  402964:	48 ff cd             	dec    rbp
  402967:	eb b8                	jmp    0x402921
  402969:	48 83 7c 24 38 00    	cmp    QWORD PTR [rsp+0x38],0x0
  40296f:	74 61                	je     0x4029d2
  402971:	4c 89 e7             	mov    rdi,r12
  402974:	4c 89 fe             	mov    rsi,r15
  402977:	ba 09 00 00 00       	mov    edx,0x9
  40297c:	e8 ce f9 ff ff       	call   0x40234f
  402981:	48 89 c3             	mov    rbx,rax
  402984:	48 89 df             	mov    rdi,rbx
  402987:	be 01 00 00 00       	mov    esi,0x1
  40298c:	44 89 f2             	mov    edx,r14d
  40298f:	e8 13 dc ff ff       	call   0x4005a7
  402994:	85 d2                	test   edx,edx
  402996:	75 3e                	jne    0x4029d6
  402998:	4c 89 e7             	mov    rdi,r12
  40299b:	4c 89 fe             	mov    rsi,r15
  40299e:	ba 0a 00 00 00       	mov    edx,0xa
  4029a3:	e8 a7 f9 ff ff       	call   0x40234f
  4029a8:	48 89 c5             	mov    rbp,rax
  4029ab:	48 89 ef             	mov    rdi,rbp
  4029ae:	48 89 de             	mov    rsi,rbx
  4029b1:	4c 89 e2             	mov    rdx,r12
  4029b4:	44 89 f1             	mov    ecx,r14d
  4029b7:	e8 16 f3 ff ff       	call   0x401cd2
  4029bc:	85 c0                	test   eax,eax
  4029be:	75 16                	jne    0x4029d6
  4029c0:	4c 89 e7             	mov    rdi,r12
  4029c3:	48 89 ee             	mov    rsi,rbp
  4029c6:	44 89 f2             	mov    edx,r14d
  4029c9:	e8 f8 f9 ff ff       	call   0x4023c6
  4029ce:	85 c0                	test   eax,eax
  4029d0:	75 04                	jne    0x4029d6
  4029d2:	31 c0                	xor    eax,eax
  4029d4:	eb 05                	jmp    0x4029db
  4029d6:	b8 01 00 00 00       	mov    eax,0x1
  4029db:	48 83 c4 50          	add    rsp,0x50
  4029df:	41 5f                	pop    r15
  4029e1:	41 5e                	pop    r14
  4029e3:	41 5d                	pop    r13
  4029e5:	41 5c                	pop    r12
  4029e7:	41 5b                	pop    r11
  4029e9:	5d                   	pop    rbp
  4029ea:	5b                   	pop    rbx
  4029eb:	c3                   	ret
  4029ec:	53                   	push   rbx
  4029ed:	55                   	push   rbp
  4029ee:	41 53                	push   r11
  4029f0:	41 54                	push   r12
  4029f2:	41 55                	push   r13
  4029f4:	41 56                	push   r14
  4029f6:	41 57                	push   r15
  4029f8:	48 83 ec 60          	sub    rsp,0x60
  4029fc:	49 89 fc             	mov    r12,rdi
  4029ff:	49 89 f5             	mov    r13,rsi
  402a02:	41 89 d6             	mov    r14d,edx
  402a05:	44 89 f7             	mov    edi,r14d
  402a08:	e8 20 f9 ff ff       	call   0x40232d
  402a0d:	48 85 c0             	test   rax,rax
  402a10:	0f 84 55 03 00 00    	je     0x402d6b
  402a16:	49 89 c7             	mov    r15,rax
  402a19:	45 39 75 00          	cmp    DWORD PTR [r13+0x0],r14d
  402a1d:	0f 85 48 03 00 00    	jne    0x402d6b
  402a23:	4c 89 ef             	mov    rdi,r13
  402a26:	e8 82 f9 ff ff       	call   0x4023ad
  402a2b:	85 c0                	test   eax,eax
  402a2d:	0f 85 38 03 00 00    	jne    0x402d6b
  402a33:	49 83 7d 10 00       	cmp    QWORD PTR [r13+0x10],0x0
  402a38:	0f 85 2d 03 00 00    	jne    0x402d6b
  402a3e:	4c 89 e7             	mov    rdi,r12
  402a41:	4c 89 fe             	mov    rsi,r15
  402a44:	ba 01 00 00 00       	mov    edx,0x1
  402a49:	e8 01 f9 ff ff       	call   0x40234f
  402a4e:	48 89 04 24          	mov    QWORD PTR [rsp],rax
  402a52:	48 89 c7             	mov    rdi,rax
  402a55:	4c 89 ee             	mov    rsi,r13
  402a58:	44 89 f2             	mov    edx,r14d
  402a5b:	e8 66 f9 ff ff       	call   0x4023c6
  402a60:	85 c0                	test   eax,eax
  402a62:	0f 85 03 03 00 00    	jne    0x402d6b
  402a68:	4c 89 e7             	mov    rdi,r12
  402a6b:	4c 89 fe             	mov    rsi,r15
  402a6e:	ba 02 00 00 00       	mov    edx,0x2
  402a73:	e8 d7 f8 ff ff       	call   0x40234f
  402a78:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  402a7d:	48 89 c7             	mov    rdi,rax
  402a80:	be 01 00 00 00       	mov    esi,0x1
  402a85:	44 89 f2             	mov    edx,r14d
  402a88:	e8 1a db ff ff       	call   0x4005a7
  402a8d:	85 d2                	test   edx,edx
  402a8f:	0f 85 d6 02 00 00    	jne    0x402d6b
  402a95:	31 db                	xor    ebx,ebx
  402a97:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
  402a9b:	48 8b 48 18          	mov    rcx,QWORD PTR [rax+0x18]
  402a9f:	48 83 f9 00          	cmp    rcx,0x0
  402aa3:	7f 08                	jg     0x402aad
  402aa5:	48 83 f9 ff          	cmp    rcx,0xffffffffffffffff
  402aa9:	7c 02                	jl     0x402aad
  402aab:	eb 49                	jmp    0x402af6
  402aad:	4c 89 e7             	mov    rdi,r12
  402ab0:	4c 89 fe             	mov    rsi,r15
  402ab3:	ba 10 00 00 00       	mov    edx,0x10
  402ab8:	e8 92 f8 ff ff       	call   0x40234f
  402abd:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
  402ac2:	48 89 c7             	mov    rdi,rax
  402ac5:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402ac9:	44 89 f2             	mov    edx,r14d
  402acc:	e8 fd f8 ff ff       	call   0x4023ce
  402ad1:	85 c0                	test   eax,eax
  402ad3:	0f 85 92 02 00 00    	jne    0x402d6b
  402ad9:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  402add:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
  402ae2:	44 89 f2             	mov    edx,r14d
  402ae5:	e8 dc f8 ff ff       	call   0x4023c6
  402aea:	85 c0                	test   eax,eax
  402aec:	0f 85 79 02 00 00    	jne    0x402d6b
  402af2:	ff c3                	inc    ebx
  402af4:	eb a1                	jmp    0x402a97
  402af6:	48 89 5c 24 48       	mov    QWORD PTR [rsp+0x48],rbx
  402afb:	4c 89 e7             	mov    rdi,r12
  402afe:	4c 89 fe             	mov    rsi,r15
  402b01:	ba 03 00 00 00       	mov    edx,0x3
  402b06:	e8 44 f8 ff ff       	call   0x40234f
  402b0b:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  402b10:	48 89 c7             	mov    rdi,rax
  402b13:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402b17:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  402b1c:	44 89 f1             	mov    ecx,r14d
  402b1f:	e8 8a de ff ff       	call   0x4009ae
  402b24:	85 c0                	test   eax,eax
  402b26:	0f 85 3f 02 00 00    	jne    0x402d6b
  402b2c:	4c 89 e7             	mov    rdi,r12
  402b2f:	4c 89 fe             	mov    rsi,r15
  402b32:	ba 04 00 00 00       	mov    edx,0x4
  402b37:	e8 13 f8 ff ff       	call   0x40234f
  402b3c:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  402b41:	48 89 c7             	mov    rdi,rax
  402b44:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402b48:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  402b4d:	44 89 f1             	mov    ecx,r14d
  402b50:	e8 51 de ff ff       	call   0x4009a6
  402b55:	85 c0                	test   eax,eax
  402b57:	0f 85 0e 02 00 00    	jne    0x402d6b
  402b5d:	4c 89 e7             	mov    rdi,r12
  402b60:	4c 89 fe             	mov    rsi,r15
  402b63:	ba 05 00 00 00       	mov    edx,0x5
  402b68:	e8 e2 f7 ff ff       	call   0x40234f
  402b6d:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
  402b72:	48 89 c7             	mov    rdi,rax
  402b75:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  402b7a:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
  402b7f:	44 89 f1             	mov    ecx,r14d
  402b82:	e8 4b f1 ff ff       	call   0x401cd2
  402b87:	85 c0                	test   eax,eax
  402b89:	0f 85 dc 01 00 00    	jne    0x402d6b
  402b8f:	4c 89 e7             	mov    rdi,r12
  402b92:	4c 89 fe             	mov    rsi,r15
  402b95:	ba 06 00 00 00       	mov    edx,0x6
  402b9a:	e8 b0 f7 ff ff       	call   0x40234f
  402b9f:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
  402ba4:	48 89 c7             	mov    rdi,rax
  402ba7:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  402bac:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
  402bb1:	44 89 f1             	mov    ecx,r14d
  402bb4:	e8 4e f0 ff ff       	call   0x401c07
  402bb9:	85 c0                	test   eax,eax
  402bbb:	0f 85 aa 01 00 00    	jne    0x402d6b
  402bc1:	4c 89 e7             	mov    rdi,r12
  402bc4:	4c 89 fe             	mov    rsi,r15
  402bc7:	ba 07 00 00 00       	mov    edx,0x7
  402bcc:	e8 7e f7 ff ff       	call   0x40234f
  402bd1:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
  402bd6:	48 89 c7             	mov    rdi,rax
  402bd9:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  402bde:	44 89 f2             	mov    edx,r14d
  402be1:	e8 e0 f7 ff ff       	call   0x4023c6
  402be6:	85 c0                	test   eax,eax
  402be8:	0f 85 7d 01 00 00    	jne    0x402d6b
  402bee:	4c 89 e7             	mov    rdi,r12
  402bf1:	4c 89 fe             	mov    rsi,r15
  402bf4:	ba 08 00 00 00       	mov    edx,0x8
  402bf9:	e8 51 f7 ff ff       	call   0x40234f
  402bfe:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
  402c03:	48 89 c7             	mov    rdi,rax
  402c06:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  402c0b:	44 89 f2             	mov    edx,r14d
  402c0e:	e8 b3 f7 ff ff       	call   0x4023c6
  402c13:	85 c0                	test   eax,eax
  402c15:	0f 85 50 01 00 00    	jne    0x402d6b
  402c1b:	48 c7 44 24 50 03 00 	mov    QWORD PTR [rsp+0x50],0x3
  402c22:	00 00 
  402c24:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
  402c28:	83 c5 10             	add    ebp,0x10
  402c2b:	85 ed                	test   ebp,ebp
  402c2d:	0f 84 07 01 00 00    	je     0x402d3a
  402c33:	4c 89 e7             	mov    rdi,r12
  402c36:	4c 89 fe             	mov    rsi,r15
  402c39:	ba 09 00 00 00       	mov    edx,0x9
  402c3e:	e8 0c f7 ff ff       	call   0x40234f
  402c43:	48 89 c3             	mov    rbx,rax
  402c46:	48 89 df             	mov    rdi,rbx
  402c49:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
  402c4e:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
  402c53:	44 89 f1             	mov    ecx,r14d
  402c56:	e8 ac ef ff ff       	call   0x401c07
  402c5b:	85 c0                	test   eax,eax
  402c5d:	0f 85 08 01 00 00    	jne    0x402d6b
  402c63:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
  402c68:	48 89 de             	mov    rsi,rbx
  402c6b:	44 89 f2             	mov    edx,r14d
  402c6e:	e8 53 f7 ff ff       	call   0x4023c6
  402c73:	85 c0                	test   eax,eax
  402c75:	0f 85 f0 00 00 00    	jne    0x402d6b
  402c7b:	4c 89 e7             	mov    rdi,r12
  402c7e:	4c 89 fe             	mov    rsi,r15
  402c81:	ba 0a 00 00 00       	mov    edx,0xa
  402c86:	e8 c4 f6 ff ff       	call   0x40234f
  402c8b:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
  402c90:	48 89 c7             	mov    rdi,rax
  402c93:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
  402c98:	44 89 f2             	mov    edx,r14d
  402c9b:	e8 07 d9 ff ff       	call   0x4005a7
  402ca0:	85 d2                	test   edx,edx
  402ca2:	0f 85 c3 00 00 00    	jne    0x402d6b
  402ca8:	4c 89 e7             	mov    rdi,r12
  402cab:	4c 89 fe             	mov    rsi,r15
  402cae:	ba 0b 00 00 00       	mov    edx,0xb
  402cb3:	e8 97 f6 ff ff       	call   0x40234f
  402cb8:	48 89 c3             	mov    rbx,rax
  402cbb:	48 89 df             	mov    rdi,rbx
  402cbe:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
  402cc3:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
  402cc8:	44 89 f1             	mov    ecx,r14d
  402ccb:	e8 02 f0 ff ff       	call   0x401cd2
  402cd0:	85 c0                	test   eax,eax
  402cd2:	0f 85 93 00 00 00    	jne    0x402d6b
  402cd8:	4c 89 e7             	mov    rdi,r12
  402cdb:	4c 89 fe             	mov    rsi,r15
  402cde:	ba 0c 00 00 00       	mov    edx,0xc
  402ce3:	e8 67 f6 ff ff       	call   0x40234f
  402ce8:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
  402ced:	48 89 c7             	mov    rdi,rax
  402cf0:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  402cf5:	48 89 da             	mov    rdx,rbx
  402cf8:	44 89 f1             	mov    ecx,r14d
  402cfb:	e8 a6 dc ff ff       	call   0x4009a6
  402d00:	85 c0                	test   eax,eax
  402d02:	75 67                	jne    0x402d6b
  402d04:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
  402d09:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  402d0e:	e8 d0 f4 ff ff       	call   0x4021e3
  402d13:	85 c0                	test   eax,eax
  402d15:	74 23                	je     0x402d3a
  402d17:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  402d1c:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
  402d21:	44 89 f2             	mov    edx,r14d
  402d24:	e8 9d f6 ff ff       	call   0x4023c6
  402d29:	85 c0                	test   eax,eax
  402d2b:	75 3e                	jne    0x402d6b
  402d2d:	48 83 44 24 50 02    	add    QWORD PTR [rsp+0x50],0x2
  402d33:	ff cd                	dec    ebp
  402d35:	e9 f1 fe ff ff       	jmp    0x402c2b
  402d3a:	4c 89 e7             	mov    rdi,r12
  402d3d:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  402d42:	44 89 f2             	mov    edx,r14d
  402d45:	e8 7c f6 ff ff       	call   0x4023c6
  402d4a:	85 c0                	test   eax,eax
  402d4c:	75 1d                	jne    0x402d6b
  402d4e:	4c 89 e7             	mov    rdi,r12
  402d51:	e8 57 f6 ff ff       	call   0x4023ad
  402d56:	85 c0                	test   eax,eax
  402d58:	75 0d                	jne    0x402d67
  402d5a:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
  402d5f:	48 ff c0             	inc    rax
  402d62:	49 01 44 24 18       	add    QWORD PTR [r12+0x18],rax
  402d67:	31 c0                	xor    eax,eax
  402d69:	eb 05                	jmp    0x402d70
  402d6b:	b8 01 00 00 00       	mov    eax,0x1
  402d70:	48 83 c4 60          	add    rsp,0x60
  402d74:	41 5f                	pop    r15
  402d76:	41 5e                	pop    r14
  402d78:	41 5d                	pop    r13
  402d7a:	41 5c                	pop    r12
  402d7c:	41 5b                	pop    r11
  402d7e:	5d                   	pop    rbp
  402d7f:	5b                   	pop    rbx
  402d80:	c3                   	ret
  402d81:	53                   	push   rbx
  402d82:	55                   	push   rbp
  402d83:	41 53                	push   r11
  402d85:	41 54                	push   r12
  402d87:	41 55                	push   r13
  402d89:	41 56                	push   r14
  402d8b:	41 57                	push   r15
  402d8d:	48 81 ec 80 00 00 00 	sub    rsp,0x80
  402d94:	49 89 fc             	mov    r12,rdi
  402d97:	49 89 f5             	mov    r13,rsi
  402d9a:	41 89 d6             	mov    r14d,edx
  402d9d:	89 4c 24 78          	mov    DWORD PTR [rsp+0x78],ecx
  402da1:	44 89 f7             	mov    edi,r14d
  402da4:	e8 84 f5 ff ff       	call   0x40232d
  402da9:	48 85 c0             	test   rax,rax
  402dac:	0f 84 1c 05 00 00    	je     0x4032ce
  402db2:	49 89 c7             	mov    r15,rax
  402db5:	45 39 75 00          	cmp    DWORD PTR [r13+0x0],r14d
  402db9:	0f 85 0f 05 00 00    	jne    0x4032ce
  402dbf:	4c 89 e7             	mov    rdi,r12
  402dc2:	4c 89 fe             	mov    rsi,r15
  402dc5:	ba 01 00 00 00       	mov    edx,0x1
  402dca:	e8 80 f5 ff ff       	call   0x40234f
  402dcf:	48 89 04 24          	mov    QWORD PTR [rsp],rax
  402dd3:	48 89 c7             	mov    rdi,rax
  402dd6:	4c 89 ee             	mov    rsi,r13
  402dd9:	44 89 f2             	mov    edx,r14d
  402ddc:	e8 e5 f5 ff ff       	call   0x4023c6
  402de1:	85 c0                	test   eax,eax
  402de3:	0f 85 e5 04 00 00    	jne    0x4032ce
  402de9:	49 8b 45 18          	mov    rax,QWORD PTR [r13+0x18]
  402ded:	48 85 c0             	test   rax,rax
  402df0:	7f 02                	jg     0x402df4
  402df2:	31 c0                	xor    eax,eax
  402df4:	48 89 44 24 68       	mov    QWORD PTR [rsp+0x68],rax
  402df9:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  402dfd:	e8 ab f5 ff ff       	call   0x4023ad
  402e02:	85 c0                	test   eax,eax
  402e04:	75 0d                	jne    0x402e13
  402e06:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
  402e0a:	48 8b 4c 24 68       	mov    rcx,QWORD PTR [rsp+0x68]
  402e0f:	48 29 48 18          	sub    QWORD PTR [rax+0x18],rcx
  402e13:	4c 89 e7             	mov    rdi,r12
  402e16:	4c 89 fe             	mov    rsi,r15
  402e19:	ba 02 00 00 00       	mov    edx,0x2
  402e1e:	e8 2c f5 ff ff       	call   0x40234f
  402e23:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  402e28:	48 89 c7             	mov    rdi,rax
  402e2b:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402e2f:	48 8b 14 24          	mov    rdx,QWORD PTR [rsp]
  402e33:	44 89 f1             	mov    ecx,r14d
  402e36:	e8 cc ed ff ff       	call   0x401c07
  402e3b:	85 c0                	test   eax,eax
  402e3d:	0f 85 8b 04 00 00    	jne    0x4032ce
  402e43:	4c 89 e7             	mov    rdi,r12
  402e46:	4c 89 fe             	mov    rsi,r15
  402e49:	ba 03 00 00 00       	mov    edx,0x3
  402e4e:	e8 fc f4 ff ff       	call   0x40234f
  402e53:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  402e58:	48 89 c7             	mov    rdi,rax
  402e5b:	be 01 00 00 00       	mov    esi,0x1
  402e60:	44 89 f2             	mov    edx,r14d
  402e63:	e8 3f d7 ff ff       	call   0x4005a7
  402e68:	85 d2                	test   edx,edx
  402e6a:	0f 85 5e 04 00 00    	jne    0x4032ce
  402e70:	4c 89 e7             	mov    rdi,r12
  402e73:	4c 89 fe             	mov    rsi,r15
  402e76:	ba 04 00 00 00       	mov    edx,0x4
  402e7b:	e8 cf f4 ff ff       	call   0x40234f
  402e80:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  402e85:	48 89 c7             	mov    rdi,rax
  402e88:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402e8c:	44 89 f2             	mov    edx,r14d
  402e8f:	e8 32 f5 ff ff       	call   0x4023c6
  402e94:	85 c0                	test   eax,eax
  402e96:	0f 85 32 04 00 00    	jne    0x4032ce
  402e9c:	4c 89 e7             	mov    rdi,r12
  402e9f:	4c 89 fe             	mov    rsi,r15
  402ea2:	ba 05 00 00 00       	mov    edx,0x5
  402ea7:	e8 a3 f4 ff ff       	call   0x40234f
  402eac:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
  402eb1:	48 89 c7             	mov    rdi,rax
  402eb4:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  402eb8:	44 89 f2             	mov    edx,r14d
  402ebb:	e8 06 f5 ff ff       	call   0x4023c6
  402ec0:	85 c0                	test   eax,eax
  402ec2:	0f 85 06 04 00 00    	jne    0x4032ce
  402ec8:	4c 89 e7             	mov    rdi,r12
  402ecb:	4c 89 fe             	mov    rsi,r15
  402ece:	ba 06 00 00 00       	mov    edx,0x6
  402ed3:	e8 77 f4 ff ff       	call   0x40234f
  402ed8:	48 89 44 24 28       	mov    QWORD PTR [rsp+0x28],rax
  402edd:	48 89 c7             	mov    rdi,rax
  402ee0:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  402ee5:	44 89 f2             	mov    edx,r14d
  402ee8:	e8 d9 f4 ff ff       	call   0x4023c6
  402eed:	85 c0                	test   eax,eax
  402eef:	0f 85 d9 03 00 00    	jne    0x4032ce
  402ef5:	4c 89 e7             	mov    rdi,r12
  402ef8:	4c 89 fe             	mov    rsi,r15
  402efb:	ba 07 00 00 00       	mov    edx,0x7
  402f00:	e8 4a f4 ff ff       	call   0x40234f
  402f05:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
  402f0a:	48 89 c7             	mov    rdi,rax
  402f0d:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  402f12:	44 89 f2             	mov    edx,r14d
  402f15:	e8 ac f4 ff ff       	call   0x4023c6
  402f1a:	85 c0                	test   eax,eax
  402f1c:	0f 85 ac 03 00 00    	jne    0x4032ce
  402f22:	4c 89 e7             	mov    rdi,r12
  402f25:	4c 89 fe             	mov    rsi,r15
  402f28:	ba 08 00 00 00       	mov    edx,0x8
  402f2d:	e8 1d f4 ff ff       	call   0x40234f
  402f32:	48 89 44 24 38       	mov    QWORD PTR [rsp+0x38],rax
  402f37:	4c 89 e7             	mov    rdi,r12
  402f3a:	4c 89 fe             	mov    rsi,r15
  402f3d:	ba 09 00 00 00       	mov    edx,0x9
  402f42:	e8 08 f4 ff ff       	call   0x40234f
  402f47:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
  402f4c:	4c 89 e7             	mov    rdi,r12
  402f4f:	4c 89 fe             	mov    rsi,r15
  402f52:	ba 0a 00 00 00       	mov    edx,0xa
  402f57:	e8 f3 f3 ff ff       	call   0x40234f
  402f5c:	48 89 44 24 48       	mov    QWORD PTR [rsp+0x48],rax
  402f61:	4c 89 e7             	mov    rdi,r12
  402f64:	4c 89 fe             	mov    rsi,r15
  402f67:	ba 0b 00 00 00       	mov    edx,0xb
  402f6c:	e8 de f3 ff ff       	call   0x40234f
  402f71:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
  402f76:	4c 89 e7             	mov    rdi,r12
  402f79:	4c 89 fe             	mov    rsi,r15
  402f7c:	ba 0c 00 00 00       	mov    edx,0xc
  402f81:	e8 c9 f3 ff ff       	call   0x40234f
  402f86:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
  402f8b:	4c 89 e7             	mov    rdi,r12
  402f8e:	4c 89 fe             	mov    rsi,r15
  402f91:	ba 0d 00 00 00       	mov    edx,0xd
  402f96:	e8 b4 f3 ff ff       	call   0x40234f
  402f9b:	48 89 44 24 60       	mov    QWORD PTR [rsp+0x60],rax
  402fa0:	48 c7 44 24 70 01 00 	mov    QWORD PTR [rsp+0x70],0x1
  402fa7:	00 00 
  402fa9:	41 8b 6d 04          	mov    ebp,DWORD PTR [r13+0x4]
  402fad:	83 c5 10             	add    ebp,0x10
  402fb0:	85 ed                	test   ebp,ebp
  402fb2:	0f 84 06 02 00 00    	je     0x4031be
  402fb8:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  402fbd:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  402fc2:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  402fc7:	44 89 f1             	mov    ecx,r14d
  402fca:	e8 38 ec ff ff       	call   0x401c07
  402fcf:	85 c0                	test   eax,eax
  402fd1:	0f 85 f7 02 00 00    	jne    0x4032ce
  402fd7:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
  402fdc:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  402fe1:	e8 f0 f2 ff ff       	call   0x4022d6
  402fe6:	85 d2                	test   edx,edx
  402fe8:	0f 85 e0 02 00 00    	jne    0x4032ce
  402fee:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
  402ff3:	48 8d 34 00          	lea    rsi,[rax+rax*1]
  402ff7:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  402ffc:	44 89 f2             	mov    edx,r14d
  402fff:	e8 a3 d5 ff ff       	call   0x4005a7
  403004:	85 d2                	test   edx,edx
  403006:	0f 85 c2 02 00 00    	jne    0x4032ce
  40300c:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
  403011:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
  403016:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
  40301b:	44 89 f1             	mov    ecx,r14d
  40301e:	e8 af ec ff ff       	call   0x401cd2
  403023:	85 c0                	test   eax,eax
  403025:	0f 85 a3 02 00 00    	jne    0x4032ce
  40302b:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
  403030:	48 8d 74 00 01       	lea    rsi,[rax+rax*1+0x1]
  403035:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  40303a:	44 89 f2             	mov    edx,r14d
  40303d:	e8 65 d5 ff ff       	call   0x4005a7
  403042:	85 d2                	test   edx,edx
  403044:	0f 85 84 02 00 00    	jne    0x4032ce
  40304a:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
  40304f:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
  403054:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
  403059:	44 89 f1             	mov    ecx,r14d
  40305c:	e8 71 ec ff ff       	call   0x401cd2
  403061:	85 c0                	test   eax,eax
  403063:	0f 85 65 02 00 00    	jne    0x4032ce
  403069:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
  40306e:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  403073:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
  403078:	44 89 f1             	mov    ecx,r14d
  40307b:	e8 26 d9 ff ff       	call   0x4009a6
  403080:	85 c0                	test   eax,eax
  403082:	0f 85 46 02 00 00    	jne    0x4032ce
  403088:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  40308d:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
  403092:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  403097:	44 89 f1             	mov    ecx,r14d
  40309a:	e8 68 eb ff ff       	call   0x401c07
  40309f:	85 c0                	test   eax,eax
  4030a1:	0f 85 27 02 00 00    	jne    0x4032ce
  4030a7:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
  4030ac:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  4030b1:	e8 20 f2 ff ff       	call   0x4022d6
  4030b6:	85 d2                	test   edx,edx
  4030b8:	0f 85 10 02 00 00    	jne    0x4032ce
  4030be:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
  4030c3:	48 8d 74 00 ff       	lea    rsi,[rax+rax*1-0x1]
  4030c8:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  4030cd:	44 89 f2             	mov    edx,r14d
  4030d0:	e8 d2 d4 ff ff       	call   0x4005a7
  4030d5:	85 d2                	test   edx,edx
  4030d7:	0f 85 f1 01 00 00    	jne    0x4032ce
  4030dd:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
  4030e2:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
  4030e7:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
  4030ec:	44 89 f1             	mov    ecx,r14d
  4030ef:	e8 de eb ff ff       	call   0x401cd2
  4030f4:	85 c0                	test   eax,eax
  4030f6:	0f 85 d2 01 00 00    	jne    0x4032ce
  4030fc:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
  403101:	48 8d 34 00          	lea    rsi,[rax+rax*1]
  403105:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  40310a:	44 89 f2             	mov    edx,r14d
  40310d:	e8 95 d4 ff ff       	call   0x4005a7
  403112:	85 d2                	test   edx,edx
  403114:	0f 85 b4 01 00 00    	jne    0x4032ce
  40311a:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
  40311f:	48 8b 74 24 50       	mov    rsi,QWORD PTR [rsp+0x50]
  403124:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
  403129:	44 89 f1             	mov    ecx,r14d
  40312c:	e8 a1 eb ff ff       	call   0x401cd2
  403131:	85 c0                	test   eax,eax
  403133:	0f 85 95 01 00 00    	jne    0x4032ce
  403139:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
  40313e:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  403143:	48 8b 54 24 30       	mov    rdx,QWORD PTR [rsp+0x30]
  403148:	44 89 f1             	mov    ecx,r14d
  40314b:	e8 56 d8 ff ff       	call   0x4009a6
  403150:	85 c0                	test   eax,eax
  403152:	0f 85 76 01 00 00    	jne    0x4032ce
  403158:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
  40315d:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  403162:	e8 7c f0 ff ff       	call   0x4021e3
  403167:	89 c3                	mov    ebx,eax
  403169:	48 8b 7c 24 60       	mov    rdi,QWORD PTR [rsp+0x60]
  40316e:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  403173:	e8 6b f0 ff ff       	call   0x4021e3
  403178:	09 d8                	or     eax,ebx
  40317a:	85 c0                	test   eax,eax
  40317c:	74 40                	je     0x4031be
  40317e:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  403183:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
  403188:	44 89 f2             	mov    edx,r14d
  40318b:	e8 36 f2 ff ff       	call   0x4023c6
  403190:	85 c0                	test   eax,eax
  403192:	0f 85 36 01 00 00    	jne    0x4032ce
  403198:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
  40319d:	48 8b 74 24 60       	mov    rsi,QWORD PTR [rsp+0x60]
  4031a2:	44 89 f2             	mov    edx,r14d
  4031a5:	e8 1c f2 ff ff       	call   0x4023c6
  4031aa:	85 c0                	test   eax,eax
  4031ac:	0f 85 1c 01 00 00    	jne    0x4032ce
  4031b2:	48 ff 44 24 70       	inc    QWORD PTR [rsp+0x70]
  4031b7:	ff cd                	dec    ebp
  4031b9:	e9 f2 fd ff ff       	jmp    0x402fb0
  4031be:	48 8b 6c 24 68       	mov    rbp,QWORD PTR [rsp+0x68]
  4031c3:	48 85 ed             	test   rbp,rbp
  4031c6:	0f 84 cb 00 00 00    	je     0x403297
  4031cc:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  4031d1:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  4031d6:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
  4031db:	44 89 f1             	mov    ecx,r14d
  4031de:	e8 c3 d7 ff ff       	call   0x4009a6
  4031e3:	85 c0                	test   eax,eax
  4031e5:	0f 85 e3 00 00 00    	jne    0x4032ce
  4031eb:	48 8b 7c 24 40       	mov    rdi,QWORD PTR [rsp+0x40]
  4031f0:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  4031f5:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
  4031fa:	44 89 f1             	mov    ecx,r14d
  4031fd:	e8 05 ea ff ff       	call   0x401c07
  403202:	85 c0                	test   eax,eax
  403204:	0f 85 c4 00 00 00    	jne    0x4032ce
  40320a:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  40320f:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  403214:	48 8b 54 24 28       	mov    rdx,QWORD PTR [rsp+0x28]
  403219:	44 89 f1             	mov    ecx,r14d
  40321c:	e8 e6 e9 ff ff       	call   0x401c07
  403221:	85 c0                	test   eax,eax
  403223:	0f 85 a5 00 00 00    	jne    0x4032ce
  403229:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
  40322e:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  403233:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
  403238:	44 89 f1             	mov    ecx,r14d
  40323b:	e8 c7 e9 ff ff       	call   0x401c07
  403240:	85 c0                	test   eax,eax
  403242:	0f 85 86 00 00 00    	jne    0x4032ce
  403248:	48 8b 7c 24 58       	mov    rdi,QWORD PTR [rsp+0x58]
  40324d:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
  403252:	48 8b 54 24 50       	mov    rdx,QWORD PTR [rsp+0x50]
  403257:	44 89 f1             	mov    ecx,r14d
  40325a:	e8 4f d7 ff ff       	call   0x4009ae
  40325f:	85 c0                	test   eax,eax
  403261:	75 6b                	jne    0x4032ce
  403263:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  403268:	48 8b 74 24 40       	mov    rsi,QWORD PTR [rsp+0x40]
  40326d:	44 89 f2             	mov    edx,r14d
  403270:	e8 51 f1 ff ff       	call   0x4023c6
  403275:	85 c0                	test   eax,eax
  403277:	75 55                	jne    0x4032ce
  403279:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
  40327e:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
  403283:	44 89 f2             	mov    edx,r14d
  403286:	e8 3b f1 ff ff       	call   0x4023c6
  40328b:	85 c0                	test   eax,eax
  40328d:	75 3f                	jne    0x4032ce
  40328f:	48 ff cd             	dec    rbp
  403292:	e9 2c ff ff ff       	jmp    0x4031c3
  403297:	83 7c 24 78 00       	cmp    DWORD PTR [rsp+0x78],0x0
  40329c:	75 18                	jne    0x4032b6
  40329e:	4c 89 e7             	mov    rdi,r12
  4032a1:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  4032a6:	44 89 f2             	mov    edx,r14d
  4032a9:	e8 18 f1 ff ff       	call   0x4023c6
  4032ae:	85 c0                	test   eax,eax
  4032b0:	75 1c                	jne    0x4032ce
  4032b2:	31 c0                	xor    eax,eax
  4032b4:	eb 1d                	jmp    0x4032d3
  4032b6:	4c 89 e7             	mov    rdi,r12
  4032b9:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  4032be:	44 89 f2             	mov    edx,r14d
  4032c1:	e8 00 f1 ff ff       	call   0x4023c6
  4032c6:	85 c0                	test   eax,eax
  4032c8:	75 04                	jne    0x4032ce
  4032ca:	31 c0                	xor    eax,eax
  4032cc:	eb 05                	jmp    0x4032d3
  4032ce:	b8 01 00 00 00       	mov    eax,0x1
  4032d3:	48 81 c4 80 00 00 00 	add    rsp,0x80
  4032da:	41 5f                	pop    r15
  4032dc:	41 5e                	pop    r14
  4032de:	41 5d                	pop    r13
  4032e0:	41 5c                	pop    r12
  4032e2:	41 5b                	pop    r11
  4032e4:	5d                   	pop    rbp
  4032e5:	5b                   	pop    rbx
  4032e6:	c3                   	ret
  4032e7:	31 c9                	xor    ecx,ecx
  4032e9:	e9 93 fa ff ff       	jmp    0x402d81
  4032ee:	b9 01 00 00 00       	mov    ecx,0x1
  4032f3:	e9 89 fa ff ff       	jmp    0x402d81
  4032f8:	53                   	push   rbx
  4032f9:	55                   	push   rbp
  4032fa:	41 53                	push   r11
  4032fc:	41 54                	push   r12
  4032fe:	41 55                	push   r13
  403300:	41 56                	push   r14
  403302:	41 57                	push   r15
  403304:	48 83 ec 20          	sub    rsp,0x20
  403308:	49 89 fc             	mov    r12,rdi
  40330b:	41 8b 44 24 08       	mov    eax,DWORD PTR [r12+0x8]
  403310:	41 89 c5             	mov    r13d,eax
  403313:	49 8d 7c 24 20       	lea    rdi,[r12+0x20]
  403318:	44 89 e9             	mov    ecx,r13d
  40331b:	e8 fa cd ff ff       	call   0x40011a
  403320:	85 c0                	test   eax,eax
  403322:	0f 88 d9 00 00 00    	js     0x403401
  403328:	4d 8b 74 24 18       	mov    r14,QWORD PTR [r12+0x18]
  40332d:	49 81 fe ff 03 00 00 	cmp    r14,0x3ff
  403334:	0f 8f df 00 00 00    	jg     0x403419
  40333a:	49 81 fe 02 fc ff ff 	cmp    r14,0xfffffffffffffc02
  403341:	0f 8c c0 00 00 00    	jl     0x403407
  403347:	41 8b 54 24 04       	mov    edx,DWORD PTR [r12+0x4]
  40334c:	83 ea 35             	sub    edx,0x35
  40334f:	89 14 24             	mov    DWORD PTR [rsp],edx
  403352:	4d 31 ff             	xor    r15,r15
  403355:	31 db                	xor    ebx,ebx
  403357:	83 fb 35             	cmp    ebx,0x35
  40335a:	73 1e                	jae    0x40337a
  40335c:	8b 14 24             	mov    edx,DWORD PTR [rsp]
  40335f:	01 da                	add    edx,ebx
  403361:	49 8d 7c 24 20       	lea    rdi,[r12+0x20]
  403366:	44 89 e9             	mov    ecx,r13d
  403369:	e8 e6 ce ff ff       	call   0x400254
  40336e:	85 c0                	test   eax,eax
  403370:	74 04                	je     0x403376
  403372:	49 0f ab df          	bts    r15,rbx
  403376:	ff c3                	inc    ebx
  403378:	eb dd                	jmp    0x403357
  40337a:	8b 14 24             	mov    edx,DWORD PTR [rsp]
  40337d:	85 d2                	test   edx,edx
  40337f:	7e 4f                	jle    0x4033d0
  403381:	ff ca                	dec    edx
  403383:	49 8d 7c 24 20       	lea    rdi,[r12+0x20]
  403388:	44 89 e9             	mov    ecx,r13d
  40338b:	e8 c4 ce ff ff       	call   0x400254
  403390:	89 c3                	mov    ebx,eax
  403392:	8b 14 24             	mov    edx,DWORD PTR [rsp]
  403395:	ff ca                	dec    edx
  403397:	49 8d 7c 24 20       	lea    rdi,[r12+0x20]
  40339c:	44 89 e9             	mov    ecx,r13d
  40339f:	e8 d5 ce ff ff       	call   0x400279
  4033a4:	89 c5                	mov    ebp,eax
  4033a6:	85 db                	test   ebx,ebx
  4033a8:	74 26                	je     0x4033d0
  4033aa:	85 ed                	test   ebp,ebp
  4033ac:	75 09                	jne    0x4033b7
  4033ae:	49 f7 c7 01 00 00 00 	test   r15,0x1
  4033b5:	74 19                	je     0x4033d0
  4033b7:	49 ff c7             	inc    r15
  4033ba:	49 0f ba e7 35       	bt     r15,0x35
  4033bf:	73 0f                	jae    0x4033d0
  4033c1:	49 d1 ef             	shr    r15,1
  4033c4:	49 ff c6             	inc    r14
  4033c7:	49 81 fe ff 03 00 00 	cmp    r14,0x3ff
  4033ce:	7f 49                	jg     0x403419
  4033d0:	4c 89 f8             	mov    rax,r15
  4033d3:	48 b9 ff ff ff ff ff 	movabs rcx,0x7ffffffffffff
  4033da:	ff 07 00 
  4033dd:	48 21 c8             	and    rax,rcx
  4033e0:	4c 89 f1             	mov    rcx,r14
  4033e3:	48 81 c1 ff 03 00 00 	add    rcx,0x3ff
  4033ea:	48 c1 e1 34          	shl    rcx,0x34
  4033ee:	48 09 c8             	or     rax,rcx
  4033f1:	49 8b 4c 24 10       	mov    rcx,QWORD PTR [r12+0x10]
  4033f6:	48 c1 e1 3f          	shl    rcx,0x3f
  4033fa:	48 09 c8             	or     rax,rcx
  4033fd:	31 d2                	xor    edx,edx
  4033ff:	eb 30                	jmp    0x403431
  403401:	31 c0                	xor    eax,eax
  403403:	31 d2                	xor    edx,edx
  403405:	eb 2a                	jmp    0x403431
  403407:	31 c0                	xor    eax,eax
  403409:	49 8b 4c 24 10       	mov    rcx,QWORD PTR [r12+0x10]
  40340e:	48 c1 e1 3f          	shl    rcx,0x3f
  403412:	48 09 c8             	or     rax,rcx
  403415:	31 d2                	xor    edx,edx
  403417:	eb 18                	jmp    0x403431
  403419:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
  403420:	00 f0 7f 
  403423:	49 8b 4c 24 10       	mov    rcx,QWORD PTR [r12+0x10]
  403428:	48 c1 e1 3f          	shl    rcx,0x3f
  40342c:	48 09 c8             	or     rax,rcx
  40342f:	31 d2                	xor    edx,edx
  403431:	48 83 c4 20          	add    rsp,0x20
  403435:	41 5f                	pop    r15
  403437:	41 5e                	pop    r14
  403439:	41 5d                	pop    r13
  40343b:	41 5c                	pop    r12
  40343d:	41 5b                	pop    r11
  40343f:	5d                   	pop    rbp
  403440:	5b                   	pop    rbx
  403441:	c3                   	ret
  403442:	49 89 e7             	mov    r15,rsp
  403445:	48 8b 35 bc 0b 00 00 	mov    rsi,QWORD PTR [rip+0xbbc]        # 0x404008
  40344c:	48 85 f6             	test   rsi,rsi
  40344f:	74 39                	je     0x40348a
  403451:	b8 09 00 00 00       	mov    eax,0x9
  403456:	48 bf 00 00 00 00 00 	movabs rdi,0x10000000000
  40345d:	01 00 00 
  403460:	ba 03 00 00 00       	mov    edx,0x3
  403465:	41 ba 22 00 10 00    	mov    r10d,0x100022
  40346b:	49 c7 c0 ff ff ff ff 	mov    r8,0xffffffffffffffff
  403472:	45 31 c9             	xor    r9d,r9d
  403475:	0f 05                	syscall
  403477:	48 ba 00 00 00 00 00 	movabs rdx,0x10000000000
  40347e:	01 00 00 
  403481:	48 39 d0             	cmp    rax,rdx
  403484:	0f 85 f7 02 00 00    	jne    0x403781
  40348a:	48 8d 05 2f 03 00 00 	lea    rax,[rip+0x32f]        # 0x4037c0
  403491:	48 89 05 90 0b 00 00 	mov    QWORD PTR [rip+0xb90],rax        # 0x404028
  403498:	48 c7 05 8d 0b 00 00 	mov    QWORD PTR [rip+0xb8d],0x0        # 0x404030
  40349f:	00 00 00 00 
  4034a3:	48 c7 05 8a 0b 00 00 	mov    QWORD PTR [rip+0xb8a],0x0        # 0x404038
  4034aa:	00 00 00 00 
  4034ae:	48 8b 35 63 0b 00 00 	mov    rsi,QWORD PTR [rip+0xb63]        # 0x404018
  4034b5:	48 85 f6             	test   rsi,rsi
  4034b8:	0f 84 94 00 00 00    	je     0x403552
  4034be:	b8 01 01 00 00       	mov    eax,0x101
  4034c3:	bf 9c ff ff ff       	mov    edi,0xffffff9c
  4034c8:	48 8d 35 09 0d 00 00 	lea    rsi,[rip+0xd09]        # 0x4041d8
  4034cf:	31 d2                	xor    edx,edx
  4034d1:	45 31 d2             	xor    r10d,r10d
  4034d4:	0f 05                	syscall
  4034d6:	48 85 c0             	test   rax,rax
  4034d9:	0f 88 a2 02 00 00    	js     0x403781
  4034df:	49 89 c4             	mov    r12,rax
  4034e2:	31 ff                	xor    edi,edi
  4034e4:	48 8b 35 2d 0b 00 00 	mov    rsi,QWORD PTR [rip+0xb2d]        # 0x404018
  4034eb:	ba 05 00 00 00       	mov    edx,0x5
  4034f0:	41 ba 02 00 00 00    	mov    r10d,0x2
  4034f6:	4d 89 e0             	mov    r8,r12
  4034f9:	4c 8b 0d 10 0b 00 00 	mov    r9,QWORD PTR [rip+0xb10]        # 0x404010
  403500:	b8 09 00 00 00       	mov    eax,0x9
  403505:	0f 05                	syscall
  403507:	48 85 c0             	test   rax,rax
  40350a:	78 37                	js     0x403543
  40350c:	48 89 05 1d 0b 00 00 	mov    QWORD PTR [rip+0xb1d],rax        # 0x404030
  403513:	8b 0d e7 0a 00 00    	mov    ecx,DWORD PTR [rip+0xae7]        # 0x404000
  403519:	48 8d 14 88          	lea    rdx,[rax+rcx*4]
  40351d:	48 89 15 14 0b 00 00 	mov    QWORD PTR [rip+0xb14],rdx        # 0x404038
  403524:	48 8b 0d f5 0a 00 00 	mov    rcx,QWORD PTR [rip+0xaf5]        # 0x404020
  40352b:	48 01 c8             	add    rax,rcx
  40352e:	72 13                	jb     0x403543
  403530:	48 89 05 f1 0a 00 00 	mov    QWORD PTR [rip+0xaf1],rax        # 0x404028
  403537:	b8 03 00 00 00       	mov    eax,0x3
  40353c:	4c 89 e7             	mov    rdi,r12
  40353f:	0f 05                	syscall
  403541:	eb 0f                	jmp    0x403552
  403543:	b8 03 00 00 00       	mov    eax,0x3
  403548:	4c 89 e7             	mov    rdi,r12
  40354b:	0f 05                	syscall
  40354d:	e9 2f 02 00 00       	jmp    0x403781
  403552:	49 8b 07             	mov    rax,QWORD PTR [r15]
  403555:	8b 0d a5 0a 00 00    	mov    ecx,DWORD PTR [rip+0xaa5]        # 0x404000
  40355b:	48 8d 51 01          	lea    rdx,[rcx+0x1]
  40355f:	48 39 d0             	cmp    rax,rdx
  403562:	0f 85 25 02 00 00    	jne    0x40378d
  403568:	4d 8d 67 10          	lea    r12,[r15+0x10]
  40356c:	4c 8b 2d cd 0a 00 00 	mov    r13,QWORD PTR [rip+0xacd]        # 0x404040
  403573:	4c 8b 35 b6 0a 00 00 	mov    r14,QWORD PTR [rip+0xab6]        # 0x404030
  40357a:	48 8b 05 cf 0a 00 00 	mov    rax,QWORD PTR [rip+0xacf]        # 0x404050
  403581:	48 89 05 d8 0a 00 00 	mov    QWORD PTR [rip+0xad8],rax        # 0x404060
  403588:	31 db                	xor    ebx,ebx
  40358a:	3b 1d 70 0a 00 00    	cmp    ebx,DWORD PTR [rip+0xa70]        # 0x404000
  403590:	0f 83 e7 00 00 00    	jae    0x40367d
  403596:	49 8b 3c dc          	mov    rdi,QWORD PTR [r12+rbx*8]
  40359a:	41 8b 04 9e          	mov    eax,DWORD PTR [r14+rbx*4]
  40359e:	83 f8 01             	cmp    eax,0x1
  4035a1:	74 32                	je     0x4035d5
  4035a3:	83 f8 02             	cmp    eax,0x2
  4035a6:	74 44                	je     0x4035ec
  4035a8:	83 f8 03             	cmp    eax,0x3
  4035ab:	74 53                	je     0x403600
  4035ad:	83 f8 04             	cmp    eax,0x4
  4035b0:	74 62                	je     0x403614
  4035b2:	83 f8 05             	cmp    eax,0x5
  4035b5:	74 7e                	je     0x403635
  4035b7:	83 f8 06             	cmp    eax,0x6
  4035ba:	0f 84 a1 00 00 00    	je     0x403661
  4035c0:	89 c2                	mov    edx,eax
  4035c2:	81 e2 00 00 00 40    	and    edx,0x40000000
  4035c8:	81 fa 00 00 00 40    	cmp    edx,0x40000000
  4035ce:	74 79                	je     0x403649
  4035d0:	e9 b8 01 00 00       	jmp    0x40378d
  4035d5:	e8 e9 01 00 00       	call   0x4037c3
  4035da:	85 d2                	test   edx,edx
  4035dc:	0f 85 ab 01 00 00    	jne    0x40378d
  4035e2:	49 89 44 dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rax
  4035e7:	e9 8a 00 00 00       	jmp    0x403676
  4035ec:	e8 79 02 00 00       	call   0x40386a
  4035f1:	85 d2                	test   edx,edx
  4035f3:	0f 85 94 01 00 00    	jne    0x40378d
  4035f9:	49 89 44 dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rax
  4035fe:	eb 76                	jmp    0x403676
  403600:	e8 18 02 00 00       	call   0x40381d
  403605:	85 d2                	test   edx,edx
  403607:	0f 85 80 01 00 00    	jne    0x40378d
  40360d:	49 89 44 dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rax
  403612:	eb 62                	jmp    0x403676
  403614:	e8 a3 02 00 00       	call   0x4038bc
  403619:	85 d2                	test   edx,edx
  40361b:	0f 85 6c 01 00 00    	jne    0x40378d
  403621:	66 48 0f 6e c0       	movq   xmm0,rax
  403626:	f2 0f 5a c0          	cvtsd2ss xmm0,xmm0
  40362a:	66 0f 7e c0          	movd   eax,xmm0
  40362e:	49 89 44 dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rax
  403633:	eb 41                	jmp    0x403676
  403635:	e8 82 02 00 00       	call   0x4038bc
  40363a:	85 d2                	test   edx,edx
  40363c:	0f 85 4b 01 00 00    	jne    0x40378d
  403642:	49 89 44 dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rax
  403647:	eb 2d                	jmp    0x403676
  403649:	41 8b 14 9e          	mov    edx,DWORD PTR [r14+rbx*4]
  40364d:	e8 a7 03 00 00       	call   0x4039f9
  403652:	85 d2                	test   edx,edx
  403654:	0f 85 33 01 00 00    	jne    0x40378d
  40365a:	49 89 44 dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rax
  40365f:	eb 15                	jmp    0x403676
  403661:	49 89 7c dd 00       	mov    QWORD PTR [r13+rbx*8+0x0],rdi
  403666:	e8 0a 03 00 00       	call   0x403975
  40366b:	4c 8b 15 d6 09 00 00 	mov    r10,QWORD PTR [rip+0x9d6]        # 0x404048
  403672:	49 89 04 da          	mov    QWORD PTR [r10+rbx*8],rax
  403676:	ff c3                	inc    ebx
  403678:	e9 0d ff ff ff       	jmp    0x40358a
  40367d:	48 8b 05 a4 09 00 00 	mov    rax,QWORD PTR [rip+0x9a4]        # 0x404028
  403684:	ff d0                	call   rax
  403686:	85 c0                	test   eax,eax
  403688:	0f 85 e7 00 00 00    	jne    0x403775
  40368e:	31 db                	xor    ebx,ebx
  403690:	3b 1d 6e 09 00 00    	cmp    ebx,DWORD PTR [rip+0x96e]        # 0x404004
  403696:	0f 83 d0 00 00 00    	jae    0x40376c
  40369c:	4c 8b 15 95 09 00 00 	mov    r10,QWORD PTR [rip+0x995]        # 0x404038
  4036a3:	41 8b 04 9a          	mov    eax,DWORD PTR [r10+rbx*4]
  4036a7:	83 f8 06             	cmp    eax,0x6
  4036aa:	74 58                	je     0x403704
  4036ac:	89 c2                	mov    edx,eax
  4036ae:	81 e2 00 00 00 40    	and    edx,0x40000000
  4036b4:	81 fa 00 00 00 40    	cmp    edx,0x40000000
  4036ba:	74 23                	je     0x4036df
  4036bc:	48 89 d8             	mov    rax,rbx
  4036bf:	e8 bf 02 00 00       	call   0x403983
  4036c4:	4c 8b 15 9d 09 00 00 	mov    r10,QWORD PTR [rip+0x99d]        # 0x404068
  4036cb:	48 89 d8             	mov    rax,rbx
  4036ce:	48 c1 e0 0c          	shl    rax,0xc
  4036d2:	49 8b 04 02          	mov    rax,QWORD PTR [r10+rax*1]
  4036d6:	e8 d0 02 00 00       	call   0x4039ab
  4036db:	ff c3                	inc    ebx
  4036dd:	eb b1                	jmp    0x403690
  4036df:	48 89 d8             	mov    rax,rbx
  4036e2:	e8 9c 02 00 00       	call   0x403983
  4036e7:	4c 8b 15 7a 09 00 00 	mov    r10,QWORD PTR [rip+0x97a]        # 0x404068
  4036ee:	48 89 d8             	mov    rax,rbx
  4036f1:	48 c1 e0 0c          	shl    rax,0xc
  4036f5:	49 8b 3c 02          	mov    rdi,QWORD PTR [r10+rax*1]
  4036f9:	89 de                	mov    esi,ebx
  4036fb:	e8 dd 05 00 00       	call   0x403cdd
  403700:	ff c3                	inc    ebx
  403702:	eb 8c                	jmp    0x403690
  403704:	48 89 d8             	mov    rax,rbx
  403707:	e8 77 02 00 00       	call   0x403983
  40370c:	b8 01 00 00 00       	mov    eax,0x1
  403711:	bf 01 00 00 00       	mov    edi,0x1
  403716:	48 8d 35 79 09 00 00 	lea    rsi,[rip+0x979]        # 0x404096
  40371d:	ba 0d 00 00 00       	mov    edx,0xd
  403722:	0f 05                	syscall
  403724:	b8 01 00 00 00       	mov    eax,0x1
  403729:	bf 01 00 00 00       	mov    edi,0x1
  40372e:	4c 8b 15 33 09 00 00 	mov    r10,QWORD PTR [rip+0x933]        # 0x404068
  403735:	48 89 d8             	mov    rax,rbx
  403738:	48 c1 e0 0c          	shl    rax,0xc
  40373c:	49 8b 34 02          	mov    rsi,QWORD PTR [r10+rax*1]
  403740:	4c 8b 15 29 09 00 00 	mov    r10,QWORD PTR [rip+0x929]        # 0x404070
  403747:	49 8b 14 da          	mov    rdx,QWORD PTR [r10+rbx*8]
  40374b:	0f 05                	syscall
  40374d:	b8 01 00 00 00       	mov    eax,0x1
  403752:	bf 01 00 00 00       	mov    edi,0x1
  403757:	48 8d 35 45 09 00 00 	lea    rsi,[rip+0x945]        # 0x4040a3
  40375e:	ba 01 00 00 00       	mov    edx,0x1
  403763:	0f 05                	syscall
  403765:	ff c3                	inc    ebx
  403767:	e9 24 ff ff ff       	jmp    0x403690
  40376c:	31 ff                	xor    edi,edi
  40376e:	b8 e7 00 00 00       	mov    eax,0xe7
  403773:	0f 05                	syscall
  403775:	bf 41 00 00 00       	mov    edi,0x41
  40377a:	b8 e7 00 00 00       	mov    eax,0xe7
  40377f:	0f 05                	syscall
  403781:	bf 41 00 00 00       	mov    edi,0x41
  403786:	b8 e7 00 00 00       	mov    eax,0xe7
  40378b:	0f 05                	syscall
  40378d:	bf 02 00 00 00       	mov    edi,0x2
  403792:	b8 e7 00 00 00       	mov    eax,0xe7
  403797:	0f 05                	syscall
  403799:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  4037a0:	00 00 00 00 
  4037a4:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  4037ab:	00 00 00 00 
  4037af:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  4037b6:	00 00 00 00 
  4037ba:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  4037c0:	31 c0                	xor    eax,eax
  4037c2:	c3                   	ret
  4037c3:	80 3f 30             	cmp    BYTE PTR [rdi],0x30
  4037c6:	75 0b                	jne    0x4037d3
  4037c8:	80 7f 01 00          	cmp    BYTE PTR [rdi+0x1],0x0
  4037cc:	75 47                	jne    0x403815
  4037ce:	31 c0                	xor    eax,eax
  4037d0:	31 d2                	xor    edx,edx
  4037d2:	c3                   	ret
  4037d3:	80 3f 31             	cmp    BYTE PTR [rdi],0x31
  4037d6:	75 0e                	jne    0x4037e6
  4037d8:	80 7f 01 00          	cmp    BYTE PTR [rdi+0x1],0x0
  4037dc:	75 37                	jne    0x403815
  4037de:	b8 01 00 00 00       	mov    eax,0x1
  4037e3:	31 d2                	xor    edx,edx
  4037e5:	c3                   	ret
  4037e6:	81 3f 74 72 75 65    	cmp    DWORD PTR [rdi],0x65757274
  4037ec:	75 0e                	jne    0x4037fc
  4037ee:	80 7f 04 00          	cmp    BYTE PTR [rdi+0x4],0x0
  4037f2:	75 21                	jne    0x403815
  4037f4:	b8 01 00 00 00       	mov    eax,0x1
  4037f9:	31 d2                	xor    edx,edx
  4037fb:	c3                   	ret
  4037fc:	81 3f 66 61 6c 73    	cmp    DWORD PTR [rdi],0x736c6166
  403802:	75 11                	jne    0x403815
  403804:	80 7f 04 65          	cmp    BYTE PTR [rdi+0x4],0x65
  403808:	75 0b                	jne    0x403815
  40380a:	80 7f 05 00          	cmp    BYTE PTR [rdi+0x5],0x0
  40380e:	75 05                	jne    0x403815
  403810:	31 c0                	xor    eax,eax
  403812:	31 d2                	xor    edx,edx
  403814:	c3                   	ret
  403815:	31 c0                	xor    eax,eax
  403817:	ba 01 00 00 00       	mov    edx,0x1
  40381c:	c3                   	ret
  40381d:	31 c0                	xor    eax,eax
  40381f:	31 d2                	xor    edx,edx
  403821:	31 c9                	xor    ecx,ecx
  403823:	44 0f b6 07          	movzx  r8d,BYTE PTR [rdi]
  403827:	45 84 c0             	test   r8b,r8b
  40382a:	74 2f                	je     0x40385b
  40382c:	41 80 f8 30          	cmp    r8b,0x30
  403830:	72 30                	jb     0x403862
  403832:	41 80 f8 39          	cmp    r8b,0x39
  403836:	77 2a                	ja     0x403862
  403838:	49 b9 99 99 99 99 99 	movabs r9,0x1999999999999999
  40383f:	99 99 19 
  403842:	4c 39 c8             	cmp    rax,r9
  403845:	77 1b                	ja     0x403862
  403847:	48 6b c0 0a          	imul   rax,rax,0xa
  40384b:	41 83 e8 30          	sub    r8d,0x30
  40384f:	4c 01 c0             	add    rax,r8
  403852:	72 0e                	jb     0x403862
  403854:	48 ff c7             	inc    rdi
  403857:	ff c1                	inc    ecx
  403859:	eb c8                	jmp    0x403823
  40385b:	85 c9                	test   ecx,ecx
  40385d:	74 03                	je     0x403862
  40385f:	31 d2                	xor    edx,edx
  403861:	c3                   	ret
  403862:	31 c0                	xor    eax,eax
  403864:	ba 01 00 00 00       	mov    edx,0x1
  403869:	c3                   	ret
  40386a:	45 31 c0             	xor    r8d,r8d
  40386d:	80 3f 2d             	cmp    BYTE PTR [rdi],0x2d
  403870:	75 09                	jne    0x40387b
  403872:	41 b8 01 00 00 00    	mov    r8d,0x1
  403878:	48 ff c7             	inc    rdi
  40387b:	41 50                	push   r8
  40387d:	e8 9b ff ff ff       	call   0x40381d
  403882:	41 58                	pop    r8
  403884:	85 d2                	test   edx,edx
  403886:	75 2c                	jne    0x4038b4
  403888:	45 85 c0             	test   r8d,r8d
  40388b:	74 15                	je     0x4038a2
  40388d:	48 b9 00 00 00 00 00 	movabs rcx,0x8000000000000000
  403894:	00 00 80 
  403897:	48 39 c8             	cmp    rax,rcx
  40389a:	77 18                	ja     0x4038b4
  40389c:	48 f7 d8             	neg    rax
  40389f:	31 d2                	xor    edx,edx
  4038a1:	c3                   	ret
  4038a2:	48 b9 ff ff ff ff ff 	movabs rcx,0x7fffffffffffffff
  4038a9:	ff ff 7f 
  4038ac:	48 39 c8             	cmp    rax,rcx
  4038af:	77 03                	ja     0x4038b4
  4038b1:	31 d2                	xor    edx,edx
  4038b3:	c3                   	ret
  4038b4:	31 c0                	xor    eax,eax
  4038b6:	ba 01 00 00 00       	mov    edx,0x1
  4038bb:	c3                   	ret
  4038bc:	53                   	push   rbx
  4038bd:	41 54                	push   r12
  4038bf:	45 31 e4             	xor    r12d,r12d
  4038c2:	80 3f 2d             	cmp    BYTE PTR [rdi],0x2d
  4038c5:	75 0b                	jne    0x4038d2
  4038c7:	41 bc 01 00 00 00    	mov    r12d,0x1
  4038cd:	48 ff c7             	inc    rdi
  4038d0:	eb 08                	jmp    0x4038da
  4038d2:	80 3f 2b             	cmp    BYTE PTR [rdi],0x2b
  4038d5:	75 03                	jne    0x4038da
  4038d7:	48 ff c7             	inc    rdi
  4038da:	48 31 c0             	xor    rax,rax
  4038dd:	48 c7 c3 01 00 00 00 	mov    rbx,0x1
  4038e4:	45 31 c0             	xor    r8d,r8d
  4038e7:	45 31 c9             	xor    r9d,r9d
  4038ea:	0f b6 0f             	movzx  ecx,BYTE PTR [rdi]
  4038ed:	84 c9                	test   cl,cl
  4038ef:	74 3d                	je     0x40392e
  4038f1:	80 f9 2e             	cmp    cl,0x2e
  4038f4:	75 10                	jne    0x403906
  4038f6:	45 85 c9             	test   r9d,r9d
  4038f9:	75 6f                	jne    0x40396a
  4038fb:	41 b9 01 00 00 00    	mov    r9d,0x1
  403901:	48 ff c7             	inc    rdi
  403904:	eb e4                	jmp    0x4038ea
  403906:	80 f9 30             	cmp    cl,0x30
  403909:	72 5f                	jb     0x40396a
  40390b:	80 f9 39             	cmp    cl,0x39
  40390e:	77 5a                	ja     0x40396a
  403910:	48 6b c0 0a          	imul   rax,rax,0xa
  403914:	83 e9 30             	sub    ecx,0x30
  403917:	48 01 c8             	add    rax,rcx
  40391a:	45 85 c9             	test   r9d,r9d
  40391d:	74 04                	je     0x403923
  40391f:	48 6b db 0a          	imul   rbx,rbx,0xa
  403923:	41 b8 01 00 00 00    	mov    r8d,0x1
  403929:	48 ff c7             	inc    rdi
  40392c:	eb bc                	jmp    0x4038ea
  40392e:	45 85 c0             	test   r8d,r8d
  403931:	74 37                	je     0x40396a
  403933:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
  403938:	48 83 fb 01          	cmp    rbx,0x1
  40393c:	74 09                	je     0x403947
  40393e:	f2 48 0f 2a cb       	cvtsi2sd xmm1,rbx
  403943:	f2 0f 5e c1          	divsd  xmm0,xmm1
  403947:	45 85 e4             	test   r12d,r12d
  40394a:	74 13                	je     0x40395f
  40394c:	48 b8 00 00 00 00 00 	movabs rax,0x8000000000000000
  403953:	00 00 80 
  403956:	66 48 0f 6e c8       	movq   xmm1,rax
  40395b:	66 0f 57 c1          	xorpd  xmm0,xmm1
  40395f:	66 48 0f 7e c0       	movq   rax,xmm0
  403964:	31 d2                	xor    edx,edx
  403966:	41 5c                	pop    r12
  403968:	5b                   	pop    rbx
  403969:	c3                   	ret
  40396a:	31 c0                	xor    eax,eax
  40396c:	ba 01 00 00 00       	mov    edx,0x1
  403971:	41 5c                	pop    r12
  403973:	5b                   	pop    rbx
  403974:	c3                   	ret
  403975:	31 c0                	xor    eax,eax
  403977:	80 3c 07 00          	cmp    BYTE PTR [rdi+rax*1],0x0
  40397b:	74 05                	je     0x403982
  40397d:	48 ff c0             	inc    rax
  403980:	eb f5                	jmp    0x403977
  403982:	c3                   	ret
  403983:	31 d2                	xor    edx,edx
  403985:	b9 0a 00 00 00       	mov    ecx,0xa
  40398a:	48 f7 f1             	div    rcx
  40398d:	04 30                	add    al,0x30
  40398f:	80 c2 30             	add    dl,0x30
  403992:	88 05 e3 06 00 00    	mov    BYTE PTR [rip+0x6e3],al        # 0x40407b
  403998:	88 15 de 06 00 00    	mov    BYTE PTR [rip+0x6de],dl        # 0x40407c
  40399e:	88 05 f5 06 00 00    	mov    BYTE PTR [rip+0x6f5],al        # 0x404099
  4039a4:	88 15 f0 06 00 00    	mov    BYTE PTR [rip+0x6f0],dl        # 0x40409a
  4039aa:	c3                   	ret
  4039ab:	53                   	push   rbx
  4039ac:	48 89 c3             	mov    rbx,rax
  4039af:	48 8d 3d cf 06 00 00 	lea    rdi,[rip+0x6cf]        # 0x404085
  4039b6:	b9 10 00 00 00       	mov    ecx,0x10
  4039bb:	48 89 da             	mov    rdx,rbx
  4039be:	48 c1 ea 3c          	shr    rdx,0x3c
  4039c2:	83 e2 0f             	and    edx,0xf
  4039c5:	83 fa 09             	cmp    edx,0x9
  4039c8:	76 05                	jbe    0x4039cf
  4039ca:	83 c2 57             	add    edx,0x57
  4039cd:	eb 03                	jmp    0x4039d2
  4039cf:	83 c2 30             	add    edx,0x30
  4039d2:	88 17                	mov    BYTE PTR [rdi],dl
  4039d4:	48 ff c7             	inc    rdi
  4039d7:	48 c1 e3 04          	shl    rbx,0x4
  4039db:	ff c9                	dec    ecx
  4039dd:	75 dc                	jne    0x4039bb
  4039df:	b8 01 00 00 00       	mov    eax,0x1
  4039e4:	bf 01 00 00 00       	mov    edi,0x1
  4039e9:	48 8d 35 88 06 00 00 	lea    rsi,[rip+0x688]        # 0x404078
  4039f0:	ba 1e 00 00 00       	mov    edx,0x1e
  4039f5:	0f 05                	syscall
  4039f7:	5b                   	pop    rbx
  4039f8:	c3                   	ret
  4039f9:	53                   	push   rbx
  4039fa:	55                   	push   rbp
  4039fb:	41 54                	push   r12
  4039fd:	41 55                	push   r13
  4039ff:	41 56                	push   r14
  403a01:	41 57                	push   r15
  403a03:	48 83 ec 40          	sub    rsp,0x40
  403a07:	49 89 fc             	mov    r12,rdi
  403a0a:	41 89 d5             	mov    r13d,edx
  403a0d:	44 89 ef             	mov    edi,r13d
  403a10:	e8 ab c6 ff ff       	call   0x4000c0
  403a15:	85 c0                	test   eax,eax
  403a17:	0f 84 77 02 00 00    	je     0x403c94
  403a1d:	89 c5                	mov    ebp,eax
  403a1f:	67 8d 40 3f          	lea    eax,[eax+0x3f]
  403a23:	c1 e8 06             	shr    eax,0x6
  403a26:	48 69 d0 00 02 00 00 	imul   rdx,rax,0x200
  403a2d:	0f 80 61 02 00 00    	jo     0x403c94
  403a33:	48 81 c2 00 10 00 00 	add    rdx,0x1000
  403a3a:	0f 82 54 02 00 00    	jb     0x403c94
  403a40:	48 83 c2 3f          	add    rdx,0x3f
  403a44:	0f 82 4a 02 00 00    	jb     0x403c94
  403a4a:	48 83 e2 c0          	and    rdx,0xffffffffffffffc0
  403a4e:	48 89 54 24 30       	mov    QWORD PTR [rsp+0x30],rdx
  403a53:	4c 8b 3d 06 06 00 00 	mov    r15,QWORD PTR [rip+0x606]        # 0x404060
  403a5a:	48 89 d0             	mov    rax,rdx
  403a5d:	48 6b c0 06          	imul   rax,rax,0x6
  403a61:	0f 80 2d 02 00 00    	jo     0x403c94
  403a67:	4c 89 f9             	mov    rcx,r15
  403a6a:	48 01 c1             	add    rcx,rax
  403a6d:	0f 82 21 02 00 00    	jb     0x403c94
  403a73:	48 3b 0d de 05 00 00 	cmp    rcx,QWORD PTR [rip+0x5de]        # 0x404058
  403a7a:	0f 87 14 02 00 00    	ja     0x403c94
  403a80:	48 89 0d d9 05 00 00 	mov    QWORD PTR [rip+0x5d9],rcx        # 0x404060
  403a87:	4c 89 3c 24          	mov    QWORD PTR [rsp],r15
  403a8b:	4c 89 f8             	mov    rax,r15
  403a8e:	48 01 d0             	add    rax,rdx
  403a91:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  403a96:	48 01 d0             	add    rax,rdx
  403a99:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  403a9e:	48 01 d0             	add    rax,rdx
  403aa1:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  403aa6:	48 01 d0             	add    rax,rdx
  403aa9:	48 89 c3             	mov    rbx,rax
  403aac:	48 01 d0             	add    rax,rdx
  403aaf:	49 89 c7             	mov    r15,rax
  403ab2:	45 31 f6             	xor    r14d,r14d
  403ab5:	41 80 3c 24 2d       	cmp    BYTE PTR [r12],0x2d
  403aba:	75 0b                	jne    0x403ac7
  403abc:	41 be 01 00 00 00    	mov    r14d,0x1
  403ac2:	49 ff c4             	inc    r12
  403ac5:	eb 0a                	jmp    0x403ad1
  403ac7:	41 80 3c 24 2b       	cmp    BYTE PTR [r12],0x2b
  403acc:	75 03                	jne    0x403ad1
  403ace:	49 ff c4             	inc    r12
  403ad1:	89 e8                	mov    eax,ebp
  403ad3:	48 69 c0 97 75 00 00 	imul   rax,rax,0x7597
  403ada:	31 d2                	xor    edx,edx
  403adc:	b9 a0 86 01 00       	mov    ecx,0x186a0
  403ae1:	48 f7 f1             	div    rcx
  403ae4:	89 44 24 20          	mov    DWORD PTR [rsp+0x20],eax
  403ae8:	41 80 3c 24 30       	cmp    BYTE PTR [r12],0x30
  403aed:	75 0c                	jne    0x403afb
  403aef:	41 80 7c 24 01 2e    	cmp    BYTE PTR [r12+0x1],0x2e
  403af5:	75 04                	jne    0x403afb
  403af7:	ff 44 24 20          	inc    DWORD PTR [rsp+0x20]
  403afb:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  403aff:	31 f6                	xor    esi,esi
  403b01:	44 89 ea             	mov    edx,r13d
  403b04:	e8 9e ca ff ff       	call   0x4005a7
  403b09:	85 d2                	test   edx,edx
  403b0b:	0f 85 83 01 00 00    	jne    0x403c94
  403b11:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  403b16:	be 0a 00 00 00       	mov    esi,0xa
  403b1b:	44 89 ea             	mov    edx,r13d
  403b1e:	e8 84 ca ff ff       	call   0x4005a7
  403b23:	85 d2                	test   edx,edx
  403b25:	0f 85 69 01 00 00    	jne    0x403c94
  403b2b:	48 89 df             	mov    rdi,rbx
  403b2e:	be 01 00 00 00       	mov    esi,0x1
  403b33:	44 89 ea             	mov    edx,r13d
  403b36:	e8 6c ca ff ff       	call   0x4005a7
  403b3b:	85 d2                	test   edx,edx
  403b3d:	0f 85 51 01 00 00    	jne    0x403c94
  403b43:	c7 44 24 24 00 00 00 	mov    DWORD PTR [rsp+0x24],0x0
  403b4a:	00 
  403b4b:	31 ed                	xor    ebp,ebp
  403b4d:	c7 44 24 28 00 00 00 	mov    DWORD PTR [rsp+0x28],0x0
  403b54:	00 
  403b55:	c7 44 24 2c 00 00 00 	mov    DWORD PTR [rsp+0x2c],0x0
  403b5c:	00 
  403b5d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
  403b62:	84 c0                	test   al,al
  403b64:	0f 84 e0 00 00 00    	je     0x403c4a
  403b6a:	3c 2e                	cmp    al,0x2e
  403b6c:	75 18                	jne    0x403b86
  403b6e:	83 7c 24 28 00       	cmp    DWORD PTR [rsp+0x28],0x0
  403b73:	0f 85 1b 01 00 00    	jne    0x403c94
  403b79:	c7 44 24 28 01 00 00 	mov    DWORD PTR [rsp+0x28],0x1
  403b80:	00 
  403b81:	49 ff c4             	inc    r12
  403b84:	eb d7                	jmp    0x403b5d
  403b86:	3c 30                	cmp    al,0x30
  403b88:	0f 82 06 01 00 00    	jb     0x403c94
  403b8e:	3c 39                	cmp    al,0x39
  403b90:	0f 87 fe 00 00 00    	ja     0x403c94
  403b96:	ff 44 24 2c          	inc    DWORD PTR [rsp+0x2c]
  403b9a:	ff 44 24 24          	inc    DWORD PTR [rsp+0x24]
  403b9e:	8b 44 24 24          	mov    eax,DWORD PTR [rsp+0x24]
  403ba2:	3b 44 24 20          	cmp    eax,DWORD PTR [rsp+0x20]
  403ba6:	0f 87 e8 00 00 00    	ja     0x403c94
  403bac:	83 7c 24 28 00       	cmp    DWORD PTR [rsp+0x28],0x0
  403bb1:	74 02                	je     0x403bb5
  403bb3:	ff c5                	inc    ebp
  403bb5:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  403bba:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  403bbe:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  403bc3:	44 89 e9             	mov    ecx,r13d
  403bc6:	e8 3c e0 ff ff       	call   0x401c07
  403bcb:	85 c0                	test   eax,eax
  403bcd:	0f 85 c1 00 00 00    	jne    0x403c94
  403bd3:	41 0f b6 34 24       	movzx  esi,BYTE PTR [r12]
  403bd8:	83 ee 30             	sub    esi,0x30
  403bdb:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  403be0:	44 89 ea             	mov    edx,r13d
  403be3:	e8 bf c9 ff ff       	call   0x4005a7
  403be8:	85 d2                	test   edx,edx
  403bea:	0f 85 a4 00 00 00    	jne    0x403c94
  403bf0:	48 8b 3c 24          	mov    rdi,QWORD PTR [rsp]
  403bf4:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  403bf9:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
  403bfe:	44 89 e9             	mov    ecx,r13d
  403c01:	e8 a0 cd ff ff       	call   0x4009a6
  403c06:	85 c0                	test   eax,eax
  403c08:	0f 85 86 00 00 00    	jne    0x403c94
  403c0e:	83 7c 24 28 00       	cmp    DWORD PTR [rsp+0x28],0x0
  403c13:	74 2d                	je     0x403c42
  403c15:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  403c1a:	48 89 de             	mov    rsi,rbx
  403c1d:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  403c22:	44 89 e9             	mov    ecx,r13d
  403c25:	e8 dd df ff ff       	call   0x401c07
  403c2a:	85 c0                	test   eax,eax
  403c2c:	75 66                	jne    0x403c94
  403c2e:	48 89 df             	mov    rdi,rbx
  403c31:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  403c36:	44 89 ea             	mov    edx,r13d
  403c39:	e8 47 cb ff ff       	call   0x400785
  403c3e:	85 d2                	test   edx,edx
  403c40:	75 52                	jne    0x403c94
  403c42:	49 ff c4             	inc    r12
  403c45:	e9 13 ff ff ff       	jmp    0x403b5d
  403c4a:	83 7c 24 2c 00       	cmp    DWORD PTR [rsp+0x2c],0x0
  403c4f:	74 43                	je     0x403c94
  403c51:	85 ed                	test   ebp,ebp
  403c53:	74 18                	je     0x403c6d
  403c55:	4c 89 ff             	mov    rdi,r15
  403c58:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  403c5c:	48 89 da             	mov    rdx,rbx
  403c5f:	44 89 e9             	mov    ecx,r13d
  403c62:	e8 6b e0 ff ff       	call   0x401cd2
  403c67:	85 c0                	test   eax,eax
  403c69:	75 29                	jne    0x403c94
  403c6b:	eb 13                	jmp    0x403c80
  403c6d:	4c 89 ff             	mov    rdi,r15
  403c70:	48 8b 34 24          	mov    rsi,QWORD PTR [rsp]
  403c74:	44 89 ea             	mov    edx,r13d
  403c77:	e8 09 cb ff ff       	call   0x400785
  403c7c:	85 d2                	test   edx,edx
  403c7e:	75 14                	jne    0x403c94
  403c80:	45 85 f6             	test   r14d,r14d
  403c83:	74 08                	je     0x403c8d
  403c85:	49 c7 47 10 01 00 00 	mov    QWORD PTR [r15+0x10],0x1
  403c8c:	00 
  403c8d:	4c 89 f8             	mov    rax,r15
  403c90:	31 d2                	xor    edx,edx
  403c92:	eb 07                	jmp    0x403c9b
  403c94:	31 c0                	xor    eax,eax
  403c96:	ba 01 00 00 00       	mov    edx,0x1
  403c9b:	48 83 c4 40          	add    rsp,0x40
  403c9f:	41 5f                	pop    r15
  403ca1:	41 5e                	pop    r14
  403ca3:	41 5d                	pop    r13
  403ca5:	41 5c                	pop    r12
  403ca7:	5d                   	pop    rbp
  403ca8:	5b                   	pop    rbx
  403ca9:	c3                   	ret
  403caa:	53                   	push   rbx
  403cab:	48 8d 1d f2 03 00 00 	lea    rbx,[rip+0x3f2]        # 0x4040a4
  403cb2:	41 89 ca             	mov    r10d,ecx
  403cb5:	41 c1 e2 02          	shl    r10d,0x2
  403cb9:	41 83 ea 04          	sub    r10d,0x4
  403cbd:	4c 89 d1             	mov    rcx,r10
  403cc0:	49 89 c3             	mov    r11,rax
  403cc3:	49 d3 eb             	shr    r11,cl
  403cc6:	41 83 e3 0f          	and    r11d,0xf
  403cca:	42 8a 14 1b          	mov    dl,BYTE PTR [rbx+r11*1]
  403cce:	43 88 14 3e          	mov    BYTE PTR [r14+r15*1],dl
  403cd2:	41 ff c7             	inc    r15d
  403cd5:	41 83 ea 04          	sub    r10d,0x4
  403cd9:	79 e2                	jns    0x403cbd
  403cdb:	5b                   	pop    rbx
  403cdc:	c3                   	ret
  403cdd:	53                   	push   rbx
  403cde:	55                   	push   rbp
  403cdf:	41 54                	push   r12
  403ce1:	41 55                	push   r13
  403ce3:	41 56                	push   r14
  403ce5:	41 57                	push   r15
  403ce7:	49 89 fc             	mov    r12,rdi
  403cea:	41 89 f5             	mov    r13d,esi
  403ced:	4c 8d 35 cc 03 00 00 	lea    r14,[rip+0x3cc]        # 0x4040c0
  403cf4:	41 c6 06 6f          	mov    BYTE PTR [r14],0x6f
  403cf8:	41 c6 46 01 75       	mov    BYTE PTR [r14+0x1],0x75
  403cfd:	41 c6 46 02 74       	mov    BYTE PTR [r14+0x2],0x74
  403d02:	44 89 e8             	mov    eax,r13d
  403d05:	31 d2                	xor    edx,edx
  403d07:	b9 0a 00 00 00       	mov    ecx,0xa
  403d0c:	f7 f1                	div    ecx
  403d0e:	04 30                	add    al,0x30
  403d10:	80 c2 30             	add    dl,0x30
  403d13:	41 88 46 03          	mov    BYTE PTR [r14+0x3],al
  403d17:	41 88 56 04          	mov    BYTE PTR [r14+0x4],dl
  403d1b:	48 8d 35 92 03 00 00 	lea    rsi,[rip+0x392]        # 0x4040b4
  403d22:	b9 0c 00 00 00       	mov    ecx,0xc
  403d27:	49 8d 7e 05          	lea    rdi,[r14+0x5]
  403d2b:	f3 a4                	rep movs BYTE PTR es:[rdi],BYTE PTR ds:[rsi]
  403d2d:	41 bf 11 00 00 00    	mov    r15d,0x11
  403d33:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
  403d37:	b9 08 00 00 00       	mov    ecx,0x8
  403d3c:	e8 69 ff ff ff       	call   0x403caa
  403d41:	43 c6 04 3e 3a       	mov    BYTE PTR [r14+r15*1],0x3a
  403d46:	41 ff c7             	inc    r15d
  403d49:	49 8b 44 24 10       	mov    rax,QWORD PTR [r12+0x10]
  403d4e:	b9 01 00 00 00       	mov    ecx,0x1
  403d53:	e8 52 ff ff ff       	call   0x403caa
  403d58:	43 c6 04 3e 3a       	mov    BYTE PTR [r14+r15*1],0x3a
  403d5d:	41 ff c7             	inc    r15d
  403d60:	49 8b 44 24 18       	mov    rax,QWORD PTR [r12+0x18]
  403d65:	b9 10 00 00 00       	mov    ecx,0x10
  403d6a:	e8 3b ff ff ff       	call   0x403caa
  403d6f:	43 c6 04 3e 3a       	mov    BYTE PTR [r14+r15*1],0x3a
  403d74:	41 ff c7             	inc    r15d
  403d77:	41 8b 44 24 08       	mov    eax,DWORD PTR [r12+0x8]
  403d7c:	b9 08 00 00 00       	mov    ecx,0x8
  403d81:	e8 24 ff ff ff       	call   0x403caa
  403d86:	43 c6 04 3e 3a       	mov    BYTE PTR [r14+r15*1],0x3a
  403d8b:	41 ff c7             	inc    r15d
  403d8e:	b8 01 00 00 00       	mov    eax,0x1
  403d93:	bf 01 00 00 00       	mov    edi,0x1
  403d98:	4c 89 f6             	mov    rsi,r14
  403d9b:	44 89 fa             	mov    edx,r15d
  403d9e:	0f 05                	syscall
  403da0:	41 8b 6c 24 08       	mov    ebp,DWORD PTR [r12+0x8]
  403da5:	85 ed                	test   ebp,ebp
  403da7:	74 35                	je     0x403dde
  403da9:	ff cd                	dec    ebp
  403dab:	4c 8d 35 0e 03 00 00 	lea    r14,[rip+0x30e]        # 0x4040c0
  403db2:	45 31 ff             	xor    r15d,r15d
  403db5:	49 8b 44 ec 20       	mov    rax,QWORD PTR [r12+rbp*8+0x20]
  403dba:	b9 10 00 00 00       	mov    ecx,0x10
  403dbf:	e8 e6 fe ff ff       	call   0x403caa
  403dc4:	b8 01 00 00 00       	mov    eax,0x1
  403dc9:	bf 01 00 00 00       	mov    edi,0x1
  403dce:	48 8d 35 eb 02 00 00 	lea    rsi,[rip+0x2eb]        # 0x4040c0
  403dd5:	ba 10 00 00 00       	mov    edx,0x10
  403dda:	0f 05                	syscall
  403ddc:	eb c7                	jmp    0x403da5
  403dde:	b8 01 00 00 00       	mov    eax,0x1
  403de3:	bf 01 00 00 00       	mov    edi,0x1
  403de8:	48 8d 35 b4 02 00 00 	lea    rsi,[rip+0x2b4]        # 0x4040a3
  403def:	ba 01 00 00 00       	mov    edx,0x1
  403df4:	0f 05                	syscall
  403df6:	41 5f                	pop    r15
  403df8:	41 5e                	pop    r14
  403dfa:	41 5d                	pop    r13
  403dfc:	41 5c                	pop    r12
  403dfe:	5d                   	pop    rbp
  403dff:	5b                   	pop    rbx
  403e00:	c3                   	ret
  403e01:	53                   	push   rbx
  403e02:	55                   	push   rbp
  403e03:	41 54                	push   r12
  403e05:	41 55                	push   r13
  403e07:	41 56                	push   r14
  403e09:	41 57                	push   r15
  403e0b:	48 83 ec 20          	sub    rsp,0x20
  403e0f:	49 89 fd             	mov    r13,rdi
  403e12:	48 89 f3             	mov    rbx,rsi
  403e15:	49 89 d4             	mov    r12,rdx
  403e18:	48 89 4c 24 18       	mov    QWORD PTR [rsp+0x18],rcx
  403e1d:	4d 8d 74 dd 00       	lea    r14,[r13+rbx*8+0x0]
  403e22:	48 89 d8             	mov    rax,rbx
  403e25:	48 0f af c3          	imul   rax,rbx
  403e29:	4d 8d 3c c6          	lea    r15,[r14+rax*8]
  403e2d:	4d 8d 04 df          	lea    r8,[r15+rbx*8]
  403e31:	4d 8d 0c d8          	lea    r9,[r8+rbx*8]
  403e35:	4d 8d 14 c1          	lea    r10,[r9+rax*8]
  403e39:	4c 89 04 24          	mov    QWORD PTR [rsp],r8
  403e3d:	4c 89 4c 24 08       	mov    QWORD PTR [rsp+0x8],r9
  403e42:	4c 89 54 24 10       	mov    QWORD PTR [rsp+0x10],r10
  403e47:	4d 85 e4             	test   r12,r12
  403e4a:	0f 84 34 01 00 00    	je     0x403f84
  403e50:	49 f7 c4 01 00 00 00 	test   r12,0x1
  403e57:	74 59                	je     0x403eb2
  403e59:	45 31 c0             	xor    r8d,r8d
  403e5c:	49 39 d8             	cmp    r8,rbx
  403e5f:	73 37                	jae    0x403e98
  403e61:	4f 8b 14 c7          	mov    r10,QWORD PTR [r15+r8*8]
  403e65:	4c 89 c0             	mov    rax,r8
  403e68:	48 0f af c3          	imul   rax,rbx
  403e6c:	49 8d 2c c6          	lea    rbp,[r14+rax*8]
  403e70:	45 31 db             	xor    r11d,r11d
  403e73:	49 39 db             	cmp    r11,rbx
  403e76:	73 13                	jae    0x403e8b
  403e78:	4a 8b 44 dd 00       	mov    rax,QWORD PTR [rbp+r11*8+0x0]
  403e7d:	4b 0f af 44 dd 00    	imul   rax,QWORD PTR [r13+r11*8+0x0]
  403e83:	49 01 c2             	add    r10,rax
  403e86:	49 ff c3             	inc    r11
  403e89:	eb e8                	jmp    0x403e73
  403e8b:	48 8b 04 24          	mov    rax,QWORD PTR [rsp]
  403e8f:	4e 89 14 c0          	mov    QWORD PTR [rax+r8*8],r10
  403e93:	49 ff c0             	inc    r8
  403e96:	eb c4                	jmp    0x403e5c
  403e98:	45 31 c0             	xor    r8d,r8d
  403e9b:	4c 8b 0c 24          	mov    r9,QWORD PTR [rsp]
  403e9f:	49 39 d8             	cmp    r8,rbx
  403ea2:	73 0e                	jae    0x403eb2
  403ea4:	4b 8b 04 c1          	mov    rax,QWORD PTR [r9+r8*8]
  403ea8:	4b 89 44 c5 00       	mov    QWORD PTR [r13+r8*8+0x0],rax
  403ead:	49 ff c0             	inc    r8
  403eb0:	eb ed                	jmp    0x403e9f
  403eb2:	49 d1 ec             	shr    r12,1
  403eb5:	0f 84 c9 00 00 00    	je     0x403f84
  403ebb:	45 31 c0             	xor    r8d,r8d
  403ebe:	49 39 d8             	cmp    r8,rbx
  403ec1:	0f 83 80 00 00 00    	jae    0x403f47
  403ec7:	4c 89 c0             	mov    rax,r8
  403eca:	48 0f af c3          	imul   rax,rbx
  403ece:	49 8d 2c c6          	lea    rbp,[r14+rax*8]
  403ed2:	4f 8b 14 c7          	mov    r10,QWORD PTR [r15+r8*8]
  403ed6:	45 31 db             	xor    r11d,r11d
  403ed9:	49 39 db             	cmp    r11,rbx
  403edc:	73 12                	jae    0x403ef0
  403ede:	4a 8b 44 dd 00       	mov    rax,QWORD PTR [rbp+r11*8+0x0]
  403ee3:	4b 0f af 04 df       	imul   rax,QWORD PTR [r15+r11*8]
  403ee8:	49 01 c2             	add    r10,rax
  403eeb:	49 ff c3             	inc    r11
  403eee:	eb e9                	jmp    0x403ed9
  403ef0:	48 8b 44 24 10       	mov    rax,QWORD PTR [rsp+0x10]
  403ef5:	4e 89 14 c0          	mov    QWORD PTR [rax+r8*8],r10
  403ef9:	31 c9                	xor    ecx,ecx
  403efb:	48 39 d9             	cmp    rcx,rbx
  403efe:	73 3f                	jae    0x403f3f
  403f00:	45 31 d2             	xor    r10d,r10d
  403f03:	45 31 db             	xor    r11d,r11d
  403f06:	49 39 db             	cmp    r11,rbx
  403f09:	73 1c                	jae    0x403f27
  403f0b:	4c 89 d8             	mov    rax,r11
  403f0e:	48 0f af c3          	imul   rax,rbx
  403f12:	48 01 c8             	add    rax,rcx
  403f15:	49 8b 04 c6          	mov    rax,QWORD PTR [r14+rax*8]
  403f19:	4a 0f af 44 dd 00    	imul   rax,QWORD PTR [rbp+r11*8+0x0]
  403f1f:	49 01 c2             	add    r10,rax
  403f22:	49 ff c3             	inc    r11
  403f25:	eb df                	jmp    0x403f06
  403f27:	4c 89 c0             	mov    rax,r8
  403f2a:	48 0f af c3          	imul   rax,rbx
  403f2e:	48 01 c8             	add    rax,rcx
  403f31:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  403f36:	4c 89 14 c2          	mov    QWORD PTR [rdx+rax*8],r10
  403f3a:	48 ff c1             	inc    rcx
  403f3d:	eb bc                	jmp    0x403efb
  403f3f:	49 ff c0             	inc    r8
  403f42:	e9 77 ff ff ff       	jmp    0x403ebe
  403f47:	48 89 d8             	mov    rax,rbx
  403f4a:	48 0f af c3          	imul   rax,rbx
  403f4e:	31 c9                	xor    ecx,ecx
  403f50:	48 8b 54 24 08       	mov    rdx,QWORD PTR [rsp+0x8]
  403f55:	48 39 c1             	cmp    rcx,rax
  403f58:	73 0d                	jae    0x403f67
  403f5a:	4c 8b 04 ca          	mov    r8,QWORD PTR [rdx+rcx*8]
  403f5e:	4d 89 04 ce          	mov    QWORD PTR [r14+rcx*8],r8
  403f62:	48 ff c1             	inc    rcx
  403f65:	eb ee                	jmp    0x403f55
  403f67:	31 c9                	xor    ecx,ecx
  403f69:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
  403f6e:	48 39 d9             	cmp    rcx,rbx
  403f71:	0f 83 d0 fe ff ff    	jae    0x403e47
  403f77:	4c 8b 04 ca          	mov    r8,QWORD PTR [rdx+rcx*8]
  403f7b:	4d 89 04 cf          	mov    QWORD PTR [r15+rcx*8],r8
  403f7f:	48 ff c1             	inc    rcx
  403f82:	eb ea                	jmp    0x403f6e
  403f84:	48 8b 4c 24 18       	mov    rcx,QWORD PTR [rsp+0x18]
  403f89:	49 8b 44 cd 00       	mov    rax,QWORD PTR [r13+rcx*8+0x0]
  403f8e:	48 83 c4 20          	add    rsp,0x20
  403f92:	41 5f                	pop    r15
  403f94:	41 5e                	pop    r14
  403f96:	41 5d                	pop    r13
  403f98:	41 5c                	pop    r12
  403f9a:	5d                   	pop    rbp
  403f9b:	5b                   	pop    rbx
  403f9c:	c3                   	ret
	...
  403ffd:	00 00                	add    BYTE PTR [rax],al
  403fff:	00 06                	add    BYTE PTR [rsi],al
  404001:	00 00                	add    BYTE PTR [rax],al
  404003:	00 01                	add    BYTE PTR [rcx],al
  404005:	00 00                	add    BYTE PTR [rax],al
  404007:	00 00                	add    BYTE PTR [rax],al
  404009:	30 02                	xor    BYTE PTR [rdx],al
  40400b:	00 00                	add    BYTE PTR [rax],al
  40400d:	00 00                	add    BYTE PTR [rax],al
  40400f:	00 00                	add    BYTE PTR [rax],al
  404011:	90                   	nop
  404012:	00 00                	add    BYTE PTR [rax],al
  404014:	00 00                	add    BYTE PTR [rax],al
  404016:	00 00                	add    BYTE PTR [rax],al
  404018:	c0 1e 00             	rcr    BYTE PTR [rsi],0x0
  40401b:	00 00                	add    BYTE PTR [rax],al
  40401d:	00 00                	add    BYTE PTR [rax],al
  40401f:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  404042:	00 00                	add    BYTE PTR [rax],al
  404044:	00 01                	add    BYTE PTR [rcx],al
  404046:	00 00                	add    BYTE PTR [rax],al
  404048:	40 00 00             	rex add BYTE PTR [rax],al
  40404b:	00 00                	add    BYTE PTR [rax],al
  40404d:	01 00                	add    DWORD PTR [rax],eax
  40404f:	00 80 00 00 00 00    	add    BYTE PTR [rax+0x0],al
  404055:	01 00                	add    DWORD PTR [rax],eax
  404057:	00 80 00 00 00 00    	add    BYTE PTR [rax+0x0],al
  40405d:	01 00                	add    DWORD PTR [rax],eax
	...
  404067:	00 80 10 02 00 00    	add    BYTE PTR [rax+0x210],al
  40406d:	01 00                	add    DWORD PTR [rax],eax
  40406f:	00 80 20 02 00 00    	add    BYTE PTR [rax+0x220],al
  404075:	01 00                	add    DWORD PTR [rax],eax
  404077:	00 6f 75             	add    BYTE PTR [rdi+0x75],ch
  40407a:	74 30                	je     0x4040ac
  40407c:	30 5f 62             	xor    BYTE PTR [rdi+0x62],bl
  40407f:	69 74 73 3d 30 78 30 	imul   esi,DWORD PTR [rbx+rsi*2+0x3d],0x30307830
  404086:	30 
  404087:	30 30                	xor    BYTE PTR [rax],dh
  404089:	30 30                	xor    BYTE PTR [rax],dh
  40408b:	30 30                	xor    BYTE PTR [rax],dh
  40408d:	30 30                	xor    BYTE PTR [rax],dh
  40408f:	30 30                	xor    BYTE PTR [rax],dh
  404091:	30 30                	xor    BYTE PTR [rax],dh
  404093:	30 30                	xor    BYTE PTR [rax],dh
  404095:	0a 6f 75             	or     ch,BYTE PTR [rdi+0x75]
  404098:	74 30                	je     0x4040ca
  40409a:	30 5f 73             	xor    BYTE PTR [rdi+0x73],bl
  40409d:	74 72                	je     0x404111
  40409f:	69 6e 67 3d 0a 30 31 	imul   ebp,DWORD PTR [rsi+0x67],0x31300a3d
  4040a6:	32 33                	xor    dh,BYTE PTR [rbx]
  4040a8:	34 35                	xor    al,0x35
  4040aa:	36 37                	ss (bad)
  4040ac:	38 39                	cmp    BYTE PTR [rcx],bh
  4040ae:	61                   	(bad)
  4040af:	62 63 64 65 66       	(bad)
  4040b4:	5f                   	pop    rdi
  4040b5:	72 61                	jb     0x404118
  4040b7:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4040b8:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4040bc:	70 3d                	jo     0x4040fb
  4040be:	30 78 00             	xor    BYTE PTR [rax+0x0],bh
	...
  404145:	00 e0                	add    al,ah
  404147:	bf 00 00 00 00       	mov    edi,0x0
  40414c:	00 00                	add    BYTE PTR [rax],al
  40414e:	e0 bf                	loopne 0x40410f
  404150:	aa                   	stos   BYTE PTR es:[rdi],al
  404151:	4c 58                	rex.WR pop rax
  404153:	e8 7a b6 eb 3f       	call   0x402bf7d2
  404158:	aa                   	stos   BYTE PTR es:[rdi],al
  404159:	4c 58                	rex.WR pop rax
  40415b:	e8 7a b6 eb bf       	call   0xffffffffc02bf7da
  404160:	aa                   	stos   BYTE PTR es:[rdi],al
  404161:	4c 58                	rex.WR pop rax
  404163:	e8 7a b6 eb bf       	call   0xffffffffc02bf7e2
  404168:	aa                   	stos   BYTE PTR es:[rdi],al
  404169:	4c 58                	rex.WR pop rax
  40416b:	e8 7a b6 eb 3f       	call   0x402bf7ea
  404170:	50                   	push   rax
  404171:	e9 2f 37 ef c6       	jmp    0xffffffffc72f78a5
  404176:	d3 3f                	sar    DWORD PTR [rdi],cl
  404178:	50                   	push   rax
  404179:	e9 2f 37 ef c6       	jmp    0xffffffffc72f78ad
  40417e:	d3 3f                	sar    DWORD PTR [rdi],cl
  404180:	a8 f4                	test   al,0xf4
  404182:	97                   	xchg   edi,eax
  404183:	9b                   	fwait
  404184:	77 e3                	ja     0x404169
  404186:	e9 bf a8 f4 97       	jmp    0xffffffff9834ea4a
  40418b:	9b                   	fwait
  40418c:	77 e3                	ja     0x404171
  40418e:	e9 bf ff 54 44       	jmp    0x44954152
  404193:	13 0e                	adc    ecx,DWORD PTR [rsi]
  404195:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  404196:	ee                   	out    dx,al
  404197:	3f                   	(bad)
  404198:	ff 54 44 13          	call   QWORD PTR [rsp+rax*2+0x13]
  40419c:	0e                   	(bad)
  40419d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40419e:	ee                   	out    dx,al
  40419f:	3f                   	(bad)
  4041a0:	5e                   	pop    rsi
  4041a1:	5a                   	pop    rdx
  4041a2:	75 04                	jne    0x4041a8
  4041a4:	23 cf                	and    ecx,edi
  4041a6:	e2 3f                	loop   0x4041e7
  4041a8:	5e                   	pop    rsi
  4041a9:	5a                   	pop    rdx
  4041aa:	75 04                	jne    0x4041b0
  4041ac:	23 cf                	and    ecx,edi
  4041ae:	e2 3f                	loop   0x4041ef
  4041b0:	00 00                	add    BYTE PTR [rax],al
  4041b2:	00 00                	add    BYTE PTR [rax],al
  4041b4:	00 00                	add    BYTE PTR [rax],al
  4041b6:	f0 3f                	lock (bad)
  4041b8:	00 00                	add    BYTE PTR [rax],al
  4041ba:	00 00                	add    BYTE PTR [rax],al
  4041bc:	00 00                	add    BYTE PTR [rax],al
  4041be:	f0 bf 00 00 00 00    	lock mov edi,0x0
  4041c4:	00 00                	add    BYTE PTR [rax],al
  4041c6:	f0 bf 00 00 00 00    	lock mov edi,0x0
  4041cc:	00 00                	add    BYTE PTR [rax],al
  4041ce:	f0 3f                	lock (bad)
  4041d0:	00 00                	add    BYTE PTR [rax],al
  4041d2:	00 00                	add    BYTE PTR [rax],al
  4041d4:	00 00                	add    BYTE PTR [rax],al
  4041d6:	e0 3f                	loopne 0x404217
  4041d8:	2f                   	(bad)
  4041d9:	70 72                	jo     0x40424d
  4041db:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4041dc:	63 2f                	movsxd ebp,DWORD PTR [rdi]
  4041de:	73 65                	jae    0x404245
  4041e0:	6c                   	ins    BYTE PTR es:[rdi],dx
  4041e1:	66 2f                	data16 (bad)
  4041e3:	65 78 65             	gs js  0x40424b
	...
  4041fe:	00 00                	add    BYTE PTR [rax],al
  404200:	01 00                	add    DWORD PTR [rax],eax
  404202:	00 00                	add    BYTE PTR [rax],al
  404204:	04 00                	add    al,0x0
  404206:	f1                   	int1
  404207:	ff 00                	inc    DWORD PTR [rax]
	...
  404215:	00 00                	add    BYTE PTR [rax],al
  404217:	00 1c 00             	add    BYTE PTR [rax+rax*1],bl
  40421a:	00 00                	add    BYTE PTR [rax],al
  40421c:	00 00                	add    BYTE PTR [rax],al
  40421e:	f1                   	int1
  40421f:	ff 00                	inc    DWORD PTR [rax]
  404221:	00 00                	add    BYTE PTR [rax],al
  404223:	00 00                	add    BYTE PTR [rax],al
  404225:	01 00                	add    DWORD PTR [rax],eax
	...
  40422f:	00 3d 00 00 00 00    	add    BYTE PTR [rip+0x0],bh        # 0x404235
  404235:	00 f1                	add    cl,dh
  404237:	ff 01                	inc    DWORD PTR [rcx]
	...
  404245:	00 00                	add    BYTE PTR [rax],al
  404247:	00 47 00             	add    BYTE PTR [rdi+0x0],al
  40424a:	00 00                	add    BYTE PTR [rax],al
  40424c:	00 00                	add    BYTE PTR [rax],al
  40424e:	f1                   	int1
  40424f:	ff 03                	inc    DWORD PTR [rbx]
	...
  40425d:	00 00                	add    BYTE PTR [rax],al
  40425f:	00 51 00             	add    BYTE PTR [rcx+0x0],dl
  404262:	00 00                	add    BYTE PTR [rax],al
  404264:	00 00                	add    BYTE PTR [rax],al
  404266:	f1                   	int1
  404267:	ff 09                	dec    DWORD PTR [rcx]
	...
  404275:	00 00                	add    BYTE PTR [rax],al
  404277:	00 5a 00             	add    BYTE PTR [rdx+0x0],bl
  40427a:	00 00                	add    BYTE PTR [rax],al
  40427c:	00 00                	add    BYTE PTR [rax],al
  40427e:	f1                   	int1
  40427f:	ff 01                	inc    DWORD PTR [rcx]
  404281:	01 00                	add    DWORD PTR [rax],eax
	...
  40428f:	00 65 00             	add    BYTE PTR [rbp+0x0],ah
  404292:	00 00                	add    BYTE PTR [rax],al
  404294:	00 00                	add    BYTE PTR [rax],al
  404296:	f1                   	int1
  404297:	ff e7                	jmp    rdi
	...
  4042a5:	00 00                	add    BYTE PTR [rax],al
  4042a7:	00 74 00 00          	add    BYTE PTR [rax+rax*1+0x0],dh
  4042ab:	00 00                	add    BYTE PTR [rax],al
  4042ad:	00 f1                	add    cl,dh
  4042af:	ff 03                	inc    DWORD PTR [rbx]
	...
  4042bd:	00 00                	add    BYTE PTR [rax],al
  4042bf:	00 84 00 00 00 00 00 	add    BYTE PTR [rax+rax*1+0x0],al
  4042c6:	f1                   	int1
  4042c7:	ff 05 00 00 00 00    	inc    DWORD PTR [rip+0x0]        # 0x4042cd
	...
  4042d5:	00 00                	add    BYTE PTR [rax],al
  4042d7:	00 93 00 00 00 00    	add    BYTE PTR [rbx+0x0],dl
  4042dd:	00 f1                	add    cl,dh
  4042df:	ff 02                	inc    DWORD PTR [rdx]
	...
  4042ed:	00 00                	add    BYTE PTR [rax],al
  4042ef:	00 9f 00 00 00 00    	add    BYTE PTR [rdi+0x0],bl
  4042f5:	00 f1                	add    cl,dh
  4042f7:	ff 22                	jmp    QWORD PTR [rdx]
  4042f9:	00 10                	add    BYTE PTR [rax],dl
	...
  404307:	00 c0                	add    al,al
  404309:	00 00                	add    BYTE PTR [rax],al
  40430b:	00 00                	add    BYTE PTR [rax],al
  40430d:	00 f1                	add    cl,dh
  40430f:	ff 9c ff ff ff ff ff 	call   FWORD PTR [rdi+rdi*8-0x1]
  404316:	ff                   	(bad)
  404317:	ff 00                	inc    DWORD PTR [rax]
  404319:	00 00                	add    BYTE PTR [rax],al
  40431b:	00 00                	add    BYTE PTR [rax],al
  40431d:	00 00                	add    BYTE PTR [rax],al
  40431f:	00 d1                	add    cl,dl
  404321:	00 00                	add    BYTE PTR [rax],al
  404323:	00 00                	add    BYTE PTR [rax],al
  404325:	00 f1                	add    cl,dh
  404327:	ff 08                	dec    DWORD PTR [rax]
	...
  404335:	00 00                	add    BYTE PTR [rax],al
  404337:	00 c9                	add    cl,cl
  404339:	00 00                	add    BYTE PTR [rax],al
  40433b:	00 00                	add    BYTE PTR [rax],al
  40433d:	00 f1                	add    cl,dh
  40433f:	ff 00                	inc    DWORD PTR [rax]
  404341:	10 00                	adc    BYTE PTR [rax],al
	...
  40434f:	00 dc                	add    ah,bl
  404351:	00 00                	add    BYTE PTR [rax],al
  404353:	00 00                	add    BYTE PTR [rax],al
  404355:	00 f1                	add    cl,dh
  404357:	ff 01                	inc    DWORD PTR [rcx]
	...
  404365:	00 00                	add    BYTE PTR [rax],al
  404367:	00 e6                	add    dh,ah
  404369:	00 00                	add    BYTE PTR [rax],al
  40436b:	00 00                	add    BYTE PTR [rax],al
  40436d:	00 f1                	add    cl,dh
  40436f:	ff 02                	inc    DWORD PTR [rdx]
	...
  40437d:	00 00                	add    BYTE PTR [rax],al
  40437f:	00 ef                	add    bh,ch
  404381:	00 00                	add    BYTE PTR [rax],al
  404383:	00 00                	add    BYTE PTR [rax],al
  404385:	00 f1                	add    cl,dh
  404387:	ff 03                	inc    DWORD PTR [rbx]
	...
  404395:	00 00                	add    BYTE PTR [rax],al
  404397:	00 f8                	add    al,bh
  404399:	00 00                	add    BYTE PTR [rax],al
  40439b:	00 00                	add    BYTE PTR [rax],al
  40439d:	00 f1                	add    cl,dh
  40439f:	ff 04 00             	inc    DWORD PTR [rax+rax*1]
	...
  4043ae:	00 00                	add    BYTE PTR [rax],al
  4043b0:	01 01                	add    DWORD PTR [rcx],eax
  4043b2:	00 00                	add    BYTE PTR [rax],al
  4043b4:	00 00                	add    BYTE PTR [rax],al
  4043b6:	f1                   	int1
  4043b7:	ff 05 00 00 00 00    	inc    DWORD PTR [rip+0x0]        # 0x4043bd
	...
  4043c5:	00 00                	add    BYTE PTR [rax],al
  4043c7:	00 0a                	add    BYTE PTR [rdx],cl
  4043c9:	01 00                	add    DWORD PTR [rax],eax
  4043cb:	00 00                	add    BYTE PTR [rax],al
  4043cd:	00 f1                	add    cl,dh
  4043cf:	ff 06                	inc    DWORD PTR [rsi]
	...
  4043dd:	00 00                	add    BYTE PTR [rax],al
  4043df:	00 16                	add    BYTE PTR [rsi],dl
  4043e1:	01 00                	add    DWORD PTR [rax],eax
  4043e3:	00 00                	add    BYTE PTR [rax],al
  4043e5:	00 f1                	add    cl,dh
  4043e7:	ff 00                	inc    DWORD PTR [rax]
  4043e9:	00 00                	add    BYTE PTR [rax],al
  4043eb:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4043f6:	00 00                	add    BYTE PTR [rax],al
  4043f8:	24 01                	and    al,0x1
  4043fa:	00 00                	add    BYTE PTR [rax],al
  4043fc:	00 00                	add    BYTE PTR [rax],al
  4043fe:	f1                   	int1
  4043ff:	ff                   	(bad)
  404400:	ff                   	(bad)
  404401:	ff                   	(bad)
  404402:	ff                   	(bad)
  404403:	3f                   	(bad)
	...
  404410:	32 01                	xor    al,BYTE PTR [rcx]
  404412:	00 00                	add    BYTE PTR [rax],al
  404414:	00 00                	add    BYTE PTR [rax],al
  404416:	f1                   	int1
  404417:	ff 00                	inc    DWORD PTR [rax]
	...
  404425:	00 00                	add    BYTE PTR [rax],al
  404427:	00 3b                	add    BYTE PTR [rbx],bh
  404429:	01 00                	add    DWORD PTR [rax],eax
  40442b:	00 00                	add    BYTE PTR [rax],al
  40442d:	00 f1                	add    cl,dh
  40442f:	ff 04 00             	inc    DWORD PTR [rax+rax*1]
	...
  40443e:	00 00                	add    BYTE PTR [rax],al
  404440:	44 01 00             	add    DWORD PTR [rax],r8d
  404443:	00 00                	add    BYTE PTR [rax],al
  404445:	00 f1                	add    cl,dh
  404447:	ff 08                	dec    DWORD PTR [rax]
	...
  404455:	00 00                	add    BYTE PTR [rax],al
  404457:	00 4a 01             	add    BYTE PTR [rdx+0x1],cl
  40445a:	00 00                	add    BYTE PTR [rax],al
  40445c:	00 00                	add    BYTE PTR [rax],al
  40445e:	f1                   	int1
  40445f:	ff 10                	call   QWORD PTR [rax]
	...
  40446d:	00 00                	add    BYTE PTR [rax],al
  40446f:	00 53 01             	add    BYTE PTR [rbx+0x1],dl
  404472:	00 00                	add    BYTE PTR [rax],al
  404474:	00 00                	add    BYTE PTR [rax],al
  404476:	f1                   	int1
  404477:	ff 18                	call   FWORD PTR [rax]
	...
  404485:	00 00                	add    BYTE PTR [rax],al
  404487:	00 5b 01             	add    BYTE PTR [rbx+0x1],bl
  40448a:	00 00                	add    BYTE PTR [rax],al
  40448c:	00 00                	add    BYTE PTR [rax],al
  40448e:	f1                   	int1
  40448f:	ff 20                	jmp    QWORD PTR [rax]
	...
  40449d:	00 00                	add    BYTE PTR [rax],al
  40449f:	00 64 01 00          	add    BYTE PTR [rcx+rax*1+0x0],ah
  4044a3:	00 00                	add    BYTE PTR [rax],al
  4044a5:	00 01                	add    BYTE PTR [rcx],al
  4044a7:	00 c0                	add    al,al
  4044a9:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  4044b8:	7c 01                	jl     0x4044bb
  4044ba:	00 00                	add    BYTE PTR [rax],al
  4044bc:	00 00                	add    BYTE PTR [rax],al
  4044be:	01 00                	add    DWORD PTR [rax],eax
  4044c0:	db 00                	fild   DWORD PTR [rax]
  4044c2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4044cd:	00 00                	add    BYTE PTR [rax],al
  4044cf:	00 86 01 00 00 00    	add    BYTE PTR [rsi+0x1],al
  4044d5:	00 01                	add    BYTE PTR [rcx],al
  4044d7:	00 de                	add    dh,bl
  4044d9:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  4044e8:	9a                   	(bad)
  4044e9:	01 00                	add    DWORD PTR [rax],eax
  4044eb:	00 00                	add    BYTE PTR [rax],al
  4044ed:	00 01                	add    BYTE PTR [rcx],al
  4044ef:	00 ee                	add    dh,ch
  4044f1:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  404500:	a4                   	movs   BYTE PTR es:[rdi],BYTE PTR ds:[rsi]
  404501:	01 00                	add    DWORD PTR [rax],eax
  404503:	00 00                	add    BYTE PTR [rax],al
  404505:	00 01                	add    BYTE PTR [rcx],al
  404507:	00 f1                	add    cl,dh
  404509:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  404518:	b3 01                	mov    bl,0x1
  40451a:	00 00                	add    BYTE PTR [rax],al
  40451c:	00 00                	add    BYTE PTR [rax],al
  40451e:	01 00                	add    DWORD PTR [rax],eax
  404520:	02 01                	add    al,BYTE PTR [rcx]
  404522:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40452d:	00 00                	add    BYTE PTR [rax],al
  40452f:	00 be 01 00 00 00    	add    BYTE PTR [rsi+0x1],bh
  404535:	00 01                	add    BYTE PTR [rcx],al
  404537:	00 f7                	add    bh,dh
  404539:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  404548:	c9                   	leave
  404549:	01 00                	add    DWORD PTR [rax],eax
  40454b:	00 00                	add    BYTE PTR [rax],al
  40454d:	00 01                	add    BYTE PTR [rcx],al
  40454f:	00 03                	add    BYTE PTR [rbx],al
  404551:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  404560:	d8 01                	fadd   DWORD PTR [rcx]
  404562:	00 00                	add    BYTE PTR [rax],al
  404564:	00 00                	add    BYTE PTR [rax],al
  404566:	01 00                	add    DWORD PTR [rax],eax
  404568:	19 01                	sbb    DWORD PTR [rcx],eax
  40456a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404575:	00 00                	add    BYTE PTR [rax],al
  404577:	00 e3                	add    bl,ah
  404579:	01 00                	add    DWORD PTR [rax],eax
  40457b:	00 00                	add    BYTE PTR [rax],al
  40457d:	00 01                	add    BYTE PTR [rcx],al
  40457f:	00 07                	add    BYTE PTR [rdi],al
  404581:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  404590:	ee                   	out    dx,al
  404591:	01 00                	add    DWORD PTR [rax],eax
  404593:	00 00                	add    BYTE PTR [rax],al
  404595:	00 01                	add    BYTE PTR [rcx],al
  404597:	00 1a                	add    BYTE PTR [rdx],bl
  404599:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  4045a8:	f6 01 00             	test   BYTE PTR [rcx],0x0
  4045ab:	00 00                	add    BYTE PTR [rax],al
  4045ad:	00 01                	add    BYTE PTR [rcx],al
  4045af:	00 2f                	add    BYTE PTR [rdi],ch
  4045b1:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  4045c0:	01 02                	add    DWORD PTR [rdx],eax
  4045c2:	00 00                	add    BYTE PTR [rax],al
  4045c4:	00 00                	add    BYTE PTR [rax],al
  4045c6:	01 00                	add    DWORD PTR [rax],eax
  4045c8:	22 01                	and    al,BYTE PTR [rcx]
  4045ca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4045d5:	00 00                	add    BYTE PTR [rax],al
  4045d7:	00 0c 02             	add    BYTE PTR [rdx+rax*1],cl
  4045da:	00 00                	add    BYTE PTR [rax],al
  4045dc:	00 00                	add    BYTE PTR [rax],al
  4045de:	01 00                	add    DWORD PTR [rax],eax
  4045e0:	35 01 40 00 00       	xor    eax,0x4001
	...
  4045ed:	00 00                	add    BYTE PTR [rax],al
  4045ef:	00 16                	add    BYTE PTR [rsi],dl
  4045f1:	02 00                	add    al,BYTE PTR [rax]
  4045f3:	00 00                	add    BYTE PTR [rax],al
  4045f5:	00 01                	add    BYTE PTR [rcx],al
  4045f7:	00 3f                	add    BYTE PTR [rdi],bh
  4045f9:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  404608:	1e                   	(bad)
  404609:	02 00                	add    al,BYTE PTR [rax]
  40460b:	00 00                	add    BYTE PTR [rax],al
  40460d:	00 01                	add    BYTE PTR [rcx],al
  40460f:	00 5a 01             	add    BYTE PTR [rdx+0x1],bl
  404612:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40461d:	00 00                	add    BYTE PTR [rax],al
  40461f:	00 27                	add    BYTE PTR [rdi],ah
  404621:	02 00                	add    al,BYTE PTR [rax]
  404623:	00 00                	add    BYTE PTR [rax],al
  404625:	00 01                	add    BYTE PTR [rcx],al
  404627:	00 47 01             	add    BYTE PTR [rdi+0x1],al
  40462a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404635:	00 00                	add    BYTE PTR [rax],al
  404637:	00 32                	add    BYTE PTR [rdx],dh
  404639:	02 00                	add    al,BYTE PTR [rax]
  40463b:	00 00                	add    BYTE PTR [rax],al
  40463d:	00 01                	add    BYTE PTR [rcx],al
  40463f:	00 5d 01             	add    BYTE PTR [rbp+0x1],bl
  404642:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40464d:	00 00                	add    BYTE PTR [rax],al
  40464f:	00 3b                	add    BYTE PTR [rbx],bh
  404651:	02 00                	add    al,BYTE PTR [rax]
  404653:	00 00                	add    BYTE PTR [rax],al
  404655:	00 01                	add    BYTE PTR [rcx],al
  404657:	00 63 01             	add    BYTE PTR [rbx+0x1],ah
  40465a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404665:	00 00                	add    BYTE PTR [rax],al
  404667:	00 44 02 00          	add    BYTE PTR [rdx+rax*1+0x0],al
  40466b:	00 00                	add    BYTE PTR [rax],al
  40466d:	00 01                	add    BYTE PTR [rcx],al
  40466f:	00 69 01             	add    BYTE PTR [rcx+0x1],ch
  404672:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40467d:	00 00                	add    BYTE PTR [rax],al
  40467f:	00 52 02             	add    BYTE PTR [rdx+0x2],dl
  404682:	00 00                	add    BYTE PTR [rax],al
  404684:	00 00                	add    BYTE PTR [rax],al
  404686:	01 00                	add    DWORD PTR [rax],eax
  404688:	85 01                	test   DWORD PTR [rcx],eax
  40468a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404695:	00 00                	add    BYTE PTR [rax],al
  404697:	00 5e 02             	add    BYTE PTR [rsi+0x2],bl
  40469a:	00 00                	add    BYTE PTR [rax],al
  40469c:	00 00                	add    BYTE PTR [rax],al
  40469e:	01 00                	add    DWORD PTR [rax],eax
  4046a0:	70 01                	jo     0x4046a3
  4046a2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4046ad:	00 00                	add    BYTE PTR [rax],al
  4046af:	00 6a 02             	add    BYTE PTR [rdx+0x2],ch
  4046b2:	00 00                	add    BYTE PTR [rax],al
  4046b4:	00 00                	add    BYTE PTR [rax],al
  4046b6:	01 00                	add    DWORD PTR [rax],eax
  4046b8:	88 01                	mov    BYTE PTR [rcx],al
  4046ba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4046c5:	00 00                	add    BYTE PTR [rax],al
  4046c7:	00 78 02             	add    BYTE PTR [rax+0x2],bh
  4046ca:	00 00                	add    BYTE PTR [rax],al
  4046cc:	00 00                	add    BYTE PTR [rax],al
  4046ce:	01 00                	add    DWORD PTR [rax],eax
  4046d0:	a4                   	movs   BYTE PTR es:[rdi],BYTE PTR ds:[rsi]
  4046d1:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  4046e0:	84 02                	test   BYTE PTR [rdx],al
  4046e2:	00 00                	add    BYTE PTR [rax],al
  4046e4:	00 00                	add    BYTE PTR [rax],al
  4046e6:	01 00                	add    DWORD PTR [rax],eax
  4046e8:	8f 01                	pop    QWORD PTR [rcx]
  4046ea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4046f5:	00 00                	add    BYTE PTR [rax],al
  4046f7:	00 90 02 00 00 00    	add    BYTE PTR [rax+0x2],dl
  4046fd:	00 01                	add    BYTE PTR [rcx],al
  4046ff:	00 a7 01 40 00 00    	add    BYTE PTR [rdi+0x4001],ah
	...
  40470d:	00 00                	add    BYTE PTR [rax],al
  40470f:	00 99 02 00 00 00    	add    BYTE PTR [rcx+0x2],bl
  404715:	00 01                	add    BYTE PTR [rcx],al
  404717:	00 bf 01 40 00 00    	add    BYTE PTR [rdi+0x4001],bh
	...
  404725:	00 00                	add    BYTE PTR [rax],al
  404727:	00 a5 02 00 00 00    	add    BYTE PTR [rbp+0x2],ah
  40472d:	00 01                	add    BYTE PTR [rcx],al
  40472f:	00 b1 01 40 00 00    	add    BYTE PTR [rcx+0x4001],dh
	...
  40473d:	00 00                	add    BYTE PTR [rax],al
  40473f:	00 b1 02 00 00 00    	add    BYTE PTR [rcx+0x2],dh
  404745:	00 01                	add    BYTE PTR [rcx],al
  404747:	00 c2                	add    dl,al
  404749:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  404758:	ba 02 00 00 00       	mov    edx,0x2
  40475d:	00 01                	add    BYTE PTR [rcx],al
  40475f:	00 dd                	add    ch,bl
  404761:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  404770:	c6 02 00             	mov    BYTE PTR [rdx],0x0
  404773:	00 00                	add    BYTE PTR [rax],al
  404775:	00 01                	add    BYTE PTR [rcx],al
  404777:	00 cf                	add    bh,cl
  404779:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  404788:	d2 02                	rol    BYTE PTR [rdx],cl
  40478a:	00 00                	add    BYTE PTR [rax],al
  40478c:	00 00                	add    BYTE PTR [rax],al
  40478e:	01 00                	add    DWORD PTR [rax],eax
  404790:	e0 01                	loopne 0x404793
  404792:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40479d:	00 00                	add    BYTE PTR [rax],al
  40479f:	00 e1                	add    cl,ah
  4047a1:	02 00                	add    al,BYTE PTR [rax]
  4047a3:	00 00                	add    BYTE PTR [rax],al
  4047a5:	00 01                	add    BYTE PTR [rcx],al
  4047a7:	00 3c 02             	add    BYTE PTR [rdx+rax*1],bh
  4047aa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4047b5:	00 00                	add    BYTE PTR [rax],al
  4047b7:	00 ed                	add    ch,ch
  4047b9:	02 00                	add    al,BYTE PTR [rax]
  4047bb:	00 00                	add    BYTE PTR [rax],al
  4047bd:	00 01                	add    BYTE PTR [rcx],al
  4047bf:	00 20                	add    BYTE PTR [rax],ah
  4047c1:	02 40 00             	add    al,BYTE PTR [rax+0x0]
	...
  4047d0:	f9                   	stc
  4047d1:	02 00                	add    al,BYTE PTR [rax]
  4047d3:	00 00                	add    BYTE PTR [rax],al
  4047d5:	00 01                	add    BYTE PTR [rcx],al
  4047d7:	00 fd                	add    ch,bh
  4047d9:	01 40 00             	add    DWORD PTR [rax+0x0],eax
	...
  4047e8:	06                   	(bad)
  4047e9:	03 00                	add    eax,DWORD PTR [rax]
  4047eb:	00 00                	add    BYTE PTR [rax],al
  4047ed:	00 01                	add    BYTE PTR [rcx],al
  4047ef:	00 0b                	add    BYTE PTR [rbx],cl
  4047f1:	02 40 00             	add    al,BYTE PTR [rax+0x0]
	...
  404800:	15 03 00 00 00       	adc    eax,0x3
  404805:	00 01                	add    BYTE PTR [rcx],al
  404807:	00 0e                	add    BYTE PTR [rsi],cl
  404809:	02 40 00             	add    al,BYTE PTR [rax+0x0]
	...
  404818:	22 03                	and    al,BYTE PTR [rbx]
  40481a:	00 00                	add    BYTE PTR [rax],al
  40481c:	00 00                	add    BYTE PTR [rax],al
  40481e:	01 00                	add    DWORD PTR [rax],eax
  404820:	33 02                	xor    eax,DWORD PTR [rdx]
  404822:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40482d:	00 00                	add    BYTE PTR [rax],al
  40482f:	00 30                	add    BYTE PTR [rax],dh
  404831:	03 00                	add    eax,DWORD PTR [rax]
  404833:	00 00                	add    BYTE PTR [rax],al
  404835:	00 01                	add    BYTE PTR [rcx],al
  404837:	00 42 02             	add    BYTE PTR [rdx+0x2],al
  40483a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404845:	00 00                	add    BYTE PTR [rax],al
  404847:	00 3e                	add    BYTE PTR [rsi],bh
  404849:	03 00                	add    eax,DWORD PTR [rax]
  40484b:	00 00                	add    BYTE PTR [rax],al
  40484d:	00 01                	add    BYTE PTR [rcx],al
  40484f:	00 53 02             	add    BYTE PTR [rbx+0x2],dl
  404852:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40485d:	00 00                	add    BYTE PTR [rax],al
  40485f:	00 4a 03             	add    BYTE PTR [rdx+0x3],cl
  404862:	00 00                	add    BYTE PTR [rax],al
  404864:	00 00                	add    BYTE PTR [rax],al
  404866:	01 00                	add    DWORD PTR [rax],eax
  404868:	46 02 40 00          	rex.RX add r8b,BYTE PTR [rax+0x0]
	...
  404878:	56                   	push   rsi
  404879:	03 00                	add    eax,DWORD PTR [rax]
  40487b:	00 00                	add    BYTE PTR [rax],al
  40487d:	00 01                	add    BYTE PTR [rcx],al
  40487f:	00 54 02 40          	add    BYTE PTR [rdx+rax*1+0x40],dl
	...
  40488f:	00 63 03             	add    BYTE PTR [rbx+0x3],ah
  404892:	00 00                	add    BYTE PTR [rax],al
  404894:	00 00                	add    BYTE PTR [rax],al
  404896:	01 00                	add    DWORD PTR [rax],eax
  404898:	76 02                	jbe    0x40489c
  40489a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4048a5:	00 00                	add    BYTE PTR [rax],al
  4048a7:	00 6f 03             	add    BYTE PTR [rdi+0x3],ch
  4048aa:	00 00                	add    BYTE PTR [rax],al
  4048ac:	00 00                	add    BYTE PTR [rax],al
  4048ae:	01 00                	add    DWORD PTR [rax],eax
  4048b0:	79 02                	jns    0x4048b4
  4048b2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4048bd:	00 00                	add    BYTE PTR [rax],al
  4048bf:	00 80 03 00 00 00    	add    BYTE PTR [rax+0x3],al
  4048c5:	00 01                	add    BYTE PTR [rcx],al
  4048c7:	00 d3                	add    bl,dl
  4048c9:	02 40 00             	add    al,BYTE PTR [rax+0x0]
	...
  4048d8:	8d 03                	lea    eax,[rbx]
  4048da:	00 00                	add    BYTE PTR [rax],al
  4048dc:	00 00                	add    BYTE PTR [rax],al
  4048de:	01 00                	add    DWORD PTR [rax],eax
  4048e0:	89 02                	mov    DWORD PTR [rdx],eax
  4048e2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4048ed:	00 00                	add    BYTE PTR [rax],al
  4048ef:	00 9a 03 00 00 00    	add    BYTE PTR [rdx+0x3],bl
  4048f5:	00 01                	add    BYTE PTR [rcx],al
  4048f7:	00 9c 02 40 00 00 00 	add    BYTE PTR [rdx+rax*1+0x40],bl
	...
  404906:	00 00                	add    BYTE PTR [rax],al
  404908:	a6                   	cmps   BYTE PTR ds:[rsi],BYTE PTR es:[rdi]
  404909:	03 00                	add    eax,DWORD PTR [rax]
  40490b:	00 00                	add    BYTE PTR [rax],al
  40490d:	00 01                	add    BYTE PTR [rcx],al
  40490f:	00 cd                	add    ch,cl
  404911:	02 40 00             	add    al,BYTE PTR [rax+0x0]
	...
  404920:	b2 03                	mov    dl,0x3
  404922:	00 00                	add    BYTE PTR [rax],al
  404924:	00 00                	add    BYTE PTR [rax],al
  404926:	01 00                	add    DWORD PTR [rax],eax
  404928:	d6                   	(bad)
  404929:	02 40 00             	add    al,BYTE PTR [rax+0x0]
	...
  404938:	c2 03 00             	ret    0x3
  40493b:	00 00                	add    BYTE PTR [rax],al
  40493d:	00 01                	add    BYTE PTR [rcx],al
  40493f:	00 1e                	add    BYTE PTR [rsi],bl
  404941:	03 40 00             	add    eax,DWORD PTR [rax+0x0]
	...
  404950:	cd 03                	int    0x3
  404952:	00 00                	add    BYTE PTR [rax],al
  404954:	00 00                	add    BYTE PTR [rax],al
  404956:	01 00                	add    DWORD PTR [rax],eax
  404958:	23 03                	and    eax,DWORD PTR [rbx]
  40495a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404965:	00 00                	add    BYTE PTR [rax],al
  404967:	00 d9                	add    cl,bl
  404969:	03 00                	add    eax,DWORD PTR [rax]
  40496b:	00 00                	add    BYTE PTR [rax],al
  40496d:	00 01                	add    BYTE PTR [rcx],al
  40496f:	00 27                	add    BYTE PTR [rdi],ah
  404971:	03 40 00             	add    eax,DWORD PTR [rax+0x0]
	...
  404980:	f0 03 00             	lock add eax,DWORD PTR [rax]
  404983:	00 00                	add    BYTE PTR [rax],al
  404985:	00 01                	add    BYTE PTR [rcx],al
  404987:	00 7e 05             	add    BYTE PTR [rsi+0x5],bh
  40498a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404995:	00 00                	add    BYTE PTR [rax],al
  404997:	00 fb                	add    bl,bh
  404999:	03 00                	add    eax,DWORD PTR [rax]
  40499b:	00 00                	add    BYTE PTR [rax],al
  40499d:	00 01                	add    BYTE PTR [rcx],al
  40499f:	00 91 05 40 00 00    	add    BYTE PTR [rcx+0x4005],dl
	...
  4049ad:	00 00                	add    BYTE PTR [rax],al
  4049af:	00 05 04 00 00 00    	add    BYTE PTR [rip+0x4],al        # 0x4049b9
  4049b5:	00 01                	add    BYTE PTR [rcx],al
  4049b7:	00 df                	add    bh,bl
  4049b9:	04 40                	add    al,0x40
	...
  4049c7:	00 10                	add    BYTE PTR [rax],dl
  4049c9:	04 00                	add    al,0x0
  4049cb:	00 00                	add    BYTE PTR [rax],al
  4049cd:	00 01                	add    BYTE PTR [rcx],al
  4049cf:	00 b1 03 40 00 00    	add    BYTE PTR [rcx+0x4003],dh
	...
  4049dd:	00 00                	add    BYTE PTR [rax],al
  4049df:	00 1d 04 00 00 00    	add    BYTE PTR [rip+0x4],bl        # 0x4049e9
  4049e5:	00 01                	add    BYTE PTR [rcx],al
  4049e7:	00 10                	add    BYTE PTR [rax],dl
  4049e9:	04 40                	add    al,0x40
	...
  4049f7:	00 2b                	add    BYTE PTR [rbx],ch
  4049f9:	04 00                	add    al,0x0
  4049fb:	00 00                	add    BYTE PTR [rax],al
  4049fd:	00 01                	add    BYTE PTR [rcx],al
  4049ff:	00 07                	add    BYTE PTR [rdi],al
  404a01:	04 40                	add    al,0x40
	...
  404a0f:	00 39                	add    BYTE PTR [rcx],bh
  404a11:	04 00                	add    al,0x0
  404a13:	00 00                	add    BYTE PTR [rax],al
  404a15:	00 01                	add    BYTE PTR [rcx],al
  404a17:	00 02                	add    BYTE PTR [rdx],al
  404a19:	04 40                	add    al,0x40
	...
  404a27:	00 4a 04             	add    BYTE PTR [rdx+0x4],cl
  404a2a:	00 00                	add    BYTE PTR [rax],al
  404a2c:	00 00                	add    BYTE PTR [rax],al
  404a2e:	01 00                	add    DWORD PTR [rax],eax
  404a30:	5a                   	pop    rdx
  404a31:	05 40 00 00 00       	add    eax,0x40
	...
  404a3e:	00 00                	add    BYTE PTR [rax],al
  404a40:	5b                   	pop    rbx
  404a41:	04 00                	add    al,0x0
  404a43:	00 00                	add    BYTE PTR [rax],al
  404a45:	00 01                	add    BYTE PTR [rcx],al
  404a47:	00 60 04             	add    BYTE PTR [rax+0x4],ah
  404a4a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404a55:	00 00                	add    BYTE PTR [rax],al
  404a57:	00 65 04             	add    BYTE PTR [rbp+0x4],ah
  404a5a:	00 00                	add    BYTE PTR [rax],al
  404a5c:	00 00                	add    BYTE PTR [rax],al
  404a5e:	01 00                	add    DWORD PTR [rax],eax
  404a60:	75 04                	jne    0x404a66
  404a62:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404a6d:	00 00                	add    BYTE PTR [rax],al
  404a6f:	00 74 04 00          	add    BYTE PTR [rsp+rax*1+0x0],dh
  404a73:	00 00                	add    BYTE PTR [rax],al
  404a75:	00 01                	add    BYTE PTR [rcx],al
  404a77:	00 8f 04 40 00 00    	add    BYTE PTR [rdi+0x4004],cl
	...
  404a85:	00 00                	add    BYTE PTR [rax],al
  404a87:	00 88 04 00 00 00    	add    BYTE PTR [rax+0x4],cl
  404a8d:	00 01                	add    BYTE PTR [rcx],al
  404a8f:	00 94 04 40 00 00 00 	add    BYTE PTR [rsp+rax*1+0x40],dl
	...
  404a9e:	00 00                	add    BYTE PTR [rax],al
  404aa0:	97                   	xchg   edi,eax
  404aa1:	04 00                	add    al,0x0
  404aa3:	00 00                	add    BYTE PTR [rax],al
  404aa5:	00 01                	add    BYTE PTR [rcx],al
  404aa7:	00 b8 04 40 00 00    	add    BYTE PTR [rax+0x4004],bh
	...
  404ab5:	00 00                	add    BYTE PTR [rax],al
  404ab7:	00 a6 04 00 00 00    	add    BYTE PTR [rsi+0x4],ah
  404abd:	00 01                	add    BYTE PTR [rcx],al
  404abf:	00 b3 04 40 00 00    	add    BYTE PTR [rbx+0x4004],dh
	...
  404acd:	00 00                	add    BYTE PTR [rax],al
  404acf:	00 bb 04 00 00 00    	add    BYTE PTR [rbx+0x4],bh
  404ad5:	00 01                	add    BYTE PTR [rcx],al
  404ad7:	00 08                	add    BYTE PTR [rax],cl
  404ad9:	05 40 00 00 00       	add    eax,0x40
	...
  404ae6:	00 00                	add    BYTE PTR [rax],al
  404ae8:	c7 04 00 00 00 00 01 	mov    DWORD PTR [rax+rax*1],0x1000000
  404aef:	00 56 05             	add    BYTE PTR [rsi+0x5],dl
  404af2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404afd:	00 00                	add    BYTE PTR [rax],al
  404aff:	00 d4                	add    ah,dl
  404b01:	04 00                	add    al,0x0
  404b03:	00 00                	add    BYTE PTR [rax],al
  404b05:	00 01                	add    BYTE PTR [rcx],al
  404b07:	00 51 05             	add    BYTE PTR [rcx+0x5],dl
  404b0a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404b15:	00 00                	add    BYTE PTR [rax],al
  404b17:	00 e3                	add    bl,ah
  404b19:	04 00                	add    al,0x0
  404b1b:	00 00                	add    BYTE PTR [rax],al
  404b1d:	00 01                	add    BYTE PTR [rcx],al
  404b1f:	00 96 05 40 00 00    	add    BYTE PTR [rsi+0x4005],dl
	...
  404b2d:	00 00                	add    BYTE PTR [rax],al
  404b2f:	00 ee                	add    dh,ch
  404b31:	04 00                	add    al,0x0
  404b33:	00 00                	add    BYTE PTR [rax],al
  404b35:	00 01                	add    BYTE PTR [rcx],al
  404b37:	00 41 06             	add    BYTE PTR [rcx+0x6],al
  404b3a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404b45:	00 00                	add    BYTE PTR [rax],al
  404b47:	00 f9                	add    cl,bh
  404b49:	04 00                	add    al,0x0
  404b4b:	00 00                	add    BYTE PTR [rax],al
  404b4d:	00 01                	add    BYTE PTR [rcx],al
  404b4f:	00 57 06             	add    BYTE PTR [rdi+0x6],dl
  404b52:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404b5d:	00 00                	add    BYTE PTR [rax],al
  404b5f:	00 03                	add    BYTE PTR [rbx],al
  404b61:	05 00 00 00 00       	add    eax,0x0
  404b66:	01 00                	add    DWORD PTR [rax],eax
  404b68:	15 06 40 00 00       	adc    eax,0x4006
	...
  404b75:	00 00                	add    BYTE PTR [rax],al
  404b77:	00 0e                	add    BYTE PTR [rsi],cl
  404b79:	05 00 00 00 00       	add    eax,0x0
  404b7e:	01 00                	add    DWORD PTR [rax],eax
  404b80:	3a 06                	cmp    al,BYTE PTR [rsi]
  404b82:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404b8d:	00 00                	add    BYTE PTR [rax],al
  404b8f:	00 17                	add    BYTE PTR [rdi],dl
  404b91:	05 00 00 00 00       	add    eax,0x0
  404b96:	01 00                	add    DWORD PTR [rax],eax
  404b98:	35 06 40 00 00       	xor    eax,0x4006
	...
  404ba5:	00 00                	add    BYTE PTR [rax],al
  404ba7:	00 22                	add    BYTE PTR [rdx],ah
  404ba9:	05 00 00 00 00       	add    eax,0x0
  404bae:	01 00                	add    DWORD PTR [rax],eax
  404bb0:	5e                   	pop    rsi
  404bb1:	06                   	(bad)
  404bb2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404bbd:	00 00                	add    BYTE PTR [rax],al
  404bbf:	00 2d 05 00 00 00    	add    BYTE PTR [rip+0x5],ch        # 0x404bca
  404bc5:	00 01                	add    BYTE PTR [rcx],al
  404bc7:	00 7b 06             	add    BYTE PTR [rbx+0x6],bh
  404bca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404bd5:	00 00                	add    BYTE PTR [rax],al
  404bd7:	00 37                	add    BYTE PTR [rdi],dh
  404bd9:	05 00 00 00 00       	add    eax,0x0
  404bde:	01 00                	add    DWORD PTR [rax],eax
  404be0:	91                   	xchg   ecx,eax
  404be1:	06                   	(bad)
  404be2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404bed:	00 00                	add    BYTE PTR [rax],al
  404bef:	00 42 05             	add    BYTE PTR [rdx+0x5],al
  404bf2:	00 00                	add    BYTE PTR [rax],al
  404bf4:	00 00                	add    BYTE PTR [rax],al
  404bf6:	01 00                	add    DWORD PTR [rax],eax
  404bf8:	71 07                	jno    0x404c01
  404bfa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c05:	00 00                	add    BYTE PTR [rax],al
  404c07:	00 4c 05 00          	add    BYTE PTR [rbp+rax*1+0x0],cl
  404c0b:	00 00                	add    BYTE PTR [rax],al
  404c0d:	00 01                	add    BYTE PTR [rcx],al
  404c0f:	00 f0                	add    al,dh
  404c11:	06                   	(bad)
  404c12:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c1d:	00 00                	add    BYTE PTR [rax],al
  404c1f:	00 56 05             	add    BYTE PTR [rsi+0x5],dl
  404c22:	00 00                	add    BYTE PTR [rax],al
  404c24:	00 00                	add    BYTE PTR [rax],al
  404c26:	01 00                	add    DWORD PTR [rax],eax
  404c28:	00 07                	add    BYTE PTR [rdi],al
  404c2a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c35:	00 00                	add    BYTE PTR [rax],al
  404c37:	00 61 05             	add    BYTE PTR [rcx+0x5],ah
  404c3a:	00 00                	add    BYTE PTR [rax],al
  404c3c:	00 00                	add    BYTE PTR [rax],al
  404c3e:	01 00                	add    DWORD PTR [rax],eax
  404c40:	5b                   	pop    rbx
  404c41:	07                   	(bad)
  404c42:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c4d:	00 00                	add    BYTE PTR [rax],al
  404c4f:	00 6c 05 00          	add    BYTE PTR [rbp+rax*1+0x0],ch
  404c53:	00 00                	add    BYTE PTR [rax],al
  404c55:	00 01                	add    BYTE PTR [rcx],al
  404c57:	00 2f                	add    BYTE PTR [rdi],ch
  404c59:	07                   	(bad)
  404c5a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c65:	00 00                	add    BYTE PTR [rax],al
  404c67:	00 77 05             	add    BYTE PTR [rdi+0x5],dh
  404c6a:	00 00                	add    BYTE PTR [rax],al
  404c6c:	00 00                	add    BYTE PTR [rax],al
  404c6e:	01 00                	add    DWORD PTR [rax],eax
  404c70:	54                   	push   rsp
  404c71:	07                   	(bad)
  404c72:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c7d:	00 00                	add    BYTE PTR [rax],al
  404c7f:	00 80 05 00 00 00    	add    BYTE PTR [rax+0x5],al
  404c85:	00 01                	add    BYTE PTR [rcx],al
  404c87:	00 4f 07             	add    BYTE PTR [rdi+0x7],cl
  404c8a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404c95:	00 00                	add    BYTE PTR [rax],al
  404c97:	00 8b 05 00 00 00    	add    BYTE PTR [rbx+0x5],cl
  404c9d:	00 01                	add    BYTE PTR [rcx],al
  404c9f:	00 78 07             	add    BYTE PTR [rax+0x7],bh
  404ca2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404cad:	00 00                	add    BYTE PTR [rax],al
  404caf:	00 96 05 00 00 00    	add    BYTE PTR [rsi+0x5],dl
  404cb5:	00 01                	add    BYTE PTR [rcx],al
  404cb7:	00 d2                	add    dl,dl
  404cb9:	07                   	(bad)
  404cba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404cc5:	00 00                	add    BYTE PTR [rax],al
  404cc7:	00 a1 05 00 00 00    	add    BYTE PTR [rcx+0x5],ah
  404ccd:	00 01                	add    BYTE PTR [rcx],al
  404ccf:	00 d9                	add    cl,bl
  404cd1:	07                   	(bad)
  404cd2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404cdd:	00 00                	add    BYTE PTR [rax],al
  404cdf:	00 ad 05 00 00 00    	add    BYTE PTR [rbp+0x5],ch
  404ce5:	00 01                	add    BYTE PTR [rcx],al
  404ce7:	00 e6                	add    dh,ah
  404ce9:	07                   	(bad)
  404cea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404cf5:	00 00                	add    BYTE PTR [rax],al
  404cf7:	00 ba 05 00 00 00    	add    BYTE PTR [rdx+0x5],bh
  404cfd:	00 01                	add    BYTE PTR [rcx],al
  404cff:	00 90 09 40 00 00    	add    BYTE PTR [rax+0x4009],dl
	...
  404d0d:	00 00                	add    BYTE PTR [rax],al
  404d0f:	00 c5                	add    ch,al
  404d11:	05 00 00 00 00       	add    eax,0x0
  404d16:	01 00                	add    DWORD PTR [rax],eax
  404d18:	d1 08                	ror    DWORD PTR [rax],1
  404d1a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404d25:	00 00                	add    BYTE PTR [rax],al
  404d27:	00 d1                	add    cl,dl
  404d29:	05 00 00 00 00       	add    eax,0x0
  404d2e:	01 00                	add    DWORD PTR [rax],eax
  404d30:	e8 08 40 00 00       	call   0x408d3d
	...
  404d3d:	00 00                	add    BYTE PTR [rax],al
  404d3f:	00 e0                	add    al,ah
  404d41:	05 00 00 00 00       	add    eax,0x0
  404d46:	01 00                	add    DWORD PTR [rax],eax
  404d48:	0d 09 40 00 00       	or     eax,0x4009
	...
  404d55:	00 00                	add    BYTE PTR [rax],al
  404d57:	00 eb                	add    bl,ch
  404d59:	05 00 00 00 00       	add    eax,0x0
  404d5e:	01 00                	add    DWORD PTR [rax],eax
  404d60:	51                   	push   rcx
  404d61:	09 40 00             	or     DWORD PTR [rax+0x0],eax
	...
  404d70:	f8                   	clc
  404d71:	05 00 00 00 00       	add    eax,0x0
  404d76:	01 00                	add    DWORD PTR [rax],eax
  404d78:	81 09 40 00 00 00    	or     DWORD PTR [rcx],0x40
	...
  404d86:	00 00                	add    BYTE PTR [rax],al
  404d88:	04 06                	add    al,0x6
  404d8a:	00 00                	add    BYTE PTR [rax],al
  404d8c:	00 00                	add    BYTE PTR [rax],al
  404d8e:	01 00                	add    DWORD PTR [rax],eax
  404d90:	37                   	(bad)
  404d91:	09 40 00             	or     DWORD PTR [rax+0x0],eax
	...
  404da0:	14 06                	adc    al,0x6
  404da2:	00 00                	add    BYTE PTR [rax],al
  404da4:	00 00                	add    BYTE PTR [rax],al
  404da6:	01 00                	add    DWORD PTR [rax],eax
  404da8:	95                   	xchg   ebp,eax
  404da9:	09 40 00             	or     DWORD PTR [rax+0x0],eax
	...
  404db8:	20 06                	and    BYTE PTR [rsi],al
  404dba:	00 00                	add    BYTE PTR [rax],al
  404dbc:	00 00                	add    BYTE PTR [rax],al
  404dbe:	01 00                	add    DWORD PTR [rax],eax
  404dc0:	b9 09 40 00 00       	mov    ecx,0x4009
	...
  404dcd:	00 00                	add    BYTE PTR [rax],al
  404dcf:	00 2e                	add    BYTE PTR [rsi],ch
  404dd1:	06                   	(bad)
  404dd2:	00 00                	add    BYTE PTR [rax],al
  404dd4:	00 00                	add    BYTE PTR [rax],al
  404dd6:	01 00                	add    DWORD PTR [rax],eax
  404dd8:	bb 09 40 00 00       	mov    ebx,0x4009
	...
  404de5:	00 00                	add    BYTE PTR [rax],al
  404de7:	00 39                	add    BYTE PTR [rcx],bh
  404de9:	06                   	(bad)
  404dea:	00 00                	add    BYTE PTR [rax],al
  404dec:	00 00                	add    BYTE PTR [rax],al
  404dee:	01 00                	add    DWORD PTR [rax],eax
  404df0:	d3 09                	ror    DWORD PTR [rcx],cl
  404df2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404dfd:	00 00                	add    BYTE PTR [rax],al
  404dff:	00 44 06 00          	add    BYTE PTR [rsi+rax*1+0x0],al
  404e03:	00 00                	add    BYTE PTR [rax],al
  404e05:	00 01                	add    BYTE PTR [rcx],al
  404e07:	00 d4                	add    ah,dl
  404e09:	09 40 00             	or     DWORD PTR [rax+0x0],eax
	...
  404e18:	55                   	push   rbp
  404e19:	06                   	(bad)
  404e1a:	00 00                	add    BYTE PTR [rax],al
  404e1c:	00 00                	add    BYTE PTR [rax],al
  404e1e:	01 00                	add    DWORD PTR [rax],eax
  404e20:	0d 0a 40 00 00       	or     eax,0x400a
	...
  404e2d:	00 00                	add    BYTE PTR [rax],al
  404e2f:	00 61 06             	add    BYTE PTR [rcx+0x6],ah
  404e32:	00 00                	add    BYTE PTR [rax],al
  404e34:	00 00                	add    BYTE PTR [rax],al
  404e36:	01 00                	add    DWORD PTR [rax],eax
  404e38:	e4 09                	in     al,0x9
  404e3a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404e45:	00 00                	add    BYTE PTR [rax],al
  404e47:	00 6d 06             	add    BYTE PTR [rbp+0x6],ch
  404e4a:	00 00                	add    BYTE PTR [rax],al
  404e4c:	00 00                	add    BYTE PTR [rax],al
  404e4e:	01 00                	add    DWORD PTR [rax],eax
  404e50:	10 0a                	adc    BYTE PTR [rdx],cl
  404e52:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404e5d:	00 00                	add    BYTE PTR [rax],al
  404e5f:	00 77 06             	add    BYTE PTR [rdi+0x6],dh
  404e62:	00 00                	add    BYTE PTR [rax],al
  404e64:	00 00                	add    BYTE PTR [rax],al
  404e66:	01 00                	add    DWORD PTR [rax],eax
  404e68:	2d 0a 40 00 00       	sub    eax,0x400a
	...
  404e75:	00 00                	add    BYTE PTR [rax],al
  404e77:	00 82 06 00 00 00    	add    BYTE PTR [rdx+0x6],al
  404e7d:	00 01                	add    BYTE PTR [rcx],al
  404e7f:	00 2a                	add    BYTE PTR [rdx],ch
  404e81:	0a 40 00             	or     al,BYTE PTR [rax+0x0]
	...
  404e90:	8d 06                	lea    eax,[rsi]
  404e92:	00 00                	add    BYTE PTR [rax],al
  404e94:	00 00                	add    BYTE PTR [rax],al
  404e96:	01 00                	add    DWORD PTR [rax],eax
  404e98:	30 0a                	xor    BYTE PTR [rdx],cl
  404e9a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404ea5:	00 00                	add    BYTE PTR [rax],al
  404ea7:	00 9b 06 00 00 00    	add    BYTE PTR [rbx+0x6],bl
  404ead:	00 01                	add    BYTE PTR [rcx],al
  404eaf:	00 52 0a             	add    BYTE PTR [rdx+0xa],dl
  404eb2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404ebd:	00 00                	add    BYTE PTR [rax],al
  404ebf:	00 a6 06 00 00 00    	add    BYTE PTR [rsi+0x6],ah
  404ec5:	00 01                	add    BYTE PTR [rcx],al
  404ec7:	00 7b 0a             	add    BYTE PTR [rbx+0xa],bh
  404eca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404ed5:	00 00                	add    BYTE PTR [rax],al
  404ed7:	00 b1 06 00 00 00    	add    BYTE PTR [rcx+0x6],dh
  404edd:	00 01                	add    BYTE PTR [rcx],al
  404edf:	00 77 0a             	add    BYTE PTR [rdi+0xa],dh
  404ee2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404eed:	00 00                	add    BYTE PTR [rax],al
  404eef:	00 bc 06 00 00 00 00 	add    BYTE PTR [rsi+rax*1+0x0],bh
  404ef6:	01 00                	add    DWORD PTR [rax],eax
  404ef8:	73 0a                	jae    0x404f04
  404efa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404f05:	00 00                	add    BYTE PTR [rax],al
  404f07:	00 c6                	add    dh,al
  404f09:	06                   	(bad)
  404f0a:	00 00                	add    BYTE PTR [rax],al
  404f0c:	00 00                	add    BYTE PTR [rax],al
  404f0e:	f1                   	int1
  404f0f:	ff 00                	inc    DWORD PTR [rax]
	...
  404f1d:	00 00                	add    BYTE PTR [rax],al
  404f1f:	00 ca                	add    dl,cl
  404f21:	06                   	(bad)
  404f22:	00 00                	add    BYTE PTR [rax],al
  404f24:	00 00                	add    BYTE PTR [rax],al
  404f26:	f1                   	int1
  404f27:	ff 04 00             	inc    DWORD PTR [rax+rax*1]
	...
  404f36:	00 00                	add    BYTE PTR [rax],al
  404f38:	cf                   	iret
  404f39:	06                   	(bad)
  404f3a:	00 00                	add    BYTE PTR [rax],al
  404f3c:	00 00                	add    BYTE PTR [rax],al
  404f3e:	f1                   	int1
  404f3f:	ff 08                	dec    DWORD PTR [rax]
	...
  404f4d:	00 00                	add    BYTE PTR [rax],al
  404f4f:	00 d4                	add    ah,dl
  404f51:	06                   	(bad)
  404f52:	00 00                	add    BYTE PTR [rax],al
  404f54:	00 00                	add    BYTE PTR [rax],al
  404f56:	f1                   	int1
  404f57:	ff 0c 00             	dec    DWORD PTR [rax+rax*1]
	...
  404f66:	00 00                	add    BYTE PTR [rax],al
  404f68:	d9 06                	fld    DWORD PTR [rsi]
  404f6a:	00 00                	add    BYTE PTR [rax],al
  404f6c:	00 00                	add    BYTE PTR [rax],al
  404f6e:	f1                   	int1
  404f6f:	ff 10                	call   QWORD PTR [rax]
	...
  404f7d:	00 00                	add    BYTE PTR [rax],al
  404f7f:	00 e1                	add    cl,ah
  404f81:	06                   	(bad)
  404f82:	00 00                	add    BYTE PTR [rax],al
  404f84:	00 00                	add    BYTE PTR [rax],al
  404f86:	f1                   	int1
  404f87:	ff 18                	call   FWORD PTR [rax]
	...
  404f95:	00 00                	add    BYTE PTR [rax],al
  404f97:	00 e8                	add    al,ch
  404f99:	06                   	(bad)
  404f9a:	00 00                	add    BYTE PTR [rax],al
  404f9c:	00 00                	add    BYTE PTR [rax],al
  404f9e:	f1                   	int1
  404f9f:	ff 28                	jmp    FWORD PTR [rax]
	...
  404fad:	00 00                	add    BYTE PTR [rax],al
  404faf:	00 ef                	add    bh,ch
  404fb1:	06                   	(bad)
  404fb2:	00 00                	add    BYTE PTR [rax],al
  404fb4:	00 00                	add    BYTE PTR [rax],al
  404fb6:	02 00                	add    al,BYTE PTR [rax]
  404fb8:	40                   	rex
  404fb9:	41                   	rex.B
  404fba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404fc5:	00 00                	add    BYTE PTR [rax],al
  404fc7:	00 ff                	add    bh,bh
  404fc9:	06                   	(bad)
  404fca:	00 00                	add    BYTE PTR [rax],al
  404fcc:	00 00                	add    BYTE PTR [rax],al
  404fce:	02 00                	add    al,BYTE PTR [rax]
  404fd0:	50                   	push   rax
  404fd1:	41                   	rex.B
  404fd2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404fdd:	00 00                	add    BYTE PTR [rax],al
  404fdf:	00 0d 07 00 00 00    	add    BYTE PTR [rip+0x7],cl        # 0x404fec
  404fe5:	00 02                	add    BYTE PTR [rdx],al
  404fe7:	00 60 41             	add    BYTE PTR [rax+0x41],ah
  404fea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  404ff5:	00 00                	add    BYTE PTR [rax],al
  404ff7:	00 1b                	add    BYTE PTR [rbx],bl
  404ff9:	07                   	(bad)
  404ffa:	00 00                	add    BYTE PTR [rax],al
  404ffc:	00 00                	add    BYTE PTR [rax],al
  404ffe:	02 00                	add    al,BYTE PTR [rax]
  405000:	70 41                	jo     0x405043
  405002:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40500d:	00 00                	add    BYTE PTR [rax],al
  40500f:	00 25 07 00 00 00    	add    BYTE PTR [rip+0x7],ah        # 0x40501c
  405015:	00 02                	add    BYTE PTR [rdx],al
  405017:	00 80 41 40 00 00    	add    BYTE PTR [rax+0x4041],al
	...
  405025:	00 00                	add    BYTE PTR [rax],al
  405027:	00 2f                	add    BYTE PTR [rdi],ch
  405029:	07                   	(bad)
  40502a:	00 00                	add    BYTE PTR [rax],al
  40502c:	00 00                	add    BYTE PTR [rax],al
  40502e:	02 00                	add    al,BYTE PTR [rax]
  405030:	90                   	nop
  405031:	41                   	rex.B
  405032:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40503d:	00 00                	add    BYTE PTR [rax],al
  40503f:	00 39                	add    BYTE PTR [rcx],bh
  405041:	07                   	(bad)
  405042:	00 00                	add    BYTE PTR [rax],al
  405044:	00 00                	add    BYTE PTR [rax],al
  405046:	02 00                	add    al,BYTE PTR [rax]
  405048:	a0 41 40 00 00 00 00 	movabs al,ds:0x4041
  40504f:	00 00 
  405051:	00 00                	add    BYTE PTR [rax],al
  405053:	00 00                	add    BYTE PTR [rax],al
  405055:	00 00                	add    BYTE PTR [rax],al
  405057:	00 43 07             	add    BYTE PTR [rbx+0x7],al
  40505a:	00 00                	add    BYTE PTR [rax],al
  40505c:	00 00                	add    BYTE PTR [rax],al
  40505e:	02 00                	add    al,BYTE PTR [rax]
  405060:	b0 41                	mov    al,0x41
  405062:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40506d:	00 00                	add    BYTE PTR [rax],al
  40506f:	00 52 07             	add    BYTE PTR [rdx+0x7],dl
  405072:	00 00                	add    BYTE PTR [rax],al
  405074:	00 00                	add    BYTE PTR [rax],al
  405076:	02 00                	add    al,BYTE PTR [rax]
  405078:	c0 41 40 00          	rol    BYTE PTR [rcx+0x40],0x0
	...
  405088:	61                   	(bad)
  405089:	07                   	(bad)
  40508a:	00 00                	add    BYTE PTR [rax],al
  40508c:	00 00                	add    BYTE PTR [rax],al
  40508e:	02 00                	add    al,BYTE PTR [rax]
  405090:	d0 41 40             	rol    BYTE PTR [rcx+0x40],1
	...
  40509f:	00 6d 07             	add    BYTE PTR [rbp+0x7],ch
  4050a2:	00 00                	add    BYTE PTR [rax],al
  4050a4:	00 00                	add    BYTE PTR [rax],al
  4050a6:	01 00                	add    DWORD PTR [rax],eax
  4050a8:	85 0a                	test   DWORD PTR [rdx],ecx
  4050aa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4050b5:	00 00                	add    BYTE PTR [rax],al
  4050b7:	00 7e 07             	add    BYTE PTR [rsi+0x7],bh
  4050ba:	00 00                	add    BYTE PTR [rax],al
  4050bc:	00 00                	add    BYTE PTR [rax],al
  4050be:	01 00                	add    DWORD PTR [rax],eax
  4050c0:	95                   	xchg   ebp,eax
  4050c1:	0a 40 00             	or     al,BYTE PTR [rax+0x0]
	...
  4050d0:	8c 07                	mov    WORD PTR [rdi],es
  4050d2:	00 00                	add    BYTE PTR [rax],al
  4050d4:	00 00                	add    BYTE PTR [rax],al
  4050d6:	01 00                	add    DWORD PTR [rax],eax
  4050d8:	98                   	cwde
  4050d9:	0a 40 00             	or     al,BYTE PTR [rax+0x0]
	...
  4050e8:	9f                   	lahf
  4050e9:	07                   	(bad)
  4050ea:	00 00                	add    BYTE PTR [rax],al
  4050ec:	00 00                	add    BYTE PTR [rax],al
  4050ee:	01 00                	add    DWORD PTR [rax],eax
  4050f0:	e9 0a 40 00 00       	jmp    0x4090ff
	...
  4050fd:	00 00                	add    BYTE PTR [rax],al
  4050ff:	00 af 07 00 00 00    	add    BYTE PTR [rdi+0x7],ch
  405105:	00 01                	add    BYTE PTR [rcx],al
  405107:	00 b0 0c 40 00 00    	add    BYTE PTR [rax+0x400c],dh
	...
  405115:	00 00                	add    BYTE PTR [rax],al
  405117:	00 c4                	add    ah,al
  405119:	07                   	(bad)
  40511a:	00 00                	add    BYTE PTR [rax],al
  40511c:	00 00                	add    BYTE PTR [rax],al
  40511e:	01 00                	add    DWORD PTR [rax],eax
  405120:	38 0b                	cmp    BYTE PTR [rbx],cl
  405122:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40512d:	00 00                	add    BYTE PTR [rax],al
  40512f:	00 d5                	add    ch,dl
  405131:	07                   	(bad)
  405132:	00 00                	add    BYTE PTR [rax],al
  405134:	00 00                	add    BYTE PTR [rax],al
  405136:	01 00                	add    DWORD PTR [rax],eax
  405138:	a9 0c 40 00 00       	test   eax,0x400c
	...
  405145:	00 00                	add    BYTE PTR [rax],al
  405147:	00 e5                	add    ch,ah
  405149:	07                   	(bad)
  40514a:	00 00                	add    BYTE PTR [rax],al
  40514c:	00 00                	add    BYTE PTR [rax],al
  40514e:	01 00                	add    DWORD PTR [rax],eax
  405150:	5b                   	pop    rbx
  405151:	0b 40 00             	or     eax,DWORD PTR [rax+0x0]
	...
  405160:	f6 07 00             	test   BYTE PTR [rdi],0x0
  405163:	00 00                	add    BYTE PTR [rax],al
  405165:	00 01                	add    BYTE PTR [rcx],al
  405167:	00 87 0c 40 00 00    	add    BYTE PTR [rdi+0x400c],al
	...
  405175:	00 00                	add    BYTE PTR [rax],al
  405177:	00 07                	add    BYTE PTR [rdi],al
  405179:	08 00                	or     BYTE PTR [rax],al
  40517b:	00 00                	add    BYTE PTR [rax],al
  40517d:	00 01                	add    BYTE PTR [rcx],al
  40517f:	00 65 0c             	add    BYTE PTR [rbp+0xc],ah
  405182:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40518d:	00 00                	add    BYTE PTR [rax],al
  40518f:	00 1f                	add    BYTE PTR [rdi],bl
  405191:	08 00                	or     BYTE PTR [rax],al
  405193:	00 00                	add    BYTE PTR [rax],al
  405195:	00 01                	add    BYTE PTR [rcx],al
  405197:	00 bb 0c 40 00 00    	add    BYTE PTR [rbx+0x400c],bh
	...
  4051a5:	00 00                	add    BYTE PTR [rax],al
  4051a7:	00 2c 08             	add    BYTE PTR [rax+rcx*1],ch
  4051aa:	00 00                	add    BYTE PTR [rax],al
  4051ac:	00 00                	add    BYTE PTR [rax],al
  4051ae:	01 00                	add    DWORD PTR [rax],eax
  4051b0:	c0 0c 40 00          	ror    BYTE PTR [rax+rax*2],0x0
	...
  4051c0:	3a 08                	cmp    cl,BYTE PTR [rax]
  4051c2:	00 00                	add    BYTE PTR [rax],al
  4051c4:	00 00                	add    BYTE PTR [rax],al
  4051c6:	01 00                	add    DWORD PTR [rax],eax
  4051c8:	cf                   	iret
  4051c9:	0c 40                	or     al,0x40
	...
  4051d7:	00 49 08             	add    BYTE PTR [rcx+0x8],cl
  4051da:	00 00                	add    BYTE PTR [rax],al
  4051dc:	00 00                	add    BYTE PTR [rax],al
  4051de:	01 00                	add    DWORD PTR [rax],eax
  4051e0:	fd                   	std
  4051e1:	0c 40                	or     al,0x40
	...
  4051ef:	00 5b 08             	add    BYTE PTR [rbx+0x8],bl
  4051f2:	00 00                	add    BYTE PTR [rax],al
  4051f4:	00 00                	add    BYTE PTR [rax],al
  4051f6:	01 00                	add    DWORD PTR [rax],eax
  4051f8:	25 0d 40 00 00       	and    eax,0x400d
	...
  405205:	00 00                	add    BYTE PTR [rax],al
  405207:	00 6a 08             	add    BYTE PTR [rdx+0x8],ch
  40520a:	00 00                	add    BYTE PTR [rax],al
  40520c:	00 00                	add    BYTE PTR [rax],al
  40520e:	01 00                	add    DWORD PTR [rax],eax
  405210:	8d 0d 40 00 00 00    	lea    ecx,[rip+0x40]        # 0x405256
	...
  40521e:	00 00                	add    BYTE PTR [rax],al
  405220:	79 08                	jns    0x40522a
  405222:	00 00                	add    BYTE PTR [rax],al
  405224:	00 00                	add    BYTE PTR [rax],al
  405226:	01 00                	add    DWORD PTR [rax],eax
  405228:	54                   	push   rsp
  405229:	0d 40 00 00 00       	or     eax,0x40
	...
  405236:	00 00                	add    BYTE PTR [rax],al
  405238:	8e 08                	mov    cs,WORD PTR [rax]
  40523a:	00 00                	add    BYTE PTR [rax],al
  40523c:	00 00                	add    BYTE PTR [rax],al
  40523e:	01 00                	add    DWORD PTR [rax],eax
  405240:	9c                   	pushf
  405241:	0d 40 00 00 00       	or     eax,0x40
	...
  40524e:	00 00                	add    BYTE PTR [rax],al
  405250:	9a                   	(bad)
  405251:	08 00                	or     BYTE PTR [rax],al
  405253:	00 00                	add    BYTE PTR [rax],al
  405255:	00 01                	add    BYTE PTR [rcx],al
  405257:	00 ba 0d 40 00 00    	add    BYTE PTR [rdx+0x400d],bh
	...
  405265:	00 00                	add    BYTE PTR [rax],al
  405267:	00 a8 08 00 00 00    	add    BYTE PTR [rax+0x8],ch
  40526d:	00 01                	add    BYTE PTR [rcx],al
  40526f:	00 99 0e 40 00 00    	add    BYTE PTR [rcx+0x400e],bl
	...
  40527d:	00 00                	add    BYTE PTR [rax],al
  40527f:	00 b6 08 00 00 00    	add    BYTE PTR [rsi+0x8],dh
  405285:	00 01                	add    BYTE PTR [rcx],al
  405287:	00 c6                	add    dh,al
  405289:	0d 40 00 00 00       	or     eax,0x40
	...
  405296:	00 00                	add    BYTE PTR [rax],al
  405298:	c3                   	ret
  405299:	08 00                	or     BYTE PTR [rax],al
  40529b:	00 00                	add    BYTE PTR [rax],al
  40529d:	00 01                	add    BYTE PTR [rcx],al
  40529f:	00 2e                	add    BYTE PTR [rsi],ch
  4052a1:	0e                   	(bad)
  4052a2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4052ad:	00 00                	add    BYTE PTR [rax],al
  4052af:	00 d3                	add    bl,dl
  4052b1:	08 00                	or     BYTE PTR [rax],al
  4052b3:	00 00                	add    BYTE PTR [rax],al
  4052b5:	00 01                	add    BYTE PTR [rcx],al
  4052b7:	00 91 0e 40 00 00    	add    BYTE PTR [rcx+0x400e],dl
	...
  4052c5:	00 00                	add    BYTE PTR [rax],al
  4052c7:	00 e1                	add    cl,ah
  4052c9:	08 00                	or     BYTE PTR [rax],al
  4052cb:	00 00                	add    BYTE PTR [rax],al
  4052cd:	00 01                	add    BYTE PTR [rcx],al
  4052cf:	00 a7 0e 40 00 00    	add    BYTE PTR [rdi+0x400e],ah
	...
  4052dd:	00 00                	add    BYTE PTR [rax],al
  4052df:	00 ed                	add    ch,ch
  4052e1:	08 00                	or     BYTE PTR [rax],al
  4052e3:	00 00                	add    BYTE PTR [rax],al
  4052e5:	00 01                	add    BYTE PTR [rcx],al
  4052e7:	00 c4                	add    ah,al
  4052e9:	0e                   	(bad)
  4052ea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4052f5:	00 00                	add    BYTE PTR [rax],al
  4052f7:	00 fb                	add    bl,bh
  4052f9:	08 00                	or     BYTE PTR [rax],al
  4052fb:	00 00                	add    BYTE PTR [rax],al
  4052fd:	00 01                	add    BYTE PTR [rcx],al
  4052ff:	00 a3 0f 40 00 00    	add    BYTE PTR [rbx+0x400f],ah
	...
  40530d:	00 00                	add    BYTE PTR [rax],al
  40530f:	00 09                	add    BYTE PTR [rcx],cl
  405311:	09 00                	or     DWORD PTR [rax],eax
  405313:	00 00                	add    BYTE PTR [rax],al
  405315:	00 01                	add    BYTE PTR [rcx],al
  405317:	00 d0                	add    al,dl
  405319:	0e                   	(bad)
  40531a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405325:	00 00                	add    BYTE PTR [rax],al
  405327:	00 16                	add    BYTE PTR [rsi],dl
  405329:	09 00                	or     DWORD PTR [rax],eax
  40532b:	00 00                	add    BYTE PTR [rax],al
  40532d:	00 01                	add    BYTE PTR [rcx],al
  40532f:	00 38                	add    BYTE PTR [rax],bh
  405331:	0f 40 00             	cmovo  eax,DWORD PTR [rax]
	...
  405340:	26 09 00             	es or  DWORD PTR [rax],eax
  405343:	00 00                	add    BYTE PTR [rax],al
  405345:	00 01                	add    BYTE PTR [rcx],al
  405347:	00 9b 0f 40 00 00    	add    BYTE PTR [rbx+0x400f],bl
	...
  405355:	00 00                	add    BYTE PTR [rax],al
  405357:	00 34 09             	add    BYTE PTR [rcx+rcx*1],dh
  40535a:	00 00                	add    BYTE PTR [rax],al
  40535c:	00 00                	add    BYTE PTR [rax],al
  40535e:	01 00                	add    DWORD PTR [rax],eax
  405360:	b1 0f                	mov    cl,0xf
  405362:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40536d:	00 00                	add    BYTE PTR [rax],al
  40536f:	00 40 09             	add    BYTE PTR [rax+0x9],al
  405372:	00 00                	add    BYTE PTR [rax],al
  405374:	00 00                	add    BYTE PTR [rax],al
  405376:	01 00                	add    DWORD PTR [rax],eax
  405378:	d9 0f                	(bad) [rdi]
  40537a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405385:	00 00                	add    BYTE PTR [rax],al
  405387:	00 4e 09             	add    BYTE PTR [rsi+0x9],cl
  40538a:	00 00                	add    BYTE PTR [rax],al
  40538c:	00 00                	add    BYTE PTR [rax],al
  40538e:	01 00                	add    DWORD PTR [rax],eax
  405390:	cc                   	int3
  405391:	10 40 00             	adc    BYTE PTR [rax+0x0],al
	...
  4053a0:	5c                   	pop    rsp
  4053a1:	09 00                	or     DWORD PTR [rax],eax
  4053a3:	00 00                	add    BYTE PTR [rax],al
  4053a5:	00 01                	add    BYTE PTR [rcx],al
  4053a7:	00 e5                	add    ch,ah
  4053a9:	0f 40 00             	cmovo  eax,DWORD PTR [rax]
	...
  4053b8:	67 09 00             	or     DWORD PTR [eax],eax
  4053bb:	00 00                	add    BYTE PTR [rax],al
  4053bd:	00 01                	add    BYTE PTR [rcx],al
  4053bf:	00 c4                	add    ah,al
  4053c1:	10 40 00             	adc    BYTE PTR [rax+0x0],al
	...
  4053d0:	75 09                	jne    0x4053db
  4053d2:	00 00                	add    BYTE PTR [rax],al
  4053d4:	00 00                	add    BYTE PTR [rax],al
  4053d6:	01 00                	add    DWORD PTR [rax],eax
  4053d8:	d7                   	xlat   BYTE PTR ds:[rbx]
  4053d9:	10 40 00             	adc    BYTE PTR [rax+0x0],al
	...
  4053e8:	81 09 00 00 00 00    	or     DWORD PTR [rcx],0x0
  4053ee:	01 00                	add    DWORD PTR [rax],eax
  4053f0:	f4                   	hlt
  4053f1:	10 40 00             	adc    BYTE PTR [rax+0x0],al
	...
  405400:	8f 09 00 00          	(bad)
  405404:	00 00                	add    BYTE PTR [rax],al
  405406:	01 00                	add    DWORD PTR [rax],eax
  405408:	e7 11                	out    0x11,eax
  40540a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405415:	00 00                	add    BYTE PTR [rax],al
  405417:	00 9d 09 00 00 00    	add    BYTE PTR [rbp+0x9],bl
  40541d:	00 01                	add    BYTE PTR [rcx],al
  40541f:	00 00                	add    BYTE PTR [rax],al
  405421:	11 40 00             	adc    DWORD PTR [rax+0x0],eax
	...
  405430:	a8 09                	test   al,0x9
  405432:	00 00                	add    BYTE PTR [rax],al
  405434:	00 00                	add    BYTE PTR [rax],al
  405436:	01 00                	add    DWORD PTR [rax],eax
  405438:	df 11                	fist   WORD PTR [rcx]
  40543a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405445:	00 00                	add    BYTE PTR [rax],al
  405447:	00 b6 09 00 00 00    	add    BYTE PTR [rsi+0x9],dh
  40544d:	00 01                	add    BYTE PTR [rcx],al
  40544f:	00 f2                	add    dl,dh
  405451:	11 40 00             	adc    DWORD PTR [rax+0x0],eax
	...
  405460:	c2 09 00             	ret    0x9
  405463:	00 00                	add    BYTE PTR [rax],al
  405465:	00 01                	add    BYTE PTR [rcx],al
  405467:	00 21                	add    BYTE PTR [rcx],ah
  405469:	12 40 00             	adc    al,BYTE PTR [rax+0x0]
	...
  405478:	d0 09                	ror    BYTE PTR [rcx],1
  40547a:	00 00                	add    BYTE PTR [rax],al
  40547c:	00 00                	add    BYTE PTR [rax],al
  40547e:	01 00                	add    DWORD PTR [rax],eax
  405480:	82                   	(bad)
  405481:	14 40                	adc    al,0x40
	...
  40548f:	00 de                	add    dh,bl
  405491:	09 00                	or     DWORD PTR [rax],eax
  405493:	00 00                	add    BYTE PTR [rax],al
  405495:	00 01                	add    BYTE PTR [rcx],al
  405497:	00 2d 12 40 00 00    	add    BYTE PTR [rip+0x4012],ch        # 0x4094af
	...
  4054a5:	00 00                	add    BYTE PTR [rax],al
  4054a7:	00 e9                	add    cl,ch
  4054a9:	09 00                	or     DWORD PTR [rax],eax
  4054ab:	00 00                	add    BYTE PTR [rax],al
  4054ad:	00 01                	add    BYTE PTR [rcx],al
  4054af:	00 7a 14             	add    BYTE PTR [rdx+0x14],bh
  4054b2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4054bd:	00 00                	add    BYTE PTR [rax],al
  4054bf:	00 f7                	add    bh,dh
  4054c1:	09 00                	or     DWORD PTR [rax],eax
  4054c3:	00 00                	add    BYTE PTR [rax],al
  4054c5:	00 01                	add    BYTE PTR [rcx],al
  4054c7:	00 94 14 40 00 00 00 	add    BYTE PTR [rsp+rdx*1+0x40],dl
	...
  4054d6:	00 00                	add    BYTE PTR [rax],al
  4054d8:	03 0a                	add    ecx,DWORD PTR [rdx]
  4054da:	00 00                	add    BYTE PTR [rax],al
  4054dc:	00 00                	add    BYTE PTR [rax],al
  4054de:	01 00                	add    DWORD PTR [rax],eax
  4054e0:	b8 14 40 00 00       	mov    eax,0x4014
	...
  4054ed:	00 00                	add    BYTE PTR [rax],al
  4054ef:	00 11                	add    BYTE PTR [rcx],dl
  4054f1:	0a 00                	or     al,BYTE PTR [rax]
  4054f3:	00 00                	add    BYTE PTR [rax],al
  4054f5:	00 01                	add    BYTE PTR [rcx],al
  4054f7:	00 eb                	add    bl,ch
  4054f9:	16                   	(bad)
  4054fa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405505:	00 00                	add    BYTE PTR [rax],al
  405507:	00 1f                	add    BYTE PTR [rdi],bl
  405509:	0a 00                	or     al,BYTE PTR [rax]
  40550b:	00 00                	add    BYTE PTR [rax],al
  40550d:	00 01                	add    BYTE PTR [rcx],al
  40550f:	00 c4                	add    ah,al
  405511:	14 40                	adc    al,0x40
	...
  40551f:	00 2a                	add    BYTE PTR [rdx],ch
  405521:	0a 00                	or     al,BYTE PTR [rax]
  405523:	00 00                	add    BYTE PTR [rax],al
  405525:	00 01                	add    BYTE PTR [rcx],al
  405527:	00 e3                	add    bl,ah
  405529:	16                   	(bad)
  40552a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405535:	00 00                	add    BYTE PTR [rax],al
  405537:	00 38                	add    BYTE PTR [rax],bh
  405539:	0a 00                	or     al,BYTE PTR [rax]
  40553b:	00 02                	add    BYTE PTR [rdx],al
  40553d:	00 01                	add    BYTE PTR [rcx],al
  40553f:	00 fd                	add    ch,bh
  405541:	16                   	(bad)
  405542:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40554d:	00 00                	add    BYTE PTR [rax],al
  40554f:	00 4c 0a 00          	add    BYTE PTR [rdx+rcx*1+0x0],cl
  405553:	00 00                	add    BYTE PTR [rax],al
  405555:	00 01                	add    BYTE PTR [rcx],al
  405557:	00 ad 17 40 00 00    	add    BYTE PTR [rbp+0x4017],ch
	...
  405565:	00 00                	add    BYTE PTR [rax],al
  405567:	00 61 0a             	add    BYTE PTR [rcx+0xa],ah
  40556a:	00 00                	add    BYTE PTR [rax],al
  40556c:	00 00                	add    BYTE PTR [rax],al
  40556e:	01 00                	add    DWORD PTR [rax],eax
  405570:	8a 17                	mov    dl,BYTE PTR [rdi]
  405572:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40557d:	00 00                	add    BYTE PTR [rax],al
  40557f:	00 70 0a             	add    BYTE PTR [rax+0xa],dh
  405582:	00 00                	add    BYTE PTR [rax],al
  405584:	00 00                	add    BYTE PTR [rax],al
  405586:	01 00                	add    DWORD PTR [rax],eax
  405588:	96                   	xchg   esi,eax
  405589:	17                   	(bad)
  40558a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405595:	00 00                	add    BYTE PTR [rax],al
  405597:	00 85 0a 00 00 00    	add    BYTE PTR [rbp+0xa],al
  40559d:	00 01                	add    BYTE PTR [rcx],al
  40559f:	00 9a 17 40 00 00    	add    BYTE PTR [rdx+0x4017],bl
	...
  4055ad:	00 00                	add    BYTE PTR [rax],al
  4055af:	00 94 0a 00 00 00 00 	add    BYTE PTR [rdx+rcx*1+0x0],dl
  4055b6:	01 00                	add    DWORD PTR [rax],eax
  4055b8:	a6                   	cmps   BYTE PTR ds:[rsi],BYTE PTR es:[rdi]
  4055b9:	17                   	(bad)
  4055ba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4055c5:	00 00                	add    BYTE PTR [rax],al
  4055c7:	00 ac 0a 00 00 00 00 	add    BYTE PTR [rdx+rcx*1+0x0],ch
  4055ce:	01 00                	add    DWORD PTR [rax],eax
  4055d0:	c3                   	ret
  4055d1:	17                   	(bad)
  4055d2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4055dd:	00 00                	add    BYTE PTR [rax],al
  4055df:	00 c0                	add    al,al
  4055e1:	0a 00                	or     al,BYTE PTR [rax]
  4055e3:	00 00                	add    BYTE PTR [rax],al
  4055e5:	00 01                	add    BYTE PTR [rcx],al
  4055e7:	00 f3                	add    bl,dh
  4055e9:	1b 40 00             	sbb    eax,DWORD PTR [rax+0x0]
	...
  4055f8:	cd 0a                	int    0xa
  4055fa:	00 00                	add    BYTE PTR [rax],al
  4055fc:	00 00                	add    BYTE PTR [rax],al
  4055fe:	01 00                	add    DWORD PTR [rax],eax
  405600:	3b 18                	cmp    ebx,DWORD PTR [rax]
  405602:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40560d:	00 00                	add    BYTE PTR [rax],al
  40560f:	00 dd                	add    ch,bl
  405611:	0a 00                	or     al,BYTE PTR [rax]
  405613:	00 00                	add    BYTE PTR [rax],al
  405615:	00 01                	add    BYTE PTR [rcx],al
  405617:	00 f0                	add    al,dh
  405619:	18 40 00             	sbb    BYTE PTR [rax+0x0],al
	...
  405628:	ee                   	out    dx,al
  405629:	0a 00                	or     al,BYTE PTR [rax]
  40562b:	00 00                	add    BYTE PTR [rax],al
  40562d:	00 01                	add    BYTE PTR [rcx],al
  40562f:	00 b3 18 40 00 00    	add    BYTE PTR [rbx+0x4018],dh
	...
  40563d:	00 00                	add    BYTE PTR [rax],al
  40563f:	00 03                	add    BYTE PTR [rbx],al
  405641:	0b 00                	or     eax,DWORD PTR [rax]
  405643:	00 00                	add    BYTE PTR [rax],al
  405645:	00 01                	add    BYTE PTR [rcx],al
  405647:	00 b8 18 40 00 00    	add    BYTE PTR [rax+0x4018],bh
	...
  405655:	00 00                	add    BYTE PTR [rax],al
  405657:	00 1b                	add    BYTE PTR [rbx],bl
  405659:	0b 00                	or     eax,DWORD PTR [rax]
  40565b:	00 00                	add    BYTE PTR [rax],al
  40565d:	00 01                	add    BYTE PTR [rcx],al
  40565f:	00 f7                	add    bh,dh
  405661:	18 40 00             	sbb    BYTE PTR [rax+0x0],al
	...
  405670:	27                   	(bad)
  405671:	0b 00                	or     eax,DWORD PTR [rax]
  405673:	00 00                	add    BYTE PTR [rax],al
  405675:	00 01                	add    BYTE PTR [rcx],al
  405677:	00 3d 19 40 00 00    	add    BYTE PTR [rip+0x4019],bh        # 0x409696
	...
  405685:	00 00                	add    BYTE PTR [rax],al
  405687:	00 39                	add    BYTE PTR [rcx],bh
  405689:	0b 00                	or     eax,DWORD PTR [rax]
  40568b:	00 00                	add    BYTE PTR [rax],al
  40568d:	00 01                	add    BYTE PTR [rcx],al
  40568f:	00 41 19             	add    BYTE PTR [rcx+0x19],al
  405692:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40569d:	00 00                	add    BYTE PTR [rax],al
  40569f:	00 45 0b             	add    BYTE PTR [rbp+0xb],al
  4056a2:	00 00                	add    BYTE PTR [rax],al
  4056a4:	00 00                	add    BYTE PTR [rax],al
  4056a6:	01 00                	add    DWORD PTR [rax],eax
  4056a8:	87 19                	xchg   DWORD PTR [rcx],ebx
  4056aa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4056b5:	00 00                	add    BYTE PTR [rax],al
  4056b7:	00 57 0b             	add    BYTE PTR [rdi+0xb],dl
  4056ba:	00 00                	add    BYTE PTR [rax],al
  4056bc:	00 00                	add    BYTE PTR [rax],al
  4056be:	01 00                	add    DWORD PTR [rax],eax
  4056c0:	8b 19                	mov    ebx,DWORD PTR [rcx]
  4056c2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4056cd:	00 00                	add    BYTE PTR [rax],al
  4056cf:	00 63 0b             	add    BYTE PTR [rbx+0xb],ah
  4056d2:	00 00                	add    BYTE PTR [rax],al
  4056d4:	00 00                	add    BYTE PTR [rax],al
  4056d6:	01 00                	add    DWORD PTR [rax],eax
  4056d8:	bd 19 40 00 00       	mov    ebp,0x4019
	...
  4056e5:	00 00                	add    BYTE PTR [rax],al
  4056e7:	00 73 0b             	add    BYTE PTR [rbx+0xb],dh
  4056ea:	00 00                	add    BYTE PTR [rax],al
  4056ec:	00 00                	add    BYTE PTR [rax],al
  4056ee:	01 00                	add    DWORD PTR [rax],eax
  4056f0:	c0 19 40             	rcr    BYTE PTR [rcx],0x40
	...
  4056ff:	00 83 0b 00 00 00    	add    BYTE PTR [rbx+0xb],al
  405705:	00 01                	add    BYTE PTR [rcx],al
  405707:	00 fe                	add    dh,bh
  405709:	19 40 00             	sbb    DWORD PTR [rax+0x0],eax
	...
  405718:	96                   	xchg   esi,eax
  405719:	0b 00                	or     eax,DWORD PTR [rax]
  40571b:	00 00                	add    BYTE PTR [rax],al
  40571d:	00 01                	add    BYTE PTR [rcx],al
  40571f:	00 37                	add    BYTE PTR [rdi],dh
  405721:	1a 40 00             	sbb    al,BYTE PTR [rax+0x0]
	...
  405730:	a7                   	cmps   DWORD PTR ds:[rsi],DWORD PTR es:[rdi]
  405731:	0b 00                	or     eax,DWORD PTR [rax]
  405733:	00 00                	add    BYTE PTR [rax],al
  405735:	00 01                	add    BYTE PTR [rcx],al
  405737:	00 42 1a             	add    BYTE PTR [rdx+0x1a],al
  40573a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405745:	00 00                	add    BYTE PTR [rax],al
  405747:	00 b3 0b 00 00 00    	add    BYTE PTR [rbx+0xb],dh
  40574d:	00 01                	add    BYTE PTR [rcx],al
  40574f:	00 73 1a             	add    BYTE PTR [rbx+0x1a],dh
  405752:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40575d:	00 00                	add    BYTE PTR [rax],al
  40575f:	00 c5                	add    ch,al
  405761:	0b 00                	or     eax,DWORD PTR [rax]
  405763:	00 00                	add    BYTE PTR [rax],al
  405765:	00 01                	add    BYTE PTR [rcx],al
  405767:	00 77 1a             	add    BYTE PTR [rdi+0x1a],dh
  40576a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405775:	00 00                	add    BYTE PTR [rax],al
  405777:	00 d1                	add    cl,dl
  405779:	0b 00                	or     eax,DWORD PTR [rax]
  40577b:	00 00                	add    BYTE PTR [rax],al
  40577d:	00 01                	add    BYTE PTR [rcx],al
  40577f:	00 aa 1a 40 00 00    	add    BYTE PTR [rdx+0x401a],ch
	...
  40578d:	00 00                	add    BYTE PTR [rax],al
  40578f:	00 e3                	add    bl,ah
  405791:	0b 00                	or     eax,DWORD PTR [rax]
  405793:	00 00                	add    BYTE PTR [rax],al
  405795:	00 01                	add    BYTE PTR [rcx],al
  405797:	00 ae 1a 40 00 00    	add    BYTE PTR [rsi+0x401a],ch
	...
  4057a5:	00 00                	add    BYTE PTR [rax],al
  4057a7:	00 ef                	add    bh,ch
  4057a9:	0b 00                	or     eax,DWORD PTR [rax]
  4057ab:	00 00                	add    BYTE PTR [rax],al
  4057ad:	00 01                	add    BYTE PTR [rcx],al
  4057af:	00 e1                	add    cl,ah
  4057b1:	1a 40 00             	sbb    al,BYTE PTR [rax+0x0]
	...
  4057c0:	fe 0b                	dec    BYTE PTR [rbx]
  4057c2:	00 00                	add    BYTE PTR [rax],al
  4057c4:	00 00                	add    BYTE PTR [rax],al
  4057c6:	01 00                	add    DWORD PTR [rax],eax
  4057c8:	1a 1b                	sbb    bl,BYTE PTR [rbx]
  4057ca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4057d5:	00 00                	add    BYTE PTR [rax],al
  4057d7:	00 12                	add    BYTE PTR [rdx],dl
  4057d9:	0c 00                	or     al,0x0
  4057db:	00 00                	add    BYTE PTR [rax],al
  4057dd:	00 01                	add    BYTE PTR [rcx],al
  4057df:	00 92 1b 40 00 00    	add    BYTE PTR [rdx+0x401b],dl
	...
  4057ed:	00 00                	add    BYTE PTR [rax],al
  4057ef:	00 26                	add    BYTE PTR [rsi],ah
  4057f1:	0c 00                	or     al,0x0
  4057f3:	00 00                	add    BYTE PTR [rax],al
  4057f5:	00 01                	add    BYTE PTR [rcx],al
  4057f7:	00 8d 1b 40 00 00    	add    BYTE PTR [rbp+0x401b],cl
	...
  405805:	00 00                	add    BYTE PTR [rax],al
  405807:	00 39                	add    BYTE PTR [rcx],bh
  405809:	0c 00                	or     al,0x0
  40580b:	00 00                	add    BYTE PTR [rax],al
  40580d:	00 01                	add    BYTE PTR [rcx],al
  40580f:	00 ea                	add    dl,ch
  405811:	1b 40 00             	sbb    eax,DWORD PTR [rax+0x0]
	...
  405820:	45 0c 00             	rex.RB or al,0x0
  405823:	00 00                	add    BYTE PTR [rax],al
  405825:	00 01                	add    BYTE PTR [rcx],al
  405827:	00 97 1b 40 00 00    	add    BYTE PTR [rdi+0x401b],dl
	...
  405835:	00 00                	add    BYTE PTR [rax],al
  405837:	00 58 0c             	add    BYTE PTR [rax+0xc],bl
  40583a:	00 00                	add    BYTE PTR [rax],al
  40583c:	00 00                	add    BYTE PTR [rax],al
  40583e:	01 00                	add    DWORD PTR [rax],eax
  405840:	e2 1b                	loop   0x40585d
  405842:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40584d:	00 00                	add    BYTE PTR [rax],al
  40584f:	00 6b 0c             	add    BYTE PTR [rbx+0xc],ch
  405852:	00 00                	add    BYTE PTR [rax],al
  405854:	00 00                	add    BYTE PTR [rax],al
  405856:	01 00                	add    DWORD PTR [rax],eax
  405858:	f5                   	cmc
  405859:	1b 40 00             	sbb    eax,DWORD PTR [rax+0x0]
	...
  405868:	79 0c                	jns    0x405876
  40586a:	00 00                	add    BYTE PTR [rax],al
  40586c:	00 00                	add    BYTE PTR [rax],al
  40586e:	01 00                	add    DWORD PTR [rax],eax
  405870:	bc 1c 40 00 00       	mov    esp,0x401c
	...
  40587d:	00 00                	add    BYTE PTR [rax],al
  40587f:	00 83 0c 00 00 00    	add    BYTE PTR [rbx+0xc],al
  405885:	00 01                	add    BYTE PTR [rcx],al
  405887:	00 c1                	add    cl,al
  405889:	1c 40                	sbb    al,0x40
	...
  405897:	00 8e 0c 00 00 00    	add    BYTE PTR [rsi+0xc],cl
  40589d:	00 01                	add    BYTE PTR [rcx],al
  40589f:	00 ca                	add    dl,cl
  4058a1:	21 40 00             	and    DWORD PTR [rax+0x0],eax
	...
  4058b0:	99                   	cdq
  4058b1:	0c 00                	or     al,0x0
  4058b3:	00 00                	add    BYTE PTR [rax],al
  4058b5:	00 01                	add    BYTE PTR [rcx],al
  4058b7:	00 00                	add    BYTE PTR [rax],al
  4058b9:	1e                   	(bad)
  4058ba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4058c5:	00 00                	add    BYTE PTR [rax],al
  4058c7:	00 a5 0c 00 00 00    	add    BYTE PTR [rbp+0xc],ah
  4058cd:	00 01                	add    BYTE PTR [rcx],al
  4058cf:	00 75 1e             	add    BYTE PTR [rbp+0x1e],dh
  4058d2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4058dd:	00 00                	add    BYTE PTR [rax],al
  4058df:	00 b3 0c 00 00 00    	add    BYTE PTR [rbx+0xc],dh
  4058e5:	00 01                	add    BYTE PTR [rcx],al
  4058e7:	00 57 1e             	add    BYTE PTR [rdi+0x1e],dl
  4058ea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4058f5:	00 00                	add    BYTE PTR [rax],al
  4058f7:	00 c3                	add    bl,al
  4058f9:	0c 00                	or     al,0x0
  4058fb:	00 00                	add    BYTE PTR [rax],al
  4058fd:	00 01                	add    BYTE PTR [rcx],al
  4058ff:	00 5b 1e             	add    BYTE PTR [rbx+0x1e],bl
  405902:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40590d:	00 00                	add    BYTE PTR [rax],al
  40590f:	00 cc                	add    ah,cl
  405911:	0c 00                	or     al,0x0
  405913:	00 00                	add    BYTE PTR [rax],al
  405915:	00 01                	add    BYTE PTR [rcx],al
  405917:	00 5b 1f             	add    BYTE PTR [rbx+0x1f],bl
  40591a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405925:	00 00                	add    BYTE PTR [rax],al
  405927:	00 d5                	add    ch,dl
  405929:	0c 00                	or     al,0x0
  40592b:	00 00                	add    BYTE PTR [rax],al
  40592d:	00 01                	add    BYTE PTR [rcx],al
  40592f:	00 24 21             	add    BYTE PTR [rcx+riz*1],ah
  405932:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40593d:	00 00                	add    BYTE PTR [rax],al
  40593f:	00 e6                	add    dh,ah
  405941:	0c 00                	or     al,0x0
  405943:	00 00                	add    BYTE PTR [rax],al
  405945:	00 01                	add    BYTE PTR [rcx],al
  405947:	00 ba 1f 40 00 00    	add    BYTE PTR [rdx+0x401f],bh
	...
  405955:	00 00                	add    BYTE PTR [rax],al
  405957:	00 f2                	add    dl,dh
  405959:	0c 00                	or     al,0x0
  40595b:	00 00                	add    BYTE PTR [rax],al
  40595d:	00 01                	add    BYTE PTR [rcx],al
  40595f:	00 2f                	add    BYTE PTR [rdi],ch
  405961:	20 40 00             	and    BYTE PTR [rax+0x0],al
	...
  405970:	02 0d 00 00 00 00    	add    cl,BYTE PTR [rip+0x0]        # 0x405976
  405976:	01 00                	add    DWORD PTR [rax],eax
  405978:	ce                   	(bad)
  405979:	1f                   	(bad)
  40597a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405985:	00 00                	add    BYTE PTR [rax],al
  405987:	00 10                	add    BYTE PTR [rax],dl
  405989:	0d 00 00 00 00       	or     eax,0x0
  40598e:	01 00                	add    DWORD PTR [rax],eax
  405990:	38 20                	cmp    BYTE PTR [rax],ah
  405992:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40599d:	00 00                	add    BYTE PTR [rax],al
  40599f:	00 20                	add    BYTE PTR [rax],ah
  4059a1:	0d 00 00 00 00       	or     eax,0x0
  4059a6:	01 00                	add    DWORD PTR [rax],eax
  4059a8:	87 20                	xchg   DWORD PTR [rax],esp
  4059aa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4059b5:	00 00                	add    BYTE PTR [rax],al
  4059b7:	00 2f                	add    BYTE PTR [rdi],ch
  4059b9:	0d 00 00 00 00       	or     eax,0x0
  4059be:	01 00                	add    DWORD PTR [rax],eax
  4059c0:	0f 21 40             	mov    rax,dr0
	...
  4059cf:	00 3e                	add    BYTE PTR [rsi],bh
  4059d1:	0d 00 00 00 00       	or     eax,0x0
  4059d6:	01 00                	add    DWORD PTR [rax],eax
  4059d8:	c4                   	(bad)
  4059d9:	20 40 00             	and    BYTE PTR [rax+0x0],al
	...
  4059e8:	4d 0d 00 00 00 00    	rex.WRB or rax,0x0
  4059ee:	01 00                	add    DWORD PTR [rax],eax
  4059f0:	fe                   	(bad)
  4059f1:	20 40 00             	and    BYTE PTR [rax+0x0],al
	...
  405a00:	5b                   	pop    rbx
  405a01:	0d 00 00 00 00       	or     eax,0x0
  405a06:	01 00                	add    DWORD PTR [rax],eax
  405a08:	2e 21 40 00          	cs and DWORD PTR [rax+0x0],eax
	...
  405a18:	6b 0d 00 00 00 00 01 	imul   ecx,DWORD PTR [rip+0x0],0x1        # 0x405a1f
  405a1f:	00 41 21             	add    BYTE PTR [rcx+0x21],al
  405a22:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405a2d:	00 00                	add    BYTE PTR [rax],al
  405a2f:	00 7b 0d             	add    BYTE PTR [rbx+0xd],bh
  405a32:	00 00                	add    BYTE PTR [rax],al
  405a34:	00 00                	add    BYTE PTR [rax],al
  405a36:	01 00                	add    DWORD PTR [rax],eax
  405a38:	93                   	xchg   ebx,eax
  405a39:	21 40 00             	and    DWORD PTR [rax+0x0],eax
	...
  405a48:	8c 0d 00 00 00 00    	mov    WORD PTR [rip+0x0],cs        # 0x405a4e
  405a4e:	01 00                	add    DWORD PTR [rax],eax
  405a50:	cf                   	iret
  405a51:	21 40 00             	and    DWORD PTR [rax+0x0],eax
	...
  405a60:	98                   	cwde
  405a61:	0d 00 00 00 00       	or     eax,0x0
  405a66:	01 00                	add    DWORD PTR [rax],eax
  405a68:	c3                   	ret
  405a69:	22 40 00             	and    al,BYTE PTR [rax+0x0]
	...
  405a78:	a4                   	movs   BYTE PTR es:[rdi],BYTE PTR ds:[rsi]
  405a79:	0d 00 00 00 00       	or     eax,0x0
  405a7e:	01 00                	add    DWORD PTR [rax],eax
  405a80:	4b 22 40 00          	rex.WXB and al,BYTE PTR [r8+0x0]
	...
  405a90:	b6 0d                	mov    dh,0xd
  405a92:	00 00                	add    BYTE PTR [rax],al
  405a94:	00 00                	add    BYTE PTR [rax],al
  405a96:	01 00                	add    DWORD PTR [rax],eax
  405a98:	b1 22                	mov    cl,0x22
  405a9a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405aa5:	00 00                	add    BYTE PTR [rax],al
  405aa7:	00 c1                	add    cl,al
  405aa9:	0d 00 00 00 00       	or     eax,0x0
  405aae:	01 00                	add    DWORD PTR [rax],eax
  405ab0:	b5 22                	mov    ch,0x22
  405ab2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405abd:	00 00                	add    BYTE PTR [rax],al
  405abf:	00 cc                	add    ah,cl
  405ac1:	0d 00 00 00 00       	or     eax,0x0
  405ac6:	01 00                	add    DWORD PTR [rax],eax
  405ac8:	bc 22 40 00 00       	mov    esp,0x4022
	...
  405ad5:	00 00                	add    BYTE PTR [rax],al
  405ad7:	00 d7                	add    bh,dl
  405ad9:	0d 00 00 00 00       	or     eax,0x0
  405ade:	01 00                	add    DWORD PTR [rax],eax
  405ae0:	5c                   	pop    rsp
  405ae1:	22 40 00             	and    al,BYTE PTR [rax+0x0]
	...
  405af0:	ec                   	in     al,dx
  405af1:	0d 00 00 00 00       	or     eax,0x0
  405af6:	01 00                	add    DWORD PTR [rax],eax
  405af8:	71 22                	jno    0x405b1c
  405afa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405b05:	00 00                	add    BYTE PTR [rax],al
  405b07:	00 fe                	add    dh,bh
  405b09:	0d 00 00 00 00       	or     eax,0x0
  405b0e:	01 00                	add    DWORD PTR [rax],eax
  405b10:	8f                   	(bad)
  405b11:	22 40 00             	and    al,BYTE PTR [rax+0x0]
	...
  405b20:	0a 0e                	or     cl,BYTE PTR [rsi]
  405b22:	00 00                	add    BYTE PTR [rax],al
  405b24:	00 00                	add    BYTE PTR [rax],al
  405b26:	01 00                	add    DWORD PTR [rax],eax
  405b28:	88 22                	mov    BYTE PTR [rdx],ah
  405b2a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405b35:	00 00                	add    BYTE PTR [rax],al
  405b37:	00 19                	add    BYTE PTR [rcx],bl
  405b39:	0e                   	(bad)
  405b3a:	00 00                	add    BYTE PTR [rax],al
  405b3c:	00 00                	add    BYTE PTR [rax],al
  405b3e:	01 00                	add    DWORD PTR [rax],eax
  405b40:	c5 22 40             	(bad)
	...
  405b4f:	00 26                	add    BYTE PTR [rsi],ah
  405b51:	0e                   	(bad)
  405b52:	00 00                	add    BYTE PTR [rax],al
  405b54:	00 00                	add    BYTE PTR [rax],al
  405b56:	01 00                	add    DWORD PTR [rax],eax
  405b58:	fc                   	cld
  405b59:	22 40 00             	and    al,BYTE PTR [rax+0x0]
	...
  405b68:	31 0e                	xor    DWORD PTR [rsi],ecx
  405b6a:	00 00                	add    BYTE PTR [rax],al
  405b6c:	00 00                	add    BYTE PTR [rax],al
  405b6e:	01 00                	add    DWORD PTR [rax],eax
  405b70:	25 23 40 00 00       	and    eax,0x4023
	...
  405b7d:	00 00                	add    BYTE PTR [rax],al
  405b7f:	00 3c 0e             	add    BYTE PTR [rsi+rcx*1],bh
  405b82:	00 00                	add    BYTE PTR [rax],al
  405b84:	00 00                	add    BYTE PTR [rax],al
  405b86:	01 00                	add    DWORD PTR [rax],eax
  405b88:	2d 23 40 00 00       	sub    eax,0x4023
	...
  405b95:	00 00                	add    BYTE PTR [rax],al
  405b97:	00 51 0e             	add    BYTE PTR [rcx+0xe],dl
  405b9a:	00 00                	add    BYTE PTR [rax],al
  405b9c:	00 00                	add    BYTE PTR [rax],al
  405b9e:	01 00                	add    DWORD PTR [rax],eax
  405ba0:	4c 23 40 00          	and    r8,QWORD PTR [rax+0x0]
	...
  405bb0:	5c                   	pop    rsp
  405bb1:	0e                   	(bad)
  405bb2:	00 00                	add    BYTE PTR [rax],al
  405bb4:	00 00                	add    BYTE PTR [rax],al
  405bb6:	01 00                	add    DWORD PTR [rax],eax
  405bb8:	4f 23 40 00          	rex.WRXB and r8,QWORD PTR [r8+0x0]
	...
  405bc8:	6a 0e                	push   0xe
  405bca:	00 00                	add    BYTE PTR [rax],al
  405bcc:	00 00                	add    BYTE PTR [rax],al
  405bce:	01 00                	add    DWORD PTR [rax],eax
  405bd0:	59                   	pop    rcx
  405bd1:	23 40 00             	and    eax,DWORD PTR [rax+0x0]
	...
  405be0:	78 0e                	js     0x405bf0
  405be2:	00 00                	add    BYTE PTR [rax],al
  405be4:	00 00                	add    BYTE PTR [rax],al
  405be6:	01 00                	add    DWORD PTR [rax],eax
  405be8:	9b                   	fwait
  405be9:	23 40 00             	and    eax,DWORD PTR [rax+0x0]
	...
  405bf8:	83 0e 00             	or     DWORD PTR [rsi],0x0
  405bfb:	00 00                	add    BYTE PTR [rax],al
  405bfd:	00 01                	add    BYTE PTR [rcx],al
  405bff:	00 a0 23 40 00 00    	add    BYTE PTR [rax+0x4023],ah
	...
  405c0d:	00 00                	add    BYTE PTR [rax],al
  405c0f:	00 8f 0e 00 00 00    	add    BYTE PTR [rdi+0xe],cl
  405c15:	00 01                	add    BYTE PTR [rcx],al
  405c17:	00 ad 23 40 00 00    	add    BYTE PTR [rbp+0x4023],ch
	...
  405c25:	00 00                	add    BYTE PTR [rax],al
  405c27:	00 a2 0e 00 00 00    	add    BYTE PTR [rdx+0xe],ah
  405c2d:	00 01                	add    BYTE PTR [rcx],al
  405c2f:	00 c6                	add    dh,al
  405c31:	23 40 00             	and    eax,DWORD PTR [rax+0x0]
	...
  405c40:	b2 0e                	mov    dl,0xe
  405c42:	00 00                	add    BYTE PTR [rax],al
  405c44:	00 00                	add    BYTE PTR [rax],al
  405c46:	01 00                	add    DWORD PTR [rax],eax
  405c48:	d2 26                	shl    BYTE PTR [rsi],cl
  405c4a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405c55:	00 00                	add    BYTE PTR [rax],al
  405c57:	00 bd 0e 00 00 00    	add    BYTE PTR [rbp+0xe],bh
  405c5d:	00 01                	add    BYTE PTR [rcx],al
  405c5f:	00 c2                	add    dl,al
  405c61:	26 40 00 00          	es rex add BYTE PTR [rax],al
	...
  405c6d:	00 00                	add    BYTE PTR [rax],al
  405c6f:	00 c9                	add    cl,cl
  405c71:	0e                   	(bad)
  405c72:	00 00                	add    BYTE PTR [rax],al
  405c74:	00 00                	add    BYTE PTR [rax],al
  405c76:	01 00                	add    DWORD PTR [rax],eax
  405c78:	89 24 40             	mov    DWORD PTR [rax+rax*2],esp
	...
  405c87:	00 d5                	add    ch,dl
  405c89:	0e                   	(bad)
  405c8a:	00 00                	add    BYTE PTR [rax],al
  405c8c:	00 00                	add    BYTE PTR [rax],al
  405c8e:	01 00                	add    DWORD PTR [rax],eax
  405c90:	91                   	xchg   ecx,eax
  405c91:	26 40 00 00          	es rex add BYTE PTR [rax],al
	...
  405c9d:	00 00                	add    BYTE PTR [rax],al
  405c9f:	00 e0                	add    al,ah
  405ca1:	0e                   	(bad)
  405ca2:	00 00                	add    BYTE PTR [rax],al
  405ca4:	00 00                	add    BYTE PTR [rax],al
  405ca6:	01 00                	add    DWORD PTR [rax],eax
  405ca8:	35 25 40 00 00       	xor    eax,0x4025
	...
  405cb5:	00 00                	add    BYTE PTR [rax],al
  405cb7:	00 f2                	add    dl,dh
  405cb9:	0e                   	(bad)
  405cba:	00 00                	add    BYTE PTR [rax],al
  405cbc:	00 00                	add    BYTE PTR [rax],al
  405cbe:	01 00                	add    DWORD PTR [rax],eax
  405cc0:	93                   	xchg   ebx,eax
  405cc1:	26 40 00 00          	es rex add BYTE PTR [rax],al
	...
  405ccd:	00 00                	add    BYTE PTR [rax],al
  405ccf:	00 02                	add    BYTE PTR [rdx],al
  405cd1:	0f 00 00             	sldt   WORD PTR [rax]
  405cd4:	00 00                	add    BYTE PTR [rax],al
  405cd6:	01 00                	add    DWORD PTR [rax],eax
  405cd8:	97                   	xchg   edi,eax
  405cd9:	25 40 00 00 00       	and    eax,0x40
	...
  405ce6:	00 00                	add    BYTE PTR [rax],al
  405ce8:	0f                   	(bad)
  405ce9:	0f 00 00             	sldt   WORD PTR [rax]
  405cec:	00 00                	add    BYTE PTR [rax],al
  405cee:	01 00                	add    DWORD PTR [rax],eax
  405cf0:	ab                   	stos   DWORD PTR es:[rdi],eax
  405cf1:	26 40 00 00          	es rex add BYTE PTR [rax],al
	...
  405cfd:	00 00                	add    BYTE PTR [rax],al
  405cff:	00 1c 0f             	add    BYTE PTR [rdi+rcx*1],bl
  405d02:	00 00                	add    BYTE PTR [rax],al
  405d04:	00 00                	add    BYTE PTR [rax],al
  405d06:	01 00                	add    DWORD PTR [rax],eax
  405d08:	d7                   	xlat   BYTE PTR ds:[rbx]
  405d09:	26 40 00 00          	es rex add BYTE PTR [rax],al
	...
  405d15:	00 00                	add    BYTE PTR [rax],al
  405d17:	00 28                	add    BYTE PTR [rax],ch
  405d19:	0f 00 00             	sldt   WORD PTR [rax]
  405d1c:	00 00                	add    BYTE PTR [rax],al
  405d1e:	01 00                	add    DWORD PTR [rax],eax
  405d20:	d6                   	(bad)
  405d21:	29 40 00             	sub    DWORD PTR [rax+0x0],eax
	...
  405d30:	33 0f                	xor    ecx,DWORD PTR [rdi]
  405d32:	00 00                	add    BYTE PTR [rax],al
  405d34:	00 00                	add    BYTE PTR [rax],al
  405d36:	01 00                	add    DWORD PTR [rax],eax
  405d38:	69 27 40 00 00 00    	imul   esp,DWORD PTR [rdi],0x40
	...
  405d46:	00 00                	add    BYTE PTR [rax],al
  405d48:	41 0f 00 00          	sldt   WORD PTR [r8]
  405d4c:	00 00                	add    BYTE PTR [rax],al
  405d4e:	01 00                	add    DWORD PTR [rax],eax
  405d50:	83 27 40             	and    DWORD PTR [rdi],0x40
	...
  405d5f:	00 50 0f             	add    BYTE PTR [rax+0xf],dl
  405d62:	00 00                	add    BYTE PTR [rax],al
  405d64:	00 00                	add    BYTE PTR [rax],al
  405d66:	01 00                	add    DWORD PTR [rax],eax
  405d68:	1a 28                	sbb    ch,BYTE PTR [rax]
  405d6a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405d75:	00 00                	add    BYTE PTR [rax],al
  405d77:	00 5e 0f             	add    BYTE PTR [rsi+0xf],bl
  405d7a:	00 00                	add    BYTE PTR [rax],al
  405d7c:	00 00                	add    BYTE PTR [rax],al
  405d7e:	01 00                	add    DWORD PTR [rax],eax
  405d80:	04 29                	add    al,0x29
  405d82:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405d8d:	00 00                	add    BYTE PTR [rax],al
  405d8f:	00 71 0f             	add    BYTE PTR [rcx+0xf],dh
  405d92:	00 00                	add    BYTE PTR [rax],al
  405d94:	00 00                	add    BYTE PTR [rax],al
  405d96:	01 00                	add    DWORD PTR [rax],eax
  405d98:	21 29                	and    DWORD PTR [rcx],ebp
  405d9a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405da5:	00 00                	add    BYTE PTR [rax],al
  405da7:	00 7f 0f             	add    BYTE PTR [rdi+0xf],bh
  405daa:	00 00                	add    BYTE PTR [rax],al
  405dac:	00 00                	add    BYTE PTR [rax],al
  405dae:	01 00                	add    DWORD PTR [rax],eax
  405db0:	69 29 40 00 00 00    	imul   ebp,DWORD PTR [rcx],0x40
	...
  405dbe:	00 00                	add    BYTE PTR [rax],al
  405dc0:	8b 0f                	mov    ecx,DWORD PTR [rdi]
  405dc2:	00 00                	add    BYTE PTR [rax],al
  405dc4:	00 00                	add    BYTE PTR [rax],al
  405dc6:	01 00                	add    DWORD PTR [rax],eax
  405dc8:	d2 29                	shr    BYTE PTR [rcx],cl
  405dca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405dd5:	00 00                	add    BYTE PTR [rax],al
  405dd7:	00 95 0f 00 00 00    	add    BYTE PTR [rbp+0xf],dl
  405ddd:	00 01                	add    BYTE PTR [rcx],al
  405ddf:	00 db                	add    bl,bl
  405de1:	29 40 00             	sub    DWORD PTR [rax+0x0],eax
	...
  405df0:	a1 0f 00 00 00 00 01 	movabs eax,ds:0x6b0001000000000f
  405df7:	00 6b 
  405df9:	2d 40 00 00 00       	sub    eax,0x40
	...
  405e06:	00 00                	add    BYTE PTR [rax],al
  405e08:	ac                   	lods   al,BYTE PTR ds:[rsi]
  405e09:	0f 00 00             	sldt   WORD PTR [rax]
  405e0c:	00 00                	add    BYTE PTR [rax],al
  405e0e:	01 00                	add    DWORD PTR [rax],eax
  405e10:	97                   	xchg   edi,eax
  405e11:	2a 40 00             	sub    al,BYTE PTR [rax+0x0]
	...
  405e20:	bc 0f 00 00 00       	mov    esp,0xf
  405e25:	00 01                	add    BYTE PTR [rcx],al
  405e27:	00 ad 2a 40 00 00    	add    BYTE PTR [rbp+0x402a],ch
	...
  405e35:	00 00                	add    BYTE PTR [rax],al
  405e37:	00 cb                	add    bl,cl
  405e39:	0f 00 00             	sldt   WORD PTR [rax]
  405e3c:	00 00                	add    BYTE PTR [rax],al
  405e3e:	01 00                	add    DWORD PTR [rax],eax
  405e40:	f6 2a                	imul   BYTE PTR [rdx]
  405e42:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405e4d:	00 00                	add    BYTE PTR [rax],al
  405e4f:	00 e0                	add    al,ah
  405e51:	0f 00 00             	sldt   WORD PTR [rax]
  405e54:	00 00                	add    BYTE PTR [rax],al
  405e56:	01 00                	add    DWORD PTR [rax],eax
  405e58:	2b 2c 40             	sub    ebp,DWORD PTR [rax+rax*2]
	...
  405e67:	00 ee                	add    dh,ch
  405e69:	0f 00 00             	sldt   WORD PTR [rax]
  405e6c:	00 00                	add    BYTE PTR [rax],al
  405e6e:	01 00                	add    DWORD PTR [rax],eax
  405e70:	3a 2d 40 00 00 00    	cmp    ch,BYTE PTR [rip+0x40]        # 0x405eb6
	...
  405e7e:	00 00                	add    BYTE PTR [rax],al
  405e80:	01 10                	add    DWORD PTR [rax],edx
  405e82:	00 00                	add    BYTE PTR [rax],al
  405e84:	00 00                	add    BYTE PTR [rax],al
  405e86:	01 00                	add    DWORD PTR [rax],eax
  405e88:	67 2d 40 00 00 00    	addr32 sub eax,0x40
	...
  405e96:	00 00                	add    BYTE PTR [rax],al
  405e98:	0b 10                	or     edx,DWORD PTR [rax]
  405e9a:	00 00                	add    BYTE PTR [rax],al
  405e9c:	00 00                	add    BYTE PTR [rax],al
  405e9e:	01 00                	add    DWORD PTR [rax],eax
  405ea0:	70 2d                	jo     0x405ecf
  405ea2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405ead:	00 00                	add    BYTE PTR [rax],al
  405eaf:	00 17                	add    BYTE PTR [rdi],dl
  405eb1:	10 00                	adc    BYTE PTR [rax],al
  405eb3:	00 00                	add    BYTE PTR [rax],al
  405eb5:	00 01                	add    BYTE PTR [rcx],al
  405eb7:	00 81 2d 40 00 00    	add    BYTE PTR [rcx+0x402d],al
	...
  405ec5:	00 00                	add    BYTE PTR [rax],al
  405ec7:	00 27                	add    BYTE PTR [rdi],ah
  405ec9:	10 00                	adc    BYTE PTR [rax],al
  405ecb:	00 00                	add    BYTE PTR [rax],al
  405ecd:	00 01                	add    BYTE PTR [rcx],al
  405ecf:	00 ce                	add    dh,cl
  405ed1:	32 40 00             	xor    al,BYTE PTR [rax+0x0]
	...
  405ee0:	32 10                	xor    dl,BYTE PTR [rax]
  405ee2:	00 00                	add    BYTE PTR [rax],al
  405ee4:	00 00                	add    BYTE PTR [rax],al
  405ee6:	01 00                	add    DWORD PTR [rax],eax
  405ee8:	f4                   	hlt
  405ee9:	2d 40 00 00 00       	sub    eax,0x40
	...
  405ef6:	00 00                	add    BYTE PTR [rax],al
  405ef8:	40 10 00             	rex adc BYTE PTR [rax],al
  405efb:	00 00                	add    BYTE PTR [rax],al
  405efd:	00 01                	add    BYTE PTR [rcx],al
  405eff:	00 13                	add    BYTE PTR [rbx],dl
  405f01:	2e 40 00 00          	cs rex add BYTE PTR [rax],al
	...
  405f0d:	00 00                	add    BYTE PTR [rax],al
  405f0f:	00 4f 10             	add    BYTE PTR [rdi+0x10],cl
  405f12:	00 00                	add    BYTE PTR [rax],al
  405f14:	00 00                	add    BYTE PTR [rax],al
  405f16:	01 00                	add    DWORD PTR [rax],eax
  405f18:	b0 2f                	mov    al,0x2f
  405f1a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405f25:	00 00                	add    BYTE PTR [rax],al
  405f27:	00 5d 10             	add    BYTE PTR [rbp+0x10],bl
  405f2a:	00 00                	add    BYTE PTR [rax],al
  405f2c:	00 00                	add    BYTE PTR [rax],al
  405f2e:	01 00                	add    DWORD PTR [rax],eax
  405f30:	be 31 40 00 00       	mov    esi,0x4031
	...
  405f3d:	00 00                	add    BYTE PTR [rax],al
  405f3f:	00 70 10             	add    BYTE PTR [rax+0x10],dh
  405f42:	00 00                	add    BYTE PTR [rax],al
  405f44:	00 00                	add    BYTE PTR [rax],al
  405f46:	01 00                	add    DWORD PTR [rax],eax
  405f48:	c3                   	ret
  405f49:	31 40 00             	xor    DWORD PTR [rax+0x0],eax
	...
  405f58:	7e 10                	jle    0x405f6a
  405f5a:	00 00                	add    BYTE PTR [rax],al
  405f5c:	00 00                	add    BYTE PTR [rax],al
  405f5e:	01 00                	add    DWORD PTR [rax],eax
  405f60:	97                   	xchg   edi,eax
  405f61:	32 40 00             	xor    al,BYTE PTR [rax+0x0]
	...
  405f70:	8c 10                	mov    WORD PTR [rax],ss
  405f72:	00 00                	add    BYTE PTR [rax],al
  405f74:	00 00                	add    BYTE PTR [rax],al
  405f76:	01 00                	add    DWORD PTR [rax],eax
  405f78:	b6 32                	mov    dh,0x32
  405f7a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405f85:	00 00                	add    BYTE PTR [rax],al
  405f87:	00 9b 10 00 00 00    	add    BYTE PTR [rbx+0x10],bl
  405f8d:	00 01                	add    BYTE PTR [rcx],al
  405f8f:	00 d3                	add    bl,dl
  405f91:	32 40 00             	xor    al,BYTE PTR [rax+0x0]
	...
  405fa0:	a7                   	cmps   DWORD PTR ds:[rsi],DWORD PTR es:[rdi]
  405fa1:	10 00                	adc    BYTE PTR [rax],al
  405fa3:	00 00                	add    BYTE PTR [rax],al
  405fa5:	00 01                	add    BYTE PTR [rcx],al
  405fa7:	00 01                	add    BYTE PTR [rcx],al
  405fa9:	34 40                	xor    al,0x40
	...
  405fb7:	00 b3 10 00 00 00    	add    BYTE PTR [rbx+0x10],dh
  405fbd:	00 01                	add    BYTE PTR [rcx],al
  405fbf:	00 19                	add    BYTE PTR [rcx],bl
  405fc1:	34 40                	xor    al,0x40
	...
  405fcf:	00 be 10 00 00 00    	add    BYTE PTR [rsi+0x10],bh
  405fd5:	00 01                	add    BYTE PTR [rcx],al
  405fd7:	00 07                	add    BYTE PTR [rdi],al
  405fd9:	34 40                	xor    al,0x40
	...
  405fe7:	00 cd                	add    ch,cl
  405fe9:	10 00                	adc    BYTE PTR [rax],al
  405feb:	00 00                	add    BYTE PTR [rax],al
  405fed:	00 01                	add    BYTE PTR [rcx],al
  405fef:	00 57 33             	add    BYTE PTR [rdi+0x33],dl
  405ff2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  405ffd:	00 00                	add    BYTE PTR [rax],al
  405fff:	00 d9                	add    cl,bl
  406001:	10 00                	adc    BYTE PTR [rax],al
  406003:	00 00                	add    BYTE PTR [rax],al
  406005:	00 01                	add    BYTE PTR [rcx],al
  406007:	00 7a 33             	add    BYTE PTR [rdx+0x33],bh
  40600a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406015:	00 00                	add    BYTE PTR [rax],al
  406017:	00 e6                	add    dh,ah
  406019:	10 00                	adc    BYTE PTR [rax],al
  40601b:	00 00                	add    BYTE PTR [rax],al
  40601d:	00 01                	add    BYTE PTR [rcx],al
  40601f:	00 76 33             	add    BYTE PTR [rsi+0x33],dh
  406022:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40602d:	00 00                	add    BYTE PTR [rax],al
  40602f:	00 f2                	add    dl,dh
  406031:	10 00                	adc    BYTE PTR [rax],al
  406033:	00 00                	add    BYTE PTR [rax],al
  406035:	00 01                	add    BYTE PTR [rcx],al
  406037:	00 d0                	add    al,dl
  406039:	33 40 00             	xor    eax,DWORD PTR [rax+0x0]
	...
  406048:	fe                   	(bad)
  406049:	10 00                	adc    BYTE PTR [rax],al
  40604b:	00 00                	add    BYTE PTR [rax],al
  40604d:	00 01                	add    BYTE PTR [rcx],al
  40604f:	00 b7 33 40 00 00    	add    BYTE PTR [rdi+0x4033],dh
	...
  40605d:	00 00                	add    BYTE PTR [rax],al
  40605f:	00 09                	add    BYTE PTR [rcx],cl
  406061:	11 00                	adc    DWORD PTR [rax],eax
  406063:	00 00                	add    BYTE PTR [rax],al
  406065:	00 01                	add    BYTE PTR [rcx],al
  406067:	00 31                	add    BYTE PTR [rcx],dh
  406069:	34 40                	xor    al,0x40
	...
  406077:	00 15 11 00 00 00    	add    BYTE PTR [rip+0x11],dl        # 0x40608e
  40607d:	00 01                	add    BYTE PTR [rcx],al
  40607f:	00 8a 34 40 00 00    	add    BYTE PTR [rdx+0x4034],cl
	...
  40608d:	00 00                	add    BYTE PTR [rax],al
  40608f:	00 22                	add    BYTE PTR [rdx],ah
  406091:	11 00                	adc    DWORD PTR [rax],eax
  406093:	00 00                	add    BYTE PTR [rax],al
  406095:	00 01                	add    BYTE PTR [rcx],al
  406097:	00 81 37 40 00 00    	add    BYTE PTR [rcx+0x4037],al
	...
  4060a5:	00 00                	add    BYTE PTR [rax],al
  4060a7:	00 2e                	add    BYTE PTR [rsi],ch
  4060a9:	11 00                	adc    DWORD PTR [rax],eax
  4060ab:	00 00                	add    BYTE PTR [rax],al
  4060ad:	00 02                	add    BYTE PTR [rdx],al
  4060af:	00 28                	add    BYTE PTR [rax],ch
  4060b1:	40                   	rex
  4060b2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4060bd:	00 00                	add    BYTE PTR [rax],al
  4060bf:	00 3f                	add    BYTE PTR [rdi],bh
  4060c1:	11 00                	adc    DWORD PTR [rax],eax
  4060c3:	00 00                	add    BYTE PTR [rax],al
  4060c5:	00 02                	add    BYTE PTR [rdx],al
  4060c7:	00 30                	add    BYTE PTR [rax],dh
  4060c9:	40                   	rex
  4060ca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4060d5:	00 00                	add    BYTE PTR [rax],al
  4060d7:	00 4e 11             	add    BYTE PTR [rsi+0x11],cl
  4060da:	00 00                	add    BYTE PTR [rax],al
  4060dc:	00 00                	add    BYTE PTR [rax],al
  4060de:	02 00                	add    al,BYTE PTR [rax]
  4060e0:	38 40 40             	cmp    BYTE PTR [rax+0x40],al
	...
  4060ef:	00 5e 11             	add    BYTE PTR [rsi+0x11],bl
  4060f2:	00 00                	add    BYTE PTR [rax],al
  4060f4:	00 00                	add    BYTE PTR [rax],al
  4060f6:	01 00                	add    DWORD PTR [rax],eax
  4060f8:	52                   	push   rdx
  4060f9:	35 40 00 00 00       	xor    eax,0x40
	...
  406106:	00 00                	add    BYTE PTR [rax],al
  406108:	6d                   	ins    DWORD PTR es:[rdi],dx
  406109:	11 00                	adc    DWORD PTR [rax],eax
  40610b:	00 00                	add    BYTE PTR [rax],al
  40610d:	00 02                	add    BYTE PTR [rdx],al
  40610f:	00 d8                	add    al,bl
  406111:	41                   	rex.B
  406112:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40611d:	00 00                	add    BYTE PTR [rax],al
  40611f:	00 7b 11             	add    BYTE PTR [rbx+0x11],bh
  406122:	00 00                	add    BYTE PTR [rax],al
  406124:	00 00                	add    BYTE PTR [rax],al
  406126:	01 00                	add    DWORD PTR [rax],eax
  406128:	43 35 40 00 00 00    	rex.XB xor eax,0x40
	...
  406136:	00 00                	add    BYTE PTR [rax],al
  406138:	8d 11                	lea    edx,[rcx]
  40613a:	00 00                	add    BYTE PTR [rax],al
  40613c:	00 00                	add    BYTE PTR [rax],al
  40613e:	01 00                	add    DWORD PTR [rax],eax
  406140:	43 35 40 00 00 00    	rex.XB xor eax,0x40
	...
  40614e:	00 00                	add    BYTE PTR [rax],al
  406150:	a6                   	cmps   BYTE PTR ds:[rsi],BYTE PTR es:[rdi]
  406151:	11 00                	adc    DWORD PTR [rax],eax
  406153:	00 00                	add    BYTE PTR [rax],al
  406155:	00 01                	add    BYTE PTR [rcx],al
  406157:	00 8d 37 40 00 00    	add    BYTE PTR [rbp+0x4037],cl
	...
  406165:	00 00                	add    BYTE PTR [rax],al
  406167:	00 b0 11 00 00 00    	add    BYTE PTR [rax+0x11],dh
  40616d:	00 02                	add    BYTE PTR [rdx],al
  40616f:	00 60 40             	add    BYTE PTR [rax+0x40],ah
  406172:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40617d:	00 00                	add    BYTE PTR [rax],al
  40617f:	00 c3                	add    bl,al
  406181:	11 00                	adc    DWORD PTR [rax],eax
  406183:	00 00                	add    BYTE PTR [rax],al
  406185:	00 01                	add    BYTE PTR [rcx],al
  406187:	00 8a 35 40 00 00    	add    BYTE PTR [rdx+0x4035],cl
	...
  406195:	00 00                	add    BYTE PTR [rax],al
  406197:	00 d1                	add    cl,dl
  406199:	11 00                	adc    DWORD PTR [rax],eax
  40619b:	00 00                	add    BYTE PTR [rax],al
  40619d:	00 01                	add    BYTE PTR [rcx],al
  40619f:	00 7d 36             	add    BYTE PTR [rbp+0x36],bh
  4061a2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4061ad:	00 00                	add    BYTE PTR [rax],al
  4061af:	00 d6                	add    dh,dl
  4061b1:	11 00                	adc    DWORD PTR [rax],eax
  4061b3:	00 00                	add    BYTE PTR [rax],al
  4061b5:	00 01                	add    BYTE PTR [rcx],al
  4061b7:	00 d5                	add    ch,dl
  4061b9:	35 40 00 00 00       	xor    eax,0x40
	...
  4061c6:	00 00                	add    BYTE PTR [rax],al
  4061c8:	df 11                	fist   WORD PTR [rcx]
  4061ca:	00 00                	add    BYTE PTR [rax],al
  4061cc:	00 00                	add    BYTE PTR [rax],al
  4061ce:	01 00                	add    DWORD PTR [rax],eax
  4061d0:	ec                   	in     al,dx
  4061d1:	35 40 00 00 00       	xor    eax,0x40
	...
  4061de:	00 00                	add    BYTE PTR [rax],al
  4061e0:	e7 11                	out    0x11,eax
  4061e2:	00 00                	add    BYTE PTR [rax],al
  4061e4:	00 00                	add    BYTE PTR [rax],al
  4061e6:	01 00                	add    DWORD PTR [rax],eax
  4061e8:	00 36                	add    BYTE PTR [rsi],dh
  4061ea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4061f5:	00 00                	add    BYTE PTR [rax],al
  4061f7:	00 ef                	add    bh,ch
  4061f9:	11 00                	adc    DWORD PTR [rax],eax
  4061fb:	00 00                	add    BYTE PTR [rax],al
  4061fd:	00 01                	add    BYTE PTR [rcx],al
  4061ff:	00 14 36             	add    BYTE PTR [rsi+rsi*1],dl
  406202:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40620d:	00 00                	add    BYTE PTR [rax],al
  40620f:	00 f7                	add    bh,dh
  406211:	11 00                	adc    DWORD PTR [rax],eax
  406213:	00 00                	add    BYTE PTR [rax],al
  406215:	00 01                	add    BYTE PTR [rcx],al
  406217:	00 35 36 40 00 00    	add    BYTE PTR [rip+0x4036],dh        # 0x40a253
	...
  406225:	00 00                	add    BYTE PTR [rax],al
  406227:	00 ff                	add    bh,bh
  406229:	11 00                	adc    DWORD PTR [rax],eax
  40622b:	00 00                	add    BYTE PTR [rax],al
  40622d:	00 01                	add    BYTE PTR [rcx],al
  40622f:	00 61 36             	add    BYTE PTR [rcx+0x36],ah
  406232:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40623d:	00 00                	add    BYTE PTR [rax],al
  40623f:	00 0a                	add    BYTE PTR [rdx],cl
  406241:	12 00                	adc    al,BYTE PTR [rax]
  406243:	00 00                	add    BYTE PTR [rax],al
  406245:	00 01                	add    BYTE PTR [rcx],al
  406247:	00 49 36             	add    BYTE PTR [rcx+0x36],cl
  40624a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406255:	00 00                	add    BYTE PTR [rax],al
  406257:	00 17                	add    BYTE PTR [rdi],dl
  406259:	12 00                	adc    al,BYTE PTR [rax]
  40625b:	00 00                	add    BYTE PTR [rax],al
  40625d:	00 01                	add    BYTE PTR [rcx],al
  40625f:	00 c3                	add    bl,al
  406261:	37                   	(bad)
  406262:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40626d:	00 00                	add    BYTE PTR [rax],al
  40626f:	00 22                	add    BYTE PTR [rdx],ah
  406271:	12 00                	adc    al,BYTE PTR [rax]
  406273:	00 00                	add    BYTE PTR [rax],al
  406275:	00 01                	add    BYTE PTR [rcx],al
  406277:	00 76 36             	add    BYTE PTR [rsi+0x36],dh
  40627a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406285:	00 00                	add    BYTE PTR [rax],al
  406287:	00 2b                	add    BYTE PTR [rbx],ch
  406289:	12 00                	adc    al,BYTE PTR [rax]
  40628b:	00 00                	add    BYTE PTR [rax],al
  40628d:	00 01                	add    BYTE PTR [rcx],al
  40628f:	00 6a 38             	add    BYTE PTR [rdx+0x38],ch
  406292:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40629d:	00 00                	add    BYTE PTR [rax],al
  40629f:	00 35 12 00 00 00    	add    BYTE PTR [rip+0x12],dh        # 0x4062b7
  4062a5:	00 01                	add    BYTE PTR [rcx],al
  4062a7:	00 1d 38 40 00 00    	add    BYTE PTR [rip+0x4038],bl        # 0x40a2e5
	...
  4062b5:	00 00                	add    BYTE PTR [rax],al
  4062b7:	00 3f                	add    BYTE PTR [rdi],bh
  4062b9:	12 00                	adc    al,BYTE PTR [rax]
  4062bb:	00 00                	add    BYTE PTR [rax],al
  4062bd:	00 01                	add    BYTE PTR [rcx],al
  4062bf:	00 bc 38 40 00 00 00 	add    BYTE PTR [rax+rdi*1+0x40],bh
	...
  4062ce:	00 00                	add    BYTE PTR [rax],al
  4062d0:	49 12 00             	rex.WB adc al,BYTE PTR [r8]
  4062d3:	00 00                	add    BYTE PTR [rax],al
  4062d5:	00 01                	add    BYTE PTR [rcx],al
  4062d7:	00 f9                	add    cl,bh
  4062d9:	39 40 00             	cmp    DWORD PTR [rax+0x0],eax
	...
  4062e8:	58                   	pop    rax
  4062e9:	12 00                	adc    al,BYTE PTR [rax]
  4062eb:	00 00                	add    BYTE PTR [rax],al
  4062ed:	00 01                	add    BYTE PTR [rcx],al
  4062ef:	00 75 39             	add    BYTE PTR [rbp+0x39],dh
  4062f2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4062fd:	00 00                	add    BYTE PTR [rax],al
  4062ff:	00 60 12             	add    BYTE PTR [rax+0x12],ah
  406302:	00 00                	add    BYTE PTR [rax],al
  406304:	00 00                	add    BYTE PTR [rax],al
  406306:	01 00                	add    DWORD PTR [rax],eax
  406308:	75 37                	jne    0x406341
  40630a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406315:	00 00                	add    BYTE PTR [rax],al
  406317:	00 70 12             	add    BYTE PTR [rax+0x12],dh
  40631a:	00 00                	add    BYTE PTR [rax],al
  40631c:	00 00                	add    BYTE PTR [rax],al
  40631e:	01 00                	add    DWORD PTR [rax],eax
  406320:	90                   	nop
  406321:	36 40 00 00          	ss rex add BYTE PTR [rax],al
	...
  40632d:	00 00                	add    BYTE PTR [rax],al
  40632f:	00 7c 12 00          	add    BYTE PTR [rdx+rdx*1+0x0],bh
  406333:	00 00                	add    BYTE PTR [rax],al
  406335:	00 01                	add    BYTE PTR [rcx],al
  406337:	00 6c 37 40          	add    BYTE PTR [rdi+rsi*1+0x40],ch
	...
  406347:	00 80 12 00 00 00    	add    BYTE PTR [rax+0x12],al
  40634d:	00 01                	add    BYTE PTR [rcx],al
  40634f:	00 04 37             	add    BYTE PTR [rdi+rsi*1],al
  406352:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40635d:	00 00                	add    BYTE PTR [rax],al
  40635f:	00 8e 12 00 00 00    	add    BYTE PTR [rsi+0x12],cl
  406365:	00 01                	add    BYTE PTR [rcx],al
  406367:	00 df                	add    bh,bl
  406369:	36 40 00 00          	ss rex add BYTE PTR [rax],al
	...
  406375:	00 00                	add    BYTE PTR [rax],al
  406377:	00 9e 12 00 00 00    	add    BYTE PTR [rsi+0x12],bl
  40637d:	00 01                	add    BYTE PTR [rcx],al
  40637f:	00 83 39 40 00 00    	add    BYTE PTR [rbx+0x4039],al
	...
  40638d:	00 00                	add    BYTE PTR [rax],al
  40638f:	00 ad 12 00 00 00    	add    BYTE PTR [rbp+0x12],ch
  406395:	00 01                	add    BYTE PTR [rcx],al
  406397:	00 ab 39 40 00 00    	add    BYTE PTR [rbx+0x4039],ch
	...
  4063a5:	00 00                	add    BYTE PTR [rax],al
  4063a7:	00 bd 12 00 00 00    	add    BYTE PTR [rbp+0x12],bh
  4063ad:	00 01                	add    BYTE PTR [rcx],al
  4063af:	00 dd                	add    ch,bl
  4063b1:	3c 40                	cmp    al,0x40
	...
  4063bf:	00 d1                	add    cl,dl
  4063c1:	12 00                	adc    al,BYTE PTR [rax]
  4063c3:	00 00                	add    BYTE PTR [rax],al
  4063c5:	00 02                	add    BYTE PTR [rdx],al
  4063c7:	00 96 40 40 00 00    	add    BYTE PTR [rsi+0x4040],dl
	...
  4063d5:	00 00                	add    BYTE PTR [rax],al
  4063d7:	00 e3                	add    bl,ah
  4063d9:	12 00                	adc    al,BYTE PTR [rax]
  4063db:	00 00                	add    BYTE PTR [rax],al
  4063dd:	00 02                	add    BYTE PTR [rdx],al
  4063df:	00 a3 40 40 00 00    	add    BYTE PTR [rbx+0x4040],ah
	...
  4063ed:	00 00                	add    BYTE PTR [rax],al
  4063ef:	00 f9                	add    cl,bh
  4063f1:	12 00                	adc    al,BYTE PTR [rax]
  4063f3:	00 00                	add    BYTE PTR [rax],al
  4063f5:	00 02                	add    BYTE PTR [rdx],al
  4063f7:	00 a3 40 40 00 00    	add    BYTE PTR [rbx+0x4040],ah
	...
  406405:	00 00                	add    BYTE PTR [rax],al
  406407:	00 01                	add    BYTE PTR [rcx],al
  406409:	13 00                	adc    eax,DWORD PTR [rax]
  40640b:	00 00                	add    BYTE PTR [rax],al
  40640d:	00 01                	add    BYTE PTR [rcx],al
  40640f:	00 15 38 40 00 00    	add    BYTE PTR [rip+0x4038],dl        # 0x40a44d
	...
  40641d:	00 00                	add    BYTE PTR [rax],al
  40641f:	00 09                	add    BYTE PTR [rcx],cl
  406421:	13 00                	adc    eax,DWORD PTR [rax]
  406423:	00 00                	add    BYTE PTR [rax],al
  406425:	00 01                	add    BYTE PTR [rcx],al
  406427:	00 23                	add    BYTE PTR [rbx],ah
  406429:	38 40 00             	cmp    BYTE PTR [rax+0x0],al
	...
  406438:	12 13                	adc    dl,BYTE PTR [rbx]
  40643a:	00 00                	add    BYTE PTR [rax],al
  40643c:	00 00                	add    BYTE PTR [rax],al
  40643e:	01 00                	add    DWORD PTR [rax],eax
  406440:	5b                   	pop    rbx
  406441:	38 40 00             	cmp    BYTE PTR [rax+0x0],al
	...
  406450:	1b 13                	sbb    edx,DWORD PTR [rbx]
  406452:	00 00                	add    BYTE PTR [rax],al
  406454:	00 00                	add    BYTE PTR [rax],al
  406456:	01 00                	add    DWORD PTR [rax],eax
  406458:	62                   	(bad)
  406459:	38 40 00             	cmp    BYTE PTR [rax+0x0],al
	...
  406468:	23 13                	and    edx,DWORD PTR [rbx]
  40646a:	00 00                	add    BYTE PTR [rax],al
  40646c:	00 00                	add    BYTE PTR [rax],al
  40646e:	01 00                	add    DWORD PTR [rax],eax
  406470:	7b 38                	jnp    0x4064aa
  406472:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40647d:	00 00                	add    BYTE PTR [rax],al
  40647f:	00 2b                	add    BYTE PTR [rbx],ch
  406481:	13 00                	adc    eax,DWORD PTR [rax]
  406483:	00 00                	add    BYTE PTR [rax],al
  406485:	00 01                	add    BYTE PTR [rcx],al
  406487:	00 b4 38 40 00 00 00 	add    BYTE PTR [rax+rdi*1+0x40],dh
	...
  406496:	00 00                	add    BYTE PTR [rax],al
  406498:	33 13                	xor    edx,DWORD PTR [rbx]
  40649a:	00 00                	add    BYTE PTR [rax],al
  40649c:	00 00                	add    BYTE PTR [rax],al
  40649e:	01 00                	add    DWORD PTR [rax],eax
  4064a0:	a2 38 40 00 00 00 00 	movabs ds:0x4038,al
  4064a7:	00 00 
  4064a9:	00 00                	add    BYTE PTR [rax],al
  4064ab:	00 00                	add    BYTE PTR [rax],al
  4064ad:	00 00                	add    BYTE PTR [rax],al
  4064af:	00 46 13             	add    BYTE PTR [rsi+0x13],al
  4064b2:	00 00                	add    BYTE PTR [rax],al
  4064b4:	00 00                	add    BYTE PTR [rax],al
  4064b6:	01 00                	add    DWORD PTR [rax],eax
  4064b8:	d2 38                	sar    BYTE PTR [rax],cl
  4064ba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4064c5:	00 00                	add    BYTE PTR [rax],al
  4064c7:	00 4f 13             	add    BYTE PTR [rdi+0x13],cl
  4064ca:	00 00                	add    BYTE PTR [rax],al
  4064cc:	00 00                	add    BYTE PTR [rax],al
  4064ce:	01 00                	add    DWORD PTR [rax],eax
  4064d0:	da 38                	fidivr DWORD PTR [rax]
  4064d2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4064dd:	00 00                	add    BYTE PTR [rax],al
  4064df:	00 59 13             	add    BYTE PTR [rcx+0x13],bl
  4064e2:	00 00                	add    BYTE PTR [rax],al
  4064e4:	00 00                	add    BYTE PTR [rax],al
  4064e6:	01 00                	add    DWORD PTR [rax],eax
  4064e8:	ea                   	(bad)
  4064e9:	38 40 00             	cmp    BYTE PTR [rax+0x0],al
	...
  4064f8:	62 13 00 00 00       	(bad)
  4064fd:	00 01                	add    BYTE PTR [rcx],al
  4064ff:	00 2e                	add    BYTE PTR [rsi],ch
  406501:	39 40 00             	cmp    DWORD PTR [rax+0x0],eax
	...
  406510:	6b 13 00             	imul   edx,DWORD PTR [rbx],0x0
  406513:	00 00                	add    BYTE PTR [rax],al
  406515:	00 01                	add    BYTE PTR [rcx],al
  406517:	00 06                	add    BYTE PTR [rsi],al
  406519:	39 40 00             	cmp    DWORD PTR [rax+0x0],eax
	...
  406528:	75 13                	jne    0x40653d
  40652a:	00 00                	add    BYTE PTR [rax],al
  40652c:	00 00                	add    BYTE PTR [rax],al
  40652e:	01 00                	add    DWORD PTR [rax],eax
  406530:	6a 39                	push   0x39
  406532:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40653d:	00 00                	add    BYTE PTR [rax],al
  40653f:	00 7d 13             	add    BYTE PTR [rbp+0x13],bh
  406542:	00 00                	add    BYTE PTR [rax],al
  406544:	00 00                	add    BYTE PTR [rax],al
  406546:	01 00                	add    DWORD PTR [rax],eax
  406548:	23 39                	and    edi,DWORD PTR [rcx]
  40654a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406555:	00 00                	add    BYTE PTR [rax],al
  406557:	00 86 13 00 00 00    	add    BYTE PTR [rsi+0x13],al
  40655d:	00 01                	add    BYTE PTR [rcx],al
  40655f:	00 47 39             	add    BYTE PTR [rdi+0x39],al
  406562:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40656d:	00 00                	add    BYTE PTR [rax],al
  40656f:	00 8f 13 00 00 00    	add    BYTE PTR [rdi+0x13],cl
  406575:	00 01                	add    BYTE PTR [rcx],al
  406577:	00 5f 39             	add    BYTE PTR [rdi+0x39],bl
  40657a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406585:	00 00                	add    BYTE PTR [rax],al
  406587:	00 98 13 00 00 00    	add    BYTE PTR [rax+0x13],bl
  40658d:	00 01                	add    BYTE PTR [rcx],al
  40658f:	00 77 39             	add    BYTE PTR [rdi+0x39],dh
  406592:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40659d:	00 00                	add    BYTE PTR [rax],al
  40659f:	00 9c 13 00 00 00 00 	add    BYTE PTR [rbx+rdx*1+0x0],bl
  4065a6:	01 00                	add    DWORD PTR [rax],eax
  4065a8:	82                   	(bad)
  4065a9:	39 40 00             	cmp    DWORD PTR [rax+0x0],eax
	...
  4065b8:	a5                   	movs   DWORD PTR es:[rdi],DWORD PTR ds:[rsi]
  4065b9:	13 00                	adc    eax,DWORD PTR [rax]
  4065bb:	00 00                	add    BYTE PTR [rax],al
  4065bd:	00 02                	add    BYTE PTR [rdx],al
  4065bf:	00 78 40             	add    BYTE PTR [rax+0x40],bh
  4065c2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4065cd:	00 00                	add    BYTE PTR [rax],al
  4065cf:	00 b5 13 00 00 00    	add    BYTE PTR [rbp+0x13],dh
  4065d5:	00 01                	add    BYTE PTR [rcx],al
  4065d7:	00 bb 39 40 00 00    	add    BYTE PTR [rbx+0x4039],bh
	...
  4065e5:	00 00                	add    BYTE PTR [rax],al
  4065e7:	00 bd 13 00 00 00    	add    BYTE PTR [rbp+0x13],bh
  4065ed:	00 01                	add    BYTE PTR [rcx],al
  4065ef:	00 cf                	add    bh,cl
  4065f1:	39 40 00             	cmp    DWORD PTR [rax+0x0],eax
	...
  406600:	c7                   	(bad)
  406601:	13 00                	adc    eax,DWORD PTR [rax]
  406603:	00 00                	add    BYTE PTR [rax],al
  406605:	00 01                	add    BYTE PTR [rcx],al
  406607:	00 d2                	add    dl,dl
  406609:	39 40 00             	cmp    DWORD PTR [rax+0x0],eax
	...
  406618:	d1 13                	rcl    DWORD PTR [rbx],1
  40661a:	00 00                	add    BYTE PTR [rax],al
  40661c:	00 00                	add    BYTE PTR [rax],al
  40661e:	02 00                	add    al,BYTE PTR [rax]
  406620:	96                   	xchg   esi,eax
  406621:	40                   	rex
  406622:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40662d:	00 00                	add    BYTE PTR [rax],al
  40662f:	00 e5                	add    ch,ah
  406631:	13 00                	adc    eax,DWORD PTR [rax]
  406633:	00 00                	add    BYTE PTR [rax],al
  406635:	00 01                	add    BYTE PTR [rcx],al
  406637:	00 94 3c 40 00 00 00 	add    BYTE PTR [rsp+rdi*1+0x40],dl
	...
  406646:	00 00                	add    BYTE PTR [rax],al
  406648:	ee                   	out    dx,al
  406649:	13 00                	adc    eax,DWORD PTR [rax]
  40664b:	00 00                	add    BYTE PTR [rax],al
  40664d:	00 01                	add    BYTE PTR [rcx],al
  40664f:	00 c7                	add    bh,al
  406651:	3a 40 00             	cmp    al,BYTE PTR [rax+0x0]
	...
  406660:	f8                   	clc
  406661:	13 00                	adc    eax,DWORD PTR [rax]
  406663:	00 00                	add    BYTE PTR [rax],al
  406665:	00 01                	add    BYTE PTR [rcx],al
  406667:	00 d1                	add    cl,dl
  406669:	3a 40 00             	cmp    al,BYTE PTR [rax+0x0]
	...
  406678:	07                   	(bad)
  406679:	14 00                	adc    al,0x0
  40667b:	00 00                	add    BYTE PTR [rax],al
  40667d:	00 01                	add    BYTE PTR [rcx],al
  40667f:	00 fb                	add    bl,bh
  406681:	3a 40 00             	cmp    al,BYTE PTR [rax+0x0]
	...
  406690:	16                   	(bad)
  406691:	14 00                	adc    al,0x0
  406693:	00 00                	add    BYTE PTR [rax],al
  406695:	00 01                	add    BYTE PTR [rcx],al
  406697:	00 5d 3b             	add    BYTE PTR [rbp+0x3b],bl
  40669a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4066a5:	00 00                	add    BYTE PTR [rax],al
  4066a7:	00 20                	add    BYTE PTR [rax],ah
  4066a9:	14 00                	adc    al,0x0
  4066ab:	00 00                	add    BYTE PTR [rax],al
  4066ad:	00 01                	add    BYTE PTR [rcx],al
  4066af:	00 4a 3c             	add    BYTE PTR [rdx+0x3c],cl
  4066b2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4066bd:	00 00                	add    BYTE PTR [rax],al
  4066bf:	00 2c 14             	add    BYTE PTR [rsp+rdx*1],ch
  4066c2:	00 00                	add    BYTE PTR [rax],al
  4066c4:	00 00                	add    BYTE PTR [rax],al
  4066c6:	01 00                	add    DWORD PTR [rax],eax
  4066c8:	86 3b                	xchg   BYTE PTR [rbx],bh
  4066ca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4066d5:	00 00                	add    BYTE PTR [rax],al
  4066d7:	00 37                	add    BYTE PTR [rdi],dh
  4066d9:	14 00                	adc    al,0x0
  4066db:	00 00                	add    BYTE PTR [rax],al
  4066dd:	00 01                	add    BYTE PTR [rcx],al
  4066df:	00 b5 3b 40 00 00    	add    BYTE PTR [rbp+0x403b],dh
	...
  4066ed:	00 00                	add    BYTE PTR [rax],al
  4066ef:	00 44 14 00          	add    BYTE PTR [rsp+rdx*1+0x0],al
  4066f3:	00 00                	add    BYTE PTR [rax],al
  4066f5:	00 01                	add    BYTE PTR [rcx],al
  4066f7:	00 42 3c             	add    BYTE PTR [rdx+0x3c],al
  4066fa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406705:	00 00                	add    BYTE PTR [rax],al
  406707:	00 4e 14             	add    BYTE PTR [rsi+0x14],cl
  40670a:	00 00                	add    BYTE PTR [rax],al
  40670c:	00 00                	add    BYTE PTR [rax],al
  40670e:	01 00                	add    DWORD PTR [rax],eax
  406710:	6d                   	ins    DWORD PTR es:[rdi],dx
  406711:	3c 40                	cmp    al,0x40
	...
  40671f:	00 5b 14             	add    BYTE PTR [rbx+0x14],bl
  406722:	00 00                	add    BYTE PTR [rax],al
  406724:	00 00                	add    BYTE PTR [rax],al
  406726:	01 00                	add    DWORD PTR [rax],eax
  406728:	80 3c 40 00          	cmp    BYTE PTR [rax+rax*2],0x0
	...
  406738:	65 14 00             	gs adc al,0x0
  40673b:	00 00                	add    BYTE PTR [rax],al
  40673d:	00 01                	add    BYTE PTR [rcx],al
  40673f:	00 8d 3c 40 00 00    	add    BYTE PTR [rbp+0x403c],cl
	...
  40674d:	00 00                	add    BYTE PTR [rax],al
  40674f:	00 6d 14             	add    BYTE PTR [rbp+0x14],ch
  406752:	00 00                	add    BYTE PTR [rax],al
  406754:	00 00                	add    BYTE PTR [rax],al
  406756:	01 00                	add    DWORD PTR [rax],eax
  406758:	9b                   	fwait
  406759:	3c 40                	cmp    al,0x40
	...
  406767:	00 77 14             	add    BYTE PTR [rdi+0x14],dh
  40676a:	00 00                	add    BYTE PTR [rax],al
  40676c:	00 00                	add    BYTE PTR [rax],al
  40676e:	01 00                	add    DWORD PTR [rax],eax
  406770:	aa                   	stos   BYTE PTR es:[rdi],al
  406771:	3c 40                	cmp    al,0x40
	...
  40677f:	00 85 14 00 00 00    	add    BYTE PTR [rbp+0x14],al
  406785:	00 02                	add    BYTE PTR [rdx],al
  406787:	00 a4 40 40 00 00 00 	add    BYTE PTR [rax+rax*2+0x40],ah
	...
  406796:	00 00                	add    BYTE PTR [rax],al
  406798:	90                   	nop
  406799:	14 00                	adc    al,0x0
  40679b:	00 00                	add    BYTE PTR [rax],al
  40679d:	00 01                	add    BYTE PTR [rcx],al
  40679f:	00 bd 3c 40 00 00    	add    BYTE PTR [rbp+0x403c],bh
	...
  4067ad:	00 00                	add    BYTE PTR [rax],al
  4067af:	00 9b 14 00 00 00    	add    BYTE PTR [rbx+0x14],bl
  4067b5:	00 02                	add    BYTE PTR [rdx],al
  4067b7:	00 c0                	add    al,al
  4067b9:	40                   	rex
  4067ba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4067c5:	00 00                	add    BYTE PTR [rax],al
  4067c7:	00 ad 14 00 00 00    	add    BYTE PTR [rbp+0x14],ch
  4067cd:	00 02                	add    BYTE PTR [rdx],al
  4067cf:	00 b4 40 40 00 00 00 	add    BYTE PTR [rax+rax*2+0x40],dh
	...
  4067de:	00 00                	add    BYTE PTR [rax],al
  4067e0:	bc 14 00 00 00       	mov    esp,0x14
  4067e5:	00 02                	add    BYTE PTR [rdx],al
  4067e7:	00 c0                	add    al,al
  4067e9:	40                   	rex
  4067ea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4067f5:	00 00                	add    BYTE PTR [rax],al
  4067f7:	00 cf                	add    bh,cl
  4067f9:	14 00                	adc    al,0x0
  4067fb:	00 00                	add    BYTE PTR [rax],al
  4067fd:	00 01                	add    BYTE PTR [rcx],al
  4067ff:	00 a5 3d 40 00 00    	add    BYTE PTR [rbp+0x403d],ah
	...
  40680d:	00 00                	add    BYTE PTR [rax],al
  40680f:	00 db                	add    bl,bl
  406811:	14 00                	adc    al,0x0
  406813:	00 00                	add    BYTE PTR [rax],al
  406815:	00 01                	add    BYTE PTR [rcx],al
  406817:	00 de                	add    dh,bl
  406819:	3d 40 00 00 00       	cmp    eax,0x40
	...
  406826:	00 00                	add    BYTE PTR [rax],al
  406828:	e5 14                	in     eax,0x14
  40682a:	00 00                	add    BYTE PTR [rax],al
  40682c:	00 00                	add    BYTE PTR [rax],al
  40682e:	01 00                	add    DWORD PTR [rax],eax
  406830:	47                   	rex.RXB
  406831:	3e 40 00 00          	ds rex add BYTE PTR [rax],al
	...
  40683d:	00 00                	add    BYTE PTR [rax],al
  40683f:	00 ef                	add    bh,ch
  406841:	14 00                	adc    al,0x0
  406843:	00 00                	add    BYTE PTR [rax],al
  406845:	00 01                	add    BYTE PTR [rcx],al
  406847:	00 84 3f 40 00 00 00 	add    BYTE PTR [rdi+rdi*1+0x40],al
	...
  406856:	00 00                	add    BYTE PTR [rax],al
  406858:	fb                   	sti
  406859:	14 00                	adc    al,0x0
  40685b:	00 00                	add    BYTE PTR [rax],al
  40685d:	00 01                	add    BYTE PTR [rcx],al
  40685f:	00 b2 3e 40 00 00    	add    BYTE PTR [rdx+0x403e],dh
	...
  40686d:	00 00                	add    BYTE PTR [rax],al
  40686f:	00 0c 15 00 00 00 00 	add    BYTE PTR [rdx*1+0x0],cl
  406876:	01 00                	add    DWORD PTR [rax],eax
  406878:	5c                   	pop    rsp
  406879:	3e 40 00 00          	ds rex add BYTE PTR [rax],al
	...
  406885:	00 00                	add    BYTE PTR [rax],al
  406887:	00 19                	add    BYTE PTR [rcx],bl
  406889:	15 00 00 00 00       	adc    eax,0x0
  40688e:	01 00                	add    DWORD PTR [rax],eax
  406890:	98                   	cwde
  406891:	3e 40 00 00          	ds rex add BYTE PTR [rax],al
	...
  40689d:	00 00                	add    BYTE PTR [rax],al
  40689f:	00 29                	add    BYTE PTR [rcx],ch
  4068a1:	15 00 00 00 00       	adc    eax,0x0
  4068a6:	01 00                	add    DWORD PTR [rax],eax
  4068a8:	73 3e                	jae    0x4068e8
  4068aa:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4068b5:	00 00                	add    BYTE PTR [rax],al
  4068b7:	00 36                	add    BYTE PTR [rsi],dh
  4068b9:	15 00 00 00 00       	adc    eax,0x0
  4068be:	01 00                	add    DWORD PTR [rax],eax
  4068c0:	8b 3e                	mov    edi,DWORD PTR [rsi]
  4068c2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4068cd:	00 00                	add    BYTE PTR [rax],al
  4068cf:	00 47 15             	add    BYTE PTR [rdi+0x15],al
  4068d2:	00 00                	add    BYTE PTR [rax],al
  4068d4:	00 00                	add    BYTE PTR [rax],al
  4068d6:	01 00                	add    DWORD PTR [rax],eax
  4068d8:	9f                   	lahf
  4068d9:	3e 40 00 00          	ds rex add BYTE PTR [rax],al
	...
  4068e5:	00 00                	add    BYTE PTR [rax],al
  4068e7:	00 5c 15 00          	add    BYTE PTR [rbp+rdx*1+0x0],bl
  4068eb:	00 00                	add    BYTE PTR [rax],al
  4068ed:	00 01                	add    BYTE PTR [rcx],al
  4068ef:	00 be 3e 40 00 00    	add    BYTE PTR [rsi+0x403e],bh
	...
  4068fd:	00 00                	add    BYTE PTR [rax],al
  4068ff:	00 6a 15             	add    BYTE PTR [rdx+0x15],ch
  406902:	00 00                	add    BYTE PTR [rax],al
  406904:	00 00                	add    BYTE PTR [rax],al
  406906:	01 00                	add    DWORD PTR [rax],eax
  406908:	47 3f                	rex.RXB (bad)
  40690a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406915:	00 00                	add    BYTE PTR [rax],al
  406917:	00 7b 15             	add    BYTE PTR [rbx+0x15],bh
  40691a:	00 00                	add    BYTE PTR [rax],al
  40691c:	00 00                	add    BYTE PTR [rax],al
  40691e:	01 00                	add    DWORD PTR [rax],eax
  406920:	d9 3e                	fnstcw WORD PTR [rsi]
  406922:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40692d:	00 00                	add    BYTE PTR [rax],al
  40692f:	00 8b 15 00 00 00    	add    BYTE PTR [rbx+0x15],cl
  406935:	00 01                	add    BYTE PTR [rcx],al
  406937:	00 f0                	add    al,dh
  406939:	3e 40 00 00          	ds rex add BYTE PTR [rax],al
	...
  406945:	00 00                	add    BYTE PTR [rax],al
  406947:	00 9f 15 00 00 00    	add    BYTE PTR [rdi+0x15],bl
  40694d:	00 01                	add    BYTE PTR [rcx],al
  40694f:	00 fb                	add    bl,bh
  406951:	3e 40 00 00          	ds rex add BYTE PTR [rax],al
	...
  40695d:	00 00                	add    BYTE PTR [rax],al
  40695f:	00 ad 15 00 00 00    	add    BYTE PTR [rbp+0x15],ch
  406965:	00 01                	add    BYTE PTR [rcx],al
  406967:	00 3f                	add    BYTE PTR [rdi],bh
  406969:	3f                   	(bad)
  40696a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406975:	00 00                	add    BYTE PTR [rax],al
  406977:	00 c0                	add    al,al
  406979:	15 00 00 00 00       	adc    eax,0x0
  40697e:	01 00                	add    DWORD PTR [rax],eax
  406980:	06                   	(bad)
  406981:	3f                   	(bad)
  406982:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40698d:	00 00                	add    BYTE PTR [rax],al
  40698f:	00 ce                	add    dh,cl
  406991:	15 00 00 00 00       	adc    eax,0x0
  406996:	01 00                	add    DWORD PTR [rax],eax
  406998:	27                   	(bad)
  406999:	3f                   	(bad)
  40699a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4069a5:	00 00                	add    BYTE PTR [rax],al
  4069a7:	00 e0                	add    al,ah
  4069a9:	15 00 00 00 00       	adc    eax,0x0
  4069ae:	01 00                	add    DWORD PTR [rax],eax
  4069b0:	55                   	push   rbp
  4069b1:	3f                   	(bad)
  4069b2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4069bd:	00 00                	add    BYTE PTR [rax],al
  4069bf:	00 f3                	add    bl,dh
  4069c1:	15 00 00 00 00       	adc    eax,0x0
  4069c6:	01 00                	add    DWORD PTR [rax],eax
  4069c8:	67 3f                	addr32 (bad)
  4069ca:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4069d5:	00 00                	add    BYTE PTR [rax],al
  4069d7:	00 0c 16             	add    BYTE PTR [rsi+rdx*1],cl
  4069da:	00 00                	add    BYTE PTR [rax],al
  4069dc:	00 00                	add    BYTE PTR [rax],al
  4069de:	01 00                	add    DWORD PTR [rax],eax
  4069e0:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4069e1:	3f                   	(bad)
  4069e2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  4069ed:	00 00                	add    BYTE PTR [rax],al
  4069ef:	00 1f                	add    BYTE PTR [rdi],bl
  4069f1:	16                   	(bad)
  4069f2:	00 00                	add    BYTE PTR [rax],al
  4069f4:	00 00                	add    BYTE PTR [rax],al
  4069f6:	03 00                	add    eax,DWORD PTR [rax]
  4069f8:	00 50 40             	add    BYTE PTR [rax+0x40],dl
	...
  406a07:	00 34 16             	add    BYTE PTR [rsi+rdx*1],dh
  406a0a:	00 00                	add    BYTE PTR [rax],al
  406a0c:	10 00                	adc    BYTE PTR [rax],al
  406a0e:	02 00                	add    al,BYTE PTR [rax]
  406a10:	70 40                	jo     0x406a52
  406a12:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406a1d:	00 00                	add    BYTE PTR [rax],al
  406a1f:	00 4a 16             	add    BYTE PTR [rdx+0x16],cl
  406a22:	00 00                	add    BYTE PTR [rax],al
  406a24:	10 00                	adc    BYTE PTR [rax],al
  406a26:	02 00                	add    al,BYTE PTR [rax]
  406a28:	04 40                	add    al,0x40
  406a2a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406a35:	00 00                	add    BYTE PTR [rax],al
  406a37:	00 5d 16             	add    BYTE PTR [rbp+0x16],bl
  406a3a:	00 00                	add    BYTE PTR [rax],al
  406a3c:	10 00                	adc    BYTE PTR [rax],al
  406a3e:	01 00                	add    DWORD PTR [rax],eax
  406a40:	01 3e                	add    DWORD PTR [rsi],edi
  406a42:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406a4d:	00 00                	add    BYTE PTR [rax],al
  406a4f:	00 74 16 00          	add    BYTE PTR [rsi+rdx*1+0x0],dh
  406a53:	00 10                	add    BYTE PTR [rax],dl
  406a55:	00 01                	add    BYTE PTR [rcx],al
  406a57:	00 a6 09 40 00 00    	add    BYTE PTR [rsi+0x4009],ah
	...
  406a65:	00 00                	add    BYTE PTR [rax],al
  406a67:	00 81 16 00 00 10    	add    BYTE PTR [rcx+0x10000016],al
  406a6d:	00 02                	add    BYTE PTR [rdx],al
  406a6f:	00 20                	add    BYTE PTR [rax],ah
  406a71:	40                   	rex
  406a72:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406a7d:	00 00                	add    BYTE PTR [rax],al
  406a7f:	00 9f 16 00 00 10    	add    BYTE PTR [rdi+0x10000016],bl
  406a85:	00 02                	add    BYTE PTR [rdx],al
  406a87:	00 10                	add    BYTE PTR [rax],dl
  406a89:	40                   	rex
  406a8a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406a95:	00 00                	add    BYTE PTR [rax],al
  406a97:	00 c1                	add    cl,al
  406a99:	16                   	(bad)
  406a9a:	00 00                	add    BYTE PTR [rax],al
  406a9c:	10 00                	adc    BYTE PTR [rax],al
  406a9e:	01 00                	add    DWORD PTR [rax],eax
  406aa0:	e8 26 40 00 00       	call   0x40aacb
	...
  406aad:	00 00                	add    BYTE PTR [rax],al
  406aaf:	00 ce                	add    dh,cl
  406ab1:	16                   	(bad)
  406ab2:	00 00                	add    BYTE PTR [rax],al
  406ab4:	10 00                	adc    BYTE PTR [rax],al
  406ab6:	01 00                	add    DWORD PTR [rax],eax
  406ab8:	e3 21                	jrcxz  0x406adb
  406aba:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406ac5:	00 00                	add    BYTE PTR [rax],al
  406ac7:	00 db                	add    bl,bl
  406ac9:	16                   	(bad)
  406aca:	00 00                	add    BYTE PTR [rax],al
  406acc:	10 00                	adc    BYTE PTR [rax],al
  406ace:	01 00                	add    DWORD PTR [rax],eax
  406ad0:	05 23 40 00 00       	add    eax,0x4023
	...
  406add:	00 00                	add    BYTE PTR [rax],al
  406adf:	00 e8                	add    al,ch
  406ae1:	16                   	(bad)
  406ae2:	00 00                	add    BYTE PTR [rax],al
  406ae4:	10 00                	adc    BYTE PTR [rax],al
  406ae6:	01 00                	add    DWORD PTR [rax],eax
  406ae8:	e7 32                	out    0x32,eax
  406aea:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406af5:	00 00                	add    BYTE PTR [rax],al
  406af7:	00 f5                	add    ch,dh
  406af9:	16                   	(bad)
  406afa:	00 00                	add    BYTE PTR [rax],al
  406afc:	10 00                	adc    BYTE PTR [rax],al
  406afe:	02 00                	add    al,BYTE PTR [rax]
  406b00:	08 40 40             	or     BYTE PTR [rax+0x40],al
	...
  406b0f:	00 0f                	add    BYTE PTR [rdi],cl
  406b11:	17                   	(bad)
  406b12:	00 00                	add    BYTE PTR [rax],al
  406b14:	10 00                	adc    BYTE PTR [rax],al
  406b16:	01 00                	add    DWORD PTR [rax],eax
  406b18:	a7                   	cmps   DWORD PTR ds:[rsi],DWORD PTR es:[rdi]
  406b19:	05 40 00 00 00       	add    eax,0x40
	...
  406b26:	00 00                	add    BYTE PTR [rax],al
  406b28:	21 17                	and    DWORD PTR [rdi],edx
  406b2a:	00 00                	add    BYTE PTR [rax],al
  406b2c:	10 00                	adc    BYTE PTR [rax],al
  406b2e:	01 00                	add    DWORD PTR [rax],eax
  406b30:	f8                   	clc
  406b31:	32 40 00             	xor    al,BYTE PTR [rax+0x0]
	...
  406b40:	36 17                	ss (bad)
  406b42:	00 00                	add    BYTE PTR [rax],al
  406b44:	10 00                	adc    BYTE PTR [rax],al
  406b46:	01 00                	add    DWORD PTR [rax],eax
  406b48:	85 07                	test   DWORD PTR [rdi],eax
  406b4a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406b55:	00 00                	add    BYTE PTR [rax],al
  406b57:	00 47 17             	add    BYTE PTR [rdi+0x17],al
  406b5a:	00 00                	add    BYTE PTR [rax],al
  406b5c:	10 00                	adc    BYTE PTR [rax],al
  406b5e:	01 00                	add    DWORD PTR [rax],eax
  406b60:	07                   	(bad)
  406b61:	1c 40                	sbb    al,0x40
	...
  406b6f:	00 50 0b             	add    BYTE PTR [rax+0xb],dl
  406b72:	00 00                	add    BYTE PTR [rax],al
  406b74:	10 00                	adc    BYTE PTR [rax],al
  406b76:	01 00                	add    DWORD PTR [rax],eax
  406b78:	42 34 40             	rex.X xor al,0x40
	...
  406b87:	00 54 17 00          	add    BYTE PTR [rdi+rdx*1+0x0],dl
  406b8b:	00 10                	add    BYTE PTR [rax],dl
  406b8d:	00 01                	add    BYTE PTR [rcx],al
  406b8f:	00 ec                	add    ah,ch
  406b91:	29 40 00             	sub    DWORD PTR [rax+0x0],eax
	...
  406ba0:	61                   	(bad)
  406ba1:	17                   	(bad)
  406ba2:	00 00                	add    BYTE PTR [rax],al
  406ba4:	10 00                	adc    BYTE PTR [rax],al
  406ba6:	01 00                	add    DWORD PTR [rax],eax
  406ba8:	d6                   	(bad)
  406ba9:	22 40 00             	and    al,BYTE PTR [rax+0x0]
	...
  406bb8:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406bb9:	17                   	(bad)
  406bba:	00 00                	add    BYTE PTR [rax],al
  406bbc:	10 00                	adc    BYTE PTR [rax],al
  406bbe:	01 00                	add    DWORD PTR [rax],eax
  406bc0:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406bc1:	06                   	(bad)
  406bc2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406bcd:	00 00                	add    BYTE PTR [rax],al
  406bcf:	00 80 17 00 00 10    	add    BYTE PTR [rax+0x10000017],al
  406bd5:	00 02                	add    BYTE PTR [rdx],al
  406bd7:	00 00                	add    BYTE PTR [rax],al
  406bd9:	40                   	rex
  406bda:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406be5:	00 00                	add    BYTE PTR [rax],al
  406be7:	00 92 17 00 00 10    	add    BYTE PTR [rdx+0x10000017],dl
  406bed:	00 02                	add    BYTE PTR [rdx],al
  406bef:	00 18                	add    BYTE PTR [rax],bl
  406bf1:	40                   	rex
  406bf2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406bfd:	00 00                	add    BYTE PTR [rax],al
  406bff:	00 ad 17 00 00 10    	add    BYTE PTR [rbp+0x10000017],ch
  406c05:	00 01                	add    BYTE PTR [rcx],al
  406c07:	00 c0                	add    al,al
  406c09:	37                   	(bad)
  406c0a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406c15:	00 00                	add    BYTE PTR [rax],al
  406c17:	00 ba 17 00 00 10    	add    BYTE PTR [rdx+0x10000017],bh
  406c1d:	00 02                	add    BYTE PTR [rdx],al
  406c1f:	00 68 40             	add    BYTE PTR [rax+0x40],ch
  406c22:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406c2d:	00 00                	add    BYTE PTR [rax],al
  406c2f:	00 d2                	add    dl,dl
  406c31:	17                   	(bad)
  406c32:	00 00                	add    BYTE PTR [rax],al
  406c34:	10 00                	adc    BYTE PTR [rax],al
  406c36:	01 00                	add    DWORD PTR [rax],eax
  406c38:	ee                   	out    dx,al
  406c39:	32 40 00             	xor    al,BYTE PTR [rax+0x0]
	...
  406c48:	df 17                	fist   WORD PTR [rdi]
  406c4a:	00 00                	add    BYTE PTR [rax],al
  406c4c:	10 00                	adc    BYTE PTR [rax],al
  406c4e:	02 00                	add    al,BYTE PTR [rax]
  406c50:	58                   	pop    rax
  406c51:	40                   	rex
  406c52:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406c5d:	00 00                	add    BYTE PTR [rax],al
  406c5f:	00 f5                	add    ch,dh
  406c61:	17                   	(bad)
  406c62:	00 00                	add    BYTE PTR [rax],al
  406c64:	10 00                	adc    BYTE PTR [rax],al
  406c66:	02 00                	add    al,BYTE PTR [rax]
  406c68:	48                   	rex.W
  406c69:	40                   	rex
  406c6a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406c75:	00 00                	add    BYTE PTR [rax],al
  406c77:	00 0a                	add    BYTE PTR [rdx],cl
  406c79:	18 00                	sbb    BYTE PTR [rax],al
  406c7b:	00 10                	add    BYTE PTR [rax],dl
  406c7d:	00 01                	add    BYTE PTR [rcx],al
  406c7f:	00 93 06 40 00 00    	add    BYTE PTR [rbx+0x4006],dl
	...
  406c8d:	00 00                	add    BYTE PTR [rax],al
  406c8f:	00 21                	add    BYTE PTR [rcx],ah
  406c91:	18 00                	sbb    BYTE PTR [rax],al
  406c93:	00 10                	add    BYTE PTR [rax],dl
  406c95:	00 02                	add    BYTE PTR [rdx],al
  406c97:	00 50 40             	add    BYTE PTR [rax+0x40],dl
  406c9a:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406ca5:	00 00                	add    BYTE PTR [rax],al
  406ca7:	00 38                	add    BYTE PTR [rax],bh
  406ca9:	18 00                	sbb    BYTE PTR [rax],al
  406cab:	00 10                	add    BYTE PTR [rax],dl
  406cad:	00 02                	add    BYTE PTR [rdx],al
  406caf:	00 40 40             	add    BYTE PTR [rax+0x40],al
  406cb2:	40 00 00             	rex add BYTE PTR [rax],al
	...
  406cbd:	00 00                	add    BYTE PTR [rax],al
  406cbf:	00 50 18             	add    BYTE PTR [rax+0x18],dl
  406cc2:	00 00                	add    BYTE PTR [rax],al
  406cc4:	10 00                	adc    BYTE PTR [rax],al
  406cc6:	01 00                	add    DWORD PTR [rax],eax
  406cc8:	d2 1c 40             	rcr    BYTE PTR [rax+rax*2],cl
	...
  406cd7:	00 5d 18             	add    BYTE PTR [rbp+0x18],bl
  406cda:	00 00                	add    BYTE PTR [rax],al
  406cdc:	10 00                	adc    BYTE PTR [rax],al
  406cde:	01 00                	add    DWORD PTR [rax],eax
  406ce0:	ce                   	(bad)
  406ce1:	23 40 00             	and    eax,DWORD PTR [rax+0x0]
	...
  406cf0:	6b 18 00             	imul   ebx,DWORD PTR [rax],0x0
  406cf3:	00 10                	add    BYTE PTR [rax],dl
  406cf5:	00 01                	add    BYTE PTR [rcx],al
  406cf7:	00 ae 09 40 00 00    	add    BYTE PTR [rsi+0x4009],ch
	...
  406d09:	67 65 6e             	outs   dx,BYTE PTR gs:[esi]
  406d0c:	65 72 61             	gs jb  0x406d70
  406d0f:	6c                   	ins    BYTE PTR es:[rdi],dx
  406d10:	5f                   	pop    rdi
  406d11:	72 75                	jb     0x406d88
  406d13:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406d14:	74 69                	je     0x406d7f
  406d16:	6d                   	ins    DWORD PTR es:[rdi],dx
  406d17:	65 5f                	gs pop rdi
  406d19:	74 65                	je     0x406d80
  406d1b:	6d                   	ins    DWORD PTR es:[rdi],dx
  406d1c:	70 6c                	jo     0x406d8a
  406d1e:	61                   	(bad)
  406d1f:	74 65                	je     0x406d86
  406d21:	2e 6f                	outs   dx,DWORD PTR ds:[rsi]
  406d23:	00 47 45             	add    BYTE PTR [rdi+0x45],al
  406d26:	4e                   	rex.WRX
  406d27:	45 52                	rex.RB push r10
  406d29:	41                   	rex.B
  406d2a:	4c 5f                	rex.WR pop rdi
  406d2c:	52                   	push   rdx
  406d2d:	55                   	push   rbp
  406d2e:	4e 54                	rex.WRX push rsp
  406d30:	49                   	rex.WB
  406d31:	4d                   	rex.WRB
  406d32:	45 5f                	rex.RB pop r15
  406d34:	44 59                	rex.R pop rcx
  406d36:	4e                   	rex.WRX
  406d37:	41                   	rex.B
  406d38:	4d                   	rex.WRB
  406d39:	49                   	rex.WB
  406d3a:	43 5f                	rex.XB pop r15
  406d3c:	41 52                	push   r10
  406d3e:	45                   	rex.RB
  406d3f:	4e                   	rex.WRX
  406d40:	41 5f                	pop    r15
  406d42:	56                   	push   rsi
  406d43:	41 00 53 59          	add    BYTE PTR [r11+0x59],dl
  406d47:	53                   	push   rbx
  406d48:	5f                   	pop    rdi
  406d49:	77 72                	ja     0x406dbd
  406d4b:	69 74 65 00 53 59 53 	imul   esi,DWORD PTR [rbp+riz*2+0x0],0x5f535953
  406d52:	5f 
  406d53:	63 6c 6f 73          	movsxd ebp,DWORD PTR [rdi+rbp*2+0x73]
  406d57:	65 00 53 59          	add    BYTE PTR gs:[rbx+0x59],dl
  406d5b:	53                   	push   rbx
  406d5c:	5f                   	pop    rdi
  406d5d:	6d                   	ins    DWORD PTR es:[rdi],dx
  406d5e:	6d                   	ins    DWORD PTR es:[rdi],dx
  406d5f:	61                   	(bad)
  406d60:	70 00                	jo     0x406d62
  406d62:	53                   	push   rbx
  406d63:	59                   	pop    rcx
  406d64:	53                   	push   rbx
  406d65:	5f                   	pop    rdi
  406d66:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406d67:	70 65                	jo     0x406dce
  406d69:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406d6a:	61                   	(bad)
  406d6b:	74 00                	je     0x406d6d
  406d6d:	53                   	push   rbx
  406d6e:	59                   	pop    rcx
  406d6f:	53                   	push   rbx
  406d70:	5f                   	pop    rdi
  406d71:	65 78 69             	gs js  0x406ddd
  406d74:	74 5f                	je     0x406dd5
  406d76:	67 72 6f             	addr32 jb 0x406de8
  406d79:	75 70                	jne    0x406deb
  406d7b:	00 50 52             	add    BYTE PTR [rax+0x52],dl
  406d7e:	4f 54                	rex.WRXB push r12
  406d80:	5f                   	pop    rdi
  406d81:	52                   	push   rdx
  406d82:	45                   	rex.RB
  406d83:	41                   	rex.B
  406d84:	44 5f                	rex.R pop rdi
  406d86:	57                   	push   rdi
  406d87:	52                   	push   rdx
  406d88:	49 54                	rex.WB push r12
  406d8a:	45 00 50 52          	add    BYTE PTR [r8+0x52],r10b
  406d8e:	4f 54                	rex.WRXB push r12
  406d90:	5f                   	pop    rdi
  406d91:	52                   	push   rdx
  406d92:	45                   	rex.RB
  406d93:	41                   	rex.B
  406d94:	44 5f                	rex.R pop rdi
  406d96:	45 58                	rex.RB pop r8
  406d98:	45                   	rex.RB
  406d99:	43 00 4d 41          	rex.XB add BYTE PTR [r13+0x41],cl
  406d9d:	50                   	push   rax
  406d9e:	5f                   	pop    rdi
  406d9f:	50                   	push   rax
  406da0:	52                   	push   rdx
  406da1:	49 56                	rex.WB push r14
  406da3:	41 54                	push   r12
  406da5:	45 00 4d 41          	add    BYTE PTR [r13+0x41],r9b
  406da9:	50                   	push   rax
  406daa:	5f                   	pop    rdi
  406dab:	50                   	push   rax
  406dac:	52                   	push   rdx
  406dad:	49 56                	rex.WB push r14
  406daf:	41 54                	push   r12
  406db1:	45 5f                	rex.RB pop r15
  406db3:	41                   	rex.B
  406db4:	4e                   	rex.WRX
  406db5:	4f                   	rex.WRXB
  406db6:	4e 5f                	rex.WRX pop rdi
  406db8:	46                   	rex.RX
  406db9:	49 58                	rex.WB pop r8
  406dbb:	45                   	rex.RB
  406dbc:	44 5f                	rex.R pop rdi
  406dbe:	4e                   	rex.WRX
  406dbf:	4f 52                	rex.WRXB push r10
  406dc1:	45 50                	rex.RB push r8
  406dc3:	4c                   	rex.WR
  406dc4:	41                   	rex.B
  406dc5:	43                   	rex.XB
  406dc6:	45 00 41 54          	add    BYTE PTR [r9+0x54],r8b
  406dca:	5f                   	pop    rdi
  406dcb:	46                   	rex.RX
  406dcc:	44                   	rex.R
  406dcd:	43 57                	rex.XB push r15
  406dcf:	44 00 4d 55          	add    BYTE PTR [rbp+0x55],r9b
  406dd3:	54                   	push   rsp
  406dd4:	41                   	rex.B
  406dd5:	42                   	rex.X
  406dd6:	4c                   	rex.WR
  406dd7:	45 5f                	rex.RB pop r15
  406dd9:	53                   	push   rbx
  406dda:	4c                   	rex.WR
  406ddb:	4f 54                	rex.WRXB push r12
  406ddd:	5f                   	pop    rdi
  406dde:	42 59                	rex.X pop rcx
  406de0:	54                   	push   rsp
  406de1:	45 53                	rex.RB push r11
  406de3:	00 54 59 50          	add    BYTE PTR [rcx+rbx*2+0x50],dl
  406de7:	45 5f                	rex.RB pop r15
  406de9:	42                   	rex.X
  406dea:	4f                   	rex.WRXB
  406deb:	4f                   	rex.WRXB
  406dec:	4c 00 54 59 50       	rex.WR add BYTE PTR [rcx+rbx*2+0x50],r10b
  406df1:	45 5f                	rex.RB pop r15
  406df3:	49                   	rex.WB
  406df4:	36 34 00             	ss xor al,0x0
  406df7:	54                   	push   rsp
  406df8:	59                   	pop    rcx
  406df9:	50                   	push   rax
  406dfa:	45 5f                	rex.RB pop r15
  406dfc:	55                   	push   rbp
  406dfd:	36 34 00             	ss xor al,0x0
  406e00:	54                   	push   rsp
  406e01:	59                   	pop    rcx
  406e02:	50                   	push   rax
  406e03:	45 5f                	rex.RB pop r15
  406e05:	46 33 32             	rex.RX xor r14d,DWORD PTR [rdx]
  406e08:	00 54 59 50          	add    BYTE PTR [rcx+rbx*2+0x50],dl
  406e0c:	45 5f                	rex.RB pop r15
  406e0e:	46                   	rex.RX
  406e0f:	36 34 00             	ss xor al,0x0
  406e12:	54                   	push   rsp
  406e13:	59                   	pop    rcx
  406e14:	50                   	push   rax
  406e15:	45 5f                	rex.RB pop r15
  406e17:	53                   	push   rbx
  406e18:	54                   	push   rsp
  406e19:	52                   	push   rdx
  406e1a:	49                   	rex.WB
  406e1b:	4e                   	rex.WRX
  406e1c:	47 00 52 50          	rex.RXB add BYTE PTR [r10+0x50],r10b
  406e20:	46 5f                	rex.RX pop rdi
  406e22:	54                   	push   rsp
  406e23:	59                   	pop    rcx
  406e24:	50                   	push   rax
  406e25:	45 5f                	rex.RB pop r15
  406e27:	46                   	rex.RX
  406e28:	4c                   	rex.WR
  406e29:	41                   	rex.B
  406e2a:	47 00 52 50          	rex.RXB add BYTE PTR [r10+0x50],r10b
  406e2e:	46 5f                	rex.RX pop rdi
  406e30:	54                   	push   rsp
  406e31:	59                   	pop    rcx
  406e32:	50                   	push   rax
  406e33:	45 5f                	rex.RB pop r15
  406e35:	4d                   	rex.WRB
  406e36:	41 53                	push   r11
  406e38:	4b 00 52 50          	rex.WXB add BYTE PTR [r10+0x50],dl
  406e3c:	46 5f                	rex.RX pop rdi
  406e3e:	54                   	push   rsp
  406e3f:	59                   	pop    rcx
  406e40:	50                   	push   rax
  406e41:	45 00 52 50          	add    BYTE PTR [r10+0x50],r10b
  406e45:	46 5f                	rex.RX pop rdi
  406e47:	50                   	push   rax
  406e48:	52                   	push   rdx
  406e49:	45                   	rex.RB
  406e4a:	43 00 52 50          	rex.XB add BYTE PTR [r10+0x50],dl
  406e4e:	46 5f                	rex.RX pop rdi
  406e50:	4e 00 52 50          	rex.WRX add BYTE PTR [rdx+0x50],r10b
  406e54:	46 5f                	rex.RX pop rdi
  406e56:	53                   	push   rbx
  406e57:	49                   	rex.WB
  406e58:	47                   	rex.RXB
  406e59:	4e 00 52 50          	rex.WRX add BYTE PTR [rdx+0x50],r10b
  406e5d:	46 5f                	rex.RX pop rdi
  406e5f:	45 58                	rex.RB pop r8
  406e61:	50                   	push   rax
  406e62:	00 52 50             	add    BYTE PTR [rdx+0x50],dl
  406e65:	46 5f                	rex.RX pop rdi
  406e67:	44                   	rex.R
  406e68:	41 54                	push   r12
  406e6a:	41 00 72 70          	add    BYTE PTR [r10+0x70],sil
  406e6e:	66 5f                	pop    di
  406e70:	70 72                	jo     0x406ee4
  406e72:	65 63 69 73          	movsxd ebp,DWORD PTR gs:[rcx+0x73]
  406e76:	69 6f 6e 5f 66 72 6f 	imul   ebp,DWORD PTR [rdi+0x6e],0x6f72665f
  406e7d:	6d                   	ins    DWORD PTR es:[rdi],dx
  406e7e:	5f                   	pop    rdi
  406e7f:	74 79                	je     0x406efa
  406e81:	70 65                	jo     0x406ee8
  406e83:	00 2e                	add    BYTE PTR [rsi],ch
  406e85:	72 70                	jb     0x406ef7
  406e87:	66 74 5f             	data16 je 0x406ee9
  406e8a:	62 61 64 00 72       	(bad)
  406e8f:	70 66                	jo     0x406ef7
  406e91:	5f                   	pop    rdi
  406e92:	6c                   	ins    BYTE PTR es:[rdi],dx
  406e93:	69 6d 62 73 5f 66 72 	imul   ebp,DWORD PTR [rbp+0x62],0x72665f73
  406e9a:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406e9b:	6d                   	ins    DWORD PTR es:[rdi],dx
  406e9c:	5f                   	pop    rdi
  406e9d:	74 79                	je     0x406f18
  406e9f:	70 65                	jo     0x406f06
  406ea1:	00 2e                	add    BYTE PTR [rsi],ch
  406ea3:	72 70                	jb     0x406f15
  406ea5:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  406ea7:	5f                   	pop    rdi
  406ea8:	62 61 64 00 72       	(bad)
  406ead:	70 66                	jo     0x406f15
  406eaf:	5f                   	pop    rdi
  406eb0:	7a 65                	jp     0x406f17
  406eb2:	72 6f                	jb     0x406f23
  406eb4:	5f                   	pop    rdi
  406eb5:	6c                   	ins    BYTE PTR es:[rdi],dx
  406eb6:	69 6d 62 73 00 2e 72 	imul   ebp,DWORD PTR [rbp+0x62],0x722e0073
  406ebd:	70 7a                	jo     0x406f39
  406ebf:	6c                   	ins    BYTE PTR es:[rdi],dx
  406ec0:	5f                   	pop    rdi
  406ec1:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406ec3:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406ec4:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406ec7:	72 70                	jb     0x406f39
  406ec9:	7a 6c                	jp     0x406f37
  406ecb:	5f                   	pop    rdi
  406ecc:	6c                   	ins    BYTE PTR es:[rdi],dx
  406ecd:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406ece:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406ecf:	70 00                	jo     0x406ed1
  406ed1:	72 70                	jb     0x406f43
  406ed3:	66 5f                	pop    di
  406ed5:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  406ed8:	79 5f                	jns    0x406f39
  406eda:	6c                   	ins    BYTE PTR es:[rdi],dx
  406edb:	69 6d 62 73 00 2e 72 	imul   ebp,DWORD PTR [rbp+0x62],0x722e0073
  406ee2:	70 63                	jo     0x406f47
  406ee4:	6c                   	ins    BYTE PTR es:[rdi],dx
  406ee5:	5f                   	pop    rdi
  406ee6:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406ee8:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406ee9:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406eec:	72 70                	jb     0x406f5e
  406eee:	63 6c 5f 6c          	movsxd ebp,DWORD PTR [rdi+rbx*2+0x6c]
  406ef2:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406ef3:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406ef4:	70 00                	jo     0x406ef6
  406ef6:	72 70                	jb     0x406f68
  406ef8:	66 5f                	pop    di
  406efa:	6d                   	ins    DWORD PTR es:[rdi],dx
  406efb:	73 62                	jae    0x406f5f
  406efd:	00 2e                	add    BYTE PTR [rsi],ch
  406eff:	72 70                	jb     0x406f71
  406f01:	66 6d                	ins    WORD PTR es:[rdi],dx
  406f03:	5f                   	pop    rdi
  406f04:	7a 65                	jp     0x406f6b
  406f06:	72 6f                	jb     0x406f77
  406f08:	00 2e                	add    BYTE PTR [rsi],ch
  406f0a:	72 70                	jb     0x406f7c
  406f0c:	66 6d                	ins    WORD PTR es:[rdi],dx
  406f0e:	5f                   	pop    rdi
  406f0f:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f10:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f11:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f12:	70 00                	jo     0x406f14
  406f14:	2e 72 70             	cs jb  0x406f87
  406f17:	66 6d                	ins    WORD PTR es:[rdi],dx
  406f19:	5f                   	pop    rdi
  406f1a:	79 65                	jns    0x406f81
  406f1c:	73 00                	jae    0x406f1e
  406f1e:	72 70                	jb     0x406f90
  406f20:	66 5f                	pop    di
  406f22:	63 6d 70             	movsxd ebp,DWORD PTR [rbp+0x70]
  406f25:	00 2e                	add    BYTE PTR [rsi],ch
  406f27:	72 70                	jb     0x406f99
  406f29:	66 63 5f 65          	movsxd bx,DWORD PTR [rdi+0x65]
  406f2d:	71 00                	jno    0x406f2f
  406f2f:	2e 72 70             	cs jb  0x406fa2
  406f32:	66 63 5f 6c          	movsxd bx,DWORD PTR [rdi+0x6c]
  406f36:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f37:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f38:	70 00                	jo     0x406f3a
  406f3a:	2e 72 70             	cs jb  0x406fad
  406f3d:	66 63 5f 67          	movsxd bx,DWORD PTR [rdi+0x67]
  406f41:	74 00                	je     0x406f43
  406f43:	2e 72 70             	cs jb  0x406fb6
  406f46:	66 63 5f 6c          	movsxd bx,DWORD PTR [rdi+0x6c]
  406f4a:	74 00                	je     0x406f4c
  406f4c:	72 70                	jb     0x406fbe
  406f4e:	66 5f                	pop    di
  406f50:	61                   	(bad)
  406f51:	64 64 5f             	fs fs pop rdi
  406f54:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f55:	69 6d 62 73 00 2e 72 	imul   ebp,DWORD PTR [rbp+0x62],0x722e0073
  406f5c:	70 66                	jo     0x406fc4
  406f5e:	61                   	(bad)
  406f5f:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f60:	5f                   	pop    rdi
  406f61:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406f63:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406f64:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406f67:	72 70                	jb     0x406fd9
  406f69:	66 61                	data16 (bad)
  406f6b:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f6c:	5f                   	pop    rdi
  406f6d:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f6e:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f6f:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f70:	70 00                	jo     0x406f72
  406f72:	72 70                	jb     0x406fe4
  406f74:	66 5f                	pop    di
  406f76:	73 75                	jae    0x406fed
  406f78:	62 5f 6c 69 6d       	(bad)
  406f7d:	62 73 00 2e 72       	(bad)
  406f82:	70 66                	jo     0x406fea
  406f84:	73 6c                	jae    0x406ff2
  406f86:	5f                   	pop    rdi
  406f87:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406f89:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406f8a:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406f8d:	72 70                	jb     0x406fff
  406f8f:	66 73 6c             	data16 jae 0x406ffe
  406f92:	5f                   	pop    rdi
  406f93:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f94:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f95:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406f96:	70 00                	jo     0x406f98
  406f98:	72 70                	jb     0x40700a
  406f9a:	66 5f                	pop    di
  406f9c:	73 68                	jae    0x407006
  406f9e:	6c                   	ins    BYTE PTR es:[rdi],dx
  406f9f:	31 00                	xor    DWORD PTR [rax],eax
  406fa1:	2e 72 70             	cs jb  0x407014
  406fa4:	66 73 31             	data16 jae 0x406fd8
  406fa7:	5f                   	pop    rdi
  406fa8:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406faa:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406fab:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406fae:	72 70                	jb     0x407020
  406fb0:	66 73 31             	data16 jae 0x406fe4
  406fb3:	5f                   	pop    rdi
  406fb4:	6c                   	ins    BYTE PTR es:[rdi],dx
  406fb5:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406fb6:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406fb7:	70 00                	jo     0x406fb9
  406fb9:	72 70                	jb     0x40702b
  406fbb:	66 5f                	pop    di
  406fbd:	73 68                	jae    0x407027
  406fbf:	72 31                	jb     0x406ff2
  406fc1:	00 2e                	add    BYTE PTR [rsi],ch
  406fc3:	72 70                	jb     0x407035
  406fc5:	66 72 31             	data16 jb 0x406ff9
  406fc8:	5f                   	pop    rdi
  406fc9:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406fcb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406fcc:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406fcf:	72 70                	jb     0x407041
  406fd1:	66 72 31             	data16 jb 0x407005
  406fd4:	5f                   	pop    rdi
  406fd5:	6c                   	ins    BYTE PTR es:[rdi],dx
  406fd6:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406fd7:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406fd8:	70 00                	jo     0x406fda
  406fda:	72 70                	jb     0x40704c
  406fdc:	66 5f                	pop    di
  406fde:	73 68                	jae    0x407048
  406fe0:	72 5f                	jb     0x407041
  406fe2:	73 74                	jae    0x407058
  406fe4:	69 63 6b 79 00 2e 72 	imul   esp,DWORD PTR [rbx+0x6b],0x722e0079
  406feb:	70 66                	jo     0x407053
  406fed:	73 73                	jae    0x407062
  406fef:	5f                   	pop    rdi
  406ff0:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  406ff2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  406ff3:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  406ff6:	72 70                	jb     0x407068
  406ff8:	66 73 73             	data16 jae 0x40706e
  406ffb:	5f                   	pop    rdi
  406ffc:	6c                   	ins    BYTE PTR es:[rdi],dx
  406ffd:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406ffe:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  406fff:	70 00                	jo     0x407001
  407001:	2e 72 70             	cs jb  0x407074
  407004:	66 73 73             	data16 jae 0x40707a
  407007:	5f                   	pop    rdi
  407008:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407009:	72 61                	jb     0x40706c
  40700b:	6c                   	ins    BYTE PTR es:[rdi],dx
  40700c:	6c                   	ins    BYTE PTR es:[rdi],dx
  40700d:	00 2e                	add    BYTE PTR [rsi],ch
  40700f:	72 70                	jb     0x407081
  407011:	66 73 73             	data16 jae 0x407087
  407014:	5f                   	pop    rdi
  407015:	7a 65                	jp     0x40707c
  407017:	72 6f                	jb     0x407088
  407019:	61                   	(bad)
  40701a:	6c                   	ins    BYTE PTR es:[rdi],dx
  40701b:	6c                   	ins    BYTE PTR es:[rdi],dx
  40701c:	00 2e                	add    BYTE PTR [rsi],ch
  40701e:	72 70                	jb     0x407090
  407020:	66 73 73             	data16 jae 0x407096
  407023:	5f                   	pop    rdi
  407024:	7a 6c                	jp     0x407092
  407026:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407027:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407028:	70 00                	jo     0x40702a
  40702a:	2e 72 70             	cs jb  0x40709d
  40702d:	66 73 73             	data16 jae 0x4070a3
  407030:	5f                   	pop    rdi
  407031:	66 69 6e 69 73 68    	imul   bp,WORD PTR [rsi+0x69],0x6873
  407037:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  40703a:	66 5f                	pop    di
  40703c:	73 68                	jae    0x4070a6
  40703e:	6c                   	ins    BYTE PTR es:[rdi],dx
  40703f:	5f                   	pop    rdi
  407040:	65 78 61             	gs js  0x4070a4
  407043:	63 74 00 2e          	movsxd esi,DWORD PTR [rax+rax*1+0x2e]
  407047:	72 70                	jb     0x4070b9
  407049:	66 73 65             	data16 jae 0x4070b1
  40704c:	5f                   	pop    rdi
  40704d:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40704f:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407050:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407053:	72 70                	jb     0x4070c5
  407055:	66 73 65             	data16 jae 0x4070bd
  407058:	5f                   	pop    rdi
  407059:	6c                   	ins    BYTE PTR es:[rdi],dx
  40705a:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40705b:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40705c:	70 00                	jo     0x40705e
  40705e:	72 70                	jb     0x4070d0
  407060:	66 5f                	pop    di
  407062:	74 65                	je     0x4070c9
  407064:	73 74                	jae    0x4070da
  407066:	5f                   	pop    rdi
  407067:	62 69 74 00 2e       	(bad)
  40706c:	72 70                	jb     0x4070de
  40706e:	66 74 62             	data16 je 0x4070d3
  407071:	5f                   	pop    rdi
  407072:	7a 65                	jp     0x4070d9
  407074:	72 6f                	jb     0x4070e5
  407076:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407079:	66 5f                	pop    di
  40707b:	61                   	(bad)
  40707c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40707d:	79 5f                	jns    0x4070de
  40707f:	6c                   	ins    BYTE PTR es:[rdi],dx
  407080:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407081:	77 5f                	ja     0x4070e2
  407083:	62 69 74 73 00       	(bad)
  407088:	2e 72 70             	cs jb  0x4070fb
  40708b:	66 61                	data16 (bad)
  40708d:	6c                   	ins    BYTE PTR es:[rdi],dx
  40708e:	62 5f 7a 65 72       	(bad) {k5}
  407093:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407094:	00 2e                	add    BYTE PTR [rsi],ch
  407096:	72 70                	jb     0x407108
  407098:	66 61                	data16 (bad)
  40709a:	6c                   	ins    BYTE PTR es:[rdi],dx
  40709b:	62 5f 66 75 6c       	(bad)
  4070a0:	6c                   	ins    BYTE PTR es:[rdi],dx
  4070a1:	00 2e                	add    BYTE PTR [rsi],ch
  4070a3:	72 70                	jb     0x407115
  4070a5:	66 61                	data16 (bad)
  4070a7:	6c                   	ins    BYTE PTR es:[rdi],dx
  4070a8:	62 5f 72 65 6d       	(bad)
  4070ad:	00 2e                	add    BYTE PTR [rsi],ch
  4070af:	72 70                	jb     0x407121
  4070b1:	66 61                	data16 (bad)
  4070b3:	6c                   	ins    BYTE PTR es:[rdi],dx
  4070b4:	62 5f 79 65 73       	(bad) {k5}
  4070b9:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  4070bc:	66 5f                	pop    di
  4070be:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4070bf:	62 6a 65 63 74       	(bad)
  4070c4:	5f                   	pop    rdi
  4070c5:	69 6e 69 74 00 2e 72 	imul   ebp,DWORD PTR [rsi+0x69],0x722e0074
  4070cc:	70 66                	jo     0x407134
  4070ce:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4070cf:	69 5f 62 61 64 00 2e 	imul   ebx,DWORD PTR [rdi+0x62],0x2e006461
  4070d6:	72 70                	jb     0x407148
  4070d8:	66 6f                	outs   dx,WORD PTR ds:[rsi]
  4070da:	69 5f 64 6f 6e 65 00 	imul   ebx,DWORD PTR [rdi+0x64],0x656e6f
  4070e1:	72 70                	jb     0x407153
  4070e3:	66 5f                	pop    di
  4070e5:	72 6f                	jb     0x407156
  4070e7:	75 6e                	jne    0x407157
  4070e9:	64 5f                	fs pop rdi
  4070eb:	66 72 6f             	data16 jb 0x40715d
  4070ee:	6d                   	ins    DWORD PTR es:[rdi],dx
  4070ef:	5f                   	pop    rdi
  4070f0:	69 6e 74 65 67 65 72 	imul   ebp,DWORD PTR [rsi+0x74],0x72656765
  4070f7:	00 2e                	add    BYTE PTR [rsi],ch
  4070f9:	72 70                	jb     0x40716b
  4070fb:	66 72 5f             	data16 jb 0x40715d
  4070fe:	7a 65                	jp     0x407165
  407100:	72 6f                	jb     0x407171
  407102:	00 2e                	add    BYTE PTR [rsi],ch
  407104:	72 70                	jb     0x407176
  407106:	66 72 5f             	data16 jb 0x407168
  407109:	62 61 64 00 2e       	(bad)
  40710e:	72 70                	jb     0x407180
  407110:	66 72 5f             	data16 jb 0x407172
  407113:	6c                   	ins    BYTE PTR es:[rdi],dx
  407114:	65 66 74 00          	gs data16 je 0x407118
  407118:	2e 72 70             	cs jb  0x40718b
  40711b:	66 72 5f             	data16 jb 0x40717d
  40711e:	72 5f                	jb     0x40717f
  407120:	77 6f                	ja     0x407191
  407122:	72 64                	jb     0x407188
  407124:	00 2e                	add    BYTE PTR [rsi],ch
  407126:	72 70                	jb     0x407198
  407128:	66 72 5f             	data16 jb 0x40718a
  40712b:	72 5f                	jb     0x40718c
  40712d:	72 6f                	jb     0x40719e
  40712f:	75 6e                	jne    0x40719f
  407131:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  407134:	72 70                	jb     0x4071a6
  407136:	66 72 5f             	data16 jb 0x407198
  407139:	72 5f                	jb     0x40719a
  40713b:	73 74                	jae    0x4071b1
  40713d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40713e:	72 65                	jb     0x4071a5
  407140:	00 2e                	add    BYTE PTR [rsi],ch
  407142:	72 70                	jb     0x4071b4
  407144:	66 72 5f             	data16 jb 0x4071a6
  407147:	72 5f                	jb     0x4071a8
  407149:	72 65                	jb     0x4071b0
  40714b:	73 74                	jae    0x4071c1
  40714d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40714e:	72 65                	jb     0x4071b5
  407150:	63 00                	movsxd eax,DWORD PTR [rax]
  407152:	2e 72 70             	cs jb  0x4071c5
  407155:	66 72 5f             	data16 jb 0x4071b7
  407158:	73 74                	jae    0x4071ce
  40715a:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40715b:	72 65                	jb     0x4071c2
  40715d:	5f                   	pop    rdi
  40715e:	6d                   	ins    DWORD PTR es:[rdi],dx
  40715f:	65 74 61             	gs je  0x4071c3
  407162:	00 2e                	add    BYTE PTR [rsi],ch
  407164:	72 70                	jb     0x4071d6
  407166:	66 72 5f             	data16 jb 0x4071c8
  407169:	69 6e 63 00 2e 72 70 	imul   ebp,DWORD PTR [rsi+0x63],0x70722e00
  407170:	66 72 5f             	data16 jb 0x4071d2
  407173:	69 6e 63 5f 6c 6f 6f 	imul   ebp,DWORD PTR [rsi+0x63],0x6f6f6c5f
  40717a:	70 00                	jo     0x40717c
  40717c:	2e 72 70             	cs jb  0x4071ef
  40717f:	66 72 5f             	data16 jb 0x4071e1
  407182:	69 6e 63 5f 63 61 72 	imul   ebp,DWORD PTR [rsi+0x63],0x7261635f
  407189:	72 79                	jb     0x407204
  40718b:	5f                   	pop    rdi
  40718c:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40718d:	75 74                	jne    0x407203
  40718f:	00 2e                	add    BYTE PTR [rsi],ch
  407191:	72 70                	jb     0x407203
  407193:	66 72 5f             	data16 jb 0x4071f5
  407196:	69 6e 63 5f 64 6f 6e 	imul   ebp,DWORD PTR [rsi+0x63],0x6e6f645f
  40719d:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4071a0:	72 70                	jb     0x407212
  4071a2:	66 72 5f             	data16 jb 0x407204
  4071a5:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4071a6:	76 65                	jbe    0x40720d
  4071a8:	72 66                	jb     0x407210
  4071aa:	6c                   	ins    BYTE PTR es:[rdi],dx
  4071ab:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4071ac:	77 00                	ja     0x4071ae
  4071ae:	2e 72 70             	cs jb  0x407221
  4071b1:	66 72 5f             	data16 jb 0x407213
  4071b4:	63 68 65             	movsxd ebp,DWORD PTR [rax+0x65]
  4071b7:	63 6b 5f             	movsxd ebp,DWORD PTR [rbx+0x5f]
  4071ba:	66 75 6c             	data16 jne 0x407229
  4071bd:	6c                   	ins    BYTE PTR es:[rdi],dx
  4071be:	77 6f                	ja     0x40722f
  4071c0:	72 64                	jb     0x407226
  4071c2:	00 2e                	add    BYTE PTR [rsi],ch
  4071c4:	72 70                	jb     0x407236
  4071c6:	66 72 5f             	data16 jb 0x407228
  4071c9:	6c                   	ins    BYTE PTR es:[rdi],dx
  4071ca:	5f                   	pop    rdi
  4071cb:	73 72                	jae    0x40723f
  4071cd:	63 00                	movsxd eax,DWORD PTR [rax]
  4071cf:	2e 72 70             	cs jb  0x407242
  4071d2:	66 72 5f             	data16 jb 0x407234
  4071d5:	6c                   	ins    BYTE PTR es:[rdi],dx
  4071d6:	5f                   	pop    rdi
  4071d7:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4071d8:	65 78 74             	gs js  0x40724f
  4071db:	00 2e                	add    BYTE PTR [rsi],ch
  4071dd:	72 70                	jb     0x40724f
  4071df:	66 72 5f             	data16 jb 0x407241
  4071e2:	6c                   	ins    BYTE PTR es:[rdi],dx
  4071e3:	5f                   	pop    rdi
  4071e4:	64 69 72 65 63 74 00 	imul   esi,DWORD PTR fs:[rdx+0x65],0x2e007463
  4071eb:	2e 
  4071ec:	72 70                	jb     0x40725e
  4071ee:	66 72 5f             	data16 jb 0x407250
  4071f1:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4071f3:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4071f4:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4071f7:	72 66                	jb     0x40725f
  4071f9:	66 75 5f             	data16 jne 0x40725b
  4071fc:	7a 65                	jp     0x407263
  4071fe:	72 6f                	jb     0x40726f
  407200:	00 2e                	add    BYTE PTR [rsi],ch
  407202:	72 66                	jb     0x40726a
  407204:	66 75 5f             	data16 jne 0x407266
  407207:	62 61 64 00 2e       	(bad)
  40720c:	72 66                	jb     0x407274
  40720e:	66 75 5f             	data16 jne 0x407270
  407211:	62 69 74 73 00       	(bad)
  407216:	2e 72 66             	cs jb  0x40727f
  407219:	66 75 5f             	data16 jne 0x40727b
  40721c:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40721d:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  407220:	72 66                	jb     0x407288
  407222:	66 75 5f             	data16 jne 0x407284
  407225:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407226:	65 78 74             	gs js  0x40729d
  407229:	00 2e                	add    BYTE PTR [rsi],ch
  40722b:	72 66                	jb     0x407293
  40722d:	66 75 5f             	data16 jne 0x40728f
  407230:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407232:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407233:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407236:	72 66                	jb     0x40729e
  407238:	66 69 5f 70 6f 73    	imul   bx,WORD PTR [rdi+0x70],0x736f
  40723e:	00 2e                	add    BYTE PTR [rsi],ch
  407240:	72 66                	jb     0x4072a8
  407242:	66 69 5f 64 6f 6e    	imul   bx,WORD PTR [rdi+0x64],0x6e6f
  407248:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  40724b:	72 66                	jb     0x4072b3
  40724d:	66 64 5f             	fs pop di
  407250:	62 61 64 00 2e       	(bad)
  407255:	72 66                	jb     0x4072bd
  407257:	66 64 5f             	fs pop di
  40725a:	73 75                	jae    0x4072d1
  40725c:	62                   	(bad)
  40725d:	00 2e                	add    BYTE PTR [rsi],ch
  40725f:	72 66                	jb     0x4072c7
  407261:	66 64 5f             	fs pop di
  407264:	68 61 76 65 00       	push   0x657661
  407269:	2e 72 66             	cs jb  0x4072d2
  40726c:	66 64 5f             	fs pop di
  40726f:	7a 65                	jp     0x4072d6
  407271:	72 6f                	jb     0x4072e2
  407273:	00 2e                	add    BYTE PTR [rsi],ch
  407275:	72 66                	jb     0x4072dd
  407277:	66 64 5f             	fs pop di
  40727a:	62 69 74 73 00       	(bad)
  40727f:	2e 72 66             	cs jb  0x4072e8
  407282:	66 64 5f             	fs pop di
  407285:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407286:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  407289:	72 66                	jb     0x4072f1
  40728b:	66 64 5f             	fs pop di
  40728e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40728f:	65 78 74             	gs js  0x407306
  407292:	00 2e                	add    BYTE PTR [rsi],ch
  407294:	72 66                	jb     0x4072fc
  407296:	66 64 5f             	fs pop di
  407299:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40729b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40729c:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  40729f:	72 70                	jb     0x407311
  4072a1:	66 63 76 5f          	movsxd si,DWORD PTR [rsi+0x5f]
  4072a5:	62 61 64 00 2e       	(bad)
  4072aa:	72 70                	jb     0x40731c
  4072ac:	66 63 76 5f          	movsxd si,DWORD PTR [rsi+0x5f]
  4072b0:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4072b2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4072b3:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  4072b7:	66 5f                	pop    di
  4072b9:	61                   	(bad)
  4072ba:	64 64 5f             	fs fs pop rdi
  4072bd:	63 6f 72             	movsxd ebp,DWORD PTR [rdi+0x72]
  4072c0:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4072c3:	72 70                	jb     0x407335
  4072c5:	66 61                	data16 (bad)
  4072c7:	63 5f 62             	movsxd ebx,DWORD PTR [rdi+0x62]
  4072ca:	61                   	(bad)
  4072cb:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  4072ce:	72 70                	jb     0x407340
  4072d0:	66 61                	data16 (bad)
  4072d2:	63 5f 61             	movsxd ebx,DWORD PTR [rdi+0x61]
  4072d5:	65 78 70             	gs js  0x407348
  4072d8:	00 2e                	add    BYTE PTR [rsi],ch
  4072da:	72 70                	jb     0x40734c
  4072dc:	66 61                	data16 (bad)
  4072de:	63 5f 61             	movsxd ebx,DWORD PTR [rdi+0x61]
  4072e1:	6c                   	ins    BYTE PTR es:[rdi],dx
  4072e2:	69 67 6e 65 64 00 2e 	imul   esp,DWORD PTR [rdi+0x6e],0x2e006465
  4072e9:	72 70                	jb     0x40735b
  4072eb:	66 61                	data16 (bad)
  4072ed:	63 5f 73             	movsxd ebx,DWORD PTR [rdi+0x73]
  4072f0:	75 62                	jne    0x407354
  4072f2:	00 2e                	add    BYTE PTR [rsi],ch
  4072f4:	72 70                	jb     0x407366
  4072f6:	66 61                	data16 (bad)
  4072f8:	63 5f 72             	movsxd ebx,DWORD PTR [rdi+0x72]
  4072fb:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4072fc:	75 6e                	jne    0x40736c
  4072fe:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  407301:	72 70                	jb     0x407373
  407303:	66 61                	data16 (bad)
  407305:	63 5f 7a             	movsxd ebx,DWORD PTR [rdi+0x7a]
  407308:	65 72 6f             	gs jb  0x40737a
  40730b:	00 2e                	add    BYTE PTR [rsi],ch
  40730d:	72 70                	jb     0x40737f
  40730f:	66 61                	data16 (bad)
  407311:	63 5f 62             	movsxd ebx,DWORD PTR [rdi+0x62]
  407314:	69 67 67 65 72 5f 62 	imul   esp,DWORD PTR [rdi+0x67],0x625f7265
  40731b:	00 2e                	add    BYTE PTR [rsi],ch
  40731d:	72 70                	jb     0x40738f
  40731f:	66 61                	data16 (bad)
  407321:	63 5f 64             	movsxd ebx,DWORD PTR [rdi+0x64]
  407324:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407325:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407326:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  40732a:	66 5f                	pop    di
  40732c:	68 69 67 68 6c       	push   0x6c686769
  407331:	65 6e                	outs   dx,BYTE PTR gs:[rsi]
  407333:	33 32                	xor    esi,DWORD PTR [rdx]
  407335:	00 2e                	add    BYTE PTR [rsi],ch
  407337:	72 68                	jb     0x4073a1
  407339:	33 32                	xor    esi,DWORD PTR [rdx]
  40733b:	5f                   	pop    rdi
  40733c:	6c                   	ins    BYTE PTR es:[rdi],dx
  40733d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40733e:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40733f:	70 00                	jo     0x407341
  407341:	2e 72 68             	cs jb  0x4073ac
  407344:	33 32                	xor    esi,DWORD PTR [rdx]
  407346:	5f                   	pop    rdi
  407347:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407349:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40734a:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  40734e:	66 5f                	pop    di
  407350:	73 68                	jae    0x4073ba
  407352:	6c                   	ins    BYTE PTR es:[rdi],dx
  407353:	33 32                	xor    esi,DWORD PTR [rdx]
  407355:	5f                   	pop    rdi
  407356:	73 6c                	jae    0x4073c4
  407358:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407359:	74 73                	je     0x4073ce
  40735b:	32 00                	xor    al,BYTE PTR [rax]
  40735d:	2e 72 73             	cs jb  0x4073d3
  407360:	33 32                	xor    esi,DWORD PTR [rdx]
  407362:	32 5f 64             	xor    bl,BYTE PTR [rdi+0x64]
  407365:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407366:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407367:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  40736a:	72 73                	jb     0x4073df
  40736c:	33 32                	xor    esi,DWORD PTR [rdx]
  40736e:	32 5f 6c             	xor    bl,BYTE PTR [rdi+0x6c]
  407371:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407372:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407373:	70 00                	jo     0x407375
  407375:	72 70                	jb     0x4073e7
  407377:	66 5f                	pop    di
  407379:	67 65 74 33          	addr32 gs je 0x4073b0
  40737d:	32 00                	xor    al,BYTE PTR [rax]
  40737f:	2e 72 67             	cs jb  0x4073e9
  407382:	33 32                	xor    esi,DWORD PTR [rdx]
  407384:	5f                   	pop    rdi
  407385:	7a 65                	jp     0x4073ec
  407387:	72 6f                	jb     0x4073f8
  407389:	00 2e                	add    BYTE PTR [rsi],ch
  40738b:	72 67                	jb     0x4073f4
  40738d:	33 32                	xor    esi,DWORD PTR [rdx]
  40738f:	5f                   	pop    rdi
  407390:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407392:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407393:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  407397:	66 5f                	pop    di
  407399:	33 32                	xor    esi,DWORD PTR [rdx]
  40739b:	5f                   	pop    rdi
  40739c:	74 6f                	je     0x40740d
  40739e:	5f                   	pop    rdi
  40739f:	75 36                	jne    0x4073d7
  4073a1:	34 00                	xor    al,0x0
  4073a3:	2e 72 33             	cs jb  0x4073d9
  4073a6:	32 75 5f             	xor    dh,BYTE PTR [rbp+0x5f]
  4073a9:	6c                   	ins    BYTE PTR es:[rdi],dx
  4073aa:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4073ab:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4073ac:	70 00                	jo     0x4073ae
  4073ae:	2e 72 33             	cs jb  0x4073e4
  4073b1:	32 75 5f             	xor    dh,BYTE PTR [rbp+0x5f]
  4073b4:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4073b6:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4073b7:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4073ba:	72 33                	jb     0x4073ef
  4073bc:	32 75 5f             	xor    dh,BYTE PTR [rbp+0x5f]
  4073bf:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4073c0:	65 78 74             	gs js  0x407437
  4073c3:	00 2e                	add    BYTE PTR [rsi],ch
  4073c5:	72 33                	jb     0x4073fa
  4073c7:	32 75 5f             	xor    dh,BYTE PTR [rbp+0x5f]
  4073ca:	6c                   	ins    BYTE PTR es:[rdi],dx
  4073cb:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4073cc:	77 00                	ja     0x4073ce
  4073ce:	47 5f                	rex.RXB pop r15
  4073d0:	42 00 47 5f          	rex.X add BYTE PTR [rdi+0x5f],al
  4073d4:	41 32 00             	xor    al,BYTE PTR [r8]
  4073d7:	47 5f                	rex.RXB pop r15
  4073d9:	41 33 00             	xor    eax,DWORD PTR [r8]
  4073dc:	47 5f                	rex.RXB pop r15
  4073de:	41 35 00 47 5f 4e    	rex.B xor eax,0x4e5f4700
  4073e4:	43                   	rex.XB
  4073e5:	4f                   	rex.WRXB
  4073e6:	45                   	rex.RB
  4073e7:	46 00 47 5f          	rex.RX add BYTE PTR [rdi+0x5f],r8b
  4073eb:	4e                   	rex.WRX
  4073ec:	46                   	rex.RX
  4073ed:	46 54                	rex.RX push rsp
  4073ef:	00 47 5f             	add    BYTE PTR [rdi+0x5f],al
  4073f2:	53                   	push   rbx
  4073f3:	49 5a                	rex.WB pop r10
  4073f5:	45 00 72 70          	add    BYTE PTR [r10+0x70],r14b
  4073f9:	66 5f                	pop    di
  4073fb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4073fc:	66 5f                	pop    di
  4073fe:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4073ff:	65 67 5f             	gs addr32 pop rdi
  407402:	68 61 6c 66 00       	push   0x666c61
  407407:	72 70                	jb     0x407479
  407409:	66 5f                	pop    di
  40740b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40740c:	66 5f                	pop    di
  40740e:	6b 33 5f             	imul   esi,DWORD PTR [rbx],0x5f
  407411:	66 77 64             	data16 ja 0x407478
  407414:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407417:	66 5f                	pop    di
  407419:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40741a:	66 5f                	pop    di
  40741c:	6b 33 5f             	imul   esi,DWORD PTR [rbx],0x5f
  40741f:	69 6e 76 00 72 70 66 	imul   ebp,DWORD PTR [rsi+0x76],0x66707200
  407426:	5f                   	pop    rdi
  407427:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407428:	66 5f                	pop    di
  40742a:	63 31                	movsxd esi,DWORD PTR [rcx]
  40742c:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  40742f:	66 5f                	pop    di
  407431:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407432:	66 5f                	pop    di
  407434:	63 32                	movsxd esi,DWORD PTR [rdx]
  407436:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407439:	66 5f                	pop    di
  40743b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40743c:	66 5f                	pop    di
  40743e:	73 31                	jae    0x407471
  407440:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407443:	66 5f                	pop    di
  407445:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407446:	66 5f                	pop    di
  407448:	73 32                	jae    0x40747c
  40744a:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  40744d:	66 5f                	pop    di
  40744f:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407450:	66 5f                	pop    di
  407452:	72 6f                	jb     0x4074c3
  407454:	74 5f                	je     0x4074b5
  407456:	66 77 64             	data16 ja 0x4074bd
  407459:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  40745c:	66 5f                	pop    di
  40745e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40745f:	66 5f                	pop    di
  407461:	72 6f                	jb     0x4074d2
  407463:	74 5f                	je     0x4074c4
  407465:	69 6e 76 00 72 70 66 	imul   ebp,DWORD PTR [rsi+0x76],0x66707200
  40746c:	5f                   	pop    rdi
  40746d:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40746e:	66 5f                	pop    di
  407470:	68 61 6c 66 00       	push   0x666c61
  407475:	72 70                	jb     0x4074e7
  407477:	66 5f                	pop    di
  407479:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40747a:	66 5f                	pop    di
  40747c:	63 65 69             	movsxd esp,DWORD PTR [rbp+0x69]
  40747f:	6c                   	ins    BYTE PTR es:[rdi],dx
  407480:	5f                   	pop    rdi
  407481:	6c                   	ins    BYTE PTR es:[rdi],dx
  407482:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407483:	67 32 00             	xor    al,BYTE PTR [eax]
  407486:	2e 72 70             	cs jb  0x4074f9
  407489:	66 5f                	pop    di
  40748b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40748c:	63 6c 5f 7a          	movsxd ebp,DWORD PTR [rdi+rbx*2+0x7a]
  407490:	65 72 6f             	gs jb  0x407502
  407493:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407496:	66 5f                	pop    di
  407498:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407499:	66 5f                	pop    di
  40749b:	63 68 6f             	movsxd ebp,DWORD PTR [rax+0x6f]
  40749e:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40749f:	73 65                	jae    0x407506
  4074a1:	5f                   	pop    rdi
  4074a2:	67 65 6f             	outs   dx,DWORD PTR gs:[esi]
  4074a5:	6d                   	ins    DWORD PTR es:[rdi],dx
  4074a6:	00 2e                	add    BYTE PTR [rsi],ch
  4074a8:	72 70                	jb     0x40751a
  4074aa:	66 5f                	pop    di
  4074ac:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074ad:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  4074b0:	62 5f 6c 6f 6f       	(bad)
  4074b5:	70 00                	jo     0x4074b7
  4074b7:	2e 72 70             	cs jb  0x40752a
  4074ba:	66 5f                	pop    di
  4074bc:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074bd:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  4074c0:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4074c2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074c3:	65 5f                	gs pop rdi
  4074c5:	73 65                	jae    0x40752c
  4074c7:	61                   	(bad)
  4074c8:	72 63                	jb     0x40752d
  4074ca:	68 00 2e 72 70       	push   0x70722e00
  4074cf:	66 5f                	pop    di
  4074d1:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074d2:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  4074d5:	61                   	(bad)
  4074d6:	33 5f 6c             	xor    ebx,DWORD PTR [rdi+0x6c]
  4074d9:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4074da:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4074db:	70 00                	jo     0x4074dd
  4074dd:	2e 72 70             	cs jb  0x407550
  4074e0:	66 5f                	pop    di
  4074e2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074e3:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  4074e6:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074e7:	65 78 74             	gs js  0x40755e
  4074ea:	5f                   	pop    rdi
  4074eb:	62                   	(bad)
  4074ec:	00 2e                	add    BYTE PTR [rsi],ch
  4074ee:	72 70                	jb     0x407560
  4074f0:	66 5f                	pop    di
  4074f2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4074f3:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  4074f6:	61                   	(bad)
  4074f7:	35 5f 6c 6f 6f       	xor    eax,0x6f6f6c5f
  4074fc:	70 00                	jo     0x4074fe
  4074fe:	2e 72 70             	cs jb  0x407571
  407501:	66 5f                	pop    di
  407503:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407504:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  407507:	61                   	(bad)
  407508:	35 5f 64 6f 6e       	xor    eax,0x6e6f645f
  40750d:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407510:	72 70                	jb     0x407582
  407512:	66 5f                	pop    di
  407514:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407515:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  407518:	63 61 6e             	movsxd esp,DWORD PTR [rcx+0x6e]
  40751b:	64 69 64 61 74 65 5f 	imul   esp,DWORD PTR fs:[rcx+riz*2+0x74],0x656e5f65
  407522:	6e 65 
  407524:	78 74                	js     0x40759a
  407526:	00 2e                	add    BYTE PTR [rsi],ch
  407528:	72 70                	jb     0x40759a
  40752a:	66 5f                	pop    di
  40752c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40752d:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  407530:	62 61 64 00 2e       	(bad)
  407535:	72 70                	jb     0x4075a7
  407537:	66 5f                	pop    di
  407539:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40753a:	63 67 5f             	movsxd esp,DWORD PTR [rdi+0x5f]
  40753d:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40753f:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407540:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  407544:	66 5f                	pop    di
  407546:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407547:	66 5f                	pop    di
  407549:	6d                   	ins    DWORD PTR es:[rdi],dx
  40754a:	61                   	(bad)
  40754b:	6b 65 5f 74          	imul   esp,DWORD PTR [rbp+0x5f],0x74
  40754f:	77 00                	ja     0x407551
  407551:	2e 72 70             	cs jb  0x4075c4
  407554:	66 5f                	pop    di
  407556:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407557:	6d                   	ins    DWORD PTR es:[rdi],dx
  407558:	74 66                	je     0x4075c0
  40755a:	5f                   	pop    rdi
  40755b:	73 69                	jae    0x4075c6
  40755d:	67 6e                	outs   dx,BYTE PTR ds:[esi]
  40755f:	5f                   	pop    rdi
  407560:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407561:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  407564:	72 70                	jb     0x4075d6
  407566:	66 5f                	pop    di
  407568:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407569:	6d                   	ins    DWORD PTR es:[rdi],dx
  40756a:	74 66                	je     0x4075d2
  40756c:	5f                   	pop    rdi
  40756d:	6c                   	ins    BYTE PTR es:[rdi],dx
  40756e:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40756f:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407570:	70 00                	jo     0x407572
  407572:	2e 72 70             	cs jb  0x4075e5
  407575:	66 5f                	pop    di
  407577:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407578:	6d                   	ins    DWORD PTR es:[rdi],dx
  407579:	74 66                	je     0x4075e1
  40757b:	5f                   	pop    rdi
  40757c:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40757e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40757f:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407582:	72 70                	jb     0x4075f4
  407584:	66 5f                	pop    di
  407586:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407587:	6d                   	ins    DWORD PTR es:[rdi],dx
  407588:	74 66                	je     0x4075f0
  40758a:	5f                   	pop    rdi
  40758b:	68 61 76 65 5f       	push   0x5f657661
  407590:	70 68                	jo     0x4075fa
  407592:	61                   	(bad)
  407593:	73 65                	jae    0x4075fa
  407595:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407598:	66 5f                	pop    di
  40759a:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40759b:	66 5f                	pop    di
  40759d:	64 69 66 32 00 2e 72 	imul   esp,DWORD PTR fs:[rsi+0x32],0x70722e00
  4075a4:	70 
  4075a5:	66 5f                	pop    di
  4075a7:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075a8:	64 32 5f 62          	xor    bl,BYTE PTR fs:[rdi+0x62]
  4075ac:	61                   	(bad)
  4075ad:	73 65                	jae    0x407614
  4075af:	00 2e                	add    BYTE PTR [rsi],ch
  4075b1:	72 70                	jb     0x407623
  4075b3:	66 5f                	pop    di
  4075b5:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075b6:	64 32 5f 64          	xor    bl,BYTE PTR fs:[rdi+0x64]
  4075ba:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4075bb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075bc:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4075bf:	72 70                	jb     0x407631
  4075c1:	66 5f                	pop    di
  4075c3:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075c4:	64 32 5f 76          	xor    bl,BYTE PTR fs:[rdi+0x76]
  4075c8:	65 63 00             	movsxd eax,DWORD PTR gs:[rax]
  4075cb:	2e 72 70             	cs jb  0x40763e
  4075ce:	66 5f                	pop    di
  4075d0:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075d1:	64 32 5f 73          	xor    bl,BYTE PTR fs:[rdi+0x73]
  4075d5:	63 61 6c             	movsxd esp,DWORD PTR [rcx+0x6c]
  4075d8:	61                   	(bad)
  4075d9:	72 00                	jb     0x4075db
  4075db:	2e 72 70             	cs jb  0x40764e
  4075de:	66 5f                	pop    di
  4075e0:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075e1:	64 32 5f 6e          	xor    bl,BYTE PTR fs:[rdi+0x6e]
  4075e5:	65 78 74             	gs js  0x40765c
  4075e8:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  4075eb:	66 5f                	pop    di
  4075ed:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075ee:	66 5f                	pop    di
  4075f0:	64 69 74 32 00 2e 72 	imul   esi,DWORD PTR fs:[rdx+rsi*1+0x0],0x6670722e
  4075f7:	70 66 
  4075f9:	5f                   	pop    rdi
  4075fa:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4075fb:	69 32 5f 62 61 73    	imul   esi,DWORD PTR [rdx],0x7361625f
  407601:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407604:	72 70                	jb     0x407676
  407606:	66 5f                	pop    di
  407608:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407609:	69 32 5f 64 6f 6e    	imul   esi,DWORD PTR [rdx],0x6e6f645f
  40760f:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407612:	72 70                	jb     0x407684
  407614:	66 5f                	pop    di
  407616:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407617:	69 32 5f 76 65 63    	imul   esi,DWORD PTR [rdx],0x6365765f
  40761d:	00 2e                	add    BYTE PTR [rsi],ch
  40761f:	72 70                	jb     0x407691
  407621:	66 5f                	pop    di
  407623:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407624:	69 32 5f 73 63 61    	imul   esi,DWORD PTR [rdx],0x6163735f
  40762a:	6c                   	ins    BYTE PTR es:[rdi],dx
  40762b:	61                   	(bad)
  40762c:	72 00                	jb     0x40762e
  40762e:	2e 72 70             	cs jb  0x4076a1
  407631:	66 5f                	pop    di
  407633:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407634:	69 32 5f 6e 65 78    	imul   esi,DWORD PTR [rdx],0x78656e5f
  40763a:	74 00                	je     0x40763c
  40763c:	72 70                	jb     0x4076ae
  40763e:	66 5f                	pop    di
  407640:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407641:	66 5f                	pop    di
  407643:	64 69 66 33 00 2e 72 	imul   esp,DWORD PTR fs:[rsi+0x33],0x70722e00
  40764a:	70 
  40764b:	66 5f                	pop    di
  40764d:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40764e:	64 33 5f 62          	xor    ebx,DWORD PTR fs:[rdi+0x62]
  407652:	61                   	(bad)
  407653:	73 65                	jae    0x4076ba
  407655:	00 2e                	add    BYTE PTR [rsi],ch
  407657:	72 70                	jb     0x4076c9
  407659:	66 5f                	pop    di
  40765b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40765c:	64 33 5f 64          	xor    ebx,DWORD PTR fs:[rdi+0x64]
  407660:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407661:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407662:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407665:	72 70                	jb     0x4076d7
  407667:	66 5f                	pop    di
  407669:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40766a:	64 33 5f 6a          	xor    ebx,DWORD PTR fs:[rdi+0x6a]
  40766e:	00 2e                	add    BYTE PTR [rsi],ch
  407670:	72 70                	jb     0x4076e2
  407672:	66 5f                	pop    di
  407674:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407675:	64 33 5f 6e          	xor    ebx,DWORD PTR fs:[rdi+0x6e]
  407679:	65 78 74             	gs js  0x4076f0
  40767c:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  40767f:	66 5f                	pop    di
  407681:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407682:	66 5f                	pop    di
  407684:	64 69 74 33 00 2e 72 	imul   esi,DWORD PTR fs:[rbx+rsi*1+0x0],0x6670722e
  40768b:	70 66 
  40768d:	5f                   	pop    rdi
  40768e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40768f:	69 33 5f 62 61 73    	imul   esi,DWORD PTR [rbx],0x7361625f
  407695:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407698:	72 70                	jb     0x40770a
  40769a:	66 5f                	pop    di
  40769c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40769d:	69 33 5f 64 6f 6e    	imul   esi,DWORD PTR [rbx],0x6e6f645f
  4076a3:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4076a6:	72 70                	jb     0x407718
  4076a8:	66 5f                	pop    di
  4076aa:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076ab:	69 33 5f 6a 00 2e    	imul   esi,DWORD PTR [rbx],0x2e006a5f
  4076b1:	72 70                	jb     0x407723
  4076b3:	66 5f                	pop    di
  4076b5:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076b6:	69 33 5f 6e 65 78    	imul   esi,DWORD PTR [rbx],0x78656e5f
  4076bc:	74 00                	je     0x4076be
  4076be:	72 70                	jb     0x407730
  4076c0:	66 5f                	pop    di
  4076c2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076c3:	66 5f                	pop    di
  4076c5:	64 69 66 35 00 2e 72 	imul   esp,DWORD PTR fs:[rsi+0x35],0x70722e00
  4076cc:	70 
  4076cd:	66 5f                	pop    di
  4076cf:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076d0:	64 35 5f 62 61 73    	fs xor eax,0x7361625f
  4076d6:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4076d9:	72 70                	jb     0x40774b
  4076db:	66 5f                	pop    di
  4076dd:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076de:	64 35 5f 64 6f 6e    	fs xor eax,0x6e6f645f
  4076e4:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4076e7:	72 70                	jb     0x407759
  4076e9:	66 5f                	pop    di
  4076eb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076ec:	64 35 5f 6a 00 2e    	fs xor eax,0x2e006a5f
  4076f2:	72 70                	jb     0x407764
  4076f4:	66 5f                	pop    di
  4076f6:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4076f7:	64 35 5f 6e 65 78    	fs xor eax,0x78656e5f
  4076fd:	74 00                	je     0x4076ff
  4076ff:	72 70                	jb     0x407771
  407701:	66 5f                	pop    di
  407703:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407704:	66 5f                	pop    di
  407706:	64 69 74 35 00 2e 72 	imul   esi,DWORD PTR fs:[rbp+rsi*1+0x0],0x6670722e
  40770d:	70 66 
  40770f:	5f                   	pop    rdi
  407710:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407711:	69 35 5f 62 61 73 65 	imul   esi,DWORD PTR [rip+0x7361625f],0x722e0065        # 0x73a1d97a
  407718:	00 2e 72 
  40771b:	70 66                	jo     0x407783
  40771d:	5f                   	pop    rdi
  40771e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40771f:	69 35 5f 64 6f 6e 65 	imul   esi,DWORD PTR [rip+0x6e6f645f],0x722e0065        # 0x6eafdb88
  407726:	00 2e 72 
  407729:	70 66                	jo     0x407791
  40772b:	5f                   	pop    rdi
  40772c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40772d:	69 35 5f 6a 00 2e 72 	imul   esi,DWORD PTR [rip+0x2e006a5f],0x5f667072        # 0x2e40e196
  407734:	70 66 5f 
  407737:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407738:	69 35 5f 6e 65 78 74 	imul   esi,DWORD PTR [rip+0x78656e5f],0x70720074        # 0x78a5e5a1
  40773f:	00 72 70 
  407742:	66 5f                	pop    di
  407744:	66 6f                	outs   dx,WORD PTR ds:[rsi]
  407746:	75 72                	jne    0x4077ba
  407748:	69 65 72 5f 6d 75 6c 	imul   esp,DWORD PTR [rbp+0x72],0x6c756d5f
  40774f:	5f                   	pop    rdi
  407750:	75 36                	jne    0x407788
  407752:	34 00                	xor    al,0x0
  407754:	2e 72 70             	cs jb  0x4077c7
  407757:	66 5f                	pop    di
  407759:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40775a:	66 6d                	ins    WORD PTR es:[rdi],dx
  40775c:	5f                   	pop    rdi
  40775d:	63 68 6f             	movsxd ebp,DWORD PTR [rax+0x6f]
  407760:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407761:	73 65                	jae    0x4077c8
  407763:	5f                   	pop    rdi
  407764:	67 65 6f             	outs   dx,DWORD PTR gs:[esi]
  407767:	6d                   	ins    DWORD PTR es:[rdi],dx
  407768:	00 2e                	add    BYTE PTR [rsi],ch
  40776a:	72 70                	jb     0x4077dc
  40776c:	66 5f                	pop    di
  40776e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40776f:	66 6d                	ins    WORD PTR es:[rdi],dx
  407771:	5f                   	pop    rdi
  407772:	70 61                	jo     0x4077d5
  407774:	63 6b 33             	movsxd ebp,DWORD PTR [rbx+0x33]
  407777:	00 2e                	add    BYTE PTR [rsi],ch
  407779:	72 70                	jb     0x4077eb
  40777b:	66 5f                	pop    di
  40777d:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40777e:	66 6d                	ins    WORD PTR es:[rdi],dx
  407780:	5f                   	pop    rdi
  407781:	70 61                	jo     0x4077e4
  407783:	63 6b 35             	movsxd ebp,DWORD PTR [rbx+0x35]
  407786:	5f                   	pop    rdi
  407787:	73 74                	jae    0x4077fd
  407789:	61                   	(bad)
  40778a:	72 74                	jb     0x407800
  40778c:	00 2e                	add    BYTE PTR [rsi],ch
  40778e:	72 70                	jb     0x407800
  407790:	66 5f                	pop    di
  407792:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407793:	66 6d                	ins    WORD PTR es:[rdi],dx
  407795:	5f                   	pop    rdi
  407796:	70 61                	jo     0x4077f9
  407798:	63 6b 35             	movsxd ebp,DWORD PTR [rbx+0x35]
  40779b:	00 2e                	add    BYTE PTR [rsi],ch
  40779d:	72 70                	jb     0x40780f
  40779f:	66 5f                	pop    di
  4077a1:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077a2:	66 6d                	ins    WORD PTR es:[rdi],dx
  4077a4:	5f                   	pop    rdi
  4077a5:	67 65 6f             	outs   dx,DWORD PTR gs:[esi]
  4077a8:	6d                   	ins    DWORD PTR es:[rdi],dx
  4077a9:	5f                   	pop    rdi
  4077aa:	70 61                	jo     0x40780d
  4077ac:	63 6b 5f             	movsxd ebp,DWORD PTR [rbx+0x5f]
  4077af:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4077b1:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077b2:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4077b5:	72 70                	jb     0x407827
  4077b7:	66 5f                	pop    di
  4077b9:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077ba:	66 6d                	ins    WORD PTR es:[rdi],dx
  4077bc:	5f                   	pop    rdi
  4077bd:	67 65 6f             	outs   dx,DWORD PTR gs:[esi]
  4077c0:	6d                   	ins    DWORD PTR es:[rdi],dx
  4077c1:	5f                   	pop    rdi
  4077c2:	72 65                	jb     0x407829
  4077c4:	61                   	(bad)
  4077c5:	64 79 00             	fs jns 0x4077c8
  4077c8:	2e 72 70             	cs jb  0x40783b
  4077cb:	66 5f                	pop    di
  4077cd:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077ce:	66 6d                	ins    WORD PTR es:[rdi],dx
  4077d0:	5f                   	pop    rdi
  4077d1:	62 61 64 00 2e       	(bad)
  4077d6:	72 70                	jb     0x407848
  4077d8:	66 5f                	pop    di
  4077da:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077db:	66 6d                	ins    WORD PTR es:[rdi],dx
  4077dd:	5f                   	pop    rdi
  4077de:	75 6e                	jne    0x40784e
  4077e0:	70 61                	jo     0x407843
  4077e2:	63 6b 00             	movsxd ebp,DWORD PTR [rbx+0x0]
  4077e5:	2e 72 70             	cs jb  0x407858
  4077e8:	66 5f                	pop    di
  4077ea:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077eb:	66 6d                	ins    WORD PTR es:[rdi],dx
  4077ed:	5f                   	pop    rdi
  4077ee:	66 6f                	outs   dx,WORD PTR ds:[rsi]
  4077f0:	72 77                	jb     0x407869
  4077f2:	61                   	(bad)
  4077f3:	72 64                	jb     0x407859
  4077f5:	00 2e                	add    BYTE PTR [rsi],ch
  4077f7:	72 70                	jb     0x407869
  4077f9:	66 5f                	pop    di
  4077fb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4077fc:	66 6d                	ins    WORD PTR es:[rdi],dx
  4077fe:	5f                   	pop    rdi
  4077ff:	75 6e                	jne    0x40786f
  407801:	70 61                	jo     0x407864
  407803:	63 6b 5f             	movsxd ebp,DWORD PTR [rbx+0x5f]
  407806:	6d                   	ins    DWORD PTR es:[rdi],dx
  407807:	61                   	(bad)
  407808:	73 6b                	jae    0x407875
  40780a:	00 2e                	add    BYTE PTR [rsi],ch
  40780c:	72 70                	jb     0x40787e
  40780e:	66 5f                	pop    di
  407810:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407811:	66 6d                	ins    WORD PTR es:[rdi],dx
  407813:	5f                   	pop    rdi
  407814:	75 6e                	jne    0x407884
  407816:	70 61                	jo     0x407879
  407818:	63 6b 5f             	movsxd ebp,DWORD PTR [rbx+0x5f]
  40781b:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40781d:	5f                   	pop    rdi
  40781e:	6d                   	ins    DWORD PTR es:[rdi],dx
  40781f:	61                   	(bad)
  407820:	73 6b                	jae    0x40788d
  407822:	00 2e                	add    BYTE PTR [rsi],ch
  407824:	72 70                	jb     0x407896
  407826:	66 5f                	pop    di
  407828:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407829:	66 6d                	ins    WORD PTR es:[rdi],dx
  40782b:	5f                   	pop    rdi
  40782c:	66 35 00 2e          	xor    ax,0x2e00
  407830:	72 70                	jb     0x4078a2
  407832:	66 5f                	pop    di
  407834:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407835:	66 6d                	ins    WORD PTR es:[rdi],dx
  407837:	5f                   	pop    rdi
  407838:	66 33 5f 73          	xor    bx,WORD PTR [rdi+0x73]
  40783c:	74 61                	je     0x40789f
  40783e:	72 74                	jb     0x4078b4
  407840:	00 2e                	add    BYTE PTR [rsi],ch
  407842:	72 70                	jb     0x4078b4
  407844:	66 5f                	pop    di
  407846:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407847:	66 6d                	ins    WORD PTR es:[rdi],dx
  407849:	5f                   	pop    rdi
  40784a:	66 33 00             	xor    ax,WORD PTR [rax]
  40784d:	2e 72 70             	cs jb  0x4078c0
  407850:	66 5f                	pop    di
  407852:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407853:	66 6d                	ins    WORD PTR es:[rdi],dx
  407855:	5f                   	pop    rdi
  407856:	66 32 5f 73          	data16 xor bl,BYTE PTR [rdi+0x73]
  40785a:	74 61                	je     0x4078bd
  40785c:	72 74                	jb     0x4078d2
  40785e:	00 2e                	add    BYTE PTR [rsi],ch
  407860:	72 70                	jb     0x4078d2
  407862:	66 5f                	pop    di
  407864:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407865:	66 6d                	ins    WORD PTR es:[rdi],dx
  407867:	5f                   	pop    rdi
  407868:	66 32 00             	data16 xor al,BYTE PTR [rax]
  40786b:	2e 72 70             	cs jb  0x4078de
  40786e:	66 5f                	pop    di
  407870:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407871:	66 6d                	ins    WORD PTR es:[rdi],dx
  407873:	5f                   	pop    rdi
  407874:	73 71                	jae    0x4078e7
  407876:	75 61                	jne    0x4078d9
  407878:	72 65                	jb     0x4078df
  40787a:	00 2e                	add    BYTE PTR [rsi],ch
  40787c:	72 70                	jb     0x4078ee
  40787e:	66 5f                	pop    di
  407880:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407881:	66 6d                	ins    WORD PTR es:[rdi],dx
  407883:	5f                   	pop    rdi
  407884:	73 71                	jae    0x4078f7
  407886:	5f                   	pop    rdi
  407887:	76 65                	jbe    0x4078ee
  407889:	63 00                	movsxd eax,DWORD PTR [rax]
  40788b:	2e 72 70             	cs jb  0x4078fe
  40788e:	66 5f                	pop    di
  407890:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407891:	66 6d                	ins    WORD PTR es:[rdi],dx
  407893:	5f                   	pop    rdi
  407894:	73 71                	jae    0x407907
  407896:	5f                   	pop    rdi
  407897:	73 63                	jae    0x4078fc
  407899:	61                   	(bad)
  40789a:	6c                   	ins    BYTE PTR es:[rdi],dx
  40789b:	61                   	(bad)
  40789c:	72 00                	jb     0x40789e
  40789e:	2e 72 70             	cs jb  0x407911
  4078a1:	66 5f                	pop    di
  4078a3:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4078a4:	66 6d                	ins    WORD PTR es:[rdi],dx
  4078a6:	5f                   	pop    rdi
  4078a7:	69 6e 76 65 72 73 65 	imul   ebp,DWORD PTR [rsi+0x76],0x65737265
  4078ae:	00 2e                	add    BYTE PTR [rsi],ch
  4078b0:	72 70                	jb     0x407922
  4078b2:	66 5f                	pop    di
  4078b4:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4078b5:	66 6d                	ins    WORD PTR es:[rdi],dx
  4078b7:	5f                   	pop    rdi
  4078b8:	69 32 00 2e 72 70    	imul   esi,DWORD PTR [rdx],0x70722e00
  4078be:	66 5f                	pop    di
  4078c0:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4078c1:	66 6d                	ins    WORD PTR es:[rdi],dx
  4078c3:	5f                   	pop    rdi
  4078c4:	69 33 5f 73 74 61    	imul   esi,DWORD PTR [rbx],0x6174735f
  4078ca:	72 74                	jb     0x407940
  4078cc:	00 2e                	add    BYTE PTR [rsi],ch
  4078ce:	72 70                	jb     0x407940
  4078d0:	66 5f                	pop    di
  4078d2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4078d3:	66 6d                	ins    WORD PTR es:[rdi],dx
  4078d5:	5f                   	pop    rdi
  4078d6:	69 33 00 2e 72 70    	imul   esi,DWORD PTR [rbx],0x70722e00
  4078dc:	66 5f                	pop    di
  4078de:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4078df:	66 6d                	ins    WORD PTR es:[rdi],dx
  4078e1:	5f                   	pop    rdi
  4078e2:	69 35 5f 73 74 61 72 	imul   esi,DWORD PTR [rip+0x6174735f],0x2e007472        # 0x61b4ec4b
  4078e9:	74 00 2e 
  4078ec:	72 70                	jb     0x40795e
  4078ee:	66 5f                	pop    di
  4078f0:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4078f1:	66 6d                	ins    WORD PTR es:[rdi],dx
  4078f3:	5f                   	pop    rdi
  4078f4:	69 35 00 2e 72 70 66 	imul   esi,DWORD PTR [rip+0x70722e00],0x666e5f66        # 0x70b2a6fe
  4078fb:	5f 6e 66 
  4078fe:	6d                   	ins    DWORD PTR es:[rdi],dx
  4078ff:	5f                   	pop    rdi
  407900:	63 61 72             	movsxd esp,DWORD PTR [rcx+0x72]
  407903:	72 79                	jb     0x40797e
  407905:	00 2e                	add    BYTE PTR [rsi],ch
  407907:	72 70                	jb     0x407979
  407909:	66 5f                	pop    di
  40790b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40790c:	66 6d                	ins    WORD PTR es:[rdi],dx
  40790e:	5f                   	pop    rdi
  40790f:	63 61 72             	movsxd esp,DWORD PTR [rcx+0x72]
  407912:	72 79                	jb     0x40798d
  407914:	5f                   	pop    rdi
  407915:	6c                   	ins    BYTE PTR es:[rdi],dx
  407916:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407917:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407918:	70 00                	jo     0x40791a
  40791a:	2e 72 70             	cs jb  0x40798d
  40791d:	66 5f                	pop    di
  40791f:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407920:	66 6d                	ins    WORD PTR es:[rdi],dx
  407922:	5f                   	pop    rdi
  407923:	63 61 72             	movsxd esp,DWORD PTR [rcx+0x72]
  407926:	72 79                	jb     0x4079a1
  407928:	5f                   	pop    rdi
  407929:	74 61                	je     0x40798c
  40792b:	69 6c 00 2e 72 70 66 	imul   ebp,DWORD PTR [rax+rax*1+0x2e],0x5f667072
  407932:	5f 
  407933:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407934:	66 6d                	ins    WORD PTR es:[rdi],dx
  407936:	5f                   	pop    rdi
  407937:	70 61                	jo     0x40799a
  407939:	63 6b 5f             	movsxd ebp,DWORD PTR [rbx+0x5f]
  40793c:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40793e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40793f:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407942:	72 70                	jb     0x4079b4
  407944:	66 5f                	pop    di
  407946:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407947:	66 6d                	ins    WORD PTR es:[rdi],dx
  407949:	5f                   	pop    rdi
  40794a:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40794b:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  40794e:	72 70                	jb     0x4079c0
  407950:	66 5f                	pop    di
  407952:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407953:	66 6d                	ins    WORD PTR es:[rdi],dx
  407955:	5f                   	pop    rdi
  407956:	74 61                	je     0x4079b9
  407958:	69 6c 5f 6c 6f 6f 70 	imul   ebp,DWORD PTR [rdi+rbx*2+0x6c],0x706f6f
  40795f:	00 
  407960:	2e 72 70             	cs jb  0x4079d3
  407963:	66 5f                	pop    di
  407965:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407966:	66 6d                	ins    WORD PTR es:[rdi],dx
  407968:	5f                   	pop    rdi
  407969:	74 61                	je     0x4079cc
  40796b:	69 6c 5f 6e 65 78 74 	imul   ebp,DWORD PTR [rdi+rbx*2+0x6e],0x747865
  407972:	00 
  407973:	2e 72 70             	cs jb  0x4079e6
  407976:	66 5f                	pop    di
  407978:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407979:	66 6d                	ins    WORD PTR es:[rdi],dx
  40797b:	5f                   	pop    rdi
  40797c:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40797e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40797f:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407982:	72 70                	jb     0x4079f4
  407984:	66 6d                	ins    WORD PTR es:[rdi],dx
  407986:	5f                   	pop    rdi
  407987:	62 61 64 00 2e       	(bad)
  40798c:	72 70                	jb     0x4079fe
  40798e:	66 6d                	ins    WORD PTR es:[rdi],dx
  407990:	5f                   	pop    rdi
  407991:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407993:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407994:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407997:	72 70                	jb     0x407a09
  407999:	66 64 32 5f 62       	data16 xor bl,BYTE PTR fs:[rdi+0x62]
  40799e:	61                   	(bad)
  40799f:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  4079a2:	72 70                	jb     0x407a14
  4079a4:	66 64 32 5f 66       	data16 xor bl,BYTE PTR fs:[rdi+0x66]
  4079a9:	69 6c 6c 00 2e 72 70 	imul   ebp,DWORD PTR [rsp+rbp*2+0x0],0x6670722e
  4079b0:	66 
  4079b1:	64 32 5f 66          	xor    bl,BYTE PTR fs:[rdi+0x66]
  4079b5:	69 6c 6c 65 64 00 2e 	imul   ebp,DWORD PTR [rsp+rbp*2+0x65],0x722e0064
  4079bc:	72 
  4079bd:	70 66                	jo     0x407a25
  4079bf:	64 32 5f 75          	xor    bl,BYTE PTR fs:[rdi+0x75]
  4079c3:	5f                   	pop    rdi
  4079c4:	64 69 72 65 63 74 00 	imul   esi,DWORD PTR fs:[rdx+0x65],0x2e007463
  4079cb:	2e 
  4079cc:	72 70                	jb     0x407a3e
  4079ce:	66 64 32 5f 76       	data16 xor bl,BYTE PTR fs:[rdi+0x76]
  4079d3:	00 2e                	add    BYTE PTR [rsi],ch
  4079d5:	72 70                	jb     0x407a47
  4079d7:	66 64 32 5f 6a       	data16 xor bl,BYTE PTR fs:[rdi+0x6a]
  4079dc:	00 2e                	add    BYTE PTR [rsi],ch
  4079de:	72 70                	jb     0x407a50
  4079e0:	66 64 32 5f 71       	data16 xor bl,BYTE PTR fs:[rdi+0x71]
  4079e5:	75 6f                	jne    0x407a56
  4079e7:	74 5f                	je     0x407a48
  4079e9:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4079eb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4079ec:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  4079ef:	72 70                	jb     0x407a61
  4079f1:	66 64 32 5f 71       	data16 xor bl,BYTE PTR fs:[rdi+0x71]
  4079f6:	5f                   	pop    rdi
  4079f7:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4079f8:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  4079fb:	72 70                	jb     0x407a6d
  4079fd:	66 64 32 5f 73       	data16 xor bl,BYTE PTR fs:[rdi+0x73]
  407a02:	75 62                	jne    0x407a66
  407a04:	74 72                	je     0x407a78
  407a06:	61                   	(bad)
  407a07:	63 74 00 2e          	movsxd esi,DWORD PTR [rax+rax*1+0x2e]
  407a0b:	72 70                	jb     0x407a7d
  407a0d:	66 64 32 5f 61       	data16 xor bl,BYTE PTR fs:[rdi+0x61]
  407a12:	64 6a 75             	fs push 0x75
  407a15:	73 74                	jae    0x407a8b
  407a17:	00 2e                	add    BYTE PTR [rsi],ch
  407a19:	72 70                	jb     0x407a8b
  407a1b:	66 64 32 5f 73       	data16 xor bl,BYTE PTR fs:[rdi+0x73]
  407a20:	75 62                	jne    0x407a84
  407a22:	5f                   	pop    rdi
  407a23:	6c                   	ins    BYTE PTR es:[rdi],dx
  407a24:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407a25:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407a26:	70 00                	jo     0x407a28
  407a28:	2e 72 70             	cs jb  0x407a9b
  407a2b:	66 64 32 5f 73       	data16 xor bl,BYTE PTR fs:[rdi+0x73]
  407a30:	75 62                	jne    0x407a94
  407a32:	5f                   	pop    rdi
  407a33:	74 6f                	je     0x407aa4
  407a35:	70 00                	jo     0x407a37
  407a37:	2e 72 70             	cs jb  0x407aaa
  407a3a:	66 64 32 5f 73       	data16 xor bl,BYTE PTR fs:[rdi+0x73]
  407a3f:	74 6f                	je     0x407ab0
  407a41:	72 65                	jb     0x407aa8
  407a43:	5f                   	pop    rdi
  407a44:	71 00                	jno    0x407a46
  407a46:	2e 72 70             	cs jb  0x407ab9
  407a49:	66 64 32 5f 61       	data16 xor bl,BYTE PTR fs:[rdi+0x61]
  407a4e:	64 64 62 61 63 6b 00 	(bad)
  407a55:	2e 72 70             	cs jb  0x407ac8
  407a58:	66 64 32 5f 61       	data16 xor bl,BYTE PTR fs:[rdi+0x61]
  407a5d:	64 64 74 6f          	fs fs je 0x407ad0
  407a61:	70 00                	jo     0x407a63
  407a63:	2e 72 70             	cs jb  0x407ad6
  407a66:	66 64 32 5f 72       	data16 xor bl,BYTE PTR fs:[rdi+0x72]
  407a6b:	65 6d                	gs ins DWORD PTR es:[rdi],dx
  407a6d:	5f                   	pop    rdi
  407a6e:	6c                   	ins    BYTE PTR es:[rdi],dx
  407a6f:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407a70:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407a71:	70 00                	jo     0x407a73
  407a73:	2e 72 70             	cs jb  0x407ae6
  407a76:	66 64 32 5f 72       	data16 xor bl,BYTE PTR fs:[rdi+0x72]
  407a7b:	65 6d                	gs ins DWORD PTR es:[rdi],dx
  407a7d:	5f                   	pop    rdi
  407a7e:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407a80:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407a81:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407a84:	72 70                	jb     0x407af6
  407a86:	66 64 32 5f 6e       	data16 xor bl,BYTE PTR fs:[rdi+0x6e]
  407a8b:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407a8c:	5f                   	pop    rdi
  407a8d:	73 74                	jae    0x407b03
  407a8f:	69 63 6b 79 00 2e 72 	imul   esp,DWORD PTR [rbx+0x6b],0x722e0079
  407a96:	70 66                	jo     0x407afe
  407a98:	64 32 5f 64          	xor    bl,BYTE PTR fs:[rdi+0x64]
  407a9c:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407a9d:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407a9e:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407aa1:	72 70                	jb     0x407b13
  407aa3:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407aa7:	5f                   	pop    rdi
  407aa8:	62 61 64 00 2e       	(bad)
  407aad:	72 70                	jb     0x407b1f
  407aaf:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407ab3:	5f                   	pop    rdi
  407ab4:	61                   	(bad)
  407ab5:	5f                   	pop    rdi
  407ab6:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ab7:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407ab8:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ab9:	7a 65                	jp     0x407b20
  407abb:	72 6f                	jb     0x407b2c
  407abd:	00 2e                	add    BYTE PTR [rsi],ch
  407abf:	72 70                	jb     0x407b31
  407ac1:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407ac5:	5f                   	pop    rdi
  407ac6:	65 71 00             	gs jno 0x407ac9
  407ac9:	2e 72 70             	cs jb  0x407b3c
  407acc:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407ad0:	5f                   	pop    rdi
  407ad1:	67 74 00             	addr32 je 0x407ad4
  407ad4:	2e 72 70             	cs jb  0x407b47
  407ad7:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407adb:	5f                   	pop    rdi
  407adc:	6c                   	ins    BYTE PTR es:[rdi],dx
  407add:	74 00                	je     0x407adf
  407adf:	2e 72 70             	cs jb  0x407b52
  407ae2:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407ae6:	5f                   	pop    rdi
  407ae7:	62 6f 74 68 5f       	(bad)
  407aec:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407aed:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407aee:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407aef:	7a 65                	jp     0x407b56
  407af1:	72 6f                	jb     0x407b62
  407af3:	00 2e                	add    BYTE PTR [rsi],ch
  407af5:	72 70                	jb     0x407b67
  407af7:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407afb:	5f                   	pop    rdi
  407afc:	73 61                	jae    0x407b5f
  407afe:	6d                   	ins    DWORD PTR es:[rdi],dx
  407aff:	65 5f                	gs pop rdi
  407b01:	73 69                	jae    0x407b6c
  407b03:	67 6e                	outs   dx,BYTE PTR ds:[esi]
  407b05:	00 2e                	add    BYTE PTR [rsi],ch
  407b07:	72 70                	jb     0x407b79
  407b09:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407b0d:	5f                   	pop    rdi
  407b0e:	73 69                	jae    0x407b79
  407b10:	67 00 2e             	add    BYTE PTR [esi],ch
  407b13:	72 70                	jb     0x407b85
  407b15:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407b19:	5f                   	pop    rdi
  407b1a:	6d                   	ins    DWORD PTR es:[rdi],dx
  407b1b:	61                   	(bad)
  407b1c:	67 5f                	addr32 pop rdi
  407b1e:	67 74 00             	addr32 je 0x407b21
  407b21:	2e 72 70             	cs jb  0x407b94
  407b24:	66 63 6d 70          	movsxd bp,DWORD PTR [rbp+0x70]
  407b28:	5f                   	pop    rdi
  407b29:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407b2b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407b2c:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407b2f:	72 70                	jb     0x407ba1
  407b31:	66 6e                	data16 outs dx,BYTE PTR ds:[rsi]
  407b33:	5f                   	pop    rdi
  407b34:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407b36:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407b37:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407b3a:	72 70                	jb     0x407bac
  407b3c:	66 61                	data16 (bad)
  407b3e:	5f                   	pop    rdi
  407b3f:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407b41:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407b42:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  407b46:	66 5f                	pop    di
  407b48:	6d                   	ins    DWORD PTR es:[rdi],dx
  407b49:	61                   	(bad)
  407b4a:	74 68                	je     0x407bb4
  407b4c:	5f                   	pop    rdi
  407b4d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407b4e:	62 6a 65 63 74       	(bad)
  407b53:	5f                   	pop    rdi
  407b54:	73 70                	jae    0x407bc6
  407b56:	61                   	(bad)
  407b57:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407b58:	00 2e                	add    BYTE PTR [rsi],ch
  407b5a:	72 70                	jb     0x407bcc
  407b5c:	6d                   	ins    DWORD PTR es:[rdi],dx
  407b5d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407b5e:	73 5f                	jae    0x407bbf
  407b60:	62 61 64 00 72       	(bad)
  407b65:	70 66                	jo     0x407bcd
  407b67:	5f                   	pop    rdi
  407b68:	6d                   	ins    DWORD PTR es:[rdi],dx
  407b69:	61                   	(bad)
  407b6a:	74 68                	je     0x407bd4
  407b6c:	5f                   	pop    rdi
  407b6d:	73 6c                	jae    0x407bdb
  407b6f:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407b70:	74 00                	je     0x407b72
  407b72:	72 70                	jb     0x407be4
  407b74:	66 5f                	pop    di
  407b76:	6d                   	ins    DWORD PTR es:[rdi],dx
  407b77:	61                   	(bad)
  407b78:	6b 65 5f 70          	imul   esp,DWORD PTR [rbp+0x5f],0x70
  407b7c:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407b7d:	77 32                	ja     0x407bb1
  407b7f:	00 2e                	add    BYTE PTR [rsi],ch
  407b81:	72 70                	jb     0x407bf3
  407b83:	66 6d                	ins    WORD PTR es:[rdi],dx
  407b85:	70 5f                	jo     0x407be6
  407b87:	62 61 64 00 2e       	(bad)
  407b8c:	72 70                	jb     0x407bfe
  407b8e:	66 6d                	ins    WORD PTR es:[rdi],dx
  407b90:	70 5f                	jo     0x407bf1
  407b92:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407b94:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407b95:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  407b99:	66 5f                	pop    di
  407b9b:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407b9c:	62 6a 65 63 74       	(bad)
  407ba1:	5f                   	pop    rdi
  407ba2:	69 73 5f 7a 65 72 6f 	imul   esi,DWORD PTR [rbx+0x5f],0x6f72657a
  407ba9:	00 72 70             	add    BYTE PTR [rdx+0x70],dh
  407bac:	66 5f                	pop    di
  407bae:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  407bb1:	79 5f                	jns    0x407c12
  407bb3:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407bb4:	62 6a 65 63 74       	(bad)
  407bb9:	00 2e                	add    BYTE PTR [rsi],ch
  407bbb:	72 70                	jb     0x407c2d
  407bbd:	66 73 71             	data16 jae 0x407c31
  407bc0:	5f                   	pop    rdi
  407bc1:	62 61 64 00 2e       	(bad)
  407bc6:	72 70                	jb     0x407c38
  407bc8:	66 73 71             	data16 jae 0x407c3c
  407bcb:	5f                   	pop    rdi
  407bcc:	7a 65                	jp     0x407c33
  407bce:	72 6f                	jb     0x407c3f
  407bd0:	00 2e                	add    BYTE PTR [rsi],ch
  407bd2:	72 70                	jb     0x407c44
  407bd4:	66 73 71             	data16 jae 0x407c48
  407bd7:	5f                   	pop    rdi
  407bd8:	6c                   	ins    BYTE PTR es:[rdi],dx
  407bd9:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407bda:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407bdb:	70 00                	jo     0x407bdd
  407bdd:	2e 72 70             	cs jb  0x407c50
  407be0:	66 73 71             	data16 jae 0x407c54
  407be3:	5f                   	pop    rdi
  407be4:	63 61 70             	movsxd esp,DWORD PTR [rcx+0x70]
  407be7:	00 2e                	add    BYTE PTR [rsi],ch
  407be9:	72 70                	jb     0x407c5b
  407beb:	66 73 71             	data16 jae 0x407c5f
  407bee:	5f                   	pop    rdi
  407bef:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407bf0:	65 78 74             	gs js  0x407c67
  407bf3:	5f                   	pop    rdi
  407bf4:	72 65                	jb     0x407c5b
  407bf6:	61                   	(bad)
  407bf7:	64 79 00             	fs jns 0x407bfa
  407bfa:	2e 72 70             	cs jb  0x407c6d
  407bfd:	66 73 71             	data16 jae 0x407c71
  407c00:	5f                   	pop    rdi
  407c01:	75 73                	jne    0x407c76
  407c03:	65 5f                	gs pop rdi
  407c05:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407c06:	65 78 74             	gs js  0x407c7d
  407c09:	00 2e                	add    BYTE PTR [rsi],ch
  407c0b:	72 70                	jb     0x407c7d
  407c0d:	66 73 71             	data16 jae 0x407c81
  407c10:	5f                   	pop    rdi
  407c11:	63 79 63             	movsxd edi,DWORD PTR [rcx+0x63]
  407c14:	6c                   	ins    BYTE PTR es:[rdi],dx
  407c15:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407c18:	72 70                	jb     0x407c8a
  407c1a:	66 73 71             	data16 jae 0x407c8e
  407c1d:	5f                   	pop    rdi
  407c1e:	75 73                	jne    0x407c93
  407c20:	65 5f                	gs pop rdi
  407c22:	67 00 2e             	add    BYTE PTR [esi],ch
  407c25:	72 70                	jb     0x407c97
  407c27:	66 73 71             	data16 jae 0x407c9b
  407c2a:	5f                   	pop    rdi
  407c2b:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407c2d:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407c2e:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407c31:	72 70                	jb     0x407ca3
  407c33:	66 65 78 5f          	data16 gs js 0x407c96
  407c37:	62 61 64 00 2e       	(bad)
  407c3c:	72 70                	jb     0x407cae
  407c3e:	66 65 78 5f          	data16 gs js 0x407ca1
  407c42:	68 61 76 65 5f       	push   0x5f657661
  407c47:	6d                   	ins    DWORD PTR es:[rdi],dx
  407c48:	00 2e                	add    BYTE PTR [rsi],ch
  407c4a:	72 70                	jb     0x407cbc
  407c4c:	66 65 78 5f          	data16 gs js 0x407caf
  407c50:	79 5f                	jns    0x407cb1
  407c52:	72 65                	jb     0x407cb9
  407c54:	61                   	(bad)
  407c55:	64 79 00             	fs jns 0x407c58
  407c58:	2e 72 70             	cs jb  0x407ccb
  407c5b:	66 65 78 5f          	data16 gs js 0x407cbe
  407c5f:	73 65                	jae    0x407cc6
  407c61:	72 69                	jb     0x407ccc
  407c63:	65 73 00             	gs jae 0x407c66
  407c66:	2e 72 70             	cs jb  0x407cd9
  407c69:	66 65 78 5f          	data16 gs js 0x407ccc
  407c6d:	73 65                	jae    0x407cd4
  407c6f:	72 69                	jb     0x407cda
  407c71:	65 73 5f             	gs jae 0x407cd3
  407c74:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407c76:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407c77:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407c7a:	72 70                	jb     0x407cec
  407c7c:	66 65 78 5f          	data16 gs js 0x407cdf
  407c80:	73 71                	jae    0x407cf3
  407c82:	75 61                	jne    0x407ce5
  407c84:	72 65                	jb     0x407ceb
  407c86:	00 2e                	add    BYTE PTR [rsi],ch
  407c88:	72 70                	jb     0x407cfa
  407c8a:	66 65 78 5f          	data16 gs js 0x407ced
  407c8e:	73 69                	jae    0x407cf9
  407c90:	67 6e                	outs   dx,BYTE PTR ds:[esi]
  407c92:	00 2e                	add    BYTE PTR [rsi],ch
  407c94:	72 70                	jb     0x407d06
  407c96:	66 65 78 5f          	data16 gs js 0x407cf9
  407c9a:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407c9b:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  407c9e:	72 70                	jb     0x407d10
  407ca0:	66 65 78 5f          	data16 gs js 0x407d03
  407ca4:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407ca6:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ca7:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407caa:	72 70                	jb     0x407d1c
  407cac:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407cae:	67 5f                	addr32 pop rdi
  407cb0:	62 61 64 00 2e       	(bad)
  407cb5:	72 70                	jb     0x407d27
  407cb7:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407cb9:	67 5f                	addr32 pop rdi
  407cbb:	63 6f 6e             	movsxd ebp,DWORD PTR [rdi+0x6e]
  407cbe:	74 72                	je     0x407d32
  407cc0:	61                   	(bad)
  407cc1:	63 74 00 2e          	movsxd esi,DWORD PTR [rax+rax*1+0x2e]
  407cc5:	72 70                	jb     0x407d37
  407cc7:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407cc9:	67 5f                	addr32 pop rdi
  407ccb:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407ccd:	5f                   	pop    rdi
  407cce:	73 71                	jae    0x407d41
  407cd0:	72 74                	jb     0x407d46
  407cd2:	00 2e                	add    BYTE PTR [rsi],ch
  407cd4:	72 70                	jb     0x407d46
  407cd6:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407cd8:	67 5f                	addr32 pop rdi
  407cda:	63 6f 6e             	movsxd ebp,DWORD PTR [rdi+0x6e]
  407cdd:	74 72                	je     0x407d51
  407cdf:	61                   	(bad)
  407ce0:	63 74 5f 64          	movsxd esi,DWORD PTR [rdi+rbx*2+0x64]
  407ce4:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407ce5:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ce6:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407ce9:	72 70                	jb     0x407d5b
  407ceb:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407ced:	67 5f                	addr32 pop rdi
  407cef:	73 65                	jae    0x407d56
  407cf1:	72 69                	jb     0x407d5c
  407cf3:	65 73 00             	gs jae 0x407cf6
  407cf6:	2e 72 70             	cs jb  0x407d69
  407cf9:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407cfb:	67 5f                	addr32 pop rdi
  407cfd:	73 65                	jae    0x407d64
  407cff:	72 69                	jb     0x407d6a
  407d01:	65 73 5f             	gs jae 0x407d63
  407d04:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407d06:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407d07:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407d0a:	72 70                	jb     0x407d7c
  407d0c:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407d0e:	67 5f                	addr32 pop rdi
  407d10:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407d11:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  407d14:	72 70                	jb     0x407d86
  407d16:	66 6c                	data16 ins BYTE PTR es:[rdi],dx
  407d18:	67 5f                	addr32 pop rdi
  407d1a:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407d1c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407d1d:	65 00 72 70          	add    BYTE PTR gs:[rdx+0x70],dh
  407d21:	66 5f                	pop    di
  407d23:	73 69                	jae    0x407d8e
  407d25:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407d26:	63 6f 73             	movsxd ebp,DWORD PTR [rdi+0x73]
  407d29:	5f                   	pop    rdi
  407d2a:	63 6f 72             	movsxd ebp,DWORD PTR [rdi+0x72]
  407d2d:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407d30:	72 70                	jb     0x407da2
  407d32:	66 73 63             	data16 jae 0x407d98
  407d35:	5f                   	pop    rdi
  407d36:	62 61 64 00 2e       	(bad)
  407d3b:	72 70                	jb     0x407dad
  407d3d:	66 73 63             	data16 jae 0x407da3
  407d40:	5f                   	pop    rdi
  407d41:	68 61 76 65 5f       	push   0x5f657661
  407d46:	6d                   	ins    DWORD PTR es:[rdi],dx
  407d47:	00 2e                	add    BYTE PTR [rsi],ch
  407d49:	72 70                	jb     0x407dbb
  407d4b:	66 73 63             	data16 jae 0x407db1
  407d4e:	5f                   	pop    rdi
  407d4f:	79 5f                	jns    0x407db0
  407d51:	72 65                	jb     0x407db8
  407d53:	61                   	(bad)
  407d54:	64 79 00             	fs jns 0x407d57
  407d57:	2e 72 70             	cs jb  0x407dca
  407d5a:	66 73 63             	data16 jae 0x407dc0
  407d5d:	5f                   	pop    rdi
  407d5e:	73 65                	jae    0x407dc5
  407d60:	72 69                	jb     0x407dcb
  407d62:	65 73 00             	gs jae 0x407d65
  407d65:	2e 72 70             	cs jb  0x407dd8
  407d68:	66 73 63             	data16 jae 0x407dce
  407d6b:	5f                   	pop    rdi
  407d6c:	73 65                	jae    0x407dd3
  407d6e:	72 69                	jb     0x407dd9
  407d70:	65 73 5f             	gs jae 0x407dd2
  407d73:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407d75:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407d76:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407d79:	72 70                	jb     0x407deb
  407d7b:	66 73 63             	data16 jae 0x407de1
  407d7e:	5f                   	pop    rdi
  407d7f:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407d81:	75 62                	jne    0x407de5
  407d83:	6c                   	ins    BYTE PTR es:[rdi],dx
  407d84:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407d87:	72 70                	jb     0x407df9
  407d89:	66 73 63             	data16 jae 0x407def
  407d8c:	5f                   	pop    rdi
  407d8d:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407d8e:	75 74                	jne    0x407e04
  407d90:	70 75                	jo     0x407e07
  407d92:	74 00                	je     0x407d94
  407d94:	2e 72 70             	cs jb  0x407e07
  407d97:	66 73 63             	data16 jae 0x407dfd
  407d9a:	5f                   	pop    rdi
  407d9b:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407d9c:	75 74                	jne    0x407e12
  407d9e:	5f                   	pop    rdi
  407d9f:	63 6f 73             	movsxd ebp,DWORD PTR [rdi+0x73]
  407da2:	00 2e                	add    BYTE PTR [rsi],ch
  407da4:	72 70                	jb     0x407e16
  407da6:	66 73 63             	data16 jae 0x407e0c
  407da9:	5f                   	pop    rdi
  407daa:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407dac:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407dad:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407db0:	72 70                	jb     0x407e22
  407db2:	66 74 64             	data16 je 0x407e19
  407db5:	5f                   	pop    rdi
  407db6:	7a 65                	jp     0x407e1d
  407db8:	72 6f                	jb     0x407e29
  407dba:	00 2e                	add    BYTE PTR [rsi],ch
  407dbc:	72 70                	jb     0x407e2e
  407dbe:	66 74 64             	data16 je 0x407e25
  407dc1:	5f                   	pop    rdi
  407dc2:	69 6e 66 00 2e 72 70 	imul   ebp,DWORD PTR [rsi+0x66],0x70722e00
  407dc9:	66 74 64             	data16 je 0x407e30
  407dcc:	5f                   	pop    rdi
  407dcd:	73 75                	jae    0x407e44
  407dcf:	62 7a 65 72 6f       	(bad)
  407dd4:	00 2e                	add    BYTE PTR [rsi],ch
  407dd6:	72 70                	jb     0x407e48
  407dd8:	66 74 64             	data16 je 0x407e3f
  407ddb:	5f                   	pop    rdi
  407ddc:	62 69 74 73 00       	(bad)
  407de1:	2e 72 70             	cs jb  0x407e54
  407de4:	66 74 64             	data16 je 0x407e4b
  407de7:	5f                   	pop    rdi
  407de8:	72 6f                	jb     0x407e59
  407dea:	75 6e                	jne    0x407e5a
  407dec:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  407def:	72 70                	jb     0x407e61
  407df1:	66 74 64             	data16 je 0x407e58
  407df4:	5f                   	pop    rdi
  407df5:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407df6:	65 78 74             	gs js  0x407e6d
  407df9:	00 2e                	add    BYTE PTR [rsi],ch
  407dfb:	72 70                	jb     0x407e6d
  407dfd:	66 74 64             	data16 je 0x407e64
  407e00:	5f                   	pop    rdi
  407e01:	70 61                	jo     0x407e64
  407e03:	63 6b 00             	movsxd ebp,DWORD PTR [rbx+0x0]
  407e06:	2e 72 70             	cs jb  0x407e79
  407e09:	66 74 64             	data16 je 0x407e70
  407e0c:	5f                   	pop    rdi
  407e0d:	69 6e 63 00 2e 72 70 	imul   ebp,DWORD PTR [rsi+0x63],0x70722e00
  407e14:	66 74 64             	data16 je 0x407e7b
  407e17:	5f                   	pop    rdi
  407e18:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  407e1a:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407e1b:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  407e1e:	61                   	(bad)
  407e1f:	72 65                	jb     0x407e86
  407e21:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407e22:	61                   	(bad)
  407e23:	5f                   	pop    rdi
  407e24:	72 65                	jb     0x407e8b
  407e26:	61                   	(bad)
  407e27:	64 79 00             	fs jns 0x407e2a
  407e2a:	2e 61                	cs (bad)
  407e2c:	72 65                	jb     0x407e93
  407e2e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407e2f:	61                   	(bad)
  407e30:	5f                   	pop    rdi
  407e31:	66 61                	data16 (bad)
  407e33:	69 6c 00 70 72 6f 67 	imul   ebp,DWORD PTR [rax+rax*1+0x70],0x72676f72
  407e3a:	72 
  407e3b:	61                   	(bad)
  407e3c:	6d                   	ins    DWORD PTR es:[rdi],dx
  407e3d:	5f                   	pop    rdi
  407e3e:	63 6f 64             	movsxd ebp,DWORD PTR [rdi+0x64]
  407e41:	65 5f                	gs pop rdi
  407e43:	70 74                	jo     0x407eb9
  407e45:	72 00                	jb     0x407e47
  407e47:	69 6e 70 75 74 5f 74 	imul   ebp,DWORD PTR [rsi+0x70],0x745f7475
  407e4e:	79 70                	jns    0x407ec0
  407e50:	65 5f                	gs pop rdi
  407e52:	70 74                	jo     0x407ec8
  407e54:	72 00                	jb     0x407e56
  407e56:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407e57:	75 74                	jne    0x407ecd
  407e59:	70 75                	jo     0x407ed0
  407e5b:	74 5f                	je     0x407ebc
  407e5d:	74 79                	je     0x407ed8
  407e5f:	70 65                	jo     0x407ec6
  407e61:	5f                   	pop    rdi
  407e62:	70 74                	jo     0x407ed8
  407e64:	72 00                	jb     0x407e66
  407e66:	2e 70 72             	cs jo  0x407edb
  407e69:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407e6a:	67 72 61             	addr32 jb 0x407ece
  407e6d:	6d                   	ins    DWORD PTR es:[rdi],dx
  407e6e:	5f                   	pop    rdi
  407e6f:	72 65                	jb     0x407ed6
  407e71:	61                   	(bad)
  407e72:	64 79 00             	fs jns 0x407e75
  407e75:	73 65                	jae    0x407edc
  407e77:	6c                   	ins    BYTE PTR es:[rdi],dx
  407e78:	66 5f                	pop    di
  407e7a:	65 78 65             	gs js  0x407ee2
  407e7d:	5f                   	pop    rdi
  407e7e:	70 61                	jo     0x407ee1
  407e80:	74 68                	je     0x407eea
  407e82:	00 2e                	add    BYTE PTR [rsi],ch
  407e84:	70 72                	jo     0x407ef8
  407e86:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  407e87:	67 72 61             	addr32 jb 0x407eeb
  407e8a:	6d                   	ins    DWORD PTR es:[rdi],dx
  407e8b:	5f                   	pop    rdi
  407e8c:	6d                   	ins    DWORD PTR es:[rdi],dx
  407e8d:	61                   	(bad)
  407e8e:	70 5f                	jo     0x407eef
  407e90:	66 61                	data16 (bad)
  407e92:	69 6c 00 2e 70 72 6f 	imul   ebp,DWORD PTR [rax+rax*1+0x2e],0x676f7270
  407e99:	67 
  407e9a:	72 61                	jb     0x407efd
  407e9c:	6d                   	ins    DWORD PTR es:[rdi],dx
  407e9d:	5f                   	pop    rdi
  407e9e:	6d                   	ins    DWORD PTR es:[rdi],dx
  407e9f:	61                   	(bad)
  407ea0:	70 5f                	jo     0x407f01
  407ea2:	66 61                	data16 (bad)
  407ea4:	69 6c 5f 6d 61 70 70 	imul   ebp,DWORD PTR [rdi+rbx*2+0x6d],0x65707061
  407eab:	65 
  407eac:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  407eaf:	62 61 64 5f 61       	(bad)
  407eb4:	72 67                	jb     0x407f1d
  407eb6:	73 00                	jae    0x407eb8
  407eb8:	72 61                	jb     0x407f1b
  407eba:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ebb:	6b 6e 5f 69          	imul   ebp,DWORD PTR [rsi+0x5f],0x69
  407ebf:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ec0:	70 75                	jo     0x407f37
  407ec2:	74 5f                	je     0x407f23
  407ec4:	63 75 72             	movsxd esi,DWORD PTR [rbp+0x72]
  407ec7:	73 6f                	jae    0x407f38
  407ec9:	72 00                	jb     0x407ecb
  407ecb:	2e 70 61             	cs jo  0x407f2f
  407ece:	72 73                	jb     0x407f43
  407ed0:	65 5f                	gs pop rdi
  407ed2:	69 6e 70 75 74 73 00 	imul   ebp,DWORD PTR [rsi+0x70],0x737475
  407ed9:	2e 72 75             	cs jb  0x407f51
  407edc:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407edd:	00 2e                	add    BYTE PTR [rsi],ch
  407edf:	69 6e 5f 62 6f 6f 6c 	imul   ebp,DWORD PTR [rsi+0x5f],0x6c6f6f62
  407ee6:	00 2e                	add    BYTE PTR [rsi],ch
  407ee8:	69 6e 5f 69 36 34 00 	imul   ebp,DWORD PTR [rsi+0x5f],0x343669
  407eef:	2e 69 6e 5f 75 36 34 	cs imul ebp,DWORD PTR [rsi+0x5f],0x343675
  407ef6:	00 
  407ef7:	2e 69 6e 5f 66 33 32 	cs imul ebp,DWORD PTR [rsi+0x5f],0x323366
  407efe:	00 
  407eff:	2e 69 6e 5f 66 36 34 	cs imul ebp,DWORD PTR [rsi+0x5f],0x343666
  407f06:	00 
  407f07:	2e 69 6e 5f 73 74 72 	cs imul ebp,DWORD PTR [rsi+0x5f],0x69727473
  407f0e:	69 
  407f0f:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407f10:	67 00 2e             	add    BYTE PTR [esi],ch
  407f13:	69 6e 5f 72 61 6e 6b 	imul   ebp,DWORD PTR [rsi+0x5f],0x6b6e6172
  407f1a:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407f1b:	5f                   	pop    rdi
  407f1c:	66 70 00             	data16 jo 0x407f1f
  407f1f:	70 61                	jo     0x407f82
  407f21:	72 73                	jb     0x407f96
  407f23:	65 5f                	gs pop rdi
  407f25:	62 6f 6f 6c 00       	(bad)
  407f2a:	2e 69 6e 5f 6e 65 78 	cs imul ebp,DWORD PTR [rsi+0x5f],0x7478656e
  407f31:	74 
  407f32:	00 70 61             	add    BYTE PTR [rax+0x61],dh
  407f35:	72 73                	jb     0x407faa
  407f37:	65 5f                	gs pop rdi
  407f39:	69 36 34 00 70 61    	imul   esi,DWORD PTR [rsi],0x61700034
  407f3f:	72 73                	jb     0x407fb4
  407f41:	65 5f                	gs pop rdi
  407f43:	75 36                	jne    0x407f7b
  407f45:	34 00                	xor    al,0x0
  407f47:	70 61                	jo     0x407faa
  407f49:	72 73                	jb     0x407fbe
  407f4b:	65 5f                	gs pop rdi
  407f4d:	66 36 34 00          	data16 ss xor al,0x0
  407f51:	70 61                	jo     0x407fb4
  407f53:	72 73                	jb     0x407fc8
  407f55:	65 5f                	gs pop rdi
  407f57:	72 61                	jb     0x407fba
  407f59:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407f5a:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  407f5e:	70 00                	jo     0x407f60
  407f60:	63 73 74             	movsxd esi,DWORD PTR [rbx+0x74]
  407f63:	72 6c                	jb     0x407fd1
  407f65:	65 6e                	outs   dx,BYTE PTR gs:[rsi]
  407f67:	00 2e                	add    BYTE PTR [rsi],ch
  407f69:	72 75                	jb     0x407fe0
  407f6b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407f6c:	74 69                	je     0x407fd7
  407f6e:	6d                   	ins    DWORD PTR es:[rdi],dx
  407f6f:	65 5f                	gs pop rdi
  407f71:	72 65                	jb     0x407fd8
  407f73:	6a 65                	push   0x65
  407f75:	63 74 00 2e          	movsxd esi,DWORD PTR [rax+rax*1+0x2e]
  407f79:	70 72                	jo     0x407fed
  407f7b:	69 6e 74 5f 6c 6f 6f 	imul   ebp,DWORD PTR [rsi+0x74],0x6f6f6c5f
  407f82:	70 00                	jo     0x407f84
  407f84:	2e 6f                	outs   dx,DWORD PTR ds:[rsi]
  407f86:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  407f89:	70 72                	jo     0x407ffd
  407f8b:	69 6e 74 5f 73 74 72 	imul   ebp,DWORD PTR [rsi+0x74],0x7274735f
  407f92:	69 6e 67 00 2e 70 72 	imul   ebp,DWORD PTR [rsi+0x67],0x72702e00
  407f99:	69 6e 74 5f 72 61 6e 	imul   ebp,DWORD PTR [rsi+0x74],0x6e61725f
  407fa0:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  407fa4:	70 00                	jo     0x407fa6
  407fa6:	6d                   	ins    DWORD PTR es:[rdi],dx
  407fa7:	61                   	(bad)
  407fa8:	6b 65 5f 6f          	imul   esp,DWORD PTR [rbp+0x5f],0x6f
  407fac:	75 74                	jne    0x408022
  407fae:	5f                   	pop    rdi
  407faf:	69 6e 64 65 78 00 70 	imul   ebp,DWORD PTR [rsi+0x64],0x70007865
  407fb6:	72 69                	jb     0x408021
  407fb8:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407fb9:	74 5f                	je     0x40801a
  407fbb:	62 69 74 73 5f       	(bad)
  407fc0:	6c                   	ins    BYTE PTR es:[rdi],dx
  407fc1:	69 6e 65 00 70 72 69 	imul   ebp,DWORD PTR [rsi+0x65],0x69727000
  407fc8:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407fc9:	74 5f                	je     0x40802a
  407fcb:	72 61                	jb     0x40802e
  407fcd:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407fce:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  407fd2:	70 5f                	jo     0x408033
  407fd4:	6c                   	ins    BYTE PTR es:[rdi],dx
  407fd5:	69 6e 65 00 6f 75 74 	imul   ebp,DWORD PTR [rsi+0x65],0x74756f00
  407fdc:	5f                   	pop    rdi
  407fdd:	73 74                	jae    0x408053
  407fdf:	72 69                	jb     0x40804a
  407fe1:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407fe2:	67 5f                	addr32 pop rdi
  407fe4:	70 72                	jo     0x408058
  407fe6:	65 66 69 78 00 6f 75 	imul   di,WORD PTR gs:[rax+0x0],0x756f
  407fed:	74 5f                	je     0x40804e
  407fef:	73 74                	jae    0x408065
  407ff1:	72 69                	jb     0x40805c
  407ff3:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  407ff4:	67 5f                	addr32 pop rdi
  407ff6:	70 72                	jo     0x40806a
  407ff8:	65 66 69 78 5f 65 6e 	imul   di,WORD PTR gs:[rax+0x5f],0x6e65
  407fff:	64 00 6e 65          	add    BYTE PTR fs:[rsi+0x65],ch
  408003:	77 6c                	ja     0x408071
  408005:	69 6e 65 00 2e 70 62 	imul   ebp,DWORD PTR [rsi+0x65],0x62702e00
  40800c:	5f                   	pop    rdi
  40800d:	62 61 64 00 2e       	(bad)
  408012:	70 75                	jo     0x408089
  408014:	5f                   	pop    rdi
  408015:	6c                   	ins    BYTE PTR es:[rdi],dx
  408016:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408017:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408018:	70 00                	jo     0x40801a
  40801a:	2e 70 75             	cs jo  0x408092
  40801d:	5f                   	pop    rdi
  40801e:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  408020:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408021:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  408024:	70 75                	jo     0x40809b
  408026:	5f                   	pop    rdi
  408027:	62 61 64 00 2e       	(bad)
  40802c:	70 69                	jo     0x408097
  40802e:	5f                   	pop    rdi
  40802f:	70 6f                	jo     0x4080a0
  408031:	73 00                	jae    0x408033
  408033:	2e 70 69             	cs jo  0x40809f
  408036:	5f                   	pop    rdi
  408037:	62 61 64 00 2e       	(bad)
  40803c:	70 69                	jo     0x4080a7
  40803e:	5f                   	pop    rdi
  40803f:	70 6f                	jo     0x4080b0
  408041:	73 69                	jae    0x4080ac
  408043:	74 69                	je     0x4080ae
  408045:	76 65                	jbe    0x4080ac
  408047:	5f                   	pop    rdi
  408048:	72 61                	jb     0x4080ab
  40804a:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40804b:	67 65 00 2e          	add    BYTE PTR gs:[esi],ch
  40804f:	70 66                	jo     0x4080b7
  408051:	5f                   	pop    rdi
  408052:	70 6c                	jo     0x4080c0
  408054:	75 73                	jne    0x4080c9
  408056:	00 2e                	add    BYTE PTR [rsi],ch
  408058:	70 66                	jo     0x4080c0
  40805a:	5f                   	pop    rdi
  40805b:	73 74                	jae    0x4080d1
  40805d:	61                   	(bad)
  40805e:	72 74                	jb     0x4080d4
  408060:	00 2e                	add    BYTE PTR [rsi],ch
  408062:	70 66                	jo     0x4080ca
  408064:	5f                   	pop    rdi
  408065:	6c                   	ins    BYTE PTR es:[rdi],dx
  408066:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408067:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408068:	70 00                	jo     0x40806a
  40806a:	2e 70 66             	cs jo  0x4080d3
  40806d:	5f                   	pop    rdi
  40806e:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  408070:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408071:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  408074:	70 66                	jo     0x4080dc
  408076:	5f                   	pop    rdi
  408077:	64 69 67 69 74 00 2e 	imul   esp,DWORD PTR fs:[rdi+0x69],0x702e0074
  40807e:	70 
  40807f:	66 5f                	pop    di
  408081:	62 61 64 00 2e       	(bad)
  408086:	70 66                	jo     0x4080ee
  408088:	5f                   	pop    rdi
  408089:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40808a:	65 78 74             	gs js  0x408101
  40808d:	00 2e                	add    BYTE PTR [rsi],ch
  40808f:	70 66                	jo     0x4080f7
  408091:	5f                   	pop    rdi
  408092:	73 69                	jae    0x4080fd
  408094:	67 6e                	outs   dx,BYTE PTR ds:[esi]
  408096:	00 2e                	add    BYTE PTR [rsi],ch
  408098:	70 66                	jo     0x408100
  40809a:	5f                   	pop    rdi
  40809b:	62 69 74 73 00       	(bad)
  4080a0:	2e 63 73 00          	cs movsxd esi,DWORD PTR [rbx+0x0]
  4080a4:	2e 63 73 5f          	cs movsxd esi,DWORD PTR [rbx+0x5f]
  4080a8:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  4080aa:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4080ab:	65 00 6f 75          	add    BYTE PTR gs:[rdi+0x75],ch
  4080af:	74 5f                	je     0x408110
  4080b1:	62 69 74 73 5f       	(bad)
  4080b6:	70 72                	jo     0x40812a
  4080b8:	65 66 69 78 00 2e 70 	imul   di,WORD PTR gs:[rax+0x0],0x702e
  4080bf:	62 5f 68 65 78       	(bad)
  4080c4:	00 2e                	add    BYTE PTR [rsi],ch
  4080c6:	70 62                	jo     0x40812a
  4080c8:	5f                   	pop    rdi
  4080c9:	64 69 67 69 74 00 2e 	imul   esp,DWORD PTR fs:[rdi+0x69],0x702e0074
  4080d0:	70 
  4080d1:	62 5f 73 74 6f       	(bad)
  4080d6:	72 65                	jb     0x40813d
  4080d8:	00 6f 75             	add    BYTE PTR [rdi+0x75],ch
  4080db:	74 5f                	je     0x40813c
  4080dd:	62 69 74 73 5f       	(bad)
  4080e2:	70 72                	jo     0x408156
  4080e4:	65 66 69 78 5f 65 6e 	imul   di,WORD PTR gs:[rax+0x5f],0x6e65
  4080eb:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  4080ee:	70 72                	jo     0x408162
  4080f0:	66 5f                	pop    di
  4080f2:	62 61 64 00 2e       	(bad)
  4080f7:	70 72                	jo     0x40816b
  4080f9:	66 5f                	pop    di
  4080fb:	70 6c                	jo     0x408169
  4080fd:	75 73                	jne    0x408172
  4080ff:	00 2e                	add    BYTE PTR [rsi],ch
  408101:	70 72                	jo     0x408175
  408103:	66 5f                	pop    di
  408105:	73 69                	jae    0x408170
  408107:	67 6e                	outs   dx,BYTE PTR ds:[esi]
  408109:	5f                   	pop    rdi
  40810a:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40810c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40810d:	65 00 2e             	add    BYTE PTR gs:[rsi],ch
  408110:	70 72                	jo     0x408184
  408112:	66 5f                	pop    di
  408114:	63 61 70             	movsxd esp,DWORD PTR [rcx+0x70]
  408117:	5f                   	pop    rdi
  408118:	72 65                	jb     0x40817f
  40811a:	61                   	(bad)
  40811b:	64 79 00             	fs jns 0x40811e
  40811e:	2e 70 72             	cs jo  0x408193
  408121:	66 5f                	pop    di
  408123:	6c                   	ins    BYTE PTR es:[rdi],dx
  408124:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408125:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408126:	70 00                	jo     0x408128
  408128:	2e 70 72             	cs jo  0x40819d
  40812b:	66 5f                	pop    di
  40812d:	66 69 6e 69 73 68    	imul   bp,WORD PTR [rsi+0x69],0x6873
  408133:	00 2e                	add    BYTE PTR [rsi],ch
  408135:	70 72                	jo     0x4081a9
  408137:	66 5f                	pop    di
  408139:	64 69 67 69 74 00 2e 	imul   esp,DWORD PTR fs:[rdi+0x69],0x702e0074
  408140:	70 
  408141:	72 66                	jb     0x4081a9
  408143:	5f                   	pop    rdi
  408144:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408145:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408146:	5f                   	pop    rdi
  408147:	66 72 61             	data16 jb 0x4081ab
  40814a:	63 00                	movsxd eax,DWORD PTR [rax]
  40814c:	2e 70 72             	cs jo  0x4081c1
  40814f:	66 5f                	pop    di
  408151:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408152:	65 78 74             	gs js  0x4081c9
  408155:	00 2e                	add    BYTE PTR [rsi],ch
  408157:	70 72                	jo     0x4081cb
  408159:	66 5f                	pop    di
  40815b:	69 6e 74 65 67 65 72 	imul   ebp,DWORD PTR [rsi+0x74],0x72656765
  408162:	00 2e                	add    BYTE PTR [rsi],ch
  408164:	70 72                	jo     0x4081d8
  408166:	66 5f                	pop    di
  408168:	73 69                	jae    0x4081d3
  40816a:	67 6e                	outs   dx,BYTE PTR ds:[esi]
  40816c:	00 2e                	add    BYTE PTR [rsi],ch
  40816e:	70 72                	jo     0x4081e2
  408170:	66 5f                	pop    di
  408172:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408173:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  408176:	70 72                	jo     0x4081ea
  408178:	66 5f                	pop    di
  40817a:	64 6f                	outs   dx,DWORD PTR fs:[rsi]
  40817c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40817d:	65 00 70 72          	add    BYTE PTR gs:[rax+0x72],dh
  408181:	66 5f                	pop    di
  408183:	68 65 78 5f 66       	push   0x665f7865
  408188:	69 78 65 64 00 68 65 	imul   edi,DWORD PTR [rax+0x65],0x65680064
  40818f:	78 5f                	js     0x4081f0
  408191:	64 69 67 69 74 73 00 	imul   esp,DWORD PTR fs:[rdi+0x69],0x2e007374
  408198:	2e 
  408199:	70 72                	jo     0x40820d
  40819b:	66 68 5f 6c          	pushw  0x6c5f
  40819f:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4081a0:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4081a1:	70 00                	jo     0x4081a3
  4081a3:	72 61                	jb     0x408206
  4081a5:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4081a6:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4081aa:	70 5f                	jo     0x40820b
  4081ac:	6c                   	ins    BYTE PTR es:[rdi],dx
  4081ad:	69 6e 65 5f 62 75 66 	imul   ebp,DWORD PTR [rsi+0x65],0x6675625f
  4081b4:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  4081b7:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4081b8:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4081bc:	70 5f                	jo     0x40821d
  4081be:	6c                   	ins    BYTE PTR es:[rdi],dx
  4081bf:	61                   	(bad)
  4081c0:	62 65 6c 00 72       	(bad)
  4081c5:	61                   	(bad)
  4081c6:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4081c7:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4081cb:	70 5f                	jo     0x40822c
  4081cd:	6c                   	ins    BYTE PTR es:[rdi],dx
  4081ce:	61                   	(bad)
  4081cf:	62 65 6c 5f 65       	(bad)
  4081d4:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4081d5:	64 00 2e             	add    BYTE PTR fs:[rsi],ch
  4081d8:	70 72                	jo     0x40824c
  4081da:	66 70 6c             	data16 jo 0x408249
  4081dd:	5f                   	pop    rdi
  4081de:	6c                   	ins    BYTE PTR es:[rdi],dx
  4081df:	69 6d 62 00 2e 70 72 	imul   ebp,DWORD PTR [rbp+0x62],0x72702e00
  4081e6:	66 70 6c             	data16 jo 0x408255
  4081e9:	5f                   	pop    rdi
  4081ea:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4081eb:	6c                   	ins    BYTE PTR es:[rdi],dx
  4081ec:	00 2e                	add    BYTE PTR [rsi],ch
  4081ee:	72 61                	jb     0x408251
  4081f0:	70 5f                	jo     0x408251
  4081f2:	6c                   	ins    BYTE PTR es:[rdi],dx
  4081f3:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4081f4:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4081f5:	70 00                	jo     0x4081f7
  4081f7:	2e 72 61             	cs jb  0x40825b
  4081fa:	70 5f                	jo     0x40825b
  4081fc:	72 65                	jb     0x408263
  4081fe:	74 75                	je     0x408275
  408200:	72 6e                	jb     0x408270
  408202:	00 2e                	add    BYTE PTR [rsi],ch
  408204:	72 61                	jb     0x408267
  408206:	70 5f                	jo     0x408267
  408208:	61                   	(bad)
  408209:	66 74 65             	data16 je 0x408271
  40820c:	72 5f                	jb     0x40826d
  40820e:	61                   	(bad)
  40820f:	70 70                	jo     0x408281
  408211:	6c                   	ins    BYTE PTR es:[rdi],dx
  408212:	79 00                	jns    0x408214
  408214:	2e 72 61             	cs jb  0x408278
  408217:	70 5f                	jo     0x408278
  408219:	61                   	(bad)
  40821a:	70 70                	jo     0x40828c
  40821c:	6c                   	ins    BYTE PTR es:[rdi],dx
  40821d:	79 5f                	jns    0x40827e
  40821f:	69 00 2e 72 61 70    	imul   eax,DWORD PTR [rax],0x7061722e
  408225:	5f                   	pop    rdi
  408226:	61                   	(bad)
  408227:	70 70                	jo     0x408299
  408229:	6c                   	ins    BYTE PTR es:[rdi],dx
  40822a:	79 5f                	jns    0x40828b
  40822c:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  40822f:	79 00                	jns    0x408231
  408231:	2e 72 61             	cs jb  0x408295
  408234:	70 5f                	jo     0x408295
  408236:	61                   	(bad)
  408237:	70 70                	jo     0x4082a9
  408239:	6c                   	ins    BYTE PTR es:[rdi],dx
  40823a:	79 5f                	jns    0x40829b
  40823c:	6a 00                	push   0x0
  40823e:	2e 72 61             	cs jb  0x4082a2
  408241:	70 5f                	jo     0x4082a2
  408243:	61                   	(bad)
  408244:	70 70                	jo     0x4082b6
  408246:	6c                   	ins    BYTE PTR es:[rdi],dx
  408247:	79 5f                	jns    0x4082a8
  408249:	73 74                	jae    0x4082bf
  40824b:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40824c:	72 65                	jb     0x4082b3
  40824e:	00 2e                	add    BYTE PTR [rsi],ch
  408250:	72 61                	jb     0x4082b3
  408252:	70 5f                	jo     0x4082b3
  408254:	61                   	(bad)
  408255:	70 70                	jo     0x4082c7
  408257:	6c                   	ins    BYTE PTR es:[rdi],dx
  408258:	79 5f                	jns    0x4082b9
  40825a:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  40825d:	79 5f                	jns    0x4082be
  40825f:	6c                   	ins    BYTE PTR es:[rdi],dx
  408260:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408261:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408262:	70 00                	jo     0x408264
  408264:	2e 72 61             	cs jb  0x4082c8
  408267:	70 5f                	jo     0x4082c8
  408269:	73 71                	jae    0x4082dc
  40826b:	75 61                	jne    0x4082ce
  40826d:	72 65                	jb     0x4082d4
  40826f:	5f                   	pop    rdi
  408270:	69 00 2e 72 61 70    	imul   eax,DWORD PTR [rax],0x7061722e
  408276:	5f                   	pop    rdi
  408277:	73 71                	jae    0x4082ea
  408279:	75 61                	jne    0x4082dc
  40827b:	72 65                	jb     0x4082e2
  40827d:	5f                   	pop    rdi
  40827e:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  408281:	79 00                	jns    0x408283
  408283:	2e 72 61             	cs jb  0x4082e7
  408286:	70 5f                	jo     0x4082e7
  408288:	73 71                	jae    0x4082fb
  40828a:	75 61                	jne    0x4082ed
  40828c:	72 65                	jb     0x4082f3
  40828e:	5f                   	pop    rdi
  40828f:	62 5f 6b 00 2e       	(bad)
  408294:	72 61                	jb     0x4082f7
  408296:	70 5f                	jo     0x4082f7
  408298:	73 71                	jae    0x40830b
  40829a:	75 61                	jne    0x4082fd
  40829c:	72 65                	jb     0x408303
  40829e:	5f                   	pop    rdi
  40829f:	62 5f 73 74 6f       	(bad)
  4082a4:	72 65                	jb     0x40830b
  4082a6:	00 2e                	add    BYTE PTR [rsi],ch
  4082a8:	72 61                	jb     0x40830b
  4082aa:	70 5f                	jo     0x40830b
  4082ac:	73 71                	jae    0x40831f
  4082ae:	75 61                	jne    0x408311
  4082b0:	72 65                	jb     0x408317
  4082b2:	5f                   	pop    rdi
  4082b3:	6a 00                	push   0x0
  4082b5:	2e 72 61             	cs jb  0x408319
  4082b8:	70 5f                	jo     0x408319
  4082ba:	73 71                	jae    0x40832d
  4082bc:	75 61                	jne    0x40831f
  4082be:	72 65                	jb     0x408325
  4082c0:	5f                   	pop    rdi
  4082c1:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4082c2:	65 78 74             	gs js  0x408339
  4082c5:	5f                   	pop    rdi
  4082c6:	69 00 2e 72 61 70    	imul   eax,DWORD PTR [rax],0x7061722e
  4082cc:	5f                   	pop    rdi
  4082cd:	73 71                	jae    0x408340
  4082cf:	75 61                	jne    0x408332
  4082d1:	72 65                	jb     0x408338
  4082d3:	5f                   	pop    rdi
  4082d4:	6b 00 2e             	imul   eax,DWORD PTR [rax],0x2e
  4082d7:	72 61                	jb     0x40833a
  4082d9:	70 5f                	jo     0x40833a
  4082db:	73 71                	jae    0x40834e
  4082dd:	75 61                	jne    0x408340
  4082df:	72 65                	jb     0x408346
  4082e1:	5f                   	pop    rdi
  4082e2:	73 74                	jae    0x408358
  4082e4:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4082e5:	72 65                	jb     0x40834c
  4082e7:	00 2e                	add    BYTE PTR [rsi],ch
  4082e9:	72 61                	jb     0x40834c
  4082eb:	70 5f                	jo     0x40834c
  4082ed:	73 71                	jae    0x408360
  4082ef:	75 61                	jne    0x408352
  4082f1:	72 65                	jb     0x408358
  4082f3:	5f                   	pop    rdi
  4082f4:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  4082f7:	79 5f                	jns    0x408358
  4082f9:	61                   	(bad)
  4082fa:	00 2e                	add    BYTE PTR [rsi],ch
  4082fc:	72 61                	jb     0x40835f
  4082fe:	70 5f                	jo     0x40835f
  408300:	73 71                	jae    0x408373
  408302:	75 61                	jne    0x408365
  408304:	72 65                	jb     0x40836b
  408306:	5f                   	pop    rdi
  408307:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  40830a:	79 5f                	jns    0x40836b
  40830c:	62 5f 62 65 67       	(bad)
  408311:	69 6e 00 2e 72 61 70 	imul   ebp,DWORD PTR [rsi+0x0],0x7061722e
  408318:	5f                   	pop    rdi
  408319:	73 71                	jae    0x40838c
  40831b:	75 61                	jne    0x40837e
  40831d:	72 65                	jb     0x408384
  40831f:	5f                   	pop    rdi
  408320:	63 6f 70             	movsxd ebp,DWORD PTR [rdi+0x70]
  408323:	79 5f                	jns    0x408384
  408325:	62                   	(bad)
  408326:	00 72 75             	add    BYTE PTR [rdx+0x75],dh
  408329:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40832a:	74 69                	je     0x408395
  40832c:	6d                   	ins    DWORD PTR es:[rdi],dx
  40832d:	65 5f                	gs pop rdi
  40832f:	62 73 73 5f 73       	(bad)
  408334:	65 6e                	outs   dx,BYTE PTR gs:[rsi]
  408336:	74 69                	je     0x4083a1
  408338:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408339:	65 6c                	gs ins BYTE PTR es:[rdi],dx
  40833b:	00 6f 75             	add    BYTE PTR [rdi+0x75],ch
  40833e:	74 70                	je     0x4083b0
  408340:	75 74                	jne    0x4083b6
  408342:	5f                   	pop    rdi
  408343:	61                   	(bad)
  408344:	75 78                	jne    0x4083be
  408346:	5f                   	pop    rdi
  408347:	62 61 73 65 5f       	(bad)
  40834c:	70 61                	jo     0x4083af
  40834e:	74 63                	je     0x4083b3
  408350:	68 00 6f 75 74       	push   0x74756f00
  408355:	70 75                	jo     0x4083cc
  408357:	74 5f                	je     0x4083b8
  408359:	63 6f 75             	movsxd ebp,DWORD PTR [rdi+0x75]
  40835c:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40835d:	74 5f                	je     0x4083be
  40835f:	70 61                	jo     0x4083c2
  408361:	74 63                	je     0x4083c6
  408363:	68 00 72 61 6e       	push   0x6e617200
  408368:	6b 6e 5f 61          	imul   ebp,DWORD PTR [rsi+0x5f],0x61
  40836c:	66 66 69 6e 65 5f 70 	data16 imul bp,WORD PTR [rsi+0x65],0x705f
  408373:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408374:	77 65                	ja     0x4083db
  408376:	72 5f                	jb     0x4083d7
  408378:	75 36                	jne    0x4083b0
  40837a:	34 00                	xor    al,0x0
  40837c:	72 61                	jb     0x4083df
  40837e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40837f:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408383:	70 5f                	jo     0x4083e4
  408385:	61                   	(bad)
  408386:	64 64 00 70 72       	fs add BYTE PTR fs:[rax+0x72],dh
  40838b:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40838c:	67 72 61             	addr32 jb 0x4083f0
  40838f:	6d                   	ins    DWORD PTR es:[rdi],dx
  408390:	5f                   	pop    rdi
  408391:	63 6f 64             	movsxd ebp,DWORD PTR [rdi+0x64]
  408394:	65 5f                	gs pop rdi
  408396:	72 65                	jb     0x4083fd
  408398:	6c                   	ins    BYTE PTR es:[rdi],dx
  408399:	5f                   	pop    rdi
  40839a:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  40839b:	66 66 73 65          	data16 data16 jae 0x408404
  40839f:	74 5f                	je     0x408400
  4083a1:	70 61                	jo     0x408404
  4083a3:	74 63                	je     0x408408
  4083a5:	68 00 70 72 6f       	push   0x6f727000
  4083aa:	67 72 61             	addr32 jb 0x40840e
  4083ad:	6d                   	ins    DWORD PTR es:[rdi],dx
  4083ae:	5f                   	pop    rdi
  4083af:	74 72                	je     0x408423
  4083b1:	61                   	(bad)
  4083b2:	69 6c 65 72 5f 66 69 	imul   ebp,DWORD PTR [rbp+riz*2+0x72],0x6c69665f
  4083b9:	6c 
  4083ba:	65 5f                	gs pop rdi
  4083bc:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4083bd:	66 66 73 65          	data16 data16 jae 0x408426
  4083c1:	74 5f                	je     0x408422
  4083c3:	70 61                	jo     0x408426
  4083c5:	74 63                	je     0x40842a
  4083c7:	68 00 72 61 6e       	push   0x6e617200
  4083cc:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4083d0:	70 5f                	jo     0x408431
  4083d2:	65 78 70             	gs js  0x408445
  4083d5:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  4083d8:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4083d9:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4083dd:	70 5f                	jo     0x40843e
  4083df:	63 6d 70             	movsxd ebp,DWORD PTR [rbp+0x70]
  4083e2:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  4083e5:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4083e6:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4083ea:	70 5f                	jo     0x40844b
  4083ec:	61                   	(bad)
  4083ed:	62 73 00 72 61       	(bad)
  4083f2:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4083f3:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4083f7:	70 5f                	jo     0x408458
  4083f9:	73 69                	jae    0x408464
  4083fb:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4083fc:	00 64 79 6e          	add    BYTE PTR [rcx+rdi*2+0x6e],ah
  408400:	61                   	(bad)
  408401:	6d                   	ins    DWORD PTR es:[rdi],dx
  408402:	69 63 5f 61 72 65 6e 	imul   esp,DWORD PTR [rbx+0x5f],0x6e657261
  408409:	61                   	(bad)
  40840a:	5f                   	pop    rdi
  40840b:	62 79 74 65 73       	(bad)
  408410:	5f                   	pop    rdi
  408411:	70 61                	jo     0x408474
  408413:	74 63                	je     0x408478
  408415:	68 00 72 61 6e       	push   0x6e617200
  40841a:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  40841e:	70 5f                	jo     0x40847f
  408420:	66 72 6f             	data16 jb 0x408492
  408423:	6d                   	ins    DWORD PTR es:[rdi],dx
  408424:	5f                   	pop    rdi
  408425:	75 36                	jne    0x40845d
  408427:	34 00                	xor    al,0x0
  408429:	72 61                	jb     0x40848c
  40842b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40842c:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408430:	70 5f                	jo     0x408491
  408432:	74 6f                	je     0x4084a3
  408434:	5f                   	pop    rdi
  408435:	66 36 34 5f          	data16 ss xor al,0x5f
  408439:	62 69 74 73 00       	(bad)
  40843e:	72 61                	jb     0x4084a1
  408440:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408441:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408445:	70 5f                	jo     0x4084a6
  408447:	63 6f 6e             	movsxd ebp,DWORD PTR [rdi+0x6e]
  40844a:	76 65                	jbe    0x4084b1
  40844c:	72 74                	jb     0x4084c2
  40844e:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  408451:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408452:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408456:	70 5f                	jo     0x4084b7
  408458:	6d                   	ins    DWORD PTR es:[rdi],dx
  408459:	75 6c                	jne    0x4084c7
  40845b:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  40845e:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40845f:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408463:	70 5f                	jo     0x4084c4
  408465:	6c                   	ins    BYTE PTR es:[rdi],dx
  408466:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  408467:	67 00 72 61          	add    BYTE PTR [edx+0x61],dh
  40846b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40846c:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408470:	70 5f                	jo     0x4084d1
  408472:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408473:	65 67 00 72 61       	add    BYTE PTR gs:[edx+0x61],dh
  408478:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408479:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  40847d:	70 5f                	jo     0x4084de
  40847f:	66 72 6f             	data16 jb 0x4084f1
  408482:	6d                   	ins    DWORD PTR es:[rdi],dx
  408483:	5f                   	pop    rdi
  408484:	69 36 34 00 69 6e    	imul   esi,DWORD PTR [rsi],0x6e690034
  40848a:	70 75                	jo     0x408501
  40848c:	74 5f                	je     0x4084ed
  40848e:	63 6f 75             	movsxd ebp,DWORD PTR [rdi+0x75]
  408491:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408492:	74 5f                	je     0x4084f3
  408494:	70 61                	jo     0x4084f7
  408496:	74 63                	je     0x4084fb
  408498:	68 00 70 72 6f       	push   0x6f727000
  40849d:	67 72 61             	addr32 jb 0x408501
  4084a0:	6d                   	ins    DWORD PTR es:[rdi],dx
  4084a1:	5f                   	pop    rdi
  4084a2:	74 72                	je     0x408516
  4084a4:	61                   	(bad)
  4084a5:	69 6c 65 72 5f 73 69 	imul   ebp,DWORD PTR [rbp+riz*2+0x72],0x7a69735f
  4084ac:	7a 
  4084ad:	65 5f                	gs pop rdi
  4084af:	70 61                	jo     0x408512
  4084b1:	74 63                	je     0x408516
  4084b3:	68 00 70 72 6f       	push   0x6f727000
  4084b8:	67 72 61             	addr32 jb 0x40851c
  4084bb:	6d                   	ins    DWORD PTR es:[rdi],dx
  4084bc:	5f                   	pop    rdi
  4084bd:	73 6c                	jae    0x40852b
  4084bf:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4084c0:	74 00                	je     0x4084c2
  4084c2:	6f                   	outs   dx,DWORD PTR ds:[rsi]
  4084c3:	75 74                	jne    0x408539
  4084c5:	70 75                	jo     0x40853c
  4084c7:	74 5f                	je     0x408528
  4084c9:	70 61                	jo     0x40852c
  4084cb:	67 65 73 5f          	addr32 gs jae 0x40852e
  4084cf:	62 61 73 65 5f       	(bad)
  4084d4:	70 61                	jo     0x408537
  4084d6:	74 63                	je     0x40853b
  4084d8:	68 00 72 61 6e       	push   0x6e617200
  4084dd:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  4084e1:	70 5f                	jo     0x408542
  4084e3:	63 6f 73             	movsxd ebp,DWORD PTR [rdi+0x73]
  4084e6:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  4084e9:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4084ea:	6b 6e 5f 69          	imul   ebp,DWORD PTR [rsi+0x5f],0x69
  4084ee:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  4084ef:	70 75                	jo     0x408566
  4084f1:	74 5f                	je     0x408552
  4084f3:	65 6e                	outs   dx,BYTE PTR gs:[rsi]
  4084f5:	64 5f                	fs pop rdi
  4084f7:	70 61                	jo     0x40855a
  4084f9:	74 63                	je     0x40855e
  4084fb:	68 00 69 6e 70       	push   0x706e6900
  408500:	75 74                	jne    0x408576
  408502:	5f                   	pop    rdi
  408503:	61                   	(bad)
  408504:	75 78                	jne    0x40857e
  408506:	5f                   	pop    rdi
  408507:	62 61 73 65 5f       	(bad)
  40850c:	70 61                	jo     0x40856f
  40850e:	74 63                	je     0x408573
  408510:	68 00 72 61 6e       	push   0x6e617200
  408515:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  408519:	70 5f                	jo     0x40857a
  40851b:	66 72 6f             	data16 jb 0x40858d
  40851e:	6d                   	ins    DWORD PTR es:[rdi],dx
  40851f:	5f                   	pop    rdi
  408520:	66 36 34 5f          	data16 ss xor al,0x5f
  408524:	62 69 74 73 00       	(bad)
  408529:	72 61                	jb     0x40858c
  40852b:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40852c:	6b 6e 5f 69          	imul   ebp,DWORD PTR [rsi+0x5f],0x69
  408530:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408531:	70 75                	jo     0x4085a8
  408533:	74 5f                	je     0x408594
  408535:	62 61 73 65 5f       	(bad)
  40853a:	70 61                	jo     0x40859d
  40853c:	74 63                	je     0x4085a1
  40853e:	68 00 69 6e 70       	push   0x706e6900
  408543:	75 74                	jne    0x4085b9
  408545:	5f                   	pop    rdi
  408546:	76 61                	jbe    0x4085a9
  408548:	6c                   	ins    BYTE PTR es:[rdi],dx
  408549:	75 65                	jne    0x4085b0
  40854b:	73 5f                	jae    0x4085ac
  40854d:	62 61 73 65 5f       	(bad)
  408552:	70 61                	jo     0x4085b5
  408554:	74 63                	je     0x4085b9
  408556:	68 00 72 61 6e       	push   0x6e617200
  40855b:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  40855f:	70 5f                	jo     0x4085c0
  408561:	64 69 76 00 72 61 6e 	imul   esi,DWORD PTR fs:[rsi+0x0],0x6b6e6172
  408568:	6b 
  408569:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  40856a:	5f                   	pop    rdi
  40856b:	66 70 5f             	data16 jo 0x4085cd
  40856e:	73 71                	jae    0x4085e1
  408570:	72 74                	jb     0x4085e6
  408572:	00 72 61             	add    BYTE PTR [rdx+0x61],dh
  408575:	6e                   	outs   dx,BYTE PTR ds:[rsi]
  408576:	6b 6e 5f 66          	imul   ebp,DWORD PTR [rsi+0x5f],0x66
  40857a:	70 5f                	jo     0x4085db
  40857c:	73 75                	jae    0x4085f3
  40857e:	62                   	(bad)
  40857f:	00 00                	add    BYTE PTR [rax],al
  408581:	2e 73 79             	cs jae 0x4085fd
  408584:	6d                   	ins    DWORD PTR es:[rdi],dx
  408585:	74 61                	je     0x4085e8
  408587:	62                   	(bad)
  408588:	00 2e                	add    BYTE PTR [rsi],ch
  40858a:	73 74                	jae    0x408600
  40858c:	72 74                	jb     0x408602
  40858e:	61                   	(bad)
  40858f:	62                   	(bad)
  408590:	00 2e                	add    BYTE PTR [rsi],ch
  408592:	73 68                	jae    0x4085fc
  408594:	73 74                	jae    0x40860a
  408596:	72 74                	jb     0x40860c
  408598:	61                   	(bad)
  408599:	62                   	(bad)
  40859a:	00 2e                	add    BYTE PTR [rsi],ch
  40859c:	74 65                	je     0x408603
  40859e:	78 74                	js     0x408614
  4085a0:	00 2e                	add    BYTE PTR [rsi],ch
  4085a2:	64 61                	fs (bad)
  4085a4:	74 61                	je     0x408607
  4085a6:	00 2e                	add    BYTE PTR [rsi],ch
  4085a8:	62 73 73 00 00       	(bad)
	...
  4085ed:	00 00                	add    BYTE PTR [rax],al
  4085ef:	00 1b                	add    BYTE PTR [rbx],bl
  4085f1:	00 00                	add    BYTE PTR [rax],al
  4085f3:	00 01                	add    BYTE PTR [rcx],al
  4085f5:	00 00                	add    BYTE PTR [rax],al
  4085f7:	00 06                	add    BYTE PTR [rsi],al
  4085f9:	00 00                	add    BYTE PTR [rax],al
  4085fb:	00 00                	add    BYTE PTR [rax],al
  4085fd:	00 00                	add    BYTE PTR [rax],al
  4085ff:	00 c0                	add    al,al
  408601:	00 40 00             	add    BYTE PTR [rax+0x0],al
  408604:	00 00                	add    BYTE PTR [rax],al
  408606:	00 00                	add    BYTE PTR [rax],al
  408608:	c0 00 00             	rol    BYTE PTR [rax],0x0
  40860b:	00 00                	add    BYTE PTR [rax],al
  40860d:	00 00                	add    BYTE PTR [rax],al
  40860f:	00 dd                	add    ch,bl
  408611:	3e 00 00             	ds add BYTE PTR [rax],al
	...
  408620:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40862f:	00 21                	add    BYTE PTR [rcx],ah
  408631:	00 00                	add    BYTE PTR [rax],al
  408633:	00 01                	add    BYTE PTR [rcx],al
  408635:	00 00                	add    BYTE PTR [rax],al
  408637:	00 03                	add    BYTE PTR [rbx],al
	...
  408641:	40                   	rex
  408642:	40 00 00             	rex add BYTE PTR [rax],al
  408645:	00 00                	add    BYTE PTR [rax],al
  408647:	00 00                	add    BYTE PTR [rax],al
  408649:	40 00 00             	rex add BYTE PTR [rax],al
  40864c:	00 00                	add    BYTE PTR [rax],al
  40864e:	00 00                	add    BYTE PTR [rax],al
  408650:	e7 01                	out    0x1,eax
	...
  40865e:	00 00                	add    BYTE PTR [rax],al
  408660:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40866f:	00 27                	add    BYTE PTR [rdi],ah
  408671:	00 00                	add    BYTE PTR [rax],al
  408673:	00 08                	add    BYTE PTR [rax],cl
  408675:	00 00                	add    BYTE PTR [rax],al
  408677:	00 03                	add    BYTE PTR [rbx],al
	...
  408681:	50                   	push   rax
  408682:	40 00 00             	rex add BYTE PTR [rax],al
  408685:	00 00                	add    BYTE PTR [rax],al
  408687:	00 e7                	add    bh,ah
  408689:	41 00 00             	add    BYTE PTR [r8],al
  40868c:	00 00                	add    BYTE PTR [rax],al
  40868e:	00 00                	add    BYTE PTR [rax],al
  408690:	40 00 00             	rex add BYTE PTR [rax],al
	...
  40869f:	00 40 00             	add    BYTE PTR [rax+0x0],al
	...
  4086ae:	00 00                	add    BYTE PTR [rax],al
  4086b0:	01 00                	add    DWORD PTR [rax],eax
  4086b2:	00 00                	add    BYTE PTR [rax],al
  4086b4:	02 00                	add    al,BYTE PTR [rax]
	...
  4086c6:	00 00                	add    BYTE PTR [rax],al
  4086c8:	e8 41 00 00 00       	call   0x40870e
  4086cd:	00 00                	add    BYTE PTR [rax],al
  4086cf:	00 20                	add    BYTE PTR [rax],ah
  4086d1:	2b 00                	sub    eax,DWORD PTR [rax]
  4086d3:	00 00                	add    BYTE PTR [rax],al
  4086d5:	00 00                	add    BYTE PTR [rax],al
  4086d7:	00 05 00 00 00 ac    	add    BYTE PTR [rip+0xffffffffac000000],al        # 0xffffffffac4086dd
  4086dd:	01 00                	add    DWORD PTR [rax],eax
  4086df:	00 08                	add    BYTE PTR [rax],cl
  4086e1:	00 00                	add    BYTE PTR [rax],al
  4086e3:	00 00                	add    BYTE PTR [rax],al
  4086e5:	00 00                	add    BYTE PTR [rax],al
  4086e7:	00 18                	add    BYTE PTR [rax],bl
  4086e9:	00 00                	add    BYTE PTR [rax],al
  4086eb:	00 00                	add    BYTE PTR [rax],al
  4086ed:	00 00                	add    BYTE PTR [rax],al
  4086ef:	00 09                	add    BYTE PTR [rcx],cl
  4086f1:	00 00                	add    BYTE PTR [rax],al
  4086f3:	00 03                	add    BYTE PTR [rbx],al
	...
  408705:	00 00                	add    BYTE PTR [rax],al
  408707:	00 08                	add    BYTE PTR [rax],cl
  408709:	6d                   	ins    DWORD PTR es:[rdi],dx
  40870a:	00 00                	add    BYTE PTR [rax],al
  40870c:	00 00                	add    BYTE PTR [rax],al
  40870e:	00 00                	add    BYTE PTR [rax],al
  408710:	78 18                	js     0x40872a
	...
  40871e:	00 00                	add    BYTE PTR [rax],al
  408720:	01 00                	add    DWORD PTR [rax],eax
	...
  40872e:	00 00                	add    BYTE PTR [rax],al
  408730:	11 00                	adc    DWORD PTR [rax],eax
  408732:	00 00                	add    BYTE PTR [rax],al
  408734:	03 00                	add    eax,DWORD PTR [rax]
	...
  408746:	00 00                	add    BYTE PTR [rax],al
  408748:	80 85 00 00 00 00 00 	add    BYTE PTR [rbp+0x0],0x0
  40874f:	00 2c 00             	add    BYTE PTR [rax+rax*1],ch
	...
  40875e:	00 00                	add    BYTE PTR [rax],al
  408760:	01 00                	add    DWORD PTR [rax],eax
	...
  408ffe:	00 00                	add    BYTE PTR [rax],al
  409000:	03 00                	add    eax,DWORD PTR [rax]
  409002:	00 00                	add    BYTE PTR [rax],al
  409004:	03 00                	add    eax,DWORD PTR [rax]
  409006:	00 00                	add    BYTE PTR [rax],al
  409008:	03 00                	add    eax,DWORD PTR [rax]
  40900a:	00 00                	add    BYTE PTR [rax],al
  40900c:	03 00                	add    eax,DWORD PTR [rax]
  40900e:	00 00                	add    BYTE PTR [rax],al
  409010:	03 00                	add    eax,DWORD PTR [rax]
  409012:	00 00                	add    BYTE PTR [rax],al
  409014:	03 00                	add    eax,DWORD PTR [rax]
  409016:	00 00                	add    BYTE PTR [rax],al
  409018:	03 00                	add    eax,DWORD PTR [rax]
	...
  40903e:	00 00                	add    BYTE PTR [rax],al
  409040:	53                   	push   rbx
  409041:	41 54                	push   r12
  409043:	41 55                	push   r13
  409045:	41 56                	push   r14
  409047:	41 57                	push   r15
  409049:	48 83 ec 40          	sub    rsp,0x40
  40904d:	83 3d b4 05 00 00 00 	cmp    DWORD PTR [rip+0x5b4],0x0        # 0x409608
  409054:	74 1b                	je     0x409071
  409056:	83 3d af 05 00 00 01 	cmp    DWORD PTR [rip+0x5af],0x1        # 0x40960c
  40905d:	0f 85 0f 02 00 00    	jne    0x409272
  409063:	48 83 3d ad 05 00 00 	cmp    QWORD PTR [rip+0x5ad],0x0        # 0x409618
  40906a:	00 
  40906b:	0f 84 01 02 00 00    	je     0x409272
  409071:	83 3d b4 05 00 00 00 	cmp    DWORD PTR [rip+0x5b4],0x0        # 0x40962c
  409078:	74 1a                	je     0x409094
  40907a:	8b 35 b0 05 00 00    	mov    esi,DWORD PTR [rip+0x5b0]        # 0x409630
  409080:	85 f6                	test   esi,esi
  409082:	74 10                	je     0x409094
  409084:	b8 cb 00 00 00       	mov    eax,0xcb
  409089:	31 ff                	xor    edi,edi
  40908b:	48 8d 15 ae 05 00 00 	lea    rdx,[rip+0x5ae]        # 0x409640
  409092:	0f 05                	syscall
  409094:	8b 05 66 05 00 00    	mov    eax,DWORD PTR [rip+0x566]        # 0x409600
  40909a:	85 c0                	test   eax,eax
  40909c:	0f 84 d7 01 00 00    	je     0x409279
  4090a2:	48 89 c6             	mov    rsi,rax
  4090a5:	48 c1 e6 06          	shl    rsi,0x6
  4090a9:	48 83 c6 18          	add    rsi,0x18
  4090ad:	0f 82 bf 01 00 00    	jb     0x409272
  4090b3:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
  4090b8:	b8 09 00 00 00       	mov    eax,0x9
  4090bd:	31 ff                	xor    edi,edi
  4090bf:	ba 03 00 00 00       	mov    edx,0x3
  4090c4:	41 ba 22 00 00 00    	mov    r10d,0x22
  4090ca:	41 b8 ff ff ff ff    	mov    r8d,0xffffffff
  4090d0:	45 31 c9             	xor    r9d,r9d
  4090d3:	0f 05                	syscall
  4090d5:	48 85 c0             	test   rax,rax
  4090d8:	0f 88 94 01 00 00    	js     0x409272
  4090de:	49 89 c7             	mov    r15,rax
  4090e1:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
  4090e6:	e8 b6 02 00 00       	call   0x4093a1
  4090eb:	85 c0                	test   eax,eax
  4090ed:	0f 85 6e 01 00 00    	jne    0x409261
  4090f3:	8b 05 07 05 00 00    	mov    eax,DWORD PTR [rip+0x507]        # 0x409600
  4090f9:	48 89 c6             	mov    rsi,rax
  4090fc:	48 c1 e6 10          	shl    rsi,0x10
  409100:	48 85 f6             	test   rsi,rsi
  409103:	0f 84 58 01 00 00    	je     0x409261
  409109:	56                   	push   rsi
  40910a:	e8 de 04 00 00       	call   0x4095ed
  40910f:	5e                   	pop    rsi
  409110:	48 89 70 08          	mov    QWORD PTR [rax+0x8],rsi
  409114:	b8 09 00 00 00       	mov    eax,0x9
  409119:	31 ff                	xor    edi,edi
  40911b:	ba 03 00 00 00       	mov    edx,0x3
  409120:	41 ba 22 00 02 00    	mov    r10d,0x20022
  409126:	41 b8 ff ff ff ff    	mov    r8d,0xffffffff
  40912c:	45 31 c9             	xor    r9d,r9d
  40912f:	0f 05                	syscall
  409131:	48 85 c0             	test   rax,rax
  409134:	0f 88 27 01 00 00    	js     0x409261
  40913a:	50                   	push   rax
  40913b:	e8 ad 04 00 00       	call   0x4095ed
  409140:	48 89 c2             	mov    rdx,rax
  409143:	58                   	pop    rax
  409144:	48 89 02             	mov    QWORD PTR [rdx],rax
  409147:	31 db                	xor    ebx,ebx
  409149:	45 31 f6             	xor    r14d,r14d
  40914c:	c7 44 24 18 ff ff ff 	mov    DWORD PTR [rsp+0x18],0xffffffff
  409153:	ff 
  409154:	e8 e4 03 00 00       	call   0x40953d
  409159:	48 89 44 24 20       	mov    QWORD PTR [rsp+0x20],rax
  40915e:	3b 1d 9c 04 00 00    	cmp    ebx,DWORD PTR [rip+0x49c]        # 0x409600
  409164:	73 67                	jae    0x4091cd
  409166:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
  40916b:	83 3c 9a 00          	cmp    DWORD PTR [rdx+rbx*4],0x0
  40916f:	75 58                	jne    0x4091c9
  409171:	41 ff c6             	inc    r14d
  409174:	e8 3a 04 00 00       	call   0x4095b3
  409179:	83 3c 98 02          	cmp    DWORD PTR [rax+rbx*4],0x2
  40917d:	74 3a                	je     0x4091b9
  40917f:	83 7c 24 18 ff       	cmp    DWORD PTR [rsp+0x18],0xffffffff
  409184:	75 06                	jne    0x40918c
  409186:	89 5c 24 18          	mov    DWORD PTR [rsp+0x18],ebx
  40918a:	eb 3d                	jmp    0x4091c9
  40918c:	89 df                	mov    edi,ebx
  40918e:	e8 66 02 00 00       	call   0x4093f9
  409193:	85 c0                	test   eax,eax
  409195:	74 10                	je     0x4091a7
  409197:	89 df                	mov    edi,ebx
  409199:	be 11 07 00 00       	mov    esi,0x711
  40919e:	e8 e6 00 00 00       	call   0x409289
  4091a3:	85 c0                	test   eax,eax
  4091a5:	74 22                	je     0x4091c9
  4091a7:	89 df                	mov    edi,ebx
  4091a9:	be 11 07 00 00       	mov    esi,0x711
  4091ae:	e8 72 02 00 00       	call   0x409425
  4091b3:	85 c0                	test   eax,eax
  4091b5:	75 76                	jne    0x40922d
  4091b7:	eb 10                	jmp    0x4091c9
  4091b9:	89 df                	mov    edi,ebx
  4091bb:	be 11 07 00 00       	mov    esi,0x711
  4091c0:	e8 c4 00 00 00       	call   0x409289
  4091c5:	85 c0                	test   eax,eax
  4091c7:	75 64                	jne    0x40922d
  4091c9:	ff c3                	inc    ebx
  4091cb:	eb 91                	jmp    0x40915e
  4091cd:	45 85 f6             	test   r14d,r14d
  4091d0:	74 5b                	je     0x40922d
  4091d2:	8b 7c 24 18          	mov    edi,DWORD PTR [rsp+0x18]
  4091d6:	83 ff ff             	cmp    edi,0xffffffff
  4091d9:	74 0e                	je     0x4091e9
  4091db:	be 11 07 00 00       	mov    esi,0x711
  4091e0:	e8 40 02 00 00       	call   0x409425
  4091e5:	85 c0                	test   eax,eax
  4091e7:	75 44                	jne    0x40922d
  4091e9:	e8 00 02 00 00       	call   0x4093ee
  4091ee:	c7 44 24 08 00 00 00 	mov    DWORD PTR [rsp+0x8],0x0
  4091f5:	00 
  4091f6:	b8 3d 00 00 00       	mov    eax,0x3d
  4091fb:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
  409202:	48 8d 74 24 08       	lea    rsi,[rsp+0x8]
  409207:	31 d2                	xor    edx,edx
  409209:	45 31 d2             	xor    r10d,r10d
  40920c:	0f 05                	syscall
  40920e:	48 83 f8 f6          	cmp    rax,0xfffffffffffffff6
  409212:	74 14                	je     0x409228
  409214:	48 83 f8 fc          	cmp    rax,0xfffffffffffffffc
  409218:	74 d4                	je     0x4091ee
  40921a:	48 85 c0             	test   rax,rax
  40921d:	78 0e                	js     0x40922d
  40921f:	83 7c 24 08 00       	cmp    DWORD PTR [rsp+0x8],0x0
  409224:	75 07                	jne    0x40922d
  409226:	eb c6                	jmp    0x4091ee
  409228:	45 31 f6             	xor    r14d,r14d
  40922b:	eb 06                	jmp    0x409233
  40922d:	41 be 01 00 00 00    	mov    r14d,0x1
  409233:	e8 b5 03 00 00       	call   0x4095ed
  409238:	48 8b 38             	mov    rdi,QWORD PTR [rax]
  40923b:	48 85 ff             	test   rdi,rdi
  40923e:	74 0b                	je     0x40924b
  409240:	48 8b 70 08          	mov    rsi,QWORD PTR [rax+0x8]
  409244:	b8 0b 00 00 00       	mov    eax,0xb
  409249:	0f 05                	syscall
  40924b:	b8 0b 00 00 00       	mov    eax,0xb
  409250:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
  409255:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  40925a:	0f 05                	syscall
  40925c:	44 89 f0             	mov    eax,r14d
  40925f:	eb 1a                	jmp    0x40927b
  409261:	b8 0b 00 00 00       	mov    eax,0xb
  409266:	48 8b 7c 24 30       	mov    rdi,QWORD PTR [rsp+0x30]
  40926b:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  409270:	0f 05                	syscall
  409272:	b8 01 00 00 00       	mov    eax,0x1
  409277:	eb 02                	jmp    0x40927b
  409279:	31 c0                	xor    eax,eax
  40927b:	48 83 c4 40          	add    rsp,0x40
  40927f:	41 5f                	pop    r15
  409281:	41 5e                	pop    r14
  409283:	41 5d                	pop    r13
  409285:	41 5c                	pop    r12
  409287:	5b                   	pop    rbx
  409288:	c3                   	ret
  409289:	41 54                	push   r12
  40928b:	41 55                	push   r13
  40928d:	41 89 fc             	mov    r12d,edi
  409290:	41 89 f5             	mov    r13d,esi
  409293:	e8 1b 03 00 00       	call   0x4095b3
  409298:	42 8b 04 a0          	mov    eax,DWORD PTR [rax+r12*4]
  40929c:	83 f8 02             	cmp    eax,0x2
  40929f:	0f 84 83 00 00 00    	je     0x409328
  4092a5:	e8 15 01 00 00       	call   0x4093bf
  4092aa:	85 c0                	test   eax,eax
  4092ac:	0f 85 83 00 00 00    	jne    0x409335
  4092b2:	4c 89 e2             	mov    rdx,r12
  4092b5:	48 c1 e2 10          	shl    rdx,0x10
  4092b9:	e8 2f 03 00 00       	call   0x4095ed
  4092be:	48 8b 30             	mov    rsi,QWORD PTR [rax]
  4092c1:	48 85 f6             	test   rsi,rsi
  4092c4:	74 5b                	je     0x409321
  4092c6:	48 01 d6             	add    rsi,rdx
  4092c9:	48 81 c6 f0 ff 00 00 	add    rsi,0xfff0
  4092d0:	b8 38 00 00 00       	mov    eax,0x38
  4092d5:	44 89 ef             	mov    edi,r13d
  4092d8:	31 d2                	xor    edx,edx
  4092da:	45 31 d2             	xor    r10d,r10d
  4092dd:	45 31 c0             	xor    r8d,r8d
  4092e0:	0f 05                	syscall
  4092e2:	48 85 c0             	test   rax,rax
  4092e5:	78 3a                	js     0x409321
  4092e7:	74 04                	je     0x4092ed
  4092e9:	31 c0                	xor    eax,eax
  4092eb:	eb 4d                	jmp    0x40933a
  4092ed:	44 89 e7             	mov    edi,r12d
  4092f0:	be 11 87 00 00       	mov    esi,0x8711
  4092f5:	e8 2b 01 00 00       	call   0x409425
  4092fa:	85 c0                	test   eax,eax
  4092fc:	75 10                	jne    0x40930e
  4092fe:	e8 eb 00 00 00       	call   0x4093ee
  409303:	31 ff                	xor    edi,edi
  409305:	b8 3c 00 00 00       	mov    eax,0x3c
  40930a:	0f 05                	syscall
  40930c:	0f 0b                	ud2
  40930e:	e8 db 00 00 00       	call   0x4093ee
  409313:	bf 46 00 00 00       	mov    edi,0x46
  409318:	b8 3c 00 00 00       	mov    eax,0x3c
  40931d:	0f 05                	syscall
  40931f:	0f 0b                	ud2
  409321:	e8 c8 00 00 00       	call   0x4093ee
  409326:	eb 0d                	jmp    0x409335
  409328:	44 89 e7             	mov    edi,r12d
  40932b:	44 89 ee             	mov    esi,r13d
  40932e:	e8 0c 00 00 00       	call   0x40933f
  409333:	eb 05                	jmp    0x40933a
  409335:	b8 01 00 00 00       	mov    eax,0x1
  40933a:	41 5d                	pop    r13
  40933c:	41 5c                	pop    r12
  40933e:	c3                   	ret
  40933f:	53                   	push   rbx
  409340:	41 54                	push   r12
  409342:	89 fb                	mov    ebx,edi
  409344:	41 89 f4             	mov    r12d,esi
  409347:	83 3d be 02 00 00 01 	cmp    DWORD PTR [rip+0x2be],0x1        # 0x40960c
  40934e:	75 3b                	jne    0x40938b
  409350:	48 8b 05 c1 02 00 00 	mov    rax,QWORD PTR [rip+0x2c1]        # 0x409618
  409357:	48 85 c0             	test   rax,rax
  40935a:	74 2f                	je     0x40938b
  40935c:	89 df                	mov    edi,ebx
  40935e:	e8 70 02 00 00       	call   0x4095d3
  409363:	48 85 c0             	test   rax,rax
  409366:	74 23                	je     0x40938b
  409368:	48 89 c7             	mov    rdi,rax
  40936b:	89 de                	mov    esi,ebx
  40936d:	4c 89 fa             	mov    rdx,r15
  409370:	44 89 e1             	mov    ecx,r12d
  409373:	4c 8d 05 1a 00 00 00 	lea    r8,[rip+0x1a]        # 0x409394
  40937a:	48 8b 05 97 02 00 00 	mov    rax,QWORD PTR [rip+0x297]        # 0x409618
  409381:	ff d0                	call   rax
  409383:	85 c0                	test   eax,eax
  409385:	75 04                	jne    0x40938b
  409387:	31 c0                	xor    eax,eax
  409389:	eb 05                	jmp    0x409390
  40938b:	b8 01 00 00 00       	mov    eax,0x1
  409390:	41 5c                	pop    r12
  409392:	5b                   	pop    rbx
  409393:	c3                   	ret
  409394:	41 57                	push   r15
  409396:	49 89 d7             	mov    r15,rdx
  409399:	e8 d5 00 00 00       	call   0x409473
  40939e:	41 5f                	pop    r15
  4093a0:	c3                   	ret
  4093a1:	e8 47 02 00 00       	call   0x4095ed
  4093a6:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
  4093ad:	48 c7 40 08 00 00 00 	mov    QWORD PTR [rax+0x8],0x0
  4093b4:	00 
  4093b5:	c7 40 10 01 00 00 00 	mov    DWORD PTR [rax+0x10],0x1
  4093bc:	31 c0                	xor    eax,eax
  4093be:	c3                   	ret
  4093bf:	8b 0d 63 02 00 00    	mov    ecx,DWORD PTR [rip+0x263]        # 0x409628
  4093c5:	83 f9 01             	cmp    ecx,0x1
  4093c8:	76 1e                	jbe    0x4093e8
  4093ca:	e8 1e 02 00 00       	call   0x4095ed
  4093cf:	4c 8d 40 10          	lea    r8,[rax+0x10]
  4093d3:	41 8b 00             	mov    eax,DWORD PTR [r8]
  4093d6:	39 c8                	cmp    eax,ecx
  4093d8:	73 0e                	jae    0x4093e8
  4093da:	67 8d 50 01          	lea    edx,[eax+0x1]
  4093de:	f0 41 0f b1 10       	lock cmpxchg DWORD PTR [r8],edx
  4093e3:	75 ee                	jne    0x4093d3
  4093e5:	31 c0                	xor    eax,eax
  4093e7:	c3                   	ret
  4093e8:	b8 01 00 00 00       	mov    eax,0x1
  4093ed:	c3                   	ret
  4093ee:	e8 fa 01 00 00       	call   0x4095ed
  4093f3:	f0 83 68 10 01       	lock sub DWORD PTR [rax+0x10],0x1
  4093f8:	c3                   	ret
  4093f9:	3b 3d 01 02 00 00    	cmp    edi,DWORD PTR [rip+0x201]        # 0x409600
  4093ff:	73 1e                	jae    0x40941f
  409401:	e8 67 01 00 00       	call   0x40956d
  409406:	8b 04 b8             	mov    eax,DWORD PTR [rax+rdi*4]
  409409:	83 f8 ff             	cmp    eax,0xffffffff
  40940c:	74 11                	je     0x40941f
  40940e:	89 c2                	mov    edx,eax
  409410:	48 8b 05 09 02 00 00 	mov    rax,QWORD PTR [rip+0x209]        # 0x409620
  409417:	48 39 c2             	cmp    rdx,rax
  40941a:	77 03                	ja     0x40941f
  40941c:	31 c0                	xor    eax,eax
  40941e:	c3                   	ret
  40941f:	b8 01 00 00 00       	mov    eax,0x1
  409424:	c3                   	ret
  409425:	53                   	push   rbx
  409426:	41 54                	push   r12
  409428:	41 55                	push   r13
  40942a:	41 56                	push   r14
  40942c:	89 fb                	mov    ebx,edi
  40942e:	41 89 f5             	mov    r13d,esi
  409431:	e8 21 01 00 00       	call   0x409557
  409436:	8b 04 98             	mov    eax,DWORD PTR [rax+rbx*4]
  409439:	85 c0                	test   eax,eax
  40943b:	74 29                	je     0x409466
  40943d:	4c 8d 25 fc fb ff ff 	lea    r12,[rip+0xfffffffffffffbfc]        # 0x409040
  409444:	49 01 c4             	add    r12,rax
  409447:	41 57                	push   r15
  409449:	53                   	push   rbx
  40944a:	41 55                	push   r13
  40944c:	41 56                	push   r14
  40944e:	41 ff d4             	call   r12
  409451:	41 5e                	pop    r14
  409453:	41 5d                	pop    r13
  409455:	5b                   	pop    rbx
  409456:	41 5f                	pop    r15
  409458:	89 df                	mov    edi,ebx
  40945a:	44 89 ee             	mov    esi,r13d
  40945d:	41 5e                	pop    r14
  40945f:	41 5d                	pop    r13
  409461:	41 5c                	pop    r12
  409463:	5b                   	pop    rbx
  409464:	eb 0d                	jmp    0x409473
  409466:	b8 01 00 00 00       	mov    eax,0x1
  40946b:	41 5e                	pop    r14
  40946d:	41 5d                	pop    r13
  40946f:	41 5c                	pop    r12
  409471:	5b                   	pop    rbx
  409472:	c3                   	ret
  409473:	53                   	push   rbx
  409474:	41 54                	push   r12
  409476:	41 55                	push   r13
  409478:	41 56                	push   r14
  40947a:	89 fb                	mov    ebx,edi
  40947c:	41 89 f5             	mov    r13d,esi
  40947f:	3b 1d 7b 01 00 00    	cmp    ebx,DWORD PTR [rip+0x17b]        # 0x409600
  409485:	0f 83 a5 00 00 00    	jae    0x409530
  40948b:	48 89 d8             	mov    rax,rbx
  40948e:	48 c1 e0 06          	shl    rax,0x6
  409492:	41 c6 44 07 04 01    	mov    BYTE PTR [r15+rax*1+0x4],0x1
  409498:	e8 a8 00 00 00       	call   0x409545
  40949d:	44 8b 34 98          	mov    r14d,DWORD PTR [rax+rbx*4]
  4094a1:	41 83 fe ff          	cmp    r14d,0xffffffff
  4094a5:	0f 84 81 00 00 00    	je     0x40952c
  4094ab:	44 3b 35 52 01 00 00 	cmp    r14d,DWORD PTR [rip+0x152]        # 0x409604
  4094b2:	73 7c                	jae    0x409530
  4094b4:	e8 ca 00 00 00       	call   0x409583
  4094b9:	46 8b 24 b0          	mov    r12d,DWORD PTR [rax+r14*4]
  4094bd:	44 3b 25 3c 01 00 00 	cmp    r12d,DWORD PTR [rip+0x13c]        # 0x409600
  4094c4:	73 6a                	jae    0x409530
  4094c6:	e8 72 00 00 00       	call   0x40953d
  4094cb:	42 8b 0c a0          	mov    ecx,DWORD PTR [rax+r12*4]
  4094cf:	85 c9                	test   ecx,ecx
  4094d1:	74 5d                	je     0x409530
  4094d3:	83 f9 01             	cmp    ecx,0x1
  4094d6:	74 1c                	je     0x4094f4
  4094d8:	4c 89 e0             	mov    rax,r12
  4094db:	48 c1 e0 06          	shl    rax,0x6
  4094df:	49 8d 3c 07          	lea    rdi,[r15+rax*1]
  4094e3:	b8 01 00 00 00       	mov    eax,0x1
  4094e8:	f0 0f c1 07          	lock xadd DWORD PTR [rdi],eax
  4094ec:	ff c0                	inc    eax
  4094ee:	39 c8                	cmp    eax,ecx
  4094f0:	77 3e                	ja     0x409530
  4094f2:	75 2a                	jne    0x40951e
  4094f4:	44 89 e7             	mov    edi,r12d
  4094f7:	e8 fd fe ff ff       	call   0x4093f9
  4094fc:	85 c0                	test   eax,eax
  4094fe:	74 0f                	je     0x40950f
  409500:	44 89 e7             	mov    edi,r12d
  409503:	44 89 ee             	mov    esi,r13d
  409506:	e8 7e fd ff ff       	call   0x409289
  40950b:	85 c0                	test   eax,eax
  40950d:	74 0f                	je     0x40951e
  40950f:	44 89 e7             	mov    edi,r12d
  409512:	44 89 ee             	mov    esi,r13d
  409515:	e8 0b ff ff ff       	call   0x409425
  40951a:	85 c0                	test   eax,eax
  40951c:	75 12                	jne    0x409530
  40951e:	e8 70 00 00 00       	call   0x409593
  409523:	46 8b 34 b0          	mov    r14d,DWORD PTR [rax+r14*4]
  409527:	e9 75 ff ff ff       	jmp    0x4094a1
  40952c:	31 c0                	xor    eax,eax
  40952e:	eb 05                	jmp    0x409535
  409530:	b8 01 00 00 00       	mov    eax,0x1
  409535:	41 5e                	pop    r14
  409537:	41 5d                	pop    r13
  409539:	41 5c                	pop    r12
  40953b:	5b                   	pop    rbx
  40953c:	c3                   	ret
  40953d:	48 8d 05 7c 01 00 00 	lea    rax,[rip+0x17c]        # 0x4096c0
  409544:	c3                   	ret
  409545:	48 8d 05 74 01 00 00 	lea    rax,[rip+0x174]        # 0x4096c0
  40954c:	8b 0d ae 00 00 00    	mov    ecx,DWORD PTR [rip+0xae]        # 0x409600
  409552:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  409556:	c3                   	ret
  409557:	48 8d 05 62 01 00 00 	lea    rax,[rip+0x162]        # 0x4096c0
  40955e:	8b 0d 9c 00 00 00    	mov    ecx,DWORD PTR [rip+0x9c]        # 0x409600
  409564:	48 8d 0c 09          	lea    rcx,[rcx+rcx*1]
  409568:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  40956c:	c3                   	ret
  40956d:	48 8d 05 4c 01 00 00 	lea    rax,[rip+0x14c]        # 0x4096c0
  409574:	8b 0d 86 00 00 00    	mov    ecx,DWORD PTR [rip+0x86]        # 0x409600
  40957a:	48 8d 0c 49          	lea    rcx,[rcx+rcx*2]
  40957e:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  409582:	c3                   	ret
  409583:	e8 e5 ff ff ff       	call   0x40956d
  409588:	8b 0d 72 00 00 00    	mov    ecx,DWORD PTR [rip+0x72]        # 0x409600
  40958e:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  409592:	c3                   	ret
  409593:	e8 eb ff ff ff       	call   0x409583
  409598:	8b 0d 66 00 00 00    	mov    ecx,DWORD PTR [rip+0x66]        # 0x409604
  40959e:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  4095a2:	c3                   	ret
  4095a3:	e8 eb ff ff ff       	call   0x409593
  4095a8:	8b 0d 56 00 00 00    	mov    ecx,DWORD PTR [rip+0x56]        # 0x409604
  4095ae:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  4095b2:	c3                   	ret
  4095b3:	e8 eb ff ff ff       	call   0x4095a3
  4095b8:	8b 0d 46 00 00 00    	mov    ecx,DWORD PTR [rip+0x46]        # 0x409604
  4095be:	48 8d 04 c8          	lea    rax,[rax+rcx*8]
  4095c2:	c3                   	ret
  4095c3:	e8 eb ff ff ff       	call   0x4095b3
  4095c8:	8b 0d 32 00 00 00    	mov    ecx,DWORD PTR [rip+0x32]        # 0x409600
  4095ce:	48 8d 04 88          	lea    rax,[rax+rcx*4]
  4095d2:	c3                   	ret
  4095d3:	3b 3d 27 00 00 00    	cmp    edi,DWORD PTR [rip+0x27]        # 0x409600
  4095d9:	73 0f                	jae    0x4095ea
  4095db:	89 fa                	mov    edx,edi
  4095dd:	e8 e1 ff ff ff       	call   0x4095c3
  4095e2:	48 6b d2 30          	imul   rdx,rdx,0x30
  4095e6:	48 01 d0             	add    rax,rdx
  4095e9:	c3                   	ret
  4095ea:	31 c0                	xor    eax,eax
  4095ec:	c3                   	ret
  4095ed:	8b 05 0d 00 00 00    	mov    eax,DWORD PTR [rip+0xd]        # 0x409600
  4095f3:	48 c1 e0 06          	shl    rax,0x6
  4095f7:	49 8d 04 07          	lea    rax,[r15+rax*1]
  4095fb:	c3                   	ret
  4095fc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  409600:	05 00 00 00 04       	add    eax,0x4000000
	...
  40960d:	00 00                	add    BYTE PTR [rax],al
  40960f:	00 02                	add    BYTE PTR [rdx],al
  409611:	00 00                	add    BYTE PTR [rax],al
  409613:	00 30                	add    BYTE PTR [rax],dh
	...
  40961d:	00 00                	add    BYTE PTR [rax],al
  40961f:	00 b0 71 0b 00 00    	add    BYTE PTR [rax+0xb71],dh
  409625:	00 00                	add    BYTE PTR [rax],al
  409627:	00 04 00             	add    BYTE PTR [rax+rax*1],al
  40962a:	00 00                	add    BYTE PTR [rax],al
  40962c:	00 00                	add    BYTE PTR [rax],al
  40962e:	00 00                	add    BYTE PTR [rax],al
  409630:	20 00                	and    BYTE PTR [rax],al
  409632:	00 00                	add    BYTE PTR [rax],al
  409634:	90                   	nop
  409635:	66 66 2e 0f 1f 84 00 	data16 cs nop WORD PTR [rax+rax*1+0x0]
  40963c:	00 00 00 00 
	...
  4096d0:	04 00                	add    al,0x0
  4096d2:	00 00                	add    BYTE PTR [rax],al
  4096d4:	00 00                	add    BYTE PTR [rax],al
  4096d6:	00 00                	add    BYTE PTR [rax],al
  4096d8:	01 00                	add    DWORD PTR [rax],eax
  4096da:	00 00                	add    BYTE PTR [rax],al
  4096dc:	02 00                	add    al,BYTE PTR [rax]
  4096de:	00 00                	add    BYTE PTR [rax],al
  4096e0:	03 00                	add    eax,DWORD PTR [rax]
  4096e2:	00 00                	add    BYTE PTR [rax],al
  4096e4:	ff                   	(bad)
  4096e5:	ff                   	(bad)
  4096e6:	ff                   	(bad)
  4096e7:	ff 20                	jmp    QWORD PTR [rax]
  4096e9:	08 00                	or     BYTE PTR [rax],al
  4096eb:	00 a0 0d 00 00 20    	add    BYTE PTR [rax+0x2000000d],ah
  4096f1:	13 00                	adc    eax,DWORD PTR [rax]
  4096f3:	00 a0 18 00 00 20    	add    BYTE PTR [rax+0x20000018],ah
  4096f9:	1e                   	(bad)
  4096fa:	00 00                	add    BYTE PTR [rax],al
  4096fc:	ff                   	(bad)
  4096fd:	ff                   	(bad)
  4096fe:	ff                   	(bad)
  4096ff:	ff                   	(bad)
  409700:	ff                   	(bad)
  409701:	ff                   	(bad)
  409702:	ff                   	(bad)
  409703:	ff                   	(bad)
  409704:	ff                   	(bad)
  409705:	ff                   	(bad)
  409706:	ff                   	(bad)
  409707:	ff                   	(bad)
  409708:	ff                   	(bad)
  409709:	ff                   	(bad)
  40970a:	ff                   	(bad)
  40970b:	ff 1d 01 00 00 04    	call   FWORD PTR [rip+0x4000001]        # 0x4409712
  409711:	00 00                	add    BYTE PTR [rax],al
  409713:	00 04 00             	add    BYTE PTR [rax+rax*1],al
  409716:	00 00                	add    BYTE PTR [rax],al
  409718:	04 00                	add    al,0x0
  40971a:	00 00                	add    BYTE PTR [rax],al
  40971c:	04 00                	add    al,0x0
  40971e:	00 00                	add    BYTE PTR [rax],al
  409720:	ff                   	(bad)
  409721:	ff                   	(bad)
  409722:	ff                   	(bad)
  409723:	ff                   	(bad)
  409724:	ff                   	(bad)
  409725:	ff                   	(bad)
  409726:	ff                   	(bad)
  409727:	ff                   	(bad)
  409728:	ff                   	(bad)
  409729:	ff                   	(bad)
  40972a:	ff                   	(bad)
  40972b:	ff                   	(bad)
  40972c:	ff                   	(bad)
  40972d:	ff                   	(bad)
  40972e:	ff                   	(bad)
  40972f:	ff 08                	dec    DWORD PTR [rax]
  409731:	00 00                	add    BYTE PTR [rax],al
  409733:	00 00                	add    BYTE PTR [rax],al
  409735:	00 00                	add    BYTE PTR [rax],al
  409737:	00 08                	add    BYTE PTR [rax],cl
  409739:	00 00                	add    BYTE PTR [rax],al
  40973b:	00 00                	add    BYTE PTR [rax],al
  40973d:	00 00                	add    BYTE PTR [rax],al
  40973f:	00 08                	add    BYTE PTR [rax],cl
  409741:	00 00                	add    BYTE PTR [rax],al
  409743:	00 00                	add    BYTE PTR [rax],al
  409745:	00 00                	add    BYTE PTR [rax],al
  409747:	00 08                	add    BYTE PTR [rax],cl
  409749:	00 00                	add    BYTE PTR [rax],al
  40974b:	00 00                	add    BYTE PTR [rax],al
  40974d:	00 00                	add    BYTE PTR [rax],al
  40974f:	00 01                	add    BYTE PTR [rcx],al
  409751:	00 00                	add    BYTE PTR [rax],al
  409753:	00 01                	add    BYTE PTR [rcx],al
  409755:	00 00                	add    BYTE PTR [rax],al
  409757:	00 01                	add    BYTE PTR [rcx],al
  409759:	00 00                	add    BYTE PTR [rax],al
  40975b:	00 01                	add    BYTE PTR [rcx],al
  40975d:	00 00                	add    BYTE PTR [rax],al
  40975f:	00 01                	add    BYTE PTR [rcx],al
  409761:	00 00                	add    BYTE PTR [rax],al
  409763:	00 00                	add    BYTE PTR [rax],al
  409765:	00 00                	add    BYTE PTR [rax],al
  409767:	00 01                	add    BYTE PTR [rcx],al
  409769:	00 00                	add    BYTE PTR [rax],al
  40976b:	00 ff                	add    bh,bh
  40976d:	ff                   	(bad)
  40976e:	ff                   	(bad)
  40976f:	ff                   	(bad)
  409770:	ff                   	(bad)
  409771:	ff                   	(bad)
  409772:	ff                   	(bad)
  409773:	ff 08                	dec    DWORD PTR [rax]
  409775:	00 00                	add    BYTE PTR [rax],al
  409777:	00 00                	add    BYTE PTR [rax],al
  409779:	00 00                	add    BYTE PTR [rax],al
  40977b:	00 54 03 00          	add    BYTE PTR [rbx+rax*1+0x0],dl
  40977f:	00 00                	add    BYTE PTR [rax],al
  409781:	00 00                	add    BYTE PTR [rax],al
  409783:	00 01                	add    BYTE PTR [rcx],al
  409785:	00 00                	add    BYTE PTR [rax],al
  409787:	00 00                	add    BYTE PTR [rax],al
  409789:	00 00                	add    BYTE PTR [rax],al
  40978b:	00 02                	add    BYTE PTR [rdx],al
  40978d:	00 00                	add    BYTE PTR [rax],al
  40978f:	00 00                	add    BYTE PTR [rax],al
  409791:	00 00                	add    BYTE PTR [rax],al
  409793:	00 01                	add    BYTE PTR [rcx],al
  409795:	00 00                	add    BYTE PTR [rax],al
  409797:	00 01                	add    BYTE PTR [rcx],al
  409799:	00 00                	add    BYTE PTR [rax],al
  40979b:	00 ff                	add    bh,bh
  40979d:	ff                   	(bad)
  40979e:	ff                   	(bad)
  40979f:	ff                   	(bad)
  4097a0:	ff                   	(bad)
  4097a1:	ff                   	(bad)
  4097a2:	ff                   	(bad)
  4097a3:	ff 08                	dec    DWORD PTR [rax]
  4097a5:	00 00                	add    BYTE PTR [rax],al
  4097a7:	00 00                	add    BYTE PTR [rax],al
  4097a9:	00 00                	add    BYTE PTR [rax],al
  4097ab:	00 54 03 00          	add    BYTE PTR [rbx+rax*1+0x0],dl
  4097af:	00 00                	add    BYTE PTR [rax],al
  4097b1:	00 00                	add    BYTE PTR [rax],al
  4097b3:	00 01                	add    BYTE PTR [rcx],al
  4097b5:	00 00                	add    BYTE PTR [rax],al
  4097b7:	00 00                	add    BYTE PTR [rax],al
  4097b9:	00 00                	add    BYTE PTR [rax],al
  4097bb:	00 02                	add    BYTE PTR [rdx],al
  4097bd:	00 00                	add    BYTE PTR [rax],al
  4097bf:	00 00                	add    BYTE PTR [rax],al
  4097c1:	00 00                	add    BYTE PTR [rax],al
  4097c3:	00 02                	add    BYTE PTR [rdx],al
  4097c5:	00 00                	add    BYTE PTR [rax],al
  4097c7:	00 01                	add    BYTE PTR [rcx],al
  4097c9:	00 00                	add    BYTE PTR [rax],al
  4097cb:	00 ff                	add    bh,bh
  4097cd:	ff                   	(bad)
  4097ce:	ff                   	(bad)
  4097cf:	ff                   	(bad)
  4097d0:	ff                   	(bad)
  4097d1:	ff                   	(bad)
  4097d2:	ff                   	(bad)
  4097d3:	ff 08                	dec    DWORD PTR [rax]
  4097d5:	00 00                	add    BYTE PTR [rax],al
  4097d7:	00 00                	add    BYTE PTR [rax],al
  4097d9:	00 00                	add    BYTE PTR [rax],al
  4097db:	00 54 03 00          	add    BYTE PTR [rbx+rax*1+0x0],dl
  4097df:	00 00                	add    BYTE PTR [rax],al
  4097e1:	00 00                	add    BYTE PTR [rax],al
  4097e3:	00 01                	add    BYTE PTR [rcx],al
  4097e5:	00 00                	add    BYTE PTR [rax],al
  4097e7:	00 00                	add    BYTE PTR [rax],al
  4097e9:	00 00                	add    BYTE PTR [rax],al
  4097eb:	00 02                	add    BYTE PTR [rdx],al
  4097ed:	00 00                	add    BYTE PTR [rax],al
  4097ef:	00 00                	add    BYTE PTR [rax],al
  4097f1:	00 00                	add    BYTE PTR [rax],al
  4097f3:	00 03                	add    BYTE PTR [rbx],al
  4097f5:	00 00                	add    BYTE PTR [rax],al
  4097f7:	00 01                	add    BYTE PTR [rcx],al
  4097f9:	00 00                	add    BYTE PTR [rax],al
  4097fb:	00 ff                	add    bh,bh
  4097fd:	ff                   	(bad)
  4097fe:	ff                   	(bad)
  4097ff:	ff                   	(bad)
  409800:	ff                   	(bad)
  409801:	ff                   	(bad)
  409802:	ff                   	(bad)
  409803:	ff 08                	dec    DWORD PTR [rax]
  409805:	00 00                	add    BYTE PTR [rax],al
  409807:	00 00                	add    BYTE PTR [rax],al
  409809:	00 00                	add    BYTE PTR [rax],al
  40980b:	00 54 03 00          	add    BYTE PTR [rbx+rax*1+0x0],dl
  40980f:	00 00                	add    BYTE PTR [rax],al
  409811:	00 00                	add    BYTE PTR [rax],al
  409813:	00 01                	add    BYTE PTR [rcx],al
  409815:	00 00                	add    BYTE PTR [rax],al
  409817:	00 00                	add    BYTE PTR [rax],al
  409819:	00 00                	add    BYTE PTR [rax],al
  40981b:	00 02                	add    BYTE PTR [rdx],al
  40981d:	00 00                	add    BYTE PTR [rax],al
  40981f:	00 00                	add    BYTE PTR [rax],al
  409821:	00 00                	add    BYTE PTR [rax],al
  409823:	00 04 00             	add    BYTE PTR [rax+rax*1],al
  409826:	00 00                	add    BYTE PTR [rax],al
  409828:	01 00                	add    DWORD PTR [rax],eax
  40982a:	00 00                	add    BYTE PTR [rax],al
  40982c:	1d 01 00 00 00       	sbb    eax,0x1
  409831:	00 00                	add    BYTE PTR [rax],al
  409833:	00 20                	add    BYTE PTR [rax],ah
  409835:	00 00                	add    BYTE PTR [rax],al
  409837:	00 00                	add    BYTE PTR [rax],al
  409839:	00 00                	add    BYTE PTR [rax],al
  40983b:	00 54 03 00          	add    BYTE PTR [rbx+rax*1+0x0],dl
  40983f:	00 00                	add    BYTE PTR [rax],al
  409841:	00 00                	add    BYTE PTR [rax],al
  409843:	00 04 00             	add    BYTE PTR [rax+rax*1],al
  409846:	00 00                	add    BYTE PTR [rax],al
  409848:	00 00                	add    BYTE PTR [rax],al
  40984a:	00 00                	add    BYTE PTR [rax],al
  40984c:	02 00                	add    al,BYTE PTR [rax]
	...
  40985e:	00 00                	add    BYTE PTR [rax],al
  409860:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409867:	49 89 e7             	mov    r15,rsp
  40986a:	48 a1 00 00 00 00 00 	movabs rax,ds:0x10000000000
  409871:	01 00 00 
  409874:	50                   	push   rax
  409875:	58                   	pop    rax
  409876:	49 89 c0             	mov    r8,rax
  409879:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409880:	00 00 00 
  409883:	50                   	push   rax
  409884:	58                   	pop    rax
  409885:	48 89 c3             	mov    rbx,rax
  409888:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  40988f:	01 00 00 
  409892:	50                   	push   rax
  409893:	58                   	pop    rax
  409894:	48 89 c5             	mov    rbp,rax
  409897:	48 39 eb             	cmp    rbx,rbp
  40989a:	0f 83 5a 00 00 00    	jae    0x4098fa
  4098a0:	4c 89 c6             	mov    rsi,r8
  4098a3:	49 0f af f0          	imul   rsi,r8
  4098a7:	48 b8 03 00 00 00 00 	movabs rax,0x3
  4098ae:	00 00 00 
  4098b1:	49 89 c3             	mov    r11,rax
  4098b4:	4c 01 de             	add    rsi,r11
  4098b7:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  4098be:	10 00 00 
  4098c1:	49 89 c3             	mov    r11,rax
  4098c4:	48 89 f0             	mov    rax,rsi
  4098c7:	49 f7 e3             	mul    r11
  4098ca:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  4098d1:	00 00 00 
  4098d4:	49 89 c3             	mov    r11,rax
  4098d7:	49 0f af d3          	imul   rdx,r11
  4098db:	48 29 d6             	sub    rsi,rdx
  4098de:	48 89 f0             	mov    rax,rsi
  4098e1:	4c 29 d8             	sub    rax,r11
  4098e4:	4c 39 de             	cmp    rsi,r11
  4098e7:	48 0f 43 f0          	cmovae rsi,rax
  4098eb:	49 89 f0             	mov    r8,rsi
  4098ee:	48 ff c3             	inc    rbx
  4098f1:	48 39 eb             	cmp    rbx,rbp
  4098f4:	0f 82 a6 ff ff ff    	jb     0x4098a0
  4098fa:	4c 89 c0             	mov    rax,r8
  4098fd:	48 a3 80 00 00 00 00 	movabs ds:0x10000000080,rax
  409904:	01 00 00 
  409907:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40990e:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409915:	49 89 e7             	mov    r15,rsp
  409918:	48 a1 80 00 00 00 00 	movabs rax,ds:0x10000000080
  40991f:	01 00 00 
  409922:	50                   	push   rax
  409923:	58                   	pop    rax
  409924:	49 89 c0             	mov    r8,rax
  409927:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40992e:	00 00 00 
  409931:	50                   	push   rax
  409932:	58                   	pop    rax
  409933:	48 89 c3             	mov    rbx,rax
  409936:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40993d:	01 00 00 
  409940:	50                   	push   rax
  409941:	58                   	pop    rax
  409942:	48 89 c5             	mov    rbp,rax
  409945:	48 39 eb             	cmp    rbx,rbp
  409948:	0f 83 5a 00 00 00    	jae    0x4099a8
  40994e:	4c 89 c6             	mov    rsi,r8
  409951:	49 0f af f0          	imul   rsi,r8
  409955:	48 b8 0d 00 00 00 00 	movabs rax,0xd
  40995c:	00 00 00 
  40995f:	49 89 c3             	mov    r11,rax
  409962:	4c 01 de             	add    rsi,r11
  409965:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40996c:	10 00 00 
  40996f:	49 89 c3             	mov    r11,rax
  409972:	48 89 f0             	mov    rax,rsi
  409975:	49 f7 e3             	mul    r11
  409978:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40997f:	00 00 00 
  409982:	49 89 c3             	mov    r11,rax
  409985:	49 0f af d3          	imul   rdx,r11
  409989:	48 29 d6             	sub    rsi,rdx
  40998c:	48 89 f0             	mov    rax,rsi
  40998f:	4c 29 d8             	sub    rax,r11
  409992:	4c 39 de             	cmp    rsi,r11
  409995:	48 0f 43 f0          	cmovae rsi,rax
  409999:	49 89 f0             	mov    r8,rsi
  40999c:	48 ff c3             	inc    rbx
  40999f:	48 39 eb             	cmp    rbx,rbp
  4099a2:	0f 82 a6 ff ff ff    	jb     0x40994e
  4099a8:	4c 89 c0             	mov    rax,r8
  4099ab:	48 a3 80 40 00 00 00 	movabs ds:0x10000004080,rax
  4099b2:	01 00 00 
  4099b5:	48 81 c4 20 00 00 00 	add    rsp,0x20
  4099bc:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  4099c3:	49 89 e7             	mov    r15,rsp
  4099c6:	48 a1 80 40 00 00 00 	movabs rax,ds:0x10000004080
  4099cd:	01 00 00 
  4099d0:	50                   	push   rax
  4099d1:	58                   	pop    rax
  4099d2:	49 89 c0             	mov    r8,rax
  4099d5:	48 b8 00 00 00 00 00 	movabs rax,0x0
  4099dc:	00 00 00 
  4099df:	50                   	push   rax
  4099e0:	58                   	pop    rax
  4099e1:	48 89 c3             	mov    rbx,rax
  4099e4:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  4099eb:	01 00 00 
  4099ee:	50                   	push   rax
  4099ef:	58                   	pop    rax
  4099f0:	48 89 c5             	mov    rbp,rax
  4099f3:	48 39 eb             	cmp    rbx,rbp
  4099f6:	0f 83 5a 00 00 00    	jae    0x409a56
  4099fc:	4c 89 c6             	mov    rsi,r8
  4099ff:	49 0f af f0          	imul   rsi,r8
  409a03:	48 b8 1d 00 00 00 00 	movabs rax,0x1d
  409a0a:	00 00 00 
  409a0d:	49 89 c3             	mov    r11,rax
  409a10:	4c 01 de             	add    rsi,r11
  409a13:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409a1a:	10 00 00 
  409a1d:	49 89 c3             	mov    r11,rax
  409a20:	48 89 f0             	mov    rax,rsi
  409a23:	49 f7 e3             	mul    r11
  409a26:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409a2d:	00 00 00 
  409a30:	49 89 c3             	mov    r11,rax
  409a33:	49 0f af d3          	imul   rdx,r11
  409a37:	48 29 d6             	sub    rsi,rdx
  409a3a:	48 89 f0             	mov    rax,rsi
  409a3d:	4c 29 d8             	sub    rax,r11
  409a40:	4c 39 de             	cmp    rsi,r11
  409a43:	48 0f 43 f0          	cmovae rsi,rax
  409a47:	49 89 f0             	mov    r8,rsi
  409a4a:	48 ff c3             	inc    rbx
  409a4d:	48 39 eb             	cmp    rbx,rbp
  409a50:	0f 82 a6 ff ff ff    	jb     0x4099fc
  409a56:	4c 89 c0             	mov    rax,r8
  409a59:	48 a3 80 80 00 00 00 	movabs ds:0x10000008080,rax
  409a60:	01 00 00 
  409a63:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409a6a:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409a71:	49 89 e7             	mov    r15,rsp
  409a74:	48 a1 80 80 00 00 00 	movabs rax,ds:0x10000008080
  409a7b:	01 00 00 
  409a7e:	50                   	push   rax
  409a7f:	58                   	pop    rax
  409a80:	49 89 c0             	mov    r8,rax
  409a83:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409a8a:	00 00 00 
  409a8d:	50                   	push   rax
  409a8e:	58                   	pop    rax
  409a8f:	48 89 c3             	mov    rbx,rax
  409a92:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  409a99:	01 00 00 
  409a9c:	50                   	push   rax
  409a9d:	58                   	pop    rax
  409a9e:	48 89 c5             	mov    rbp,rax
  409aa1:	48 39 eb             	cmp    rbx,rbp
  409aa4:	0f 83 5a 00 00 00    	jae    0x409b04
  409aaa:	4c 89 c6             	mov    rsi,r8
  409aad:	49 0f af f0          	imul   rsi,r8
  409ab1:	48 b8 2b 00 00 00 00 	movabs rax,0x2b
  409ab8:	00 00 00 
  409abb:	49 89 c3             	mov    r11,rax
  409abe:	4c 01 de             	add    rsi,r11
  409ac1:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409ac8:	10 00 00 
  409acb:	49 89 c3             	mov    r11,rax
  409ace:	48 89 f0             	mov    rax,rsi
  409ad1:	49 f7 e3             	mul    r11
  409ad4:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409adb:	00 00 00 
  409ade:	49 89 c3             	mov    r11,rax
  409ae1:	49 0f af d3          	imul   rdx,r11
  409ae5:	48 29 d6             	sub    rsi,rdx
  409ae8:	48 89 f0             	mov    rax,rsi
  409aeb:	4c 29 d8             	sub    rax,r11
  409aee:	4c 39 de             	cmp    rsi,r11
  409af1:	48 0f 43 f0          	cmovae rsi,rax
  409af5:	49 89 f0             	mov    r8,rsi
  409af8:	48 ff c3             	inc    rbx
  409afb:	48 39 eb             	cmp    rbx,rbp
  409afe:	0f 82 a6 ff ff ff    	jb     0x409aaa
  409b04:	4c 89 c0             	mov    rax,r8
  409b07:	48 a3 80 c0 00 00 00 	movabs ds:0x1000000c080,rax
  409b0e:	01 00 00 
  409b11:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409b18:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409b1f:	49 89 e7             	mov    r15,rsp
  409b22:	48 a1 80 c0 00 00 00 	movabs rax,ds:0x1000000c080
  409b29:	01 00 00 
  409b2c:	50                   	push   rax
  409b2d:	58                   	pop    rax
  409b2e:	49 89 c0             	mov    r8,rax
  409b31:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409b38:	00 00 00 
  409b3b:	50                   	push   rax
  409b3c:	58                   	pop    rax
  409b3d:	48 89 c3             	mov    rbx,rax
  409b40:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  409b47:	01 00 00 
  409b4a:	50                   	push   rax
  409b4b:	58                   	pop    rax
  409b4c:	48 89 c5             	mov    rbp,rax
  409b4f:	48 39 eb             	cmp    rbx,rbp
  409b52:	0f 83 5a 00 00 00    	jae    0x409bb2
  409b58:	4c 89 c6             	mov    rsi,r8
  409b5b:	49 0f af f0          	imul   rsi,r8
  409b5f:	48 b8 3d 00 00 00 00 	movabs rax,0x3d
  409b66:	00 00 00 
  409b69:	49 89 c3             	mov    r11,rax
  409b6c:	4c 01 de             	add    rsi,r11
  409b6f:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409b76:	10 00 00 
  409b79:	49 89 c3             	mov    r11,rax
  409b7c:	48 89 f0             	mov    rax,rsi
  409b7f:	49 f7 e3             	mul    r11
  409b82:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409b89:	00 00 00 
  409b8c:	49 89 c3             	mov    r11,rax
  409b8f:	49 0f af d3          	imul   rdx,r11
  409b93:	48 29 d6             	sub    rsi,rdx
  409b96:	48 89 f0             	mov    rax,rsi
  409b99:	4c 29 d8             	sub    rax,r11
  409b9c:	4c 39 de             	cmp    rsi,r11
  409b9f:	48 0f 43 f0          	cmovae rsi,rax
  409ba3:	49 89 f0             	mov    r8,rsi
  409ba6:	48 ff c3             	inc    rbx
  409ba9:	48 39 eb             	cmp    rbx,rbp
  409bac:	0f 82 a6 ff ff ff    	jb     0x409b58
  409bb2:	4c 89 c0             	mov    rax,r8
  409bb5:	48 a3 80 00 01 00 00 	movabs ds:0x10000010080,rax
  409bbc:	01 00 00 
  409bbf:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409bc6:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409bcd:	49 89 e7             	mov    r15,rsp
  409bd0:	48 a1 80 00 01 00 00 	movabs rax,ds:0x10000010080
  409bd7:	01 00 00 
  409bda:	50                   	push   rax
  409bdb:	58                   	pop    rax
  409bdc:	49 89 c0             	mov    r8,rax
  409bdf:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409be6:	00 00 00 
  409be9:	50                   	push   rax
  409bea:	58                   	pop    rax
  409beb:	48 89 c3             	mov    rbx,rax
  409bee:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  409bf5:	01 00 00 
  409bf8:	50                   	push   rax
  409bf9:	58                   	pop    rax
  409bfa:	48 89 c5             	mov    rbp,rax
  409bfd:	48 39 eb             	cmp    rbx,rbp
  409c00:	0f 83 5a 00 00 00    	jae    0x409c60
  409c06:	4c 89 c6             	mov    rsi,r8
  409c09:	49 0f af f0          	imul   rsi,r8
  409c0d:	48 b8 4f 00 00 00 00 	movabs rax,0x4f
  409c14:	00 00 00 
  409c17:	49 89 c3             	mov    r11,rax
  409c1a:	4c 01 de             	add    rsi,r11
  409c1d:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409c24:	10 00 00 
  409c27:	49 89 c3             	mov    r11,rax
  409c2a:	48 89 f0             	mov    rax,rsi
  409c2d:	49 f7 e3             	mul    r11
  409c30:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409c37:	00 00 00 
  409c3a:	49 89 c3             	mov    r11,rax
  409c3d:	49 0f af d3          	imul   rdx,r11
  409c41:	48 29 d6             	sub    rsi,rdx
  409c44:	48 89 f0             	mov    rax,rsi
  409c47:	4c 29 d8             	sub    rax,r11
  409c4a:	4c 39 de             	cmp    rsi,r11
  409c4d:	48 0f 43 f0          	cmovae rsi,rax
  409c51:	49 89 f0             	mov    r8,rsi
  409c54:	48 ff c3             	inc    rbx
  409c57:	48 39 eb             	cmp    rbx,rbp
  409c5a:	0f 82 a6 ff ff ff    	jb     0x409c06
  409c60:	4c 89 c0             	mov    rax,r8
  409c63:	48 a3 80 40 01 00 00 	movabs ds:0x10000014080,rax
  409c6a:	01 00 00 
  409c6d:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409c74:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409c7b:	49 89 e7             	mov    r15,rsp
  409c7e:	48 a1 80 40 01 00 00 	movabs rax,ds:0x10000014080
  409c85:	01 00 00 
  409c88:	50                   	push   rax
  409c89:	58                   	pop    rax
  409c8a:	49 89 c0             	mov    r8,rax
  409c8d:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409c94:	00 00 00 
  409c97:	50                   	push   rax
  409c98:	58                   	pop    rax
  409c99:	48 89 c3             	mov    rbx,rax
  409c9c:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  409ca3:	01 00 00 
  409ca6:	50                   	push   rax
  409ca7:	58                   	pop    rax
  409ca8:	48 89 c5             	mov    rbp,rax
  409cab:	48 39 eb             	cmp    rbx,rbp
  409cae:	0f 83 5a 00 00 00    	jae    0x409d0e
  409cb4:	4c 89 c6             	mov    rsi,r8
  409cb7:	49 0f af f0          	imul   rsi,r8
  409cbb:	48 b8 65 00 00 00 00 	movabs rax,0x65
  409cc2:	00 00 00 
  409cc5:	49 89 c3             	mov    r11,rax
  409cc8:	4c 01 de             	add    rsi,r11
  409ccb:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409cd2:	10 00 00 
  409cd5:	49 89 c3             	mov    r11,rax
  409cd8:	48 89 f0             	mov    rax,rsi
  409cdb:	49 f7 e3             	mul    r11
  409cde:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409ce5:	00 00 00 
  409ce8:	49 89 c3             	mov    r11,rax
  409ceb:	49 0f af d3          	imul   rdx,r11
  409cef:	48 29 d6             	sub    rsi,rdx
  409cf2:	48 89 f0             	mov    rax,rsi
  409cf5:	4c 29 d8             	sub    rax,r11
  409cf8:	4c 39 de             	cmp    rsi,r11
  409cfb:	48 0f 43 f0          	cmovae rsi,rax
  409cff:	49 89 f0             	mov    r8,rsi
  409d02:	48 ff c3             	inc    rbx
  409d05:	48 39 eb             	cmp    rbx,rbp
  409d08:	0f 82 a6 ff ff ff    	jb     0x409cb4
  409d0e:	4c 89 c0             	mov    rax,r8
  409d11:	48 a3 80 80 01 00 00 	movabs ds:0x10000018080,rax
  409d18:	01 00 00 
  409d1b:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409d22:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409d29:	49 89 e7             	mov    r15,rsp
  409d2c:	48 a1 80 80 01 00 00 	movabs rax,ds:0x10000018080
  409d33:	01 00 00 
  409d36:	50                   	push   rax
  409d37:	58                   	pop    rax
  409d38:	49 89 c0             	mov    r8,rax
  409d3b:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409d42:	00 00 00 
  409d45:	50                   	push   rax
  409d46:	58                   	pop    rax
  409d47:	48 89 c3             	mov    rbx,rax
  409d4a:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  409d51:	01 00 00 
  409d54:	50                   	push   rax
  409d55:	58                   	pop    rax
  409d56:	48 89 c5             	mov    rbp,rax
  409d59:	48 39 eb             	cmp    rbx,rbp
  409d5c:	0f 83 5a 00 00 00    	jae    0x409dbc
  409d62:	4c 89 c6             	mov    rsi,r8
  409d65:	49 0f af f0          	imul   rsi,r8
  409d69:	48 b8 71 00 00 00 00 	movabs rax,0x71
  409d70:	00 00 00 
  409d73:	49 89 c3             	mov    r11,rax
  409d76:	4c 01 de             	add    rsi,r11
  409d79:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409d80:	10 00 00 
  409d83:	49 89 c3             	mov    r11,rax
  409d86:	48 89 f0             	mov    rax,rsi
  409d89:	49 f7 e3             	mul    r11
  409d8c:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409d93:	00 00 00 
  409d96:	49 89 c3             	mov    r11,rax
  409d99:	49 0f af d3          	imul   rdx,r11
  409d9d:	48 29 d6             	sub    rsi,rdx
  409da0:	48 89 f0             	mov    rax,rsi
  409da3:	4c 29 d8             	sub    rax,r11
  409da6:	4c 39 de             	cmp    rsi,r11
  409da9:	48 0f 43 f0          	cmovae rsi,rax
  409dad:	49 89 f0             	mov    r8,rsi
  409db0:	48 ff c3             	inc    rbx
  409db3:	48 39 eb             	cmp    rbx,rbp
  409db6:	0f 82 a6 ff ff ff    	jb     0x409d62
  409dbc:	4c 89 c0             	mov    rax,r8
  409dbf:	48 a3 80 c0 01 00 00 	movabs ds:0x1000001c080,rax
  409dc6:	01 00 00 
  409dc9:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409dd0:	c3                   	ret
	...
  409ddd:	00 00                	add    BYTE PTR [rax],al
  409ddf:	00 48 81             	add    BYTE PTR [rax-0x7f],cl
  409de2:	ec                   	in     al,dx
  409de3:	20 00                	and    BYTE PTR [rax],al
  409de5:	00 00                	add    BYTE PTR [rax],al
  409de7:	49 89 e7             	mov    r15,rsp
  409dea:	48 a1 08 00 00 00 00 	movabs rax,ds:0x10000000008
  409df1:	01 00 00 
  409df4:	50                   	push   rax
  409df5:	58                   	pop    rax
  409df6:	49 89 c0             	mov    r8,rax
  409df9:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409e00:	00 00 00 
  409e03:	50                   	push   rax
  409e04:	58                   	pop    rax
  409e05:	48 89 c3             	mov    rbx,rax
  409e08:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  409e0f:	01 00 00 
  409e12:	50                   	push   rax
  409e13:	58                   	pop    rax
  409e14:	48 89 c5             	mov    rbp,rax
  409e17:	48 39 eb             	cmp    rbx,rbp
  409e1a:	0f 83 5a 00 00 00    	jae    0x409e7a
  409e20:	4c 89 c6             	mov    rsi,r8
  409e23:	49 0f af f0          	imul   rsi,r8
  409e27:	48 b8 05 00 00 00 00 	movabs rax,0x5
  409e2e:	00 00 00 
  409e31:	49 89 c3             	mov    r11,rax
  409e34:	4c 01 de             	add    rsi,r11
  409e37:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409e3e:	10 00 00 
  409e41:	49 89 c3             	mov    r11,rax
  409e44:	48 89 f0             	mov    rax,rsi
  409e47:	49 f7 e3             	mul    r11
  409e4a:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409e51:	00 00 00 
  409e54:	49 89 c3             	mov    r11,rax
  409e57:	49 0f af d3          	imul   rdx,r11
  409e5b:	48 29 d6             	sub    rsi,rdx
  409e5e:	48 89 f0             	mov    rax,rsi
  409e61:	4c 29 d8             	sub    rax,r11
  409e64:	4c 39 de             	cmp    rsi,r11
  409e67:	48 0f 43 f0          	cmovae rsi,rax
  409e6b:	49 89 f0             	mov    r8,rsi
  409e6e:	48 ff c3             	inc    rbx
  409e71:	48 39 eb             	cmp    rbx,rbp
  409e74:	0f 82 a6 ff ff ff    	jb     0x409e20
  409e7a:	4c 89 c0             	mov    rax,r8
  409e7d:	48 a3 80 10 00 00 00 	movabs ds:0x10000001080,rax
  409e84:	01 00 00 
  409e87:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409e8e:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409e95:	49 89 e7             	mov    r15,rsp
  409e98:	48 a1 80 10 00 00 00 	movabs rax,ds:0x10000001080
  409e9f:	01 00 00 
  409ea2:	50                   	push   rax
  409ea3:	58                   	pop    rax
  409ea4:	49 89 c0             	mov    r8,rax
  409ea7:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409eae:	00 00 00 
  409eb1:	50                   	push   rax
  409eb2:	58                   	pop    rax
  409eb3:	48 89 c3             	mov    rbx,rax
  409eb6:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  409ebd:	01 00 00 
  409ec0:	50                   	push   rax
  409ec1:	58                   	pop    rax
  409ec2:	48 89 c5             	mov    rbp,rax
  409ec5:	48 39 eb             	cmp    rbx,rbp
  409ec8:	0f 83 5a 00 00 00    	jae    0x409f28
  409ece:	4c 89 c6             	mov    rsi,r8
  409ed1:	49 0f af f0          	imul   rsi,r8
  409ed5:	48 b8 11 00 00 00 00 	movabs rax,0x11
  409edc:	00 00 00 
  409edf:	49 89 c3             	mov    r11,rax
  409ee2:	4c 01 de             	add    rsi,r11
  409ee5:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409eec:	10 00 00 
  409eef:	49 89 c3             	mov    r11,rax
  409ef2:	48 89 f0             	mov    rax,rsi
  409ef5:	49 f7 e3             	mul    r11
  409ef8:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409eff:	00 00 00 
  409f02:	49 89 c3             	mov    r11,rax
  409f05:	49 0f af d3          	imul   rdx,r11
  409f09:	48 29 d6             	sub    rsi,rdx
  409f0c:	48 89 f0             	mov    rax,rsi
  409f0f:	4c 29 d8             	sub    rax,r11
  409f12:	4c 39 de             	cmp    rsi,r11
  409f15:	48 0f 43 f0          	cmovae rsi,rax
  409f19:	49 89 f0             	mov    r8,rsi
  409f1c:	48 ff c3             	inc    rbx
  409f1f:	48 39 eb             	cmp    rbx,rbp
  409f22:	0f 82 a6 ff ff ff    	jb     0x409ece
  409f28:	4c 89 c0             	mov    rax,r8
  409f2b:	48 a3 80 50 00 00 00 	movabs ds:0x10000005080,rax
  409f32:	01 00 00 
  409f35:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409f3c:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409f43:	49 89 e7             	mov    r15,rsp
  409f46:	48 a1 80 50 00 00 00 	movabs rax,ds:0x10000005080
  409f4d:	01 00 00 
  409f50:	50                   	push   rax
  409f51:	58                   	pop    rax
  409f52:	49 89 c0             	mov    r8,rax
  409f55:	48 b8 00 00 00 00 00 	movabs rax,0x0
  409f5c:	00 00 00 
  409f5f:	50                   	push   rax
  409f60:	58                   	pop    rax
  409f61:	48 89 c3             	mov    rbx,rax
  409f64:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  409f6b:	01 00 00 
  409f6e:	50                   	push   rax
  409f6f:	58                   	pop    rax
  409f70:	48 89 c5             	mov    rbp,rax
  409f73:	48 39 eb             	cmp    rbx,rbp
  409f76:	0f 83 5a 00 00 00    	jae    0x409fd6
  409f7c:	4c 89 c6             	mov    rsi,r8
  409f7f:	49 0f af f0          	imul   rsi,r8
  409f83:	48 b8 1f 00 00 00 00 	movabs rax,0x1f
  409f8a:	00 00 00 
  409f8d:	49 89 c3             	mov    r11,rax
  409f90:	4c 01 de             	add    rsi,r11
  409f93:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  409f9a:	10 00 00 
  409f9d:	49 89 c3             	mov    r11,rax
  409fa0:	48 89 f0             	mov    rax,rsi
  409fa3:	49 f7 e3             	mul    r11
  409fa6:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  409fad:	00 00 00 
  409fb0:	49 89 c3             	mov    r11,rax
  409fb3:	49 0f af d3          	imul   rdx,r11
  409fb7:	48 29 d6             	sub    rsi,rdx
  409fba:	48 89 f0             	mov    rax,rsi
  409fbd:	4c 29 d8             	sub    rax,r11
  409fc0:	4c 39 de             	cmp    rsi,r11
  409fc3:	48 0f 43 f0          	cmovae rsi,rax
  409fc7:	49 89 f0             	mov    r8,rsi
  409fca:	48 ff c3             	inc    rbx
  409fcd:	48 39 eb             	cmp    rbx,rbp
  409fd0:	0f 82 a6 ff ff ff    	jb     0x409f7c
  409fd6:	4c 89 c0             	mov    rax,r8
  409fd9:	48 a3 80 90 00 00 00 	movabs ds:0x10000009080,rax
  409fe0:	01 00 00 
  409fe3:	48 81 c4 20 00 00 00 	add    rsp,0x20
  409fea:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  409ff1:	49 89 e7             	mov    r15,rsp
  409ff4:	48 a1 80 90 00 00 00 	movabs rax,ds:0x10000009080
  409ffb:	01 00 00 
  409ffe:	50                   	push   rax
  409fff:	58                   	pop    rax
  40a000:	49 89 c0             	mov    r8,rax
  40a003:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a00a:	00 00 00 
  40a00d:	50                   	push   rax
  40a00e:	58                   	pop    rax
  40a00f:	48 89 c3             	mov    rbx,rax
  40a012:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a019:	01 00 00 
  40a01c:	50                   	push   rax
  40a01d:	58                   	pop    rax
  40a01e:	48 89 c5             	mov    rbp,rax
  40a021:	48 39 eb             	cmp    rbx,rbp
  40a024:	0f 83 5a 00 00 00    	jae    0x40a084
  40a02a:	4c 89 c6             	mov    rsi,r8
  40a02d:	49 0f af f0          	imul   rsi,r8
  40a031:	48 b8 2f 00 00 00 00 	movabs rax,0x2f
  40a038:	00 00 00 
  40a03b:	49 89 c3             	mov    r11,rax
  40a03e:	4c 01 de             	add    rsi,r11
  40a041:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a048:	10 00 00 
  40a04b:	49 89 c3             	mov    r11,rax
  40a04e:	48 89 f0             	mov    rax,rsi
  40a051:	49 f7 e3             	mul    r11
  40a054:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a05b:	00 00 00 
  40a05e:	49 89 c3             	mov    r11,rax
  40a061:	49 0f af d3          	imul   rdx,r11
  40a065:	48 29 d6             	sub    rsi,rdx
  40a068:	48 89 f0             	mov    rax,rsi
  40a06b:	4c 29 d8             	sub    rax,r11
  40a06e:	4c 39 de             	cmp    rsi,r11
  40a071:	48 0f 43 f0          	cmovae rsi,rax
  40a075:	49 89 f0             	mov    r8,rsi
  40a078:	48 ff c3             	inc    rbx
  40a07b:	48 39 eb             	cmp    rbx,rbp
  40a07e:	0f 82 a6 ff ff ff    	jb     0x40a02a
  40a084:	4c 89 c0             	mov    rax,r8
  40a087:	48 a3 80 d0 00 00 00 	movabs ds:0x1000000d080,rax
  40a08e:	01 00 00 
  40a091:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a098:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a09f:	49 89 e7             	mov    r15,rsp
  40a0a2:	48 a1 80 d0 00 00 00 	movabs rax,ds:0x1000000d080
  40a0a9:	01 00 00 
  40a0ac:	50                   	push   rax
  40a0ad:	58                   	pop    rax
  40a0ae:	49 89 c0             	mov    r8,rax
  40a0b1:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a0b8:	00 00 00 
  40a0bb:	50                   	push   rax
  40a0bc:	58                   	pop    rax
  40a0bd:	48 89 c3             	mov    rbx,rax
  40a0c0:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a0c7:	01 00 00 
  40a0ca:	50                   	push   rax
  40a0cb:	58                   	pop    rax
  40a0cc:	48 89 c5             	mov    rbp,rax
  40a0cf:	48 39 eb             	cmp    rbx,rbp
  40a0d2:	0f 83 5a 00 00 00    	jae    0x40a132
  40a0d8:	4c 89 c6             	mov    rsi,r8
  40a0db:	49 0f af f0          	imul   rsi,r8
  40a0df:	48 b8 43 00 00 00 00 	movabs rax,0x43
  40a0e6:	00 00 00 
  40a0e9:	49 89 c3             	mov    r11,rax
  40a0ec:	4c 01 de             	add    rsi,r11
  40a0ef:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a0f6:	10 00 00 
  40a0f9:	49 89 c3             	mov    r11,rax
  40a0fc:	48 89 f0             	mov    rax,rsi
  40a0ff:	49 f7 e3             	mul    r11
  40a102:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a109:	00 00 00 
  40a10c:	49 89 c3             	mov    r11,rax
  40a10f:	49 0f af d3          	imul   rdx,r11
  40a113:	48 29 d6             	sub    rsi,rdx
  40a116:	48 89 f0             	mov    rax,rsi
  40a119:	4c 29 d8             	sub    rax,r11
  40a11c:	4c 39 de             	cmp    rsi,r11
  40a11f:	48 0f 43 f0          	cmovae rsi,rax
  40a123:	49 89 f0             	mov    r8,rsi
  40a126:	48 ff c3             	inc    rbx
  40a129:	48 39 eb             	cmp    rbx,rbp
  40a12c:	0f 82 a6 ff ff ff    	jb     0x40a0d8
  40a132:	4c 89 c0             	mov    rax,r8
  40a135:	48 a3 80 10 01 00 00 	movabs ds:0x10000011080,rax
  40a13c:	01 00 00 
  40a13f:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a146:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a14d:	49 89 e7             	mov    r15,rsp
  40a150:	48 a1 80 10 01 00 00 	movabs rax,ds:0x10000011080
  40a157:	01 00 00 
  40a15a:	50                   	push   rax
  40a15b:	58                   	pop    rax
  40a15c:	49 89 c0             	mov    r8,rax
  40a15f:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a166:	00 00 00 
  40a169:	50                   	push   rax
  40a16a:	58                   	pop    rax
  40a16b:	48 89 c3             	mov    rbx,rax
  40a16e:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  40a175:	01 00 00 
  40a178:	50                   	push   rax
  40a179:	58                   	pop    rax
  40a17a:	48 89 c5             	mov    rbp,rax
  40a17d:	48 39 eb             	cmp    rbx,rbp
  40a180:	0f 83 5a 00 00 00    	jae    0x40a1e0
  40a186:	4c 89 c6             	mov    rsi,r8
  40a189:	49 0f af f0          	imul   rsi,r8
  40a18d:	48 b8 53 00 00 00 00 	movabs rax,0x53
  40a194:	00 00 00 
  40a197:	49 89 c3             	mov    r11,rax
  40a19a:	4c 01 de             	add    rsi,r11
  40a19d:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a1a4:	10 00 00 
  40a1a7:	49 89 c3             	mov    r11,rax
  40a1aa:	48 89 f0             	mov    rax,rsi
  40a1ad:	49 f7 e3             	mul    r11
  40a1b0:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a1b7:	00 00 00 
  40a1ba:	49 89 c3             	mov    r11,rax
  40a1bd:	49 0f af d3          	imul   rdx,r11
  40a1c1:	48 29 d6             	sub    rsi,rdx
  40a1c4:	48 89 f0             	mov    rax,rsi
  40a1c7:	4c 29 d8             	sub    rax,r11
  40a1ca:	4c 39 de             	cmp    rsi,r11
  40a1cd:	48 0f 43 f0          	cmovae rsi,rax
  40a1d1:	49 89 f0             	mov    r8,rsi
  40a1d4:	48 ff c3             	inc    rbx
  40a1d7:	48 39 eb             	cmp    rbx,rbp
  40a1da:	0f 82 a6 ff ff ff    	jb     0x40a186
  40a1e0:	4c 89 c0             	mov    rax,r8
  40a1e3:	48 a3 80 50 01 00 00 	movabs ds:0x10000015080,rax
  40a1ea:	01 00 00 
  40a1ed:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a1f4:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a1fb:	49 89 e7             	mov    r15,rsp
  40a1fe:	48 a1 80 50 01 00 00 	movabs rax,ds:0x10000015080
  40a205:	01 00 00 
  40a208:	50                   	push   rax
  40a209:	58                   	pop    rax
  40a20a:	49 89 c0             	mov    r8,rax
  40a20d:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a214:	00 00 00 
  40a217:	50                   	push   rax
  40a218:	58                   	pop    rax
  40a219:	48 89 c3             	mov    rbx,rax
  40a21c:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a223:	01 00 00 
  40a226:	50                   	push   rax
  40a227:	58                   	pop    rax
  40a228:	48 89 c5             	mov    rbp,rax
  40a22b:	48 39 eb             	cmp    rbx,rbp
  40a22e:	0f 83 5a 00 00 00    	jae    0x40a28e
  40a234:	4c 89 c6             	mov    rsi,r8
  40a237:	49 0f af f0          	imul   rsi,r8
  40a23b:	48 b8 67 00 00 00 00 	movabs rax,0x67
  40a242:	00 00 00 
  40a245:	49 89 c3             	mov    r11,rax
  40a248:	4c 01 de             	add    rsi,r11
  40a24b:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a252:	10 00 00 
  40a255:	49 89 c3             	mov    r11,rax
  40a258:	48 89 f0             	mov    rax,rsi
  40a25b:	49 f7 e3             	mul    r11
  40a25e:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a265:	00 00 00 
  40a268:	49 89 c3             	mov    r11,rax
  40a26b:	49 0f af d3          	imul   rdx,r11
  40a26f:	48 29 d6             	sub    rsi,rdx
  40a272:	48 89 f0             	mov    rax,rsi
  40a275:	4c 29 d8             	sub    rax,r11
  40a278:	4c 39 de             	cmp    rsi,r11
  40a27b:	48 0f 43 f0          	cmovae rsi,rax
  40a27f:	49 89 f0             	mov    r8,rsi
  40a282:	48 ff c3             	inc    rbx
  40a285:	48 39 eb             	cmp    rbx,rbp
  40a288:	0f 82 a6 ff ff ff    	jb     0x40a234
  40a28e:	4c 89 c0             	mov    rax,r8
  40a291:	48 a3 80 90 01 00 00 	movabs ds:0x10000019080,rax
  40a298:	01 00 00 
  40a29b:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a2a2:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a2a9:	49 89 e7             	mov    r15,rsp
  40a2ac:	48 a1 80 90 01 00 00 	movabs rax,ds:0x10000019080
  40a2b3:	01 00 00 
  40a2b6:	50                   	push   rax
  40a2b7:	58                   	pop    rax
  40a2b8:	49 89 c0             	mov    r8,rax
  40a2bb:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a2c2:	00 00 00 
  40a2c5:	50                   	push   rax
  40a2c6:	58                   	pop    rax
  40a2c7:	48 89 c3             	mov    rbx,rax
  40a2ca:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a2d1:	01 00 00 
  40a2d4:	50                   	push   rax
  40a2d5:	58                   	pop    rax
  40a2d6:	48 89 c5             	mov    rbp,rax
  40a2d9:	48 39 eb             	cmp    rbx,rbp
  40a2dc:	0f 83 5a 00 00 00    	jae    0x40a33c
  40a2e2:	4c 89 c6             	mov    rsi,r8
  40a2e5:	49 0f af f0          	imul   rsi,r8
  40a2e9:	48 b8 7f 00 00 00 00 	movabs rax,0x7f
  40a2f0:	00 00 00 
  40a2f3:	49 89 c3             	mov    r11,rax
  40a2f6:	4c 01 de             	add    rsi,r11
  40a2f9:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a300:	10 00 00 
  40a303:	49 89 c3             	mov    r11,rax
  40a306:	48 89 f0             	mov    rax,rsi
  40a309:	49 f7 e3             	mul    r11
  40a30c:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a313:	00 00 00 
  40a316:	49 89 c3             	mov    r11,rax
  40a319:	49 0f af d3          	imul   rdx,r11
  40a31d:	48 29 d6             	sub    rsi,rdx
  40a320:	48 89 f0             	mov    rax,rsi
  40a323:	4c 29 d8             	sub    rax,r11
  40a326:	4c 39 de             	cmp    rsi,r11
  40a329:	48 0f 43 f0          	cmovae rsi,rax
  40a32d:	49 89 f0             	mov    r8,rsi
  40a330:	48 ff c3             	inc    rbx
  40a333:	48 39 eb             	cmp    rbx,rbp
  40a336:	0f 82 a6 ff ff ff    	jb     0x40a2e2
  40a33c:	4c 89 c0             	mov    rax,r8
  40a33f:	48 a3 80 d0 01 00 00 	movabs ds:0x1000001d080,rax
  40a346:	01 00 00 
  40a349:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a350:	c3                   	ret
	...
  40a35d:	00 00                	add    BYTE PTR [rax],al
  40a35f:	00 48 81             	add    BYTE PTR [rax-0x7f],cl
  40a362:	ec                   	in     al,dx
  40a363:	20 00                	and    BYTE PTR [rax],al
  40a365:	00 00                	add    BYTE PTR [rax],al
  40a367:	49 89 e7             	mov    r15,rsp
  40a36a:	48 a1 10 00 00 00 00 	movabs rax,ds:0x10000000010
  40a371:	01 00 00 
  40a374:	50                   	push   rax
  40a375:	58                   	pop    rax
  40a376:	49 89 c0             	mov    r8,rax
  40a379:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a380:	00 00 00 
  40a383:	50                   	push   rax
  40a384:	58                   	pop    rax
  40a385:	48 89 c3             	mov    rbx,rax
  40a388:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a38f:	01 00 00 
  40a392:	50                   	push   rax
  40a393:	58                   	pop    rax
  40a394:	48 89 c5             	mov    rbp,rax
  40a397:	48 39 eb             	cmp    rbx,rbp
  40a39a:	0f 83 5a 00 00 00    	jae    0x40a3fa
  40a3a0:	4c 89 c6             	mov    rsi,r8
  40a3a3:	49 0f af f0          	imul   rsi,r8
  40a3a7:	48 b8 07 00 00 00 00 	movabs rax,0x7
  40a3ae:	00 00 00 
  40a3b1:	49 89 c3             	mov    r11,rax
  40a3b4:	4c 01 de             	add    rsi,r11
  40a3b7:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a3be:	10 00 00 
  40a3c1:	49 89 c3             	mov    r11,rax
  40a3c4:	48 89 f0             	mov    rax,rsi
  40a3c7:	49 f7 e3             	mul    r11
  40a3ca:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a3d1:	00 00 00 
  40a3d4:	49 89 c3             	mov    r11,rax
  40a3d7:	49 0f af d3          	imul   rdx,r11
  40a3db:	48 29 d6             	sub    rsi,rdx
  40a3de:	48 89 f0             	mov    rax,rsi
  40a3e1:	4c 29 d8             	sub    rax,r11
  40a3e4:	4c 39 de             	cmp    rsi,r11
  40a3e7:	48 0f 43 f0          	cmovae rsi,rax
  40a3eb:	49 89 f0             	mov    r8,rsi
  40a3ee:	48 ff c3             	inc    rbx
  40a3f1:	48 39 eb             	cmp    rbx,rbp
  40a3f4:	0f 82 a6 ff ff ff    	jb     0x40a3a0
  40a3fa:	4c 89 c0             	mov    rax,r8
  40a3fd:	48 a3 80 20 00 00 00 	movabs ds:0x10000002080,rax
  40a404:	01 00 00 
  40a407:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a40e:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a415:	49 89 e7             	mov    r15,rsp
  40a418:	48 a1 80 20 00 00 00 	movabs rax,ds:0x10000002080
  40a41f:	01 00 00 
  40a422:	50                   	push   rax
  40a423:	58                   	pop    rax
  40a424:	49 89 c0             	mov    r8,rax
  40a427:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a42e:	00 00 00 
  40a431:	50                   	push   rax
  40a432:	58                   	pop    rax
  40a433:	48 89 c3             	mov    rbx,rax
  40a436:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a43d:	01 00 00 
  40a440:	50                   	push   rax
  40a441:	58                   	pop    rax
  40a442:	48 89 c5             	mov    rbp,rax
  40a445:	48 39 eb             	cmp    rbx,rbp
  40a448:	0f 83 5a 00 00 00    	jae    0x40a4a8
  40a44e:	4c 89 c6             	mov    rsi,r8
  40a451:	49 0f af f0          	imul   rsi,r8
  40a455:	48 b8 13 00 00 00 00 	movabs rax,0x13
  40a45c:	00 00 00 
  40a45f:	49 89 c3             	mov    r11,rax
  40a462:	4c 01 de             	add    rsi,r11
  40a465:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a46c:	10 00 00 
  40a46f:	49 89 c3             	mov    r11,rax
  40a472:	48 89 f0             	mov    rax,rsi
  40a475:	49 f7 e3             	mul    r11
  40a478:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a47f:	00 00 00 
  40a482:	49 89 c3             	mov    r11,rax
  40a485:	49 0f af d3          	imul   rdx,r11
  40a489:	48 29 d6             	sub    rsi,rdx
  40a48c:	48 89 f0             	mov    rax,rsi
  40a48f:	4c 29 d8             	sub    rax,r11
  40a492:	4c 39 de             	cmp    rsi,r11
  40a495:	48 0f 43 f0          	cmovae rsi,rax
  40a499:	49 89 f0             	mov    r8,rsi
  40a49c:	48 ff c3             	inc    rbx
  40a49f:	48 39 eb             	cmp    rbx,rbp
  40a4a2:	0f 82 a6 ff ff ff    	jb     0x40a44e
  40a4a8:	4c 89 c0             	mov    rax,r8
  40a4ab:	48 a3 80 60 00 00 00 	movabs ds:0x10000006080,rax
  40a4b2:	01 00 00 
  40a4b5:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a4bc:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a4c3:	49 89 e7             	mov    r15,rsp
  40a4c6:	48 a1 80 60 00 00 00 	movabs rax,ds:0x10000006080
  40a4cd:	01 00 00 
  40a4d0:	50                   	push   rax
  40a4d1:	58                   	pop    rax
  40a4d2:	49 89 c0             	mov    r8,rax
  40a4d5:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a4dc:	00 00 00 
  40a4df:	50                   	push   rax
  40a4e0:	58                   	pop    rax
  40a4e1:	48 89 c3             	mov    rbx,rax
  40a4e4:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  40a4eb:	01 00 00 
  40a4ee:	50                   	push   rax
  40a4ef:	58                   	pop    rax
  40a4f0:	48 89 c5             	mov    rbp,rax
  40a4f3:	48 39 eb             	cmp    rbx,rbp
  40a4f6:	0f 83 5a 00 00 00    	jae    0x40a556
  40a4fc:	4c 89 c6             	mov    rsi,r8
  40a4ff:	49 0f af f0          	imul   rsi,r8
  40a503:	48 b8 25 00 00 00 00 	movabs rax,0x25
  40a50a:	00 00 00 
  40a50d:	49 89 c3             	mov    r11,rax
  40a510:	4c 01 de             	add    rsi,r11
  40a513:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a51a:	10 00 00 
  40a51d:	49 89 c3             	mov    r11,rax
  40a520:	48 89 f0             	mov    rax,rsi
  40a523:	49 f7 e3             	mul    r11
  40a526:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a52d:	00 00 00 
  40a530:	49 89 c3             	mov    r11,rax
  40a533:	49 0f af d3          	imul   rdx,r11
  40a537:	48 29 d6             	sub    rsi,rdx
  40a53a:	48 89 f0             	mov    rax,rsi
  40a53d:	4c 29 d8             	sub    rax,r11
  40a540:	4c 39 de             	cmp    rsi,r11
  40a543:	48 0f 43 f0          	cmovae rsi,rax
  40a547:	49 89 f0             	mov    r8,rsi
  40a54a:	48 ff c3             	inc    rbx
  40a54d:	48 39 eb             	cmp    rbx,rbp
  40a550:	0f 82 a6 ff ff ff    	jb     0x40a4fc
  40a556:	4c 89 c0             	mov    rax,r8
  40a559:	48 a3 80 a0 00 00 00 	movabs ds:0x1000000a080,rax
  40a560:	01 00 00 
  40a563:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a56a:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a571:	49 89 e7             	mov    r15,rsp
  40a574:	48 a1 80 a0 00 00 00 	movabs rax,ds:0x1000000a080
  40a57b:	01 00 00 
  40a57e:	50                   	push   rax
  40a57f:	58                   	pop    rax
  40a580:	49 89 c0             	mov    r8,rax
  40a583:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a58a:	00 00 00 
  40a58d:	50                   	push   rax
  40a58e:	58                   	pop    rax
  40a58f:	48 89 c3             	mov    rbx,rax
  40a592:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a599:	01 00 00 
  40a59c:	50                   	push   rax
  40a59d:	58                   	pop    rax
  40a59e:	48 89 c5             	mov    rbp,rax
  40a5a1:	48 39 eb             	cmp    rbx,rbp
  40a5a4:	0f 83 5a 00 00 00    	jae    0x40a604
  40a5aa:	4c 89 c6             	mov    rsi,r8
  40a5ad:	49 0f af f0          	imul   rsi,r8
  40a5b1:	48 b8 35 00 00 00 00 	movabs rax,0x35
  40a5b8:	00 00 00 
  40a5bb:	49 89 c3             	mov    r11,rax
  40a5be:	4c 01 de             	add    rsi,r11
  40a5c1:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a5c8:	10 00 00 
  40a5cb:	49 89 c3             	mov    r11,rax
  40a5ce:	48 89 f0             	mov    rax,rsi
  40a5d1:	49 f7 e3             	mul    r11
  40a5d4:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a5db:	00 00 00 
  40a5de:	49 89 c3             	mov    r11,rax
  40a5e1:	49 0f af d3          	imul   rdx,r11
  40a5e5:	48 29 d6             	sub    rsi,rdx
  40a5e8:	48 89 f0             	mov    rax,rsi
  40a5eb:	4c 29 d8             	sub    rax,r11
  40a5ee:	4c 39 de             	cmp    rsi,r11
  40a5f1:	48 0f 43 f0          	cmovae rsi,rax
  40a5f5:	49 89 f0             	mov    r8,rsi
  40a5f8:	48 ff c3             	inc    rbx
  40a5fb:	48 39 eb             	cmp    rbx,rbp
  40a5fe:	0f 82 a6 ff ff ff    	jb     0x40a5aa
  40a604:	4c 89 c0             	mov    rax,r8
  40a607:	48 a3 80 e0 00 00 00 	movabs ds:0x1000000e080,rax
  40a60e:	01 00 00 
  40a611:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a618:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a61f:	49 89 e7             	mov    r15,rsp
  40a622:	48 a1 80 e0 00 00 00 	movabs rax,ds:0x1000000e080
  40a629:	01 00 00 
  40a62c:	50                   	push   rax
  40a62d:	58                   	pop    rax
  40a62e:	49 89 c0             	mov    r8,rax
  40a631:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a638:	00 00 00 
  40a63b:	50                   	push   rax
  40a63c:	58                   	pop    rax
  40a63d:	48 89 c3             	mov    rbx,rax
  40a640:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a647:	01 00 00 
  40a64a:	50                   	push   rax
  40a64b:	58                   	pop    rax
  40a64c:	48 89 c5             	mov    rbp,rax
  40a64f:	48 39 eb             	cmp    rbx,rbp
  40a652:	0f 83 5a 00 00 00    	jae    0x40a6b2
  40a658:	4c 89 c6             	mov    rsi,r8
  40a65b:	49 0f af f0          	imul   rsi,r8
  40a65f:	48 b8 47 00 00 00 00 	movabs rax,0x47
  40a666:	00 00 00 
  40a669:	49 89 c3             	mov    r11,rax
  40a66c:	4c 01 de             	add    rsi,r11
  40a66f:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a676:	10 00 00 
  40a679:	49 89 c3             	mov    r11,rax
  40a67c:	48 89 f0             	mov    rax,rsi
  40a67f:	49 f7 e3             	mul    r11
  40a682:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a689:	00 00 00 
  40a68c:	49 89 c3             	mov    r11,rax
  40a68f:	49 0f af d3          	imul   rdx,r11
  40a693:	48 29 d6             	sub    rsi,rdx
  40a696:	48 89 f0             	mov    rax,rsi
  40a699:	4c 29 d8             	sub    rax,r11
  40a69c:	4c 39 de             	cmp    rsi,r11
  40a69f:	48 0f 43 f0          	cmovae rsi,rax
  40a6a3:	49 89 f0             	mov    r8,rsi
  40a6a6:	48 ff c3             	inc    rbx
  40a6a9:	48 39 eb             	cmp    rbx,rbp
  40a6ac:	0f 82 a6 ff ff ff    	jb     0x40a658
  40a6b2:	4c 89 c0             	mov    rax,r8
  40a6b5:	48 a3 80 20 01 00 00 	movabs ds:0x10000012080,rax
  40a6bc:	01 00 00 
  40a6bf:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a6c6:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a6cd:	49 89 e7             	mov    r15,rsp
  40a6d0:	48 a1 80 20 01 00 00 	movabs rax,ds:0x10000012080
  40a6d7:	01 00 00 
  40a6da:	50                   	push   rax
  40a6db:	58                   	pop    rax
  40a6dc:	49 89 c0             	mov    r8,rax
  40a6df:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a6e6:	00 00 00 
  40a6e9:	50                   	push   rax
  40a6ea:	58                   	pop    rax
  40a6eb:	48 89 c3             	mov    rbx,rax
  40a6ee:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a6f5:	01 00 00 
  40a6f8:	50                   	push   rax
  40a6f9:	58                   	pop    rax
  40a6fa:	48 89 c5             	mov    rbp,rax
  40a6fd:	48 39 eb             	cmp    rbx,rbp
  40a700:	0f 83 5a 00 00 00    	jae    0x40a760
  40a706:	4c 89 c6             	mov    rsi,r8
  40a709:	49 0f af f0          	imul   rsi,r8
  40a70d:	48 b8 59 00 00 00 00 	movabs rax,0x59
  40a714:	00 00 00 
  40a717:	49 89 c3             	mov    r11,rax
  40a71a:	4c 01 de             	add    rsi,r11
  40a71d:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a724:	10 00 00 
  40a727:	49 89 c3             	mov    r11,rax
  40a72a:	48 89 f0             	mov    rax,rsi
  40a72d:	49 f7 e3             	mul    r11
  40a730:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a737:	00 00 00 
  40a73a:	49 89 c3             	mov    r11,rax
  40a73d:	49 0f af d3          	imul   rdx,r11
  40a741:	48 29 d6             	sub    rsi,rdx
  40a744:	48 89 f0             	mov    rax,rsi
  40a747:	4c 29 d8             	sub    rax,r11
  40a74a:	4c 39 de             	cmp    rsi,r11
  40a74d:	48 0f 43 f0          	cmovae rsi,rax
  40a751:	49 89 f0             	mov    r8,rsi
  40a754:	48 ff c3             	inc    rbx
  40a757:	48 39 eb             	cmp    rbx,rbp
  40a75a:	0f 82 a6 ff ff ff    	jb     0x40a706
  40a760:	4c 89 c0             	mov    rax,r8
  40a763:	48 a3 80 60 01 00 00 	movabs ds:0x10000016080,rax
  40a76a:	01 00 00 
  40a76d:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a774:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a77b:	49 89 e7             	mov    r15,rsp
  40a77e:	48 a1 80 60 01 00 00 	movabs rax,ds:0x10000016080
  40a785:	01 00 00 
  40a788:	50                   	push   rax
  40a789:	58                   	pop    rax
  40a78a:	49 89 c0             	mov    r8,rax
  40a78d:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a794:	00 00 00 
  40a797:	50                   	push   rax
  40a798:	58                   	pop    rax
  40a799:	48 89 c3             	mov    rbx,rax
  40a79c:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  40a7a3:	01 00 00 
  40a7a6:	50                   	push   rax
  40a7a7:	58                   	pop    rax
  40a7a8:	48 89 c5             	mov    rbp,rax
  40a7ab:	48 39 eb             	cmp    rbx,rbp
  40a7ae:	0f 83 5a 00 00 00    	jae    0x40a80e
  40a7b4:	4c 89 c6             	mov    rsi,r8
  40a7b7:	49 0f af f0          	imul   rsi,r8
  40a7bb:	48 b8 6b 00 00 00 00 	movabs rax,0x6b
  40a7c2:	00 00 00 
  40a7c5:	49 89 c3             	mov    r11,rax
  40a7c8:	4c 01 de             	add    rsi,r11
  40a7cb:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a7d2:	10 00 00 
  40a7d5:	49 89 c3             	mov    r11,rax
  40a7d8:	48 89 f0             	mov    rax,rsi
  40a7db:	49 f7 e3             	mul    r11
  40a7de:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a7e5:	00 00 00 
  40a7e8:	49 89 c3             	mov    r11,rax
  40a7eb:	49 0f af d3          	imul   rdx,r11
  40a7ef:	48 29 d6             	sub    rsi,rdx
  40a7f2:	48 89 f0             	mov    rax,rsi
  40a7f5:	4c 29 d8             	sub    rax,r11
  40a7f8:	4c 39 de             	cmp    rsi,r11
  40a7fb:	48 0f 43 f0          	cmovae rsi,rax
  40a7ff:	49 89 f0             	mov    r8,rsi
  40a802:	48 ff c3             	inc    rbx
  40a805:	48 39 eb             	cmp    rbx,rbp
  40a808:	0f 82 a6 ff ff ff    	jb     0x40a7b4
  40a80e:	4c 89 c0             	mov    rax,r8
  40a811:	48 a3 80 a0 01 00 00 	movabs ds:0x1000001a080,rax
  40a818:	01 00 00 
  40a81b:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a822:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a829:	49 89 e7             	mov    r15,rsp
  40a82c:	48 a1 80 a0 01 00 00 	movabs rax,ds:0x1000001a080
  40a833:	01 00 00 
  40a836:	50                   	push   rax
  40a837:	58                   	pop    rax
  40a838:	49 89 c0             	mov    r8,rax
  40a83b:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a842:	00 00 00 
  40a845:	50                   	push   rax
  40a846:	58                   	pop    rax
  40a847:	48 89 c3             	mov    rbx,rax
  40a84a:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a851:	01 00 00 
  40a854:	50                   	push   rax
  40a855:	58                   	pop    rax
  40a856:	48 89 c5             	mov    rbp,rax
  40a859:	48 39 eb             	cmp    rbx,rbp
  40a85c:	0f 83 5a 00 00 00    	jae    0x40a8bc
  40a862:	4c 89 c6             	mov    rsi,r8
  40a865:	49 0f af f0          	imul   rsi,r8
  40a869:	48 b8 83 00 00 00 00 	movabs rax,0x83
  40a870:	00 00 00 
  40a873:	49 89 c3             	mov    r11,rax
  40a876:	4c 01 de             	add    rsi,r11
  40a879:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a880:	10 00 00 
  40a883:	49 89 c3             	mov    r11,rax
  40a886:	48 89 f0             	mov    rax,rsi
  40a889:	49 f7 e3             	mul    r11
  40a88c:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a893:	00 00 00 
  40a896:	49 89 c3             	mov    r11,rax
  40a899:	49 0f af d3          	imul   rdx,r11
  40a89d:	48 29 d6             	sub    rsi,rdx
  40a8a0:	48 89 f0             	mov    rax,rsi
  40a8a3:	4c 29 d8             	sub    rax,r11
  40a8a6:	4c 39 de             	cmp    rsi,r11
  40a8a9:	48 0f 43 f0          	cmovae rsi,rax
  40a8ad:	49 89 f0             	mov    r8,rsi
  40a8b0:	48 ff c3             	inc    rbx
  40a8b3:	48 39 eb             	cmp    rbx,rbp
  40a8b6:	0f 82 a6 ff ff ff    	jb     0x40a862
  40a8bc:	4c 89 c0             	mov    rax,r8
  40a8bf:	48 a3 80 e0 01 00 00 	movabs ds:0x1000001e080,rax
  40a8c6:	01 00 00 
  40a8c9:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a8d0:	c3                   	ret
	...
  40a8dd:	00 00                	add    BYTE PTR [rax],al
  40a8df:	00 48 81             	add    BYTE PTR [rax-0x7f],cl
  40a8e2:	ec                   	in     al,dx
  40a8e3:	20 00                	and    BYTE PTR [rax],al
  40a8e5:	00 00                	add    BYTE PTR [rax],al
  40a8e7:	49 89 e7             	mov    r15,rsp
  40a8ea:	48 a1 18 00 00 00 00 	movabs rax,ds:0x10000000018
  40a8f1:	01 00 00 
  40a8f4:	50                   	push   rax
  40a8f5:	58                   	pop    rax
  40a8f6:	49 89 c0             	mov    r8,rax
  40a8f9:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a900:	00 00 00 
  40a903:	50                   	push   rax
  40a904:	58                   	pop    rax
  40a905:	48 89 c3             	mov    rbx,rax
  40a908:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a90f:	01 00 00 
  40a912:	50                   	push   rax
  40a913:	58                   	pop    rax
  40a914:	48 89 c5             	mov    rbp,rax
  40a917:	48 39 eb             	cmp    rbx,rbp
  40a91a:	0f 83 5a 00 00 00    	jae    0x40a97a
  40a920:	4c 89 c6             	mov    rsi,r8
  40a923:	49 0f af f0          	imul   rsi,r8
  40a927:	48 b8 0b 00 00 00 00 	movabs rax,0xb
  40a92e:	00 00 00 
  40a931:	49 89 c3             	mov    r11,rax
  40a934:	4c 01 de             	add    rsi,r11
  40a937:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a93e:	10 00 00 
  40a941:	49 89 c3             	mov    r11,rax
  40a944:	48 89 f0             	mov    rax,rsi
  40a947:	49 f7 e3             	mul    r11
  40a94a:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a951:	00 00 00 
  40a954:	49 89 c3             	mov    r11,rax
  40a957:	49 0f af d3          	imul   rdx,r11
  40a95b:	48 29 d6             	sub    rsi,rdx
  40a95e:	48 89 f0             	mov    rax,rsi
  40a961:	4c 29 d8             	sub    rax,r11
  40a964:	4c 39 de             	cmp    rsi,r11
  40a967:	48 0f 43 f0          	cmovae rsi,rax
  40a96b:	49 89 f0             	mov    r8,rsi
  40a96e:	48 ff c3             	inc    rbx
  40a971:	48 39 eb             	cmp    rbx,rbp
  40a974:	0f 82 a6 ff ff ff    	jb     0x40a920
  40a97a:	4c 89 c0             	mov    rax,r8
  40a97d:	48 a3 80 30 00 00 00 	movabs ds:0x10000003080,rax
  40a984:	01 00 00 
  40a987:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40a98e:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40a995:	49 89 e7             	mov    r15,rsp
  40a998:	48 a1 80 30 00 00 00 	movabs rax,ds:0x10000003080
  40a99f:	01 00 00 
  40a9a2:	50                   	push   rax
  40a9a3:	58                   	pop    rax
  40a9a4:	49 89 c0             	mov    r8,rax
  40a9a7:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40a9ae:	00 00 00 
  40a9b1:	50                   	push   rax
  40a9b2:	58                   	pop    rax
  40a9b3:	48 89 c3             	mov    rbx,rax
  40a9b6:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40a9bd:	01 00 00 
  40a9c0:	50                   	push   rax
  40a9c1:	58                   	pop    rax
  40a9c2:	48 89 c5             	mov    rbp,rax
  40a9c5:	48 39 eb             	cmp    rbx,rbp
  40a9c8:	0f 83 5a 00 00 00    	jae    0x40aa28
  40a9ce:	4c 89 c6             	mov    rsi,r8
  40a9d1:	49 0f af f0          	imul   rsi,r8
  40a9d5:	48 b8 17 00 00 00 00 	movabs rax,0x17
  40a9dc:	00 00 00 
  40a9df:	49 89 c3             	mov    r11,rax
  40a9e2:	4c 01 de             	add    rsi,r11
  40a9e5:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40a9ec:	10 00 00 
  40a9ef:	49 89 c3             	mov    r11,rax
  40a9f2:	48 89 f0             	mov    rax,rsi
  40a9f5:	49 f7 e3             	mul    r11
  40a9f8:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40a9ff:	00 00 00 
  40aa02:	49 89 c3             	mov    r11,rax
  40aa05:	49 0f af d3          	imul   rdx,r11
  40aa09:	48 29 d6             	sub    rsi,rdx
  40aa0c:	48 89 f0             	mov    rax,rsi
  40aa0f:	4c 29 d8             	sub    rax,r11
  40aa12:	4c 39 de             	cmp    rsi,r11
  40aa15:	48 0f 43 f0          	cmovae rsi,rax
  40aa19:	49 89 f0             	mov    r8,rsi
  40aa1c:	48 ff c3             	inc    rbx
  40aa1f:	48 39 eb             	cmp    rbx,rbp
  40aa22:	0f 82 a6 ff ff ff    	jb     0x40a9ce
  40aa28:	4c 89 c0             	mov    rax,r8
  40aa2b:	48 a3 80 70 00 00 00 	movabs ds:0x10000007080,rax
  40aa32:	01 00 00 
  40aa35:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40aa3c:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40aa43:	49 89 e7             	mov    r15,rsp
  40aa46:	48 a1 80 70 00 00 00 	movabs rax,ds:0x10000007080
  40aa4d:	01 00 00 
  40aa50:	50                   	push   rax
  40aa51:	58                   	pop    rax
  40aa52:	49 89 c0             	mov    r8,rax
  40aa55:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40aa5c:	00 00 00 
  40aa5f:	50                   	push   rax
  40aa60:	58                   	pop    rax
  40aa61:	48 89 c3             	mov    rbx,rax
  40aa64:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40aa6b:	01 00 00 
  40aa6e:	50                   	push   rax
  40aa6f:	58                   	pop    rax
  40aa70:	48 89 c5             	mov    rbp,rax
  40aa73:	48 39 eb             	cmp    rbx,rbp
  40aa76:	0f 83 5a 00 00 00    	jae    0x40aad6
  40aa7c:	4c 89 c6             	mov    rsi,r8
  40aa7f:	49 0f af f0          	imul   rsi,r8
  40aa83:	48 b8 29 00 00 00 00 	movabs rax,0x29
  40aa8a:	00 00 00 
  40aa8d:	49 89 c3             	mov    r11,rax
  40aa90:	4c 01 de             	add    rsi,r11
  40aa93:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40aa9a:	10 00 00 
  40aa9d:	49 89 c3             	mov    r11,rax
  40aaa0:	48 89 f0             	mov    rax,rsi
  40aaa3:	49 f7 e3             	mul    r11
  40aaa6:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40aaad:	00 00 00 
  40aab0:	49 89 c3             	mov    r11,rax
  40aab3:	49 0f af d3          	imul   rdx,r11
  40aab7:	48 29 d6             	sub    rsi,rdx
  40aaba:	48 89 f0             	mov    rax,rsi
  40aabd:	4c 29 d8             	sub    rax,r11
  40aac0:	4c 39 de             	cmp    rsi,r11
  40aac3:	48 0f 43 f0          	cmovae rsi,rax
  40aac7:	49 89 f0             	mov    r8,rsi
  40aaca:	48 ff c3             	inc    rbx
  40aacd:	48 39 eb             	cmp    rbx,rbp
  40aad0:	0f 82 a6 ff ff ff    	jb     0x40aa7c
  40aad6:	4c 89 c0             	mov    rax,r8
  40aad9:	48 a3 80 b0 00 00 00 	movabs ds:0x1000000b080,rax
  40aae0:	01 00 00 
  40aae3:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40aaea:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40aaf1:	49 89 e7             	mov    r15,rsp
  40aaf4:	48 a1 80 b0 00 00 00 	movabs rax,ds:0x1000000b080
  40aafb:	01 00 00 
  40aafe:	50                   	push   rax
  40aaff:	58                   	pop    rax
  40ab00:	49 89 c0             	mov    r8,rax
  40ab03:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40ab0a:	00 00 00 
  40ab0d:	50                   	push   rax
  40ab0e:	58                   	pop    rax
  40ab0f:	48 89 c3             	mov    rbx,rax
  40ab12:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  40ab19:	01 00 00 
  40ab1c:	50                   	push   rax
  40ab1d:	58                   	pop    rax
  40ab1e:	48 89 c5             	mov    rbp,rax
  40ab21:	48 39 eb             	cmp    rbx,rbp
  40ab24:	0f 83 5a 00 00 00    	jae    0x40ab84
  40ab2a:	4c 89 c6             	mov    rsi,r8
  40ab2d:	49 0f af f0          	imul   rsi,r8
  40ab31:	48 b8 3b 00 00 00 00 	movabs rax,0x3b
  40ab38:	00 00 00 
  40ab3b:	49 89 c3             	mov    r11,rax
  40ab3e:	4c 01 de             	add    rsi,r11
  40ab41:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40ab48:	10 00 00 
  40ab4b:	49 89 c3             	mov    r11,rax
  40ab4e:	48 89 f0             	mov    rax,rsi
  40ab51:	49 f7 e3             	mul    r11
  40ab54:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40ab5b:	00 00 00 
  40ab5e:	49 89 c3             	mov    r11,rax
  40ab61:	49 0f af d3          	imul   rdx,r11
  40ab65:	48 29 d6             	sub    rsi,rdx
  40ab68:	48 89 f0             	mov    rax,rsi
  40ab6b:	4c 29 d8             	sub    rax,r11
  40ab6e:	4c 39 de             	cmp    rsi,r11
  40ab71:	48 0f 43 f0          	cmovae rsi,rax
  40ab75:	49 89 f0             	mov    r8,rsi
  40ab78:	48 ff c3             	inc    rbx
  40ab7b:	48 39 eb             	cmp    rbx,rbp
  40ab7e:	0f 82 a6 ff ff ff    	jb     0x40ab2a
  40ab84:	4c 89 c0             	mov    rax,r8
  40ab87:	48 a3 80 f0 00 00 00 	movabs ds:0x1000000f080,rax
  40ab8e:	01 00 00 
  40ab91:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40ab98:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40ab9f:	49 89 e7             	mov    r15,rsp
  40aba2:	48 a1 80 f0 00 00 00 	movabs rax,ds:0x1000000f080
  40aba9:	01 00 00 
  40abac:	50                   	push   rax
  40abad:	58                   	pop    rax
  40abae:	49 89 c0             	mov    r8,rax
  40abb1:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40abb8:	00 00 00 
  40abbb:	50                   	push   rax
  40abbc:	58                   	pop    rax
  40abbd:	48 89 c3             	mov    rbx,rax
  40abc0:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40abc7:	01 00 00 
  40abca:	50                   	push   rax
  40abcb:	58                   	pop    rax
  40abcc:	48 89 c5             	mov    rbp,rax
  40abcf:	48 39 eb             	cmp    rbx,rbp
  40abd2:	0f 83 5a 00 00 00    	jae    0x40ac32
  40abd8:	4c 89 c6             	mov    rsi,r8
  40abdb:	49 0f af f0          	imul   rsi,r8
  40abdf:	48 b8 49 00 00 00 00 	movabs rax,0x49
  40abe6:	00 00 00 
  40abe9:	49 89 c3             	mov    r11,rax
  40abec:	4c 01 de             	add    rsi,r11
  40abef:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40abf6:	10 00 00 
  40abf9:	49 89 c3             	mov    r11,rax
  40abfc:	48 89 f0             	mov    rax,rsi
  40abff:	49 f7 e3             	mul    r11
  40ac02:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40ac09:	00 00 00 
  40ac0c:	49 89 c3             	mov    r11,rax
  40ac0f:	49 0f af d3          	imul   rdx,r11
  40ac13:	48 29 d6             	sub    rsi,rdx
  40ac16:	48 89 f0             	mov    rax,rsi
  40ac19:	4c 29 d8             	sub    rax,r11
  40ac1c:	4c 39 de             	cmp    rsi,r11
  40ac1f:	48 0f 43 f0          	cmovae rsi,rax
  40ac23:	49 89 f0             	mov    r8,rsi
  40ac26:	48 ff c3             	inc    rbx
  40ac29:	48 39 eb             	cmp    rbx,rbp
  40ac2c:	0f 82 a6 ff ff ff    	jb     0x40abd8
  40ac32:	4c 89 c0             	mov    rax,r8
  40ac35:	48 a3 80 30 01 00 00 	movabs ds:0x10000013080,rax
  40ac3c:	01 00 00 
  40ac3f:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40ac46:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40ac4d:	49 89 e7             	mov    r15,rsp
  40ac50:	48 a1 80 30 01 00 00 	movabs rax,ds:0x10000013080
  40ac57:	01 00 00 
  40ac5a:	50                   	push   rax
  40ac5b:	58                   	pop    rax
  40ac5c:	49 89 c0             	mov    r8,rax
  40ac5f:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40ac66:	00 00 00 
  40ac69:	50                   	push   rax
  40ac6a:	58                   	pop    rax
  40ac6b:	48 89 c3             	mov    rbx,rax
  40ac6e:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40ac75:	01 00 00 
  40ac78:	50                   	push   rax
  40ac79:	58                   	pop    rax
  40ac7a:	48 89 c5             	mov    rbp,rax
  40ac7d:	48 39 eb             	cmp    rbx,rbp
  40ac80:	0f 83 5a 00 00 00    	jae    0x40ace0
  40ac86:	4c 89 c6             	mov    rsi,r8
  40ac89:	49 0f af f0          	imul   rsi,r8
  40ac8d:	48 b8 61 00 00 00 00 	movabs rax,0x61
  40ac94:	00 00 00 
  40ac97:	49 89 c3             	mov    r11,rax
  40ac9a:	4c 01 de             	add    rsi,r11
  40ac9d:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40aca4:	10 00 00 
  40aca7:	49 89 c3             	mov    r11,rax
  40acaa:	48 89 f0             	mov    rax,rsi
  40acad:	49 f7 e3             	mul    r11
  40acb0:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40acb7:	00 00 00 
  40acba:	49 89 c3             	mov    r11,rax
  40acbd:	49 0f af d3          	imul   rdx,r11
  40acc1:	48 29 d6             	sub    rsi,rdx
  40acc4:	48 89 f0             	mov    rax,rsi
  40acc7:	4c 29 d8             	sub    rax,r11
  40acca:	4c 39 de             	cmp    rsi,r11
  40accd:	48 0f 43 f0          	cmovae rsi,rax
  40acd1:	49 89 f0             	mov    r8,rsi
  40acd4:	48 ff c3             	inc    rbx
  40acd7:	48 39 eb             	cmp    rbx,rbp
  40acda:	0f 82 a6 ff ff ff    	jb     0x40ac86
  40ace0:	4c 89 c0             	mov    rax,r8
  40ace3:	48 a3 80 70 01 00 00 	movabs ds:0x10000017080,rax
  40acea:	01 00 00 
  40aced:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40acf4:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40acfb:	49 89 e7             	mov    r15,rsp
  40acfe:	48 a1 80 70 01 00 00 	movabs rax,ds:0x10000017080
  40ad05:	01 00 00 
  40ad08:	50                   	push   rax
  40ad09:	58                   	pop    rax
  40ad0a:	49 89 c0             	mov    r8,rax
  40ad0d:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40ad14:	00 00 00 
  40ad17:	50                   	push   rax
  40ad18:	58                   	pop    rax
  40ad19:	48 89 c3             	mov    rbx,rax
  40ad1c:	48 a1 28 00 00 00 00 	movabs rax,ds:0x10000000028
  40ad23:	01 00 00 
  40ad26:	50                   	push   rax
  40ad27:	58                   	pop    rax
  40ad28:	48 89 c5             	mov    rbp,rax
  40ad2b:	48 39 eb             	cmp    rbx,rbp
  40ad2e:	0f 83 5a 00 00 00    	jae    0x40ad8e
  40ad34:	4c 89 c6             	mov    rsi,r8
  40ad37:	49 0f af f0          	imul   rsi,r8
  40ad3b:	48 b8 6d 00 00 00 00 	movabs rax,0x6d
  40ad42:	00 00 00 
  40ad45:	49 89 c3             	mov    r11,rax
  40ad48:	4c 01 de             	add    rsi,r11
  40ad4b:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40ad52:	10 00 00 
  40ad55:	49 89 c3             	mov    r11,rax
  40ad58:	48 89 f0             	mov    rax,rsi
  40ad5b:	49 f7 e3             	mul    r11
  40ad5e:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40ad65:	00 00 00 
  40ad68:	49 89 c3             	mov    r11,rax
  40ad6b:	49 0f af d3          	imul   rdx,r11
  40ad6f:	48 29 d6             	sub    rsi,rdx
  40ad72:	48 89 f0             	mov    rax,rsi
  40ad75:	4c 29 d8             	sub    rax,r11
  40ad78:	4c 39 de             	cmp    rsi,r11
  40ad7b:	48 0f 43 f0          	cmovae rsi,rax
  40ad7f:	49 89 f0             	mov    r8,rsi
  40ad82:	48 ff c3             	inc    rbx
  40ad85:	48 39 eb             	cmp    rbx,rbp
  40ad88:	0f 82 a6 ff ff ff    	jb     0x40ad34
  40ad8e:	4c 89 c0             	mov    rax,r8
  40ad91:	48 a3 80 b0 01 00 00 	movabs ds:0x1000001b080,rax
  40ad98:	01 00 00 
  40ad9b:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40ada2:	48 81 ec 20 00 00 00 	sub    rsp,0x20
  40ada9:	49 89 e7             	mov    r15,rsp
  40adac:	48 a1 80 b0 01 00 00 	movabs rax,ds:0x1000001b080
  40adb3:	01 00 00 
  40adb6:	50                   	push   rax
  40adb7:	58                   	pop    rax
  40adb8:	49 89 c0             	mov    r8,rax
  40adbb:	48 b8 00 00 00 00 00 	movabs rax,0x0
  40adc2:	00 00 00 
  40adc5:	50                   	push   rax
  40adc6:	58                   	pop    rax
  40adc7:	48 89 c3             	mov    rbx,rax
  40adca:	48 a1 20 00 00 00 00 	movabs rax,ds:0x10000000020
  40add1:	01 00 00 
  40add4:	50                   	push   rax
  40add5:	58                   	pop    rax
  40add6:	48 89 c5             	mov    rbp,rax
  40add9:	48 39 eb             	cmp    rbx,rbp
  40addc:	0f 83 5a 00 00 00    	jae    0x40ae3c
  40ade2:	4c 89 c6             	mov    rsi,r8
  40ade5:	49 0f af f0          	imul   rsi,r8
  40ade9:	48 b8 89 00 00 00 00 	movabs rax,0x89
  40adf0:	00 00 00 
  40adf3:	49 89 c3             	mov    r11,rax
  40adf6:	4c 01 de             	add    rsi,r11
  40adf9:	48 b8 cb 49 54 f4 c6 	movabs rax,0x10c6f45449cb
  40ae00:	10 00 00 
  40ae03:	49 89 c3             	mov    r11,rax
  40ae06:	48 89 f0             	mov    rax,rsi
  40ae09:	49 f7 e3             	mul    r11
  40ae0c:	48 b8 43 42 0f 00 00 	movabs rax,0xf4243
  40ae13:	00 00 00 
  40ae16:	49 89 c3             	mov    r11,rax
  40ae19:	49 0f af d3          	imul   rdx,r11
  40ae1d:	48 29 d6             	sub    rsi,rdx
  40ae20:	48 89 f0             	mov    rax,rsi
  40ae23:	4c 29 d8             	sub    rax,r11
  40ae26:	4c 39 de             	cmp    rsi,r11
  40ae29:	48 0f 43 f0          	cmovae rsi,rax
  40ae2d:	49 89 f0             	mov    r8,rsi
  40ae30:	48 ff c3             	inc    rbx
  40ae33:	48 39 eb             	cmp    rbx,rbp
  40ae36:	0f 82 a6 ff ff ff    	jb     0x40ade2
  40ae3c:	4c 89 c0             	mov    rax,r8
  40ae3f:	48 a3 80 f0 01 00 00 	movabs ds:0x1000001f080,rax
  40ae46:	01 00 00 
  40ae49:	48 81 c4 20 00 00 00 	add    rsp,0x20
  40ae50:	c3                   	ret
	...
  40ae5d:	00 00                	add    BYTE PTR [rax],al
  40ae5f:	00 48 a1             	add    BYTE PTR [rax-0x5f],cl
  40ae62:	80 c0 01             	add    al,0x1
  40ae65:	00 00                	add    BYTE PTR [rax],al
  40ae67:	01 00                	add    DWORD PTR [rax],eax
  40ae69:	00 50 48             	add    BYTE PTR [rax+0x48],dl
  40ae6c:	a1 80 d0 01 00 00 01 	movabs eax,ds:0x1000001d080
  40ae73:	00 00 
  40ae75:	50                   	push   rax
  40ae76:	59                   	pop    rcx
  40ae77:	58                   	pop    rax
  40ae78:	48 01 c8             	add    rax,rcx
  40ae7b:	50                   	push   rax
  40ae7c:	48 a1 80 e0 01 00 00 	movabs rax,ds:0x1000001e080
  40ae83:	01 00 00 
  40ae86:	50                   	push   rax
  40ae87:	59                   	pop    rcx
  40ae88:	58                   	pop    rax
  40ae89:	48 01 c8             	add    rax,rcx
  40ae8c:	50                   	push   rax
  40ae8d:	48 a1 80 f0 01 00 00 	movabs rax,ds:0x1000001f080
  40ae94:	01 00 00 
  40ae97:	50                   	push   rax
  40ae98:	59                   	pop    rcx
  40ae99:	58                   	pop    rax
  40ae9a:	48 01 c8             	add    rax,rcx
  40ae9d:	50                   	push   rax
  40ae9e:	58                   	pop    rax
  40ae9f:	48 a3 80 00 02 00 00 	movabs ds:0x10000020080,rax
  40aea6:	01 00 00 
  40aea9:	48 a1 80 00 02 00 00 	movabs rax,ds:0x10000020080
  40aeb0:	01 00 00 
  40aeb3:	50                   	push   rax
  40aeb4:	58                   	pop    rax
  40aeb5:	48 a3 80 10 02 00 00 	movabs ds:0x10000021080,rax
  40aebc:	01 00 00 
  40aebf:	c3                   	ret
