program waitslow
  use iso_fortran_env, only: int64
  use omp_lib
  implicit none
  integer(int64), parameter :: m = 1000003_int64
  integer(int64), parameter :: kval(4,8) = reshape([ &
    3_int64,5_int64,7_int64,11_int64, &
    13_int64,17_int64,19_int64,23_int64, &
    29_int64,31_int64,37_int64,41_int64, &
    43_int64,47_int64,53_int64,59_int64, &
    61_int64,67_int64,71_int64,73_int64, &
    79_int64,83_int64,89_int64,97_int64, &
    101_int64,103_int64,107_int64,109_int64, &
    113_int64,127_int64,131_int64,137_int64], [4,8])
  integer(int64) :: seed(4), out(4), heavy, light, x, n, total
  integer :: c, s, i, argc, tid
  character(len=64) :: arg
  argc=command_argument_count(); if(argc /= 6) stop 2
  do c=1,4
     call get_command_argument(c,arg); read(arg,*) seed(c)
  end do
  call get_command_argument(5,arg); read(arg,*) heavy
  call get_command_argument(6,arg); read(arg,*) light
  out=0_int64
#ifdef SERIAL
  do c=1,4
     x=seed(c)
     do s=1,8
        if(mod(s-1,4)==c-1) then; n=heavy; else; n=light; end if
        do i=1,int(n)
           x=modulo(x*x+kval(c,s),m)
        end do
     end do
     out(c)=x
  end do
#else
!$omp parallel private(tid,c,s,i,x,n) shared(seed,out,heavy,light)
  tid=omp_get_thread_num(); c=tid+1; x=seed(c)
  do s=1,8
     if(mod(s-1,4)==c-1) then; n=heavy; else; n=light; end if
     do i=1,int(n)
        x=modulo(x*x+kval(c,s),m)
     end do
#ifdef BSP
!$omp barrier
#endif
  end do
  out(c)=x
!$omp end parallel
#endif
  total=sum(out)
  write(*,'(A,I0)') 'total=',total
end program
