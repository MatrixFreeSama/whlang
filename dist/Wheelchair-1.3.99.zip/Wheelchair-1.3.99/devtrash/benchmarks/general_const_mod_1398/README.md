# General constant-mod Physical Reality benchmark, 1.3.98

This evidence isolates a General u64 recurrence whose hot relation is
`(x*x+k) % 1000003`. Four independent causal chains rotate heavy and light
stages and join only at the final output.

The 1.3.98 Wheelchair binary was AOT-compiled with CPUs 0-3 visible. The
1.3.97 baseline is the immediately preceding release. C and Fortran controls
use the same four independent chains without stage barriers so that the result
measures local code generation after the causal structure has already been
made explicit by hand.

Host observed during the 21-round interleaved run: Intel Xeon Platinum 8573C,
KVM, CPUs 0-3 pinned, four-CPU cgroup quota. Raw wall/CPU times are in
`ab21.csv`.

Medians:

| implementation | wall time |
|---|---:|
| Wheelchair 1.3.97 | 187.395 ms |
| Wheelchair 1.3.98 | **119.934 ms** |
| C async | 137.212 ms |
| Fortran async | 139.161 ms |

1.3.98 is 1.5625x the 1.3.97 throughput and reduces wall time by 36.0% in this
probe. The gain is attributed to the generic compile-time constant-modulo
Physical Reality, not to a workload route. The compiler source contains no
benchmark name or divisor-specific path.
