#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static const uint64_t K[8][4] = {
 {3,5,7,11},{13,17,19,23},{29,31,37,41},{43,47,53,59},
 {61,67,71,73},{79,83,89,97},{101,103,107,109},{113,127,131,137}
};
static inline uint64_t run(uint64_t x, uint64_t n, uint64_t k){
    for(uint64_t i=0;i<n;i++) x=(x*x+k)%1000003ULL;
    return x;
}
int main(int argc,char**argv){
    if(argc!=7) return 2;
    uint64_t seed[4], out[4]={0};
    for(int c=0;c<4;c++) seed[c]=strtoull(argv[c+1],0,10);
    uint64_t heavy=strtoull(argv[5],0,10), light=strtoull(argv[6],0,10);
#ifdef SERIAL
    for(int c=0;c<4;c++){
        uint64_t x=seed[c];
        for(int s=0;s<8;s++) x=run(x, ((s&3)==c)?heavy:light, K[s][c]);
        out[c]=x;
    }
#else
    #pragma omp parallel num_threads(4) shared(out,seed)
    {
        int c=omp_get_thread_num();
        uint64_t x=seed[c];
        for(int s=0;s<8;s++){
            x=run(x, ((s&3)==c)?heavy:light, K[s][c]);
#ifdef BSP
            #pragma omp barrier
#endif
        }
        out[c]=x;
    }
#endif
    unsigned long long total=(unsigned long long)(out[0]+out[1]+out[2]+out[3]);
    printf("total=%llu\n",total);
    return 0;
}
