# General scalar Physical Reality 1.3.96

Same-host 20,000,000-step Strict comparison on the visible AMD EPYC 9V74 execution set (`taskset 0-4`). Eleven alternating rounds; values below are medians. C: `gcc -O3 -march=native -fno-fast-math -ffp-contract=off`. Fortran: `gfortran -O3 -march=native -fno-fast-math -ffp-contract=off -fprotect-parens`.

| workload | 1.3.95 | 1.3.96 | speedup | C Strict | Fortran Strict |
|---|---:|---:|---:|---:|---:|
| mass3 | 149.417 ms | 118.921 ms | 1.256x | 110.943 ms | 110.387 ms |
| chem6 | 138.581 ms | 136.311 ms | 1.017x | 115.108 ms | 115.244 ms |
| rigid7 | 240.182 ms | 189.122 ms | 1.270x | 179.166 ms | 178.340 ms |

The change is compiler-wide scalar FP physicalization, not a workload route. AVX-512 `ISA_CAP_WIDE_REGFILE` exposes the architectural XMM16..31 carrier bank to General; low-register targets retain one 16-carrier realization. Persistent CSE and constants share the existing carrier authority and whole-episode fact arena. The old source-order eight-value residency cliff and the arbitrary two-temporary reserve are removed.

Strict reference bits are unchanged for mass3, chem6 and rigid7 at 0, 1,000 and 100,000 steps. Field production binaries are byte-identical to 1.3.95; a representative Tensor strict generated binary is byte-identical.

`chem6` remains the useful residual probe: its hot loop has no repeated constant materialization after this change, but still carries six next-generation-to-old-generation scalar moves per iteration. No chem-specific scheduler or alternate backend is introduced to hide that remaining general lifetime problem.
