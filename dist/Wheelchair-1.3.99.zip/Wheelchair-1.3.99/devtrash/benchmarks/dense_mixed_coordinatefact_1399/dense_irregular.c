#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

static inline double xv(uint64_t b, uint64_t i) {
    return -0.375 + (double)((b * 31 + i * 17 + 5) % 2048) / 1024.0;
}
static inline double yv(uint64_t b, uint64_t i) {
    return 0.25 + (double)((b * 19 + i * 23 + 7) % 1024) / 1536.0;
}

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    uint64_t n = strtoull(argv[1], 0, 10);
    double *part = (double*)calloc((size_t)n, sizeof(double));
    if (!part) return 3;
    #pragma omp parallel for schedule(static)
    for (uint64_t b = 0; b < n; ++b) {
        double s = 0.0;
        for (uint64_t i = 0; i < 127; ++i) {
            const double xi = xv(b, i);
            for (uint64_t j = 0; j < 127; ++j) {
                const uint64_t p = (j * 37 + i * 13 + b * 7 + 11) % 127;
                const uint64_t q = (j * 19 + i * 5 + b * 11 + 23) % 127;
                const uint64_t r = (i * 41 + j * 17 + b * 13 + 31) % 127;
                const double w = 0.75 + (double)((i * 29 + j * 43 + b * 3 + 17) % 257) / 512.0;
                s += xi * yv(b, p) * w
                   + 0.03125 * xv(b, q) * xi
                   - 0.015625 * yv(b, j) * yv(b, r);
            }
        }
        part[b] = s;
    }
    double checksum = 0.0;
    for (uint64_t b = 0; b < n; ++b) checksum += part[b];
    uint64_t bits; memcpy(&bits, &checksum, sizeof bits);
    printf("checksum_bits=0x%016llx\n", (unsigned long long)bits);
    free(part);
    return 0;
}
