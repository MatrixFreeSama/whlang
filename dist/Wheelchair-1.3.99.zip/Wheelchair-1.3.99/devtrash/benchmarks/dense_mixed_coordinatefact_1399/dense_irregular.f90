program dense_irregular_allpairs127
  use iso_fortran_env, only: int64, real64
  use omp_lib
  implicit none
  integer(int64) :: n, b, i, j, p, q, r, bits
  integer :: ios
  character(len=64) :: arg
  real(real64), allocatable :: part(:)
  real(real64) :: s, xi, w, checksum

  if (command_argument_count() /= 1) stop 2
  call get_command_argument(1, arg)
  read(arg, *, iostat=ios) n
  if (ios /= 0) stop 2
  allocate(part(0:n-1))

!$omp parallel do schedule(static) private(b,i,j,p,q,r,s,xi,w)
  do b = 0_int64, n - 1_int64
     s = 0.0_real64
     do i = 0_int64, 126_int64
        xi = xv(b, i)
        do j = 0_int64, 126_int64
           p = modulo(j * 37_int64 + i * 13_int64 + b * 7_int64 + 11_int64, 127_int64)
           q = modulo(j * 19_int64 + i * 5_int64 + b * 11_int64 + 23_int64, 127_int64)
           r = modulo(i * 41_int64 + j * 17_int64 + b * 13_int64 + 31_int64, 127_int64)
           w = 0.75_real64 + real(modulo(i * 29_int64 + j * 43_int64 + b * 3_int64 + 17_int64, 257_int64), real64) / 512.0_real64
           s = s + xi * yv(b, p) * w &
                 + 0.03125_real64 * xv(b, q) * xi &
                 - 0.015625_real64 * yv(b, j) * yv(b, r)
        end do
     end do
     part(b) = s
  end do
!$omp end parallel do

  checksum = 0.0_real64
  do b = 0_int64, n - 1_int64
     checksum = checksum + part(b)
  end do
  bits = transfer(checksum, bits)
  write(*,'(A,Z16.16)') 'checksum_bits=0x', bits
  deallocate(part)
contains
  pure real(real64) function xv(b, i)
    integer(int64), intent(in) :: b, i
    xv = -0.375_real64 + real(modulo(b * 31_int64 + i * 17_int64 + 5_int64, 2048_int64), real64) / 1024.0_real64
  end function xv
  pure real(real64) function yv(b, i)
    integer(int64), intent(in) :: b, i
    yv = 0.25_real64 + real(modulo(b * 19_int64 + i * 23_int64 + 7_int64, 1024_int64), real64) / 1536.0_real64
  end function yv
end program dense_irregular_allpairs127
