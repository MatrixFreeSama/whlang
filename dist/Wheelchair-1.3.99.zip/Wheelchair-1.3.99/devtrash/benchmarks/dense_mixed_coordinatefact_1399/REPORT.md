# Dense mixed-radix CoordinateFact benchmark

## Workload

`n=8192`, static axes `127 x 127`, 132,128,768 pair interactions. Connectivity
is 100%; irregularity comes from reversible non-power-of-two index
permutations. There is no sparse skip and no branch-selected algorithm.

## Repair sequence

1. Proven `<2^32` literal vector div/mod: remove integer->double reciprocal
   materialization; exact unsigned reciprocal-high plus one correction.
2. Promote static non-power-of-two mixed-radix coordinates to persistent
   CoordinateFacts shared across sibling expressions.
3. Let mixed-radix CoordinateFacts share the existing literal-scaled carrier
   ownership table.

No workload matcher, `127` matcher, fixed execution threshold, runtime selector,
or second Tensor backend was introduced.

## Formal result

Nine interleaved measured rounds after two warmups, affinity CPU 0-3.

| implementation | Strict median | Fast median |
|---|---:|---:|
| Wheelchair 1.3.98 | 641.747 ms | 660.481 ms |
| Wheelchair 1.3.99 | 259.110 ms | 257.937 ms |
| C | 222.339 ms | 208.940 ms |
| Fortran | 230.461 ms | 215.541 ms |

Wheelchair improvement: 2.477x Strict and 2.561x Fast. The remaining control
gap is retained as evidence rather than hidden with a benchmark-specific path.

See `raw.csv` and `summary.csv` for all runs.
