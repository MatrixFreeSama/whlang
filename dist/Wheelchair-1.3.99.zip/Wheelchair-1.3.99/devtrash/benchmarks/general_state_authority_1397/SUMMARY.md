# General StateFact authority closure 1.3.97

Same-host Strict 20M-step evidence on the visible AMD EPYC 9V74 execution set, pinned with `taskset 0-4`.

The 31-round alternating A/B gives `chem6` 140.167 ms for 1.3.96 and 125.606 ms for 1.3.97, a 1.1165x throughput gain. Its six old/next FP transport moves disappear because the complete FP generation proves one carrier fixed point after whole-episode CSE.

`mass3` and `rigid7` fail that complete proof and retain the 1.3.96 realization. Their generated hot-code SHA256 values are unchanged. This prevents partial coalescing from becoming another execution regime.

`general_ab31.csv` is the old/new authority. `general_fourway15.csv` adds C and Fortran Strict references.
