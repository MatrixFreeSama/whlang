#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair137_tensor_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

case "$(cat VERSION)" in 1.3.7|1.3.8|1.3.10) ;; *) exit 1 ;; esac
./build.sh > "$T/build.log" 2>&1
for m in \
 TENSOR_GLOBAL_PHYSICAL_REALITY=BUILT \
 TENSOR_REACHABLE_USE_GRAPH=BUILT \
 TENSOR_DEMAND_CAUSAL_LIFETIME=BUILT \
 TENSOR_CROSS_SUBTREE_VALUEFACT=BUILT \
 TENSOR_AFFINE_FACT_PROFILING=BUILT \
 TENSOR_AFFINE_INDUCTION_PROFITABILITY=BUILT \
 TENSOR_CONSTANT_PROFITABILITY=BUILT \
 TENSOR_THREE_OPERAND_COPY_ELISION=BUILT \
 TENSOR_LAST_CONSUMER_SQUARE=BUILT \
 TENSOR_TOLERANT_EXACT_DOUBLE=BUILT \
 TENSOR_BASE_PROFILE_PHYSICAL_REALITY=BUILT \
 TENSOR_WIDE_PROFILE_PHYSICAL_REALITY=BUILT \
 TENSOR_NATIVE256_HISTORICAL_AUTHORITY=PRESERVED \
 DEAD_PERSISTENT_FACT_POLICY=reject-without-future-consumer \
 RESOURCE_RECIPIENT_SELECTION=0 \
 RUNTIME_FACT_MANAGER=0 \
 RUNTIME_RESIDENCY_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 STRICT_FP_REASSOCIATION=0 \
 WHEELCHAIR_1_3_7_BUILD=PASS
do grep -q "^$m$" "$T/build.log"; done
echo 'TENSOR_PHYSICAL_REALITY_BUILD_AUTHORITY=PASS'

S=compiler/tensor_frontend_137_x86_64.S
grep -q '^tensor137_analyze_expr:' "$S"
grep -q '^tensor137_binding_cache_profitable:' "$S"
grep -q '^tensor137_profile_affine_coeff:' "$S"
grep -q '^tensor137_select_induct_facts:' "$S"
grep -q '^tensor137_profile_constant:' "$S"
grep -q '^tensor137_select_constant_facts:' "$S"
grep -q 'T137_PROFILE_BASE' "$S"
grep -q 'T137_CACHE_COUNT-2' "$S"
grep -q 'last-consumer square' "$S"
grep -q 'tolerant exact-doubling' "$S"
if grep -Eqi '\b(fluid|solid|fsi)\b' "$S" compiler/physical_reality_137.inc; then
  echo 'FSI_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'GENERIC_TENSOR_FACT_SOURCE_AUTHORITY=PASS'
echo 'NO_FSI_SPECIALIZATION=PASS'

# Same semantics through both native512 physical budgets.
J=benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
for C in topologyc topologyc-wide; do
  build/$C "$J" -o "$T/$C" --executors 1 >/dev/null
  a=$($T/$C 4)
  b=$($T/$C 100000)
  [ "$a" = 'checksum_bits=0x3fb2acf007b0d71c' ]
  [ "$b" = 'checksum_bits=0x40c5a457a3a332ad' ]
done
cmp_out_a=$($T/topologyc 31)
cmp_out_b=$($T/topologyc-wide 31)
[ "$cmp_out_a" = "$cmp_out_b" ]
echo 'BASE_WIDE_TENSOR_SEMANTIC_EQUIVALENCE=PASS'

# Native256 remains truthful and semantically equivalent on the probe.
build/topologyc-wide-native256 "$J" -o "$T/native256" --executors 1 >/dev/null
[ "$($T/native256 31)" = 'checksum_bits=0x3ffcc9e1ef653b1c' ]
echo 'TENSOR_NATIVE256_HISTORICAL_AUTHORITY=PRESERVED'

# Machine-code pressure gate. The probe is diagnostic only; compiler source has
# no probe name. Count the whole generated RX payload so boundary/general bodies
# cannot hide expensive integer multiplication or copy formation.
line=$(readelf -lW "$T/topologyc-wide" | grep 'LOAD.*R E' | tail -n 1)
set -- $line
off=$2
sz=$5
dd if="$T/topologyc-wide" of="$T/hot.bin" bs=1 skip=$((off)) count=$((sz)) status=none
objdump -D -b binary -m i386:x86-64 -M intel --insn-width=32 "$T/hot.bin" > "$T/hot.S" 2>/dev/null
vpmullq=$(grep -Ec '\bvpmullq\b' "$T/hot.S" || true)
vmov=$(grep -Ec '\bvmovdqa64\b' "$T/hot.S" || true)
bcast=$(grep -Ec '\bvpbroadcastq\b' "$T/hot.S" || true)
[ "$vpmullq" -le 20 ]
[ "$vmov" -le 45 ]
[ "$bcast" -le 60 ]
echo "TENSOR_PROBE_VPMULLQ_SITES=$vpmullq"
echo "TENSOR_PROBE_VMOVDQA64_SITES=$vmov"
echo "TENSOR_PROBE_VPBROADCASTQ_SITES=$bcast"
echo 'TENSOR_MACHINE_WORK_COMPRESSION=PASS'

# Compile-time authority only. No runtime coordinator may appear.
grep -q '^\.equ PR137_RUNTIME_FACT_MANAGER,0$' compiler/physical_reality_137.inc
grep -q '^\.equ PR137_RUNTIME_RESIDENCY_MANAGER,0$' compiler/physical_reality_137.inc
grep -q '^\.equ PR137_RUNTIME_AUTOTUNE,0$' compiler/physical_reality_137.inc
grep -q '^\.equ PR137_GLOBAL_READY_QUEUE,0$' compiler/physical_reality_137.inc
grep -q '^\.equ PR137_WORK_STEALING,0$' compiler/physical_reality_137.inc
grep -q '^\.equ PR137_RESOURCE_RECIPIENT_SELECTION,0$' compiler/physical_reality_137.inc
echo 'NO_RUNTIME_TENSOR_FACT_MANAGER=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_TENSOR_PHYSICAL_REALITY_1_3_7=PASS'
