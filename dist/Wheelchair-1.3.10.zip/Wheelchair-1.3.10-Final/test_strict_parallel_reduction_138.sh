#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair138_strict_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

case "$(cat VERSION)" in 1.3.8|1.3.10) ;; *) exit 1 ;; esac
./build.sh > "$T/build.log" 2>&1
for m in \
 STRICT_PARALLEL_REDUCTION_BIT_IDENTITY=BUILT \
 STRICT_EXACT_REDUCTION_TREE=BUILT \
 STRICT_REDUCTION_SINGLE_EXECUTOR_FALLBACK=0 \
 NATIVE512_STRICT_REDUCTION_REPAIR=BUILT \
 NATIVE256_STRICT_REDUCTION_REPAIR=BUILT \
 DERIVED_STRICT_REDUCTION_REPAIR=BUILT \
 WHEELCHAIR_1_3_8_BUILD=PASS
 do grep -q "^$m$" "$T/build.log"; done
if [ "$(cat VERSION)" = 1.3.10 ]; then
 grep -q '^TOLERANT_REDUCTION_FABRIC_1_3_7=SUPERSEDED_BY_1_3_10_CAUSAL_TREE$' "$T/build.log"
else
 grep -q '^TOLERANT_REDUCTION_FABRIC_1_3_7=PRESERVED$' "$T/build.log"
fi
echo 'STRICT_REDUCTION_BUILD_AUTHORITY=PASS'

# Source authority. 1.3.10 supersedes the split balanced/strict runtimes with
# one canonical causal-work tree. The exact reduction identity remains stronger:
# q1/q2/q4 share the same mathematical tree and differ only in blind capacity
# availability.
if [ "$(cat VERSION)" = 1.3.10 ]; then
  for S in \
   runtime/tensor_runtime_138_x86_64.S \
   runtime/tensor_derived_runtime_138_x86_64.S \
   runtime/tensor_runtime_native256_138_x86_64.S \
   runtime/tensor_derived_runtime_native256_138_x86_64.S
  do
    grep -q '^run_causal_tree:' "$S"
    grep -q '^worker_range:' "$S"
    grep -q '^try_claim_credit:' "$S"
    grep -q '^release_credit:' "$S"
    ! grep -q '^run_tree_strict:' "$S"
    ! grep -q 'g_exec' "$S"
  done
  echo 'STRICT_EXACT_TREE_SOURCE_AUTHORITY=PASS'
else
  for S in \
   compiler/tensor_frontend_138_x86_64.S \
   compiler/tensor_derived_frontend_138_x86_64.S \
   compiler/tensor_frontend_base_native256_138.S \
   compiler/tensor_frontend_wide_native256_138.S \
   compiler/tensor_frontend_derived_native256_138.S
  do
    grep -q '1.3.8 strict reduction repair' "$S"
  done
  for S in \
   runtime/tensor_runtime_138_x86_64.S \
   runtime/tensor_derived_runtime_138_x86_64.S \
   runtime/tensor_runtime_native256_138_x86_64.S \
   runtime/tensor_derived_runtime_native256_138_x86_64.S
  do
    grep -q '^run_tree_strict:' "$S"
    grep -q '^worker_range:' "$S"
  done
  echo 'STRICT_EXACT_TREE_SOURCE_AUTHORITY=PASS'
fi

# No workload name or benchmark-size specialization is allowed in repaired compiler/runtime sources.
if grep -Eqi '\b(fluid|solid|fsi)\b' \
 compiler/tensor_frontend_138_x86_64.S \
 compiler/tensor_derived_frontend_138_x86_64.S \
 compiler/tensor_frontend_base_native256_138.S \
 compiler/tensor_frontend_wide_native256_138.S \
 compiler/tensor_frontend_derived_native256_138.S \
 runtime/tensor_runtime_138_x86_64.S \
 runtime/tensor_runtime_native256_138_x86_64.S; then
 echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'NO_WORKLOAD_SPECIALIZATION=PASS'

# Reuse the historical FSI graph only as a diagnostic probe. The strict contract
# is produced mechanically from the checked-in tolerant probe without changing
# any formula or topology.
SRC=benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
STRICT="$T/fsi_strict.whex"
sed 's/"floating_point":"tolerant"/"floating_point":"strict"/' "$SRC" > "$STRICT"
if cmp -s "$SRC" "$STRICT"; then
  # Human-surface fixture may spell the contract differently; handle that form.
  sed 's/tolerance 1e-8/strict/' "$SRC" > "$STRICT"
fi
# Sanity: strict token/contract must now be present.
grep -Eqi 'strict|"floating_point"[[:space:]]*:[[:space:]]*"strict"' "$STRICT"

# All mature base/wide AVX-512 and AVX2 compiler lanes prove q1=q2=q4 at
# 10M. The previously failing 100M regression is then pinned on the wide lane
# of each ISA; base/wide share the repaired runtime fabric within an ISA.
for C in topologyc topologyc-wide topologyc-native256 topologyc-wide-native256; do
  for q in 1 2 4; do
    build/$C "$STRICT" -o "$T/${C}_q$q" --executors "$q" >/dev/null
  done
  a=$("$T/${C}_q1" 10000000)
  b=$("$T/${C}_q2" 10000000)
  c=$("$T/${C}_q4" 10000000)
  [ "$a" = "$b" ]
  [ "$a" = "$c" ]
done
echo 'STRICT_EXECUTOR_COUNT_BIT_IDENTITY=PASS'
echo 'STRICT_NATIVE512_BIT_IDENTITY=PASS'
echo 'STRICT_NATIVE256_BIT_IDENTITY=PASS'

# Explicitly pin the 100M one-ULP regression on one production wide lane per ISA.
for C in topologyc-wide topologyc-wide-native256; do
  for q in 1 2 4; do
    [ "$("$T/${C}_q$q" 100000000)" = 'checksum_bits=0x416522bcff4adb3a' ]
  done
done
echo 'STRICT_100M_ONE_ULP_REGRESSION=FIXED'

# 1.3.10 deliberately retires the historical balanced tolerant partition.
# Tolerant execution now uses the same canonical causal work tree, so capacity
# changes cannot alter which reduction nodes exist. This is stronger structural
# determinism; it is not a route through a q1 worker fallback.
for q in 1 2 4; do
  build/topologyc-wide "$SRC" -o "$T/tol_q$q" --executors "$q" >/dev/null
done
if [ "$(cat VERSION)" = 1.3.10 ]; then
  [ "$("$T/tol_q1" 10000000)" = 'checksum_bits=0x4130e896f42e1d94' ]
  [ "$("$T/tol_q2" 10000000)" = 'checksum_bits=0x4130e896f42e1d94' ]
  [ "$("$T/tol_q4" 10000000)" = 'checksum_bits=0x4130e896f42e1d94' ]
  [ "$("$T/tol_q1" 100000000)" = 'checksum_bits=0x416522bcff4adae6' ]
  [ "$("$T/tol_q2" 100000000)" = 'checksum_bits=0x416522bcff4adae6' ]
  [ "$("$T/tol_q4" 100000000)" = 'checksum_bits=0x416522bcff4adae6' ]
  echo 'TOLERANT_CANONICAL_CAUSAL_TREE_1_3_10=PASS'
else
  [ "$("$T/tol_q1" 10000000)" = 'checksum_bits=0x4130e896f42e1d94' ]
  [ "$("$T/tol_q2" 10000000)" = 'checksum_bits=0x4130e896f42e1d94' ]
  [ "$("$T/tol_q4" 10000000)" = 'checksum_bits=0x4130e896f42e1d94' ]
  [ "$("$T/tol_q4" 100000000)" = 'checksum_bits=0x416522bcff4adae7' ]
  echo 'TOLERANT_1_3_7_REDUCTION_AUTHORITY=PRESERVED'
fi

# Structural anti-serialization audit. Strict q>1 must enter clone-based exact
# subtrees, not change executor_count_patch to one or add a root reduction sweep.
for S in runtime/tensor_runtime_138_x86_64.S runtime/tensor_runtime_native256_138_x86_64.S; do
  grep -q 'SYS_clone' "$S"
  if [ "$(cat VERSION)" = 1.3.10 ]; then grep -q '^try_claim_credit:' "$S"; else grep -q 'Parent immediately' "$S"; fi
  ! grep -Eqi 'work[ -]?steal|global ready queue|recipient selection|root serial reduction' "$S"
done
echo 'STRICT_TRUE_PARALLEL_FABRIC=PRESERVED'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_STRICT_PARALLEL_REDUCTION_1_3_8=PASS'
