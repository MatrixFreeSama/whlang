#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.7|1.3.8|1.3.10) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_137.log 2>&1
for marker in \
 WHEELCHAIR_1_3_6_BUILD=PASS \
 WHEELCHAIR_1_3_7_BUILD=PASS \
 TENSOR_GLOBAL_PHYSICAL_REALITY=BUILT \
 TENSOR_REACHABLE_USE_GRAPH=BUILT \
 TENSOR_DEMAND_CAUSAL_LIFETIME=BUILT \
 TENSOR_CROSS_SUBTREE_VALUEFACT=BUILT \
 TENSOR_AFFINE_FACT_PROFILING=BUILT \
 TENSOR_AFFINE_INDUCTION_PROFITABILITY=BUILT \
 TENSOR_CONSTANT_PROFITABILITY=BUILT \
 TENSOR_THREE_OPERAND_COPY_ELISION=BUILT \
 TENSOR_LAST_CONSUMER_SQUARE=BUILT \
 TENSOR_TOLERANT_EXACT_DOUBLE=BUILT \
 TENSOR_BASE_PROFILE_PHYSICAL_REALITY=BUILT \
 TENSOR_WIDE_PROFILE_PHYSICAL_REALITY=BUILT \
 TENSOR_NATIVE256_HISTORICAL_AUTHORITY=PRESERVED \
 RESOURCE_RECIPIENT_SELECTION=0 \
 RUNTIME_FACT_MANAGER=0 \
 RUNTIME_RESIDENCY_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 STRICT_FP_REASSOCIATION=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
do grep -q "^$marker$" .release_build_137.log; done
echo 'BUILD_1_3_7_AUTHORITY=PASS'

# Every prebuilt image in the package is byte-identical to a clean source build.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# 1.3.6 complete authority, which itself includes 1.3.5 history, remains binding.
./test_release_native_136.sh
echo 'COMPLETE_1_3_6_RELEASE_AUTHORITY_PRESERVED=PASS'
./test_tensor_physical_reality_137.sh

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -Eqi '\b(fluid|solid|fsi)\b' compiler/tensor_frontend_137_x86_64.S compiler/physical_reality_137.inc; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
(cd frozen_native && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
echo 'FROZEN_NATIVE_AUTHORITY=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_7.md \
 RELEASE_NOTES_1_3_7.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_7.md \
 RELEASE_GATES_1_3_7.txt \
 PERFORMANCE_1_3_7_TENSOR_PHYSICAL_REALITY.md \
 test_tensor_physical_reality_137.sh
do test -s "$f"; done

echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_RUNTIME_FACT_MANAGER=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_1_3_7_RELEASE=PASS'
