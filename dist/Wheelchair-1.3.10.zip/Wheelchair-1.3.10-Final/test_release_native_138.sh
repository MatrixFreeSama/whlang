#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = '1.3.8' ]

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_138.log 2>&1
for marker in \
 WHEELCHAIR_1_3_7_BUILD=PASS \
 STRICT_PARALLEL_REDUCTION_BIT_IDENTITY=BUILT \
 STRICT_EXACT_REDUCTION_TREE=BUILT \
 STRICT_REDUCTION_SINGLE_EXECUTOR_FALLBACK=0 \
 TOLERANT_REDUCTION_FABRIC_1_3_7=PRESERVED \
 NATIVE512_STRICT_REDUCTION_REPAIR=BUILT \
 NATIVE256_STRICT_REDUCTION_REPAIR=BUILT \
 DERIVED_STRICT_REDUCTION_REPAIR=BUILT \
 WHEELCHAIR_1_3_8_BUILD=PASS \
 RESOURCE_RECIPIENT_SELECTION=0 \
 RUNTIME_FACT_MANAGER=0 \
 RUNTIME_RESIDENCY_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 STRICT_FP_REASSOCIATION=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
 do grep -q "^$marker$" .release_build_138.log; done
echo 'BUILD_1_3_8_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Preserve the complete 1.3.7 authority, then add the narrow 1.3.8 fix gate.
./test_release_native_137.sh
echo 'COMPLETE_1_3_7_RELEASE_AUTHORITY_PRESERVED=PASS'
./test_strict_parallel_reduction_138.sh

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -Eqi '\b(fluid|solid|fsi)\b' \
 compiler/tensor_frontend_138_x86_64.S \
 compiler/tensor_derived_frontend_138_x86_64.S \
 compiler/tensor_frontend_base_native256_138.S \
 compiler/tensor_frontend_wide_native256_138.S \
 runtime/tensor_runtime_138_x86_64.S \
 runtime/tensor_runtime_native256_138_x86_64.S; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
(cd frozen_native && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
echo 'FROZEN_HISTORICAL_SOURCE_AUTHORITY=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_8.md \
 RELEASE_NOTES_1_3_8.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_8.md \
 PERFORMANCE_1_3_8_STRICT_REDUCTION_REPAIR.md \
 test_strict_parallel_reduction_138.sh
 do test -s "$f"; done

echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_RUNTIME_FACT_MANAGER=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_1_3_8_RELEASE=PASS'
