#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1310_reflow_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

[ "$(cat VERSION)" = 1.3.10 ]
./build.sh > "$T/build.log" 2>&1
for m in \
 LOAD_BALANCING_FAMILY=EXTINCT_FROM_TENSOR_FIELD_PRODUCTION_RUNTIME \
 STATIC_EQUAL_WORK_PARTITION=0 \
 PROPORTIONAL_EXECUTOR_SPLIT=0 \
 EXECUTOR_ID_WORK_TOPOLOGY=0 \
 CAUSAL_WORK_IS_DEMAND_AUTHORITY=1 \
 HARDWARE_WIDTH_IS_ONLY_CEILING=1 \
 ANONYMOUS_SURPLUS_RELEASE=1 \
 BLIND_CAPACITY_CLAIM=1 \
 DISTRIBUTED_CREDIT_CACHELINES=4 \
 GLOBAL_SURPLUS_COUNTER=0 \
 FAILED_CLAIM_SPIN=0 \
 PEER_LOAD_OBSERVATION=0 \
 PEER_WORK_OBSERVATION=0 \
 POST_COMPLETION_WORK_SEARCH=0 \
 RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1 \
 RESOURCE_ACQUISITION_IS_DONOR_BLIND=1 \
 CLAIM_REQUIRES_PREEXISTING_CAUSAL_WORK=1 \
 OCCUPANCY_AS_OPTIMIZATION_TARGET=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_10_BUILD=PASS
 do grep -q "^$m$" "$T/build.log"; done
grep -q '^TOLERANT_REDUCTION_FABRIC_1_3_7=SUPERSEDED_BY_1_3_10_CAUSAL_TREE$' "$T/build.log"
echo 'BLIND_REFLOW_BUILD_AUTHORITY=PASS'

# Production runtime family. Causal work exists before capacity activation.
RUNTIMES="
runtime/tensor_runtime_138_x86_64.S
runtime/tensor_derived_runtime_138_x86_64.S
runtime/tensor_runtime_native256_138_x86_64.S
runtime/tensor_derived_runtime_native256_138_x86_64.S
runtime/field_runtime_512_x86_64.S
runtime/field_runtime_256_x86_64.S
frozen_native/generated_derived/tensor_derived_runtime_template_x86_64.S
frozen_native/generated_native256/tensor_runtime_native256_template_x86_64.S
frozen_native/generated_native256/tensor_derived_runtime_native256_template_x86_64.S
"
for S in $RUNTIMES; do
  grep -q '^run_causal_tree:' "$S"
  grep -q '^try_claim_credit:' "$S"
  grep -q '^release_credit:' "$S"
  grep -q 'g_credit_lines' "$S"
  grep -q 'lock btr' "$S"
  grep -q 'lock bts' "$S"
  grep -q 'cmp r10d,4' "$S" || grep -q 'cmp r10d, 4' "$S"
  ! grep -Eq '^run_tree_strict:|\bg_exec\b' "$S"
done
echo 'CAUSAL_WORK_TOPOLOGY_SOURCE_AUTHORITY=PASS'
echo 'DISTRIBUTED_ANONYMOUS_CREDIT_FABRIC=PASS'

# There may be four bounded probes, never a retry loop that waits for credit.
for S in runtime/tensor_runtime_138_x86_64.S runtime/field_runtime_512_x86_64.S; do
  awk '/^try_claim_credit:/{p=1} /^release_credit:/{p=0} p{print}' "$S" > "$T/claim.S"
  grep -q 'cmp r10d,4' "$T/claim.S" || grep -q 'cmp r10d, 4' "$T/claim.S"
  ! grep -Eqi 'pause|sched_yield|futex|nanosleep' "$T/claim.S"
  awk '/^\.rct_no_credit:|^\.frct_no_credit:/{p=1} /^\.rct_local:|^\.frct_local:/{p=0} p{print}' "$S" > "$T/deeper.S" || true
  grep -q 'call run_causal_tree' "$T/deeper.S"
done
echo 'FAILED_CLAIM_SPIN=0'
echo 'LATER_REAL_CAUSAL_EXPANSION_RECLAIM=PASS'

# Source-wide family extinction: no active equal partition, proportional split,
# executor-ID work tree, or central worker/load authority may reappear.
if grep -R -n -E 'id[[:space:]]*\*[[:space:]]*chunks|run_tree_strict|\bp_left\b|\bg_exec\b' \
  runtime compiler frozen_native --include='*.S' --include='*.inc' > "$T/forbidden" 2>/dev/null; then
  cat "$T/forbidden" >&2; exit 1
fi
if grep -R -n -E 'global_surplus_counter|worker_load\[|queue_length\[|idle_worker_list|busy_worker_list|victim_selection|donor_selection' \
  runtime compiler frozen_native --include='*.S' --include='*.inc' > "$T/forbidden2" 2>/dev/null; then
  cat "$T/forbidden2" >&2; exit 1
fi
echo 'STATIC_EQUAL_WORK_PARTITION=0'
echo 'PROPORTIONAL_EXECUTOR_SPLIT=0'
echo 'PEER_LOAD_AUTHORITY=0'
echo 'GLOBAL_SURPLUS_COUNTER=0'

# Affinity/user width is only a ceiling. Compatibility names may remain in the
# file format, but build authority must explicitly deny hardware-as-demand.
grep -q 'HARDWARE_WIDTH_IS_DEMAND_AUTHORITY=0' "$T/build.log"
grep -q 'AFFINITY_CPU_COUNT_TO_WORKER_DEMAND=0' "$T/build.log"
grep -q 'EXECUTOR_OPTION_SEMANTICS=capacity-ceiling-only' "$T/build.log"
grep -q '^capacity_ceiling_patch:' runtime/tensor_runtime_138_x86_64.S
grep -q '^capacity_ceiling_patch:' runtime/field_runtime_512_x86_64.S
echo 'HARDWARE_WIDTH_IS_ONLY_CEILING=PASS'

# q is a ceiling, not a demand. Tiny Tensor work must remain numerically equal
# even when the compatibility spelling asks for 256 capacity slots.
SRC=tests/whex/strength_probe.whex
build/topologyc "$SRC" -o "$T/q1" --executors 1 >/dev/null
build/topologyc "$SRC" -o "$T/q256" --executors 256 >/dev/null
[ "$("$T/q1" 1)" = "$("$T/q256" 1)" ]
[ "$("$T/q1" 100000)" = "$("$T/q256" 100000)" ]
echo 'CAPACITY_CEILING_DOES_NOT_CREATE_WORK=PASS'

# Canonical FSI reduction tree is independent of capacity availability in both
# contracts. This is a diagnostic graph, not a specialization trigger.
SRC=benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
STRICT="$T/fsi_strict.whex"
sed 's/^tolerance 1e-8$/strict/' "$SRC" > "$STRICT"
for mode in tolerant strict; do
  if [ "$mode" = tolerant ]; then P="$SRC"; expect=0x4130e896f42e1d94; else P="$STRICT"; expect=0x4130e896f42e1dd6; fi
  for q in 1 2 4; do
    build/topologyc-wide "$P" -o "$T/${mode}_q$q" --executors "$q" >/dev/null
    out=$("$T/${mode}_q$q" 10000000)
    [ "$out" = "checksum_bits=$expect" ]
  done
done
echo 'TOLERANT_CAPACITY_INDEPENDENT_CAUSAL_TREE=PASS'
echo 'STRICT_CAPACITY_INDEPENDENT_CAUSAL_TREE=PASS'

# General's futex/arrival fabric is causal waiting, not a worker-balancing
# scheduler. Protect it from future over-broad cleanups.
grep -q 'FUTEX_WAIT' runtime/general_parallel_release_x86_64.S
grep -q 'indegree' runtime/general_parallel_release_x86_64.S
grep -q 'GENERAL_PARALLEL_GLOBAL_READY_QUEUE=0' build.sh
grep -q 'GENERAL_PARALLEL_POST_COMPLETION_WORK_SEARCH=0' build.sh
echo 'GENERAL_CAUSAL_FUTEX_PROTECTED=PASS'

# AOT topology queue and intra-kernel carrier scheduling are likewise protected.
grep -q 'g_topo_queue' compiler/general_frontend_x86_64.S
grep -q 'synthesize_resource_schedule' frozen_native/topologyc_multi_isa_x86_64.S
grep -q 'TOLERANT_FP_MULTI_CARRIER=BUILT' "$T/build.log"
echo 'AOT_TOPOLOGY_QUEUE_PROTECTED=PASS'
echo 'INTRA_KERNEL_ILP_SCHEDULING_PROTECTED=PASS'

# No workload-specific switch is allowed in the production reflow runtime.
if grep -Eqi '\b(fluid|solid|fsi)\b' \
 runtime/tensor_runtime_138_x86_64.S runtime/field_runtime_512_x86_64.S; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'NO_WORKLOAD_SPECIALIZATION=PASS'

echo 'WORK_STEALING=0'
echo 'PUSH_BALANCING=0'
echo 'PULL_BALANCING=0'
echo 'RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1'
echo 'RESOURCE_ACQUISITION_IS_DONOR_BLIND=1'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_BLIND_SURPLUS_REFLOW_1_3_10=PASS'
