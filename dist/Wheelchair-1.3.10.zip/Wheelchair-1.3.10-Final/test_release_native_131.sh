#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

case "$(cat VERSION)" in 1.3.1|1.3.7|1.3.8|1.3.10) ;; *) exit 1 ;; esac
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_131.log 2>&1
for marker in \
 WHEELCHAIR_1_3_1_BUILD=PASS \
 PHYSICAL_TENSOR_REALIZATION=BUILT \
 PHYSICAL_TENSOR_PLAN_FACTS=carriers,episode-width \
 STRICT_FP_PHYSICAL_EPISODE=single-carrier-multibody \
 TOLERANT_FP_MULTI_CARRIER=BUILT \
 FIELD_PHYSICAL_DAG_TRUE_DEPENDENCY=BUILT \
 FIELD_FIXED_RANK_ADDRESS_EPISODES=rank1..8 \
 MACHINE_EMITTER_ARTIFICIAL_SERIAL_EDGE=0 \
 PHYSICAL_REALIZATION_MACHINE_FIDELITY=BUILT \
 REDUNDANT_REMAINING_CMP=0 \
 MAX_RESIDENT_EXECUTORS=256 \
 GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
do grep -q "$marker" .release_build_131.log; done
echo 'BUILD_1_3_1_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

./test_execution_granularity_1212.sh
echo 'HISTORICAL_TENSOR_CAUSAL_GATES=PASS'
./test_neighborhood_semantics_1215.sh
echo 'HISTORICAL_NEIGHBORHOOD_GATES=PASS'
./test_field_native_1216.sh
echo 'HISTORICAL_FIELD_NATIVE_GATES=PASS'
./test_field_locality_1217.sh
echo 'HISTORICAL_FIELD_LOCALITY_GATES=PASS'
./test_field_surface_1218.sh
echo 'HISTORICAL_FIELD_SURFACE_GATES=PASS'
./test_physical_realization_131.sh

T=${TMPDIR:-/tmp}/wheelchair131_release_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
build/wheelchairc tests/general_parallel_126/iterate_probe.wh -o "$T/iterate256" --executors 256 >/dev/null
[ "$("$T/iterate256" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ]
echo 'GENERAL_ITERATE_Q256=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_NEW_RUNTIME_SCHEDULER=PASS'
echo 'STRICT_FP_HISTORICAL_GATES=PASS'
echo 'WH_WHEX_FIELD_ABI_COMPATIBLE=PASS'
echo 'WHEELCHAIR_1_3_1_RELEASE=PASS'
