#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD="$ROOT/build"
FROZEN="$ROOT/frozen_native"
rm -rf "$BUILD"
mkdir -p "$BUILD/generated_derived" "$BUILD/generated_native256"
cd "$ROOT"

# Frozen native physicalizations remain source authority. 1.2.14 preserves
# the tensor runtime lifecycle sources under the manifest; every frozen byte is
# verified before it can enter the production build.
(cd "$FROZEN" && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
cp -a "$FROZEN/generated_derived/." "$BUILD/generated_derived/"
cp -a "$FROZEN/generated_native256/." "$BUILD/generated_native256/"
cp "$FROZEN/topologyc_multi_isa_x86_64.S" "$BUILD/topologyc_multi_isa_x86_64.S"
cp "$FROZEN/tensor_frontend_profile_base.S" "$BUILD/tensor_frontend_profile_base.S"
cp "$FROZEN/tensor_frontend_profile_wide.S" "$BUILD/tensor_frontend_profile_wide.S"

echo 'FROZEN_NATIVE_ASSEMBLY_SHA256=PASS'
echo 'PRODUCTION_BUILD_PYTHON_GENERATORS=0'

# Mature native-512 runtime remains the protected physical peak.
as --64 runtime/tensor_runtime_template_x86_64.S -o "$BUILD/tensor_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_template.o" -o "$BUILD/tensor_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_template" compiler/runtime_offsets.inc

# Mature derived native-512 runtime from frozen authoritative assembly.
as --64 "$BUILD/generated_derived/tensor_derived_runtime_template_x86_64.S" -o "$BUILD/tensor_derived_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_template.o" -o "$BUILD/tensor_derived_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_template" "$BUILD/runtime_derived_offsets.inc"
derived_product_va=$(nm -n "$BUILD/tensor_derived_runtime_template" | awk '$3=="rank_n_product_patch" {print "0x"$1; exit}')
[ -n "$derived_product_va" ]
printf '.equ RUNTIME_RANK_N_PRODUCT_OFF, 0x%x\n' $((derived_product_va-0x400000)) >> "$BUILD/runtime_derived_offsets.inc"

# True AVX2/YMM runtimes, also frozen as source rather than regenerated.
as --64 "$BUILD/generated_native256/tensor_runtime_native256_template_x86_64.S" -o "$BUILD/tensor_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_native256_template.o" -o "$BUILD/tensor_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_native256_template" "$BUILD/runtime_native256_offsets.inc"

as --64 "$BUILD/generated_native256/tensor_derived_runtime_native256_template_x86_64.S" -o "$BUILD/tensor_derived_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_native256_template.o" -o "$BUILD/tensor_derived_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_native256_template" "$BUILD/runtime_derived_native256_offsets.inc"
derived256_product_va=$(nm -n "$BUILD/tensor_derived_runtime_native256_template" | awk '$3=="rank_n_product_patch" {print "0x"$1; exit}')
[ -n "$derived256_product_va" ]
printf '.equ RUNTIME_RANK_N_PRODUCT_OFF, 0x%x\n' $((derived256_product_va-0x400000)) >> "$BUILD/runtime_derived_native256_offsets.inc"

# The freshly derived offsets must remain byte-identical to the frozen proof.
cmp "$BUILD/runtime_derived_offsets.inc" "$FROZEN/runtime_derived_offsets.inc"
cmp "$BUILD/runtime_native256_offsets.inc" "$FROZEN/runtime_native256_offsets.inc"
cmp "$BUILD/runtime_derived_native256_offsets.inc" "$FROZEN/runtime_derived_native256_offsets.inc"

echo 'FROZEN_RUNTIME_OFFSETS_EQUIVALENCE=PASS'

as --64 runtime/general_runtime_template_x86_64.S -o "$BUILD/general_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/general_runtime.ld \
  "$BUILD/general_runtime_template.o" -o "$BUILD/general_runtime_template"
./tools/generate_general_runtime_offsets.sh "$BUILD/general_runtime_template" compiler/general_runtime_offsets.inc

# Recipient-blind causal-region runtime. Offset derivation is shell + native ELF
# symbols only; no Python participates in production build authority.
as --64 runtime/general_parallel_release_x86_64.S -o "$BUILD/general_parallel_release.o"
ld -nostdlib -static -z noexecstack -T runtime/general_parallel_release.ld \
  "$BUILD/general_parallel_release.o" -o "$BUILD/general_parallel_release.elf"
objcopy -O binary --only-section=.text \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin"
sh tools/generate_general_parallel_release_offsets.sh \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin" \
  "$BUILD/general_parallel_release_offsets.json" "$BUILD/general_parallel_release_offsets.inc"
cmp "$BUILD/general_parallel_release_offsets.json" "$FROZEN/general_parallel_release_offsets.json"

echo 'GENERAL_PARALLEL_RELEASE_OFFSETS_NO_PYTHON=PASS'

# Shared handwritten sovereign topology core with physical-shape capability algebra.
as --64 "$BUILD/topologyc_multi_isa_x86_64.S" -o "$BUILD/topologyc_core.o"
as --64 compiler/general_frontend_x86_64.S -o "$BUILD/general_frontend.o"
as --64 compiler/general_runtime_blob_x86_64.S -o "$BUILD/general_runtime_blob.o"
as --64 compiler/general_parallel_release_blob_x86_64.S -o "$BUILD/general_parallel_release_blob.o"
as --64 compiler/surface_lowerer_x86_64.S -o "$BUILD/surface_lowerer.o"

# Native/split 512 physicalizers.
as --64 "$BUILD/tensor_frontend_profile_base.S" -o "$BUILD/tensor_frontend_base.o"
as --64 "$BUILD/tensor_frontend_profile_wide.S" -o "$BUILD/tensor_frontend_wide.o"
as --64 compiler/runtime_blob_x86_64.S -o "$BUILD/runtime_blob.o"

# 1.2.17 sovereign native field lane.  This extends the separate direct-native AOT
# physicalization so the protected 1.2.15 f64 tensor path remains byte-authoritative.
# The field lane is pure handwritten assembly and maps materialized WHFLD216
# fields directly; it never routes through C, LLVM, JIT, Python, or a bytecode
# interpreter.
as --64 runtime/field_runtime_512_x86_64.S -o "$BUILD/field_runtime_512.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_512.o" -o "$BUILD/field_runtime_512_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_512_offsets.inc"

as --64 runtime/field_runtime_256_x86_64.S -o "$BUILD/field_runtime_256.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_256.o" -o "$BUILD/field_runtime_256_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_256_template" "$BUILD/field_runtime_256_offsets.inc"

as --64 compiler/field_runtime_blob_512_x86_64.S -o "$BUILD/field_runtime_blob_512.o"
as --64 compiler/field_runtime_blob_256_x86_64.S -o "$BUILD/field_runtime_blob_256.o"
as --64 compiler/field_frontend_512_x86_64.S -o "$BUILD/field_frontend_512.o"
as --64 compiler/field_frontend_256_x86_64.S -o "$BUILD/field_frontend_256.o"
as --64 compiler/fieldc_driver_x86_64.S -o "$BUILD/fieldc_driver.o"
as --64 compiler/field_parser_link_stubs_x86_64.S -o "$BUILD/field_parser_link_stubs.o"

# Reuse only the frozen handwritten JSON parser symbols from the mature tensor
# frontend.  Unreachable tensor-only parser link references are satisfied by
# compile-time stubs; no tensor scheduler/runtime is entered by fieldc.
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_512.o" \
  "$BUILD/tensor_frontend_base.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_512.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc"
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_256.o" \
  "$BUILD/tensor_frontend_base.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_256.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_base.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_wide.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-wide"
as --64 "$BUILD/generated_derived/tensor_derived_frontend_x86_64.S" -o "$BUILD/tensor_frontend_derived.o"
as --64 "$BUILD/generated_derived/runtime_derived_blob_x86_64.S" -o "$BUILD/runtime_derived_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_derived.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived"

# Native256 physicalizers for every generic graph-resource class.
as --64 "$BUILD/generated_native256/tensor_frontend_base_native256.S" -o "$BUILD/tensor_frontend_base_native256.o"
as --64 "$BUILD/generated_native256/tensor_frontend_wide_native256.S" -o "$BUILD/tensor_frontend_wide_native256.o"
as --64 "$BUILD/generated_native256/tensor_frontend_derived_native256.S" -o "$BUILD/tensor_frontend_derived_native256.o"
as --64 "$BUILD/generated_native256/runtime_native256_blob_x86_64.S" -o "$BUILD/runtime_native256_blob.o"
as --64 "$BUILD/generated_native256/runtime_derived_native256_blob_x86_64.S" -o "$BUILD/runtime_derived_native256_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_base_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_wide_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-wide-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_derived_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived-native256"

# Native production launchers.  The driver performs only compile-time structural
# classification (base/wide/derived from canonical structure); it never retries a failed compiler
# and never inspects workload names.
as --64 compiler/native_driver_x86_64.S -o "$BUILD/native_driver.o"
ld -nostdlib -static -z noexecstack "$BUILD/native_driver.o" "$BUILD/surface_lowerer.o" -o "$BUILD/wheelchairc"
cp "$BUILD/wheelchairc" "$BUILD/whexc"

for f in \
  "$BUILD/topologyc" "$BUILD/topologyc-wide" "$BUILD/topologyc-derived" \
  "$BUILD/topologyc-native256" "$BUILD/topologyc-wide-native256" "$BUILD/topologyc-derived-native256" \
  "$BUILD/tensor_runtime_template" "$BUILD/tensor_derived_runtime_template" \
  "$BUILD/tensor_runtime_native256_template" "$BUILD/tensor_derived_runtime_native256_template" \
  "$BUILD/general_runtime_template" "$BUILD/general_parallel_release.elf" \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_256_template" \
  "$BUILD/fieldc" "$BUILD/fieldc-native256" \
  "$BUILD/wheelchairc" "$BUILD/whexc"; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# Production build closure must not invoke Python. Python remains allowed only
# in reference/validation tooling while the human surface is being migrated.
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'Python invocation leaked into production build' >&2; exit 1
fi

echo 'GENERIC_PRODUCT_SUBTRACT_CONTRACTION=BUILT'
echo 'GENERIC_VECTOR_REDUCTION_RESIDENCY=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_BASE=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_WIDE=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_DERIVED=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_WORKLOAD_DISPATCH=0'
echo 'NATIVE_RESOURCE_PROFILE_RUNTIME_SELECTOR=0'
echo 'MULTI_ISA_TOPOLOGYC=BUILT'
echo 'PHYSICAL_VECTOR_SHAPES=native256,split512x256,native512'
echo 'NATIVE256_BASE=BUILT'
echo 'NATIVE256_WIDE=BUILT'
echo 'NATIVE256_DERIVED=BUILT'
echo 'NATIVE256_SCALAR_FALLBACK=0'
echo 'PHYSICAL_VECTOR_PROFILE_WORKLOAD_DISPATCH=0'
echo 'PHYSICAL_VECTOR_RUNTIME_PROFITABILITY_SELECTOR=0'
echo 'GENERAL_PARALLEL_BLIND_RELEASE_ENGINE=BUILT'
echo 'GENERAL_PARALLEL_FABRIC_AUTHORITY=blind-release-program-slot'
echo 'GENERAL_PARALLEL_GLOBAL_READY_QUEUE=0'
echo 'GENERAL_PARALLEL_ROOT_SCHEDULER=0'
echo 'GENERAL_PARALLEL_RUNTIME_COST_SELECTOR=0'
echo 'GENERAL_PARALLEL_SERIAL_FALLBACK=0'
echo 'GENERAL_PARALLEL_RUNTIME_FIXED_HOME_OWNERSHIP=0'
echo 'GENERAL_PARALLEL_PERSISTENT_IDLE_WORKER_SPIN=0'
echo 'GENERAL_PARALLEL_POST_COMPLETION_WORK_SEARCH=0'
echo 'GENERAL_PARALLEL_POST_COMPLETION_PEER_QUERY=0'
echo 'GENERAL_PARALLEL_RESOURCE_RELEASE_DESTINATION=0'
echo 'GENERAL_PARALLEL_RESOURCE_HANDOFF=0'
echo 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS'
echo 'ACTIVE_SPECIAL_PURPOSE_NATIVE_ROUTE=0'
echo 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0'
echo 'PRODUCTION_NATIVE_LAUNCHERS=BUILT'
echo 'TENSOR_INVOCATION_STACK_ARENA=BUILT'
echo 'TENSOR_RECURSIVE_STACK_MMAP=0'
echo 'TENSOR_RECURSIVE_STACK_MUNMAP=0'
echo 'CAUSAL_MESH_COARSENING=BUILT'
echo 'CAUSAL_WIDTH_PRESERVATION_GATE=BUILT'
echo 'ADAPTIVE_EXECUTION_GRANULARITY=BUILT'
echo 'WHEELCHAIR_1_2_14_FROZEN_ASSEMBLY_BUILD=PASS'
echo 'WHEELCHAIR_1_2_14_NATIVE_PROFILE_SELECTOR=BUILT'
echo 'EXECUTION_REPRESENTATION_COMPRESSION=BUILT'
echo 'DENSE_RANKN_COORDINATE_INDUCTION=BUILT'
echo 'DENSE_RANKN_COALESCED_AXIS_CARRY=BUILT'
echo 'NO_NEGATIVE_STRUCTURAL_COMPRESSION=BUILT'
echo 'DERIVED_AFFINE_INDUCTION=BUILT'
echo 'CROSS_AXIS_LICM=BUILT'
echo 'DENSE_STATIC_INNER_UNROLL=BUILT'
echo 'DELAYED_ZMM_REDUCTION=BUILT'
echo 'BOUNDARY_IDENTITY_ELIMINATION=BUILT'
echo 'PROVEN_ZERO_TAIL_ELIMINATION=BUILT'
echo 'RANKN_LIFETIME_REGISTER_REUSE=BUILT'
echo 'DENSE_CARETAKER_OPTIMIZATION_1_2_14=BUILT'
echo 'WHEELCHAIR_BUILD=PASS'
# 1.2.15 capability markers. Historical 1.2.14 markers above remain for
# regression gates and do not imply an old release version.
echo 'RANKN_COORDINATE_ALGEBRA_1_2_15=BUILT'
echo 'RANKN_AFFINE_NEIGHBORHOOD_GATHER=BUILT'
echo 'RANKN_PERIODIC_PHYSICAL_RING_LOWERING=BUILT'
echo 'RANKN_PHYSICAL_DOMAIN_PROOFS=BUILT'
echo 'RANKN_NEIGHBORHOOD_NATIVE256_EQUIVALENCE=BUILT'
echo 'WHEELCHAIR_1_2_15_BUILD=PASS'

echo 'NATIVE_FIELD_ABI_1_2_16=BUILT'
echo 'RANKN_F32_NATIVE512=BUILT'
echo 'RANKN_F32_NATIVE256=BUILT'
echo 'MULTI_DYNAMIC_EXTENTS_FIELD=BUILT'
echo 'GENERAL_CONST_INTEGER_DIVMOD=BUILT'
echo 'FIELD_NOALIAS_CONTRACT=BUILT'
echo 'FIELD_INOUT_MODE=BUILT'
echo 'FIELD_INTERPRETER=0'
echo 'FIELD_SCALAR_FALLBACK=0'
echo 'FIELD_C_LLVM_JIT_BACKEND=0'
echo 'WHEELCHAIR_1_2_16_BUILD=PASS'

# 1.2.17 generic field-locality caretaker layer. No source/ABI change.
echo 'FIELD_LOAD_IDENTITY_ALGEBRA_1_2_17=BUILT'
echo 'NEIGHBORHOOD_COORDINATE_CSE_1_2_17=BUILT'
echo 'INPUT_LAYOUT_EQUIVALENCE_PROOF_1_2_17=BUILT'
echo 'DYNAMIC_POW2_ADDRESS_STRENGTH_REDUCTION_1_2_17=BUILT'
echo 'REUSE_WEIGHTED_FIELD_RESIDENCY_1_2_17=BUILT'
echo 'FIELD_VERSION_SAFE_CACHE_1_2_17=BUILT'
echo 'FIELD_LOCALITY_WORKLOAD_DISPATCH=0'
echo 'FIELD_LOCALITY_RUNTIME_READY_QUEUE=0'
echo 'FIELD_LOCALITY_WORK_STEALING=0'
echo 'WHEELCHAIR_1_2_17_BUILD=PASS'

# 1.2.18 human Field surface completion.  WH/WHEX materialized-field syntax is
# compile-time only and erases into the unchanged wheelchair.field/1 canonical
# graph before the 1.2.17 locality backend.  No new runtime or ABI layer exists.
echo 'NATIVE_FIELD_HUMAN_SURFACE_1_2_18=BUILT'
echo 'WH_WHEX_FIELD_BRIDGE_1_2_18=BUILT'
echo 'PURE_FN_LEXICAL_SCOPE_1_2_18=BUILT'
echo 'FIELD_SURFACE_NEW_RUNTIME_LAYER=0'
echo 'FIELD_SURFACE_CANONICAL_FORMAT=wheelchair.field/1'
echo 'FIELD_SURFACE_ABI=WHFLD216'
echo 'WHEELCHAIR_1_2_18_BUILD=PASS'

# 1.3.0 structure-preserving physical realization.  The language remains AOT,
# direct-native and scheduler-free at runtime: Physical-DAG planning is a
# compiler-only stage immediately before ISA selection/encoding.
echo 'PHYSICAL_DAG_TENSOR_TWO_PASS=BUILT'
echo 'PHYSICAL_DAG_FIELD_PLAN=BUILT'
echo 'AUTOMATIC_RANKN_EXECUTION_TENSOR=BUILT'
echo 'TENSOR_EPISODE_UNIT=whole-fused-rankn-chunk'
echo 'SCHEDULER_BEFORE_CANONICAL_CODEGEN=PASS'
echo 'SCHEDULER_PLAN_RUNTIME_CLOSURE=PASS'
echo 'POST_CODEGEN_SCHEDULE_OVERRIDE=0'
echo 'SEMANTIC_ISA_OVERRIDE=BUILT'
echo 'DIRECT_MACHINE_ENCODING=PRESERVED'
echo 'MAX_RESIDENT_EXECUTORS=256'
echo 'DEFAULT_EXECUTOR_GEOMETRY=affinity-capped-auto'
echo 'EMPTY_EXECUTOR_LEAVES=ERASED'
echo 'GENERAL_CAUSAL_RUNTIME_NODE_CAPACITY=256'
echo 'GENERAL_PARALLEL_WIDTH_2_256=BUILT'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'WHEELCHAIR_1_3_0_BUILD=PASS'

# 1.3.1 physical-realization completion.  Physical-DAG relations must survive
# into real independent machine recurrence chains.  Strict FP order remains a
# separate physical contract from tolerant multi-carrier realization.
echo 'PHYSICAL_TENSOR_REALIZATION=BUILT'
echo 'PHYSICAL_TENSOR_PLAN_FACTS=carriers,episode-width'
echo 'STRICT_FP_PHYSICAL_EPISODE=single-carrier-multibody'
echo 'TOLERANT_FP_MULTI_CARRIER=BUILT'
echo 'FIELD_PHYSICAL_DAG_TRUE_DEPENDENCY=BUILT'
echo 'FIELD_FIXED_RANK_ADDRESS_EPISODES=rank1..8'
echo 'MACHINE_EMITTER_ARTIFICIAL_SERIAL_EDGE=0'
echo 'PHYSICAL_REALIZATION_MACHINE_FIDELITY=BUILT'
echo 'WHEELCHAIR_1_3_1_BUILD=PASS'
echo 'REDUNDANT_REMAINING_CMP=0'

# Wheelchair 1.3.2 Physical Memory Causality authority.
# Writable storage follows causal ownership instead of packed shared-address
# convenience. These markers are validated structurally and dynamically by
# test_physical_memory_132.sh before release.
echo 'PHYSICAL_MEMORY_DAG=BUILT'
echo 'MUTABLE_LAYOUT_INJECTIVITY=BUILT'
echo 'WRITABLE_CACHELINE_GEOMETRY_PROOF=BUILT'
echo 'GENERAL_CAUSAL_NODE_PAGE_ISOLATION=4096'
echo 'GENERAL_CAUSAL_ARRIVAL_COUNT=BUILT'
echo 'GENERAL_MUTABLE_MAILBOX_PAGE_ISOLATION=4096'
echo 'CHILD_RESULT_PRIVATE_OWNERSHIP=BUILT'
echo 'NUMA_NODE_LOCALIZATION=best-effort-getcpu-mbind'
echo 'MEMORY_ISA_OVERRIDE=non-temporal-pure-output'
echo 'SINGLE_TOUCH_CAUSAL_TRANSFER=BUILT'
echo 'CENTRAL_MEMORY_SCHEDULER=0'
echo 'WHEELCHAIR_1_3_2_BUILD=PASS'
# Wheelchair 1.3.3 Causal Physical Optimization authority.
# Equivalent arithmetic and memory realizations are chosen only from generic
# structural/legal facts. No workload-name route, JIT, runtime autotune loop,
# or central optimizer participates in the hot path.
echo 'PHYSICAL_OPTIMIZATION_GRAPH=BUILT'
echo 'TOLERANT_SHARED_FACTOR_FUSION=BUILT'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'FMA_SUBGRAPH_COVER=BUILT'
echo 'FUSION_WIDTH_COLLAPSE=0'
echo 'ADDRESS_CSE_1_3_3=INHERITED_AND_AUDITED'
echo 'LOAD_IDENTITY_REUSE_1_3_3=INHERITED_AND_AUDITED'
echo 'TARGET_CACHE_CAPACITY_QUERY=CPUID_LEAF4'
echo 'CAUSAL_MEMORY_PROFITABILITY=BUILT'
echo 'RANDOM_READ_PRESSURE_MODEL=BUILT'
echo 'SMALL_OUTPUT_NT_HEURISTIC=REMOVED'
echo 'NT_POLICY_UNIT=physical-bytes-vs-cache-geometry'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'BENCHMARK_DISPATCH=0'
echo 'CENTRAL_OPTIMIZER_RUNTIME=0'
echo 'USELESS_PREFETCH_POLICY=do-not-emit-without-proof'
echo 'WHEELCHAIR_1_3_3_BUILD=PASS'

# Wheelchair 1.3.4 Physical Regularity Collapse authority.
# Proven Rank-N regularity becomes the machine address form itself. Generic
# gather remains only as truthful boundary/irregular fallback. Tolerant factor
# supernodes receive a width-preserving FMA cover; strict FP order is sovereign.
echo 'PHYSICAL_REGULARITY_COLLAPSE=BUILT'
echo 'PHYSICAL_STRIDE_SIGNATURE=BUILT'
echo 'REGULAR_NEIGHBORHOOD_INTERIOR=BUILT'
echo 'FIXED_DISPLACEMENT_VECTOR_LOAD=BUILT'
echo 'PHYSICAL_SIMD_AXIS_SELECTION=contiguous-innermost-proven'
echo 'ISA_ADDRESS_MODE_COVER=base+q*4+signed-delta'
echo 'NEIGHBORHOOD_LOAD_IDENTITY=INHERITED_AND_AUDITED'
echo 'WIDE_FACTOR_FMA_COVER=BUILT'
echo 'FMA_WIDTH_PRESERVATION=BUILT'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'GENERIC_GATHER_FALLBACK=PRESERVED'
echo 'IRREGULAR_GATHER_PRESERVATION=BUILT'
echo 'FIELD_PHYSICAL_OWNERSHIP_PRESERVED=PASS'
echo 'MEMORY_PROFITABILITY_1_3_3_PRESERVED=PASS'
echo 'NO_FEM_SPECIAL_CASE=PASS'
echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_LOOKUP_OPTIMIZATION=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'WHEELCHAIR_1_3_4_BUILD=PASS'

# Wheelchair 1.3.5 Physical Realization Uniqueness authority.
# A still-valid physical fact must be consumed rather than recreated merely for
# emitter convenience. Identity/residency decisions are compile-time only.
echo 'PHYSICAL_REALIZATION_UNIQUENESS=BUILT'
echo 'PHYSICAL_FACT_IDENTITY=BUILT'
echo 'PHYSICAL_FACT_IDENTITY_KEY=ordered-access-id+exact-f32-bits'
echo 'PHYSICAL_FACT_REUSE_PROFITABILITY=BUILT'
echo 'DEMAND_CAUSAL_MATERIALIZATION=BUILT'
echo 'CROSS_CONSUMER_FACT_SHARING=BUILT'
echo 'IMMUTABLE_CONSTANT_IDENTITY=BUILT'
echo 'HOT_CONSTANT_REGISTER_RESIDENCY=native256'
echo 'DIRECT_MATERIAL_MEMORY_OPERAND=native256'
echo 'ADDRESS_FACT_UNIQUENESS=BUILT'
echo 'AVX2_FULL_YMM_BANK=BUILT'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'MEMORY_PROFITABILITY_1_3_3_PRESERVED=PASS'
echo 'PHYSICAL_REGULARITY_1_3_4_PRESERVED=PASS'
echo 'RUNTIME_RESIDENCY_MANAGER=0'
echo 'RUNTIME_AUTOTUNE_LOOP=0'
echo 'BENCHMARK_RESIDENCY_DISPATCH=0'
echo 'WORK_STEALING=0'
echo 'WHEELCHAIR_1_3_5_BUILD=PASS'
