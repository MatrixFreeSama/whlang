#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
REAL_AS=$(command -v as)
TMP=${TMPDIR:-/tmp}/wheelchair-native-coverage-$$
WORK="$TMP/repo"
HITS="$TMP/hits"
SHIM="$TMP/shim"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$WORK" "$HITS" "$SHIM"
cp -a "$ROOT/." "$WORK/"

cat > "$SHIM/as" <<EOF
#!/bin/sh
exec "$REAL_AS" --gdwarf-5 "\$@"
EOF
chmod +x "$SHIM/as"
(
  cd "$WORK"
  PATH="$SHIM:$PATH" ./build.sh >/dev/null
)

instrument() {
  target=$1
  [ -x "$target" ] || return 0
  mv "$target" "$target.coverage-real"
  cat > "$target" <<'WRAP'
#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
REAL="$0.coverage-real"
if [ "${WHEELCHAIR_COVERAGE_TRACED:-0}" = 1 ]; then
  exec "$REAL" "$@"
fi
export WHEELCHAIR_COVERAGE_TRACED=1
exec python3 "$ROOT/devtrash/coverage/native_coverage.py" trace \
  --root "$ROOT" --hit-dir "$WHEELCHAIR_COVERAGE_DIR" "$REAL" "$@"
WRAP
  chmod +x "$target"
}

export WHEELCHAIR_COVERAGE_DIR="$HITS"
for dir in bin build; do
  for name in wheelchairc whexc fieldc fieldc-native256 topologyc topologyc-derived topologyc-native256 topologyc-derived-native256; do
    instrument "$WORK/$dir/$name"
  done
done

# Coverage reuses existing regression inputs but does not replay the entire
# correctness suite under ptrace. One observation corpus is enough; correctness
# remains the authority of current.list.
(
  cd "$WORK"
  T="$TMP/probes"
  mkdir -p "$T"

  bin/wheelchairc surface/examples/auto_repair_clean.wh -o "$T/clean" >/dev/null
  bin/wheelchairc surface/examples/auto_repair_typos.wh -o "$T/repair" >/dev/null
  bin/wheelchairc devtrash/tests/semantic_convergence_1368/repeated.wh -o "$T/semantic" >/dev/null
  bin/wheelchairc devtrash/tests/execution_form_convergence_1370/naive_two_lag.wh -o "$T/execution" >/dev/null
  bin/wheelchairc devtrash/tests/field_human_shell_1346/compact.wh -o "$T/field-human" >/dev/null
  bin/whexc surface/whex_examples/heat_en.whex -o "$T/expert" >/dev/null

  bin/topologyc-native256 devtrash/tests/whex/strength_probe.whex -o "$T/t256" >/dev/null
  bin/topologyc-derived devtrash/tests/whex/rank6_native_122.whex -o "$T/d512" >/dev/null
  bin/topologyc-derived-native256 devtrash/tests/whex/rank6_native_122.whex -o "$T/d256" >/dev/null
  build/fieldc devtrash/tests/burn_machine_1374/poisson_weighted_tolerant.json -o "$T/f512" >/dev/null
  build/fieldc-native256 devtrash/tests/burn_machine_1374/poisson_weighted_tolerant.json -o "$T/f256" >/dev/null
)

python3 "$WORK/devtrash/coverage/native_coverage.py" report \
  --root "$WORK" --hit-dir "$HITS" \
  --json "$ROOT/NATIVE_COVERAGE_1_3_80.json" \
  --text "$ROOT/NATIVE_COVERAGE_1_3_80.txt"
