#!/usr/bin/env python3
"""Wheelchair native compiler source-line coverage.

Coverage is observed outside the production program with ptrace breakpoints.
The debug build differs only by DWARF line metadata; production source and
machine semantics are not instrumented or rewritten.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import re
import signal
import subprocess
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", message="This process .* is multi-threaded")

libc = ctypes.CDLL(None, use_errno=True)
libc.ptrace.restype = ctypes.c_long

PTRACE_TRACEME = 0
PTRACE_PEEKTEXT = 1
PTRACE_POKETEXT = 4
PTRACE_CONT = 7
PTRACE_SINGLESTEP = 9
PTRACE_GETREGS = 12
PTRACE_SETREGS = 13
PTRACE_SETOPTIONS = 0x4200
PTRACE_O_TRACEEXEC = 0x10
PTRACE_EVENT_EXEC = 4
WORD = ctypes.sizeof(ctypes.c_long)
MASK = (1 << (WORD * 8)) - 1


class Regs(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_ulonglong)
        for name in (
            "r15 r14 r13 r12 rbp rbx r11 r10 r9 r8 rax rcx rdx rsi rdi "
            "orig_rax rip cs eflags rsp ss fs_base gs_base ds es fs gs"
        ).split()
    ]


def ptrace(req: int, pid: int, addr=0, data=0) -> int:
    ctypes.set_errno(0)
    av = ctypes.c_void_p(addr)
    dv = data if not isinstance(data, int) else ctypes.c_void_p(data & MASK)
    result = libc.ptrace(req, pid, av, dv)
    if result == -1 and ctypes.get_errno() != 0:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err))
    return result


def source_inventory(root: Path) -> list[str]:
    files = []
    for base in (root / "compiler", root / "runtime"):
        if not base.is_dir():
            continue
        for path in base.rglob("*"):
            if path.is_file() and path.suffix in (".S", ".inc"):
                files.append(path.relative_to(root).as_posix())
    return sorted(files)


def canonical_source(raw: str, inventory: list[str]) -> str:
    raw = raw.replace("\\", "/")
    if raw in inventory:
        return raw
    # GAS/binutils may print a shortened left edge for long filenames. Match
    # only a unique suffix so the report never guesses between two sources.
    matches = [p for p in inventory if p.endswith(raw) or Path(p).name.endswith(raw)]
    if len(matches) == 1:
        return matches[0]
    base = Path(raw).name
    exact = [p for p in inventory if Path(p).name == base]
    if len(exact) == 1:
        return exact[0]
    return raw


def decoded_lines(exe: Path, root: Path, inventory: list[str]) -> dict[int, set[tuple[str, int]]]:
    try:
        proc = subprocess.run(
            ["objdump", "--dwarf=decodedline", str(exe)],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            check=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return {}
    result: dict[int, set[tuple[str, int]]] = {}
    rx = re.compile(r"^\s*(\S+)\s+(\d+)\s+(0x[0-9a-fA-F]+)\b")
    for text in proc.stdout.splitlines():
        match = rx.match(text)
        if not match:
            continue
        raw, number, address = match.groups()
        if not (raw.endswith(".S") or raw.endswith(".inc")):
            continue
        src = canonical_source(raw, inventory)
        if not (src.startswith("compiler/") or src.startswith("runtime/")):
            continue
        result.setdefault(int(address, 16), set()).add((src, int(number)))
    return result


def current_exe(pid: int) -> Path | None:
    try:
        return Path(os.path.realpath(os.readlink(f"/proc/{pid}/exe")))
    except OSError:
        return None


class OneShotBreakpoints:
    """Break once per machine statement address, then disappear permanently."""

    def __init__(self, pid: int, address_map: dict[int, set[tuple[str, int]]]):
        self.pid = pid
        self.address_map = address_map
        self.active = set(address_map)
        self.original_words: dict[int, int] = {}
        by_word: dict[int, list[int]] = {}
        for address in self.active:
            base = address & ~(WORD - 1)
            by_word.setdefault(base, []).append(address - base)
        for base, offsets in by_word.items():
            original = ptrace(PTRACE_PEEKTEXT, pid, base, 0) & MASK
            self.original_words[base] = original
            patched = original
            for offset in offsets:
                patched = (patched & ~(0xFF << (8 * offset))) | (0xCC << (8 * offset))
            ptrace(PTRACE_POKETEXT, pid, base, patched)

    def remove(self, address: int) -> None:
        base = address & ~(WORD - 1)
        offset = address - base
        current = ptrace(PTRACE_PEEKTEXT, self.pid, base, 0) & MASK
        original_byte = (self.original_words[base] >> (8 * offset)) & 0xFF
        restored = (current & ~(0xFF << (8 * offset))) | (original_byte << (8 * offset))
        ptrace(PTRACE_POKETEXT, self.pid, base, restored)
        self.active.discard(address)


def trace(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    inventory = source_inventory(root)
    hit_dir = Path(args.hit_dir)
    hit_dir.mkdir(parents=True, exist_ok=True)

    pid = os.fork()
    if pid == 0:
        ptrace(PTRACE_TRACEME, 0)
        os.kill(os.getpid(), signal.SIGSTOP)
        os.execv(args.program, [args.program, *args.program_args])

    os.waitpid(pid, 0)
    ptrace(PTRACE_SETOPTIONS, pid, 0, PTRACE_O_TRACEEXEC)
    ptrace(PTRACE_CONT, pid)

    hits: set[tuple[str, int]] = set()
    executables: set[str] = set()
    breakpoints: OneShotBreakpoints | None = None
    rc = 1

    while True:
        _, status = os.waitpid(pid, 0)
        if os.WIFEXITED(status):
            rc = os.WEXITSTATUS(status)
            break
        if os.WIFSIGNALED(status):
            rc = 128 + os.WTERMSIG(status)
            break
        if not os.WIFSTOPPED(status):
            continue

        sig = os.WSTOPSIG(status)
        event = status >> 16
        if sig == signal.SIGTRAP and event == PTRACE_EVENT_EXEC:
            exe = current_exe(pid)
            address_map = {}
            if exe is not None:
                try:
                    rel = exe.resolve().relative_to(root)
                    executables.add(rel.as_posix())
                    address_map = decoded_lines(exe, root, inventory)
                except ValueError:
                    pass
            breakpoints = OneShotBreakpoints(pid, address_map) if address_map else None
            ptrace(PTRACE_CONT, pid)
            continue

        if sig == signal.SIGTRAP and breakpoints is not None:
            regs = Regs()
            ptrace(PTRACE_GETREGS, pid, 0, ctypes.byref(regs))
            address = regs.rip - 1
            if address in breakpoints.active:
                hits.update(breakpoints.address_map[address])
                breakpoints.remove(address)
                regs.rip = address
                ptrace(PTRACE_SETREGS, pid, 0, ctypes.byref(regs))
                ptrace(PTRACE_SINGLESTEP, pid)
                _, step_status = os.waitpid(pid, 0)
                if os.WIFEXITED(step_status):
                    rc = os.WEXITSTATUS(step_status)
                    break
                if os.WIFSIGNALED(step_status):
                    rc = 128 + os.WTERMSIG(step_status)
                    break
                ptrace(PTRACE_CONT, pid)
                continue

        ptrace(PTRACE_CONT, pid, 0, 0 if sig == signal.SIGTRAP else sig)

    record = {
        "hits": sorted(f"{src}:{line}" for src, line in hits),
        "executables": sorted(executables),
        "rc": rc,
    }
    (hit_dir / f"trace-{os.getpid()}.json").write_text(
        json.dumps(record, sort_keys=True) + "\n", encoding="utf-8"
    )
    return rc


def production_compilers(root: Path) -> list[Path]:
    names = (
        "wheelchairc",
        "whexc",
        "fieldc",
        "fieldc-native256",
        "topologyc",
        "topologyc-derived",
        "topologyc-native256",
        "topologyc-derived-native256",
    )
    result = []
    for name in names:
        plain = root / "bin" / name
        traced = root / "bin" / f"{name}.coverage-real"
        if traced.is_file():
            result.append(traced)
        elif plain.is_file():
            result.append(plain)
    return result


def report(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    inventory = source_inventory(root)
    total: set[tuple[str, int]] = set()
    for exe in production_compilers(root):
        for locations in decoded_lines(exe, root, inventory).values():
            total.update(locations)

    hits: set[tuple[str, int]] = set()
    traced_executables: set[str] = set()
    for path in Path(args.hit_dir).glob("trace-*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        traced_executables.update(data.get("executables", []))
        for item in data.get("hits", []):
            src, line = item.rsplit(":", 1)
            hits.add((src, int(line)))
    hits &= total

    by_file: dict[str, list[int]] = {}
    by_hit: dict[str, set[int]] = {}
    for src, line in total:
        by_file.setdefault(src, []).append(line)
    for src, line in hits:
        by_hit.setdefault(src, set()).add(line)

    total_n = len(total)
    hit_n = len(hits)
    percent = (100.0 * hit_n / total_n) if total_n else 0.0
    rows = []
    for src in sorted(by_file):
        den = len(set(by_file[src]))
        num = len(by_hit.get(src, set()))
        rows.append({"source": src, "covered": num, "executable": den, "percent": (100.0*num/den if den else 0.0)})

    payload = {
        "metric": "native-compiler-executable-assembly-line-coverage",
        "covered_lines": hit_n,
        "executable_lines": total_n,
        "percent": round(percent, 2),
        "traced_executables": sorted(traced_executables),
        "sources": rows,
    }
    Path(args.json).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    text = [
        "Wheelchair native compiler coverage",
        "metric=native-compiler-executable-assembly-line-coverage",
        f"covered_lines={hit_n}",
        f"executable_lines={total_n}",
        f"coverage_percent={percent:.2f}",
        f"traced_executable_count={len(traced_executables)}",
        "",
        "source coverage:",
    ]
    for row in rows:
        text.append(f"{row['source']} {row['covered']}/{row['executable']} {row['percent']:.2f}%")
    Path(args.text).write_text("\n".join(text) + "\n", encoding="utf-8")
    print(f"NATIVE_COMPILER_LINE_COVERAGE={percent:.2f}% ({hit_n}/{total_n})")
    return 0 if total_n > 0 and hit_n > 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    p_trace = sub.add_parser("trace")
    p_trace.add_argument("--root", required=True)
    p_trace.add_argument("--hit-dir", required=True)
    p_trace.add_argument("program")
    p_trace.add_argument("program_args", nargs=argparse.REMAINDER)
    p_trace.set_defaults(func=trace)

    p_report = sub.add_parser("report")
    p_report.add_argument("--root", required=True)
    p_report.add_argument("--hit-dir", required=True)
    p_report.add_argument("--json", required=True)
    p_report.add_argument("--text", required=True)
    p_report.set_defaults(func=report)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
