# Architecture aging — 1.3.92

## Before

1.3.91 had exact silicon-domain identity as a placement authority, but Tensor and Field also used that locality proof as the existence proof for execution multiplicity. On a virtualized host where deterministic cache CPUID leaves were hidden, the compiler therefore collapsed an externally admitted multi-CPU machine to one execution context even though the OS still exposed an exact affinity set and cgroup CPU quota.

General had the opposite asymmetry: it consumed the shared outward-lifecycle price, but its native Region materialization did not share the same execution-admission bound as Tensor/Field.

## Aging

1.3.92 separates facts that describe different physics:

```text
external execution admission
    = affinity ∩ finite cgroup CPU quota
    -> bounds native execution multiplicity

silicon locality identity
    = proved cache / NUMA domain relationships
    -> prices placement and transport only
```

Unknown locality no longer destroys independently proved execution capacity. Locality remains conservative: no cache-domain identity is invented when CPUID does not expose it.

Tensor and Field now expose the largest profitable **integer** width bounded by exact admission and real structural work. The historical next-power-of-two executor geometry is deleted.

General consumes the same admission fact. Native Region clones acquire one shared multiplicity slot; when the bound is occupied, the already-live execution continues the ready Region locally. Completion returns only the count. There is no idle-CPU query, recipient, worker pool, ready queue, work stealing, or runtime topology scheduler.

The outward lifecycle price remains one shared target Physical Reality fact for General/Tensor/Field. 1.3.92 does not add benchmark-size or workload-name thresholds.
