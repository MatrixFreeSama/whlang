# Testing — 1.3.92

The current release authority contains **23 tests**.

The new 1.3.92 gate proves:

- external execution admission and silicon locality are distinct authorities;
- finite cgroup CPU quota is admitted as an external capacity fact;
- execution admission is burned into generated Tensor/Field images;
- General/Tensor/Field all consume the execution-admission authority;
- an admitted width of three remains three when the environment permits it;
- power-of-two executor rounding is absent;
- locality-proof failure does not collapse execution admission;
- runtime idle-CPU/resource queries are absent;
- no capacity-ceiling compatibility symbol survives.

All earlier semantic convergence, Field/Tensor structure, Physical DAG, Traffic, StateFact, CoordinateFact, silicon-domain, heterogeneous-edge, fabric target, realization descriptor, and direct fabric activation gates remain active.

The 23 release tests were executed in batches because the complete historical regression corpus exceeds the orchestration window; every listed gate passed individually.
