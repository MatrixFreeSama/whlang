# Wheelchair 1.3.92 release notes

1.3.92 repairs outward expansion by separating execution admission from silicon locality.

- External CPU admission is derived from the process affinity set and any finite cgroup `cpu.max` quota.
- Missing cache-domain identity no longer collapses execution multiplicity to one; locality remains placement/transport information only.
- Tensor and Field no longer round admitted width upward to a power of two. They expose the largest profitable integer width under the shared outward-lifecycle price.
- General now consumes the same execution-admission bound. Native Region materialization uses a shared count only to prevent excess x86 contexts; saturation continues work locally.
- Completion returns multiplicity capacity without recipient selection, idle-resource probing, a worker pool, a ready queue, or work stealing.
- The existing x86+fabric Physical Reality, fabric activation ABI, Field datapath projection, and no-fallback rules remain unchanged.
- No source annotation, parallel DSL, HLS kernel model, fixed PE/tile scheme, benchmark-name route, or source-size threshold was introduced.

On the release host, FSI improves by about 1.70x at 10M and 1.91x at 100M versus 1.3.91 because the existing expansion path is no longer incorrectly disabled. General scalar controls remain noise-level unchanged.
