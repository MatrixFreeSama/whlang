# Wheelchair 1.3.92

![Build](https://img.shields.io/badge/build-23%2F23%20PASS-brightgreen) ![Release](https://img.shields.io/badge/release-1.3.92-blue)

Wheelchair is an HPC- and simulation-first general-purpose AOT language built around Rank-N semantics, matrix-free execution, ValueFacts, StateFacts, AddressFacts, RegionFacts, CoordinateFacts, GroupFact, Physical Reality, Traffic Reality, Silicon Domain Graphs, and Physical DAG execution.

The objective is not occupancy. It is convergence of real physical work toward the mathematical-physical lower bound:

```text
physical work / mathematical-physical lower bound -> 1
```

Idle silicon is valid whenever another materialization costs more than the remaining necessary work.

## 1.3.92: execution admission separated from locality

1.3.91 could prove silicon locality and heterogeneous realization, but one physical distinction was still wrong: failure to prove cache-domain identity could collapse CPU execution multiplicity to one.

1.3.92 separates the two authorities:

```text
execution admission
    = process affinity ∩ finite cgroup CPU quota
    -> how many native executions may coexist

silicon locality
    = proved cache / NUMA domain identity
    -> where work and traffic are cheapest
```

The release host exposes five affinity contexts and a four-CPU cgroup quota, so the compiler closes `execution_admission_capacity = 4` even though its virtualized CPUID interface does not expose deterministic cache identity.

## Structural outward expansion

Tensor and Field consume exact admission directly. Their launch geometry now chooses the largest profitable **integer** width allowed by real work and the shared outward-lifecycle price. The old power-of-two roundup is gone: 3 stays 3, and 5 is never turned into 8 merely to fit a binary executor tree.

General consumes the same admission fact. A ready x86 Region may create another native execution only while the shared admitted count has room. When the bound is occupied, the already-live execution continues that Region locally. Completion returns only the count; it does not name or wake a recipient.

There is still no idle-CPU query, worker pool, ready queue, work stealing, runtime topology scheduler, fixed chunk threshold, or workload-name route.

## Performance

The expansion repair restores a path that 1.3.91 incorrectly disabled on the release host.

| FSI tolerant probe | 1.3.91 | 1.3.92 | 1.3.91 / 1.3.92 | GCC fast |
|---|---:|---:|---:|---:|
| 10M | 22.906 ms | **13.463 ms** | **1.701x** | 15.379 ms |
| 100M | 205.466 ms | **107.321 ms** | **1.915x** | 116.427 ms |

The Wheelchair FSI source declares `tolerance 1e-8`; measured results remain far inside that contract. On this host 1.3.92 is also about 1.14x faster than GCC fast at 10M and 1.08x at 100M.

General `mass3/chem6/rigid7` controls measured over 21 interleaved runs show a geometric-mean `1.3.91/1.3.92 = 1.00320x`, only +0.32% with mixed direction, so the truthful General runtime change is **0% identifiable**.

See `PERFORMANCE_1_3_92.md`.

## Heterogeneous silicon remains one architecture

The x86+fabric work from 1.3.88–1.3.91 remains intact. FPGA is a physical domain, not a source language. Wheelchair still has no `@fpga`, HLS kernel authority, fixed PE grid, fixed tile size, runtime device selector, or second fabric semantic IR. Missing board hardware never authorizes an x86 compatibility fallback.

The current silicon contract is `wheelchair.silicon-reality/9`. A real FPGA board bridge, RTL/place-and-route integration, and bitstream emitter are still absent, so no FPGA hardware speedup is claimed.

## Production toolchain

Production compiler/runtime authority remains handwritten x86-64 assembly and direct static ELF emission. The production build does not use C/C++, Rust, LLVM, MLIR, Python, a JIT, bytecode VM, HLS compiler, or FPGA kernel compiler.

```sh
./build.sh

bin/whexc INPUT.whex -o OUTPUT
bin/wheelchairc INPUT.wh -o OUTPUT
bin/topologyc INPUT.whex -o OUTPUT
bin/fieldc INPUT.json -o OUTPUT
```

## Release authority

The current release gate contains **23 tests**. Production authority remains under `compiler/`, `runtime/`, `surface/`, `tools/`, `build.sh`, and generated `bin/` executables. `devtrash/` contains regression, benchmark, historical, and archaeological material only.

See `ARCHITECTURE_AGING_1_3_92.md`, `EXECUTION_ADMISSION_EXPANSION_1_3_92.md`, `PERFORMANCE_1_3_92.md`, `TESTING_1_3_92.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_92.md`, and `WHEELCHAIR_CHARTER_1_3_92.md`.
