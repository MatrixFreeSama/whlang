# Wheelchair charter — 1.3.92

Wheelchair remains a general-purpose AOT structural language. Parallelism and hardware targets are consequences of Physical Reality, not source sublanguages.

1. Mathematical and causal facts remain semantic authority.
2. Execution admission and locality are different physical facts: admission bounds multiplicity; locality prices placement and transport.
3. External admission may use exact affinity and explicit OS/container quota facts, but never instantaneous idle-resource searches.
4. Unknown locality stays unknown. It cannot erase independently proved causal work or execution capacity.
5. Outward realization must strictly repay its physical lifecycle cost. No source-size or workload-name threshold owns the decision.
6. General, Tensor, and Field share the same multiplicity authority. Saturation continues locally instead of constructing a worker system.
7. Completion releases capacity without recipient identity, work stealing, a ready queue, or ownership transfer.
8. x86 and reconfigurable fabric remain domains of one Physical DAG. No `@fpga`, kernel language, HLS authority, fixed PE/tile model, or second semantic IR is admitted.
9. Optimization remains reduction of necessary physical work toward the mathematical-physical lower bound.
