# Performance — 1.3.92

## Release-host physical facts

The host exposes five schedulable CPU contexts to the process and a finite cgroup quota equal to four CPU-equivalents. Deterministic cache CPUID identity is hidden on this virtualized host.

1.3.92 therefore closes:

```text
execution_admission_capacity = min(5 affinity contexts, 4 quota contexts) = 4
```

without inventing cache locality.

## FSI expansion recovery

The tolerant FSI probe is the workload that exposed the 1.3.91 regression. The 1.3.91 compiler collapsed execution multiplicity to one because cache-domain identity was unavailable. 1.3.92 uses the independently proved admission capacity of four.

Interleaved whole-process measurements on the release host:

| N | 1.3.91 median | 1.3.92 median | 1.3.91 / 1.3.92 | GCC fast median | GFortran fast median |
|---:|---:|---:|---:|---:|---:|
| 10,000,000 | 22.906 ms | **13.463 ms** | **1.701x** | 15.379 ms | 15.980 ms |
| 100,000,000 | 205.466 ms | **107.321 ms** | **1.915x** | 116.427 ms | 120.678 ms |

For these measurements, 1.3.92 is about **1.14x** faster than GCC fast at 10M and **1.08x** faster at 100M. The Wheelchair source declares `tolerance 1e-8`; relative differences from the GCC result are approximately `9.2e-13` at 10M and `5.1e-12` at 100M, inside that contract.

The speedup is not a new FSI fast path. The mathematical body is unchanged; the repaired physical fact allows the existing Tensor frontier to expose the width that the external machine actually admits.

## General whole-episode regression control

Frozen 1.3.91 and final 1.3.92 compiled `mass3`, `chem6`, and `rigid7`. Twenty-one interleaved runs at 20,000,000 steps give:

| Probe | 1.3.91 median | 1.3.92 median | old/new |
|---|---:|---:|---:|
| mass3 | 187.301 ms | 187.271 ms | 1.00016x |
| chem6 | 210.686 ms | 206.189 ms | 1.02181x |
| rigid7 | 300.019 ms | 303.682 ms | 0.98794x |
| geometric mean | | | **1.00320x** |

The probes disagree in direction and the geometric mean is only about +0.32%. It is treated as host noise. Truthful General runtime change: **0% identifiable**.

The final General admission guard changes the generated General image by a small fixed amount but does not add a worker loop or hot-path scheduler.

## FPGA

The release host still has no proved FPGA board bridge, RTL/place-and-route flow, or bitstream. No FPGA hardware speedup is claimed.

Raw data: `devtrash/benchmarks/execution_admission_expansion_1392/`.
