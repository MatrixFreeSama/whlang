# Execution admission and outward expansion — 1.3.92

## One multiplicity authority

The current x86 execution bound is derived from externally imposed machine facts available at compile time:

```text
allowed affinity contexts
        ∩
finite cgroup cpu.max capacity, when present
        =
execution_admission_capacity
```

A missing or unlimited cgroup quota contributes no smaller bound. Wheelchair does not query instantaneous CPU load or search for idle processors.

On the release host the compiler observes:

```text
allowed_execution_contexts = 5
cpu_quota_execution_capacity = 4
execution_admission_capacity = 4
```

The same host hides deterministic cache CPUID leaves, so L1/L2/L3 identity is not proved. In 1.3.91 that lack of locality identity collapsed multiplicity to one. In 1.3.92 it affects placement only.

## Tensor / Field

AOT publishes one structural quantum and its work price. Runtime knows the logical extent and computes the largest profitable integer width not exceeding execution admission or available quanta. For a proposed leaf, necessary work must strictly repay the shared outward lifecycle price.

There is no `next_power_of_two(capacity)`. An admission of 3 can produce 3 ownership regions; 5 is not silently converted into 8.

## General

General uses the same external admission bound. The invocation root is initially one live native execution. An x86 Region may materialize another context only after an atomic admission increment succeeds. When the bound is occupied, that ready Region continues on the current execution. A child returns its count on completion; the invocation root returns its own count before entering `wait4`.

The count is not a work queue or resource owner. It contains no CPU identity and cannot transfer work to another execution.

## Removed failure mode

The old failure chain was:

```text
CPUID cache identity hidden
-> exact locality domain unavailable
-> execution ceiling = 1
-> Tensor/Field outward expansion disabled
```

The new chain is:

```text
locality unknown -> no locality placement claim
external admission still proved -> multiplicity remains available
```

This is a convergence repair, not a new parallel programming model.
