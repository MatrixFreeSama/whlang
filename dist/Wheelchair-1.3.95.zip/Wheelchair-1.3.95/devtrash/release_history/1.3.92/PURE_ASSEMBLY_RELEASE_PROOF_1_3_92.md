# Pure assembly release proof — 1.3.92

Production compiler/runtime authority remains handwritten x86-64 assembly with shell build tooling and linker descriptions.

The production build uses GNU `as`, `ld`, `nm`, `objcopy`, `readelf`, and ordinary shell/text utilities. It does not route user compilation through GCC, Clang, C/C++, Rust, LLVM, MLIR, Python, a JIT, bytecode VM, HLS compiler, or FPGA kernel compiler.

The new cgroup `cpu.max` admission reader and the General/Tensor/Field multiplicity logic are implemented in the existing assembly Physical Reality path. Python appears only in regression/benchmark inspection under `devtrash/`; it is not production authority.

The eight release compiler binaries are static x86-64 ELF executables with no dynamic section.
