# Architecture aging — 1.3.94

1.3.94 removes one more collapsed physical axis.

Previous releases correctly separated execution admission from cache locality, but 1.3.92 still converted cgroup CPU bandwidth into a whole-core-equivalent multiplicity cap. That conversion mixed a temporal budget with a spatial context set.

The current authority is narrower:

```text
causality              -> mathematical execution order
affinity set           -> x86 execution-context multiplicity
cpu.max quota / period -> temporal budget
cache / NUMA identity  -> placement and transport
Traffic Reality        -> movement and total realization cost
issue / dependency     -> recurrence carrier width
```

No compatibility route preserves the retired quota-as-worker-count interpretation. The obsolete `cpu_quota_execution_capacity`, `sd_cpu_quota_capacity`, and quota-capacity reader are deleted from production authority.

The 1.3.92 exact integer leaf geometry remains intact. The compiler does not round five contexts to eight and does not recover performance by oversubscribing the OS. The objective remains minimum necessary physical work, not hardware occupancy.
