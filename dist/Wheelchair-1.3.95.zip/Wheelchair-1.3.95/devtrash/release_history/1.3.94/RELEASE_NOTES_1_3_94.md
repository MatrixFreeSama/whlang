# Wheelchair 1.3.94 release notes

1.3.94 fixes a Physical Reality category error in x86 execution admission.

A finite cgroup `cpu.max` quota was previously divided by its period and treated as an integer execution-context ceiling. That represented a time budget as a spatial context count. The compiler now keeps the exact quota and period as temporal facts while deriving execution multiplicity directly from the externally admitted affinity set.

The silicon contract advances to `wheelchair.silicon-reality/10` / `topology.silicon-audit/10` and replaces `cpu_quota_execution_capacity` with `cpu_quota_usec` and `cpu_period_usec`.

The old power-of-two expansion rule remains absent. There is no runtime idle-capacity query, worker pool, work stealing, ready queue, source-visible parallel DSL route, fixed PE/tile route, or benchmark matcher.

The same-host A/B measured 1.163x on FSI 100M, 1.182x on the lightweight Tensor reduction, 1.194x on dense Rank-3, and 1.148x–1.323x across the retained Field probes. General mature-scalar probes remained continuity-level.
