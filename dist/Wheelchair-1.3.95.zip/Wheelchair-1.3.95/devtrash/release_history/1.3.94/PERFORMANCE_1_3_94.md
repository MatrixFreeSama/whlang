# Performance — 1.3.94

The release comparison was measured as an interleaved same-host 1.3.93 / 1.3.94 A/B before final packaging. Raw data is retained under `devtrash/benchmarks/spatial_temporal_quota_1394/`.

## Parallel structural workloads

| workload | 1.3.93 median | 1.3.94 median | 1.3.93 / 1.3.94 |
|---|---:|---:|---:|
| FSI 100M | 111.050 ms | **95.511 ms** | **1.163x** |
| lightweight Tensor 100M | 10.693 ms | **9.049 ms** | **1.182x** |
| dense Rank-3 | 27.886 ms | **23.352 ms** | **1.194x** |
| miniAMR 7-point | 7.530 ms | **6.557 ms** | **1.148x** |
| miniAMR 27-point | 24.160 ms | **19.784 ms** | **1.221x** |
| miniFE heat21 | 20.365 ms | **16.668 ms** | **1.222x** |
| CloverLeaf x-acceleration | 26.550 ms | **20.068 ms** | **1.323x** |

These gains come from restoring the fifth affinity-proved execution context on the validation host. They do not restore the old `5 -> 8` power-of-two oversubscription behavior.

## General mature-scalar continuity

| workload | 1.3.93 median | 1.3.94 median | movement |
|---|---:|---:|---:|
| mass3 | 182.730 ms | 179.812 ms | +1.6% throughput |
| chem6 | 205.700 ms | 203.025 ms | +1.3% throughput |
| rigid7 | 305.501 ms | 307.048 ms | -0.5% throughput |

The General set remains continuity-level. No scalar benchmark route was added.

## FSI diagnostic boundary

A four-way diagnostic showed that 1.3.79 and 1.3.93 are effectively equal when forced to the same four-leaf geometry. The apparent historical multi-execution regression came from old 1.3.79 rounding five contexts to eight leaves. 1.3.94 does not reintroduce that mechanism.
