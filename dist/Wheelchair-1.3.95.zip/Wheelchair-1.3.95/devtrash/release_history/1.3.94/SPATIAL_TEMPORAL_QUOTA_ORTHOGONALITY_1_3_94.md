# Spatial multiplicity / temporal quota orthogonality — 1.3.94

`cpu.max` and an affinity mask describe different physical axes.

The affinity mask proves which x86 execution contexts are admitted to the process. `cpu.max` describes how much CPU time the cgroup may consume during a quota period. A finite time budget does not prove that an affinity-visible execution context ceases to exist.

1.3.93 collapsed these two facts into one integer:

```text
execution_admission = min(affinity_contexts, floor(quota / period))
```

On the validation host this converted five affinity-proved contexts plus a `400000 / 100000` time budget into four execution contexts. That was a category error.

1.3.94 retains the original facts instead:

```text
affinity set
    -> x86 execution multiplicity

cpu.max quota / period
    -> temporal CPU budget

cache / NUMA identity
    -> locality and transport price
```

All remain Physical Reality facts, but none is allowed to impersonate another axis.

The old power-of-two expansion rule remains deleted. Five admitted contexts produce at most five execution leaves, never eight. There is still no worker pool, ready queue, work stealing, idle-CPU query, runtime device scheduler, source-visible parallel kernel, or benchmark-specific route.

The silicon contract is now `wheelchair.silicon-reality/10` and publishes the exact `cpu_quota_usec` and `cpu_period_usec` values rather than the retired synthetic `cpu_quota_execution_capacity` field.
