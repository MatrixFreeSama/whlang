# Wheelchair charter — 1.3.94

1. Mathematical and physical facts remain distinct until a real law requires them to meet.
2. Traffic prices movement, locality and total realization cost; it does not invent arithmetic dependencies.
3. Issue/dependency facts own recurrence carrier width.
4. The affinity set owns x86 execution-context multiplicity; temporal CPU quota does not impersonate a context count.
5. `cpu.max` remains a quota/period time-budget fact rather than a worker-count selector.
6. Physical Reality remains one authority. Orthogonal physical axes do not become separate optimizers, algorithms, schedulers, or IRs.
7. Execution multiplicity remains distinct from silicon locality.
8. x86 and fabric may coexist in one Physical DAG realization; neither becomes a source-visible kernel world.
9. No benchmark name, fixed problem-size threshold, power-of-two leaf rule, fixed tile, fixed PE count, worker pool, work stealing, runtime idle-resource query, or compatibility backend may select execution semantics.
10. Optimization continues toward minimum necessary physical work, not maximum occupancy.
