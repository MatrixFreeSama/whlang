# Pure assembly release proof — 1.3.94

Production compiler/runtime authority remains handwritten x86-64 assembly and linker descriptions.

Current production source counts:

```text
.S   30
.inc 15
.ld   4
```

All eight production compiler executables are static ELF64 x86-64 binaries with no dynamic section:

```text
fieldc
fieldc-native256
topologyc
topologyc-derived
topologyc-derived-native256
topologyc-native256
wheelchairc
whexc
```

The production build does not use C/C++, Rust, LLVM, MLIR, Python, a JIT, bytecode VM, HLS compiler, or FPGA kernel compiler as a compiler/runtime authority.
