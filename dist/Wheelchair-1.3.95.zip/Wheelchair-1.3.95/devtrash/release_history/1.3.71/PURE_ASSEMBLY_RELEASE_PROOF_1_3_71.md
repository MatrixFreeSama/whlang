# Wheelchair 1.3.71 Pure-Assembly Release Proof

The production compiler/runtime chain remains handwritten x86-64 assembly and shell build tooling. 1.3.71 adds no C/C++/LLVM/JIT backend and no Python production generator.

The changed production authorities are:

- `compiler/field_frontend_common_x86_64.S` - generated-kernel region persistence and boundary-only mask rematerialization;
- `runtime/field_runtime_512_x86_64.S` - native512 generic run-end proof;
- `runtime/field_runtime_256_x86_64.S` - native256 generic run-end proof;
- `tools/generate_field_runtime_offsets.sh` - direct offset publication for `field_regular_run_end`;
- `compiler/physical_reality.inc` - current architectural invariants.

`build.sh` asserts the absence of the retired episode-bool authority and the absence of workload-specific region selectors.
