# Wheelchair 1.3.71 Charter

A fact that has already proved its physical consequence must not be recomputed merely because execution advanced to the next packet.

For Field locality, high-level topology is allowed to exist long enough to prove a direct physical region. Once proved, stable execution retains only the least expensive physical consequence. Axis, Region and periodic-coordinate machinery return only when the physical region actually changes.

This is sparse execution applied to compiler-generated address logic:

`no fact change -> no topology work`.

The law is workload-blind. Problem names never authorize optimization. Fixed geometry thresholds, runtime managers and shadow IRs are prohibited. If a region cannot be proved, the mature general path remains the authority.
