# Wheelchair 1.3.71 Architecture Aging

## Physical Region Fact Sparsification

1.3.71 does not add a stencil optimizer. It ages the existing Field Physical Regularity Collapse so that a proved physical region persists instead of being re-proved for every vector packet.

The old hot path repeatedly asked whether each packet was still inside the same Rank-N periodic interior. That was semantically correct but physically redundant: Axis, Region, periodic topology and full-lane validity had already proved the same direct-address relation and remained unchanged for many consecutive packets.

The current authority is:

```text
Axis / Region / neighborhood facts
        -> one truthful boundary proof
        -> exclusive regular-run end
        -> direct AddressFact consumption while q < run_end
        -> boundary only: rematerialize topology + lane mask
```

The run end is invocation-local and lives in the generated kernel's existing execution state. It is not a runtime manager, table, scheduler, cache service, or second IR. The proof is conservatively confined to the current innermost physical row, so outer coordinates cannot change while the fact is reused. A partial tail is never cached as a full-lane region.

The old boolean authority `field_regular_episode_ok` and `FIELD_RUNTIME_REGULAR_EPISODE_VA` are deleted. Their replacement, `field_regular_run_end`, returns the physical consequence that the generated code actually needs. This is an aging change: less semantic scaffolding survives into the hot path.

## What disappeared from stable regions

Inside a proved direct run, generated code no longer repeats:

- Rank-N coordinate recovery;
- periodic boundary proof;
- q+[lane] coordinate construction;
- active-mask helper calls;
- per-packet topology rematerialization.

A stable run keeps only the direct field base + signed byte delta + flat q relation and a full-lane mask fact. Genuine region boundaries, irregular layouts and partial tails still enter the old general gather/mask authority.

## Explicit non-authorities

There is no Poisson/stencil matcher, fixed extent/rank threshold, per-element address table, second address IR, runtime region manager, JIT/autotune, or workload dispatch. The optimization follows only existing layout, extent, signed neighborhood and Region facts.
