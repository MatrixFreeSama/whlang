# Wheelchair 1.3.71 Performance Note

## 256^3 periodic Poisson hot-path replay

A same-source, same-data regression probe was used only to measure the architectural effect that motivated 1.3.71. It is not a Poisson-specific compiler route.

The probe uses one contiguous 256x256x256 f32 field, six periodic neighbors, the weighted local relation

`q = 6.125*center - xp - xm - yp - ym - zp - zm`

followed by `sum(q*q)`. Both releases use four inherited Field workers and the same CPU affinity. Results are whole-process wall-clock medians from 19 interleaved runs on the release Xeon Platinum 8370C host; shared-host noise is visible, so these numbers are diagnostic rather than portable guarantees.

| Contract | 1.3.70 median | 1.3.71 median | Change |
|---|---:|---:|---:|
| strict | 46.477 ms | 40.601 ms | 1.145x, 12.64% less wall time |
| tolerant/fast | 46.637 ms | 38.792 ms | 1.202x, 16.82% less wall time |

All four binaries produced the same checksum bits `0x4c7ebb65` for this fixture.

The improvement comes from reducing repeated physical work, not changing the arithmetic formula: one regular-run proof now covers many consecutive packets, and stable packets no longer call the q/lane mask constructor. Boundary packets still use the existing general proof/gather machinery.

This does not claim that 1.3.71 has caught top C/Fortran on the earlier Poisson replay. It closes one measured source of overhead while preserving the general Rank-N physical semantics.
