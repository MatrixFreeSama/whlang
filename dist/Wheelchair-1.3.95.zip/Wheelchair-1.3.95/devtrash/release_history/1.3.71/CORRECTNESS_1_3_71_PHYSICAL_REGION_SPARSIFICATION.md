# Wheelchair 1.3.71 Correctness: Physical Region Sparsification

The semantic rule is simple: a previously proved direct-address relation may persist only while every active lane remains inside the same physical region. Crossing the region boundary invalidates the cached physical consequence and re-enters the mature generic topology proof.

The 1.3.71 release gate proves:

- native512 and native256 export the same `field_regular_run_end` authority;
- the old per-packet boolean authority is absent;
- stable regular emission contains no `FIELD_RUNTIME_MASK_VA` rematerialization;
- the boundary/fallback block retains truthful mask and coordinate construction;
- a non-zero 4x4x4 periodic-neighbor oracle produces identical `0x45020000` checksums on native512 and native256;
- the inherited Field suite preserves arbitrary extents, tail masks, inout, noalias, irregular strides and gather fallback;
- the inherited Physical Regularity suite preserves strict/tolerant arithmetic and regular/boundary equivalence.

A run never caches a partial tail as full-lane. For a full packet, the exclusive run end is bounded by both the current innermost row's upper neighborhood margin and the last q that can still contain a complete vector packet inside the invocation range. Therefore `q < run_end` is a sufficient physical proof for direct full-lane execution.

Unproved structure remains on the existing generic path. No approximate topology rewrite is allowed.
