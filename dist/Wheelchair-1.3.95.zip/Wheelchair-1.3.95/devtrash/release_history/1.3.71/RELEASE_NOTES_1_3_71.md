# Wheelchair 1.3.71 Release Notes

1.3.71 introduces no new source syntax and no workload-specific optimizer. It strengthens the existing Field Physical Reality by making proved physical-region facts persistent across unchanged vector packets.

Changes:

- replace per-packet `field_regular_episode_ok` boolean proof with `field_regular_run_end`;
- keep the exclusive direct-region end in invocation-local generated-kernel state;
- skip repeated topology proof while q remains inside that region;
- remove unconditional per-packet q+[lane] / mask construction from stable regular regions;
- publish a full-lane mask directly for complete regular packets;
- rematerialize coordinates/masks only at real region boundaries, irregular-layout fallback or partial tails;
- delete the old `FIELD_RUNTIME_REGULAR_EPISODE_VA` authority rather than retain a compatibility alias;
- preserve native256/native512 generic gather and arbitrary-layout fallback.

Non-features are intentional: no Poisson/stencil matcher, no fixed extent/rank threshold, no per-element address table, no second physical-address IR, no runtime region manager and no autotuner.
