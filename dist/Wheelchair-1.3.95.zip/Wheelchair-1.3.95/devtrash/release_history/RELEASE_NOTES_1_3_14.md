# Wheelchair 1.3.14 Release Notes

## Main change

Wheelchair 1.3.14 is an architecture-consolidation release. It absorbs the scalar causal-transition machinery exposed by 1.3.12/1.3.13 into the existing Rank-N / Versioned Physical Reality / Physical DAG system instead of retaining a second physical backend.

The release follows a merge-and-reuse-first rule: new structures should become facts in the existing architecture before any new private allocator, scheduler, constant bank or backend is considered.

## Consolidated

- General, Tensor and Field now share `compiler/physical_reality_138.inc` as the compiler-wide physical vocabulary.
- Causal scalar state is represented as a Rank-N causal-axis/versioned-state fact.
- 1.3.13 old/new transition generations are absorbed into Versioned Physical Reality.
- the standalone transition-DAG concept is absorbed into the Physical DAG.
- fixed expression-depth `R11..R15` / `XMM11..XMM15` scratch ownership is removed from the active General physical path.
- admitted integer and floating expressions use compile-time lifetime carriers with last-consumer release.
- admitted scalar FP lowering uses three-operand VEX arithmetic.
- floating constants and temporaries share one physical carrier authority; the historical fixed three-constant slot ceiling is removed.
- the 1.3.13 structural `xadd` and three-state shift/add peaks remain selected from relation structure, not workload names.
- the duplicate 1.3.12 stack-compatible recurrence backend is removed; unproven graphs fall back to the existing General semantic path.

## Source consolidation

- confirmed dead/placeholder Surface and Field helpers were removed;
- the unused `tensor_comm_elimination` compiler ghost state and write path were removed;
- `tensor_frontend_137_x86_64.S` left the active compiler source set;
- native256 base/wide frontend copies were collapsed into one assembly-time physical profile source;
- Tensor runtime 512/256 and base/derived copies were collapsed into one profile-driven source;
- unused internal `worker` compatibility wrappers were removed.

Across active `compiler/`, `runtime/` and `surface/` assembly/include sources, the line count falls from 87,449 in the 1.3.13 release workspace to 67,807 in 1.3.14, a reduction of 19,642 lines (22.46%). This is a source-maintenance metric, not a performance claim.

## Simulation probes

The consolidation was tested on unrelated FP simulation-style state updates rather than recurrence names: a damped oscillator, a three-node thermal coupling and a Maxwell material point. All Wheelchair/C/GFortran compared outputs were bit-identical under the stated benchmark contract.

The same-host 50M-step five-round medians recorded in `PERFORMANCE_1_3_14_SIMULATION.csv` are:

| case | Wheelchair 1.3.14 | C | GFortran |
|---|---:|---:|---:|
| damped oscillator | 127.093 ms | 110.904 ms | 107.688 ms |
| thermal3 | 188.524 ms | 187.771 ms | 188.387 ms |
| Maxwell point | 103.508 ms | 86.718 ms | 87.308 ms |

The thermal probe is structurally important because it uses four distinct hot FP constants. Its admitted hot loop no longer rematerializes a fourth constant every iteration, and its FP arithmetic is emitted as direct three-operand VEX operations plus the necessary state commits.

These are host-specific diagnostic measurements. 1.3.14 does not claim universal superiority over C or Fortran.

## Preserved boundaries

- strict FP reassociation remains disabled;
- trapping integer semantics are not weakened for native admission;
- no C/LLVM/JIT production backend is introduced;
- no workload-name dispatch is introduced;
- runtime transition graph walker: 0;
- runtime register allocator: 0;
- work stealing: 0;
- global ready queue: 0;
- resource-recipient selection: 0.
