# Wheelchair 1.3.76

1.3.76 completes the next stage of machine burn: causal independence proved by the existing Physical DAG can now survive to ISA as disjoint packet-local SIMD carriers and early next-packet load materialization. Group width is derived from real live machine-carrier pressure and existing causal depth rather than a fixed unroll number or candidate table.

Strict floating-point reduction order remains authoritative and is not regrouped. The obsolete byte-clone experiment is removed rather than retained as a compatibility path. Generic, boundary, mixed-layout, and native256 realizations remain on the same canonical architecture.

No workload matcher, second machine scheduler IR, fixed machine-unroll authority, Group-width candidate set, runtime issue selector, compatibility backend, or JIT is introduced.
