# Performance 1.3.76

The primary release evidence is structural machine-code convergence, not a claimed benchmark multiplier. In the existing 256^3 seven-neighbor Field stress case, generated tolerant code now gives the later packet its own SIMD carrier bank and issues its direct loads early (for example the next packet appears at +0x40 byte displacement while the first packet remains live). This is genuine carrier independence, unlike simple byte duplication of the same packet body.

Whole-process timing on the current shared Xeon environment was not statistically stable enough to claim a release speedup. One earlier single-worker sample showed about 6.6% improvement, while a later 81-pair alternating run was noise-bound and showed no confirmed gain. 1.3.76 therefore makes no general or stable speedup claim. Its hard performance-oriented result is that already-proved same-depth work is now visible to hardware as independent machine work.
