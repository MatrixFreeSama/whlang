# Pure Assembly Release Proof 1.3.76

Production compiler/runtime sources remain handwritten x86-64 assembly with shell build tooling. 1.3.76 adds no LLVM/GCC/C backend, JIT, Python production generator, second machine scheduling IR, runtime issue manager, or workload-specific machine path. Causal-depth burn is emitted directly from the existing Physical DAG and GroupFact authority.
