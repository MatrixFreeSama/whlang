# Correctness 1.3.76 — Causal-Depth Machine Burn

Release gates verify that tolerant stable-Region code contains disjoint packet carrier banks, early next-packet direct loads, and Group-level index advance while preserving the established numerical result. Strict reduction code is checked to contain no regrouped packet reduction. Mixed padded/strided Field inputs are verified byte-for-byte against their expected output in both native512 and native256 paths.

The implementation contains no workload-name matcher, second scheduling IR, fixed Group-width candidate set, private machine-unroll authority, runtime issue selector, or retained byte-cloning path.
