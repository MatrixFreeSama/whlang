# Wheelchair Charter 1.3.76

A proved causal independence relation must not collapse back into an artificial serial machine-carrier reuse merely because a generic emitter is convenient. Physical Facts flow directly into carrier lifetime, operator identity, and machine-visible causal depth.

Group width is a consequence of the real Physical DAG and available machine carriers, never a workload name, fixed threshold, private candidate table, or runtime scheduling decision. Strict semantic dependencies remain dependencies. Truthful degradation replaces compatibility branches.
