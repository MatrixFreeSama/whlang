# Architecture Aging 1.3.76

1.3.74 burned where a Physical Fact lives. 1.3.75 burned exact operator identity into the terminal ISA. 1.3.76 burns one more layer: already-proved causal independence becomes disjoint machine-carrier identity before execution.

The compiler does not create a late scheduling graph. It consumes the same Physical-DAG order and the existing canonical GroupFact authority. Group carrier capacity is derived from the actual live SIMD-machine facts and the remaining architectural carrier namespace; Group body depth remains bounded by the existing causal depth. There is no private candidate list such as 2/4/8 and no fixed unroll threshold.

For a stable direct Region, later independent packets can have their immutable LoadFacts materialized early into separate SIMD carriers before the earlier packet has exhausted its arithmetic chain. Their logical values use packet-local carrier banks, so the CPU sees independent machine work rather than repeated reuse of one carrier set. The old byte-clone prototype is not retained.

Strict reduction recurrence is a semantic dependency. If regrouping would change strict floating-point order, GroupFact naturally degrades to one packet. Boundary and irregular layouts continue through the canonical truthful realization rather than a compatibility branch.
