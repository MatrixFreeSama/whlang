# Performance Boundary 1.3.84

1.3.84 is an architecture-realization release. It does not claim an FPGA/ASIC speedup without synthesis, placement, routing, timing closure, and measurements on a specified device.

The x86 production path is regression-gated to preserve existing semantics and machine realization. The new objective is explicit in the architecture:

```text
physical work / mathematical-physical lower bound -> 1
```

Occupancy is not an objective. A larger amount of active silicon is useful only when the target's real physical cost model proves that it reduces total required work or causal time.

The architectural opportunity on a future spatial target comes from removing avoidable instruction-machine work: independent facts need not be serialized and rediscovered, short-lived values need not be transported through generic storage, and strong traffic relations may become direct locality/route constraints. Those are potentials, not benchmark claims.
