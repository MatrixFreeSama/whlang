# Wheelchair Charter 1.3.84

Wheelchair remains a general AOT structural language. It is not a parallel DSL and it is not a hardware-kernel language.

## Structural execution law

The program states mathematical, state, effect, and capability facts. Physical DAG expresses the required causality. Target silicon decides the physical realization subject to those facts.

```text
mathematics gives relation
causality gives time
silicon gives physical realization
```

Absence of a causal edge is not a request to create a thread. It is permission for the target to realize independence in the cheapest truthful form available.

## Hard prohibitions

The architecture must not grow worker pools, work stealing, global ready queues, recipient selection, idle-resource queries, workload-name dispatch, target-specific source kernels, fixed PE/tile/stage counts, second target semantic IRs, or occupancy goals.

A target may degrade Group/placement because of real physical limits. It may not change semantics to fit the machine.
