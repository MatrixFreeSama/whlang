# Wheelchair 1.3.84 Release Notes

## Silicon-realization closure

1.3.84 extends the existing Physical Reality authority through the target's exposed silicon boundary. The compiler no longer defines the instruction stream as the conceptual ceiling of structural execution.

The same Physical DAG now owns target realization:

```text
causal depth     -> time
Traffic/Region   -> space
fact lifetime    -> storage
GroupFact        -> multiplicity
```

On x86-64 these facts continue to burn directly into the existing machine emitter. On a spatial target, the architecture permits the same independent facts to exist as simultaneous physical compute/storage/routes without first converting them into a sequential instruction list.

## No parallel-language branch

No worker pool, task graph, ready queue, work stealing, source kernel, HLS scheduling language, fixed PE count, fixed tile, fixed pipeline depth, occupancy target, workload selector, or target-private semantic IR was added.

The existing General, Tensor, and Field surfaces remain general mathematical views into one compiler-wide Physical Reality.

## Target contract

`topologyc --silicon-contract` now emits a machine-readable target-only `wheelchair.silicon-reality/1` contract. It reports the target's exposed physical facts together with the structural laws used by every realization. It is deliberately not a program representation.

## Cleanup

The unused compiler-wide `PR_DOMAIN_GPR/XMM/YMM/ZMM/MASK` vocabulary is removed. Those names described one ISA's carriers and did not belong in universal Physical Reality.

The old `Physical-DAG -> ISA time axis` authority is replaced rather than aliased by `Physical-DAG -> realization time axis`. Existing x86 behavior is preserved by regression tests; there is no compatibility shadow.
