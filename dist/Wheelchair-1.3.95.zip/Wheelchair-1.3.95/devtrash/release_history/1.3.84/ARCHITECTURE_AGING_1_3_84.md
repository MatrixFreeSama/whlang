# Architecture Aging 1.3.84

1.3.84 closes the conceptual gap between Wheelchair's Physical DAG and the target silicon. The change is deliberately an aging step, not a new backend family: the existing facts remain the only semantic and physical authority.

## Missing layer

Before 1.3.84, the architecture correctly burned Physical-DAG depth, GroupFact, AddressFact, RegionFact, Traffic Reality, and lifetime into the x86 machine emitter, but the written authority still ended conceptually at an ISA schedule. That wording made a future spatial target look like a second execution model even though the needed structure already existed upstream.

## Converged rule

The final target realization is now described by four old facts:

```text
causal depth        -> realization time
Traffic + Region    -> realization space
fact lifetime       -> realization storage
GroupFact           -> realization multiplicity
```

An ISA target serializes only where its exposed machine requires serialization. A spatial target may realize independent facts as simultaneously live physical resources without first rebuilding a sequential instruction stream.

## Silicon Reality

`compiler/silicon_reality.inc` is included by the compiler-wide Physical Reality authority. It classifies target resources as execution, storage, transport, and effect domains and fixes the one-way laws that all targets must obey.

It does not contain a program graph, algorithm selector, device-specific kernel language, worker model, processing-element count, tile size, pipeline-stage count, or runtime resource allocator.

## Removed conceptual redundancy

The unused `PR_DOMAIN_GPR/XMM/YMM/ZMM/MASK` pseudo-domain vocabulary is deleted. Architectural registers remain x86 realization details instead of pretending to be compiler-wide physical domains.

The old statement that Physical depth is the final **ISA** time axis is aged into the stronger statement that Physical depth is the final **realization** time axis. x86 still consumes exactly the same order, so the existing machine-code path remains zero-flip.

## Anti-DSL firewall

A target is not allowed to introduce source kernels, tasks, workers, a second semantic IR, fixed PE/tile widths, occupancy as an objective, workload-name routing, or runtime work stealing. The optimization target remains convergence of real physical work toward the mathematical-physical lower bound.
