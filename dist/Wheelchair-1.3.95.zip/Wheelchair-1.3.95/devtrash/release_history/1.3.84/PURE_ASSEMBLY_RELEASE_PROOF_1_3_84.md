# Pure Assembly Release Proof 1.3.84

The production compiler/runtime path remains handwritten x86-64 assembly and direct ELF emission. 1.3.84 adds no C, C++, LLVM, JIT, Python, or HLS dependency to the production build.

`compiler/silicon_reality.inc` is compile-time authority only. `topologyc --silicon-contract` is emitted by the existing assembly compiler executable.

Python remains permitted in validation tooling and release tests only. `build.sh` continues to reject Python invocation from the production build path.
