# Silicon Reality 1.3.84

Wheelchair now treats the instruction machine as one target realization rather than the conceptual end of execution.

The invariant is:

```text
program facts
  -> Physical DAG
  -> target physical facts
  -> realization
```

No intermediate parallel-language model is inserted.

## Authorities

- **Time:** causal depth.
- **Space:** Traffic Reality plus Region/Address relations.
- **Storage:** ValueFact/StateFact lifetime.
- **Multiplicity:** GroupFact constrained by real target carriers.
- **Effects:** Capability/Effect boundary.

Target geometry may degrade a realization when resources are insufficient. It may not change semantics.

## Spatial realization

A spatial target is permitted to map independent Physical-DAG facts directly to simultaneously live compute units, local storage, and routes. It is explicitly forbidden to re-linearize the DAG merely to recover the same independence later.

This is not an FPGA DSL or HLS kernel layer. FPGA/ASIC vendor primitives, placement regions, routing resources, memories, and arithmetic blocks are target-exposed physical resources. They consume the same facts that x86 currently maps to registers, memory operands, SIMD carriers, and executions.

## Hardware boundary

Commodity CPU/GPU software cannot address arbitrary individual transistors. Wheelchair therefore stops at the finest physical primitives exposed by the target. `SR_ARBITRARY_TRANSISTOR_ADDRESSING=0` is a hard truth, not an implementation omission.

## Machine-readable contract

`bin/topologyc --silicon-contract` emits `wheelchair.silicon-reality/1`. It contains target facts and architecture laws only. It intentionally contains no program DAG, kernel list, task graph, fixed tile, or PE count, so it cannot become a shadow program IR.
