# Testing 1.3.84

The release authority contains 17 tests.

The new `test_silicon_realization_1384.sh` verifies:

- Silicon Reality is included exactly once through Physical Reality.
- Physical DAG, causal depth, Traffic/Region, lifetime, and GroupFact are the single realization authorities.
- ISA is not the semantic ceiling.
- spatial realization does not require re-linearization.
- no fixed PE/tile/pipeline-stage authority exists.
- no runtime silicon allocator, idle-resource query, ready queue, work stealing, hardware-kernel language, parallel-DSL route, or second target semantic IR exists.
- `topologyc --silicon-contract` emits valid machine-readable JSON with those laws.
- representative Field and General programs remain zero-flip on the x86 realization.

Run:

```sh
./test.sh release
```
