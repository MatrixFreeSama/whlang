# Wheelchair charter 1.3.89

Wheelchair remains a general-purpose AOT language whose program authority is mathematical and causal structure, not a hardware kernel surface.

For heterogeneous silicon:

1. One Physical DAG owns semantics.
2. Target hardware contributes physical facts only.
3. x86 and reconfigurable fabric may coexist in one realization.
4. Physical Edge traffic participates in cross-domain cost.
5. Placement is AOT and deterministic.
6. Missing hardware facts remain missing; they are never guessed.
7. No runtime device scheduler, worker pool, work stealing, fixed PE count, tile size, kernel annotation, HLS semantic authority or target-private graph is admissible.
8. A target realization may degrade when hardware is insufficient; it may not change semantics.
9. Performance claims require measured hardware. Synthetic cost closure is proof, not benchmark evidence.
