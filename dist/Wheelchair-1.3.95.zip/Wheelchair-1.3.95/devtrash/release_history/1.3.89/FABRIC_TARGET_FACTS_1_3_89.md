# Fabric target facts 1.3.89

## Purpose

A reconfigurable fabric is another physical domain in the same Wheelchair Silicon Domain Graph. It is not a language mode.

`compiler/fabric_target_facts_x86_64.S` owns the current external fact interface. All production defaults are zero. A target integration may provide values at assembly time only when it has authority for the hardware.

Published dimensions:

```text
fabric_logic_units
fabric_register_units
fabric_dsp_units
fabric_local_storage_bytes
fabric_routing_domains
fabric_clock_regions
fabric_compute_ticks_num / fabric_compute_ticks_den
fabric_activation_ticks
fabric_transport_fixed_ticks
fabric_transport_ticks_per_byte
```

The common tick ratio is a target calibration against the existing Physical Reality work unit; it is not a source hint and not a workload classifier.

## Placement closure

General Region placement consumes:

```text
Region work_ticks
Physical Edge transfer_bytes
current neighboring domain tags
fabric work ratio
fabric activation cost
fabric crossing cost
```

Every accepted domain flip strictly lowers cost. With finite binary labels and strict improvement, convergence requires no fixed round count.

## Release-host state

The production contract reports all fabric facts as zero and `fabric_target_facts_proved = 0`. No Region is tagged as fabric.

The release test also builds a proof-only synthetic target from the same source. This verifies mixed-domain closure but is not installed and is not a hardware benchmark.
