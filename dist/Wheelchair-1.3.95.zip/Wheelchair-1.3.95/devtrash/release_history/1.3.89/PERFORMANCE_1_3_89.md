# Performance 1.3.89

## Measurement boundary

The release host has no proved FPGA domain, fabric activation bridge, RTL emitter, place-and-route toolchain, board, or bitstream. Real FPGA acceleration cannot be measured and is not estimated.

## Generated-program execution

Frozen 1.3.88 and current 1.3.89 compiled `mass3`, `chem6`, and `rigid7`. All three generated ELF files are byte-identical across releases.

Thirty interleaved 20,000,000-step runs pinned to CPU 0 produced:

| probe | 1.3.88 median | 1.3.89 median | 1.3.88 / 1.3.89 |
| --- | ---: | ---: | ---: |
| mass3 | 0.152294898 s | 0.152359436 s | 0.99958x |
| chem6 | 0.140615868 s | 0.140734461 s | 0.99916x |
| rigid7 | 0.242138841 s | 0.240702173 s | 1.00597x |
| geometric mean | | | **1.00156x** |

The approximately `+0.156%` timing difference is noise. Because the generated executables are byte-identical, the release claim is:

```text
x86 generated-program speedup = 0%
x86 generated-program regression = 0%
```

## Compile-time observation

Sixty interleaved compiles per probe were also measured. The geometric-mean 1.3.88/1.3.89 median ratio was about `1.035x`. These compiles take roughly 1.4-2.1 ms and process launch/cache noise dominates at this scale; no compiler-speed claim is made.

## Proof-only joint cost

A synthetic target-fact profile used only by the release gate changes `branch_probe` from all-x86 tags to `2,2,1,2,1`. Under that synthetic cost algebra the calculated physical cost changes from 762 to 647 ticks, a 15.0919% reduction.

This is not a speedup measurement. It proves that the joint placement algebra responds to target physical facts without workload-specific routing.

Raw data is under `devtrash/benchmarks/fabric_target_facts_1389/`.
