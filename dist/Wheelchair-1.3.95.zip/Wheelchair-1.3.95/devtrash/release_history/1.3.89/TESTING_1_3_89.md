# Testing 1.3.89

The current release authority contains 20 tests.

The new `test_fabric_target_facts_1389.sh` verifies:

- production fabric target facts default to zero;
- the current contract is `wheelchair.silicon-reality/6`;
- target resource facts are externally supplied physical facts;
- joint placement uses strict-improvement convergence with no fixed round limit;
- normal production compilation creates no fabric tags;
- a proof-only target compiler built from the same sources produces a deterministic mixed x86/fabric Region plan;
- Physical Edge facts remain unchanged between production and proof target compiles;
- no FPGA source annotation, kernel, HLS route, runtime device selector, fixed PE grid, fixed tile or workload matcher appears.

All previous current-release gates remain active.
