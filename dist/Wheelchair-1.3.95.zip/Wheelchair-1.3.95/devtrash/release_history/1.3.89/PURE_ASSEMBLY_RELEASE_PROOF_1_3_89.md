# Pure assembly release proof 1.3.89

Production compiler and runtime authority remains handwritten x86-64 assembly under `compiler/` and `runtime/`.

The new fabric target-fact authority is `compiler/fabric_target_facts_x86_64.S`. Production build assembly uses zero defaults. The release proof may assemble a separate temporary target-fact object with `--defsym` values and relink the already-built current compiler objects. That temporary proof compiler is not installed under `bin/`.

No C, C++, LLVM, JIT, Python generator or HLS tool participates in production compiler construction. Python used by release tests only inspects generated ELF metadata and benchmark records; it is not production authority.
