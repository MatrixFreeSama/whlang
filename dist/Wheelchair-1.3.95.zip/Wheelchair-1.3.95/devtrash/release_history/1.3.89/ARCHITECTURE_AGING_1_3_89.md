# Architecture aging 1.3.89

## Removed assumption

1.3.88 could represent a fabric realization tag but normal compilation had no target-physical fabric facts and therefore no lawful way to derive a mixed placement.

1.3.89 ages this into the existing Silicon Reality instead of adding another backend policy layer.

```text
Physical DAG
    ×
Physical Edge traffic
    ×
x86 domain facts
    ×
fabric target facts
    ->
AOT joint domain closure
```

## Single authority

Fabric facts are target facts only:

```text
logic capacity
register capacity
DSP capacity
local storage
routing domains
clock regions
common work conversion
activation cost
cross-domain transport cost
```

They do not create source syntax or a target-owned graph.

## Convergence law

A Region domain flip is legal only when it strictly lowers the same local contribution to the global physical energy: Region work plus every incident cross-domain Physical Edge. Exact ties retain the current domain. Repeated canonical passes stop only at structural stability, not at a fixed iteration count.

This removes both a magic crossover and a fixed optimization-round budget.

## Conservative boundary

Unknown/unbounded Region work remains x86. Unknown transfer size makes a cross-domain edge inadmissible. Missing target facts remain zero and cannot materialize fabric.

## Still absent

1.3.89 deliberately does not add:

- source FPGA annotations;
- kernels, workers, tasks or PE grids;
- fixed tile or pipeline counts;
- runtime device selection or migration;
- FPGA algorithm selectors;
- RTL/netlist/bitstream emission.
