# Wheelchair 1.3.24

Wheelchair 1.3.24 is the **Branch Extinction / Physical-DAG Closure** release. It removes the remaining source-shape fast lanes and compatibility-only routes identified in the 1.3.x production tree, while folding their useful mathematics into the existing ValueFact / Physical Reality / Physical DAG authority. No replacement workload route, solver route, fixed state-count route, fixed chunk size, runtime autotuner, C/LLVM backend, or JIT is introduced.

The Field two-term Factor2/FactorGroup/cross-output island is gone. Tolerant multiply-accumulate contraction is now admitted from generic def-use and common-factor ValueFact closure, including three-or-more-term groups. The Rank-N fixed periodic AST matchers are gone in favor of affine-mod canonicalization. Tensor last-consumer square admission is gone in favor of general post-materialization ValueFact reuse. The old fixed chunk geometries are gone: runtime leaf geometry is derived from the AOT structural quantum, immutable target width, and outward-materialization price.

On the same five-CPU AMD host used for release validation, 1.3.24 versus 1.3.23 measured about **1.047x** on `chem6` (20M steps), **1.053x** on `ring8` (10M steps), and **1.056x** on 100M-element FSI. A 10M/50M/100M FSI slope fit improves steady-state throughput from about **0.562 ns/element to 0.522 ns/element** (about **1.076x**). Short strongly causal probes remain approximately flat within host noise. See `PERFORMANCE_1_3_24_BRANCH_EXTINCTION.md`.

See `WHEELCHAIR_CHARTER_1_3_24.md`, `RELEASE_NOTES_1_3_24.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_24.md`, `PERFORMANCE_1_3_24_BRANCH_EXTINCTION.md`, `test_branch_extinction_1324.sh`, and `test_release_native_1324.sh`.

# Wheelchair 1.3.23

Wheelchair 1.3.23 is the **Composition-Closed Transition Power** release. It restores the mathematical peak that was lost when the historical fixed two-state affine iterate route was deleted in 1.3.22, but it does **not** restore that private route. Transition power is now admitted from the existing counted-recurrence Physical Reality by algebraic proof and causal backward slicing.

For a published result ValueFact, the compiler takes its backward slice. If that slice proves a wrap-u64 affine self-map `F(x)=A*x+B`, repeated causal application is represented as `F^N` and realized by binary composition in `O(log N)`. Total semantic state count is not an admission condition: the release gate includes a nine-state recurrence where seven coupled sibling states are outside the published-result slice and therefore create no physical work for that result. Non-closed recurrences remain on the ordinary causal register-DAG.

The historical `g_try_emit_affine_iterate`, `g_match_affine_update`, `gc_affine_*`, fixed boundary-select `axis±1` matcher, and their stale frozen-native copies are absent. No recurrence runtime manager, repetition threshold, workload dispatch, C/LLVM backend, or JIT is introduced.

A same-host whole-process LCG check shows the structural change: 1.3.22 scales approximately linearly (1M 1.54 ms, 10M 12.19 ms, 100M 116.29 ms), while 1.3.23 stays around 0.27-0.29 ms and is dominated by process startup. These timings are local evidence; the release authority is the recovered binary-composition machine structure and regression suite.

See `WHEELCHAIR_CHARTER_1_3_23.md`, `RELEASE_NOTES_1_3_23.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_23.md`, `PERFORMANCE_1_3_23_TRANSITION_POWER.md`, `test_transition_power_1323.sh`, and `test_release_native_1323.sh`.

# Wheelchair 1.3.22

Wheelchair 1.3.22 is the **Predicate ValueFact Persistence / Boolean Sparsification** release. It strengthens the same Physical Reality / Physical DAG path: an immutable materialized predicate is an ordinary ValueFact and is not physically re-evaluated while its input versions are unchanged. The release also deletes the historical fixed two-state affine-iterate lowering and fixed axis±1 interior boundary-select matcher rather than preserving private shape routes.

The canonical predicate probe reduces four identical `x < y` source occurrences from four machine comparisons to one, with exact true/false output bits and explicit Physical-DAG dependency preservation. No Boolean runtime, repetition threshold, workload dispatch, C/LLVM backend, or JIT is introduced.

Wheelchair 1.3.21 introduced **Physical ValueFact Transport Sparsification**. It strengthened the existing Physical Reality / Physical DAG path and deleted another historical fixed policy.

A semantic timestep boundary no longer implies a physical `register -> memory -> register` handoff. After the final effective consumer of an old state ValueFact, its physical carrier may immediately become the next-version authority. Effective liveness is computed after selected whole-episode CSE subgraphs have already been materialized, so only real remaining consumers keep an old authority alive.

There is no chemistry route, state-count route, transport backend, runtime ValueFact manager, or runtime allocator. The old fixed `G_PHYS_FP_RESIDENT_MAX=6` rule is deleted; FP state residency is derived from target carrier geometry and actual carrier conflicts. If a persistent next-version candidate exhausts anonymous carriers, the same DAG is retried AOT after releasing that competing realization.

The `chem6` pressure probe falls from 89 to 59 hot-loop instructions while retaining 15 scalar multiplies and exact IEEE-754 output. The unrelated 8-state ring falls from 82 to 42 hot-loop instructions, showing that the change is not chemistry-specific.

See `WHEELCHAIR_CHARTER_1_3_21.md`, `RELEASE_NOTES_1_3_21.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_21.md`, `PERFORMANCE_1_3_21_TRANSPORT_SPARSIFICATION.md`, `test_transport_sparsification_1321.sh`, and `test_release_native_1321.sh`.

# Wheelchair 1.3.19

Wheelchair is an HPC- and simulation-first general-purpose language built around matrix-free execution, Rank-N semantics, AOT compilation, direct x86-64 machine code, and causal physical execution.

Wheelchair 1.3.19 is the **Structural Execution Theory Consolidation** release. It formalizes the execution rule exposed by the recent Physical DAG and external-silicon work:

> **Equivalent causal depth is spontaneously parallel; serialization exists only as increased causal depth.**

Source order is not execution authority. The primary performance variables are total necessary physical work `W`, weighted causal span `S`, and critical-path realization overhead `H`. The structural speedup model is

```text
S_struct(P) = W / (max(W/P, S) + H)
S_struct_ideal(P) = min(P, W/S)
```

`W/S` is **Intrinsic Causal Parallelism**. Future optimization work is classified by whether it reduces `W`, `S`, or `H`; if an optimization cannot identify one of those reductions, it is presumed architecture growth without proven physical value.

1.3.19 deliberately does **not** add a runtime causal-depth scheduler, level queue, serial-fraction manager, worker pool, credit fabric, or resource-availability query. `tools/structural_execution_model.sh` is an offline diagnostic that reads existing immutable Physical Reality facts from generated Tensor/Field ELFs and evaluates the model for a supplied extent. Theory does not create hot-path work merely to observe itself.

See `WHEELCHAIR_CHARTER_1_3_19.md`, `RELEASE_NOTES_1_3_19.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_19.md`, `RELEASE_GATES_1_3_19.txt`, `PERFORMANCE_1_3_19_STRUCTURAL_EXECUTION.md`, `PERFORMANCE_1_3_19_STRUCTURAL_SCALING.csv`, `tools/structural_execution_model.sh`, `test_structural_execution_1319.sh`, and `test_release_native_1319.sh`.

## 1.3.19 Structural Execution Theory

Structural Execution does not start from a sequential program and then search for a parallel percentage. The Physical DAG represents a causal partial order directly. Nodes at equal causal depth have no ordering edge unless semantics prove one; only true dependency increases span.

The research diagnosis is therefore:

```text
W too large? -> remove duplicate/avoidable physical work
S too deep?  -> remove false causal edges, never true mathematical causality
H too large? -> remove avoidable realization/scheduling/lifecycle work
```

The existing 1.3.18 Emergent Outward Expansion remains the physical realization mechanism. 1.3.19 adds theory, diagnostics and release authority around that existing architecture, not another optimizer branch.

# Wheelchair 1.3.18

Wheelchair is an HPC- and simulation-first general-purpose language built around matrix-free execution, Rank-N semantics, AOT compilation, direct x86-64 machine code, and causal physical execution.

Wheelchair 1.3.18 is the **Emergent Outward Expansion** release. It preserves the 1.3.17 law that Wheelchair owns work, never silicon, while deleting the remaining assumption that every mathematically independent split must immediately become a Linux execution context.

`Ready` now means *independently executable*, not *must clone*. Tensor and Field keep the same canonical causal tree and offer two physical realizations: local continuation or outward execution. Existing Physical Reality chooses between them by total physical cost. The AOT compiler measures the target execution-context lifetime and derives work cost from the existing physical schedule/operator graph. There is no fixed element/chunk/instruction/time threshold and no runtime query of CPU availability.

```text
causal independence
      -> local continuation
      -> outward execution
      -> lower proved physical cost wins
```

The external-silicon law remains unchanged: no credit pool, free-worker inventory, capacity claim/release, work stealing, global ready queue, runtime CPU pinning, donor lookup or recipient lookup. Completed outward execution still evaporates from Wheelchair rather than returning a resource token.

Same-host diagnostics show why the distinction matters. A 100M lightweight Tensor reduction drops from 14.481 ms in 1.3.17 to 6.953 ms in 1.3.18 while median voluntary context switches fall from 2699 to 337. A heavy 100M FSI probe remains essentially unchanged at about 57.5 ms because outward execution is already physically profitable. These measurements are host/workload-specific evidence, not universal language claims.

See `WHEELCHAIR_CHARTER_1_3_18.md`, `RELEASE_NOTES_1_3_18.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_18.md`, `RELEASE_GATES_1_3_18.txt`, `PERFORMANCE_1_3_18_EMERGENT_EXPANSION.md`, `PERFORMANCE_1_3_18_RESOURCE_AB.csv`, `test_emergent_outward_expansion_1318.sh`, and `test_release_native_1318.sh`.

## 1.3.18 Emergent Outward Expansion

1.3.18 deletes `independent split == unconditional clone`. The semantic tree stays unchanged, but the physical realization may remain local when the OS execution-context lifecycle would cost more than the subtree itself. When the work is heavier than outward materialization, it is exposed to OS/hardware exactly as before.

The comparison uses immutable AOT physical facts, not current resource availability. Consequently the profitable split boundary can move naturally across CPUs/kernels without a workload-size magic number. Strict reductions preserve their canonical pairwise tree in both realizations.

## 1.3.17 External Silicon Authority

The active resource path contains no internal execution-capacity accounting. Tensor and Field true independent splits directly materialize an outward child execution; completion terminates that child. General future regions are semantic facts only until their real dependencies become ready, at which point the successor is materialized. No future region is pre-created merely to sleep on a futex.

Current production images expose only fields consumed by the current runtime contract; compatibility-only resource-control fields are not retained as execution authority. Affinity/topology may still be observed as hardware facts for AOT/NUMA reasoning, but Wheelchair does not use those observations to reserve CPUs or determine how many causal work fragments may exist.

Wheelchair is an HPC- and simulation-first general-purpose language built around matrix-free execution, Rank-N semantics, AOT compilation, direct x86-64 machine code, and causal physical execution.

Wheelchair 1.3.16 is the **Whole-Episode Physical DAG Strengthening** release. It continues the merge-and-reuse-first rule: new simulation families are structural probes, not reasons to create new backends. The existing Rank-N / Axis / Operator / Region / Effect / Capability + Versioned Physical Reality + Physical DAG architecture now shares exact old-version ValueFacts across simultaneous next-state expressions and proves whole-episode carrier pressure AOT.

Persistent state, shared ValueFacts, constants and anonymous temporaries use one compile-time physical carrier authority. An extra profitable constant may reduce residency, but it does not select a legacy stack backend. Strict operation order remains part of ValueFact identity; no FP reassociation, runtime graph walker, runtime CSE manager or workload-specific cache is introduced.

The supreme objective is not CPU occupancy:

```text
not: CPU utilization -> 100%

but: necessary physical work / all active physical work -> 100%
```

Idle silicon is legal when no independent causal work exists. Activated silicon doing avoidable coordination, balancing, polling, redistribution, duplicate realization, register shuffling, repeated materialization, artificial synchronization, or occupancy maintenance is a design failure.

The governing rule remains:

> **Activate no silicon without necessary work. Waste no activated silicon on avoidable work.**

## 1.3.16 Whole-Episode Physical DAG Strengthening

1.3.16 strengthens the old unified Physical Reality in two places exposed by unrelated simulation probes. First, anonymous temporary pressure is proven before constant/shared-fact retention, so constant count can no longer create a register-native-to-stack backend cliff. Second, all simultaneous next-state expressions enter one exact strict-order CSE domain, allowing repeated old-version subgraphs to become one physical ValueFact.

The retained shared-fact set is a parent/child antichain, and selected future facts do not become direct sources until they are actually materialized. These rules repair both duplicate physical work and a ready/future identity hazard without adding a runtime cache or a workload-specific optimizer.

Authority probes cover two through eight distinct hot constants, six-species mass-action kinetics, seven-state quaternion/rigid-body dynamics, a shared-quaternion-norm graph, and a six-state mechanical chain. The full seven-state rigid-body probe moves from the 1.3.15 generic stack evaluator back into the VEX Physical DAG; the shared-norm hot arithmetic contracts from 53/28/7 multiply/add/sub operations to 38/19/4.

See `WHEELCHAIR_CHARTER_1_3_16.md`, `RELEASE_NOTES_1_3_16.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_16.md`, `PERFORMANCE_1_3_16_WHOLE_EPISODE_PHYSICAL_DAG.md`, `PERFORMANCE_1_3_16_SIMULATION.csv`, and `PERFORMANCE_1_3_16_PHYSICAL_DAG.csv`.

## 1.3.15 Rank-N Causal Physicalization Closure

1.3.15 removes the last fixed-size assumption from the unified causal-state path. Counted induction is Axis authority rather than persistent model state. Versioned state facts receive profitable GPR/XMM carriers when physical capacity allows; excess facts remain in their already-owned private state pages while their expressions continue through the same register-native Physical DAG. There is no large-state backend and no runtime state scheduler.

The durable path is therefore:

```text
N versioned causal ValueFacts
    -> existing Physical Reality
    -> whole-episode lifetime / pressure / profitability
    -> partial residency
    -> private-page materialization only where physically necessary
    -> native machine code
```

The old private-page structure is strengthened with compile-time in-page cache-set coloring. This removes the 4 KiB-stride L1D set-alias cliff without replacing private ownership with a shared packed manager. Integer and mixed FP/integer spill states obey the same law.

Release probes cover 4/8/16/32 FP states, eight wrap-u64 states, and mixed FP/u64 state. Beyond register capacity the hot loop gains only necessary state-page traffic, not artificial push/pop traffic or a backend cliff. The 1.3.13 XADD peaks and 1.3.14 VEX/constant-residency peaks remain release obligations.

See `WHEELCHAIR_CHARTER_1_3_15.md`, `RELEASE_NOTES_1_3_15.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_15.md`, `PERFORMANCE_1_3_15_STATE_CONTINUITY.csv`, and `PERFORMANCE_1_3_15_SIMULATION.csv`.

## 1.3.14 Unified Physical Architecture Consolidation

The durable compiler path is:

```text
WH / WHEX semantics
    -> Rank-N / Axis / Operator / Region / Effect / Capability
    -> Versioned Physical Reality
    -> Physical DAG
    -> shared lifetime / carrier / constant / ISA authority
    -> native machine code
```

Key 1.3.14 changes:

- General, Tensor and Field share the compiler-wide Physical Reality vocabulary.
- Causal scalar state is represented as a causal axis rather than a workload-specific backend.
- fixed expression-depth GPR/XMM scratch ownership is removed from the active causal-state path.
- scalar FP physicalization uses three-operand VEX and shared constant/temporary carrier authority.
- the historical three-constant FP residency ceiling is removed.
- native256 frontend copies and Tensor runtime profile copies are collapsed into assembly-time profiles.
- confirmed dead helpers, ghost state and unused internal compatibility wrappers are removed.
- active compiler/runtime/surface assembly/include source falls from 87,449 lines in the 1.3.13 workspace to 67,807 lines in 1.3.14 while preserving the protected technical peaks.

See `WHEELCHAIR_CHARTER_1_3_14.md`, `RELEASE_NOTES_1_3_14.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_14.md`, and `PERFORMANCE_1_3_14_UNIFIED_PHYSICAL_REALITY.md`.

## 1.3.12 Causal State Collapse

### A source variable is not a physical-state entitlement

The historical General register path admitted at most two semantic states. A recurrence with two true values plus one loop counter therefore fell into the generic state-slot path even though the counter was only control authority. 1.3.12 separates those roles at AOT time.

```text
semantic source
    -> causal state-role proof
    -> persistent data state / counted control / fallback
    -> physical register realization
```

A proved zero-initialized `counter < bound` / `counter = counter + 1` state uses independent machine control authority. It does not consume the persistent data-state register budget. The current x86-64 General path admits up to three scalar data states in R8/R9/R10, with counted control in RBX and its invariant bound in RBP. Larger or unsafe graphs keep the generic fallback.

The path supports u64, i64, f32, and f64 state bit authorities. A counter that participates in value expressions remains readable from its control register. Simultaneous transition semantics remain intact while `state_values` / `state_temp` materialization is absent from admitted register recurrences.

### Not a Fibonacci specialization

Fibonacci was only the probe that exposed the state-role cliff. Release authority also requires a Lucas recurrence, a three-data-state Tribonacci recurrence, an f64 recurrence, and a value-participating counter. Production compiler/runtime sources contain no named recurrence dispatch. Runtime recursion remains deliberately deferred.

### Same-host evidence

On the same Intel Xeon Platinum 8573C host, fixed to one CPU, seven interleaved 500M recurrence rounds measured:

| implementation | median wall | median CPU time |
|---|---:|---:|
| Wheelchair 1.3.11 | 2044.286 ms | 2041.844 ms |
| Wheelchair 1.3.12 | **427.384 ms** | **426.433 ms** |
| Expert C | 177.460 ms | 176.900 ms |
| GFortran | 178.169 ms | 177.849 ms |

The 1.3.12 probe is about **4.783x** the 1.3.11 throughput. Wheelchair still takes about **2.408x** the Expert C time, so this release does not claim a Fibonacci victory over C. The architectural result is removal of persistent generic state/temp traffic from the admitted recurrence path.

Non-Fibonacci same-mechanism probes show about **4.717x** throughput on 100M Lucas, **4.911x** on a 50M three-data Tribonacci recurrence, and **1.301x** on a 10M f64 recurrence, with compared 1.3.11/1.3.12 results bit-identical. See `PERFORMANCE_1_3_12_CAUSAL_STATE_COLLAPSE.md`.

## 1.3.11 Field physical-work reduction

### Rank-N proof compression

The regular direct-load path already existed before 1.3.11. The newly exposed cost was the proof itself. On non-power-of-two shapes, the old generic interior check could perform repeated integer divisions for both ends of a SIMD episode on each affected axis. 1.3.11 proves the innermost row once, rejects row crossing, and then decodes each shared outer coordinate once. A rank-3 interior episode therefore falls from roughly twelve scalar divisions in the worst generic pattern to roughly four.

True boundary and irregular cases retain the existing fallback authority. A static gather site is not evidence that an interior episode dynamically executes a gather.

### Reuse-weighted neighbor residency

Ordinary AVX-512 Field execution now admits a bounded residency bank in ZMM6..ZMM12 for immutable neighbor facts selected from compile-time reuse counts. The goal is not maximum register occupancy. A fact earns residency only when keeping it alive is cheaper than repeatedly reloading its physical authority.

### Complex WH/WHEX Field surface

The canonical Field graph and human Field lowerer now support four floating logical registers, v0..v3. This closes a real surface gap discovered by a high-pressure three-output 3D expression that the canonical `wheelchair.field/1` backend could execute but the former three-register human expression slice rejected.

The fourth carrier remains compile-time only. There is no runtime expression interpreter, no JIT, and no alternate Field semantics.

### Physical profitability rejects decorative optimization

A broad tolerant mul-plus-add FMA contraction was implemented and measured during development. It reduced static instruction count but increased accumulator recurrence pressure and slowed multi-capacity execution. It is intentionally absent from the release. Wheelchair does not optimize FMA count; it optimizes necessary physical work.

### Same-host retained-mechanism audit

On the 224^3 complex materialized Field probe, final 1.3.10 binaries and the final 1.3.11 candidate were measured on the same Intel Xeon Platinum 8573C host using tmpfs data, fixed affinity, two warmups, and nine interleaved measured rounds:

| capacity | 1.3.10 wall | 1.3.11 wall | throughput ratio | 1.3.10 CPU-time | 1.3.11 CPU-time |
|---:|---:|---:|---:|---:|---:|
| 1 | 180.614 ms | 164.780 ms | 1.096x | 179.913 ms | 164.067 ms |
| 2 | 149.694 ms | 143.305 ms | 1.045x | 209.940 ms | 203.347 ms |
| 4 | 105.734 ms | 83.971 ms | 1.259x | 269.465 ms | 223.353 ms |

The three-cell geometric-mean throughput ratio is about **1.130x**. At capacity 4, wall time falls about **20.6%** while total active CPU-time falls about **17.1%**. The canonical checksum stays bit-identical at `0x443cec18`. These are host- and workload-specific measurements.

## 1.3.10 execution architecture

### Work exists before capacity

Hardware width is only a ceiling. It does not create work.

```text
causal work -> eligibility to activate silicon
hardware     -> maximum permission ceiling
```

In 1.3.10, hardware width was treated only as a ceiling and never as a source of work. The historical `--executors N` compatibility option was removed in 1.3.24; current execution capacity comes only from the compiled target/affinity authority.

### Load balancing is extinct from Tensor and Field production execution

1.3.10 removes the remaining worker-equality family:

- no static `id * chunks / P` work partition;
- no proportional executor assignment by subtree size;
- no executor-ID work topology;
- no work stealing;
- no push or pull balancing;
- no peer load observation;
- no idle-worker or busy-worker discovery for redistribution;
- no global load table;
- no global ready queue;
- no post-completion work search;
- no runtime occupancy autotuning.

Execution topology comes from the canonical causal work tree. A capacity ceiling may change how many independent subtrees run at once, but it must not change which causal work exists.

### Blind Surplus Reflow

A completed causal region releases anonymous execution capacity. It never selects a recipient. A region that already owns another independent causal subtree may make one bounded blind claim for anonymous capacity. It never searches for a donor.

```text
finished causal work
        |
        v
anonymous capacity release
        |
        v
unowned execution permission
        ^
        |
blind bounded claim
        |
pre-existing independent causal work
```

The claimed object is execution permission, not another thread's work.

```text
resource release is recipient-blind
resource acquisition is donor-blind
```

Anonymous credits are distributed across four cache-line-isolated bitsets. There is no single global surplus counter. A failed claim does not spin, poll, inspect peers, or retry the same point. Execution continues through necessary local work, and a later genuine causal expansion point may perform a new bounded claim.

### Protected mechanisms

The load-balancing purge does not remove mechanisms that perform real causal or machine work:

- General causal futex waiting on a region's own indegree;
- AOT Kahn topology queues used only during compilation;
- intra-kernel SIMD carrier scheduling that removes dependency stalls inside already-active silicon;
- locality constraints that express physical permission or cost;
- compile-time physical scheduling that removes instructions or dependencies without runtime worker redistribution.

## Numerical contracts

Wheelchair keeps strict and tolerant floating-point contracts distinct.

The 1.3.8 strict reduction repair remains preserved. On the FSI diagnostic, native512 and native256 strict execution produces the same final bits across capacity ceilings q1, q2 and q4. In 1.3.10, tolerant execution also uses a capacity-independent canonical causal reduction tree.

Selected 100M FSI checksums:

```text
tolerant q1/q2/q4: 0x416522bcff4adae6
strict   q1/q2/q4: 0x416522bcff4adb3a
```

The FSI graph is a regression probe only. Production source contains no FSI, fluid, or solid specialization trigger.

## Active-Silicon audit

Host-specific 1.3.8 to 1.3.10 measurements on an Intel Xeon Platinum 8573C with 5 visible vCPUs and a sustained 4-CPU cgroup quota show the intended distinction between occupancy and useful active work.

At N=100M:

| Contract | q | 1.3.8 wall | 1.3.10 wall | 1.3.8 CPU time | 1.3.10 CPU time |
|---|---:|---:|---:|---:|---:|
| tolerant | 2 | 163.058 ms | 164.698 ms | 320.053 ms | 269.260 ms |
| tolerant | 4 | 83.526 ms | 85.106 ms | 318.845 ms | 270.973 ms |
| strict | 4 | 163.809 ms | 124.686 ms | 477.018 ms | 402.070 ms |

Tolerant q2/q4 reduces total active CPU time by about 16% and 15% while wall time stays within about 1% to 2%. Strict q4 reduces wall time by about 23.9% while also reducing total CPU active time by about 15.7%.

The generated FSI arithmetic hot payload is byte-identical between 1.3.8 and 1.3.10, so these measurements isolate execution-fabric changes rather than an FSI arithmetic rewrite.

These measurements are host- and workload-specific. They are not a transistor-level Active-Silicon Purity percentage and are not a universal performance claim.

See `PERFORMANCE_1_3_10_BLIND_SURPLUS_REFLOW.md` for the full measurement table and claim boundary.

## Core language and compiler model

Wheelchair remains:

- matrix-free by default;
- Rank-N oriented;
- AOT only;
- direct x86-64 native code;
- no C, LLVM, MLIR, or JIT production backend;
- no Python source in the release implementation path;
- WH human surface plus WHEX lower-level semantics;
- strict and tolerant numerical contracts;
- AVX2 and AVX-512 native Tensor and Field paths;
- recipient-blind resource release;
- no work stealing and no central runtime scheduler.

WH may present familiar surface forms such as `if` or `while`, but the lower execution model is dataized and physical rather than a requirement for sequential von-Neumann control.

## Build

```sh
./build.sh
```

The production build uses shell plus handwritten assembly tooling. It invokes no Python compiler generator and no C/LLVM production backend.

## Compile

General WH/WHEX:

```sh
./wheelchairc program.wh -o program
./whexc program.whex -o program
```

Tensor:

```sh
./topologyc program.whex -o program
./topologyc-wide program.whex -o program
./topologyc-native256 program.whex -o program-avx2
```

The historical `--executors N` compatibility CLI was removed in 1.3.24. Current Tensor compilation exposes no executor-count source option.

Field:

```sh
./fieldc kernel.whex -o kernel
./fieldc-native256 kernel.whex -o kernel-avx2
```

## Release validation

Run the complete 1.3.12 release authority:

```sh
./test_release_native_1312.sh
```

The dedicated General causal-state gate is:

```sh
./test_causal_state_collapse_1312.sh
```

The release first requires the complete 1.3.11 authority and then the new General state-collapse authority. Final success ends with:

```text
WHEELCHAIR_1_3_11_RELEASE=PASS
COMPLETE_1_3_11_RELEASE_AUTHORITY_PRESERVED=PASS
WHEELCHAIR_CAUSAL_STATE_COLLAPSE_1_3_12=PASS
WHEELCHAIR_1_3_12_RELEASE=PASS
```

## 1.3.12 authority documents

- `WHEELCHAIR_CHARTER_1_3_12.md`
- `RELEASE_NOTES_1_3_12.md`
- `RELEASE_GATES_1_3_12.txt`
- `PURE_ASSEMBLY_RELEASE_PROOF_1_3_12.md`
- `PERFORMANCE_1_3_12_CAUSAL_STATE_COLLAPSE.md`
- `test_causal_state_collapse_1312.sh`
- `test_release_native_1312.sh`

Historical charter, release-note, proof, benchmark, and regression files remain in the package for auditability.

## Permanent execution red lines

```text
HARDWARE_WIDTH_IS_DEMAND_AUTHORITY=0
STATIC_EQUAL_WORK_PARTITION=0
PROPORTIONAL_EXECUTOR_SPLIT=0
EXECUTOR_ID_WORK_TOPOLOGY=0
WORK_STEALING=0
PUSH_BALANCING=0
PULL_BALANCING=0
PEER_LOAD_OBSERVATION=0
PEER_WORK_OBSERVATION=0
GLOBAL_LOAD_TABLE=0
GLOBAL_READY_QUEUE=0
GLOBAL_SURPLUS_COUNTER=0
POST_COMPLETION_WORK_SEARCH=0
FAILED_CLAIM_SPIN=0
RUNTIME_BALANCING_AUTOTUNE=0
OCCUPANCY_AS_OPTIMIZATION_TARGET=0

CAUSAL_WORK_IS_DEMAND_AUTHORITY=1
HARDWARE_WIDTH_IS_ONLY_CEILING=1
ANONYMOUS_SURPLUS_RELEASE=1
BLIND_CAPACITY_CLAIM=1
RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1
RESOURCE_ACQUISITION_IS_DONOR_BLIND=1
CLAIM_REQUIRES_PREEXISTING_CAUSAL_WORK=1
ACTIVE_SILICON_PURITY_IS_PRIMARY=1
```

## 1.3.12 General recurrence red lines

```text
SOURCE_VARIABLE_IS_PHYSICAL_STATE_AUTHORITY=0
CONTROL_STATE_CONSUMES_DATA_STATE_BUDGET=0
HARDCODED_TWO_STATE_REGISTER_LIMIT=0
MANDATORY_STATE_TEMP_SLOT_COMMIT=0
RUNTIME_STATE_ROLE_MANAGER=0
RUNTIME_REGISTER_SCHEDULER=0
FIBONACCI_SPECIALIZATION=0
WORKLOAD_NAME_SPECIALIZATION=0
BENCHMARK_SIZE_SPECIALIZATION=0
RUNTIME_RECURSION=DEFERRED
```
