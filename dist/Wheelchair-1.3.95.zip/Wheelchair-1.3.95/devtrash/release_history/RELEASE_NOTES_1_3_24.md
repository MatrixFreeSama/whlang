# Wheelchair 1.3.24 Release Notes

## Branch Extinction / Physical-DAG Closure

Wheelchair 1.3.24 removes the remaining source-shape optimization islands and compatibility-only execution routes found in the active 1.3.x production tree. Their useful mathematics is retained only after being absorbed into the existing ValueFact / Physical Reality / Physical DAG authority.

### Removed private/compatibility routes

- the General one-u64/f64-map-reduce fast-candidate gate;
- source-text frontend sniffing used to guess old semantic lanes;
- Field `OP_FACTOR2_ACC`, `OP_FACTOR_GROUP`, cross-output private supernodes and the fixed 12-op admission template;
- Tensor `x*x` plus exact-use-count last-consumer private admission;
- fixed periodic `axis±C` / `axis+n-C` AST matchers;
- fixed operator-subspace recursion-depth admission;
- fixed 16K/64K chunk geometry and chunk-derived reduction depth;
- historical executor/chunk compatibility CLI and parser routes;
- compatibility-only runtime resource-control aliases;
- Field generic backward ABI entries superseded by current Rank-N native entries;
- production use of `frozen_native` as source authority.

### Generalized replacement capabilities

- Common-factor contraction is now a generic ValueFact closure over ordinary MUL/FMA def-use relations. It admits three-or-more-term groups and creates no private opcode.
- Rank-N periodic coordinate recovery uses affine-mod canonicalization rather than matching one spelling of a periodic expression.
- Tensor copy elision is driven by post-materialization ValueFact authority and final-consumer lifetime, not by a square-specific branch.
- Tensor/Field leaf geometry is selected from the structural quantum, immutable target parallel width and outward-materialization price. Runtime owns no historical fixed chunk size.
- Scheduler overlap/carrier decisions use the common physical-price analysis and silicon profile rather than per-op `1/2/4`, divider=2 or memory=4 branches.

### Numerical contracts

Strict floating-point contracts remain bit-preserving. Tolerant programs are validated against their declared numerical contract instead of frozen historical reduction-order bits.

### Same-host evidence

Five-CPU AMD host, affinity 0-4, alternating whole-process runs:

- `chem6`, 20M steps: 165.38 ms -> 157.96 ms median, 1.047x.
- `ring8`, 10M steps: 54.10 ms -> 51.39 ms median, 1.053x.
- FSI, 100M elements: 57.40 ms -> 54.37 ms median, 1.056x.
- FSI steady-state slope from 10M/50M/100M: 0.562 ns/element -> 0.522 ns/element, about 1.076x throughput.

Short strongly causal probes remain approximately flat within host noise.
