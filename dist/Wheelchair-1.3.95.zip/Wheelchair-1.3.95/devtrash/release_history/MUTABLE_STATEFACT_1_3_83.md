# Mutable StateFact 1.3.83

## Law

Two mutable mathematical facts whose causal lifetimes overlap must never share
one writable physical authority merely because they have the same local state
ordinal.

## Realization

For state index `i` in one live `iterate` execution:

```text
current(i) = frame + 16*i
next(i)    = frame + 16*i + 8
```

R15 carries `frame` only inside the generated iterate episode. The frame size is
`16 * max_state_count`, rounded to the existing stack alignment. It is taken
from the already-existing execution stack and returned by a matching stack
adjustment when the episode finishes.

The physical demand therefore scales with simultaneous causal lifetime, not
with total source binding count.

## Regression that exposed the defect

Four independent non-affine recurrences each hold `{x,i}` and execute at the
same causal depth before a later join. In 1.3.82 all four `x` values mapped to
shared state slot 0 and all four `i` values to shared slot 1. Under `CLONE_VM`
this was a true writable-address race.

1.3.83 produces execution-local R15-relative loads/stores and twenty repeated
four-CPU runs are bit-exact against the independent mathematical result.
