# Wheelchair Charter 1.3.83

Wheelchair minimizes unnecessary physical work rather than maximizing hardware
occupancy.

1.3.83 adds one ownership law to the existing charter:

> A mutable StateFact has exactly one physical authority for its live causal
> lifetime. Independent live StateFacts do not coordinate over a shared writable
> slot. Dead StateFacts surrender their storage without choosing a recipient.

This law does not create a parallel-language model. Parallel execution remains
a consequence of causal independence and Physical Reality, never a user-visible
worker, barrier, task-pool, or stealing abstraction.
