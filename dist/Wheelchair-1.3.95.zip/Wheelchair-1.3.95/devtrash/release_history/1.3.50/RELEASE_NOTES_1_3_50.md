# Wheelchair 1.3.50 Release Notes

## Human-surface convergence

1.3.50 ages the WH/WHEX human surface by deleting independent syntax-family ceilings that no longer describe the underlying structural semantics.

The old `RANK_MAX=16` and declaration-by-rank rectangular stride table are gone. Rank metadata uses one flat stride-fact pool, so a declaration stores exactly the axes it owns. WH `for` and WHEX `each` no longer reject positive static extents merely because they are not powers of two. Power-of-two structure may still be exploited physically, but it is no longer a source-language law.

Compile-time `pure fn` is no longer a one-parameter abstraction. Formal parameters live in one flat lexical pool and calls are expanded with simultaneous hygienic substitution. Caller expressions are cloned outside the callee substitution context so a caller name that matches another formal parameter cannot be captured. The old sixteen-function and sixteen-argument Surface tables are retired.

Record fields, dictionaries, dictionary entries, nested facts, structured temporary metadata and cascade goals no longer own small independent Surface capacities. Cascade prerequisites are represented as explicit compile-time relation edges rather than a 64-bit completion mask. The historical fixed `work <= 1,048,576` cascade rejection is removed.

No lower execution capability is fabricated. The current General iterate-state boundary, runtime binding capacity, Tensor representation limits, Field ABI limits and advanced matrix-decomposition worksets remain unchanged. This release changes only compile-time human-surface structure and metadata ownership.

No compatibility parser or fallback path is retained for the retired ceilings.
