# Wheelchair 1.3.50 Human-Surface Convergence Correctness

The release gate proves both regression safety and removal of the retired Surface boundaries.

The inherited 1.3.49 final-release suite remains green. New boundary-crossing probes require:

- WH `for` and WHEX `each` with static radix 3 to compile to the same checksum;
- Rank 80 to compile through the existing one-runtime-extent Tensor product authority;
- an 80-parameter pure function and twenty separate pure declarations to compile and execute correctly;
- a lexical-capture case `foo(b, 2)` where caller axis `b` also names a formal parameter to evaluate correctly, proving simultaneous hygienic substitution;
- eighty record fields, one hundred forty dictionary entries and forty nested facts to cross their retired small tables;
- seventy cascade goals with sixty-nine dependency edges to cross both the old 32-goal table and machine-word dependency representation;
- cascade work of 1,048,577 to cross the deleted fixed work threshold.

Static source checks reject reintroduction of the retired `RANK_MAX`, `SCOPE_MAX`, `DECL_MAX`, dictionary/nested/cascade family caps, cascade prerequisite bit mask and fixed cascade-work comparison.

The gate does not require lower-layer limits to disappear. A limit is removed only where the Surface itself was the limiting authority.
