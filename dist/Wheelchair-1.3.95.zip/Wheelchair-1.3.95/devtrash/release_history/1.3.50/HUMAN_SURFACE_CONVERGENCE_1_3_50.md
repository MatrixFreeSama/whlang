# Wheelchair 1.3.50 Human-Surface Convergence

## One Surface fact authority

A syntax family may not invent a smaller semantic ceiling when the represented compile-time structure is already general. Surface metadata therefore derives its ordinary capacity from the existing AST fact arena instead of separate Rank, declaration, dictionary, nested, cascade and temporary-object tiers.

This is not an unlimited-memory claim. Exhausting the compiler fact arena is a compiler resource frontier. A real lower-layer representation boundary remains a boundary and is not relabeled as a human-surface feature.

## Rank and radix

Rank metadata is stored as a flat `(offset,count)` span into one stride pool. The former `declaration_count * Rank-16` rectangle is deleted. WH `for`, WHEX `each`, WHEX `field` and WHEX `sum` now agree that a static extent is any positive cardinality. Shift/mask realization remains an implementation opportunity for powers of two, never a parse-time requirement.

The release probe compiles Rank 80 with one runtime extent and seventy-nine static unit extents through the existing Tensor product authority. No second Rank backend is introduced.

## Pure lexical relations

`pure fn` parameters are compile-time lexical facts. Arity is represented by a flat parameter span and calls disappear before canonical emission. Expansion substitutes all formals in one tree walk. A substituted caller expression is cloned with callee substitution disabled, preventing accidental capture when caller and callee names coincide.

There is no runtime call ABI, closure object, dispatcher or compatibility one-argument path.

## Closed structures

Record, dictionary and nested objects remain compile-time-only structures. Their old per-family small tables are retired. Cascade causality is represented by an explicit predecessor edge list and completion facts, not a machine-word bit mask. The old fixed cascade-work rejection is deleted; actual compile-time work is governed by the represented work relation and ordinary compiler resources.

## Deliberately retained lower boundaries

This release does not change the General frontend/runtime state representation, General runtime binding capacity, Tensor dynamic-extent model, Field ABI/type/VREG model, structured matrix tag representation, or advanced matrix decomposition worksets. Those are lower or algorithmic capabilities and must be generalized at their own authority before the human surface can expose more.
