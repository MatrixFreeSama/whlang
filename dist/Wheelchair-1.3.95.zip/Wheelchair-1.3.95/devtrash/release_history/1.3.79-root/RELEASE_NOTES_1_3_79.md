# Wheelchair 1.3.79

1.3.79 is a test-closure release. Production compiler and runtime source are unchanged from 1.3.78, and all eight production compiler binaries are byte-identical.

## Current test authority

`./test.sh` is the only current-release entry point. The default mode rebuilds Wheelchair, runs the 12 explicitly admitted current regression scripts, and verifies the production zero-flip. `./test.sh coverage` runs native compiler coverage; `./test.sh all` runs both phases. Historical release tests remain available under `devtrash/` but are not silently promoted into the current suite.

## Native coverage

Coverage is measured outside the compiler. The test harness creates a temporary build with DWARF line metadata and observes executed statement addresses with one-shot `ptrace` breakpoints. Production binaries receive no counters, probes, wrappers, runtime manager, or alternate lowering path.

Current result:

- covered executable assembly source lines: 21,288
- linked executable assembly source lines: 48,569
- native compiler line coverage: 43.83%

The exact machine-readable result is stored in `NATIVE_COVERAGE_1_3_79.json`; the source breakdown is in `NATIVE_COVERAGE_1_3_79.txt`.

## Zero-flip

Testing has no backedge into production authority. `compiler/`, `runtime/`, `surface/`, `tools/`, and `build.sh` contain no coverage hook. The production hashes remain identical to 1.3.78.
