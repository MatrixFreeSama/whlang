# Testing

Run the current release suite with:

```sh
./test.sh
```

Run native coverage with:

```sh
./test.sh coverage
```

Use `./test.sh all` when one shell session should execute both. The test closure has three layers but one entry point.

1. The normal production build must succeed from the current handwritten source authority.
2. The explicit current regression set must pass. Historical tests under `devtrash/` are archive material unless admitted by `devtrash/release_tests/current.list`.
3. Native compiler coverage observes the already-existing implementation from outside the production path.

## Coverage definition

The denominator is the union of DWARF statement lines from the eight production compiler executables. Only executable locations originating in current `compiler/*.S`, `compiler/*.inc`, `runtime/*.S`, or `runtime/*.inc` source can enter the metric. Comments, documentation, archived sources, generated test files, and shell assertions do not inflate the denominator.

The numerator is the subset of those lines reached while compiling the existing observation corpus. The collector installs a software breakpoint at each statement address in a temporary DWARF-only build. Each breakpoint removes itself permanently after the first hit, because line coverage only asks whether a statement was reached at least once.

The coverage build is disposable. It cannot become a production input, and `test_test_closure_1379.sh` rejects any coverage backedge into production source or build authority.

Current result: `43.83% (21288/48569)`.
