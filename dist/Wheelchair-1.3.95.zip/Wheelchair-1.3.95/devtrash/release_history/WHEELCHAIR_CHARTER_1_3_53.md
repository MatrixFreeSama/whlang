# Wheelchair Charter 1.3.53 addendum

Advanced mathematical iteration depth is not an implementation identity.

- A mathematical relation may expose an optional final AOT-static refinement count when the existing relation genuinely contains a refinement budget.
- Omission selects a documented historical default only for convenience and source stability.
- Supplying the count must reuse the same relation and existing ValueFact / Structured Fact / Physical DAG authorities.
- Runtime algorithm selectors, named count-specific variants and named precision-specific solver families are forbidden.
- Dimension-driven finite algebra and coefficient/formula order are not to be disguised as iteration budgets.
- Mathematical admissibility remains mathematical admissibility and is not weakened by a larger iteration budget.
