# Architecture Aging 1.3.83

1.3.83 extends the same fact-lifetime rule already used by ValueFact,
AddressFact, RegionFact, and CoordinateFact to mutable General state.

## Missing layer

Before 1.3.83, semantic state lifetime and physical state ownership diverged.
The compiler measured only the largest local `iterate` state vector and reused
one shared absolute arena for every binding. That was valid only under serial
lifetime assumptions, while the causal physicalizer could correctly make
independent `iterate` fragments simultaneous.

## Aging rule

A mutable StateFact is owned by the causal execution in which it is live.
Current and next-version values share one execution-local frame. The frame is
created by generated code, not by a runtime allocator or scheduler. When the
causal episode returns, its StateFacts are dead and the same stack bytes become
available to later work.

This converts:

```text
local state ordinal -> shared absolute address
```

into:

```text
causal execution lifetime + local state ordinal -> execution-local address
```

without introducing a second IR or an ownership manager.

## Removed authority

The General shared persistent state arena and shared next-version mailbox are no
longer part of the target runtime layout. Anonymous integer temporaries no longer
borrow R15 because R15 is the generated StateFact-frame authority during an
`iterate` episode.

## What was not added

There is no lock repair, mutex, spin wait, worker pool, work stealing, global
ready queue, runtime owner map, state scheduler, or parallel-DSL execution path.
Independent mathematical facts receive independent physical authority; when the
facts die, their storage is naturally reusable.
