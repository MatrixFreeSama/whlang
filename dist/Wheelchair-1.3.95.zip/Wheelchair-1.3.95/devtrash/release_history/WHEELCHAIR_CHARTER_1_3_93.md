# Wheelchair charter — 1.3.93

1. Mathematical and physical facts remain distinct until a real law requires them to meet.
2. Traffic prices movement, locality and total realization cost; it does not invent arithmetic dependencies.
3. Issue/dependency facts own recurrence carrier width.
4. Physical Reality remains one authority. Orthogonal physical axes do not become separate optimizers, algorithms, or IRs.
5. Execution admission remains distinct from silicon locality.
6. x86 and fabric may coexist in one Physical DAG realization; neither becomes a source-visible kernel world.
7. No benchmark name, fixed problem-size threshold, fixed tile, fixed PE count, worker pool, work stealing, runtime idle-resource query, or compatibility backend may select execution semantics.
8. Optimization continues toward minimum necessary physical work, not maximum occupancy.
