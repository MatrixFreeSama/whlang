# Testing 1.3.86

The current release authority remains 17 tests.

The 1.3.86 silicon-domain identity gate verifies:

- one shared production domain-identity probe;
- APIC/cache identity rather than Linux CPU-number adjacency;
- exact admitted-domain counts and intersections in the machine-readable contract;
- restoration to zero semantic change on General and Field probes;
- no runtime topology probe, idle-capacity query, worker/task model, HLS route, kernel language, fixed PE/tile authority, or target-private semantic IR.

The complete release suite also retains all active mathematical/physical convergence, CoordinateFact, mutable StateFact, human-shell, GroupFact, Traffic Reality, RegionFact, and machine-burn gates.
