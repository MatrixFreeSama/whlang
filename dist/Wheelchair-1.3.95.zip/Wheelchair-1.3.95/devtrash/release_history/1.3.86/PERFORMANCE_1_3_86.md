# Performance 1.3.86

## Generated-program execution

The release host exposes five admitted x86-64 execution contexts, one visible NUMA node, and one admitted L3 domain. The stronger 1.3.86 identity proof therefore resolves the same L3 execution ceiling as 1.3.85.

`mass3`, `chem6`, and `rigid7` were compiled once with 1.3.85 and once with 1.3.86. Every corresponding executable is SHA-256 identical:

- `mass3`: `9e73aefc35551713059f42c66af69c5a889415200de4fab283f4f853b2bf17e8`
- `chem6`: `3f651f3cdea49280be4b4851cb4faa717cb68ea020d8706b70ffd0c550d21cbd`
- `rigid7`: `9a199896c98fcb9d2de3f821b57ee16aa229a22efa92785ff480ec7583ef9bf0`

Therefore generated-program acceleration on these probes is **0% by construction**.

A 12-repetition interleaved wall-time sample at 20,000,000 steps produced a geometric-mean observed ratio of about `1.0100x` for 1.3.86 over 1.3.85. Because the executable bytes are identical, this is environmental measurement noise and is not counted as speedup.

## Compiler cost

The exact admitted-domain identity probe performs compile-time affinity/APIC observations. Across 20 repetitions of the same three tiny programs, median compile time increased by about `0.20 ms` on average, corresponding to roughly 15% relative overhead because the baseline compiles complete in only 1–2 ms.

This is an explicit current cost of deeper target proof. It does not enter generated-program runtime and should be reduced only by converging the same proof, not by reintroducing guessed topology or a runtime scheduler.

Raw measurements are in `devtrash/benchmarks/silicon_domain_1386/`.
