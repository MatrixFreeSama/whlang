# Pure assembly release proof 1.3.86

The production compiler/runtime path remains handwritten x86-64 assembly with direct ELF emission. The new domain-identity implementation is `compiler/silicon_domain_probe_x86_64.S` and is linked directly into `topologyc` and `fieldc`.

The probe uses Linux affinity syscalls only as compile-time observation machinery. It restores the compiler process affinity before returning and does not create a program runtime scheduler or worker model.

No C, LLVM, JIT, Python generator, bytecode VM, HLS compiler, FPGA toolchain, or ASIC toolchain is part of production build authority.
