# Wheelchair 1.3.86 release notes

## Silicon domain identity

1.3.85 introduced silicon-domain widths and hierarchy. 1.3.86 removes the remaining cardinality approximation: `min(allowed_execution_contexts, cache_share_width)` is no longer treated as proof that the admitted CPUs occupy one physical cache domain.

The production compiler now uses one shared handwritten-assembly domain probe. It temporarily constrains the compiler process to each externally admitted logical CPU, reads that CPU's architectural APIC identity, groups those identities by the deterministic cache-sharing widths, and restores the original affinity mask before compilation continues. The result is the actual admitted L1D/L2/L3 domain count and maximum admitted intersection for the target visible to the compiler.

Linux CPU numbers are not treated as die coordinates. Vendor/model names do not select execution routes. Unknown geometry remains unknown.

## Convergence

The duplicated affinity-popcount path in `fieldc` and the old `topologyc` runtime-topology routine are retired from production authority. General/Tensor and Field consume the same silicon-domain identity result.

No worker pool, task scheduler, kernel language, HLS route, fixed PE/tile count, occupancy objective, target-private semantic IR, idle-capacity query, or runtime topology autotuner is added.

The silicon contract advances to `wheelchair.silicon-reality/3`; the audit advances to `topology.silicon-audit/4`.

## Performance

On the release host, the five admitted execution contexts are still inside one L3 domain. The `mass3`, `chem6`, and `rigid7` whole-episode executables produced by 1.3.85 and 1.3.86 are byte-identical. Generated-program acceleration on these probes is therefore exactly **0%**.

An interleaved timing sample showed about `1.0100x` geometric-mean wall-time speedup, but byte-identical machine code makes that measurement noise rather than a release performance claim.

The stronger compile-time topology proof costs about `0.20 ms` per compile on this host in the small three-kernel sample, roughly a 15% relative increase only because these compiles themselves take around 1–2 ms. This cost is outside generated-program execution and is retained explicitly rather than hidden.
