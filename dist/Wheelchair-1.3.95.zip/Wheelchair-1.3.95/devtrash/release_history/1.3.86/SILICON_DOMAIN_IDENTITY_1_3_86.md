# Silicon Domain Identity 1.3.86

## Problem removed

A cache-sharing width is capacity, not identity.

If an L3 reports a sharing width of 8 and the OS admits 8 logical CPUs, those eight CPUs are not necessarily members of one L3 domain. A pure `min(allowed, share_width)` rule therefore confuses cardinality with physical membership.

## Current authority

1.3.86 closes that gap at compile time:

```text
external affinity set
        x
architectural APIC identities
        x
L1D/L2/L3 sharing widths
        ->
actual admitted domain intersections
```

For every admitted logical CPU, the compiler briefly applies a single-CPU affinity mask, reads architectural APIC identity, records cache-domain identity, and restores the original affinity mask before continuing. This is target discovery only. It never observes CPU load, free capacity, queue state, recipients, or program work.

The contract exposes:

- `l1d_admitted_domain_count`
- `l1d_max_admitted_intersection`
- `l2_admitted_domain_count`
- `l2_max_admitted_intersection`
- `l3_admitted_domain_count`
- `l3_max_admitted_intersection`
- `domain_identity_exact`

`locality_domain_execution_ceiling` is now derived from the largest actually admitted L3 intersection when exact identity is available. Cardinality-only arithmetic survives only as a conservative probe-failure degradation.

## Release-host observation

The release host admits five logical CPUs. Architectural sharing widths report two logical contexts for L1D and L2 and sixteen for L3. The exact admitted identity probe finds:

```text
L1D: 3 admitted domains, largest intersection = 2
L2 : 3 admitted domains, largest intersection = 2
L3 : 1 admitted domain,  largest intersection = 5
```

This is the distinction 1.3.85 could not represent: the target exposes several near domains even though the full admitted set remains inside one LLC.

## Boundary

1.3.86 still does not invent cache-to-cache latency, mesh distance, die coordinates, DRAM channel hashes, µop-port routing, or transistor addresses. Those quantities can participate only when the target exposes a trustworthy fact. The absence of a fact is not replaced by a guessed constant.

This release also does not yet pin generated program regions to a compiled cache-domain mask. Domain identity is now correct; target placement remains a later physical realization step.
