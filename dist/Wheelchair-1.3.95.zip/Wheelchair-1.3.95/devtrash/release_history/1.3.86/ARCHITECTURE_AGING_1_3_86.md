# Architecture aging 1.3.86

1.3.86 is a convergence release, not a new backend family.

The old shape was:

```text
allowed CPU count
        +
cache sharing width
        -> min(...)
```

That result was only a cardinality bound. It could not prove cache-domain membership.

The aged shape is:

```text
Physical DAG                 target affinity set
     |                               |
Traffic / Region             APIC + cache identity
     |                               |
     +----------- Physical Reality --+
                         |
                   realization
```

The production source gains one shared `silicon_domain_probe_x86_64.S`. The former private affinity counting in Field and the old `detect_runtime_topology` block in `topologyc` are removed from active authority.

Hard exclusions remain unchanged: no user-visible hardware kernel, no worker/task ontology, no fixed tile or PE count, no source-size crossover, no runtime idle-resource query, no work stealing, no target-private semantic graph, and no device-name route.
