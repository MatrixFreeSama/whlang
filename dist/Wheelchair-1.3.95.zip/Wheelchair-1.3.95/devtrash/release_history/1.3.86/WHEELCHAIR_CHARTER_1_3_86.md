# Wheelchair charter 1.3.86

Wheelchair remains a general-purpose AOT language whose execution authority is structural rather than sequential or parallel by declaration.

The program supplies mathematical, causal, state, address, effect, capability, traffic, and lifetime facts. The target supplies only physical facts it can actually expose. Physical Reality closes the two without changing semantics.

For silicon space:

```text
mathematical relation decides why locality matters
silicon identity decides which locality boundaries actually exist
physical cost decides realization
```

CPU numbers are labels, not geometry. Cache width is capacity, not membership. Unknown physical distance stays unknown. Idle hardware is not a defect. Runtime load is not a semantic input. A target may degrade realization but may not create a second program.

FPGA or ASIC realization, if added later, must consume the same Physical DAG and facts directly. It must not introduce a hardware-kernel sublanguage, a user-managed processing-element grid, or an HLS compatibility world.
