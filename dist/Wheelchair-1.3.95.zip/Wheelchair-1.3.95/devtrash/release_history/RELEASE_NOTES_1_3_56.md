# Wheelchair 1.3.56

Final compiler-workspace aging pass over the remaining safe-to-remove capacity walls.

- Field count and access count are instance-sized across Surface/frontend/generated metadata/runtime; the old 8-field and 128-access capacities are gone rather than enlarged.
- Tensor scalar/vector/init staging is growable with whole-AOT replay; fixed 4-MiB staging and 524,288-fixup warehouses are removed.
- Tensor constant and affine-linear optimizer metadata is sized from the parsed graph; the old 512/2048 fact tiers are removed.
- A permanent gate executes 10 fields / 130 accesses and a strict Tensor expression with 600 distinct constants.
- Existing Rank-8 `WHFLD216`, four-logical-VREG Field physicalization and Tensor one-runtime-extent semantics remain explicit because changing them would add a new representation or physicalizer rather than age a workspace.
- Mature Newton-Jv output remains byte-identical to the protected baseline.
