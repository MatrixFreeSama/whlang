# Wheelchair 1.3.60

Compiler convergence release. A latent unary-call AST hygiene bug exposed by nested `pure fn` composition is closed at the shared call-construction boundary, so unused AST children cannot inherit parser scratch and later masquerade as pointers during structural cloning.

The existing decimal scientific-notation grammar is also completed end-to-end. `1e-13` and `1.0e-13` now reach the same numeric authority. The four current Tensor/General consumers share one executable f64 literal parser instead of carrying copied parser bodies.

No stdpf-specific route, proof runtime, theorem kernel, helper threshold, algorithm family, runtime scheduler, ISA path, or fallback backend is added. Existing mature workloads remain byte-identical. The release gate compiles a 512-function composition, the full 148-helper stdpf-1909261354 fixture, scientific notation across all four consumers, and the inherited 1.3.59 probes.
