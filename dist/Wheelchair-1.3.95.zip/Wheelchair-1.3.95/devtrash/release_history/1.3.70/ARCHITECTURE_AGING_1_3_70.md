# Wheelchair 1.3.70 architecture aging

## Goal

Human execution form must not become a physical-performance authority when the same semantic relation can be proved from existing facts. 1.3.70 therefore continues the 1.3.68/69 convergence line rather than adding a recursion optimizer family.

## One authority chain

```text
human source
  -> Surface AST witnesses
  -> execution-form proof
  -> existing collected iterate facts
  -> General causal relation
  -> Rank-N / ValueFact closure
  -> Physical Reality / Physical DAG
  -> ISA
```

`NK_RECUR_CALL`, `NK_RECUR_DEF`, and `NK_RECUR_APPLY` are Surface-only witnesses. They cannot serialize into canonical JSON. A successful proof erases them into the old iterate representation before General sees the program. No recurrence IR survives beside the old authority.

The explicit iterate parser was correspondingly aged: its serialization is now factored through `s_emit_collected_iterate_binding`. Both handwritten `iterate` and proved recursion populate the same state/update/condition/result facts and use that one emitter.

## Structural recurrence proof

For the current admitted class, Surface proves:

- integer overflow contract is wrap;
- recursive function result is `u64`;
- one branch is nonrecursive base data and one branch is recursive step data;
- self calls use a fixed positive backward lag `k-d`;
- every additional recursive-call argument is the same immutable lexical formal;
- the maximum lag `K` is derived from the relation itself;
- the base guard partitions exactly the structural span `0..K-1`;
- the step is autonomous with respect to the recurrence axis outside self-call indices;
- admitted arithmetic is total under the current wrap-u64 proof.

The compiler then forms the semantic window `[F(t), ..., F(t+K-1)]`, replaces `F(k-d)` with old-state lane `K-d`, and emits an ordinary `K+1`-state iterate (the extra state is the existing repeat counter). The General backend independently decides whether the resulting relation satisfies its existing Rank-N affine transition-power proof.

No constant in this process decides that `K` is small enough. Storage is compiler-only workset memory sized from the proved relation.

## Aging rules preserved

- no named-algorithm matcher;
- no runtime memo/cache for recursion;
- no second recursive/recurrence IR;
- no fixed order, state-count or recursion-depth threshold;
- no runtime selector;
- no special ISA route in Surface;
- no approximate fallback when proof fails;
- existing Physical Reality remains the only downstream physical choice authority.

## Human-shell cleanup

Exact pure-function identity now precedes declaration typo repair. This removes an old accidental penalty on one-letter mathematical names (`f`, `g`, `r`, etc.) without creating another identifier namespace or compatibility parser.
