# Wheelchair 1.3.70 release notes

## Execution-form convergence

1.3.70 extends the existing human semantic convergence across execution spelling. A pure self-recursive `u64` relation may now disappear before canonical General emission when the Surface can prove one finite fixed-lag, autonomous, total wrap-u64 recurrence. The relation is not handed to a recursive runtime. Its structural lag window is projected directly into the same collected `iterate` facts already used by explicit state iteration, after which the existing General causal graph, Rank-N affine closure, Physical Reality and ISA authorities take over.

The classic two-lag recursive sandbag therefore remains textbook-naive at the source and still reaches the old `rankn_affine_power_u64` transition-power kernel. The release gate additionally exercises unrelated affine second-order and third-order relations, a structural lag span of 17, and an invariant extra function argument. Lag span is data derived from the dependency relation; it is not a fixed-order admission family.

## Human spelling loses more authority

A one-character ASCII pure-function name such as `f` is now an exact callable identity before optional declaration typo repair. Users no longer need to lengthen mathematical function names merely to avoid the human-shell repair heuristic.

Equivalent guard orientation is also structural. For the admitted recurrence class, `k < K { base } else { step }` and the corresponding reversed recurrence-first form recover the same old iterate relation rather than creating separate backends.

## Deliberate exclusions

There is no recursion runtime, memoization service, recurrence-specific IR, recursive backend, workload-name matcher, fixed recursion-depth threshold, fixed lag/order limit, runtime selector, JIT, or autotuner. The production path contains no Fibonacci/FFT/Newton/etc. admission branch.

The proof is intentionally conservative. Direct dynamic dependence on the recurrence axis in the step, non-static recursive lags, trap-sensitive arithmetic, and other unproved recursive forms are not silently reinterpreted. 1.3.70 does not create a generic recursive fallback merely to accept those spellings.

## Regression

The new execution-form release gate passes. The inherited 1.3.67 Rank-N transition-power, 1.3.68 identity semantic convergence, 1.3.69 proof-level semantic convergence, 1.3.60 pure-composition, and 1.3.50 human-surface gates also pass. Current 1.3.66 Group aging remains enforced by the production build.
