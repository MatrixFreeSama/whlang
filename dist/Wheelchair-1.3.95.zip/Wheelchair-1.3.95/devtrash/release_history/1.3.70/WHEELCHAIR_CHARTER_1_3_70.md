# Wheelchair 1.3.70 charter

1. Human execution spelling is not a performance authority. If recursion, iteration, or explicit state describe one proved relation, their surface identity should disappear before physical realization.
2. Users are not required to reformulate ordinary mathematics into the compiler's favorite affine syntax merely to unlock an existing generic capability.
3. Semantic zero-flip is absolute. Proof failure means no convergence, never an approximate rewrite.
4. A new human form must converge into an old semantic/physical authority. A recursive runtime, recurrence IR, memo service, or compatibility backend is forbidden as a convenience shortcut.
5. Algorithm names are not admissibility facts. Fibonacci, Newton, FFT, Krylov, stencil, sorting, and benchmark identities must not select production routes.
6. Structural size is data. Recurrence order/lag span, state count, and recursion depth must not acquire fixed numeric admission thresholds.
7. Physical choice remains downstream in the existing ValueFact / ShapeFact-N / GroupFact / Physical Reality / Physical DAG chain.
8. Human-shell repair may not override an exact lexical mathematical identity. One-letter names are first-class when they are exact bindings/callables.
9. Runtime work must not be introduced merely to recover structure that AOT proof can erase.
10. New capability should age toward invisibility: as the proof matures, fewer modules should need to know whether the human source was recursive, iterative, or explicitly stateful.
