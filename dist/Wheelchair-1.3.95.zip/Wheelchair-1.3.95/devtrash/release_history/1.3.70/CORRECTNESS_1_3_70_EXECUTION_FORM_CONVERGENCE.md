# Wheelchair 1.3.70 correctness: execution-form convergence

## Zero-flip condition

The new lowering is admitted only after a semantic proof. It is not legal because two programs merely return the same value on a benchmark.

For a proved lag span `K`, the recursive definition has a base domain covering exactly `0 <= k < K` and an autonomous step whose only uses of the recurrence axis are fixed-lag self-call indices. The compiler initializes the old iterate state window with the exact base expressions at `k=0..K-1`. Each transition shifts the window and evaluates the proved step after replacing each self call `F(k-d)` by the corresponding old state. Therefore after `N` transitions state lane zero denotes `F(N)`.

Wrap-u64 totality is required because the recovered window may compute future lanes that were not demanded by the original recursive call tree. Total arithmetic prevents those causally irrelevant calculations from introducing a new trap/observable event.

## Positive gates

The release gate verifies:

- naive two-lag recursion at `N=0,10,100,500000000`;
- actual machine-code call to the existing `rankn_affine_power_u64` helper;
- byte-identical `.text` versus the older handwritten explicit-iterate form of the same relation;
- a different affine second-order recurrence;
- a third-order recurrence;
- a lag-17 recurrence, proving order is structural data rather than a tiny fixed family;
- an additional immutable function parameter;
- one-letter function syntax through `f(k)`.

## Refusal gates

Compilation must reject rather than reinterpret:

- a step with direct dynamic recurrence-axis dependence;
- a recursive lag that is not AOT-static;
- the same recurrence under the trap-overflow contract.

These rejects are intentional. 1.3.70 does not add a generic recursive runtime fallback, because doing so would create a second execution authority solely to preserve an unproved human spelling.

## Historical regression

The 1.3.67 transition-power, 1.3.68 semantic identity, 1.3.69 proof relations, 1.3.60 pure composition and 1.3.50 human-surface release tests pass against 1.3.70 with only historical exact-version assertions adapted where necessary.
