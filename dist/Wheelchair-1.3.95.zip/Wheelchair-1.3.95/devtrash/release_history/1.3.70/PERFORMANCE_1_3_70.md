# Wheelchair 1.3.70 performance note

1.3.70 changes the complexity reachable from naive human source; it does not claim a universal instruction-throughput speedup.

The release's central performance proof is machine-text convergence. The naive recursive two-lag source:

```text
f(k) = k,                         k < 2
f(k) = f(k-1) + f(k-2),           otherwise
```

and the historical handwritten two-state `iterate` source compile to byte-identical `.text`. Both contain an actual call to the existing Rank-N affine power helper. Consequently the recursive surface pays no retained recursive-call-tree or runtime-memoization cost after AOT convergence.

For a proved affine fixed-lag relation, the old General path may represent repeated application by binary transition composition, so execution depth depends logarithmically on the repeat count rather than on the exponentially expanded naive call tree. That complexity collapse belongs to the existing 1.3.67 Rank-N transition-power authority; 1.3.70 merely allows a much less polished human spelling to reach it.

The release gate also reaches transition power from unrelated second-order, third-order, lag-17 and invariant-parameter recurrences. No workload-specific speed claim is inferred from the classic sandbag.

Representative downstream code remains unchanged versus 1.3.69 for unrelated paths:

- Automatic Grouping probe generated ELF SHA-256: `dde7b79907071c34c2faf22e3432ed4ad10cfcc906f0b56fa0f6f5dd4d2ac15b` in both releases.
- Field sum generated ELF SHA-256: `46b0c01d91e96bb8d273a7f545d5a64095f1c270bd02ef3c6388ced2c25ed57d` in both releases.
- strict-FP `mass3.wh` `.text` SHA-256: `bb28c43d8c8b1251943905d59f56998483194fb4922397ad982a9415394aa578` in both releases.

These identities are boundary evidence: 1.3.70 widens the upstream human forms that can reach mature downstream optimization without perturbing unrelated Tensor/Group, Field, or strict-FP realization.
