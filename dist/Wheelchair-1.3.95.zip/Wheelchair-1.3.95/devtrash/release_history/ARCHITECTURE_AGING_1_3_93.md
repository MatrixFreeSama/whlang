# Architecture aging — 1.3.93

1.3.93 separates two physical axes that had been collapsed into one scalar bound.

```text
compute issue / dependency -> recurrence and carrier width
transport / Traffic Reality -> movement, locality and total realization cost
```

The axes still meet in the common Physical Reality cost. They do not become separate schedulers or IRs.

The release adds no workload route, no special reduction backend, no runtime bandwidth sampler, no worker/task system, and no fixed width table. Existing x86/fabric joint placement and execution-admission architecture remain unchanged.

The intended invariant is simple: an expensive movement can make an execution expensive, but it cannot by itself prove that two independent arithmetic recurrences have become one recurrence.
