# Pure assembly release proof 1.3.87

The production compiler/runtime path remains handwritten x86-64 assembly with direct ELF emission.

The static placement implementation extends the existing shared `compiler/silicon_domain_probe_x86_64.S`. Tensor, Field, and General frontends burn the proven placement fact directly into their generated runtime images. Generated runtimes use one direct `sched_setaffinity` system call only when the baked target fact requires it. No C runtime, LLVM, JIT, Python generator, bytecode VM, HLS compiler, FPGA toolchain, or ASIC toolchain is part of production build authority.

The affinity call is realization machinery, not a runtime scheduler: it does not inspect load, free capacity, queues, recipients, or program work, and it performs no placement search or migration loop.
