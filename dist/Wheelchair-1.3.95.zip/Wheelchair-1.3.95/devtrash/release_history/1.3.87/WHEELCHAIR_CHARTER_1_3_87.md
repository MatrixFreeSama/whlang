# Wheelchair charter 1.3.87

Wheelchair remains a general-purpose AOT language. Structural execution is neither sequential nor parallel by declaration.

The program supplies mathematical, causal, state, address, effect, capability, traffic, and lifetime facts. The target supplies physical facts it can actually prove. Physical Reality closes the two without changing semantics.

For silicon space:

```text
mathematical structure decides relation
causal depth decides time
Traffic x exact domain identity decides locality pressure
fact lifetime decides storage lifetime
GroupFact x target carriers decides multiplicity
Physical Reality decides realization
```

CPU ordinals are not geometry. Cache sharing width is not domain identity. Unknown physical distance remains unknown. Idle silicon remains valid. Runtime load is not a semantic input. Placement may constrain where an execution is admitted, but it may not create a second program or a second scheduling ontology.

A future FPGA or ASIC realization must consume the same Physical DAG and facts directly. It must not turn Wheelchair into a hardware-kernel DSL, user-managed processing-element grid, pragma-driven HLS dialect, or parallel-language compatibility layer.
