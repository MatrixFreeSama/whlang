# Performance 1.3.87

## Generated-program execution

The release host exposes five admitted execution contexts inside one exact admitted L3 domain. Consequently the new static placement mechanism resolves to `static_placement_required=0` on this machine.

`mass3`, `chem6`, and `rigid7` were compiled once with frozen 1.3.86 and once with 1.3.87. The 1.3.87 images are 224 bytes larger, uniformly, because the runtime now contains the one-shot placement guard and baked-mask storage. On this host the placement branch exits immediately and does not enter the mature computation loop.

Twelve interleaved whole-episode repetitions at 20,000,000 steps, externally pinned to CPU 0, produced these median ratios:

| probe | 1.3.86 median | 1.3.87 median | 1.3.87 / 1.3.86 |
| --- | ---: | ---: | ---: |
| mass3 | 0.151607 s | 0.152997 s | 0.99091x |
| chem6 | 0.142767 s | 0.142988 s | 0.99845x |
| rigid7 | 0.245778 s | 0.243627 s | 1.00883x |
| geometric mean | | | **0.99937x** |

The geometric-mean difference is approximately **-0.06%** and is treated as measurement noise. No generated-program speedup is claimed on this single-L3 host.

The new path is intended to remove avoidable cross-LLC placement when an externally admitted target actually spans multiple exact L3 domains. That condition is absent here, so no cross-domain performance number can be measured honestly in this release environment.

## Compiler cost

Twenty interleaved compile repetitions per probe show no resolvable additional cost beyond the 1.3.86 exact identity probe. The geometric-mean compile-time ratio is approximately `0.99372x`; individual median deltas range from about `-0.056 ms` to `+0.029 ms`, so this is retained as environmental noise.

Raw data and generated comparison images are stored under `devtrash/benchmarks/silicon_static_placement_1387/`.
