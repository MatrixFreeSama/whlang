# Silicon static placement 1.3.87

## Closed gap

1.3.86 answered which admitted execution contexts belong to the same cache domain. It did not yet make that identity executable.

1.3.87 turns exact L3-domain identity into an AOT placement fact:

```text
Traffic x exact admitted L3 identity
                 ->
        preferred physical domain
                 ->
       baked affinity-domain mask
                 ->
        inherited realization
```

The target probe constructs exact admitted L1D, L2, and L3 identities from architectural APIC identity and cache-sharing geometry. When more than one exact admitted L3 domain exists, it selects the largest admitted L3 intersection. A tie is resolved by architectural domain identity, not by Linux CPU ordinal.

The generated Tensor, Field, and General runtimes receive the same placement fact. They do not rediscover topology. When placement is required, the process applies the baked mask once at entry. Outward executions inherit it naturally.

## Failure law

Placement is an optimization fact, not a semantic fact. If the one-shot operating-system affinity request is rejected, program semantics do not change. There is no retry search and no alternate placement algorithm.

If exact domain identity cannot be established at compile time, 1.3.87 no longer falls back to `min(allowed, cache_width)`. The physical execution ceiling becomes one. Unknown space stays unknown.

## Release-host observation

The release host admits five logical CPUs and one exact admitted L3 domain:

```text
L1D: 3 admitted domains, largest intersection = 2
L2 : 3 admitted domains, largest intersection = 2
L3 : 1 admitted domain,  largest intersection = 5
```

Therefore:

```text
static_placement_exact = 1
static_placement_required = 0
preferred_l3_execution_contexts = 5
```

No cross-L3 placement action is performed on this host.

## Boundary

This release does not claim die-coordinate placement, cache-to-cache latency, mesh distance, DRAM-channel identity, exact micro-op port routing, FPGA place-and-route, ASIC floorplanning, or transistor addressing. Those may enter Physical Reality only when the target exposes a trustworthy fact.
