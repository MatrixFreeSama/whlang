# Testing 1.3.87

The current release authority contains 18 tests.

The 1.3.87 silicon static-placement gate verifies:

- exact domain identity remains the source of placement facts;
- cardinality fallback is absent;
- the contract publishes AOT inherited placement and no runtime selector;
- Tensor, Field, and General runtimes contain only the one-shot inherited placement mechanism;
- the generated Field executable receives the same placement requirement published by the target contract;
- placement does not create a worker/task/kernel ontology, fixed PE/tile authority, migration loop, or second semantic IR;
- existing Field output remains byte-correct after the new runtime fact is burned.

The complete release suite retains mathematical/physical convergence, CoordinateFact, mutable StateFact, human-shell behavior, GroupFact, Traffic Reality, RegionFact, machine-burn, silicon realization, silicon-domain graph, and exact domain-identity gates.
