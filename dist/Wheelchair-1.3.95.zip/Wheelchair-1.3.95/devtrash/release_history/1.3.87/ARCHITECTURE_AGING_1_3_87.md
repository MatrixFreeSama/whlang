# Architecture aging 1.3.87

1.3.87 closes the next missing link in silicon-space realization. 1.3.86 could prove exact admitted cache-domain identity, but generated programs still left placement entirely to the operating system.

The aged shape is:

```text
mathematical Physical DAG
        |
Traffic / Region / lifetime / GroupFact
        |
        +------------------------------+
                                       |
external affinity set                  |
        x                              |
exact APIC/cache-domain identity       |
        |                              |
        +------ Physical Reality ------+
                       |
              AOT placement fact
                       |
              generated executable
```

The compiler selects one exact admitted L3 domain when the externally admitted set spans multiple L3 domains. The largest exact admitted intersection is selected; equal-capacity domains are ordered by architectural domain identity, never by Linux CPU-number adjacency. The resulting affinity mask is burned into the executable.

At process entry the generated runtime applies that mask once only when the target proof says it is required. Outward executions inherit the same operating-system affinity domain. There is no runtime resource search, load query, migration loop, recipient table, ready queue, or placement scheduler.

The 1.3.86 cardinality compatibility approximation is deleted. If exact identity cannot be proven, locality capacity collapses conservatively to one execution instead of guessing a cache domain from counts.

The placement fact is a target realization of the existing Physical DAG. It does not create a hardware sublanguage, a second semantic graph, user-visible processing elements, fixed tiles, or a special FPGA/ASIC program model.
