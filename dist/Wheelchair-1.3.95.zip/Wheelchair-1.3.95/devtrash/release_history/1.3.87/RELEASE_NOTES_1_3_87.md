# Wheelchair 1.3.87 release notes

## Exact silicon-domain placement becomes executable

1.3.86 established exact admitted cache-domain identity. 1.3.87 closes the next layer: that identity now participates directly in generated-program placement.

The shared silicon probe derives an exact preferred admitted L3 domain. If the external affinity set spans multiple L3 domains, the compiler burns that domain mask into Tensor, Field, and General executables. The generated runtime applies the mask once at entry; outward executions inherit it. No runtime topology discovery or placement decision is introduced.

The machine-readable contract advances to `wheelchair.silicon-reality/4`; the silicon audit advances to `topology.silicon-audit/5`.

## Convergence and deletion

The old cardinality fallback is removed. Probe failure no longer guesses locality capacity from `min(allowed execution contexts, cache sharing width)`; it conservatively exposes one execution until exact physical identity is known.

Linux CPU ordinals remain labels rather than geometry. Vendor/model names remain diagnostic. No fixed source-size crossover, fixed processing-element count, tile size, user-visible hardware kernel, worker/task ontology, ready queue, work stealing, runtime silicon allocator, or target-private semantic IR is added.

The new placement implementation reuses one shared physical fact across General, Tensor, and Field instead of creating target-specific schedulers.

## Performance

The release host has one exact admitted L3 domain, so static placement is not required there. Twelve interleaved whole-episode measurements of `mass3`, `chem6`, and `rigid7` give a geometric-mean 1.3.87/1.3.86 ratio of about `0.99937x`, approximately `-0.06%`, which is retained as noise rather than reported as a regression or speedup.

The generated images are 224 bytes larger because the placement guard and baked-mask area now exist. No cross-LLC acceleration is claimed without a cross-LLC target.
