# Fabric realization descriptor — 1.3.90

1.3.90 serializes the already-closed heterogeneous Physical DAG into one compact target descriptor per General Region.

Descriptor format 1 is 48 bytes:

| Offset | Width | Fact |
|---:|---:|---|
| 0 | 4 | Region id |
| 4 | 4 | realization tag |
| 8 | 8 | work ticks, or all ones when unbounded |
| 16 | 8 | incident Physical Edge transfer bytes, or all ones when unknown |
| 24 | 8 | shared causal completion entry offset |
| 32 | 8 | incident Physical Edge count |
| 40 | 8 | descriptor format version |

The descriptor is derived from the same Region DAG, work facts, Physical Edge Facts, target placement and completion law already used by the compiler. It is not a second semantic IR.

`gr_fabric_descriptor_for_node` exposes the corresponding record. `gr_publish_completion` remains the only successor-publication authority.

A fabric-tagged image with no proved activation bridge is rejected before Region execution. There is no x86 compatibility fallback.

1.3.90 does not contain a board driver, RTL emitter, place-and-route integration or bitstream emitter. Those remain target realization work.
