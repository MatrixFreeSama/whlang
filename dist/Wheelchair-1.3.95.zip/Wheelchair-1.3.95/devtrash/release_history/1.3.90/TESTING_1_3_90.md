# Testing — 1.3.90

The current release authority contains 21 tests.

The new `test_fabric_realization_descriptor_1390.sh` verifies:

- contract format `wheelchair.silicon-reality/7`;
- descriptor format 1;
- descriptors are physically present in a real generated General image;
- production fabric Region count is zero;
- proof-only mixed placement remains `2,2,1,2,1`;
- three proof fabric Regions are counted exactly;
- every descriptor references the shared completion entry;
- unbridged mixed execution is rejected without semantic output;
- native fabric fallback, second fabric IR, kernel/HLS syntax and runtime device scheduling remain absent.

All earlier current-authority tests remain active.
