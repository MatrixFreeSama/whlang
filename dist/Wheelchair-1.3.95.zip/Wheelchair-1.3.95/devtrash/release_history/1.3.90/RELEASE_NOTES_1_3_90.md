# Wheelchair 1.3.90 release notes

- Added format-1 Physical Realization Descriptors for General Regions.
- Added `gr_fabric_descriptor_for_node` as a target-integration boundary.
- Preserved `gr_publish_completion` as the single causal completion authority.
- Added fabric Region count to generated runtime state.
- Added hard admission: mixed fabric images cannot execute without a proved activation bridge.
- Explicitly forbids native x86 fallback for fabric-tagged Regions.
- Upgraded Silicon Reality contract/audit format to `/7`.
- Kept production fabric facts at zero; no hardware is fabricated.
- Kept source syntax, Physical DAG semantics and x86 mathematical results unchanged.
- No RTL, place-and-route or bitstream claim is made.
