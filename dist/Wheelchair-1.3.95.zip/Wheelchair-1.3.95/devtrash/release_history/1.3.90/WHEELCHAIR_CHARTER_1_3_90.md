# Wheelchair charter — 1.3.90

Wheelchair expresses program facts once and closes them against physical reality.

For heterogeneous silicon:

1. The Physical DAG remains the only program graph.
2. x86 and reconfigurable fabric may realize different Regions simultaneously.
3. Target resources are facts, never source annotations.
4. Cross-domain traffic belongs to Physical Edge Facts.
5. A realization descriptor may serialize facts but may not become a second semantic IR.
6. Completion has one causal authority across every physical domain.
7. Missing hardware is absence, not permission to fall back to another domain.
8. No worker pool, task graph, kernel language, HLS semantic authority, fixed PE/tile count or runtime device selector is admitted.
9. Real hardware performance is reported only when the corresponding hardware actually executes the workload.
