# Performance — 1.3.90

## Host scope

The release host exposes no proved FPGA target. Therefore only x86 regression cost is measurable. No FPGA speedup is claimed.

## Whole-episode runtime

`mass3`, `chem6`, and `rigid7` were compiled by frozen 1.3.89 and current 1.3.90. Each executable was run for 20,000,000 steps over 30 interleaved measurements.

| Probe | 1.3.89 median | 1.3.90 median | old/new |
|---|---:|---:|---:|
| mass3 | 0.152900259 s | 0.151552609 s | 1.00889x |
| chem6 | 0.139148760 s | 0.141507370 s | 0.98333x |
| rigid7 | 0.244118662 s | 0.243333225 s | 1.00323x |
| geometric mean | | | **0.99842x** |

The probes disagree in direction. The geometric mean corresponds to roughly 0.16% slower for 1.3.90 and is treated as measurement noise. Truthful runtime change: **0%**.

## Image size

For all three probes the 1.3.90 image is 112 bytes larger than 1.3.89. The added bytes expose the fabric descriptor/admission boundary. The mathematical hot bodies are not changed for this host.

## Compiler time

Thirty interleaved compile measurements give a geometric-mean old/new ratio of `0.99081x`, or roughly +0.93% compile time for 1.3.90. Absolute median deltas range from about -0.03 ms to +0.11 ms in these small programs and are near host noise.

Raw data: `devtrash/benchmarks/fabric_realization_descriptor_1390/`.

## Synthetic fabric proof

The existing proof-only target facts still close `branch_probe` to `2,2,1,2,1`. 1.3.90 additionally burns three fabric descriptors and refuses to execute that mixed image without a bridge. This is an architecture proof, not a hardware performance result.
