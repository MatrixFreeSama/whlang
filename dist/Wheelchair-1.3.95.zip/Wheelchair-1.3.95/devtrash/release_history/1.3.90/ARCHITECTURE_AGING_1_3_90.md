# Architecture aging — 1.3.90

The release ages the 1.3.89 heterogeneous placement proof into a consumable physical-realization boundary.

The old gap was:

```text
Physical DAG -> mixed domain tags -> no executable fabric boundary
```

1.3.90 becomes:

```text
Physical DAG
  -> Physical Edge Facts
  -> joint domain closure
  -> one descriptor per Region
  -> one shared completion law
```

No FPGA syntax, kernel extraction, HLS IR, worker pool, task graph, fixed tile/PE count, runtime device chooser or native fallback was added.

The descriptor contains no new semantics. It is a serialization of already-proved physical facts. This preserves one authority while allowing future board integration to consume the result without reconstructing the program structure.

Physical absence is now explicit: if a plan contains fabric Regions and no activation bridge is proved, execution stops instead of silently using x86.
