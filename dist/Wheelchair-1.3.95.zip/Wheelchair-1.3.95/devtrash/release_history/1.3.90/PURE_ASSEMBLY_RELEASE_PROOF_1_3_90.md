# Pure-assembly release proof — 1.3.90

Production compiler/runtime authority remains handwritten x86-64 assembly plus shell build/link orchestration. Production build authority does not invoke Python, C, LLVM or a JIT.

The 1.3.90 heterogeneous extension is implemented in the same current assembly authorities:

- `compiler/general_frontend_x86_64.S`
- `runtime/general_parallel_release_x86_64.S`
- `compiler/silicon_reality.inc`
- `compiler/physical_reality.inc`
- `compiler/fabric_target_facts_x86_64.S`

`build.sh` derives runtime offsets from ELF symbols and validates the new descriptor/activation laws. Development tests may use Python to inspect emitted ELF metadata; Python is not a production compiler component.
