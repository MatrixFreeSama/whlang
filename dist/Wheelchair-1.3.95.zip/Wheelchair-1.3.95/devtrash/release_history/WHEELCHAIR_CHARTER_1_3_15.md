# Wheelchair 1.3.15 Charter — Rank-N Causal Physicalization Closure

## Governing rule

1.3.15 does not add a four-state, large-state, recurrence, ODE, or simulation backend. It strengthens the existing Rank-N / Axis / Operator / Region / Effect / Capability + Versioned Physical Reality + Physical DAG architecture until causal persistent state obeys the same Rank-N law as Tensor and Field.

A state count is not an admission class. It is only one input to compile-time physical pressure. If the target has profitable carriers, ValueFacts remain resident. When pressure exceeds that capacity, only the necessary facts materialize into their already-owned state pages; the rest of the causal episode remains in the same Physical DAG.

## Hard constraints

- no state-count workload dispatch;
- no `N <= 3` or `N <= 4` backend threshold;
- counted induction is Axis authority, not model-state entitlement;
- no runtime DAG walker, register allocator, state scheduler, ready queue, work stealing, or recipient selection;
- partial residency must not create a stack-evaluator fallback cliff;
- spill is legal only as a consequence of real physical pressure or exact semantic requirements;
- private state-page ownership is preserved; cache-set coloring strengthens that old structure rather than replacing it with a shared packed manager;
- strict FP ordering and trapping integer semantics remain proof boundaries;
- all 1.3.13/1.3.14 technical peaks remain release obligations.

## Physical law

```text
Versioned ValueFacts
    -> one causal Physical DAG
    -> compile-time lifetime / pressure / profitability
    -> resident carrier when profitable
    -> existing private state page only when necessary
    -> last proved consumer releases carrier blindly
```

No runtime component decides who receives released silicon next.
