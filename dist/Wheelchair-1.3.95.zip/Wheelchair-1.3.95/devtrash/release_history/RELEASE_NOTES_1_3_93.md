# Wheelchair 1.3.93 release notes

1.3.93 repairs a compiler-level Physical Reality error: transport cost was allowed to constrain arithmetic recurrence width.

The total schedule still includes Traffic Reality and may report traffic as the bottleneck. A new issue/dependency bound is captured before transport joins total cost; reduction and Group recurrence carriers consume that narrower fact.

For the historical lightweight Tensor reduction this restores two independent accumulators and a sixteen-element hot episode without adding a benchmark-specific route. Same-host 100M measurements improve one-execution time from 36.833 ms to 24.723 ms and the current four-execution realization from 13.255 ms to 12.148 ms.

The 1.3.92 execution-admission/locality repair remains intact. Heterogeneous x86/fabric Physical Reality remains intact. No kernel language, HLS authority, worker pool, work stealing, fixed tile/PE grid, runtime device selector, or compatibility reduction backend is introduced.
