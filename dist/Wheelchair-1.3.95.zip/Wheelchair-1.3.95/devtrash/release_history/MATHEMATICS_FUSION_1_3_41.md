# Mathematics Fusion 1.3.41

## Rule

The release uses **A∩B, not A+B**. An old algorithm is retained only once at the deepest useful mathematical identity. Surface functions project that identity into ordinary AST/ValueFacts; no math runtime object survives.

## 1. Euler/Lambert continued fraction: exp and expm1

The existing exponential construction reduces `x` to `y=x/64` and forms an Euler/Lambert continued-fraction seed. The useful common quantity is not the full exponential but

```text
q = exp(y) - 1
```

The two surfaces are then exact algebraic projections:

```text
exp:    e = 1 + q;  e <- e*e        (six times)
expm1:  q <- q*(q + 2)              (six times)
```

The second recurrence follows from `(1+q)^2-1=q(q+2)` and avoids subtracting one from a rounded exponential. Source: `s_expand_exp_seed_q_ast`, `s_expand_exp_ast`, `s_expand_expm1_ast`.

## 2. Kahan compensated log1p

For `y=1+x` and `c=y-1`, the correction

```text
log1p(x) = log(y) * x/c
```

recovers the original x lost by rounding in y. If c is exactly zero, x itself is the correct first-order result at machine precision. The zero case is a protected denominator plus dataflow select, not a runtime branch. Source: `s_expand_log1p_ast`.

The same fact is consumed by stable identities for inverse hyperbolic functions.

## 3. Abramowitz-Stegun 7.1.26: erf and erfc

The old approximation naturally computes a complement-like tail

```text
q = t * P(t) * exp(-x^2),  t = 1/(1+p|x|)
```

which is approximately `erfc(|x|)`. Therefore the shared kernel is q, not erf. Projections are

```text
erf(x)  = sign(x) * (1-q)
erfc(x) = q            for x>=0
          2-q          for x<0
```

This keeps the positive erfc tail from being destroyed by `1-erf(x)`. Source: `s_expand_erf_tail_ast`, `s_expand_erf_ast`, `s_expand_erfc_ast`.

## 4. Lanczos: Gamma family

The classic g=7 Lanczos core is

```text
z = x-1
S = c0 + sum(ci/(z+i))
t = z + 7.5
a = z + 0.5
```

Those three facts `(S,t,a)` are now emitted once by `s_expand_lanczos_core_ast`. The historical Gamma projection keeps the old multiply/pow order. Log-Gamma projects

```text
lgamma(x) = 0.5 ln(2pi) + a ln(t) - t + ln(S)
```

Ratios such as Beta and binomial coefficients combine log-Gamma values before one final exponential, preventing avoidable intermediate overflow.

## 5. Scaled Euclidean norm

The scale-safe identity

```text
m = max(|x|,|y|)
n = min(|x|,|y|)
hypot = m * sqrt(1 + (n/m)^2)
```

with a protected zero denominator is one authority for both scalar `hypot` and complex magnitude. Source: `s_expand_scaled_hypot_ast`.

## 6. Sparse select and semantic origin

`select` is an existing dataflow fact, not a solver branch. A differentiable semantic may end in a select, but `SN_C` is also the select false edge. 1.3.41 wraps such a result through multiplication by one before attaching semantic-origin metadata. This repairs the shared metadata boundary once instead of adding per-function exceptions.

## Still intentionally young

Root finding remains fixed Newton refinement, quadrature remains fixed 8-point Gauss-Legendre, LU/inverse remain unpivoted, QR remains modified Gram-Schmidt, and eig/SVD remain power-deflation / A^T A based. These are not hidden by compatibility fallbacks in 1.3.41.
