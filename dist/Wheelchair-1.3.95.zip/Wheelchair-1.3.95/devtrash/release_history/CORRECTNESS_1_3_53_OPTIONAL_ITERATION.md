# Correctness proof notes: 1.3.53 optional iteration

The executable release gate is `devtrash/release_tests/test_optional_iteration_convergence_1353.sh`.

It proves four properties.

1. **Default preservation.** Every migrated relation is compiled once with its optional count omitted and once with the historical default written explicitly. The resulting ELF files must be byte-identical, not merely numerically close.
2. **User ownership.** Non-default static counts compile and execute through Lambert W, zeta, polylog, complete elliptic integrals, digamma/trigamma, inverse erf, composite GL8 integration, matrix exp/log/sqrt, eigensystem and all SVD projections.
3. **Root-compatible staging.** A runtime input used as an iteration count is rejected. The count is an AOT source fact just like `root`'s fourth argument; there is no runtime solver-control channel.
4. **No named implementation fork.** Production assembly is checked for the absence of precision/count-specific custom solver names.

In addition, the 1.3.52 compiler was used as a frozen baseline during release construction. Representative omitted-default scalar and matrix programs produced byte-identical generated ELFs under 1.3.52 and 1.3.53:

```text
scalar defaults: f171d062fa7b25fe937e372cc014cb166b7219d29606faf4a0c30501a96e51a4
matrix defaults: 0d3a986a9ff095db8a9bf6a6e38376667964b3dd64a0441c9d576258f6d34c9e
```

Thus the new optional spelling does not perturb historical output when it is unused.

Inherited release gates for native mathematics, structured mathematics, parametric Rank-N precision, RootRelation, root precision fusion, matrix/precision generalization, Field human shell, AVX2 ownership, ValueFact lifetime, Tensor Physical Reality, sparse materialization, Surface convergence and structural-capacity convergence remain required.
