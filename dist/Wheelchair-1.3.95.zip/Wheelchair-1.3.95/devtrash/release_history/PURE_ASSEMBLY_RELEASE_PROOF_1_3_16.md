# Wheelchair 1.3.16 Pure Assembly Release Proof

Production compiler/runtime implementation remains direct GNU assembler/linker driven native x86-64. `build.sh` does not invoke Python, GCC, Clang, LLVM `llc`, LLVM `opt`, JIT infrastructure or a C backend.

The 1.3.16 work is implemented inside the existing assembly General frontend plus the existing `physical_reality_138.inc` vocabulary. The generated causal hot episodes contain direct native instructions; whole-episode CSE discovery, structural equality, temporary-pressure proof, ready/future authority and carrier selection exist only at AOT compile time.

Release prohibitions:

- runtime CSE manager: 0
- runtime ValueFact cache: 0
- runtime DAG walker: 0
- runtime register allocator: 0
- global ready queue: 0
- work stealing: 0
- resource recipient selection: 0
- workload-name dispatch: 0
- strict-FP reassociation: 0

The complete inherited 1.3.15 authority and the new `test_whole_episode_physical_1316.sh` authority are mandatory for release.
