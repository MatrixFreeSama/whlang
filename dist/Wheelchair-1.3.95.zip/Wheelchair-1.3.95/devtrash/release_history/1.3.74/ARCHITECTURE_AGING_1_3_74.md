# Wheelchair 1.3.74 Architecture Aging

## Burn-level Machine Facts

1.3.74 closes the last gap between a proved Physical Fact and its hardware carrier. A fact that already has a stable physical identity is no longer translated back into a packet-local temporary merely because the machine emitter expects one.

For a proved direct Field Region:

- immutable AddressFacts are assigned to the real x86-64 GPR bank and loaded once at Region entry;
- immutable ConstantFacts are loaded into their resident SIMD carriers once at Region entry;
- immutable LoadFact / ConstantFact logical values may alias those physical carriers directly, so consumer arithmetic reads the carrier itself instead of first creating synthetic vreg copies;
- a tolerant `x*x` whose sole next semantic use is reduction can fuse into the existing hidden accumulator with `vfmadd231ps`, while strict floating-point keeps the original multiplication and addition order;
- full-packet direct loads are unmasked because Region proof already owns lane validity. Boundary, partial-tail and irregular-layout paths retain truthful mask/gather semantics.

The carrier allocator is constrained only by architectural capacity and existing helper-clobber facts. Carrier exhaustion falls back to the already-existing truthful stack authority; this is not a second optimization backend or a workload route.

## Aging law

The implementation extends the existing Physical Reality -> ISA path. It does not add a machine IR, register-allocation mode, runtime carrier manager, named workload matcher, JIT, autotuner, or fixed workload threshold.

The intended lifetime is now:

```text
Semantic Fact
    -> Physical Fact
    -> proved lifetime
    -> Machine carrier
    -> ISA consumer
    -> carrier released when the fact dies
```

A higher-level fact is not allowed to be serialized into a generic temporary after its final machine identity is known.

## Generic truth remains sovereign

The direct Region is not the whole language. If launch proof rejects direct layout, if a Region reaches a periodic/boundary edge, or if the physical carrier bank is exhausted, the existing generic/gather/stack authority remains the semantic path. 1.3.74 deliberately preserves those cases rather than pretending runtime geometry is an AOT constant.
