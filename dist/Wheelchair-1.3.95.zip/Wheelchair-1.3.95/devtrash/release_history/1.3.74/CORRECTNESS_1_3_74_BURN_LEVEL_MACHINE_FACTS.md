# Wheelchair 1.3.74 Correctness: Burn-level Machine Facts

The release gate `devtrash/release_tests/test_burn_level_machine_facts_1374.sh` proves both semantics and emitted machine shape.

It verifies:

- native512 tolerant and strict Poisson-style seven-neighbor inputs preserve their historical p16 checksum bits;
- native256 tolerant and strict preserve their own historical width-specific checksum bits;
- the AVX-512 generated image contains direct Region loads from the seven Region-resident GPR bases (`RBX`, `RCX`, `RDI`, `RSI`, `R8`, `R9`, `R10`) indexed by `R12`;
- tolerant square+reduction emits hidden-accumulator `vfmadd231ps`, while strict mode does not and retains `vmulps`;
- no named Poisson/stencil/Fibonacci/MGPCG matcher, second machine IR or fixed burn threshold exists.

A historical mixed-layout regression caught an in-place alias-lifetime error during development: `v1=v1*const` initially ended the destination alias before resolving the read side. 1.3.74 resolves the source carrier first, then terminates the old destination lifetime. The padded/strided mixed-field oracle is restored to `checksum_f32_bits=0x47126d00` on both native512 and native256.

Boundary, arbitrary-extent, gather fallback and historical semantic convergence gates remain authoritative.
