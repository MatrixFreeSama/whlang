# Wheelchair 1.3.74 Performance Notes

The primary result of 1.3.74 is machine-shape aging, not a universal benchmark claim.

On the same 256^3 seven-neighbor tolerant Field diagnostic used during the 1.3.73 investigation, pinned to CPUs 0-3 on the Xeon Platinum 8370C host, nine whole-process samples gave:

- 1.3.73 median: 40.729 ms (34.228..50.067 ms)
- 1.3.74 median: 35.670 ms (30.557..42.039 ms)
- observed median reduction: 12.42%
- both: `checksum_f32_bits=0x4b27b8fe`

The sample ranges overlap substantially, so this is evidence of a favorable change, not a precise universal speedup estimate.

The stronger evidence is the generated direct hot path itself. Compared with 1.3.73, a proved Region no longer reloads seven AddressFact pointers from stack for every packet; those facts occupy GPRs for the Region lifetime. Constant residents are loaded at Region entry rather than every packet, many immutable source-to-logical-vreg `vmovaps` copies disappear, and tolerant square+reduction can fuse into the hidden accumulator FMA.

The remaining performance gap to an expert C stencil is therefore increasingly concentrated in instruction-level scheduling / independent-packet exposure and the unavoidable memory/reduction work, rather than repeated recovery of already-proved Field facts.
