# Wheelchair 1.3.74 Pure Assembly Release Proof

1.3.74 continues to build the production compiler/runtime path from assembly sources and emit native x86-64 machine code directly. It does not introduce LLVM, GCC as a code-generation backend, C-generated hot kernels, JIT compilation, bytecode execution, or a machine-level interpreter.

The new burn-level carrier logic lives in `compiler/field_frontend_common_x86_64.S` and the architecture contract in `compiler/physical_reality.inc`.

Release gates inspect the generated final LOAD image with `objdump -b binary` and verify GPR-resident AddressFacts and tolerant reduction fusion directly in emitted ISA.
