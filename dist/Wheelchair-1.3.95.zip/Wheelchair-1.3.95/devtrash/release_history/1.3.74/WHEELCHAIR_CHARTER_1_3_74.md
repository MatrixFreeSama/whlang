# Wheelchair Charter 1.3.74

1. A proved fact must not become a runtime question again.
2. A proved machine lifetime must not become a synthetic temporary again.
3. Physical Fact identity should become hardware-carrier identity whenever architectural capacity permits.
4. Carrier exhaustion preserves truthful old authority; it must not create a second optimization backend.
5. Strict floating-point order is semantic truth. Tolerant contraction requires an explicit def/use proof.
6. No workload names, benchmark routes, fixed workload thresholds, JIT, work stealing or algorithm zoo may be introduced to obtain a fast path.
7. Boundary and irregular geometry remain first-class truth, not compatibility residue.
8. New capability should age into existing Physical Reality / ISA authorities until the new mechanism itself stops looking separate.
