# Wheelchair 1.3.74 Release Notes

## Main change

Physical Facts now burn directly into machine carriers instead of being demoted back into packet-local temporaries at the last emitter layer.

## Added / aged

- Region-lifetime AddressFact -> GPR allocation;
- Region-lifetime ConstantFact -> SIMD residency;
- compiler-only immutable carrier aliasing for logical values;
- direct unmasked regular loads after complete-packet Region proof;
- tolerant def/use fusion of square + reduction into the hidden accumulator FMA;
- exact source-before-destination lifetime ordering for destructive in-place operations;
- 1.3.74 machine-shape release gate.

## Removed

- the old `ff_emit_cache_store` compatibility name; the current helper-return ABI is explicitly `ff_emit_cache_store_simd0`;
- per-packet stack pointer re-materialization for GPR-resident AddressFacts;
- per-packet constant-resident reload in stable direct Regions;
- synthetic immutable LoadFact/ConstantFact -> logical-vreg copies where carrier identity is already proved.

## Preserved

- strict FP ordering;
- generic/padded/strided gather fallback;
- boundary and partial-tail mask truth;
- native512/native256 semantics;
- all earlier semantic, execution-form, Region and ownership convergence authorities.

No workload matcher, second machine IR, JIT, runtime carrier-policy manager or fixed burn threshold is introduced.
