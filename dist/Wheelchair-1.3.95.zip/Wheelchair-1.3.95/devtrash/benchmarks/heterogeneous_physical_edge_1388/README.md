# 1.3.88 heterogeneous Physical Edge benchmark

Frozen 1.3.87 is compared with current 1.3.88 on the same host.

`runtime_raw.csv` contains 30 interleaved 20,000,000-step repetitions for `mass3`, `chem6`, and `rigid7`, pinned to CPU 0. `runtime_summary.csv` reports a geometric-mean 1.3.87/1.3.88 ratio of about `1.00085x` (`+0.085%`), treated as measurement noise.

`compile_raw.csv` contains 30 interleaved compilation repetitions per probe. `compile_summary.csv` reports about 3.7% additional compiler time for 1.3.88, approximately 0.04-0.09 ms absolute on these tiny compiles.

No FPGA timing is present because the release host exposes no proved fabric target facts and no FPGA toolchain. The release does not estimate hardware acceleration.
