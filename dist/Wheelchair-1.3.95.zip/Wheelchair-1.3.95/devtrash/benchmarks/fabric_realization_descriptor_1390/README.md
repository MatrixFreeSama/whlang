# 1.3.90 fabric realization descriptor benchmark

Frozen 1.3.89 and current 1.3.90 are compared on the existing 20,000,000-step General whole-episode probes.

The release host has no proved fabric target. Runtime numbers therefore measure only x86 regression cost. The synthetic fabric profile is used only by the release proof to validate mixed descriptors and hard rejection when no activation bridge exists.
