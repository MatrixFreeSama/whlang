#!/usr/bin/env python3
import csv, math, os, statistics, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parents[3]
d=Path(__file__).resolve().parent
probes=['mass3','chem6','rigid7']
rows=[]
# warmup
for p in probes:
    for v in ('1389','1390'):
        subprocess.run([str(d/f'{p}_{v}'),'20000000'],stdout=subprocess.DEVNULL,check=True)
for i in range(30):
    for p in probes:
        order=('1389','1390') if i%2==0 else ('1390','1389')
        for v in order:
            t=time.perf_counter_ns()
            cp=subprocess.run([str(d/f'{p}_{v}'),'20000000'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            dt=(time.perf_counter_ns()-t)/1e9
            if cp.returncode: raise SystemExit((p,v,cp.returncode))
            rows.append((i,p,v,dt))
with open(d/'runtime_raw.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['iteration','probe','version','seconds']); w.writerows(rows)
summary=[]; ratios=[]
for p in probes:
    a=[r[3] for r in rows if r[1]==p and r[2]=='1389']
    b=[r[3] for r in rows if r[1]==p and r[2]=='1390']
    ma=statistics.median(a); mb=statistics.median(b); ratio=ma/mb
    ratios.append(ratio); summary.append((p,ma,mb,ratio))
geomean=math.exp(sum(math.log(x) for x in ratios)/len(ratios))
with open(d/'runtime_summary.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['probe','median_1_3_89_s','median_1_3_90_s','ratio_1389_over_1390'])
    w.writerows(summary); w.writerow(['geomean','','',geomean])
# compiler timing
base=Path('/mnt/data/Wheelchair-1.3.89-baseline/Wheelchair-1.3.89/bin/wheelchairc')
cur=root/'bin/wheelchairc'
compile_rows=[]
out=Path('/tmp/wheelchair_1390_compile_bench'); out.mkdir(exist_ok=True)
for i in range(30):
    for p in probes:
        src=root/'devtrash/tests/general_whole_episode_1316'/f'{p}.wh'
        order=(('1389',base),('1390',cur)) if i%2==0 else (('1390',cur),('1389',base))
        for v,c in order:
            target=out/f'{p}_{v}'
            t=time.perf_counter_ns(); cp=subprocess.run([str(c),str(src),'-o',str(target)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); dt=(time.perf_counter_ns()-t)/1e6
            if cp.returncode: raise SystemExit(('compile',p,v,cp.returncode))
            compile_rows.append((i,p,v,dt))
with open(d/'compile_raw.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['iteration','probe','version','milliseconds']); w.writerows(compile_rows)
summary2=[]; ratios2=[]
for p in probes:
    a=[r[3] for r in compile_rows if r[1]==p and r[2]=='1389']; b=[r[3] for r in compile_rows if r[1]==p and r[2]=='1390']
    ma=statistics.median(a); mb=statistics.median(b); ratio=ma/mb; ratios2.append(ratio); summary2.append((p,ma,mb,ratio,mb-ma))
gm2=math.exp(sum(math.log(x) for x in ratios2)/len(ratios2))
with open(d/'compile_summary.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['probe','median_1_3_89_ms','median_1_3_90_ms','ratio_1389_over_1390','delta_ms']); w.writerows(summary2); w.writerow(['geomean','','',gm2,''])
print('runtime geomean',geomean)
for x in summary: print(x)
print('compile geomean',gm2)
for x in summary2: print(x)
