# 1.3.87 silicon static placement benchmark

The release host admits five logical CPUs inside one exact admitted L3 domain. The 1.3.87 placement contract therefore reports `static_placement_required=0`; the new cross-domain placement mechanism is dormant on this host.

`mass3`, `chem6`, and `rigid7` were compiled with frozen 1.3.86 and current 1.3.87. The 1.3.87 generated images are 224 bytes larger because they contain one startup placement guard plus the baked placement-mask storage. The mature computation loops are unchanged by this release on the single-L3 host.

`raw.csv` contains 12 interleaved runtime repetitions at 20,000,000 steps pinned externally to CPU 0. Median ratios are reported in `summary.csv`. The geometric-mean 1.3.87/1.3.86 ratio is about `0.99937x` (`-0.06%`), which is treated as measurement noise, not as a performance claim.

`compile_raw.csv` contains 20 interleaved compile repetitions per kernel. `compile_summary.csv` shows no resolvable new compile-time cost on this host; the geometric-mean compile-time ratio is about `0.99372x`, also retained as noise.

No cross-LLC acceleration is claimed because this host exposes only one admitted L3 domain. That path requires a target whose externally admitted CPU set actually crosses exact L3 domains.
