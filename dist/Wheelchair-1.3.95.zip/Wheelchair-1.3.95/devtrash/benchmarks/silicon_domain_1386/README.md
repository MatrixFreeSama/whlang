# 1.3.86 silicon-domain identity benchmark

The release host admits five logical CPUs. The 1.3.86 exact identity probe reports three admitted L1D domains, three admitted L2 domains, and one admitted L3 domain; the maximum admitted intersections are 2, 2, and 5 respectively.

`mass3`, `chem6`, and `rigid7` were compiled with frozen 1.3.85 and current 1.3.86. Corresponding output executables are byte-identical, so generated-program acceleration is 0% by construction.

`raw.csv` contains 12 interleaved runtime repetitions at 20,000,000 steps pinned to CPU 0. The observed geometric-mean ratio is about 1.0100x for 1.3.86/1.3.85, retained as noise because the binaries are identical.

`compile_raw.csv` contains 20 interleaved compile repetitions for each kernel. The new compile-time identity proof costs about 0.20 ms per tiny compile on average on this host.
