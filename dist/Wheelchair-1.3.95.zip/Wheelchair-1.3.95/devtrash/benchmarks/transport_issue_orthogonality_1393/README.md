# 1.3.93 transport/issue orthogonality benchmark evidence

Same-host evidence for the compiler repair that separates transport cost from reduction issue width.

- `light_old_new_raw.csv`: frozen 1.3.92 vs repaired 1.3.93, 15 interleaved rounds, both one-execution and four-execution realizations.
- `fsi_dense_old_new_raw.csv`: 1.3.92 vs 1.3.93 continuity controls, nine interleaved rounds.
- `light_vs_c_fortran_raw.csv`: repaired 1.3.93 against the fresh contract-matched C/Fortran references, 15 interleaved rounds.

All compared lightweight-reduction outputs are bit-identical (`0x422665f782000000`).
