# FSI 1.3.79 vs 1.3.93 root-cause check

## Scope

Same host, same FSI source (`ae468a4c...92baad`), same CPU affinity (`0-3`), 100,000,000 elements.

The question was whether Wheelchair 1.3.93 introduced an approximately 20% multi-execution FSI regression relative to 1.3.79.

## Machine-code result

Both versions emit a 10,353-byte static ELF for the same source.

The FSI worker segment at file offset `0x2000`, length `0x871`, is byte-identical:

`sha256 = 6b78610fe8720845cdfca22d13e3eb81d8802a601c99db0994dd69b8f33b8a3f`

Therefore the numerical FSI hot loop is not the source of the observed multi-execution difference.

## Launch-geometry difference

1.3.79 emits `capacity_ceiling = 5` and its cold launch geometry rounds execution width upward to the next power of two. Thus capacity 5 becomes 8 leaves.

1.3.93 emits `execution_admission = 4` from the current host's `affinity x finite cgroup quota` and uses that exact integer width. There is no power-of-two execution round-up.

This host exposes 5 logical CPUs but has a finite cgroup quota of 4 CPU-equivalents.

## Controlled A/B

Only the embedded admission/capacity integer was changed. No worker instruction, numerical expression, source program, ISA path, or runtime algorithm was changed.

| Variant | Median wall time | Output |
|---|---:|---|
| 1.3.79 old capacity 5 -> 8 leaves | 90.322 ms | `0x416522bcff4b1f25` |
| 1.3.79 capacity forced to 4 -> 4 leaves | 118.888 ms | `0x416522bcff4b5091` |
| 1.3.93 production admission 4 -> 4 leaves | 118.283 ms | `0x416522bcff4b5091` |
| 1.3.93 admission forced to 8 -> 8 leaves | 93.661 ms | `0x416522bcff4b1f25` |

At equal geometry, 1.3.79 and 1.3.93 differ by roughly 0.5%, consistent with run noise.

Changing only the leaf count reproduces both the timing class and the tolerant reduction output bits across versions.

## Scheduling cost evidence

Seven-run `/usr/bin/time` probe:

| Geometry | Real median | User median | Voluntary CS | Involuntary CS |
|---|---:|---:|---:|---:|
| 1.3.79, 4 leaves | 0.12 s | 0.33 s | 6 | 18 |
| 1.3.79, 8 leaves | 0.09 s | 0.29 s | 13 | 53 |
| 1.3.93, 4 leaves | 0.11 s | 0.32 s | 5 | 20 |
| 1.3.93, 8 leaves | 0.08 s | 0.29 s | 14 | 52 |

The old result is therefore tied to deliberate/accidental OS oversubscription: 8 ownership leaves on a substrate with 4 CPU-equivalent quota. It also materially increases context switching.

## Conclusion

There is no 1.3.79 -> 1.3.93 FSI worker/runtime regression at equal execution geometry.

The previously reported ~20% gap came from comparing different realization geometries:

- 1.3.79: power-of-two round-up, 5 -> 8 leaves;
- 1.3.93: exact physical admission, 4 leaves.

Restoring the old behavior would reintroduce power-of-two execution geometry and oversubscription, contradicting the current Physical Reality authority. No production-source change is justified by this comparison.

If the 8-leaf result is worth pursuing, the correct direction is to recover its latency/load-balancing benefit *inside admitted executions* through existing issue/group facts, not by creating more OS executions than the proved admission capacity.
