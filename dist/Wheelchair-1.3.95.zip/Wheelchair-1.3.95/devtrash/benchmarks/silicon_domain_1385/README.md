# 1.3.85 silicon-domain benchmark note

Release host: the same container used for the release build, with five admitted x86-64 CPUs, one visible NUMA node, and one visible L3 sharing domain.

`mass3`, `chem6`, and `rigid7` were compiled once with the frozen 1.3.84 package and once with 1.3.85. Corresponding output executables were SHA-256 identical:

- mass3: `9e73aefc35551713059f42c66af69c5a889415200de4fab283f4f853b2bf17e8`
- chem6: `3f651f3cdea49280be4b4851cb4faa717cb68ea020d8706b70ffd0c550d21cbd`
- rigid7: `9a199896c98fcb9d2de3f821b57ee16aa229a22efa92785ff480ec7583ef9bf0`

The interleaved timing sample uses 20,000,000 steps, CPU 0, 15 measured repetitions per version per kernel. Its geometric-mean timing ratio is about 0.9911x for 1.3.85 over 1.3.84. Because each corresponding executable is byte-identical, the observed timing difference cannot be attributed to generated code and is retained only as a noise record.

The release claim is therefore 0% generated-program acceleration on this single-domain host. The new architecture removes a missing spatial fact layer; it does not invent a same-host speedup where the target exposes no relevant cross-domain choice.
