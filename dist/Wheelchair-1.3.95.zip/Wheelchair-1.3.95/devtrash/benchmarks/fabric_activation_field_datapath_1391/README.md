# 1.3.91 fabric activation / Field datapath benchmark

Frozen 1.3.90 and current 1.3.91 are compared on the existing 20,000,000-step General whole-episode probes. The release host has no proved FPGA target, so these numbers measure x86 regression cost only.

The Field proof uses synthetic target facts only to verify that the existing op-level Physical DAG is serialized into a fabric datapath descriptor and that unbridged execution is rejected. It is not a hardware speed result.
