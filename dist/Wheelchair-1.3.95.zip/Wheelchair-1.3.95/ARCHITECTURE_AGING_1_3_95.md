# Architecture aging 1.3.95

No execution architecture changed in 1.3.95. The release surface was aged to match the architecture's existing single-authority rule: production executables live in `bin/`; generated build products do not become a second shipped authority.

Historical experiments keep irreducible evidence rather than reproducible executable copies. This reduces storage without adding indirection to compiler/runtime execution.
