# Testing 1.3.95

The current release authority remains 25 tests. The closure test is versioned to 1.3.95; the 1.3.94 spatial/temporal quota gate remains active.

Packaging is additionally verified after testing: `build/` must be absent from the staged archive, no ELF may remain under `devtrash/benchmarks`, `bin/` must contain the eight static production compilers, and the final archive must pass ZIP integrity and `SHA256SUMS` verification.
