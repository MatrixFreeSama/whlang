# Release surface convergence 1.3.95

1.3.95 changes the release surface only. Production compiler/runtime execution logic is unchanged from 1.3.94.

The release has one authority for shipped production executables: `bin/`.

`build/` is reproducible scratch created by `build.sh` and is deliberately absent from the archive. Historical benchmark directories retain source, raw measurements, summaries, environment records, and hashes; reproducible benchmark ELF outputs are not shipped. Duplicate scratch build logs are not retained when an identical release-history copy already exists.

No compatibility route, scheduler, worker pool, benchmark-specific compiler path, or execution fallback is introduced by this release.
