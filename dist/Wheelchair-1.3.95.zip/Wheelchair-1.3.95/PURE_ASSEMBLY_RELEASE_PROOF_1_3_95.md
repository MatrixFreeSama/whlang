# Pure assembly release proof 1.3.95

Production compiler/runtime authority remains handwritten x86-64 assembly plus `.inc`, linker scripts and shell orchestration. `build.sh` recreates the generated `build/` workspace from the shipped source tree. The final release removes that workspace after verification and ships production executables only under `bin/`.

Final production source counts: 30 `.S`, 15 `.inc`, 4 `.ld`. All eight binaries under `bin/` are statically linked ELF64 and have no dynamic section. Their bytes are identical to the corresponding 1.3.94 production binaries; this release does not alter execution code.
