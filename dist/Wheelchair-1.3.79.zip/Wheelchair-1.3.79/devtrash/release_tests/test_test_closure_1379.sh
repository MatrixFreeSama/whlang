#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
TMP=${TMPDIR:-/tmp}/wheelchair_test_closure_1379_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"

[ "$(cat VERSION)" = "1.3.79" ]
[ -x test.sh ]
[ -x devtrash/coverage/run_native_coverage.sh ]
[ -x devtrash/coverage/native_coverage.py ]
[ -s devtrash/release_tests/current.list ]

# Testing observes production. It has no route back into compiler authority.
! grep -RqsE 'native_coverage|WHEELCHAIR_COVERAGE|coverage-real' compiler runtime surface tools build.sh

# The test-only release must preserve every production compiler byte from 1.3.78.
sha256sum \
  bin/fieldc bin/fieldc-native256 \
  bin/topologyc bin/topologyc-derived bin/topologyc-derived-native256 bin/topologyc-native256 \
  bin/wheelchairc bin/whexc > "$TMP/current.sha256"
cmp -s "$TMP/current.sha256" PRODUCTION_BIN_SHA256_1_3_78.txt

# Current-suite authority is explicit and small; historical archaeology does not
# become current merely because it still exists under devtrash.
[ "$(grep -c '^test_.*\.sh$' devtrash/release_tests/current.list)" -eq 12 ]
[ "$(sort devtrash/release_tests/current.list | uniq -d | wc -l)" -eq 0 ]
while IFS= read -r test; do
  [ -x "devtrash/release_tests/$test" ]
done < devtrash/release_tests/current.list

printf '%s\n' \
  'TEST_OBSERVER_PRODUCTION_BACKEDGE=0' \
  'HISTORICAL_TEST_AUTO_ADMISSION=0' \
  'CURRENT_RELEASE_TEST_AUTHORITY=PASS' \
  'PRODUCTION_BIN_ZERO_FLIP_FROM_1_3_78=PASS' \
  'WHEELCHAIR_TEST_CLOSURE_1_3_79=PASS'
