#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1371_region_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'PHYSICAL_REGION_SPARSIFICATION_BUILD=PASS'

grep -q '^.equ PR_PHYSICAL_REGION_FACT_SPARSIFICATION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_PROVED_TOPOLOGY_RETIRES_INSIDE_REGION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_BOUNDARY_ONLY_TOPOLOGY_REMATERIALIZATION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_PHYSICAL_REGION_SECOND_IR,0$' compiler/physical_reality.inc
grep -q '^.equ PR_STENCIL_WORKLOAD_MATCHER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_PHYSICAL_REGION_FIXED_THRESHOLD,0$' compiler/physical_reality.inc
grep -q '^.equ PR_PER_ELEMENT_ADDRESS_TABLE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_PHYSICAL_REGION_MANAGER,0$' compiler/physical_reality.inc
echo 'PHYSICAL_REGION_SINGLE_AUTHORITY=PASS'

# The old per-packet predicate name is deleted rather than preserved as a
# compatibility alias. The runtime exports one run-end authority on both widths.
! grep -RqsE 'field_regular_episode_ok|FIELD_RUNTIME_REGULAR_EPISODE_VA' compiler runtime tools
grep -q '^field_regular_run_end:' runtime/field_runtime_512_x86_64.S
grep -q '^field_regular_run_end:' runtime/field_runtime_256_x86_64.S
grep -q 'FIELD_RUNTIME_REGULAR_RUN_END_VA' tools/generate_field_runtime_offsets.sh
echo 'REGULAR_EPISODE_BOOL_AUTHORITY=0'
echo 'REGULAR_RUN_END_AUTHORITY=PASS'

# Stable direct regions must not rematerialize the old q+[lane] mask helper.
# The fallback boundary block retains the truthful helper exactly where topology
# actually changes.
sed -n '/# loop label/,/\.fcg_regular_emission_done:/p' compiler/field_frontend_common_x86_64.S > "$T/regular.txt"
! grep -q 'FIELD_RUNTIME_MASK_VA' "$T/regular.txt"
sed -n '/\.fcg_regular_emission_done:/,/# Runtime layout proof chooses/p' compiler/field_frontend_common_x86_64.S > "$T/boundary.txt"
grep -q 'FIELD_RUNTIME_MASK_VA' "$T/boundary.txt"
grep -q 'cg_cmp_q_regular_end' compiler/field_frontend_common_x86_64.S
grep -q 'cg_fullmask512' compiler/field_frontend_common_x86_64.S
grep -q 'cg_fullmask256' compiler/field_frontend_common_x86_64.S
echo 'STABLE_REGION_MASK_REMATERIALIZATION=0'
echo 'BOUNDARY_MASK_REMATERIALIZATION=PASS'

# Small periodic non-zero oracle exercises truthful boundary handling on both
# physical widths. It is deliberately too small to benefit from long runs, so a
# wrong "always direct" implementation cannot hide behind performance.
for C in fieldc fieldc-native256; do
  build/$C devtrash/tests/field_1217/pow2_neighbor.json -o "$T/$C-neighbor" >/dev/null
  out=$("$T/$C-neighbor" devtrash/tests/field_1217/pow2_4x4x4.whfld)
  [ "$out" = 'checksum_f32_bits=0x45020000' ]
done
echo 'PERIODIC_BOUNDARY_ZERO_FLIP=PASS'
echo 'NATIVE512_NATIVE256_REGION_EQUIVALENCE=PASS'

# Existing broad Field oracles remain the semantic authority for arbitrary
# extents, irregular layouts, inout, noalias, tail masks, and gather fallback.
bash devtrash/release_tests/test_field_native_1216.sh >/dev/null
bash devtrash/release_tests/test_physical_regularity_134.sh >/dev/null
echo 'FIELD_GENERAL_FALLBACK_PRESERVED=PASS'
echo 'ARBITRARY_EXTENT_TAIL_FIDELITY=PASS'

! grep -RqsE '(^|[^A-Za-z])(poisson|stencil)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'physical_region.*(threshold|limit)[[:space:]]*=[[:space:]]*[1-9]' compiler runtime surface tools
echo 'POISSON_SPECIAL_CASE=0'
echo 'STENCIL_SPECIAL_CASE=0'
echo 'PHYSICAL_REGION_FIXED_THRESHOLD=0'
echo 'PHYSICAL_REGION_RUNTIME_MANAGER=0'
echo 'WHEELCHAIR_PHYSICAL_REGION_SPARSIFICATION_1_3_71=PASS'
