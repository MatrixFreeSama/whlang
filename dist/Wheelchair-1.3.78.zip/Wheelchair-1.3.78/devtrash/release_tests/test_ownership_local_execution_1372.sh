#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair1372_owner_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'OWNERSHIP_LOCAL_BUILD=PASS'

grep -q '^.equ PR_OWNERSHIP_LOCAL_EXECUTION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_LAUNCH_FRONTIER_RETIRES_AT_REGION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_OS_LIFECYCLE_COMPLETION_AUTHORITY,1$' compiler/physical_reality.inc
grep -q '^.equ PR_REDUCTION_SEPARATE_FROM_EXECUTION_OWNERSHIP,1$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_CAUSAL_TREE_AUTHORITY,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_SUBTREE_PROFITABILITY_RECHECK,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RECURSIVE_PARALLEL_JOIN_TREE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_EXECUTION_GLOBAL_COMPLETION_COUNTER,0$' compiler/physical_reality.inc

echo 'OWNERSHIP_LOCAL_SINGLE_AUTHORITY=PASS'

for S in runtime/tensor_runtime_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  grep -q '^run_region_frontier:' "$S"
  grep -q '^reduce_region_results:' "$S"
  grep -q 'CLONE_PARENT' "$S"
  grep -q 'SYS_wait4' "$S"
  ! grep -q '^run_causal_tree:' "$S"
  ! grep -q '^run_causal_tree_local:' "$S"
  ! grep -q 'g_region_done' "$S"
done
echo 'RUNTIME_CAUSAL_TREE_AUTHORITY=0'
echo 'RECURSIVE_JOIN_TREE=0'
echo 'GLOBAL_COMPLETION_COUNTER=0'

# Profitability remains cold.  The ownership frontier must not re-price subtrees.
for S in runtime/tensor_runtime_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  sed -n '/^run_region_frontier:/,/^# reduce_region_results/p' "$S" > "$T/frontier.txt"
  ! grep -q 'outward_materialization_ticks_patch' "$T/frontier.txt"
  ! grep -q 'chunk_work_ticks_patch' "$T/frontier.txt"
  ! grep -q 'field_chunk_work_ticks_patch' "$T/frontier.txt"
  ! grep -q 'call run_region_frontier' "$T/frontier.txt"
done
grep -q 'outward_materialization_ticks_patch' runtime/tensor_runtime_x86_64.S
grep -q 'outward_materialization_ticks_patch' runtime/field_runtime_512_x86_64.S
echo 'SUBTREE_PROFITABILITY_RECHECK=0'
echo 'LAUNCH_FRONTIER_SELF_RECURSION=0'

# Existing Field boundary truth remains intact on both wide physical profiles.
for C in fieldc fieldc-native256; do
  build/$C devtrash/tests/field_1217/pow2_neighbor.json -o "$T/$C-neighbor" >/dev/null
  out=$("$T/$C-neighbor" devtrash/tests/field_1217/pow2_4x4x4.whfld)
  [ "$out" = 'checksum_f32_bits=0x45020000' ]
done
echo 'FIELD_BOUNDARY_ZERO_FLIP=PASS'

# Tensor strict reduction remains bit-identical across current wide profiles.
SRC=devtrash/benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
STRICT="$T/fsi_strict.whex"
sed 's/"floating_point":"tolerant"/"floating_point":"strict"/' "$SRC" > "$STRICT"
for C in topologyc topologyc-native256; do
  build/$C "$STRICT" -o "$T/$C-fsi" >/dev/null
  "$T/$C-fsi" 10000000 > "$T/$C.out"
done
cmp "$T/topologyc.out" "$T/topologyc-native256.out"
echo 'TENSOR_STRICT_REDUCTION_BIT_IDENTITY=PASS'

! grep -RqsE '(^|[^A-Za-z])(poisson|stencil)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'runtime_(ready_queue|work_steal)|g_(ready_queue|work_steal)' compiler runtime surface tools
echo 'WORKLOAD_SPECIAL_CASE=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WHEELCHAIR_OWNERSHIP_LOCAL_EXECUTION_1_3_72=PASS'
