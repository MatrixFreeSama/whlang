#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
D=devtrash/tests/burn_machine_1374
./build.sh >/dev/null
echo 'COMPLETE_MACHINE_BURN_BUILD=PASS'
build/fieldc "$D/poisson_weighted_tolerant.json" -o "$T/fast" >/dev/null
build/fieldc "$D/poisson_weighted_strict.json" -o "$T/strict" >/dev/null
[ "$("$T/fast" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c695' ]
[ "$("$T/strict" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c695' ]
echo 'COMPLETE_MACHINE_BURN_ZERO_FLIP=PASS'
extract_generated() {
  local exe=$1 out=$2
  read off va sz <<EOH
$(readelf -lW "$exe" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOH
  dd if="$exe" of="$out.bin" bs=1 skip=$((off)) count=$((sz)) status=none
  objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$out.bin" > "$out.dis"
}
extract_generated "$T/fast" "$T/fast"
extract_generated "$T/strict" "$T/strict"
# Carrier burn remains intact.
for pat in '\[rbx\+r12\*4\]' '\[rcx\+r12\*4\]' '\[rdi\+r12\*4\]' '\[rsi\+r12\*4\]' '\[r8\+r12\*4\]' '\[r9\+r12\*4\]' '\[r10\+r12\*4\]'; do grep -Eq "$pat" "$T/fast.dis"; done
echo 'ADDRESSFACT_GPR_BURN_PRESERVED=PASS'
# Tolerant exact -1 coefficients die as SUBs; the center coefficient remains FMA.
[ "$(grep -Ec 'vsubps[[:space:]]+zmm1,zmm1,zmm(6|7|8|9|10|11)' "$T/fast.dis")" -ge 6 ]
[ "$(grep -Ec 'vfmadd231ps[[:space:]]+zmm1' "$T/fast.dis")" -eq 1 ]
grep -Eq 'vfmadd231ps[[:space:]]+zmm5\{k1\},zmm1,zmm1' "$T/fast.dis"
echo 'TOLERANT_OPERATOR_FORM_BURN=PASS'
# Strict path must not take the tolerant identity folding shortcut.
! grep -Eq 'vsubps[[:space:]]+zmm1,zmm1,zmm(6|7|8|9|10|11)' "$T/strict.dis"
grep -Eq 'vmulps' "$T/strict.dis"
echo 'STRICT_OPERATOR_ORDER_PRESERVED=PASS'
# Architecture prohibitions.
grep -q '^.equ PR_LATE_MACHINE_GRAPH_REWRITE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_SECOND_MACHINE_SCHEDULER_IR,0$' compiler/physical_reality.inc
grep -q '^.equ PR_FIXED_PACKET_UNROLL_AUTHORITY,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_MACHINE_ISSUE_MANAGER,0$' compiler/physical_reality.inc
! grep -RqsE '(^|[^A-Za-z])(poisson|stencil|fibonacci|mgpcg)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
echo 'LATE_MACHINE_GRAPH_REWRITE=0'
echo 'SECOND_MACHINE_SCHEDULER_IR=0'
echo 'FIXED_PACKET_UNROLL_AUTHORITY=0'
echo 'MACHINE_WORKLOAD_MATCHER=0'
echo 'WHEELCHAIR_COMPLETE_MACHINE_BURN_1_3_75=PASS'
