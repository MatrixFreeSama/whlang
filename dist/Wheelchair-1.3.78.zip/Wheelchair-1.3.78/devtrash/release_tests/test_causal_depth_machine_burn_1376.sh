#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
D=devtrash/tests/burn_machine_1374
F=devtrash/tests/field_1216
./build.sh >/dev/null
echo 'CAUSAL_DEPTH_MACHINE_BURN_BUILD=PASS'
# Compile with one immutable target-affinity geometry so runtime metadata cannot
# masquerade as a floating-point/codegen difference.
taskset -c 0-3 build/fieldc "$D/poisson_weighted_tolerant.json" -o "$T/fast" >/dev/null
taskset -c 0-3 build/fieldc "$D/poisson_weighted_strict.json" -o "$T/strict" >/dev/null
taskset -c 0-3 build/fieldc-native256 "$D/poisson_weighted_tolerant.json" -o "$T/fast256" >/dev/null
[ "$("$T/fast" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c695' ]
[ "$("$T/strict" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c695' ]
[ "$("$T/fast256" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c696' ]
echo 'CAUSAL_DEPTH_ZERO_FLIP=PASS'
extract_generated() {
  local exe=$1 out=$2
  read off va sz <<EOH
$(readelf -lW "$exe" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOH
  dd if="$exe" of="$out.bin" bs=1 skip=$((off)) count=$((sz)) status=none
  objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$out.bin" > "$out.dis"
}
extract_generated "$T/fast" "$T/fast"
extract_generated "$T/strict" "$T/strict"
# Packet zero remains the mature carrier set.  The following packet owns a
# different set and is addressed from the same burned AddressFacts with +64 B.
grep -Eq 'vmovups[[:space:]]+zmm15,.*\+0x40\]' "$T/fast.dis"
grep -Eq 'vmovups[[:space:]]+zmm(16|17|18|19|20|21),.*\+0x40\]' "$T/fast.dis"
grep -Eq 'vfmadd231ps[[:space:]]+zmm5\{k1\},zmm22,zmm22' "$T/fast.dis"
grep -Eq 'add[[:space:]]+r12,0x20' "$T/fast.dis"
echo 'DISJOINT_PACKET_MACHINE_CARRIERS=PASS'
echo 'EARLY_NEXT_PACKET_LOADS=PASS'
# Strict reduction is an exact recurrence and therefore remains canonical
# one-packet Vector realization rather than changing IEEE reduction grouping.
! grep -Eq 'vfmadd231ps[[:space:]]+zmm5\{k1\},zmm22,zmm22' "$T/strict.dis"
! grep -Eq 'add[[:space:]]+r12,0x20' "$T/strict.dis"
echo 'STRICT_REDUCTION_GROUP_REORDER=0'
# The irregular/mixed authority remains the old truthful native path.
for C in fieldc fieldc-native256; do
  build/$C "$F/mixed.json" -o "$T/$C-mixed" >/dev/null
  cp "$F/out_3x5x7.whfld" "$T/$C-out.whfld"
  [ "$("$T/$C-mixed" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/$C-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
  cmp "$T/$C-out.whfld" "$F/expected_mixed_3x5x7.whfld"
done
echo 'GENERIC_MIXED_LAYOUT_ZERO_FLIP=PASS'
# Architecture prohibitions and single authority.
grep -q '^.equ PR_CAUSAL_DEPTH_MACHINE_BURN,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUPFACT_DISJOINT_PACKET_CARRIERS,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUPFACT_CARRIER_FROM_LIVE_MACHINE_FACTS,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_PACKET_BYTE_CLONING,0$' compiler/physical_reality.inc
grep -q '^.equ PR_PRIVATE_MACHINE_UNROLL_WIDTH,0$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_WIDTH_CANDIDATE_SET,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_GROUP_ISSUE_SELECTOR,0$' compiler/physical_reality.inc
! grep -q 'ff_direct_preload_end_ptr' compiler/field_frontend_common_x86_64.S
! grep -RqsE 'group_body_factor[^\n]*(=|,)[[:space:]]*(2|4|8)([^0-9]|$)' compiler runtime surface tools
! grep -RqsE '(^|[^A-Za-z])(poisson|stencil|fibonacci|mgpcg)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
echo 'GROUP_PACKET_BYTE_CLONING=0'
echo 'PRIVATE_MACHINE_UNROLL_WIDTH=0'
echo 'GROUP_WIDTH_CANDIDATE_SET=0'
echo 'RUNTIME_GROUP_ISSUE_SELECTOR=0'
echo 'MACHINE_WORKLOAD_MATCHER=0'
echo 'WHEELCHAIR_CAUSAL_DEPTH_MACHINE_BURN_1_3_76=PASS'
