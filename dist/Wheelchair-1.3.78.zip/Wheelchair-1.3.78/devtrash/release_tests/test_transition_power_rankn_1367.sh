#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
TMP=${TMPDIR:-/tmp}/wheelchair_transition_power_1367_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
G=compiler/general_frontend_x86_64.S
R=runtime/general_runtime_template_x86_64.S
P=compiler/physical_reality.inc

# One production authority: the old scalar self-map route is gone.  A scalar
# recurrence is now simply a one-lane instance of the Rank-N affine closure.
grep -q '^g_transition_mark_state_refs:' "$G"
grep -q '^g_transition_emit_affine_terms:' "$G"
grep -q '^g_try_emit_transition_power_slice:' "$G"
grep -q '^rankn_affine_power_u64:' "$R"
grep -q '^g_alloc_runtime_temp_bytes:' "$G"
grep -q '^.equ PR_TRANSITION_POWER_RANKN_AFFINE_CLOSURE,1$' "$P"
grep -q '^.equ PR_TRANSITION_POWER_SCALAR_SHADOW_AUTHORITY,0$' "$P"
grep -q '^.equ PR_TRANSITION_POWER_FIXED_DIMENSION,0$' "$P"
grep -q '^.equ PR_TRANSITION_POWER_STATE_COUNT_ROUTE,0$' "$P"
grep -q '^.equ PR_TRANSITION_POWER_REPEAT_THRESHOLD,0$' "$P"
grep -q '^.equ PR_FIXED_AFFINE_AST_MATCHER,0$' "$P"
grep -q '^.equ PR_TRANSITION_POWER_RUNTIME_SELECTOR,0$' "$P"
grep -q '^.equ PR_RUNTIME_TRANSITION_POWER_MANAGER,0$' "$P"
! grep -RqsE '^g_collect_u64_transition_affine:|^g_transition_power_a:|^g_transition_power_b:|^gc_transition_power_mov_r8_rax:|^gc_transition_power_square:' compiler runtime surface tools

# Helper: require the generated program code to contain an actual absolute call
# to the native Rank-N power helper.  Merely embedding the runtime symbol is not
# sufficient evidence because every general binary contains the runtime image.
require_power_call() {
  bin=$1
  addr=$(nm -n build/general_runtime_template | awk '$3=="rankn_affine_power_u64" {print $1; exit}')
  [ -n "$addr" ]
  python3 - "$bin" "$addr" <<'PY'
import struct,sys
p=sys.argv[1]
a=int(sys.argv[2],16)
needle=b'\x48\xb8'+struct.pack('<Q',a)+b'\xff\xd0'
data=open(p,'rb').read()
if needle not in data:
    raise SystemExit(1)
PY
}

reject_power_call() {
  bin=$1
  addr=$(nm -n build/general_runtime_template | awk '$3=="rankn_affine_power_u64" {print $1; exit}')
  [ -n "$addr" ]
  python3 - "$bin" "$addr" <<'PY'
import struct,sys
p=sys.argv[1]
a=int(sys.argv[2],16)
needle=b'\x48\xb8'+struct.pack('<Q',a)+b'\xff\xd0'
data=open(p,'rb').read()
if needle in data:
    raise SystemExit(1)
PY
}

# Historical one-state LCG remains valid through the same Rank-N mechanism.
./build/wheelchairc devtrash/tests/general/lcg64_iterate_wrap.wh -o "$TMP/lcg" >/dev/null
[ "$("$TMP/lcg" 42 10)" = 'out00_bits=0x06593f7b1358c594' ]
[ "$("$TMP/lcg" 42 10000000)" = 'out00_bits=0x929c95aa45b914aa' ]
require_power_call "$TMP/lcg"

# The old 1.3.12 two-state recurrence now enters the same closure.  This is not
# a Fibonacci route: sibling-state references are ordinary Rank-N basis terms.
./build/wheelchairc devtrash/benchmarks/general_causal_state_1312/fib_iter.wh -o "$TMP/fib" >/dev/null
[ "$("$TMP/fib" 10)" = 'out00_bits=0x0000000000000037' ]
[ "$("$TMP/fib" 100)" = 'out00_bits=0x33db76a7c594bfc3' ]
[ "$("$TMP/fib" 500000000)" = 'out00_bits=0x3848ac567d65efc5' ]
require_power_call "$TMP/fib"

# Eight coupled semantic states prove that state cardinality is structural data,
# not an admission branch.  The ninth counter state remains outside the result
# slice because its value does not feed the published causal relation.
./build/wheelchairc devtrash/tests/general_rankn_causal_1315/int8_ring.wh -o "$TMP/ring" >/dev/null
[ "$("$TMP/ring" 1)" = 'out00_bits=0x0000000000000003' ]
[ "$("$TMP/ring" 10)" = 'out00_bits=0x0000000000001640' ]
[ "$("$TMP/ring" 100)" = 'out00_bits=0xbbbff58564000000' ]
require_power_call "$TMP/ring"

# General affine syntax: multiple states, literal scaling, subtraction and bias.
# z is deliberately non-affine but causally irrelevant and must disappear from
# the published-result slice instead of poisoning the whole iterate.
./build/wheelchairc devtrash/tests/general/rankn_affine_transition_wrap.wh -o "$TMP/aff" >/dev/null
[ "$("$TMP/aff" 0)" = 'out00_bits=0x0000000000000003' ]
[ "$("$TMP/aff" 10)" = 'out00_bits=0xffffffffffcebc9f' ]
[ "$("$TMP/aff" 100)" = 'out00_bits=0x8abbc534bc447693' ]
[ "$("$TMP/aff" 10000)" = 'out00_bits=0x870e8868b4c70483' ]
require_power_call "$TMP/aff"

# A genuinely non-affine published slice must not be forced through a private
# approximation or selector.  It falls back to the ordinary causal DAG.
./build/wheelchairc devtrash/tests/general/nonaffine_iterate_wrap.wh -o "$TMP/nonaff" >/dev/null
[ "$("$TMP/nonaff" 10)" = 'out00_bits=0x59d44b3118cfac50' ]
reject_power_call "$TMP/nonaff"

printf '%s\n' \
 'TRANSITION_POWER_RANKN_AFFINE_CLOSURE=PASS' \
 'SCALAR_TRANSITION_POWER_SHADOW_AUTHORITY=0' \
 'TRANSITION_POWER_FIXED_DIMENSION=0' \
 'TRANSITION_POWER_STATE_COUNT_ROUTE=0' \
 'TRANSITION_POWER_REPEAT_THRESHOLD=0' \
 'AFFINE_PROOF_AND_EMISSION_SINGLE_TRAVERSAL=PASS' \
 'IRRELEVANT_NONAFFINE_STATE_ERASURE=PASS' \
 'NONAFFINE_RESULT_GENERIC_DAG_FALLBACK=PASS' \
 'WHEELCHAIR_TRANSITION_POWER_1_3_67=PASS'
