#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

grep -q '^g_semantic_identity_representative:' compiler/general_frontend_x86_64.S
grep -q '^g_semantic_expr_is_total:' compiler/general_frontend_x86_64.S
grep -q '^g_semantic_prove_equal:' compiler/general_frontend_x86_64.S
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_PROOF_RELATIONS,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_IDENTITY_SHELL_ERASURE,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_COMPARISON_DUALITY,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_ASSOCIATIVE_REWRITE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_STRICT_FP_SEMANTIC_REASSOCIATION,0$' compiler/physical_reality.inc
grep -q '^.equ PR_STRICT_FP_SEMANTIC_COMMUTATION,0$' compiler/physical_reality.inc
! grep -RqsE 'semantic_(newton|fft|fibonacci|stencil|krylov|sort)_|semantic_algorithm_match' compiler runtime surface tools

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
for name in comm_direct comm_repeated nested_direct nested_proof identity_direct identity_shell compare_direct compare_dual strict_order; do
  ./bin/wheelchairc "devtrash/tests/semantic_convergence_1369/${name}.wh" -o "$TMP/${name}.bin" >/dev/null
  objcopy --only-section=.text -O binary "$TMP/${name}.bin" "$TMP/${name}.text"
done

cmp "$TMP/comm_direct.text" "$TMP/comm_repeated.text"
cmp "$TMP/nested_direct.text" "$TMP/nested_proof.text"
cmp "$TMP/identity_direct.text" "$TMP/identity_shell.text"
cmp "$TMP/compare_direct.text" "$TMP/compare_dual.text"

for name in comm_direct comm_repeated; do
  out="$($TMP/${name}.bin 5 9)"
  grep -q 'out00_bits=0x000000000000000e' <<<"$out"
done
for name in nested_direct nested_proof; do
  out="$($TMP/${name}.bin 4 5 6)"
  grep -q 'out00_bits=0x0000000000000036' <<<"$out"
done
for name in identity_direct identity_shell; do
  out="$($TMP/${name}.bin 5)"
  grep -q 'out00_bits=0x000000000000000c' <<<"$out"
done
for name in compare_direct compare_dual; do
  out="$($TMP/${name}.bin 5 9)"
  grep -q 'out00_bits=0x0000000000000001' <<<"$out"
done
strict_out="$($TMP/strict_order.bin)"
grep -q 'out00_bits=0x3ff0000000000000' <<<"$strict_out"
grep -q 'out01_bits=0x0000000000000000' <<<"$strict_out"

# The proof closure may compose safe relations, but must not become an algebra
# rewrite zoo. Associative regrouping and strict-FP arithmetic reordering remain
# absent by construction and by the release counterexample above.
! grep -RqsE 'semantic_(associate|reassociate|fastmath|fp_commute)_enable' compiler runtime surface tools

echo 'SEMANTIC_COMMUTATIVE_PROOF=PASS'
echo 'SEMANTIC_COMPOSITIONAL_PROOF=PASS'
echo 'SEMANTIC_IDENTITY_SHELL_ERASURE=PASS'
echo 'SEMANTIC_COMPARISON_DUALITY=PASS'
echo 'STRICT_FP_ORDER_PRESERVED=PASS'
echo 'SEMANTIC_ALGORITHM_MATCHER=0'
echo 'WHEELCHAIR_SEMANTIC_CONVERGENCE_1_3_69=PASS'
