#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
D=devtrash/tests/burn_machine_1374

./build.sh >/dev/null
echo 'BURN_LEVEL_BUILD=PASS'

# Architecture authority is singular and explicitly machine-carrier based.
grep -q '^.equ PR_BURN_LEVEL_MACHINE_FACTS,1$' compiler/physical_reality.inc
grep -q '^.equ PR_ADDRESSFACT_GPR_REGION_LIFETIME,1$' compiler/physical_reality.inc
grep -q '^.equ PR_CONSTANTFACT_SIMD_REGION_LIFETIME,1$' compiler/physical_reality.inc
grep -q '^.equ PR_IMMUTABLE_CARRIER_ALIASING,1$' compiler/physical_reality.inc
grep -q '^.equ PR_PACKET_STACK_ADDRESS_RELOAD,0$' compiler/physical_reality.inc
grep -q '^.equ PR_PACKET_CONSTANT_RELOAD,0$' compiler/physical_reality.inc
grep -q '^.equ PR_TOLERANT_REDUCE_MACHINE_FUSION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_MACHINE_FACT_SECOND_IR,0$' compiler/physical_reality.inc
grep -q '^.equ PR_MACHINE_FACT_WORKLOAD_MATCHER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_MACHINE_FACT_RUNTIME_POLICY_MANAGER,0$' compiler/physical_reality.inc
! grep -q '^ff_emit_cache_store:$' compiler/field_frontend_common_x86_64.S
echo 'MACHINE_FACT_AUTHORITY=PASS'

# Same mathematical program, both FP contracts and both physical vector widths.
for C in fieldc fieldc-native256; do
  build/$C "$D/poisson_weighted_tolerant.json" -o "$T/$C-fast" >/dev/null
  build/$C "$D/poisson_weighted_strict.json" -o "$T/$C-strict" >/dev/null
  if [ "$C" = fieldc ]; then expect=0x4616c695; else expect=0x4616c696; fi
  [ "$("$T/$C-fast" "$D/p16.whfld")" = "checksum_f32_bits=$expect" ]
  [ "$("$T/$C-strict" "$D/p16.whfld")" = "checksum_f32_bits=$expect" ]
done
echo 'BURN_LEVEL_ZERO_FLIP=PASS'

# Disassemble the generated AVX-512 LOAD image, not the compiler/runtime shell.
extract_generated() {
  local exe=$1 out=$2
  read off va sz <<EOH
$(readelf -lW "$exe" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOH
  dd if="$exe" of="$out.bin" bs=1 skip=$((off)) count=$((sz)) status=none
  objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$out.bin" > "$out.dis"
}
extract_generated "$T/fieldc-fast" "$T/fast"
extract_generated "$T/fieldc-strict" "$T/strict"

# Seven immutable neighborhood AddressFacts occupy the Region-resident GPR bank.
for pat in \
  '\[rbx\+r12\*4\]' '\[rcx\+r12\*4\]' '\[rdi\+r12\*4\]' \
  '\[rsi\+r12\*4\]' '\[r8\+r12\*4\]'  '\[r9\+r12\*4\]' \
  '\[r10\+r12\*4\]'; do
  grep -Eq "$pat" "$T/fast.dis"
done
echo 'ADDRESSFACT_GPR_BURN=PASS'

# Tolerant def/use proof burns square+reduction into the hidden accumulator FMA.
grep -Eq 'vfmadd231ps[[:space:]]+zmm5\{k1\},zmm1,zmm1' "$T/fast.dis"
! grep -Eq 'vfmadd231ps[[:space:]]+zmm5\{k1\},zmm1,zmm1' "$T/strict.dis"
grep -Eq 'vmulps[[:space:]]+zmm1,zmm1,zmm1' "$T/strict.dis"
echo 'TOLERANT_SQUARE_REDUCTION_MACHINE_FUSION=PASS'
echo 'STRICT_FP_MACHINE_ORDER_PRESERVED=PASS'

# No named workload route, no second machine IR, no fixed burn-level threshold.
! grep -RqsE '(^|[^A-Za-z])(poisson|stencil|fibonacci|mgpcg)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'burn_level.*(threshold|limit)[[:space:]]*=[[:space:]]*[1-9]' compiler runtime surface tools
echo 'MACHINE_WORKLOAD_MATCHER=0'
echo 'SECOND_MACHINE_IR=0'
echo 'FIXED_BURN_THRESHOLD=0'
echo 'WHEELCHAIR_BURN_LEVEL_MACHINE_FACTS_1_3_74=PASS'
