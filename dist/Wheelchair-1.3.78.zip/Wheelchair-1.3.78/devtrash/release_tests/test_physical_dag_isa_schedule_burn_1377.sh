#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
D=devtrash/tests/burn_machine_1374
F=devtrash/tests/field_1216
./build.sh >/dev/null
echo 'ISA_SCHEDULE_BURN_BUILD=PASS'

# Compile for one immutable target geometry. Runtime metadata may not masquerade
# as a codegen difference.
taskset -c 0-3 build/fieldc "$D/poisson_weighted_tolerant.json" -o "$T/fast" >/dev/null
taskset -c 0-3 build/fieldc "$D/poisson_weighted_strict.json" -o "$T/strict" >/dev/null
taskset -c 0-3 build/fieldc-native256 "$D/poisson_weighted_tolerant.json" -o "$T/fast256" >/dev/null
[ "$("$T/fast" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c695' ]
[ "$("$T/strict" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c695' ]
[ "$("$T/fast256" "$D/p16.whfld")" = 'checksum_f32_bits=0x4616c696' ]
echo 'ISA_SCHEDULE_ZERO_FLIP=PASS'

extract_generated() {
  local exe=$1 out=$2
  read off va sz <<EOH
$(readelf -lW "$exe" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOH
  dd if="$exe" of="$out.bin" bs=1 skip=$((off)) count=$((sz)) status=none
  objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$out.bin" > "$out.dis"
}
extract_generated "$T/fast" "$T/fast"
extract_generated "$T/strict" "$T/strict"

# Representative AVX-512 pressure case: Group width is not prescribed by the
# compiler.  On this target and this DAG the live-carrier proof naturally yields
# five independent packets (80 f32 values).  The four later packets are visible
# only as a consequence, not as a source-level width authority.
grep -Eq 'vfmadd231ps[[:space:]]+zmm15,zmm13,.*\+0x40\]' "$T/fast.dis"
grep -Eq 'vfmadd231ps[[:space:]]+zmm19,zmm13,.*\+0x80\]' "$T/fast.dis"
grep -Eq 'vfmadd231ps[[:space:]]+zmm23,zmm13,.*\+0xc0\]' "$T/fast.dis"
grep -Eq 'vfmadd231ps[[:space:]]+zmm27,zmm13,.*\+0x100\]' "$T/fast.dis"
grep -Eq 'add[[:space:]]+r12,0x50' "$T/fast.dis"
echo 'LIVE_MACHINEFACT_GROUP_WIDTH=PASS'

# The Physical depth order is the final ISA time axis.  All five center-stage
# operations appear before the first-neighbor stage; that stage is then issued
# horizontally across all five packet identities before the next depth.
python3 - "$T/fast.dis" <<'PY'
import re,sys
lines=open(sys.argv[1]).read().splitlines()
def first_after(rx,start=0):
    p=re.compile(rx)
    for i in range(start,len(lines)):
        if p.search(lines[i]): return i
    raise SystemExit('missing: '+rx)
# Unique later-packet center memory operands anchor the Group episode.
p1=first_after(r'vfmadd231ps\s+zmm15,zmm13,.*\+0x40\]')
p0=max(i for i,l in enumerate(lines[:p1]) if re.search(r'vfmadd231ps\s+zmm1,zmm0,zmm13',l))
p2=first_after(r'vfmadd231ps\s+zmm19,zmm13,.*\+0x80\]',p1+1)
p3=first_after(r'vfmadd231ps\s+zmm23,zmm13,.*\+0xc0\]',p2+1)
p4=first_after(r'vfmadd231ps\s+zmm27,zmm13,.*\+0x100\]',p3+1)
s0=first_after(r'vsubps\s+zmm1,zmm1,zmm6',p4+1)
s1=first_after(r'vsubps\s+zmm15,zmm15,.*\+0x40\]',s0+1)
s2=first_after(r'vsubps\s+zmm19,zmm19,.*\+0x80\]',s1+1)
s3=first_after(r'vsubps\s+zmm23,zmm23,.*\+0xc0\]',s2+1)
s4=first_after(r'vsubps\s+zmm27,zmm27,.*\+0x100\]',s3+1)
end=first_after(r'add\s+r12,0x50',s4+1)
if not (p0<p1<p2<p3<p4<s0<s1<s2<s3<s4<end):
    raise SystemExit('not depth-major')
# Later immutable LoadFacts must remain memory identities until consumption;
# do not resurrect the old shadow load carrier bank in this Group window.
win='\n'.join(lines[p0:end+1])
if re.search(r'vmovups\s+zmm(?:16|20|24|28),.*\+0x(?:40|80|c0|100)\]',win):
    raise SystemExit('shadow load carrier resurrected')
print('DEPTH_MAJOR_MACHINE_ORDER=PASS')
print('LOADFACT_MEMORY_OPERAND_BURN=PASS')
PY

# Strict reduction is an exact FP recurrence, so cross-packet regrouping is not
# contract-legal and naturally remains the canonical single-packet realization.
! grep -Eq 'vfmadd231ps[[:space:]]+zmm15,zmm13,.*\+0x40\]' "$T/strict.dis"
! grep -Eq 'add[[:space:]]+r12,0x50' "$T/strict.dis"
echo 'STRICT_REDUCTION_SCHEDULE_REORDER=0'

# Irregular/mixed truth stays on the canonical general path for both widths.
for C in fieldc fieldc-native256; do
  build/$C "$F/mixed.json" -o "$T/$C-mixed" >/dev/null
  cp "$F/out_3x5x7.whfld" "$T/$C-out.whfld"
  [ "$("$T/$C-mixed" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/$C-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
  cmp "$T/$C-out.whfld" "$F/expected_mixed_3x5x7.whfld"
done
echo 'GENERIC_MIXED_LAYOUT_ZERO_FLIP=PASS'

# Architecture laws: the existing Physical order and GroupFact remain sovereign.
grep -q '^.equ PR_PHYSICAL_DAG_ISA_SCHEDULE_BURN,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_DEPTH_MAJOR_ISA_EMISSION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_LOADFACT_DEFERRED_MATERIALIZATION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_LOADFACT_MEMORY_OPERAND_BURN,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_LOADFACT_SYNTHETIC_CARRIER_REQUIRED,0$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_PACKET0_BYTE_COPY_AUTHORITY,0$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_PACKET_MAJOR_BODY_AUTHORITY,0$' compiler/physical_reality.inc
grep -q '^.equ PR_POST_CODEGEN_MACHINE_SCHEDULER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_SCHEDULE_BURN_SECOND_IR,0$' compiler/physical_reality.inc
grep -q '^.equ GF_PHYSICAL_DEPTH_IS_FINAL_ISA_TIME_AXIS,1$' compiler/groupfact.inc
grep -q '^.equ GF_LOADFACT_LIFETIME_STARTS_AT_TRUE_CONSUMER,1$' compiler/groupfact.inc
grep -q '^.equ GF_LOADFACT_MAY_REMAIN_MEMORY_AT_TRUE_CONSUMER,1$' compiler/groupfact.inc
grep -q '^ff_emit_group_fma_direct_mem:$' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_group_packet_op:$' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_group_depth_schedule:$' compiler/field_frontend_common_x86_64.S
! grep -q '^ff_emit_group_packet_preload:$' compiler/field_frontend_common_x86_64.S
! grep -q '^ff_emit_group_packet_body:$' compiler/field_frontend_common_x86_64.S
! grep -RqsE 'schedule_burn.*(width|factor)[[:space:]]*=[[:space:]]*(2|3|4|5|8)([^0-9]|$)' compiler runtime surface tools
! grep -RqsE '(^|[^A-Za-z])(poisson|stencil|fibonacci|mgpcg)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
echo 'POST_CODEGEN_MACHINE_SCHEDULER=0'
echo 'SECOND_MACHINE_SCHEDULE_IR=0'
echo 'FIXED_SCHEDULE_WIDTH=0'
echo 'MACHINE_WORKLOAD_MATCHER=0'
echo 'WHEELCHAIR_PHYSICAL_DAG_ISA_SCHEDULE_BURN_1_3_77=PASS'
