#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
C="$ROOT/bin/wheelchairc"
X="$ROOT/bin/whexc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

fail() { printf 'human-shell 1.3.78: %s\n' "$*" >&2; exit 1; }

# One reporting authority only.  The human shell consumes already-proved facts;
# it may not grow optimization-subtype routes or duplicate character pictures.
grep -q '^human_shell_report_success:' compiler/human_shell_feedback_x86_64.S
grep -q '^human_shell_report_error:' compiler/human_shell_feedback_x86_64.S
grep -q '^surface_note_convergence_name:' compiler/surface_lowerer_x86_64.S
grep -Fq 'Repaired successfully.' compiler/human_shell_feedback_x86_64.S
grep -Fq 'Cheesed successfully.' compiler/human_shell_feedback_x86_64.S
grep -Fq 'Compiled successfully.' compiler/human_shell_feedback_x86_64.S
grep -Fq 'Compilation failed.' compiler/human_shell_feedback_x86_64.S
[ "$(grep -c '^hs_art_pattern:$' compiler/human_shell_feedback_x86_64.S)" -eq 1 ]
! grep -RqsE 'human_shell.*(fibonacci|recursion|alias|duplicate|identity|field|tensor)[_-]?(message|route|selector|branch)' compiler runtime surface tools
! grep -RqsE 'cheese_(fibonacci|recursive|alias|field|tensor)|repair_(keyword|identifier|newline)_message' compiler runtime surface tools

# Clean human WH is deliberately quiet except for the final result.
clean_out=$($C surface/examples/auto_repair_clean.wh -o "$TMP/clean")
[ "$clean_out" = 'Compiled successfully.' ] || fail 'clean output forked'

# Repair uses the same fixed geometry rendered through ! and reports its source
# position.  No internal compiler vocabulary may escape the human shell.
repair_out=$($C surface/examples/auto_repair_typos.wh -o "$TMP/repair")
grep -Fq '!' <<<"$repair_out" || fail 'repair portrait missing'
grep -Fq 'line 1:' <<<"$repair_out" || fail 'repair line missing'
grep -Fq 'Repaired successfully.' <<<"$repair_out" || fail 'repair result missing'
grep -Fq 'Compiled successfully.' <<<"$repair_out" || fail 'repair final result missing'
! grep -Eq 'topologyc:|fieldc:|sovereign|frontend|lowering|physical DAG|executor|native AOT' <<<"$repair_out" || fail 'internal term leaked through repair path'

# Repair precedes convergence.  Start from the canonical naive recurrence and
# perturb only the program keyword so both facts are present in one compilation.
sed '1s/^program /progra /' devtrash/tests/execution_form_convergence_1370/naive_two_lag.wh > "$TMP/repair_cheese.wh"
both_out=$($C "$TMP/repair_cheese.wh" -o "$TMP/repair_cheese")
repair_pos=$(grep -n -m1 'Repaired successfully\.' <<<"$both_out" | cut -d: -f1)
cheese_pos=$(grep -n -m1 'Cheesed successfully\.' <<<"$both_out" | cut -d: -f1)
[ -n "$repair_pos" ] && [ -n "$cheese_pos" ] && [ "$repair_pos" -lt "$cheese_pos" ] || fail 'Repair -> Convergence order violated'
grep -Fq 'line 1:' <<<"$both_out" || fail 'combined repair line missing'
grep -Fq 'line 5:' <<<"$both_out" || fail 'combined convergence line missing'

# Convergence has one user-facing success exit regardless of proof subtype.
cheese_out=$($C devtrash/tests/execution_form_convergence_1370/naive_two_lag.wh -o "$TMP/cheese")
grep -Fq 'Cheesed successfully.' <<<"$cheese_out" || fail 'convergence result missing'
grep -Fq 'line 5:' <<<"$cheese_out" || fail 'convergence line missing'
! grep -Eiq 'fibonacci|recursive|memo|dynamic programming|identity shell|duplicate|alias|groupization|vectorized' <<<"$cheese_out" || fail 'convergence subtype leaked'

semantic_out=$($C devtrash/tests/semantic_convergence_1368/repeated.wh -o "$TMP/semantic")
grep -Fq 'Cheesed successfully.' <<<"$semantic_out" || fail 'semantic convergence did not join fused exit'
! grep -Eiq 'alias|duplicate|identity|semantic convergence' <<<"$semantic_out" || fail 'semantic convergence subtype leaked'

# Error dominates every successful intermediate fact.  A repair may happen
# internally first, but the final visible state is only the multiplication-sign
# portrait plus the error location/result.
cat > "$TMP/repair_error.wh" <<'SRC'
progra repair_error
let cat: u64 = 1
let bag: u64 = 2
let x: u64 = bat + 1
publish x
SRC
set +e
error_out=$($C "$TMP/repair_error.wh" -o "$TMP/error" 2>&1)
error_rc=$?
set -e
[ "$error_rc" -ne 0 ] || fail 'ambiguous source unexpectedly accepted'
grep -Fq '×' <<<"$error_out" || fail 'error portrait missing'
grep -Fq 'line 4:' <<<"$error_out" || fail 'error line missing'
grep -Fq 'Compilation failed.' <<<"$error_out" || fail 'error result missing'
! grep -Fq 'Repaired successfully.' <<<"$error_out" || fail 'repair state leaked through final error'
! grep -Fq 'Cheesed successfully.' <<<"$error_out" || fail 'convergence state leaked through final error'
! grep -Eq 'topologyc:|fieldc:|sovereign|frontend|lowering|physical DAG|executor|native AOT' <<<"$error_out" || fail 'internal term leaked through error path'

# Native field WH joins the same human report rather than maintaining a private
# boundary/type/expression diagnostic branch.
cp devtrash/tests/field_surface_1218/boundary_invalid.whex "$TMP/field_bad.wh"
set +e
field_err=$($C "$TMP/field_bad.wh" -o "$TMP/field_bad" 2>&1)
field_rc=$?
set -e
[ "$field_rc" -ne 0 ] || fail 'unproved field boundary unexpectedly accepted'
grep -Fq '×' <<<"$field_err" || fail 'field error did not use fused portrait'
grep -Fq 'Compilation failed.' <<<"$field_err" || fail 'field error did not use fused result'
! grep -Eq 'fieldc:|boundary access|native-field human surface|requires f32|expression slice' <<<"$field_err" || fail 'field-specific diagnostic branch leaked'

# Expert WHEX remains expert: no human phrases and no character-art conversion.
expert_out=$($X surface/whex_examples/heat_en.whex -o "$TMP/expert")
grep -Eq 'topologyc:|fieldc:' <<<"$expert_out" || fail 'expert output unexpectedly hidden'
! grep -Eq 'Repaired successfully\.|Cheesed successfully\.|Compiled successfully\.|Compilation failed\.' <<<"$expert_out" || fail 'human shell leaked into WHEX'

printf '%s\n' \
  'HUMAN_SHELL_SINGLE_REPORT_AUTHORITY=PASS' \
  'HUMAN_SHELL_REPAIR_THEN_CONVERGENCE=PASS' \
  'HUMAN_SHELL_CONVERGENCE_SUBTYPE_BRANCHES=0' \
  'HUMAN_SHELL_ERROR_DOMINATES_REPAIR=PASS' \
  'HUMAN_SHELL_LINE_PREFIX=PASS' \
  'HUMAN_SHELL_INTERNAL_TERM_LEAK=0' \
  'HUMAN_SHELL_FIELD_BRANCHES_FUSED=PASS' \
  'WHEX_EXPERT_OUTPUT_PRESERVED=PASS' \
  'WHEELCHAIR_HUMAN_SHELL_FEEDBACK_1_3_78=PASS'
