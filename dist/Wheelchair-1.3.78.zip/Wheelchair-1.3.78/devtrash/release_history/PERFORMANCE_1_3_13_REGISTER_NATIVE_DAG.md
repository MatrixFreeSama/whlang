# Wheelchair 1.3.13 Register-Native DAG Performance Diagnostic

## Scope

These are same-host diagnostics for the specific recurrence probes that exposed the stack-expression gap. They are not a language-wide performance claim and not a cross-machine leaderboard.

Host used for this development diagnostic: AMD EPYC 9V74 80-Core Processor under the current container/VM environment. Runs were CPU-pinned. Each result below is the median of seven measured whole-process runs after warm-up.

## 1.3.12 -> 1.3.13

| Probe | N | 1.3.12 median | 1.3.13 median | Throughput change |
|---|---:|---:|---:|---:|
| Fibonacci | 500,000,000 | 568.208 ms | 142.973 ms | 3.974x |
| Lucas | 100,000,000 | 121.097 ms | 30.934 ms | 3.914x |
| Tribonacci | 50,000,000 | 105.080 ms | 31.211 ms | 3.367x |
| strict floating recurrence | 10,000,000 | 66.658 ms | 60.472 ms | 1.102x |

All compared outputs were bit-identical between 1.3.12 and 1.3.13 for the measured probes.

## Expert-C diagnostic

For the same 500,000,000-step Fibonacci boundary on this host, an independently built GCC `-O3 -march=native` C control measured 162.223 ms median in the same diagnostic session, versus 142.973 ms for the 1.3.13 development image.

This one-host result is recorded only as evidence that removal of the artificial stack dataflow can reach the hand-tuned/native-compiler regime. It must not be generalized into a universal claim that Wheelchair is faster than C.

## Why the improvement occurred

The decisive change is structural. The 1.3.12 recurrence state was already resident in registers, but arithmetic operands/results still travelled through generated machine-stack operations. 1.3.13 keeps admitted expression values in registers and commits next-generation state only after old-generation consumers complete.

For the proven two-state swap-plus-wrap-add relation, the transition DAG selects `xadd` directly. The selection is structural and contains no Fibonacci/Lucas name test.

The floating recurrence improves less because strict scalar floating dependency latency remains real after the artificial transport is removed. 1.3.13 removes unnecessary transport but does not claim to erase true arithmetic dependence.
