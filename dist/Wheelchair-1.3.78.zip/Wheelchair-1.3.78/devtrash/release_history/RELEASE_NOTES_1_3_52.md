# Wheelchair 1.3.52 release notes

1.3.52 is an architecture-aging release. It adds no source syntax, mathematical semantic, algorithm family, scheduler, compatibility path, or ISA backend.

## Convergence

- Removed historical revision identity from active Tensor and Physical-Reality filenames, symbols, macros and local labels.
- Collapsed `physical_reality_136/137/138.inc` into the single current authority `compiler/physical_reality.inc`.
- Removed dead byte-copy compiler aliases `topologyc-wide` and `topologyc-wide-native256`; the current driver already had no live selection path to them.
- Removed unreachable production remnants `compiler/json_parser_x86_64.S`, `compiler/physical_vector_shapes.inc`, and the obsolete native256 relink helper.
- Reduced the production `build.sh` from 1,219 to 199 lines by moving historical release-banner proof out of normal construction. Historical regression logic remains under `devtrash/release_tests`.
- Kept all current Tensor, Field, General, mathematical, Physical-DAG and ISA semantics unchanged.

## Performance

Full self-build median on the release host changed from 1.006139 s (1.3.51, five samples) to 0.804347 s (1.3.52, seven samples): 1.2509x build throughput and 20.06% less wall time.

The mature Newton-Jv generated ELF is byte-identical between 1.3.51 and 1.3.52, SHA-256 `bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac`. Runtime structural speedup for that probe is therefore 0%; observed wall-clock differences between the identical executables are noise.

Canonical `bin/` payload falls from 7,383,384 bytes to 5,325,312 bytes, a 27.88% reduction, principally by deleting the two dead wide aliases.
