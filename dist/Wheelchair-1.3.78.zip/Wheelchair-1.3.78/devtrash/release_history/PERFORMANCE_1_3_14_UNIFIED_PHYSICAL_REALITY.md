# Wheelchair 1.3.14 Unified Physical Reality Performance Note

## Boundary

This note records same-host diagnostic measurements for three unrelated FP state-update kernels. It is evidence about the newly unified physical path, not a language-wide performance claim.

- 50,000,000 update steps per measured process.
- five interleaved measured rounds.
- CPU affinity fixed to one CPU in the benchmark harness.
- C and GFortran use native optimized builds with fast-math disabled and FP contraction disabled/protected as appropriate.
- compared final FP64 outputs are bit-identical.

## Median wall time

| case | Wheelchair 1.3.14 | C | GFortran |
|---|---:|---:|---:|
| damped oscillator | 127.093 ms | 110.904 ms | 107.688 ms |
| thermal3 | 188.524 ms | 187.771 ms | 188.387 ms |
| Maxwell point | 103.508 ms | 86.718 ms | 87.308 ms |

Raw rounds are in `PERFORMANCE_1_3_14_SIMULATION.csv`.

## Machine-code finding

The key improvement is not a workload-specific formula. The unified scalar FP path removes the former fixed-depth XMM scratch discipline, emits three-operand VEX scalar arithmetic, shares constant and temporary physical-carrier authority, and releases temporary carriers after their last proven consumer.

The three-node thermal probe contains four distinct hot constants and therefore guards the historical fixed-three-constant residency cliff. In the validated 1.3.14 hot loop all four are preheader-resident and the steady-state loop contains no `movabs -> movq` constant reconstruction.

## Interpretation

1.3.14 demonstrates that architecture consolidation can improve both maintainability and generated code. It does not claim that Wheelchair now universally beats C or Fortran; the damped-oscillator and Maxwell probes still show remaining target-code scheduling/selection headroom.
