# Wheelchair 1.3.54 physical footprint and performance note

1.3.54 is an architecture-aging release, not a runtime-optimization release.

## Static BSS reduction

On the release build:

| executable | 1.3.53 BSS | 1.3.54 BSS | reduction |
|---|---:|---:|---:|
| `wheelchairc` | 124,802,112 B | 21,520 B | 99.9828% |
| `topologyc` | 134,356,800 B | 9,576,208 B | 92.8726% |
| `fieldc` | 134,980,480 B | 10,199,888 B | 92.4434% |

The reduction comes from removing large static Surface slabs and replacing them with
structure-sized mappings.  File sizes rise slightly because allocator logic is now real
code rather than zero-filled BSS declarations.

## Build timing

Five clean full builds on the same release host:

- 1.3.53: 1.19, 1.16, 1.19, 1.14, 1.17 s; median 1.17 s
- 1.3.54: 1.16, 1.21, 1.14, 1.15, 1.15 s; median 1.15 s

That is about 1.017x build throughput / 1.71% lower median wall time.  The difference is
small enough that the release does not treat it as a universal speed claim.

## Runtime stability

The mature Newton-Jv generated ELF is byte-identical between 1.3.53 and 1.3.54, so its
structural runtime speed change is exactly 0% at the machine-image level.  Any wall-clock
difference between those identical files is measurement noise.
