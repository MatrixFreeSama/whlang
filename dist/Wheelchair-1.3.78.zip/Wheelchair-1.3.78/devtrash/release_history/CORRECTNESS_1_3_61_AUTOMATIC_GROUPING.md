# Wheelchair 1.3.61 Automatic Grouping correctness

Release validation exercises the production `synthesize_group_fact` implementation directly from `topologyc_core.o`.

Verified cases:

- rank-0 / one-member structure -> Scalar;
- one logical axis -> Vector;
- Rank-2 logical geometry -> Group;
- operation-affine body replication lifts a rank-1 relation to Group;
- a second carrier changes geometry only when a reduction relation exists;
- logical rank 65,535 remains ordinary data with no rank admission table;
- diagnostic group-cardinality overflow becomes unknown and does not reject;
- all four Tensor physicalizers use GroupFact and contain none of the retired physical-plan names.

Inherited ShapeFact-N, selector, physical-plan and pure-composition release tests remain green. `stdpf-1909261508` also passes 11/11 native examples and a 4096-link generic-proof convergence chain on the 1.3.61 compiler.
