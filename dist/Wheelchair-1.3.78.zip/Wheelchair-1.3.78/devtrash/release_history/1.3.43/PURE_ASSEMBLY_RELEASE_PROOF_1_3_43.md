# Pure Assembly Release Proof 1.3.43

Production compiler/runtime authority remains handwritten x86-64 assembly plus shell build logic. 1.3.43 adds no C/C++ production source, numerical library, JIT, root runtime, precision-specific root solver, root scheduler, or external Fourier implementation.

The new P>64 comparison authority lives in `runtime/rankn_precision_physical_x86_64.inc`; its generated-program entry is exposed through the existing runtime-offset mechanism and general frontend. Root precision assimilation remains compile-time AST/Structured-Fact/ValueFact construction in `compiler/surface_lowerer_x86_64.S`.

Python, Decimal, Fraction and GMP appear only in `devtrash/` release tests/oracles and are not linked into production binaries.
