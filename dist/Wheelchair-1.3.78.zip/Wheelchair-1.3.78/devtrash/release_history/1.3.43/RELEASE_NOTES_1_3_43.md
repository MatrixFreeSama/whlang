# Wheelchair 1.3.43 Release Notes

1.3.43 assimilates parameterized floating precision into the existing sparse RootRelation instead of creating a high-precision root family.

## Root precision

- `root` stays in the representation of its mathematical facts, including arbitrary `fpP`, `P > 64`.
- Fixed `DBL_EPSILON` and `DBL_MAX` acceptance gates are removed from RootRelation.
- Zero and one inside RootRelation are precision-neutral identities rather than hard f64 constants.
- Final acceptance uses the Newton correction becoming unrepresentable at the candidate's own scale.
- Real projection reuses the same representation-stability fact for the imaginary carrier.
- `fpP` comparisons use one shared sign/exponent/significand authority and branchless predicate projection.

## Fourier physical boundary

High-precision root validation exposed a 32/64-bit stack-field overlap in AOT Fourier unpack: a 64-bit bound read combined the 32-bit `n64` field with the adjacent packed-geometry field. The bound is now read at its actual 32-bit width. Dense division-produced significands therefore agree with exact arithmetic under AOT geometry without adding a precision-specific route.

## Compatibility

The 1.3.42 f64 RootRelation outputs are retained by regression. Existing native mathematics, Rank-N mathematics, structured mathematics, 1.3.41 mathematics fusion, parameterized precision and native Fourier exact-oracle gates remain green.
