# Correctness Gate 1.3.43: Root Precision Fusion

`devtrash/release_tests/test_root_precision_fusion_1343.sh` verifies:

- one numeric `rankn_fp_cmp` authority implements all P>64 ordered/equality comparisons;
- signed and zero comparisons operate on represented values rather than carrier references;
- dense `17/12` significands squared at fp127 and fp191 agree with an independent exact Fraction/RNE oracle under AOT packed Fourier geometry;
- fp65, fp127 and fp521 all execute the same RootRelation and return their own `out_rankn_fp` carriers;
- nine Newton generations for sqrt(2) match independent high-precision RNE significands at all three precisions;
- the imaginary projection is zero in the same wide representation;
- active source contains no named-width root implementation or precision selector;
- fixed binary64 epsilon and maximum-finite constants are absent from RootRelation.

The final release gate reruns the 1.3.34 native/Rank-N math gates, 1.3.36 structured math, 1.3.40 parameterized precision and Fourier GMP oracle, 1.3.41 mathematics fusion, and 1.3.42 root relation gate.
