# Root Precision Fusion 1.3.43

## Purpose

1.3.43 does not add a wide-root implementation. It removes the remaining f64 assumptions from the existing sparse RootRelation and lets that relation parasitize the already parameterized `fpP` ValueFact machinery.

## One relation, one precision flow

`root(x, expr, guess[, iterations])` still owns one compile-time Newton relation. Zero and one are precision-neutral semantic facts. Arithmetic, structured complex operations, symbolic differentiation and result projection inherit the representation selected by the existing precision meet.

For `P > 64`, comparison is now a single `rankn_fp_cmp` authority over normalized sign, exponent and significand. It has no named-width route and returns only -1, 0 or +1; boolean predicates are branchless projections in the general frontend.

## Representation-native acceptance

The former fixed binary64 epsilon and maximum-finite checks are absent. The final Newton correction

```text
delta = f(z) / f'(z)
```

is the acceptance witness. If `f(z)` is exactly zero, or if `f'(z)` is nonzero and both correction components are too small to alter the candidate's current representation scale, the candidate is valid. Real projection reuses the same representation-stability relation for the imaginary component.

This makes precision stricter naturally as P grows. No precision table or root tolerance branch exists.

## Fourier boundary correction

High-precision root pressure exposed a physical-layout bug outside RootRelation. Fourier unpack stored `n64` as a 32-bit fact at stack offset 40 and the AOT packed geometry in the adjacent 32 bits at offset 44, but one final-limb bound comparison loaded 64 bits. With nonzero AOT geometry, the upper geometry word was therefore interpreted as part of `n64`, permitting a cross-carrier read for dense tail digits.

The boundary now compares the exact 32-bit `n64` fact. Runtime-derived and AOT-carried Fourier geometry therefore use identical significand bounds. No precision-specific workaround or second multiplication path was introduced.

## Sparse rule

The release follows A-intersection-B rather than A+B:

```text
RootRelation
  intersect precision-neutral identities
  intersect fpP numeric compare
  intersect existing complex arithmetic
  intersect representation stability
  -> one ValueFact/Physical-DAG path
```

There is no `root_fp128`, `root_fp256`, root precision selector, high-precision root runtime, or compatibility fallback.
