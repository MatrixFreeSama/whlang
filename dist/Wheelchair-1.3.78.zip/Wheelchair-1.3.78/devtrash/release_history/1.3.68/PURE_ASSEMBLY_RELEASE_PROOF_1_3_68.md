# Pure assembly release proof 1.3.68

The production compiler/runtime path remains handwritten x86-64 assembly with direct static ELF emission. Human semantic convergence is implemented in `compiler/general_frontend_x86_64.S` and adds no C/C++ backend, LLVM, MLIR, JIT, bytecode VM, Python compiler generator or vendor code-generation layer.

`g_semantic_converge_symbols`, `g_semantic_resolve_symbol`, `g_semantic_expr_is_pure` and `g_semantic_json_equal` operate entirely at AOT compile time. Canonical representatives are stored in the existing General symbol arena; no runtime table or convergence helper is emitted into user programs.

`build.sh` reconstructs the canonical production compilers from `compiler/`, `runtime/`, `surface/` and `tools/` and contains a 1.3.68 gate that rejects a second semantic IR authority, algorithm-name matcher, fixed convergence rounds, runtime convergence manager and strict-FP reassociation authority.

The generated `build/` workspace is excluded from the release archive after final production binaries are copied into `bin/`.
