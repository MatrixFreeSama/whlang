# Wheelchair 1.3.68 semantic-convergence correctness

The correctness contract is semantic zero-flip: convergence may erase a difference in human spelling only when the compiler can prove that no observable semantic difference is being erased.

## Proof boundary

The first production proof class admits only General `compute` bindings whose expression trees are immutable scalar structure over literals, inputs and earlier compute representatives. Direct aliases also require identical declared type. Exact-tree equality preserves JSON node type, object keys, literal spans, operation order, argument order, casts and declared type.

No associative or commutative rewriting is performed. In particular, strict floating-point expressions are not reassociated. The release test fixes this with the counterexample `a=1e16, b=-1e16, c=1`: `(a+b)+c` remains `1.0` while `a+(b+c)` remains `0.0`.

Mutable state, axis values, field/load accesses, dictionary structure and other expressions outside the proof class are not converged. An unproved expression simply follows the pre-existing path.

## Materialization invariant

A converged symbol points to an earlier canonical representative in the existing symbol record. Emission and causal-reference construction resolve this pointer before machine materialization. Thus a converged alias/exact duplicate does not introduce a second producer fragment, while every downstream consumer observes the same canonical fact.

## Regression evidence

`devtrash/release_tests/test_semantic_convergence_1368.sh` passes:

- `SEMANTIC_ALIAS_CONVERGENCE=PASS`
- `SEMANTIC_EXACT_TREE_CONVERGENCE=PASS`
- `STRICT_FP_ORDER_PRESERVED=PASS`
- `HUMAN_FORM_TEXT_IDENTITY=PASS`
- `WHEELCHAIR_SEMANTIC_CONVERGENCE_1_3_68=PASS`

The pre-existing human-surface convergence and pure-composition convergence release tests also pass unchanged. Before the version bump, the full 1.3.67 Rank-N transition-power gate passed against the modified compiler source, confirming that the new upstream representative discipline did not disturb the existing recurrence/Physical path.
