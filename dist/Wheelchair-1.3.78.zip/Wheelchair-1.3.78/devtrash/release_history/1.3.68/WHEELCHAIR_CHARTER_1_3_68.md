# Wheelchair Charter 1.3.68

- Human spelling is evidence, not a performance authority.
- Automatic convergence is not auto-repair. A valid spelling may disappear only under a proof of semantic equivalence.
- Semantic zero-flip is mandatory. Unproved differences remain distinct.
- Convergence occurs after type/numeric-contract proof and before first machine-fragment materialization.
- The existing General symbol record owns canonical semantic identity. A second canonical AST/IR is prohibited.
- Algorithm names, workload identities and "expert" levels are not dispatch keys.
- No fixed convergence round count, rewrite budget or size threshold may decide semantic identity.
- Strict floating-point operation order remains semantic fact unless an explicit user contract says otherwise; 1.3.68 introduces no reassociation authority.
- Mutable state, effectful/non-pure structure and unsupported relations are preserved rather than guessed away.
- Downstream ValueFact, ShapeFact-N, GroupFact, Physical Reality and Physical DAG remain the optimization/realization authority.
- A converged binding owns no duplicate physical producer fragment.
- New convergence laws must age into existing fact authorities instead of accumulating per-domain optimizer families.
