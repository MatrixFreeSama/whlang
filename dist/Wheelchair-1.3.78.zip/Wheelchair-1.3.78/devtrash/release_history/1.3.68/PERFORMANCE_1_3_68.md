# Wheelchair 1.3.68 performance note

1.3.68 is primarily an architecture-convergence release, not a new benchmark claim.

The useful performance property is earlier erasure of redundant human structure. An alias chain, a repeated pure compute and the direct spelling of the same relation all reach byte-identical generated `.text` in the release gate. A converged compute is skipped before fragment emission, so duplicate human spelling does not become an additional machine producer that must later be repaired by the Physical backend.

No universal runtime speedup is claimed. For cases that the existing ValueFact/Physical machinery already canonicalized, the final ISA may be unchanged. That is desirable: 1.3.68 moves equivalence proof earlier and removes dependence on human form without creating a competing optimization authority.

Compile-time convergence has no fixed rounds or runtime component. The current General implementation performs one source-topological causal sweep and retains the old compiler/runtime execution architecture.
