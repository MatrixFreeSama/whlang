# Wheelchair 1.3.68 Human Semantic Convergence aging

1.3.68 fills the previously empty boundary between typed human semantics and first physical materialization. The architecture is now:

`human surface -> typed semantic facts -> semantic representative fixed point -> Physical Reality -> Physical DAG -> ISA`

The new capability is deliberately aged into the old General symbol authority instead of creating a canonical-AST layer. Each existing 64-byte symbol already owns identity, type, slot and DOM evidence. Offsets `+40/+48/+56` now carry the canonical semantic representative and compile-time convergence proof state. No `ConvergenceNode`, secondary graph or optimizer-plan object exists.

## Placement

The convergence sweep runs immediately after `.binding_decl_done`. At this point all General declarations have passed source-order registration and type inference, and overflow/precision contracts are known. It runs before `.codegen`, before `g_fragment_begin`, and therefore before a human spelling can become an independently materialized machine fragment.

This placement is later than the human parser because strict floating-point, overflow and type facts are required for a zero-flip proof. It is earlier than the causal/Physical layer because convergence is intended to erase human-form distinctions rather than repair machine fragments after they already exist.

## Fixed point without pass zoo

General bindings are already topologically ordered by source declaration. A compute can therefore converge only to an already-established representative. One causal sweep reaches the available closure. There is no global retry loop, fixed iteration count, convergence threshold or workload route.

The current proof class is monotone and intentionally narrow:

- immutable input/compute leaves may participate;
- a direct alias requires identical declared type;
- exact pure expression trees compare after canonical leaf resolution;
- operation and argument order are preserved;
- axis, state, field, load, dictionary and other non-pure structures remain outside the closure.

When proof fails, nothing is rewritten. The symbol remains its own representative.

## Downstream aging

`g_emit_expr` resolves a variable to its canonical semantic representative before loading a slot. Causal reference collection performs the same resolution before locating the producer fragment. A compute whose representative is another symbol emits no duplicate fragment. This makes convergence a property of the existing frontend-to-Physical chain rather than a parallel optimizer.

Tensor, Field and the human surface do not receive private convergence engines in this release. Their existing ShapeFact/Axis/Operator and Physical authorities remain intact. The architectural direction is to let future proven relations join the same fact authority, not to grow per-language algorithm matchers.
