# Wheelchair 1.3.68 release notes

1.3.68 establishes human semantic convergence in the existing General frontend. It is not an auto-repair subsystem and it does not add an "expert optimizer" level. After declaration, type and numeric-contract proof, but before the first machine fragment is materialized, immutable scalar bindings may converge to an existing canonical semantic representative when equivalence is exact.

The representative lives inside the existing 64-byte General symbol record. Direct aliases of identical type collapse to the referenced representative. Pure expression trees may collapse when their JSON semantic structure is exactly equal after variable leaves are resolved to canonical representatives. Operation order, argument order, literal spelling/bits, casts and declared type remain part of identity. Strict floating-point reassociation is therefore not introduced.

The first proof class intentionally excludes axis, mutable state, field/load, dictionary and other non-pure structures. If equivalence is not proved, the original binding remains distinct and follows the ordinary compiler path. There is no algorithm-name matcher, fixed convergence round count, rewrite budget, second IR, runtime convergence manager, JIT or autotuner.

Downstream expression emission and causal-edge construction resolve the canonical representative before materialization. A converged compute does not own a second machine fragment. Existing ValueFact, ShapeFact-N, GroupFact, Physical Reality, Physical DAG and machine canonicalization remain the sole downstream optimization authorities.

The release gate is `devtrash/release_tests/test_semantic_convergence_1368.sh`. It proves alias convergence, exact-tree convergence, identical generated `.text` for three different human spellings, and a strict-FP non-associativity counterexample whose two results remain observably different.
