# Wheelchair 1.3.18 Emergent Outward Expansion — same-host diagnostic

This evidence isolates execution-context materialization. Numerical lowering is unchanged from 1.3.17.

The benchmark host exposed five CPUs to the container. 1.3.17 and 1.3.18 binaries were compiled from identical sources and measured in interleaved runs.

| probe | 1.3.17 median wall | 1.3.18 median wall | change |
|---|---:|---:|---:|
| lightweight Tensor reduction, 100M | 14.481 ms | 6.953 ms | 2.083x throughput |
| heavy FSI, 100M | 57.532 ms | 57.375 ms | approximately unchanged |

For the lightweight 100M probe:

- median user CPU time: 61.271 ms -> 28.898 ms;
- median system CPU time: 1.112 ms -> 0.179 ms;
- median voluntary context switches: 2699 -> 337;
- median involuntary context switches: 18 -> 7.

This is the intended structural result: lightweight independent work is no longer forced into one Linux execution lifetime per eligible split, while heavy work remains profitable to expose outward.

The expansion condition is not the benchmark size. The generated program compares immutable same-dimension physical costs produced during AOT compilation. No runtime CPU supply is queried.

## Strict C / Fortran same-task rematch

A separate 21-round interleaved rematch used all five CPUs exposed by the container. GCC/GFortran 14.2 were compiled with `-O3 -march=native -mtune=native -fopenmp -fno-fast-math -ffp-contract=off`; Fortran also used `-fprotect-parens`. The FSI references split the two periodic boundaries from the interior and use OpenMP SIMD plus power-of-two masks, avoiding a deliberately scalar reference.

| probe | Wheelchair 1.3.17 | Wheelchair 1.3.18 | GCC C | GFortran |
|---|---:|---:|---:|---:|
| lightweight Tensor reduction, 100M | 15.492 ms | **7.773 ms** | 20.659 ms | 20.677 ms |
| FSI, 100M | 56.997 ms | **46.626 ms** | 70.313 ms | 63.084 ms |
| 7-state rigid-body causal control, 1M | n/a | 15.359 ms | **9.706 ms** | 10.132 ms |

The lightweight reduction is bit-identical across Wheelchair/C/Fortran. FSI is a tolerant reduction; the four outputs differ only by a few ULP and remain inside the source tolerance. The rigid-body control is bit-identical and intentionally shows that 1.3.18 does not claim universal superiority: its resource-grain change targets outward execution materialization, not scalar causal arithmetic.
