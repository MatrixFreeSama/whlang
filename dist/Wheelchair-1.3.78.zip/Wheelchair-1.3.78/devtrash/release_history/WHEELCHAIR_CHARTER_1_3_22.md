# Wheelchair Charter 1.3.22

## Predicate ValueFacts are not control-flow decorations

A predicate is an ordinary proved ValueFact. Its physical existence is governed by dependency, version and lifetime, not by how many times a programmer wrote the same `if`, comparison, or `select` guard.

1. **No new information, no repeated physical question.** An exactly equivalent materialized predicate remains authoritative while every input version remains authoritative.
2. **Reuse must preserve causality.** If generated code consumes a previously materialized PredicateFact that the source syntax did not name, the Physical DAG must receive the corresponding dependency edge.
3. **No repetition threshold.** Two, four or four thousand textual repetitions do not define an optimization route. Validity of the PredicateFact does.
4. **No Boolean runtime.** Predicate lifetime, identity and reuse are AOT compiler facts. There is no runtime predicate cache, manager or scheduler.
5. **No fixed AST private doors.** A particular boundary-select spelling, state count, workload name or benchmark shape may not own a private lowering path.
6. **Delete historical specialization rather than preserve it for compatibility.** A useful mathematical idea may return only after being absorbed into a general proof vocabulary.
7. **The old architecture remains sovereign.** Predicate sparsification is another consequence of Physical Reality / Physical DAG / ValueFact lifetime, not a sibling architecture.

The unifying rule remains: a physical action that produces no new information should not be repeated.
