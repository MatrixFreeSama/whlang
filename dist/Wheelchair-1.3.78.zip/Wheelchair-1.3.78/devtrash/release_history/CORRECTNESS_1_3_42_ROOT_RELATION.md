# Correctness Gate 1.3.42: Sparse Root Relation

The release gate `devtrash/release_tests/test_root_relation_1342.sh` verifies:

- omitted iteration count is exactly the five-generation default;
- explicit iteration count is honored at AOT;
- `sqrt(2)` is emitted as a valid real projection with zero imaginary carrier;
- `x^2+1` is empty at the default budget and resolves to `+i` at eight generations from the release seed;
- a constant nonzero relation produces sparse empty output rather than divide-by-zero failure;
- `exp(x)=0` produces no accepted candidate at the default budget;
- `sin(x)=0` near 3 converges to pi through existing complex transcendental semantics;
- only one `s_parse_root_call` authority exists and no real/complex/fallback root solver family exists.

The older native mathematics, Rank-N mathematics, structured mathematics, mathematics fusion, parameterized precision and Fourier precision gates are rerun by the final 1.3.42 release gate.
