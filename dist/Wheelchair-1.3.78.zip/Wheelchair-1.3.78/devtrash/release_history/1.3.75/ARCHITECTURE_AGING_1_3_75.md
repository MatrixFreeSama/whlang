# Architecture Aging 1.3.75

The 1.3.74 carrier burn answered where a fact lives. 1.3.75 removes one more translation boundary: an exact immutable coefficient now determines the final x86 operator form directly. Physical-DAG facts are not copied into a late optimizer graph. Machine realization consumes the same fact and emits its terminal hardware meaning.

`x * (+1)` contributing to an accumulator becomes ADD, `x * (-1)` becomes SUB, and `x * 0` disappears only under the tolerant contract. Strict FP keeps the source-proved operator order. Existing depth-sorted Physical-DAG order continues directly into emission; there is no second scheduler authority.
