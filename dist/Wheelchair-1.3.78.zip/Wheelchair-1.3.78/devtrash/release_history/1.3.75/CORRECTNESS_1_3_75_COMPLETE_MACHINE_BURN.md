# Correctness 1.3.75

Release gates verify identical numerical results for strict and tolerant reference Field programs, exact strict preservation, AddressFact GPR burn from 1.3.74, and tolerant operator identity burn in generated AVX-512 machine code. The Poisson-shaped regression is evidence only; compiler code contains no Poisson/stencil workload matcher.
