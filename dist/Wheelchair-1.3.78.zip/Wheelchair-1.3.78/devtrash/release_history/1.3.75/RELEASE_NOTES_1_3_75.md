# Wheelchair 1.3.75

1.3.75 ages burn-level realization through the final operator form. The Physical DAG is unchanged and remains the sole ordering authority. Under tolerant floating-point semantics, immutable ConstantFacts with exact values +1, -1, and 0 no longer survive as multiply operations inside accumulator FMAs: the emitter realizes them directly as ADD, SUB, or no operation. Strict floating-point order is unchanged.

No workload matcher, late graph rewrite, second machine scheduler IR, fixed packet-unroll rule, or runtime issue manager was added.
