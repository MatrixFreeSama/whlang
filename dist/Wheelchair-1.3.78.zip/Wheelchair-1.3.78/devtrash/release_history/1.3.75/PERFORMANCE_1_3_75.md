# Performance 1.3.75

The principal evidence is machine-form reduction rather than a benchmark claim. In the existing seven-neighbor weighted Field stress case, the tolerant direct kernel changes from one center FMA plus six `x*(-1)` FMAs to one center FMA plus six `vsubps`. AddressFact GPR residency and square-reduction FMA from 1.3.74 remain intact. Strict code retains its original multiply/add sequence.
