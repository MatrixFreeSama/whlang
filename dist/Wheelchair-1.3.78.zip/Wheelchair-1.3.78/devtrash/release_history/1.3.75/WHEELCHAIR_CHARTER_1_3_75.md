# Wheelchair Charter 1.3.75

A proved fact may not be translated back into a generic temporary or generic operator at the final machine boundary. Physical facts flow directly into carrier lifetime, operator form, and causal-depth order. No workload names, fixed optimization thresholds, compatibility backends, JIT, or second scheduling IR are authorities.
