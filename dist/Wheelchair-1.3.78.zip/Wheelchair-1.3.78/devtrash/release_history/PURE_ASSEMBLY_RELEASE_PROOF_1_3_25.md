# Pure Assembly Release Proof 1.3.25

Wheelchair 1.3.25 preserves the direct native production chain:

```text
WH / WHEX / Field surface
    -> handwritten assembly compiler
    -> AOT native x86-64 image
```

Production build authority does not invoke Python, C, LLVM, JIT, or a bytecode interpreter.

The 1.3.25 release gate additionally proves:

1. `bin/` is the sole production executable location.
2. root-level executable duplicates are absent.
3. production source and build logic contain no path dependency on `devtrash/`.
4. the complete production build succeeds while `devtrash/` is physically absent.
5. rebuilt production binaries match the stored 1.3.24 production SHA-256 set byte-for-byte.
6. inherited semantic and machine-work regression gates pass from their new non-production archive location.
