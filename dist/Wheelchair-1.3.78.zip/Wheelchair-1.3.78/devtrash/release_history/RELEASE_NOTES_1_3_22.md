# Wheelchair 1.3.22 Release Notes

## Predicate ValueFact Persistence / Boolean Sparsification

Wheelchair 1.3.22 strengthens the existing Physical Reality / Physical DAG architecture. It does not add a Boolean backend, predicate runtime, cache, repetition threshold, or workload route.

A materialized immutable boolean expression is now an ordinary ValueFact. If an exactly equivalent predicate is requested again while its input versions are unchanged, the compiler reuses the existing materialized fact and records the reuse as an explicit fragment dependency. Repeated source syntax no longer implies repeated physical comparison.

The canonical regression contains four source occurrences of `x < y`: one named predicate, two inline `select` guards, and a second named predicate. The 1.3.21 image emits four `ucomisd`/`setb` pairs. The 1.3.22 image emits one pair while preserving both true- and false-direction IEEE-754 output bits.

## Historical private routes deleted

This release physically removes two previously discovered shape-specific routes:

- the fixed two-state u64 affine-iterate O(log N) private lowering (`g_try_emit_affine_iterate`, `g_match_affine_update`, `gc_affine_*`);
- the fixed `INTERIOR_PROVEN` boundary-select matcher that recognized only `eq(axis,0) -> axis-1` and `eq(axis+1,n) -> axis+1` shapes (`vec_select_interior_false`, `expr_is_axis_delta1`).

Generic counted recurrence semantics, generic select lowering, ordinary affine proofs, Rank-N register-DAG execution, and the existing Physical Reality remain authoritative. If affine-recurrence compression is recovered in a future release, it must enter through a general algebraic proof rather than a fixed state-count route.

## Inherited architecture

1.3.22 preserves the 1.3.12 causal-state collapse, 1.3.13 register-native transition path, 1.3.14 unified Physical Reality, 1.3.15 Rank-N causal physicalization, 1.3.16 whole-episode Physical DAG, 1.3.17 external silicon authority, 1.3.18 emergent expansion, 1.3.19 structural execution, 1.3.20 unified ValueFact pressure remap, and 1.3.21 transport sparsification.

No Python release source, C/LLVM/JIT backend, runtime predicate manager, runtime register allocator, global ready queue, work stealing, or workload-specific Boolean route is introduced.
