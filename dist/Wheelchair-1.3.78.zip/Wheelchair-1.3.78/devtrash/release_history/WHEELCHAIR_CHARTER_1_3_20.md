# Wheelchair Charter 1.3.20 — One Physical Reality, Fewer Branches

1. A workload is evidence, never an implementation identity.
2. No state count, solver name, simulation family, or variable name may select a private execution backend.
3. Simultaneous next-version storage is a physical realization candidate, not a semantic register ownership rule.
4. State ValueFacts, shared ValueFacts, constants, anonymous temporaries, and next-version ValueFacts compete under the same AOT physical authority.
5. If one realization blocks already-proved reusable work through physical carrier exhaustion, the same DAG may be re-mapped using existing storage/hand-off mechanisms. This is not a fallback backend.
6. Historical special transition emitters are deleted. ISA-specific compression is allowed only as generic machine-sequence canonicalization after the semantic DAG has already been formed.
7. No runtime register allocator, ValueFact manager, CSE cache, workload selector, or state-count selector may be introduced.
8. Technical peaks must be recovered through the common path where possible rather than preserved by resurrecting private source-level branches.
