# Wheelchair 1.3.20 — Unified ValueFact Pressure Remap

## Scope

This release strengthens the existing Physical Reality / whole-episode register-DAG path. It does not add a chemistry backend, reaction-network matcher, state-count backend, runtime register allocator, runtime ValueFact manager, or solver-name specialization.

The `chem6` workload is used only as a pressure probe because 1.3.19 exposed a carrier-pressure cliff there. The accepted repair is workload-agnostic: when an already-profitable shared FP ValueFact cannot be assigned a physical carrier during AOT realization, the same Physical DAG is remapped once with next-version state values treated as transient ValueFacts using the existing state handoff path.

The historical source-level 2-state `xadd` and 3-state shift/add private transition branches are deleted. The old two-state ISA peak is retained only through generic post-emission machine-sequence canonicalization.

## Machine-work audit

Hot-loop counts were taken from disassembly of the same `.wh` workloads under the 1.3.19 baseline and the 1.3.20 candidate.

| Probe | 1.3.19 hot instructions | 1.3.20 hot instructions | 1.3.19 `vmulsd` | 1.3.20 `vmulsd` |
|---|---:|---:|---:|---:|
| `chem6` | 114 | 89 | 25 | 15 |
| `mass3` | 85 | 85 | 18 | 18 |
| `rigid7` | 175 | 175 | 41 | 41 |
| `rigid7_cseprobe` | 151 | 151 | 38 | 38 |

For `chem6`, 1.3.20 removes ten repeated scalar multiplies per timestep without a named chemistry rule. The unrelated simulation probes keep their established arithmetic machine work exactly.

The `chem6` literal-materialization count is also lower but remains a visible frontier: the measured hot loop moved from approximately 20 `movabs` literal constructions in 1.3.19 to approximately 17 in 1.3.20. Therefore the remaining gap to mature C/Fortran code generation is not claimed solved by this release.

## 20,000,000-step `chem6` strict rematch

Representative pinned-host median timings from the release development run:

| Implementation | Median | Minimum | Maximum |
|---|---:|---:|---:|
| Wheelchair 1.3.20 | 179.613 ms | 175.531 ms | 188.416 ms |
| C | 116.344 ms | 113.260 ms | 124.092 ms |
| Fortran | 122.840 ms | 113.829 ms | 126.844 ms |

C flags:

```text
-O3 -march=native -mtune=native -fno-fast-math -ffp-contract=off
```

Fortran used the same optimization/FP intent plus `-fprotect-parens`.

All three produced the same final IEEE-754 payload:

```text
0x3fc1fd3b23361dd4
```

This release therefore claims a general machine-work repair, not victory over C or Fortran. On this probe, Wheelchair remains roughly 1.54x slower than the measured C median. The remaining frontier is dominated by literal/constant realization and mature scalar register/code scheduling rather than by the ten repeated reaction-rate multiplications removed here.

## Causal-state technical peak preservation

The deleted source-level two-state transition matcher is not required to preserve the old ISA result. Fibonacci/Lucas generated through the unified register-DAG are post-emission canonicalized from the exact generic move/add/move sequence to the equivalent `xadd r9,r8` machine primitive. No state count or workload name selects that canonicalization.

Representative 50,000,000-step development timings remained in the same range as 1.3.19 (about 15–17 ms for Fibonacci/Lucas on this host), while Tribonacci remained about 30 ms. These figures are host observations, not cross-machine guarantees.

## Release boundary

1.3.20 claims:

- removal of the historical 2-state and 3-state private transition-shape emitters;
- one unified AOT shared-carrier-pressure remap on the existing Physical Reality;
- `chem6` hot-loop multiplication reduction from 25 to 15 with exact output preservation;
- no arithmetic-machine-work increase in `mass3`, `rigid7`, or `rigid7_cseprobe`;
- generic ISA canonicalization preserving the historical `xadd` technical peak;
- no runtime register allocator or runtime ValueFact manager.

It does **not** claim that all constant-materialization pressure is solved, that the full AVX-512 XMM16–31 carrier domain is exploited by the general frontend, or that every inherited historical test script is a valid 1.3.20 release authority. Some older scripts are already stale/environment-sensitive on the untouched 1.3.19 baseline; 1.3.20 does not rewrite semantic history merely to make those old gates green.
