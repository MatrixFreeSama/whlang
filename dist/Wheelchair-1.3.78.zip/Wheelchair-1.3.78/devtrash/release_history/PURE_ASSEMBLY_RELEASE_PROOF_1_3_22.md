# Wheelchair 1.3.22 Pure Assembly Release Proof

Wheelchair 1.3.22 remains a static AOT native compiler whose production compiler/runtime authority is assembly. The production build invokes no Python source generator and no C/LLVM/JIT backend.

## New proof gates

- `PREDICATE_REPEAT_4_TO_1=PASS`
- `PREDICATE_SEMANTICS_BOTH_DIRECTIONS=PASS`
- `PREDICATE_REUSE_CAUSAL_DEPENDENCY=PASS`
- `PREDICATE_REPEAT_MAGIC_THRESHOLD=0`
- `RUNTIME_PREDICATE_MANAGER=0`
- `FIXED_BOUNDARY_SELECT_MATCHER=0`
- `FIXED_STATE_AFFINE_ITERATE_ROUTE=0`

The canonical predicate probe compiles four identical source predicates to one physical compare/set operation. Both truth directions retain exact output bits.

Source scans require the former fixed-state affine lowering and fixed boundary-select matcher symbols to be absent, not merely disabled.

All inherited 1.3.1x/1.3.2x structural, tensor, field, state, transport and static-native release gates remain required.
