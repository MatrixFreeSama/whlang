# Wheelchair 1.3.19 Charter — Structural Execution Theory Consolidation

## 1. Structural execution

Wheelchair executes a causal partial order, not source-line order. Work at equivalent causal depth is independently executable by construction. Serialization is not a default execution mode; it exists only where a real mathematical dependency increases causal depth.

> **Equivalent causal depth is spontaneously parallel; serialization exists only as increased causal depth.**

Program order alone is not causal authority. A source-order edge may survive physicalization only when semantics, effects, trapping behavior, aliasing, strict floating-point order, or another proven dependency requires it.

## 2. Structural performance variables

Every performance diagnosis is reduced first to three physical quantities:

- `W` — total necessary Physical Work in the target Physical Reality cost domain;
- `S` — weighted Causal Span, the longest necessary causal path;
- `H` — weighted Physical Realization Overhead on the execution-critical path.

The structural execution speedup model is

\[
\boxed{\mathcal S_{struct}(P)=\frac{W}{\max(W/P,S)+H}}
\]

or, with `c=S/W` and `h=H/W`,

\[
\boxed{\mathcal S_{struct}(P)=\frac{1}{\max(1/P,c)+h}}
\]

The zero-overhead ideal becomes

\[
\boxed{\mathcal S^{ideal}_{struct}(P)=\min(P,W/S)}.
\]

`W/S` is **Intrinsic Causal Parallelism**: the amount of parallel silicon a mathematical structure can use on average before its causal span becomes the dominant limit.

This is a performance model, not a claim that Amdahl's Law is false. Amdahl describes a serial/parallel partition. Structural Execution uses work/span because Wheelchair does not grant source order independent execution authority.

## 3. Three physical regions

### Causal-limited

`S` approaches `W`. Additional silicon cannot erase a true dependency chain. Sequential local realization is then a correct physical consequence of mathematics, not a failed parallelizer.

### Realization-limited

`W/S` is large, but `H` is not negligible relative to useful work. Mathematical independence exists, yet materializing every independent fragment would waste silicon on lifecycle work. 1.3.18 Emergent Outward Expansion is the canonical repair: independence permits outward execution but does not require it.

### Structure-dominated

`S << W` and `H << W/P`. Execution approaches `W/P`, so scaling approaches the available physical parallelism. The FSI strong/weak-scaling probes are current evidence of this region.

## 4. W/S/H optimization law

Every new optimization must identify which physical quantity it reduces:

- repeated arithmetic, loads, moves, address work, duplicate realization: `ΔW < 0`;
- false dependency, artificial order, unnecessary barrier: `ΔS < 0`;
- credit management, clone storms, scheduler bookkeeping, avoidable joins/lifecycle: `ΔH < 0`.

An optimization that cannot state which of `W`, `S`, or `H` it reduces is presumed to be architecture growth without proven physical value.

## 5. AOT-only structural facts

1.3.19 does not add a runtime causal-depth scheduler, level queue, serial-fraction manager, worker graph, or resource manager. Existing Physical Reality facts are exposed to an offline structural diagnostic. Tensor/Field binaries already contain immutable per-chunk work price and outward-materialization price; the diagnostic combines those AOT facts with the canonical reduction tree to report parameterized `W`, `S`, `H`, and `W/S` for a concrete runtime extent.

Dynamic extents mean absolute `W` and `S` are not always compile-time constants. The compiler therefore exports stable physical coefficients, while the diagnostic evaluates the structural model for a supplied extent without changing generated machine code.

## 6. Hot-path non-intrusion

Structural Execution Theory is descriptive authority over the existing Physical DAG, not a new runtime mechanism. 1.3.19 intentionally preserves the 1.3.18 production compiler/runtime machine images unless a correctness repair is required. Theory must not create runtime work merely to observe itself.

## 7. Research rule

For every new simulation or HPC probe, diagnose in this order:

1. Is `W` too large?
2. Is `S` deeper than mathematics requires?
3. Is `H` too expensive?
4. If all three are near their physical lower bounds, the remaining limit belongs to the problem or hardware rather than a hidden scheduler.

The preferred research output is therefore not merely “parallel percentage,” but the tuple `(W, S, W/S, H)` plus measured scaling.
