# Pure Assembly Release Proof 1.3.42

Production compiler/runtime authority remains handwritten x86-64 assembly and shell build logic. 1.3.42 adds no C/C++ production source, root runtime, root scheduler, JIT, libm/BLAS dependency, real/complex root selector, or fallback solver.

RootRelation, componentwise structured differentiation, sparse zero-derivative protection and complex-semantic checkpointing are implemented in `compiler/surface_lowerer_x86_64.S` as compile-time AST/Structured-Fact/ValueFact construction over existing physical authorities.
