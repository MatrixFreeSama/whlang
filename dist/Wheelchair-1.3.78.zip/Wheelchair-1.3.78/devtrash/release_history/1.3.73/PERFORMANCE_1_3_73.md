# Wheelchair 1.3.73 Performance Note

Diagnostic: the same 256^3 periodic seven-point weighted f32 Field reduction used while diagnosing 1.3.71/1.3.72, pinned to CPUs 0-3 on the Xeon Platinum 8370C host.

1.3.73 is primarily an architecture-lifetime change. Interleaved whole-process measurements against 1.3.72 were within host scheduling/noise at roughly the one-percent level; all runs produced identical checksum bits `0x4b27b8fe`. No universal speedup is claimed from this change alone.

The relevant machine-code change is structural: once a direct Region is entered, its backedge returns directly to the direct-load kernel head and does not traverse a packet-global layout selector. Uniform-layout and NT policy are likewise captured as invocation-static mode bits rather than generated-code RIP-relative global-policy reads.

This release intentionally does not claim that the remaining Poisson gap is solved. Actual field loads, address carriers, arithmetic/reduction dependency depth, memory behavior and process/file costs remain separate issues.
