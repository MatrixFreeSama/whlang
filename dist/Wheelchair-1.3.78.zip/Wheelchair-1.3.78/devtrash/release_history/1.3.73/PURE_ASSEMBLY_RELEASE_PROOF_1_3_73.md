# Wheelchair 1.3.73 Pure-Assembly Release Proof

The production compiler/runtime remains an AOT x86-64 assembly chain. No C, LLVM, JIT, Python generator, bytecode interpreter, runtime recurrence engine or new staticization backend is added.

1.3.73 changes the generated Field machine function and the existing assembly runtime only. Cold-proved invocation policy is packed into `EDX`, captured in `R15D`, and consumed as machine control state. The direct Region loop emits a machine backedge to its own direct-load head; global policy bytes are not reloaded by that packet loop.

`build.sh` continues to require the historical single-authority gates and now additionally rejects the old packet-global policy offsets and compatibility names.
