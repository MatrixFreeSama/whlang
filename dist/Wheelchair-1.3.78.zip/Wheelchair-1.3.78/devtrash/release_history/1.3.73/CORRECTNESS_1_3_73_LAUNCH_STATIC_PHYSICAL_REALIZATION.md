# Wheelchair 1.3.73 Correctness: Launch-static Physical Realization

The correctness boundary is zero semantic flip. 1.3.73 does not assume that runtime Field files are compile-time constants. It only changes the lifetime of facts after launch validation has proved them immutable for the invocation.

The release gate verifies:

- native512 and native256 periodic-boundary oracles remain bit-identical;
- arbitrary extents, tails, gathers, inout/noalias and generic Field paths remain valid through the older broad Field suites;
- a direct Region backedges directly to the direct kernel head instead of returning through a packet-level global layout selector;
- generated code no longer has `FIELD_RUNTIME_REGULAR_CONTIG_VA`, `FIELD_RUNTIME_UNIFORM_LAYOUT_VA` or `FIELD_RUNTIME_NT_ACTIVE_VA` authorities;
- the deleted `g_input_regular_contig` name has no compatibility alias;
- no Poisson/stencil matcher or fixed staticization threshold exists.

A boundary is still allowed to rematerialize mask/coordinate/topology facts, because the physical relation actually changed there. An irregular invocation remains generic. Staticization therefore removes repeated questions, not truthful variability.
