# Wheelchair 1.3.73 Architecture Aging

## Launch-static physical realization

1.3.73 removes a surviving form of dynamic physical interpretation from the Field path. In 1.3.72, layout, uniformity and non-temporal policy had already been proved before the generated kernel ran, but generated packet code could still reload those global facts and branch on them again. That duplicated an authority which had already finished its job.

The current path packs the cold-proved invocation facts once into the generated-kernel call state:

- bit 0: direct contiguous layout is available;
- bit 1: immutable input layout is uniform;
- bit 2: non-temporal output policy is active.

The generated function captures the mode in one preserved machine register. A direct Region then loops directly on its exclusive Region end. No packet inside that Region reloads global layout policy or asks again whether the invocation is direct. Only a true Region boundary re-enters `field_regular_run_end`; an invocation whose launch proof rejects direct layout enters the generic loop once and remains generic.

This is staticization of proved facts, not falsification of runtime data. External WHFLD extents and layouts are runtime inputs and remain so. Once launch-time validation turns them into an immutable physical fact, however, that fact is no longer allowed to reappear as a packet-level question.

## Aging / fusion rules

The implementation grows into the existing Field code generator and Physical Reality authority. It does not add a staticization optimizer, second kernel IR, JIT, runtime policy manager, workload matcher, or fixed Region span. The old generated-code RIP-relative authorities for regular-layout, uniform-layout and NT-policy bytes are deleted rather than retained as compatibility paths.

The direct and generic identities now exist as control regions inside the same generated machine function:

```text
cold validation
    -> launch-static mode
    -> generated invocation
       -> direct-layout Region transition loop
          -> direct kernel backedge while q < run_end
          -> boundary rematerialization only at a real boundary
       -> OR generic loop for an invocation that never proved direct layout
```

The architecture continues the same aging law used by 1.3.71 and 1.3.72: once a higher-level fact has produced its physical consequence, the higher-level authority retires.
