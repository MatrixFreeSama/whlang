# Wheelchair 1.3.73 Release Notes

## Main change

Field physical realization is now launch-static after proof. Layout, uniform-input and NT-output facts are packed once before the generated function executes. The hot direct Region does not reload them per packet.

## Removed

- generated packet-level regular-layout global reload;
- generated packet-level uniform-layout global reload;
- generated packet-level NT-policy global reload;
- obsolete `FIELD_RUNTIME_REGULAR_CONTIG_VA`, `FIELD_RUNTIME_UNIFORM_LAYOUT_VA`, and `FIELD_RUNTIME_NT_ACTIVE_VA` generated-code authorities;
- obsolete `g_input_regular_contig` name;
- dead `ff_emit_movzx_eax_runtime_byte` emitter helper;
- old regular-layout compatibility branch in generated code.

## Preserved

- truthful runtime Field geometry;
- Region-boundary topology rematerialization;
- generic gather/layout fallback;
- strict/tolerant contracts;
- native512/native256 semantics;
- ownership-local execution from 1.3.72;
- all previous semantic/execution convergence paths.

No workload-specific matcher, fixed extent/rank threshold, second IR, runtime staticization manager or JIT is introduced.
