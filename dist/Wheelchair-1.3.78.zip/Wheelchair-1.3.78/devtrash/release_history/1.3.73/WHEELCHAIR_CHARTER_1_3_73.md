# Wheelchair Charter 1.3.73

## Static fact extinction law

A fact which is provable before a hot physical action may guide materialization, but after its physical consequence has been selected it must not become a runtime question again unless the underlying input fact truly changes.

For external Field data this creates three lifetimes:

1. runtime input truth may be unknown before launch;
2. cold validation proves an invocation-static physical fact;
3. the hot kernel consumes only the frozen consequence.

The compiler must not pretend stage 1 is static, and must not drag stage 2 into stage 3 as repeated policy checks.

## Red lines

- no algorithm/workload-name matcher;
- no second staticization IR/backend;
- no JIT or runtime code regeneration;
- no fixed extent/rank/Region threshold used as an admission rule;
- no compatibility route retaining a retired packet-global authority;
- strict floating-point semantics remain strict unless the source contract permits otherwise.
