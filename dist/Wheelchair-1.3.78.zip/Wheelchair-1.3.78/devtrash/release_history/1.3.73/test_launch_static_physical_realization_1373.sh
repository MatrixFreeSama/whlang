#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

./build.sh >/dev/null
echo 'LAUNCH_STATIC_BUILD=PASS'

# Static architecture evidence: launch facts are packed outside generated code.
grep -q 'cg_test_r15_direct:' compiler/field_frontend_common_x86_64.S
grep -q 'cg_test_r15_uniform:' compiler/field_frontend_common_x86_64.S
grep -q 'cg_test_r15_nt:' compiler/field_frontend_common_x86_64.S
! grep -RqsE 'FIELD_RUNTIME_(REGULAR_CONTIG|UNIFORM_LAYOUT|NT_ACTIVE)_VA|ff_regular_layout_fallback_disp_ptr|g_input_regular_contig' compiler runtime tools
for f in runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  grep -q '^g_launch_direct_layout:' "$f"
  grep -q 'movzx eax,byte ptr \[rip+g_launch_direct_layout\]' "$f"
  grep -q 'movzx eax,byte ptr \[rip+g_input_uniform_layout\]' "$f"
  grep -q 'movzx eax,byte ptr \[rip+g_nt_active\]' "$f"
done
echo 'LAUNCH_FACTS_PACKED_ONCE=PASS'
echo 'PACKET_GLOBAL_POLICY_RELOAD=0'

# Direct-region inner loop must backedge directly to the direct kernel head.
grep -q 'ff_direct_backedge_disp_ptr' compiler/field_frontend_common_x86_64.S
grep -q 'ff_direct_loop_ptr' compiler/field_frontend_common_x86_64.S
grep -q 'ff_regular_loop_ptr' compiler/field_frontend_common_x86_64.S
grep -q 'ff_generic_loop_ptr' compiler/field_frontend_common_x86_64.S
echo 'DIRECT_REGION_STATIC_BACKEDGE=PASS'

# Boundary truth remains authoritative on both physical widths.
for C in fieldc fieldc-native256; do
  build/$C devtrash/tests/field_1217/pow2_neighbor.json -o "$T/$C-neighbor" >/dev/null
  out=$("$T/$C-neighbor" devtrash/tests/field_1217/pow2_4x4x4.whfld)
  [ "$out" = 'checksum_f32_bits=0x45020000' ]
done
echo 'BOUNDARY_ZERO_FLIP=PASS'

# Broad pre-existing Field semantics remain the authority.
bash devtrash/release_tests/test_field_native_1216.sh >/dev/null
bash devtrash/release_tests/test_physical_regularity_134.sh >/dev/null
echo 'GENERAL_FIELD_FALLBACK=PASS'
echo 'ARBITRARY_EXTENT_FIDELITY=PASS'

! grep -RqsE '(^|[^A-Za-z])(poisson|stencil)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'launch_static.*(threshold|limit)[[:space:]]*=[[:space:]]*[1-9]' compiler runtime surface tools
echo 'WORKLOAD_MATCHER=0'
echo 'FIXED_STATICIZATION_THRESHOLD=0'
echo 'SECOND_STATICIZATION_IR=0'
echo 'WHEELCHAIR_LAUNCH_STATIC_PHYSICAL_REALIZATION_1_3_73=PASS'
