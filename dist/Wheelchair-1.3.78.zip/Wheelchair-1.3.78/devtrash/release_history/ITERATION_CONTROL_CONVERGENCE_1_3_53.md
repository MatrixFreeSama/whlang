# Wheelchair 1.3.53: Optional-Iteration Convergence

## Rule

Iteration/refinement depth is policy, not mathematical identity. Existing advanced mathematical relations therefore follow one source contract:

```text
semantic(required arguments [, static_iterations])
```

If the final count is omitted, the historical release value is used as a fallback. If it is written, that AOT-static `u64` controls the existing compile-time expansion. The value does not survive as a runtime solver object, runtime algorithm selector, scheduler input, tolerance switch, or precision-specific implementation.

`root(x, expression, guess [, iterations])` remains the reference contract. 1.3.53 extends the same ownership rule to the already-existing iterative advanced semantics rather than creating named custom variants.

## Shared authority

The Semantic Registry marks ordinary mathematical builtins that accept an optional final iteration fact with `MSF_OPTIONAL_ITER`. A single parser path admits either the required arity or required arity plus one. `s_math_iteration_count` validates an explicitly supplied count as AOT-static and otherwise returns the historical fallback constant.

The centralized fallbacks are:

| Relation | Omitted value |
| --- | ---: |
| `root` / `newton` | 5 Newton generations |
| `integral` / `quad` | 1 GL8 panel |
| `lambertw` | 3 Halley refinements |
| `erfinv` | 2 Newton refinements |
| `digamma` | recurrence shift 8 |
| `trigamma` | recurrence shift 8 |
| `zeta` | Euler-Maclaurin cutoff 16 |
| `polylog` | 24 Horner-series terms |
| `elliptic_k`, `elliptic_e` | 6 AGM refinements |
| `matrix_exp` | 12 Taylor terms |
| `matrix_log` | 9 odd-series refinements after the seed |
| `matrix_sqrt` | 6 Newton refinements |
| `eig_values`, `eig_vectors` | 20 power iterations |
| `svd_values`, `svd_u`, `svd_v` | 20 spectral power iterations |

These values preserve old source behavior; they no longer define the maximum representable depth.

## Integral

The historical integral relation is an 8-point Gauss-Legendre panel. Eight is the quadrature formula order, not an iteration budget, so 1.3.53 does not reinterpret the optional count as a different Gauss-Legendre order.

```text
integral(x, a, b, expression)          # one historical GL8 panel
integral(x, a, b, expression, panels)  # same GL8 relation on `panels` equal subintervals
```

No second integrator is selected. The composite form is AOT-unrolled through the same scalar ValueFact authority.

## What is deliberately not parameterized

Finite algebraic loops whose depth is structurally determined by the input are not iteration budgets. LU, LDLT, Cholesky, matrix multiplication and similar dimension-driven loops therefore do not receive an arbitrary iteration argument.

Coefficient-table length and formula order are likewise not silently redefined as iteration counts. Lanczos coefficients, Bernoulli correction identities and the GL8 node/weight formula remain part of their existing mathematical recipes.

## No algorithm zoo

1.3.53 does not add `root_fp256`, `matrix_exp_custom`, `eig_fast`, `integral_custom`, or analogous paths. An explicit count changes only the depth of the relation already owned by the old architecture.
