# Wheelchair 1.3.26 — Field ValueFact Phase-Lifetime Completion

1.3.26 strengthens the existing Field `LoadFact -> AddressFact -> Physical Reality` architecture after real sparse simulation kernels exposed avoidable value transport.

## Deleted rules

The release physically removes two old optimization-eligibility rules rather than keeping them as compatibility branches:

- immutable Field loads no longer require `use_count > 1` before they may occupy a resident SIMD carrier;
- the presence of integer-index operations no longer disables AVX-512 load residency globally.

No replacement stencil/workload branch exists.

## Old architecture strengthened

Physical carrier ownership is now phase-lifetime based. Address/load helpers own scratch registers only while the helper phase is alive. Once that causal phase finishes, those registers return to the ordinary Physical Reality and may hold immutable LoadFacts during arithmetic.

For AVX-512 the post-helper arithmetic phase can use ZMM0 and ZMM6..31 as immutable resident carriers. ZMM1..4 remain ordinary value carriers and ZMM5 remains the reduction carrier. For AVX2, YMM6..15 become resident-capable after helper completion; YMM0 remains the established reduction/helper transfer carrier.

When later arithmetic contains a helper, mutable load, or store that can clobber residents, the compiler retains a stack reload authority. Pure arithmetic neighborhoods do not create that redundant stack transport.

## No workload route

The production compiler contains no miniFE, miniAMR, CloverLeaf, 7-point, 21-point, or 27-point dispatch. The same carrier/lifetime facts apply to any Field graph.

## Validation

The complete inherited release suite remains authoritative. 1.3.26 adds a dedicated phase-lifetime gate that verifies full-bank encoding, single-use residency, irregular-layout preservation, Rank-N/helper correctness, and absence of workload-shaped routes.
