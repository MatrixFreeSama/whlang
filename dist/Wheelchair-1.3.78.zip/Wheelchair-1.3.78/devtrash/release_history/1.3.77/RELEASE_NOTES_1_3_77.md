# Wheelchair 1.3.77

1.3.77 completes the next burn-level stage: the existing Physical-DAG dependency-depth order is now the final ISA time axis for legal Group episodes. Packet independence no longer ends at separate carrier banks; arithmetic itself is emitted depth-major across the simultaneously live packet MachineFacts.

Later immutable LoadFacts keep their AddressFact identity until true consumption. When a tolerant terminal operator can encode the address directly, the load becomes the x86 memory operand and no synthetic shadow load carrier is created. Group width therefore follows real live logical-value pressure and causal depth rather than cache-count pressure, a fixed unroll width, or a candidate table.

Strict reduction order remains authoritative and does not receive illegal cross-packet regrouping. Generic, boundary, mixed-layout, and native256 paths retain their established results.

The old packet-major machine-body authority, shadow load-carrier assumption, and early-load materialization assumption are not retained as compatibility paths.
