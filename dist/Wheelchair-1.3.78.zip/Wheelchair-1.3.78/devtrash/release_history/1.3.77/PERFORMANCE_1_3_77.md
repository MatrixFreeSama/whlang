# Performance 1.3.77

The primary release evidence is structural: the final ISA time axis now follows the existing Physical-DAG depth order, and immutable later-packet LoadFacts may remain AddressFacts all the way into arithmetic memory operands. On the current AVX-512 representative pressure case this naturally yields five simultaneously live packet q-chains (80 f32 values per Group) without a source-level or compiler-private width of five.

A single-worker whole-process diagnostic on the current shared Intel Xeon Platinum 8573C compared the released 1.3.76 compiler with the final 1.3.77 tree on the same 256^3 zero-field tolerant workload, compiled and executed under the same CPU affinity. Across 61 alternating pairs:

- 1.3.76 median: 27.358 ms (Q1 23.520 ms, Q3 43.893 ms)
- 1.3.77 median: 26.160 ms (Q1 22.873 ms, Q3 39.759 ms)
- independent-median difference: about 4.38% faster for 1.3.77
- paired median difference: about 2.05% faster for 1.3.77

The environment shows substantial scheduling noise and wide interquartile ranges. Therefore 1.3.77 does **not** claim a stable general speedup multiplier. The hard result is that proved causal independence, carrier lifetime, and AddressFact identity now survive into the actual ISA ordering instead of being repackaged into packet-major sequential machine code.
