# Correctness 1.3.77 — Physical-DAG to ISA Schedule Burn

Release gates verify all of the following on the representative Field pressure case:

- tolerant and strict numerical checksums remain unchanged for native512;
- native256 retains its established checksum;
- the current AVX-512 target naturally exposes five simultaneous packet MachineFacts from live carrier pressure, visible as +0x40/+0x80/+0xc0/+0x100 packet displacements and one 80-value Group advance;
- all center-depth operations are emitted before the first neighbor depth, then each neighbor depth is emitted horizontally across the live packet identities;
- later immutable LoadFacts are consumed directly as arithmetic memory operands rather than resurrecting a shadow load-carrier bank;
- strict reduction does not receive cross-packet regrouping;
- padded/strided mixed-layout native512 and native256 results remain byte-for-byte identical to their expected output.

The implementation contains no workload-name matcher, post-codegen scheduler, second machine scheduling IR, fixed unroll width, Group-width candidate table, runtime issue selector, packet-body byte clone, or packet-major compatibility backend.
