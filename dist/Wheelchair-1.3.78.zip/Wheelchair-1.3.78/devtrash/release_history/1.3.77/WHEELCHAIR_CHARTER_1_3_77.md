# Wheelchair Charter 1.3.77

A proved Physical-DAG relation must remain authoritative through the final instruction time axis. The compiler must not first collapse proved same-depth work into ordinary sequential packet code and then ask a second optimizer to rediscover the lost independence.

A MachineFact should exist only for its true physical lifetime. If an immutable LoadFact is already represented completely by an AddressFact and its terminal consumer can encode that address, no synthetic SIMD carrier may be created merely to satisfy a generic emitter shape.

Group width is a consequence of real causal depth and live architectural carriers. It is never a workload name, fixed number, candidate table, runtime issue decision, or compatibility backend. Strict semantic dependencies remain dependencies; truthful degradation replaces special-case repair.
