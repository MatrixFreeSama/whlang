# devtrash

`devtrash/` is Wheelchair's non-production development archive.

It contains useful material that is **not required to run or build Wheelchair**:

- regression corpora and release tests;
- benchmarks;
- historical source trees;
- frozen-native regression snapshots;
- old release notes, performance evidence, hashes and logs.

The name is deliberate: this is where development archaeology lives so it cannot masquerade as current product structure.

Nothing under this directory has production authority. If an old optimization is useful, extract its general mathematical/physical property and implement that property in the current architecture. Do not copy the old private branch back into production source.
