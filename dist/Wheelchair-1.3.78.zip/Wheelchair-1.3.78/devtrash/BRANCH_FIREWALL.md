# Branch Firewall

The archive is a one-way historical boundary.

Allowed direction:

```text
old observation / benchmark / proof
        -> extract general property
        -> current ValueFact / Physical Reality / Physical DAG
```

Forbidden direction:

```text
devtrash old source
        -> copy/include/link
        -> production fast path
```

Production admission may depend on current semantic and physical facts. It may not depend on workload names, solver names, benchmark names, archived file identity, historical version identity, fixed source-shape templates, or compatibility-only routes.
