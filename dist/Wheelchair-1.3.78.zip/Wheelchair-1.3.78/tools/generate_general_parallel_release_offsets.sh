#!/bin/sh
set -eu
[ "$#" -eq 3 ] || [ "$#" -eq 4 ] || { echo 'usage: generate_general_parallel_release_offsets.sh ELF BIN OUT_JSON [OUT_INC]' >&2; exit 64; }
ELF=$1
BIN=$2
OUT=$3
INC=${4:-}
need='gr_release_base gr_node_count gr_edge_count gr_template_end'
value() {
  name=$1
  v=$(nm -n "$ELF" | awk -v n="$name" '$3==n {print $1; exit}')
  [ -n "$v" ] || { echo "missing blind-release symbol: $name" >&2; exit 1; }
  printf '%d' "$((0x$v))"
}
BASE=$(value gr_release_base)
[ "$BASE" -eq 0 ] || { echo "gr_release_base must link at offset zero, got $BASE" >&2; exit 1; }
END=$(value gr_template_end)
SIZE=$(wc -c < "$BIN" | tr -d ' ')
[ "$SIZE" -eq "$END" ] || { echo "raw template size $SIZE != gr_template_end $END" >&2; exit 1; }
NODE=$(value gr_node_count)
EDGE=$(value gr_edge_count)
cat > "$OUT" <<EOF
{
  "format": "wheelchair.general_parallel_release_offsets/1",
  "graph_capacity": "structural",
  "offsets": {
    "gr_edge_count": $EDGE,
    "gr_node_count": $NODE,
    "gr_release_base": 0,
    "gr_template_end": $END
  },
  "metadata_layout": "indegree[N],first_out[N],entry_offsets[N],edge_v[E],next_edge[E]",
  "template_size": $SIZE
}
EOF

if [ -n "$INC" ]; then
cat > "$INC" <<EOF
.equ GR_NODE_COUNT_OFF, $NODE
.equ GR_EDGE_COUNT_OFF, $EDGE
.equ GR_TEMPLATE_SIZE, $SIZE
EOF
fi
echo 'GENERAL_PARALLEL_RELEASE_OFFSETS=DERIVED_WITHOUT_PYTHON'
