# Wheelchair 1.3.78

Wheelchair is an AOT, matrix-free, Rank-N HPC/general language whose compiler lowers human forms through semantic, physical, and machine convergence directly to native ISA.

1.3.78 ages the WH human shell without adding a new optimizer, diagnostic subtype tree, retry frontend, runtime manager, or execution path. Existing parser repairs and existing convergence proofs now feed one shared user-facing report surface.

Human feedback is deliberately closed: repair is reported before convergence; source locations use `line N:`; every successful automatic convergence exits through `Cheesed successfully.`; a final error dominates any earlier repair state. The fixed character portrait has one stored geometry and is rendered through `!` for repaired input or `×` for an unresolved error rather than duplicating pictures or state-specific templates.

WHEX and canonical expert paths retain their technical output. Runtime, Physical Reality, GroupFact, ISA realization, mathematical semantics, and generated workload executables are unchanged by this release.
