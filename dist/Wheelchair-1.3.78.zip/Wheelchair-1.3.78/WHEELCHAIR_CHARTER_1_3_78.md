# Wheelchair Charter 1.3.78

1. Human spelling may be repaired only where the existing proof admits a unique repair; reporting does not create a second parser.
2. Repair is reported before convergence.
3. Every human-shell source location begins with `line N:`.
4. Automatic convergence has one successful user-facing exit: `Cheesed successfully.`
5. The human shell does not branch by algorithm, proof class, frontend family, or optimization subtype.
6. Final error dominates intermediate repair/convergence presentation.
7. The character portrait has one geometry; state is rendered by cell substitution, not duplicated artwork.
8. Field WH shares the same human reporting authority rather than retaining private message branches.
9. WHEX/canonical paths remain expert-facing and may expose technical compiler terminology.
10. Human-shell work must not alter runtime semantics, Physical Reality, GroupFact, ISA realization, or generated workload code.
