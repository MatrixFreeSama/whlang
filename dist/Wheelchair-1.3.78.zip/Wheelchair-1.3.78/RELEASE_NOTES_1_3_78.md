# Wheelchair 1.3.78

1.3.78 is a human-shell convergence release. It does not introduce a new language semantic, optimizer, backend, scheduler, runtime authority, or compatibility path.

The WH surface now records facts already proved by existing machinery and feeds them into one reporting unit:

- input repair is reported first with `line N:` and `Repaired successfully.`;
- automatic semantic/execution-form convergence has one user-facing successful exit, `Cheesed successfully.`, followed by its source line when known;
- unresolved failure uses the same source-line convention and `Compilation failed.`;
- a final error dominates repair/convergence presentation;
- one stored portrait mask is rendered as `!` for repair or `×` for error, so character geometry is not duplicated;
- Field WH joins the same reporting exit instead of maintaining separate boundary/domain/type/expression message branches;
- WHEX/canonical expert reporting remains on the existing technical path.

No convergence subtype is exposed to the human shell. Fibonacci, aliases, repeated expressions, field forms, and future convergence proofs do not receive private message routes.

Regression checks preserve the existing semantic, field, execution-form, and Physical-DAG -> ISA schedule-burn laws. Selected 1.3.77 versus 1.3.78 workload outputs are byte-identical ELF files, including repaired input, recursive convergence, semantic convergence, and Field WH cases.
