# Wheelchair 1.3.100

1.3.100 removes repeated mixed-radix coordinate reconstruction from the Tensor derived physical path.

## Compiler repair

Static mixed-radix `CoordinateFact`s now persist across vector packets as one carry recurrence. The innermost finite digit advances by the physical packet width, exact wrap produces the carry fact, outer digits consume that carry, and an already-owned direct residue supplies the carry of its unbounded quotient. The compiler therefore stops rebuilding the same `floor(root / stride)` and `% radix` relations from the physical root every packet.

The change extends the existing `CoordinateFact` authority. It adds no workload-name matcher, runtime radix selector, second Tensor IR, JIT path, hot-kernel API, worker pool, or barrier semantics.

## Dense irregular result

Same Dense Permuted All-Pairs 127 workload, `8192 x 127 x 127`, 100% connected:

- Strict 21-round A/B median: 1.3.99 **267.034 ms** -> 1.3.100 **243.331 ms**, **1.097x**.
- Fast 21-round A/B median: 1.3.99 **295.857 ms** -> 1.3.100 **265.949 ms**, **1.112x**.
- Single-core Strict 5-round median: **976.786 ms** -> **799.527 ms**; per-round ratio median **1.132x** on a noisy shared host.

A separate 7-round four-core interleaved control set measured 1.3.100 Strict at **262.938 ms**, C at **252.687 ms**, and Fortran at **247.702 ms**. Host variance is substantial, so the paired A/B series is the release-to-release authority.

Generated Strict hot code shrinks from **5497 B** to **5249 B**. Static generated counts fall `vpmuludq` **84 -> 75** and `vmovdqa64` **172 -> 153**.

## Correctness

Strict sampled outputs at `n = 64, 127, 128, 256, 1024, 8192` are bit-identical to 1.3.99. Current release tests: **27/27 PASS**.
