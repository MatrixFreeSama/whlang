# Pure assembly release proof 1.3.100

The compiler repair lives in `compiler/tensor_derived_frontend_x86_64.S`, the existing handwritten x86-64 Tensor derived frontend.

The generated carry recurrence is emitted directly as native integer vector operations. No C/C++ helper, JIT compiler, bytecode VM, runtime radix selector, external optimizer, or second Tensor IR is introduced.

Release guards require the generic recurrence labels and reject known benchmark/workload names from the production frontend.
