# Architecture aging 1.3.100

The repair is an aging step, not a new optimization family.

Previously, non-power-of-two coordinates were already valid `CoordinateFact`s, but the generated hot loop could reconstruct those facts from the flat physical root each packet. 1.3.100 makes the existing fact persistent: a static mixed-radix chain advances by carry.

The physical relation is now:

`packet root -> persistent finite digit -> exact wrap/carry -> next digit`

rather than repeated:

`packet root -> constant division -> constant modulo -> coordinate`.

An unbounded quotient and its direct residue are no longer treated as independent information. When the residue is already live, its exact wrap fact advances the quotient.

No second coordinate representation is created. Non-chain or unproven mixed facts retain the mature exact decode path under the same authority. There is no workload identity, radix table, runtime policy selector, or scheduling mechanism in the admission rule.
