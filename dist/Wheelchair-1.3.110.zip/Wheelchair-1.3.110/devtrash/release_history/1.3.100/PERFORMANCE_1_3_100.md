# Performance 1.3.100

Benchmark: Dense Permuted All-Pairs 127, `n=8192`, 127 x 127 pair interactions per batch, 100% connectivity, irregular affine permutations, no sparse skipping.

## Release-to-release paired A/B

| Mode | 1.3.99 median | 1.3.100 median | Speedup |
|---|---:|---:|---:|
| Strict, 4 CPU | 267.034 ms | 243.331 ms | 1.097x |
| Fast, 4 CPU | 295.857 ms | 265.949 ms | 1.112x |

Strict single-core 5-round medians: 976.786 ms -> 799.527 ms. Because the host showed large frequency/noise variation, the paired per-round ratio median, 1.132x, is more representative than dividing those two independent medians.

## Same-run language controls

Seven interleaved four-core rounds:

| Variant | Median |
|---|---:|
| Wheelchair 1.3.100 Strict | 262.938 ms |
| C Strict | 252.687 ms |
| Fortran Strict | 247.702 ms |
| Wheelchair 1.3.100 Fast | 244.249 ms |
| C Fast | 189.856 ms |
| Fortran Fast | 223.245 ms |

These controls are not substituted for the paired release-to-release series; shared-host variance is visible in their ranges.

## Generated-machine contraction

Strict generated executable hot RX segment:

- bytes: 5497 -> 5249
- `vpmuludq`: 84 -> 75
- `vpsrlq`: 60 -> 55
- `vpsubq`: 46 -> 43
- `vmovdqa64`: 172 -> 153

The gain comes from deleting repeated coordinate arithmetic. No extra execution is created to obtain it.
