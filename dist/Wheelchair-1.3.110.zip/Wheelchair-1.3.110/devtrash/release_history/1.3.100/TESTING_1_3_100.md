# Testing 1.3.100

Current release authority remains **27 tests**, not 28. The previous current mixed-radix test and closure were evolved in place instead of stacking another compatibility layer.

- 27/27 current release tests PASS.
- New current mixed-radix carry probe compiles and runs arbitrary non-power-of-two radix 127 and verifies exact output at `n=64` and `n=127`.
- Dense Strict sampled `n=64,127,128,256,1024,8192` is bit-identical to 1.3.99.
- Existing power-of-two/non-power-of-two General modulo authority remains tested.
- Existing CoordinateFact aging and Physical DAG tests remain PASS.

See `RELEASE_TEST_LOG_1_3_100.txt` and `PRODUCTION_BIN_SHA256_1_3_100.txt`.
