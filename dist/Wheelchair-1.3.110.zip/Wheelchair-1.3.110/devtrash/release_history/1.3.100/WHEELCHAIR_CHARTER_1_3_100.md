# Wheelchair charter 1.3.100

Wheelchair remains a whole-program static AOT language. Parallel or serial realization follows causal structure and Physical Reality; 1.3.100 does not introduce a DSL kernel boundary.

The compiler should prefer one older, reusable mathematical/physical relation over parallel special cases. When two live facts encode the same information, reuse the fact and delete reconstruction. Compatibility branches and workload-name routes are not architectural authorities.
