# Release surface convergence 1.3.100

The public release surface remains one Wheelchair distribution with the existing compiler/runtime/surface/tools hierarchy.

1.3.100 does not add a user-visible pragma, tuning parameter, radix mode, parallel construct, or benchmark-specific switch. The optimization is inferred from existing static coordinate facts.

The current release-test set remains 27 entries by aging the previous mixed-radix current test and current closure in place.
