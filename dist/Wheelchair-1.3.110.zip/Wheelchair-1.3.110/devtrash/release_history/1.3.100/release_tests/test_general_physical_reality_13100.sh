#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.100" ]
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality.inc
T=${TMPDIR:-/tmp}/wheelchair13100_general_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

# 1.3.96 scalar FP register geometry remains the compiler-wide authority.
grep -q '^\.include "compiler/isa_capabilities.inc"$' "$G"
grep -q '^g_phys_fp_geometry_refresh:' "$G"
grep -q 'ISA_CAP_WIDE_REGFILE' "$G"
grep -q '^g_emit_phys_evex_scalar3:' "$G"
! grep -q 'G_PHYS_FP_CARRIER_COUNT' "$G"
! grep -q 'G_PHYS_FP_TEMP_MASK_INIT' "$G"
! grep -q 'G_PHYS_FP_CONST_MAX' "$G"
grep -q 'g_phys_const_candidate_bits:.skip G_PHYS_CSE_MAX\*8' "$G"
grep -q 'g_phys_cse_resident_expr:.skip G_PHYS_CSE_MAX\*8' "$G"
grep -q 'g_phys_const_resident_bits:.skip G_PHYS_CSE_MAX\*8' "$G"

# 1.3.97 FP generation authority remains whole-generation or disjoint.
grep -q '^.equ PR_FP_GENERATION_FIXED_POINT_AUTHORITY,1$' "$P"
grep -q '^.equ PR_FP_GENERATION_PARTIAL_AUTHORITY_MIX,0$' "$P"
grep -q '^.equ PR_FP_GENERATION_WORKLOAD_MATCHER,0$' "$P"
grep -q '^.equ PR_FP_GENERATION_SECOND_BACKEND,0$' "$P"
grep -q '^g_phys_expr_effectively_uses_state:$' "$G"
grep -q '^g_phys_fp_can_birth_in_old_authority:$' "$G"
grep -q '^g_phys_prove_inplace_fp_epoch:$' "$G"
! grep -Eq 'mass3|chem6|rigid7' "$G"

# 1.3.98 absorbs every nonzero compile-time u64 modulo ConstantFact into one
# reciprocal physical relation. Powers of two own no compatibility path.
grep -q '^.equ PR_GENERAL_CONST_MOD_RECIPROCAL_AUTHORITY,1$' "$P"
grep -q '^.equ PR_GENERAL_CONST_MOD_POWER_OF_TWO_BRANCH,0$' "$P"
grep -q '^.equ PR_GENERAL_CONST_MOD_WORKLOAD_MATCHER,0$' "$P"
grep -q '^.equ PR_GENERAL_CONST_MOD_RUNTIME_SELECTOR,0$' "$P"
grep -q '^.equ PR_GENERAL_CONST_MOD_SECOND_BACKEND,0$' "$P"
grep -q '^g_emit_phys_u64_const_mod:$' "$G"
grep -q '^g_emit_phys_mul_rax_gpr:$' "$G"
grep -q '^g_emit_phys_gpr_cmp:$' "$G"
grep -q '^g_emit_phys_gpr_cmovae:$' "$G"
grep -q '^\.gpior2: mov eax,1; ret' "$G"
! grep -Eq 'mod_.*(pow2|power2)|pow2_.*mod|mod_.*mask_path' "$G"

# Mature FP reference probes remain bit-exact.
S=devtrash/tests/general_whole_episode_1316
for n in mass3 chem6 rigid7; do
  build/wheelchairc "$S/$n.wh" -o "$T/$n" >/dev/null
  chmod +x "$T/$n"
done
[ "$("$T/mass3" 100000)" = 'out00_bits=0x3fa90c89b2e19b14' ]
[ "$("$T/chem6" 100000)" = 'out00_bits=0x3fad4117d563218b' ]
[ "$("$T/rigid7" 100000)" = 'out00_bits=0x3fd72fe2f4bace4b' ]

# Power-of-two and non-power-of-two divisors use the same native relation.
cat > "$T/mod16.wh" <<'SRC'
program mod16
contract integer_overflow = wrap
input seed: u64
input count: u64
iterate r limit count {
 state x: u64 = seed
 state i: u64 = 0
 while i < count
 update x = (x * x + 17) % 16
 update i = i + 1
 result x
}
output total = r
SRC
cat > "$T/mod1000003.wh" <<'SRC'
program mod1000003
contract integer_overflow = wrap
input seed: u64
input count: u64
iterate r limit count {
 state x: u64 = seed
 state i: u64 = 0
 while i < count
 update x = (x * x + 17) % 1000003
 update i = i + 1
 result x
}
output total = r
SRC
for n in mod16 mod1000003; do
  build/wheelchairc "$T/$n.wh" -o "$T/$n" >/dev/null
  chmod +x "$T/$n"
  off=$(od -An -tu8 -j $((0x4010)) -N8 "$T/$n" | tr -d ' ')
  size=$(od -An -tu8 -j $((0x4018)) -N8 "$T/$n" | tr -d ' ')
  rel=$(od -An -tu8 -j $((0x4020)) -N8 "$T/$n" | tr -d ' ')
  dd if="$T/$n" of="$T/$n.code" bs=1 skip=$((off+rel)) count=$((size-rel)) status=none
  objdump -D -b binary -mi386:x86-64 -Mintel "$T/$n.code" > "$T/$n.dis"
  grep -Eq '[[:space:]]mul[[:space:]]+r(11|12|13|14)' "$T/$n.dis"
  grep -Eq '[[:space:]]cmovae[[:space:]]+' "$T/$n.dis"
done
[ "$("$T/mod16" 123456789 101)" = 'out00_bits=0x000000000000000a' ]
[ "$("$T/mod1000003" 123456789 101)" = 'out00_bits=0x00000000000826cf' ]

# Wide-register General remains live where the host actually exposes it.
if grep -qw avx512f /proc/cpuinfo 2>/dev/null; then
  off=$(od -An -tu8 -j $((0x4010)) -N8 "$T/mass3" | tr -d ' ')
  size=$(od -An -tu8 -j $((0x4018)) -N8 "$T/mass3" | tr -d ' ')
  rel=$(od -An -tu8 -j $((0x4020)) -N8 "$T/mass3" | tr -d ' ')
  dd if="$T/mass3" of="$T/mass3.code" bs=1 skip=$((off+rel)) count=$((size-rel)) status=none
  objdump -D -b binary -mi386:x86-64 -Mintel "$T/mass3.code" > "$T/mass3.dis"
  grep -Eq 'xmm(1[6-9]|2[0-9]|3[01])' "$T/mass3.dis"

  off=$(od -An -tu8 -j $((0x4010)) -N8 "$T/chem6" | tr -d ' ')
  size=$(od -An -tu8 -j $((0x4018)) -N8 "$T/chem6" | tr -d ' ')
  rel=$(od -An -tu8 -j $((0x4020)) -N8 "$T/chem6" | tr -d ' ')
  dd if="$T/chem6" of="$T/chem6.code" bs=1 skip=$((off+rel)) count=$((size-rel)) status=none
  objdump -D -b binary -mi386:x86-64 -Mintel "$T/chem6.code" > "$T/chem6.dis"
  ! grep -Eq 'vmovsd[[:space:]]+xmm(1[6-9]|2[0-9]|3[01]),xmm(1[6-9]|2[0-9]|3[01]),xmm[1-9]' "$T/chem6.dis"
fi

printf '%s\n' \
  'GENERAL_SINGLE_PHYSICAL_REALITY=PASS' \
  'FP_GENERATION_FIXED_POINT_AUTHORITY=PASS' \
  'CONST_MOD_RECIPROCAL_AUTHORITY=PASS' \
  'CONST_MOD_POWER_OF_TWO_BRANCH=0' \
  'CONST_MOD_WORKLOAD_ROUTE=0' \
  'STRICT_GENERAL_REFERENCE_BITS=PASS' \
  'WHEELCHAIR_GENERAL_PHYSICAL_REALITY_1_3_100=PASS'
