#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP=${TMPDIR:-/tmp}/wheelchair_mixed13100_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
SRC="$ROOT/compiler/tensor_derived_frontend_x86_64.S"

grep -q '^vec_mixed_chain_preflight:' "$SRC"
grep -q '^vec_mixed_emit_step_chain:' "$SRC"
grep -q '^vec_mixed_find_direct_residue:' "$SRC"
grep -q '^vec_mixed_emit_step:' "$SRC"
grep -q '^vec_mixed_scaled_refresh:' "$SRC"
! grep -Eq 'dense_irregular_allpairs127|waitslow|mass3|chem6|rigid7' "$SRC"

cat > "$TMP/probe.whex" <<'WH'
program mixed_coordinatefact_probe
strict
input n: u64 range 64..65536
field x[b in n, i in 127]: f64 = -0.375 + cast(f64, (b * 31 + i * 17 + 5) % 2048) / 1024.0
field y[b in n, i in 127]: f64 = 0.25 + cast(f64, (b * 19 + i * 23 + 7) % 1024) / 1536.0
sum checksum[b in n, i in 127, j in 127]: f64 =
    x[b, i] * y[b, (j * 37 + i * 13 + b * 7 + 11) % 127] * (0.75 + cast(f64, (i * 29 + j * 43 + b * 3 + 17) % 257) / 512.0)
  + 0.03125 * x[b, (j * 19 + i * 5 + b * 11 + 23) % 127] * x[b, i]
  - 0.015625 * y[b, j] * y[b, (i * 41 + j * 17 + b * 13 + 31) % 127]
output checksum
WH
"$ROOT/bin/whexc" "$TMP/probe.whex" -o "$TMP/probe" >/dev/null
[ "$("$TMP/probe" 64)" = 'checksum_bits=0x411761c7a7f9297e' ]
[ "$("$TMP/probe" 127)" = 'checksum_bits=0x41272d5ac3e2792c' ]
printf '%s\n' \
  'MIXED_RADIX_CARRY_RECURRENCE_1_3_100=PASS' \
  'RUNTIME_RADIX_SELECTOR_1_3_100=0' \
  'DENSE_MIXED_WORKLOAD_MATCHER=0' \
  'SECOND_TENSOR_IR_1_3_100=0'
