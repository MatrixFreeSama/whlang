# Release Surface Convergence 1.3.103

The root release surface contains only current 1.3.103 authority documents. 1.3.102 release documents are archived under `devtrash/release_history/1.3.102/` rather than duplicated at the root.

Current release tests remain exactly 27. 1.3.103 changes existing General scalar-FP physical realization in place; it adds neither a compatibility test branch nor a second runtime/compiler surface.
