# Wheelchair Charter 1.3.103

Wheelchair remains a whole-progress AOT general-purpose HPC language.

Execution follows mathematical causality and Physical Reality. Parallelism is not a source-level language promise. The runtime does not query idle CPUs, steal work, maintain a persistent worker pool, or insert barriers to manufacture occupancy. Outward execution is permitted only as a physical realization of already-existing causal work, and completed executions return their capacity to the operating system.

Compiler optimization follows the same rule: reuse an already-proven physical lifetime fact before inventing a new mechanism. 1.3.103 therefore removes dead-carrier transport in the existing General path rather than adding an explicit-dynamics or timestep-specific optimizer.

Strict numerical semantics remain stronger authority than execution geometry. Tolerance may use its explicit numerical freedom; execution cardinality itself may never redefine Strict arithmetic.
