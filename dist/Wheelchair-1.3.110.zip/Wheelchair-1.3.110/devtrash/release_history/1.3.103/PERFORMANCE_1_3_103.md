# Performance 1.3.103

The diagnostic is two independent explicit-dynamics regions with identical four-DOF recurrence shape and a 10:1 timestep ratio. The stiff region runs 200,000,000 steps while the soft region runs 20,000,000; both are pinned to the same two-CPU invocation. C and Fortran use GCC/GFortran `-O3 -march=native -fopenmp -fno-fast-math -ffp-contract=off` with passive OpenMP waiting.

The 1.3.103 lifetime placement removes four pure FP carrier transports per timestep from the hot recurrence: twelve timestep-boundary moves become eight. Output bits remain identical to 1.3.102, C and Fortran on the checked problem.

Seven interleaved longer runs measured medians of approximately 1.01649 s for Wheelchair 1.3.102 and 1.01675 s for Wheelchair 1.3.103. That ratio is -0.03%, which is measurement noise rather than a speedup. C and Fortran were both about 0.9668 s in that run, approximately 5% ahead of Wheelchair.

A shorter earlier run appeared to show about 1.8% improvement; the longer rerun did not reproduce it, so that number is rejected rather than published as a performance claim. 1.3.103 retains the structural repair because it removes redundant physical work and encoding duplication without adding workload-specific machinery.

These measurements are same-host diagnostics, not universal performance claims.
