#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.103" ]
[ -x test.sh ]
[ -x devtrash/coverage/run_native_coverage.sh ]
! grep -RqsE 'native_coverage|WHEELCHAIR_COVERAGE|coverage-real' compiler runtime surface tools build.sh
[ "$(grep -c '^test_.*\.sh$' devtrash/release_tests/current.list)" -eq 27 ]
[ "$(sort devtrash/release_tests/current.list | uniq -d | wc -l)" -eq 0 ]
grep -q '^test_execution_realization_13103.sh$' devtrash/release_tests/current.list
grep -q '^test_general_physical_reality_13103.sh$' devtrash/release_tests/current.list
grep -q '^test_tensor_fact_aging_13103.sh$' devtrash/release_tests/current.list
grep -q '^test_test_closure_13103.sh$' devtrash/release_tests/current.list
! grep -q '^test_execution_admission_expansion_1392.sh$' devtrash/release_tests/current.list
! grep -q '^test_general_physical_reality_13101.sh$' devtrash/release_tests/current.list
! grep -q '^test_tensor_fact_aging_13101.sh$' devtrash/release_tests/current.list
! grep -q '^test_test_closure_13101.sh$' devtrash/release_tests/current.list
while IFS= read -r t; do [ -x "devtrash/release_tests/$t" ]; done < devtrash/release_tests/current.list
printf '%s\n' \
  'TEST_OBSERVER_PRODUCTION_BACKEDGE=0' \
  'CURRENT_RELEASE_TEST_AUTHORITY=PASS' \
  'LEGACY_1_3_101_CURRENT_TEST_SPLIT=0' \
  'WHEELCHAIR_TEST_CLOSURE_1_3_103=PASS'
