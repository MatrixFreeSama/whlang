# Architecture Aging 1.3.103

The release removes two redundant scalar-FP physical identities without adding a new optimization layer.

1. Dead old StateFact authority is reusable storage. Once the existing effective last-use frontier proves the old value unavailable to every later consumer, a disjoint next-version carrier has no physical role.
2. Scalar FP register transport has one encoder authority. VEX handles ordinary registers and the same existing path upgrades to EVEX when register geometry requires it.

The resulting chain remains:

`Physical DAG -> lifetime proof -> carrier realization -> arithmetic -> completion -> OS return`

There is no dynamics-specific path, timestep class, state-shape selector, scheduler or second FP IR.
