# Wheelchair 1.3.103 Release Notes

1.3.103 ages General scalar FP realization by deleting transport that has lost physical purpose.

- A next FP StateFact may be born directly in its old carrier when the existing effective last-use frontier proves that old authority dead before the current update.
- This is the existing Physical DAG lifetime proof applied to placement. It does not inspect dynamics, material parameters, timestep ratios, state names, state count or benchmark shape.
- Scalar FP carrier copies now use the existing VEX/EVEX scalar emitter as their single encoding authority. The duplicate low-register copy encoder and its fall-through double-emission risk are deleted.
- Fixed-point generation authority, Strict arithmetic order, execution admission, completion-local exposure and OS resource return are unchanged.

Two rejected experiments are absent from the release: `2*x -> x+x` showed no stable wall-time benefit on the target host, and low-register-first carrier placement regressed the same workload. Neither became a compatibility path or optimization branch.

No workload matcher, explicit-dynamics recognizer, timestep heuristic, benchmark route, runtime idle-CPU query, scheduler, worker pool, work stealing, JIT path, source-visible parallel kernel, second FP backend or DSL execution surface is introduced.
