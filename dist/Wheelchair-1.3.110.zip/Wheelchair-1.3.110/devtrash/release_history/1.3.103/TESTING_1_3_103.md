# Testing 1.3.103

Current release authority remains 27 tests. The final compiler change passed all 27 current release tests; tests 19 through 27 were also rerun individually after the aggregate runner exceeded the external command time window.

Additional 1.3.103 probe:

- two independent explicit-dynamics regions, 10:1 timestep ratio;
- bit-identical checked outputs across Wheelchair 1.3.102, Wheelchair 1.3.103, C and Fortran;
- four redundant timestep carrier transports removed from the four-state FP recurrence;
- no `2*x -> x+x` rule retained after it failed to show stable wall-time benefit;
- no low-register-first placement retained after it regressed the target workload.

Inherited execution, Tensor, Field, fabric and Strict-semantic authority remains covered by the same 27-test release set.
