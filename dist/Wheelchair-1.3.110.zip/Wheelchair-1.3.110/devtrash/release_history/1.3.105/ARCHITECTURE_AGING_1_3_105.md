# Architecture Aging 1.3.105

Rank-N precision now has one semantic representation:

`fpP source -> interned type identity + u64 PrecisionFact(P) -> exact program trailer -> hot object precision`

The previous relation `type = flag | P` is deleted. Type identity no longer owns precision width, and the generated object no longer stores a second limb-count fact. Limb cardinality is derived from `P` as `(P + 63) >> 6` where needed.

The compiler's input/output type vectors and Rank-N precision facts share one represented-DOM-sized metadata arena. The runtime maps the exact emitted trailer. No fixed precision table, named-width family, compatibility decoder, runtime selector, JIT path, or second backend is added.

Existing arithmetic cores may still contain local digit/index widths. Those are implementation frontiers of the physical realization, not semantic precision ceilings. This release does not disguise them by inventing a larger precision constant.
