# Performance 1.3.105

1.3.105 is a representation-convergence release, not a benchmark-specific optimization release.

The hot Rank-N object remains 32 bytes before limb payload. Removing the stored limb count does not enlarge the object. Precision lookup occurs at type/object materialization; arithmetic continues to read precision from the hot object header. The change therefore removes duplicated metadata without inserting a runtime precision selector into arithmetic loops.

No universal wall-time speedup claim is attached to this release.
