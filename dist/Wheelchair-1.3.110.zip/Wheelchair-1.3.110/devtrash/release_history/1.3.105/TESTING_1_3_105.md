# Testing 1.3.105

Current release authority contains 29 tests.

The new `test_rankn_precision_fact_13105.sh` gate proves three properties:

1. `fp1073741824`, the first precision beyond the former 30-bit payload ceiling, compiles through the ordinary compiler path.
2. Generated Rank-N output exposes the u64 precision fact, and unrelated precisions coexist in one intern domain while existing precision-propagation policy remains authoritative.
3. Production compiler/runtime sources contain no old Rank-N flag/mask ceiling and no stored `RPF_N` limb-count field.

All earlier current release tests remain in the gate.
