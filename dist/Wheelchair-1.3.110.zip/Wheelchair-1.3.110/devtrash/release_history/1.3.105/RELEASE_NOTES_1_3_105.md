# Wheelchair 1.3.105 Release Notes

1.3.105 removes the historical Rank-N precision ceiling caused by packing `P` into a 30-bit type payload.

- `GTYPE_RANKN_FP_FLAG`, `GTYPE_RANKN_FP_MASK`, `RPF_TYPE_FLAG`, and `RPF_TYPE_MASK` are deleted.
- Every source `fpP` is interned into the ordinary represented-program type domain. The interned ID carries identity only.
- Precision is stored as a u64 `PrecisionFact` in the same instance-derived compiler metadata arena used by I/O type facts, then emitted into the exact-sized read-only program trailer.
- The runtime resolves an interned Rank-N type through that trailer and copies `P` into the object header once.
- The old stored `RPF_N` limb count is deleted. Limb cardinality is derived from precision.
- The arbitrary `1024` Rank-N type gap is deleted. Parameterized type IDs begin at `STATIC_LAST + 1`.
- Canonical Rank-N output prints precision, not compiler-internal type identity.
- `fp1073741824`, one bit beyond the former `0x3fffffff` ceiling, compiles through the ordinary Rank-N path.

No compatibility decoder for the encoded-type format is retained. No fp128/fp256 branch family, precision selector, workload matcher, JIT, kernel-offload surface, scheduler, worker pool, or second Rank-N backend is introduced.

This release removes the compiler semantic ceiling. It does not claim that every existing arithmetic realization has already aged every local digit/index counter to address-width cardinality; those remaining physical implementation frontiers stay visible for later convergence.
