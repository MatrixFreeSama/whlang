# Release Surface Convergence 1.3.105

The root release surface contains current 1.3.105 authority documents. 1.3.104 release documents are archived under `devtrash/release_history/1.3.104/`.

The current gate contains 29 tests. One new gate covers Rank-N precision-fact aging. No compatibility release surface is kept for the former encoded precision type IDs.
