# Wheelchair Charter 1.3.105

Wheelchair remains a whole-progress AOT general-purpose HPC language.

Mathematical structure defines causality. Physical Reality realizes that causality without turning parallelism into a source-level language promise. Compiler representations follow the same convergence rule: a fact should have one owner, and an implementation convenience should not become a second semantic authority.

For Rank-N floating point, type identity now answers only "which type fact" while precision answers only "how many significand bits". The compiler no longer limits precision because a type word reserved only 30 payload bits.

Strict numerical semantics remain stronger authority than execution geometry. This release adds no dynamic scheduler, worker pool, workload matcher, JIT, or DSL parallel surface.
