# Architecture Aging 1.3.104

The release removes independent capacity authorities that duplicated facts already present elsewhere.

`instance cardinality -> optimizer arena`

`kernel affinity width -> launch admission storage`

`CPUID terminator -> topology enumeration`

`Structured-Fact cardinality -> matrix dimension frontier`

The compiler therefore has fewer private tables and fewer unrelated numeric gates. It does not add a dynamic scheduler or parallel-language layer. Causality still defines available work; Physical Reality only decides realization.

Remaining fixed widths that encode an external format or machine representation are kept visible rather than replaced with larger constants. In particular, current `WHFLD216` rank/geometry is not claimed to be unbounded in this release.
