# Wheelchair Charter 1.3.104

Wheelchair remains a whole-progress AOT general-purpose HPC language.

Execution follows mathematical causality and Physical Reality. Parallelism is not a source-level language promise. The runtime does not query idle CPUs, steal work, maintain a persistent worker pool, or insert barriers to manufacture occupancy. Outward execution is permitted only as a physical realization of already-existing causal work, and completed executions return their capacity to the operating system.

Compiler capacity follows the same rule: if instance structure, kernel state, ISA geometry, or a representation already owns a bound, no second magic-number authority should sit above it. 1.3.104 removes such duplicate ceilings rather than replacing them with larger numbers.

Strict numerical semantics remain stronger authority than execution geometry. Tolerance may use its explicit numerical freedom; execution cardinality itself may never redefine Strict arithmetic.
