# Performance 1.3.104

1.3.104 is a structural hard-limit aging release. No benchmark-specific speedup claim is attached to it.

The removed 16/32/64 optimizer tables can preserve profitable facts on larger programs that previously fell off a profiling/CSE cliff. Dynamic affinity width also prevents very large admitted CPU sets from degenerating through an undersized `sched_getaffinity` buffer. These are capacity and correctness repairs, not a promise of universal wall-time improvement.

Mature Strict arithmetic order, existing physical carrier realization, and workload-independent AOT execution remain unchanged where the old limits were not reached.
