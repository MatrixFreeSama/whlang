# Release Surface Convergence 1.3.104

The root release surface contains current 1.3.104 authority documents. 1.3.103 release documents and its current-test snapshot are archived under `devtrash/release_history/1.3.103/`.

The current gate contains 28 tests. The additional gate proves the deleted argv/path, affinity, CPUID-enumeration, matrix-dimension, zeta, polylog, and tetration walls without creating compatibility implementations.
