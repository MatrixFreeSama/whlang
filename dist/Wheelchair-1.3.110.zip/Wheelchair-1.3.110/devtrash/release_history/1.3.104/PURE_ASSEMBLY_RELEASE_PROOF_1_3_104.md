# Pure Assembly Release Proof 1.3.104

Production compiler/runtime authority remains handwritten x86-64 assembly and direct static ELF emission.

Production binaries:

- `bin/wheelchairc`
- `bin/whexc`
- `bin/topologyc`
- `bin/topologyc-derived`
- `bin/topologyc-native256`
- `bin/topologyc-derived-native256`
- `bin/fieldc`
- `bin/fieldc-native256`

1.3.104 adds no LLVM, MLIR, C/C++, Rust, Python runtime, JIT, bytecode VM, OpenMP runtime, HLS compiler, source kernel, or alternate execution backend. Capacity aging is implemented in the existing assembly authorities.
