# Wheelchair 1.3.104 Release Notes

1.3.104 removes arbitrary compiler/runtime capacity ceilings where the existing instance, kernel, or representation already supplies the correct bound.

- Invocation affinity no longer assumes a 128-byte/1024-CPU world. `sched_getaffinity` storage grows on kernel `EINVAL`; compile-time static placement remains locality-only and can no longer collapse a wider invocation to one execution.
- The native driver deletes fixed 4096-byte executable/selected-path arrays and the 257-slot argv mirror. Paths are mmap-sized and process-start argv is reused directly.
- General whole-episode physical CSE/constant candidate storage is allocated from JSON-fact cardinality. The former 32-candidate table is gone.
- Tensor constant/affine profiling and value/index CSE storage share the existing optimizer arena and follow optimizer cardinality. The former 16/64-slot tables are gone.
- CPUID topology/cache enumeration terminates only on architectural termination facts; the extra 8-level and 32-subleaf fuses are gone.
- Structured matrix/vector identity no longer places dimension in the old 255-wide tag window. Component cardinality remains the representation frontier.
- `zeta`, `polylog`, and `tetration` no longer impose the historical 32, 16, and 8 AOT-static semantic walls. Their generated structure is bounded by ordinary representation/memory facts instead.

No workload matcher, benchmark route, scheduler, worker pool, runtime idle-CPU query, JIT path, source-visible parallel directive, kernel-offload surface, or second semantic backend is introduced.

`WHFLD216` rank width and its signed-dword field geometry are deliberately not disguised by increasing constants. They remain an explicit external-format/runtime representation frontier requiring a format-and-hot-table redesign, not a magic-number patch.
