# Testing 1.3.104

Current release authority contains 28 tests.

The new hard-limit gate checks that fixed native-driver buffers, fixed affinity width, CPUID enumeration fuses, the 255 matrix dimension wall, and the 32/16/8 zeta/polylog/tetration walls are absent. It also compiles programs beyond the former math limits: `zeta(33)`, `polylog(17, 0.5)`, and `tetration(1.0, 9)`.

General physical-reality tests now assert instance-derived CSE/constant storage. Tensor aging tests assert optimizer-arena-backed profiling/cache storage. Existing Strict reference bits and execution-cardinality invariants remain part of the gate.
