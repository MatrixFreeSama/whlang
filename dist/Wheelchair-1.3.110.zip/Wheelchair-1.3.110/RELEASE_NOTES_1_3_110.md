# Wheelchair 1.3.110 Release Notes

1.3.110 deletes the Field Rank-8 semantic/ABI wall instead of moving it to a larger constant.

- `FIELD_RUNTIME_RANK_CAP`, `MAX_RANK`, fixed 32-byte access deltas and fixed eight-axis extent/stride tables are absent from production Field paths.
- `WHFLD217` stores one u64 RankFact and exact Rank-N extent/stride descriptor spans. `WHFLD216` is rejected; no compatibility reader survives.
- Surface and canonical Field lowering allocate RankFact-derived axis arenas.
- Native512/Native256 use one runtime-rank address relation. The historical `r1..r8` prepare/offset/load/store families are deleted.
- AVX-512's spare ZMM coordinate carriers are physical resources, not a semantic axis ceiling.
- Rank 9, 17 and 33 execute through the ordinary release path on both native widths.
- A caller-saved RankFact lifetime bug in mutable-field contiguity proof is repaired, and gather/scatter mask state is restored at the ISA consumption boundary.

No rank selector, old-format converter, workload matcher, JIT, scheduler, worker pool, source-visible parallel construct or second Field backend is introduced.
