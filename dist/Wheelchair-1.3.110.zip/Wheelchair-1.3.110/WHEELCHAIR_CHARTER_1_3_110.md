# Wheelchair Charter 1.3.110

Wheelchair continues toward the mathematical-physical lower bound by deleting limits and work that are not implied by the represented mathematics or physical machine.

For Field, rank is one RankFact. File layout, metadata, AddressFacts, CoordinateFacts and machine realization may integrate that fact differently, but no fixed axis width may become a language semantic limit. A finite register bank is a Physical Reality input, not permission to reject a higher-rank program.

For arbitrary precision (`P > 64`), local propagation remains the single execution principle. Different numerical relations may integrate it through different native coordinates, but none becomes a separate high-precision subsystem.

Compatibility branches are not an architectural preservation mechanism. When an authority is replaced, the obsolete authority is deleted.
