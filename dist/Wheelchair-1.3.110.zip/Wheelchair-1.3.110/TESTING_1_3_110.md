# Testing 1.3.110

The current release authority remains 29 tests. Existing CoordinateFact and hard-limit gates are aged in place rather than stacking another test family.

The Field RankFact gate executes rank 9, 17 and 33 on Native512 and Native256, exercises non-power-of-two mixed-radix coordinates, and retains truthful gather fallback. Human Field syntax crosses the historical eighth-axis boundary. Existing broad Field tests continue to cover padded/strided output, irregular gather, inout/noalias, tail masks, periodic boundaries and strict/tolerant behavior.
