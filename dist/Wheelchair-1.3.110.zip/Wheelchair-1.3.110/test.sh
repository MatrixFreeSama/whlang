#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
MODE=${1:-release}
LOG="$ROOT/RELEASE_TEST_LOG_1_3_107.txt"
TMP=${TMPDIR:-/tmp}/wheelchair_test_13107_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"

record() {
  label=$1
  shift
  safe=$(printf '%s' "$label" | tr '/: ' '___')
  out="$TMP/out.$safe"
  printf '[%s]\n' "$label" >> "$LOG"
  if "$@" > "$out" 2>&1; then
    cat "$out" >> "$LOG"
  else
    cat "$out" >> "$LOG"
    cat "$out" >&2
    printf 'FAILED=%s\n' "$label" >&2
    exit 1
  fi
  printf '\n' >> "$LOG"
}

run_release() {
  : > "$LOG"
  record build ./build.sh
  sha256sum \
    bin/fieldc bin/fieldc-native256 \
    bin/topologyc bin/topologyc-derived bin/topologyc-derived-native256 bin/topologyc-native256 \
    bin/wheelchairc bin/whexc > PRODUCTION_BIN_SHA256_1_3_107.txt
  while IFS= read -r test; do
    [ -n "$test" ] || continue
    record "$test" "devtrash/release_tests/$test"
  done < devtrash/release_tests/current.list
  printf '%s\n' \
    'CURRENT_RELEASE_TESTS=29/29' \
    'CURRENT_RELEASE_TEST_FAILURES=0' \
    'MATHEMATICAL_PHYSICAL_CONVERGENCE_1_3_81=PASS' \
    'COORDINATEFACT_AGING_1_3_82=PASS' \
    'MUTABLE_STATEFACT_1_3_83=PASS' \
    'SILICON_REALIZATION_1_3_84=PASS' \
    'SILICON_DOMAIN_GRAPH_1_3_85=PASS' \
    'SILICON_DOMAIN_IDENTITY_1_3_86=PASS' \
    'SILICON_STATIC_PLACEMENT_1_3_87=PASS' \
    'HETEROGENEOUS_PHYSICAL_EDGE_1_3_88=PASS' \
    'FABRIC_TARGET_FACTS_1_3_89=PASS' \
    'FABRIC_REALIZATION_DESCRIPTOR_1_3_90=PASS' \
    'FABRIC_ACTIVATION_FIELD_DATAPATH_1_3_91=PASS' \
    'INVOCATION_BOUND_EXECUTION_ADMISSION_1_3_102=PASS' \
    'STATIC_PLACEMENT_INVOCATION_INTERSECTION_1_3_102=PASS' \
    'STRICT_REDUCTION_EXECUTION_CARDINALITY_INVARIANT_1_3_102=PASS' \
    'ARBITRARY_CARDINALITY_LAUNCH_FRONTIER_1_3_102=PASS' \
    'COMPLETION_LOCAL_SIBLING_EXPOSURE_1_3_102=PASS' \
    'TRANSPORT_ISSUE_ORTHOGONALITY_1_3_93=PASS' \
    'SPATIAL_TEMPORAL_QUOTA_ORTHOGONALITY_1_3_94=PASS' \
    'MIXED_RADIX_CARRY_RECURRENCE_1_3_102=PASS' \
    'SCALED_FACT_LOGICAL_PHYSICAL_ALIAS=0' \
    'TOLERANT_LITERAL_DIV_RECIPROCAL_1_3_102=PASS' \
    'GENERAL_FP_DEAD_AUTHORITY_REUSE_1_3_103=PASS' \
    'SCALAR_FP_TRANSPORT_EMITTER_CONVERGENCE_1_3_103=PASS' \
    'WORKLOAD_SPECIFIC_FP_ROUTE_1_3_103=0' \
    'SECOND_FP_TRANSITION_BACKEND_1_3_103=0' \
    'INSTANCE_DERIVED_OPTIMIZER_CAPACITY_1_3_104=PASS' \
    'KERNEL_DERIVED_AFFINITY_WIDTH_1_3_104=PASS' \
    'ARBITRARY_MATH_DIMENSION_WALLS_1_3_104=0' \
    'RANKN_TYPE_PHYSICAL_FACT_1_3_106=PASS' \
    'RUNTIME_FOURIER_PLANNER_1_3_106=0' \
    'RANKN_DECIMAL_PER_DIGIT_FOURIER_1_3_106=0' \
    'RANKN_LOCAL_CARRIER_PROJECTION_1_3_107=PASS' \
    'RANKN_STRICT_CLOSE_AUTHORITY_1_3_107=PASS' \
    'SOURCE_VISIBLE_LOCAL_FLOAT_DIALECT_1_3_107=0' \
    'WHEELCHAIR_TEST_1_3_107=PASS' | tee -a "$LOG"
}

run_coverage() {
  sh devtrash/coverage/run_native_coverage.sh
}

case "$MODE" in
  release) run_release ;;
  coverage) run_coverage ;;
  all) run_release; run_coverage ;;
  *) printf 'usage: %s [release|coverage|all]\n' "$0" >&2; exit 64 ;;
esac
