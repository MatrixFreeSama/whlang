# Architecture Aging 1.3.110

Field axis cardinality is now an invocation RankFact instead of a fixed external/runtime width. Surface lowering, canonical Field metadata, AddressFact deltas, Region/Coordinate facts and runtime axis tables allocate exactly the represented rank.

`WHFLD217` replaces the fixed `extent[8] / stride[8]` descriptor with a 64-byte fixed header followed by `rank` u64 extents and `rank` u64 strides. The compiler/runtime ABI carries one u64 RankFact and one RankFact-derived delta stride. The old `r1..r8` address/load/store families and the AVX-512 eight-carrier semantic width authority are deleted; both native widths use one runtime-rank address relation.

This is not a generic fallback layered beside the old path. The fixed-rank path is absent. The remaining signed-dword coordinate and physical-offset representation frontier is separate from rank cardinality and remains explicit.
