# Performance 1.3.110

1.3.110 is primarily a capacity/physicalization convergence release. The purpose is to delete fixed-rank duplicated machine families without charging common ranks for a generic compatibility path.

On the same host, a 1,048,576-element strict f32 reduction compared with unmodified 1.3.109 produced the following median ratios (`1.3.109 / 1.3.110`):

| rank | Native512 | Native256 |
|---:|---:|---:|
| 3 | 1.039x | 1.006x |
| 8 | 0.999x | 1.018x |

These differences are small enough that no broad speedup is claimed. The important result is that deleting the fixed r1..r8 runtime family does not create a low-rank performance cliff while rank 9/17/33 become executable through the same authority.
