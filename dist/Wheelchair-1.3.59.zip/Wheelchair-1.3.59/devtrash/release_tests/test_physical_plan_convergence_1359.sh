#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -x bin/whexc ] || ./build.sh >/dev/null

# The common pass-0 scheduler is sovereign in the three historical locations
# that used to overwrite its result with a fixed two-body episode.
for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  grep -q 'call synthesize_resource_schedule' "$f"
  grep -q 'mov eax,dword ptr \[rip+schedule_unroll\]' "$f"
  grep -q 'mov dword ptr \[rip+physical_plan_unroll\],eax' "$f"
  ! grep -Fq 'mov dword ptr [rip+schedule_unroll],2' "$f"
  ! grep -Fq 'mov dword ptr [rip+physical_plan_unroll],2' "$f"
done

# Derived native512 closes over the shape that was actually emitted.  It is not
# converted into the base fixed-width rule and must keep its probe/canonical
# realized-shape equality.
grep -q 'physical_realized_unroll' compiler/tensor_derived_frontend_x86_64.S
grep -q 'cmp eax,dword ptr \[rip+physical_plan_unroll\]' compiler/tensor_derived_frontend_x86_64.S

LIGHT=devtrash/tests/whex/emergent_light_reduction_1318.whex
NEWTON=devtrash/tests/whex/newton_jv_mature_regression.whex
FSI=devtrash/benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
R3=devtrash/tests/whex/rank3_native_122.whex
R3S=devtrash/tests/whex/rank3_neighborhood_strict_1215.whex

bin/topologyc "$LIGHT" -o "$T/light" >/dev/null
[ "$("$T/light" 4)" = 'checksum_bits=0x4078400000000000' ]
bin/topologyc "$NEWTON" -o "$T/newton" >/dev/null
[ "$("$T/newton" 4)" = 'checksum_bits=0xbfaa960790000000' ]

# 1.3.58 selector convergence stays exact after the physical-plan aging.
bin/whexc "$FSI" -o "$T/fsi-whexc" >/dev/null
bin/topologyc "$FSI" -o "$T/fsi-base" >/dev/null
cmp "$T/fsi-whexc" "$T/fsi-base"
[ "$("$T/fsi-whexc" 4)" = 'checksum_bits=0x3fb2acf007b0d71c' ]

# native256 base follows the same scheduler authority and preserves the declared
# mathematical result for the mature rank-1 probes.
for C in topologyc-native256; do
  bin/$C "$LIGHT" -o "$T/light-256" >/dev/null
  [ "$("$T/light-256" 4)" = 'checksum_bits=0x4078400000000000' ]
  bin/$C "$NEWTON" -o "$T/newton-256" >/dev/null
  [ "$("$T/newton-256" 4)" = 'checksum_bits=0xbfaa960790000000' ]
done

# Derived native256 no longer has a private post-scheduler width overwrite.
bin/topologyc-derived-native256 "$R3" -o "$T/r3-256" >/dev/null
[ "$("$T/r3-256" 17)" = 'checksum_bits=0x40c1ee0000000000' ]
bin/topologyc-derived-native256 "$R3S" -o "$T/r3s-256" >/dev/null
[ "$("$T/r3s-256" 17)" = 'checksum_bits=0x40fac74000000000' ]

# Productized ShapeFact still selects the existing derived native512 consumer.
R3B=devtrash/tests/shapefact_1357/rank3_batch.whex
bin/whexc "$R3B" -o "$T/r3-whexc" >/dev/null
bin/topologyc-derived "$R3B" -o "$T/r3-derived" >/dev/null
cmp "$T/r3-whexc" "$T/r3-derived"

echo PHYSICAL_PLAN_CONVERGENCE_1_3_59=PASS
