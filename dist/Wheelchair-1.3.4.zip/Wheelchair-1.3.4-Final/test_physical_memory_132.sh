#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair132_memory_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

case "$(cat VERSION)" in 1.3.1|1.3.2|1.3.3) ;; *) exit 1 ;; esac
./build.sh > "$T/build.log" 2>&1
for m in \
 PHYSICAL_MEMORY_DAG=BUILT \
 MUTABLE_LAYOUT_INJECTIVITY=BUILT \
 WRITABLE_CACHELINE_GEOMETRY_PROOF=BUILT \
 GENERAL_CAUSAL_NODE_PAGE_ISOLATION=4096 \
 GENERAL_CAUSAL_ARRIVAL_COUNT=BUILT \
 GENERAL_MUTABLE_MAILBOX_PAGE_ISOLATION=4096 \
 CHILD_RESULT_PRIVATE_OWNERSHIP=BUILT \
 NUMA_NODE_LOCALIZATION=best-effort-getcpu-mbind \
 MEMORY_ISA_OVERRIDE=non-temporal-pure-output \
 SINGLE_TOUCH_CAUSAL_TRANSFER=BUILT \
 CENTRAL_MEMORY_SCHEDULER=0 \
 WHEELCHAIR_1_3_2_BUILD=PASS
do grep -q "$m" "$T/build.log"; done
echo 'PHYSICAL_MEMORY_BUILD_AUTHORITY=PASS'

# Mutable address injectivity is a launch-time mathematical proof, not an
# executor-count workaround. A legal-span but self-aliasing writable layout is
# rejected by both native widths; the same overlapping layout is legal read-only.
for C in fieldc fieldc-native256; do
  build/$C tests/field_1216/copy.json -o "$T/$C-copy" --executors 4 >/dev/null
  cp tests/field_1216/out_3x5x7.whfld "$T/$C-badout.whfld"
  for off in 96 104 112; do
    printf '\004\000\000\000\000\000\000\000' | dd of="$T/$C-badout.whfld" bs=1 seek=$off conv=notrunc status=none
  done
  set +e
  "$T/$C-copy" tests/field_1216/a_3x5x7.whfld "$T/$C-badout.whfld" >/dev/null 2>&1
  r=$?
  set -e
  [ "$r" -eq 2 ]

  build/$C tests/field_1216/sum.json -o "$T/$C-sum" --executors 4 >/dev/null
  cp tests/field_1216/a_3x5x7.whfld "$T/$C-aliasin.whfld"
  for off in 96 104 112; do
    printf '\004\000\000\000\000\000\000\000' | dd of="$T/$C-aliasin.whfld" bs=1 seek=$off conv=notrunc status=none
  done
  "$T/$C-sum" "$T/$C-aliasin.whfld" >/dev/null
done
echo 'MUTABLE_LAYOUT_INJECTIVITY=PASS'
echo 'READONLY_OVERLAPPING_VIEW=PASS'

# Build large rank-3 descriptors entirely with POSIX tools. 4*64*256 = 65536
# f32 values => four 16K-element chunks, enough to exercise physical ownership.
make_large_header() {
  f=$1; s0=$2; s1=$3; s2=$4
  cp tests/field_1216/a_3x5x7.whfld "$f"
  # extents: 4, 64, 256
  printf '\004\000\000\000\000\000\000\000' | dd of="$f" bs=1 seek=32 conv=notrunc status=none
  printf '\100\000\000\000\000\000\000\000' | dd of="$f" bs=1 seek=40 conv=notrunc status=none
  printf '\000\001\000\000\000\000\000\000' | dd of="$f" bs=1 seek=48 conv=notrunc status=none
  case "$s0" in
    65536) b0='\000\000\001\000\000\000\000\000' ;;
    4)     b0='\004\000\000\000\000\000\000\000' ;;
    *) exit 99;;
  esac
  case "$s1" in
    1024) b1='\000\004\000\000\000\000\000\000' ;;
    16)   b1='\020\000\000\000\000\000\000\000' ;;
    *) exit 99;;
  esac
  case "$s2" in
    4)    b2='\004\000\000\000\000\000\000\000' ;;
    1024) b2='\000\004\000\000\000\000\000\000' ;;
    *) exit 99;;
  esac
  printf "$b0" | dd of="$f" bs=1 seek=96 conv=notrunc status=none
  printf "$b1" | dd of="$f" bs=1 seek=104 conv=notrunc status=none
  printf "$b2" | dd of="$f" bs=1 seek=112 conv=notrunc status=none
  # total = 65536
  printf '\000\000\001\000\000\000\000\000' | dd of="$f" bs=1 seek=160 conv=notrunc status=none
  truncate -s 262400 "$f"
  dd if=/dev/zero of="$f" bs=256 seek=1 count=1024 conv=notrunc status=none
}
make_large_header "$T/in-large.whfld" 65536 1024 4
make_large_header "$T/out-large.whfld" 65536 1024 4
# One non-zero datum proves streaming output really reaches the mapped file.
printf '\000\000\200\077' | dd of="$T/in-large.whfld" bs=1 seek=256 conv=notrunc status=none

build/fieldc tests/field_1216/copy.json -o "$T/copy-large512" --executors 4 >/dev/null
"$T/copy-large512" "$T/in-large.whfld" "$T/out-large.whfld" >/dev/null
cmp "$T/in-large.whfld" "$T/out-large.whfld"
make_large_header "$T/out-large256.whfld" 65536 1024 4
build/fieldc-native256 tests/field_1216/copy.json -o "$T/copy-large256" --executors 4 >/dev/null
"$T/copy-large256" "$T/in-large.whfld" "$T/out-large256.whfld" >/dev/null
cmp "$T/in-large.whfld" "$T/out-large256.whfld"
echo 'CONTIGUOUS_FIELD_FASTPATH_PRESERVED=PASS'
echo 'MEMORY_ISA_STREAMING_OUTPUT_RUNTIME_512_256=PASS'

# This transpose-like layout is injective but logical chunks interleave physical
# ownership. q1 is legal; q4 must reject rather than false-share or silently
# serialize. (AVX-512 is used because it has architectural scatter.)
make_large_header "$T/out-transpose.whfld" 4 16 1024
build/fieldc tests/field_1216/copy.json -o "$T/copy-q1" --executors 1 >/dev/null
"$T/copy-q1" "$T/in-large.whfld" "$T/out-transpose.whfld" >/dev/null
cp "$T/out-transpose.whfld" "$T/out-transpose-q4.whfld"
set +e
"$T/copy-large512" "$T/in-large.whfld" "$T/out-transpose-q4.whfld" >/dev/null 2>&1
r=$?
set -e
[ "$r" -eq 2 ]
echo 'STRIDED_WRITABLE_PHYSICAL_OWNERSHIP_GATE=PASS'
echo 'NO_HIDDEN_Q1_SERIAL_FALLBACK=PASS'

# ISA evidence: large pure output owns non-temporal full-vector stores, while
# every worker fences its own stream before causal ownership ends.
objdump -d build/field_runtime_512_template | grep -q 'vmovntps'
objdump -d build/field_runtime_256_template | grep -q 'vmovntps'
objdump -d build/field_runtime_512_template | grep -q 'sfence'
objdump -d build/field_runtime_256_template | grep -q 'sfence'
echo 'MEMORY_ISA_OVERRIDE_VERIFIED=PASS'

# General mutable objects are page mailboxes/state, never packed writable slots.
grep -q '^\.equ MUTABLE_SLOT_BYTES, 4096$' runtime/general_runtime_template_x86_64.S
grep -q '^binding_mailboxes:$' runtime/general_runtime_template_x86_64.S
grep -q '^state_temp_mailboxes:$' runtime/general_runtime_template_x86_64.S
grep -q '^output_pages:$' runtime/general_runtime_template_x86_64.S
for fn in g_binding_slot_addr g_state_slot_addr g_state_temp_addr g_output_slot_addr; do
  grep "$fn:" compiler/general_frontend_x86_64.S | grep -q 'shl rax,12'
done
grep -q '^\.equ ST_NODE_BYTES, 4096$' runtime/general_parallel_release_x86_64.S
grep -q 'ST_NODE_ARRIVED' runtime/general_parallel_release_x86_64.S
if grep -q 'ST_REMAIN' runtime/general_parallel_release_x86_64.S; then exit 1; fi
grep -q 'SYS_getcpu' runtime/general_parallel_release_x86_64.S
grep -q 'SYS_mbind' runtime/general_parallel_release_x86_64.S
grep -Fq 'lock add dword ptr [rdi],1' runtime/general_parallel_release_x86_64.S
echo 'UNRELATED_WRITABLE_PAGE_SHARING=0'
echo 'GENERAL_CAUSAL_PAGE_OWNERSHIP=PASS'
echo 'NUMA_OWNER_LOCALIZATION_PATH=PASS'

# Child-to-parent values live at the child-owned stack-slice base, not a parent
# writable cache line. Validate every runtime physicalization.
for f in \
 runtime/tensor_runtime_template_x86_64.S \
 frozen_native/generated_derived/tensor_derived_runtime_template_x86_64.S \
 frozen_native/generated_native256/tensor_runtime_native256_template_x86_64.S \
 frozen_native/generated_native256/tensor_derived_runtime_native256_template_x86_64.S \
 runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S
do
  grep -q 'mov \[rsp+8\],rax' "$f"
  sed -n '/^run_tree:/,/^# worker/p' "$f" | grep -q 'mov r15,rax'
  if sed -n '/^run_tree:/,/^# worker/p' "$f" | grep -q 'mov r15,rsp'; then exit 1; fi
done
echo 'CHILD_RESULT_LINE_ISOLATION=PASS'
echo 'SINGLE_TOUCH_CAUSAL_HANDOFF=PASS'

# Parallel-runtime patch addresses are derived from the actual native ELF; no
# stale handwritten memory-layout constants remain in the compiler.
grep -q 'build/general_parallel_release_offsets.inc' compiler/general_frontend_x86_64.S
if grep -q '^\.equ GR_NODE_COUNT_OFF,0x' compiler/general_frontend_x86_64.S; then exit 1; fi
test -s build/general_parallel_release_offsets.inc
echo 'PHYSICAL_MEMORY_LAYOUT_OFFSET_CLOSURE=PASS'

# Dynamic causal semantics at both ordinary width and the 256-domain ceiling.
build/wheelchairc tests/general_parallel_126/causal_mesh_probe.wh -o "$T/mesh4" --executors 4 >/dev/null
[ "$("$T/mesh4" 1)" = 'out00_bits=0x0000000000000018' ]
build/wheelchairc tests/general_parallel_126/iterate_probe.wh -o "$T/iterate256" --executors 256 >/dev/null
[ "$("$T/iterate256" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ]
echo 'RECIPIENT_BLIND_CAUSAL_MEMORY_Q256=PASS'

if grep -RniE 'work[ _-]*steal|global[ _-]*(ready|memory)[ _-]*queue|central[ _-]*memory[ _-]*scheduler' \
  runtime/general_parallel_release_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S \
  | grep -v -E 'There is no|no .*work|CENTRAL_MEMORY_SCHEDULER' >/dev/null 2>&1; then
  echo 'CENTRAL_MEMORY_COORDINATOR=FAIL' >&2; exit 1
fi
echo 'NO_CENTRAL_MEMORY_SCHEDULER=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'PHYSICAL_MEMORY_FIDELITY_CHECK=PASS'
echo 'WHEELCHAIR_PHYSICAL_MEMORY_CAUSALITY_1_3_2=PASS'
