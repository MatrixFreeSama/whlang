#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
CC="$ROOT/bin/wheelchairc"

# Surface storage is structural: retired monolithic static slabs and Field-shell
# serialization/cardinality tiers must not return.
S="$ROOT/compiler/surface_lowerer_x86_64.S"
F="$ROOT/compiler/field_surface_lowerer_x86_64.inc"
G="$ROOT/compiler/general_frontend_x86_64.S"
RC="$ROOT/compiler/general_runtime_capacity.inc"
! grep -q '^\.equ SAST_MAX' "$S"
! grep -q '^\.equ SBUF_.*_CAP' "$S"
grep -q '^s_grow_ast_slab:' "$S"
grep -q '^s_out_reserve:' "$S"
grep -q '^s_alloc_pointer_workset:' "$S"
! grep -q 'SFH_OPS_CAP' "$F"
! grep -q 'SFH_MAX_SCALARS' "$F"
! grep -q 'SFH_MAX_REDUCES' "$F"
grep -q 'same growable serialization' "$F"
! grep -q 'GENERAL_RUNTIME_BINDING_SLOT_CAP' "$RC"
grep -q '^dynamic_arena_bytes_patch:' "$ROOT/runtime/general_runtime_template_x86_64.S"
grep -q '^program_trailer_file_offset_patch:' "$ROOT/runtime/general_runtime_template_x86_64.S"
! grep -q 'GENERAL_DATA_MEMSZ_FILE_OFF' "$G"

# Human Surface + General runtime: cross the retired 240 binding mailbox tier.
python3 - "$T/b300.wh" <<'PY'
import sys
p=sys.argv[1]
lines=['program bindings300','let b0: u64 = 1']
for i in range(1,300):
    lines.append(f'let b{i}: u64 = b{i-1} + 1')
lines += ['let answer: u64 = b299','output answer']
open(p,'w').write('\n'.join(lines)+'\n')
PY
"$CC" "$T/b300.wh" -o "$T/b300" >/dev/null
[ "$("$T/b300")" = 'out00_bits=0x000000000000012c' ]

# Field human-shell scalar metadata is source-sized rather than the retired 32 tier.
python3 - "$T/f40.wh" <<'PY'
import sys
p=sys.argv[1]
lines=['program field_scalar40','strict']
for i in range(40): lines.append(f'input s{i}: u64')
lines += [
 'input field u[x in s0 periodic]: f32',
 'output field out[x in s0]: f32',
 'for x in s0 {',
 '  out[x] = u[x]',
 '}'
]
open(p,'w').write('\n'.join(lines)+'\n')
PY
"$CC" "$T/f40.wh" -o "$T/f40" >/dev/null

# Matrix decomposition worksets scale with dimension.  This crosses the retired
# sixteen-component/4x4 Cholesky scratch wall using the same existing relation.
cat > "$T/ch5.wh" <<'SRC'
program cholesky5
let A = matrix(5,
4.0,0.0,0.0,0.0,0.0,
0.0,4.0,0.0,0.0,0.0,
0.0,0.0,4.0,0.0,0.0,
0.0,0.0,0.0,4.0,0.0,
0.0,0.0,0.0,0.0,4.0)
let L = cholesky(A)
let x: f64 = mget(L,0,0)
output x
SRC
"$CC" "$T/ch5.wh" -o "$T/ch5" >/dev/null
[ "$("$T/ch5")" = 'out00_bits=0x4000000000000000' ]

# Static reservation must not regress to the old ~119 MiB Surface slab in the
# launcher. This is a build-layout invariant, not a runtime performance claim.
bss=$(size "$ROOT/bin/wheelchairc" | awk 'NR==2 {print $3}')
[ "$bss" -lt 1048576 ]

# Mature Newton-Jv generated machine image remains unchanged by storage aging.
"$ROOT/bin/whexc" "$ROOT/devtrash/tests/whex/newton_jv_mature_regression.whex" -o "$T/newton" >/dev/null
[ "$(sha256sum "$T/newton" | awk '{print $1}')" = 'bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac' ]

echo ARCHITECTURE_AGING_1_3_54=PASS
