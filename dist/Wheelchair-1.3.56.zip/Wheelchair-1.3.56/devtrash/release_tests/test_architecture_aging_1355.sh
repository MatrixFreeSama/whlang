#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -x bin/wheelchairc ] || ./build.sh >/dev/null

G=compiler/general_frontend_x86_64.S
GR=runtime/general_runtime_template_x86_64.S
GC=compiler/general_runtime_capacity.inc
F=compiler/field_frontend_common_x86_64.S

# 1.3.55: General cardinality belongs to each AOT program instance, not the
# runtime template. No enlarged replacement cap is accepted.
! grep -Eq 'GENERAL_RUNTIME_(INPUT|BINDING_SLOT|STATE|OUTPUT)_CAP' "$GC"
grep -q '^\.equ GENERAL_RUNTIME_DYNAMIC_ARENA_VA,' "$GC"
grep -q '^g_prepare_code_arenas:' "$G"
grep -q 'g_code_growth_factor' "$G"
grep -q 'g_code_overflow' "$G"
! grep -q 'GCODE_CAP' "$G"
grep -q '^dynamic_arena_bytes_patch:' "$GR"
grep -q '^program_trailer_file_offset_patch:' "$GR"
grep -q '^program_trailer_size_patch:' "$GR"
grep -q '^program_code_rel_offset_patch:' "$GR"
grep -q '^rankn_input_end_patch:' "$GR"
grep -q '^g_measure_runtime_state_capacity:' "$G"
grep -q '^g_measure_rankn_input_workspace:' "$G"
! grep -Eq 'RPF_INPUT_(OBJ_)?STRIDE|GRPF_INPUT_STRIDE' "$G" "$GR"

# Field compiler graph/code staging is structural; current physical Field ABI
# (field/rank/access/VREG) is intentionally outside this assertion.
! grep -Eq '^\.equ (MAX_OPS|MAX_CONST_POOL|GEN_CAP),' "$F"
grep -q '^ff_prepare_graph_arena:' "$F"
grep -q '^ff_prepare_code_arena:' "$F"
grep -q 'ff_code_growth_factor' "$F"
grep -q 'ff_code_overflow' "$F"

# Runtime template should not carry the retired hundreds-of-MiB program record.
bss=$(size build/general_runtime_template | awk 'NR==2 {print $3}')
[ "$bss" -lt 1048576 ]

# Cross the retired 16-input / 32-output General record with existing semantics.
python3 - "$T/io40.wh" <<'PY'
import sys
p=sys.argv[1]
lines=['program io40']
for i in range(40): lines.append(f'input x{i}: u64')
lines.append('let y: u64 = x0 + 0')
for i in range(40): lines.append(f'output o{i} = x{i}')
open(p,'w').write('\n'.join(lines)+'\n')
PY
bin/wheelchairc "$T/io40.wh" -o "$T/io40" >/dev/null
mapfile -t io_out < <("$T/io40" $(seq 0 39))
[ "${#io_out[@]}" -eq 40 ]
[ "${io_out[0]}" = 'out00_bits=0x0000000000000000' ]
[ "${io_out[39]}" = 'out39_bits=0x0000000000000027' ]

# Cross the retired 64-state runtime record: 80 f64 states + one u64 counter.
python3 - "$T/state81.wh" <<'PY'
import sys
p=sys.argv[1]
lines=['program state81','input steps: u64','iterate sim limit steps {']
for i in range(80): lines.append(f'    state s{i}: f64 = {float(i):.1f}')
lines += ['    state i: u64 = 0','    while i < steps']
for i in range(80): lines.append(f'    update s{i} = s{i} + 1.0')
lines += ['    update i = i + 1','    result s0','}','publish sim']
open(p,'w').write('\n'.join(lines)+'\n')
PY
bin/wheelchairc "$T/state81.wh" -o "$T/state81" >/dev/null
[ "$("$T/state81" 0)" = 'out00_bits=0x0000000000000000' ]
[ "$("$T/state81" 1)" = 'out00_bits=0x3ff0000000000000' ]

# Cross the retired 512-KiB General AOT program slot. The code trailer length is
# read from the runtime's own generated metadata, not inferred from file size.
python3 - "$T/code18k.wh" <<'PY'
import sys
p=sys.argv[1]
lines=['program code18k','let b0: u64 = 1']
for i in range(1,18000): lines.append(f'let b{i}: u64 = b{i-1} + 1')
lines += ['let answer: u64 = b17999','output answer']
open(p,'w').write('\n'.join(lines)+'\n')
PY
bin/wheelchairc "$T/code18k.wh" -o "$T/code18k" >/dev/null
[ "$("$T/code18k")" = 'out00_bits=0x0000000000004650' ]
python3 - "$T/code18k" compiler/general_runtime_offsets.inc <<'PY'
import re,struct,sys
path,incpath=sys.argv[1:]
inc=open(incpath).read()
def off(name):
    m=re.search(rf'^\.equ {name},\s*(0x[0-9a-fA-F]+|\d+)',inc,re.M)
    if not m: raise SystemExit(f'missing {name}')
    return int(m.group(1),0)
f=open(path,'rb').read()
trailer_size=struct.unpack_from('<Q',f,off('GENERAL_PROGRAM_TRAILER_SIZE_OFF'))[0]
code_rel=struct.unpack_from('<Q',f,off('GENERAL_PROGRAM_CODE_REL_OFFSET_OFF'))[0]
code_len=trailer_size-code_rel
if code_len <= 524288: raise SystemExit(f'code trailer did not cross old cap: {code_len}')
print(f'GENERAL_CODE_TRAILER_BYTES={code_len}')
PY

# Field compiler graph/code staging crosses both retired compiler-only tiers:
# >8192 existing ops and >64 distinct constants. This does not change the
# existing Field runtime rank/access/VREG ABI.
python3 - "$T/field9000.json" <<'PY'
import json,sys
ops=[{'op':'load','access':0,'dst':0}]
for i in range(8997):
    ops.append({'op':'const','value':float((i%70)+1),'dst':1})
ops += [{'op':'store','field':1,'src':0},{'op':'reduce','src':0}]
obj={
 'format':'wheelchair.field/1','contracts':{'floating_point':'strict'},
 'fields':[{'mode':'input','type':'f32','rank':1},{'mode':'output','type':'f32','rank':1}],
 'accesses':[{'field':0,'delta':[0]}],'ops':ops
}
open(sys.argv[1],'w').write(json.dumps(obj,separators=(',',':')))
PY
bin/fieldc "$T/field9000.json" -o "$T/field9000" >/dev/null
[ -x "$T/field9000" ]

# Cross the retired fixed 1-MiB fpP parser-object tier.  P=131073 makes the
# old object formula exceed that tier; the decimal ingress must now size six
# parser work objects directly from P.
cat > "$T/fp131073.wh" <<'WH'
program fpwide
input x: fp131073
let y: fp131073 = x
output y
WH
bin/wheelchairc "$T/fp131073.wh" -o "$T/fp131073" >/dev/null
"$T/fp131073" 1 > "$T/fp131073.out"
grep -q '^out00_rankn_fp=0x40020001:' "$T/fp131073.out"
[ "$(wc -c < "$T/fp131073.out")" -gt 32000 ]

# Existing mature WHEX Newton-Jv machine image stays byte-identical to the
# actual 1.3.54 release baseline despite General/Field storage aging.
bin/whexc devtrash/tests/whex/newton_jv_mature_regression.whex -o "$T/newton" >/dev/null
[ "$(sha256sum "$T/newton" | awk '{print $1}')" = 'bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac' ]

echo ARCHITECTURE_AGING_1_3_55=PASS
