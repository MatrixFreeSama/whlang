#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -x bin/topologyc ] || ./build.sh >/dev/null

# Field cardinality is instance data. Rank remains the current WHFLD216 format
# width; this gate deliberately does not advertise a new field-file format.
! grep -Rqs 'FIELD_RUNTIME_FIELD_CAP\|FIELD_RUNTIME_ACCESS_CAP' compiler runtime tools
! grep -RqsE '\bMAX_(FIELDS|SPECS|ACCESS)\b' compiler/field_frontend_common_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S
grep -q '^\.equ FIELD_RUNTIME_RANK_CAP,8$' compiler/field_runtime_capacity.inc
grep -q '^ff_prepare_instance_arena:' compiler/field_frontend_common_x86_64.S
grep -q '^field_prepare_instance_arenas:' runtime/field_runtime_512_x86_64.S
grep -q '^field_prepare_instance_arenas:' runtime/field_runtime_256_x86_64.S
grep -q '^field_metadata_va_patch:' runtime/field_runtime_512_x86_64.S
grep -q '^field_metadata_va_patch:' runtime/field_runtime_256_x86_64.S

# Tensor compiler workspaces are graph/code facts, not 4-MiB/512/2048
# acceptance tiers. All four physicalizers own the same grow/replay rule.
for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_derived_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  grep -q '^tensor_prepare_code_arenas:' "$f"
  grep -q '^tensor_prepare_optimizer_arena:' "$f"
  grep -q 'tensor_code_overflow' "$f"
  grep -q 'tensor_optimizer_capacity' "$f"
  ! grep -Eq 'EVAL_CAP|VEC_AOT_FACT_CAP|\.skip[[:space:]]+4194304|\.skip[[:space:]]+524288' "$f"
  ! grep -Eq '^vec_const_(bits|reg|addr):\.skip|^vec_linear_(binding|key_a|key_b|key_c|expr|coeff|mode):\.skip' "$f"
done

# Cross the retired 8-field / 128-access Field record with the existing rank-1
# semantics. Ten distinct files also exercise the runtime no-alias validation.
python3 - "$T" <<'PY'
import json,struct,sys
from pathlib import Path
D=Path(sys.argv[1])
fields=[{'mode':'input','type':'f32','rank':1} for _ in range(10)]
accesses=[{'field':i%10,'delta':[0]} for i in range(130)]
ops=[{'op':'load','access':129,'dst':0},{'op':'reduce','src':0}]
obj={'format':'wheelchair.field/1','contracts':{'floating_point':'strict'},
     'fields':fields,'accesses':accesses,'ops':ops}
(D/'field_wide.json').write_text(json.dumps(obj,separators=(',',':')))
for j in range(10):
    h=bytearray(256); h[:8]=b'WHFLD216'
    struct.pack_into('<IIIIQ',h,8,1,1,1,0,256)
    struct.pack_into('<8Q',h,32,4,0,0,0,0,0,0,0)
    struct.pack_into('<8Q',h,96,4,0,0,0,0,0,0,0)
    struct.pack_into('<Q',h,160,4)
    vals=[j+1,j+2,j+3,j+4]
    (D/f'f{j}.whfld').write_bytes(h+b''.join(struct.pack('<f',float(x)) for x in vals))
PY
bin/fieldc "$T/field_wide.json" -o "$T/field_wide" >/dev/null
field_args=(); for i in $(seq 0 9); do field_args+=("$T/f${i}.whfld"); done
[ "$("$T/field_wide" "${field_args[@]}")" = 'checksum_f32_bits=0x42380000' ]

# Cross the retired 512-constant Tensor optimizer pool. Keep the mature tensor
# schema/operations and only enlarge an existing strict map expression.
python3 - devtrash/tests/topology_cases/strict_fma_control.wh "$T/tensor600.json" <<'PY'
import json,sys
obj=json.load(open(sys.argv[1]))
leaves=[]
for i in range(1,601):
    axis={'op':'cast','to':'f64','args':[{'axis':'i'}]}
    leaves.append({'op':'mul','args':[axis,{'literal':i+0.125,'type':'f64'}]})
while len(leaves)>1:
    nxt=[]
    for j in range(0,len(leaves),2):
        nxt.append({'op':'add','args':[leaves[j],leaves[j+1]]} if j+1<len(leaves) else leaves[j])
    leaves=nxt
obj['bindings'][0]['expr']=leaves[0]
open(sys.argv[2],'w').write(json.dumps(obj,separators=(',',':')))
PY
bin/topologyc "$T/tensor600.json" -o "$T/tensor600" >/dev/null
[ "$("$T/tensor600" 4)" = 'checksum_bits=0x4140838c00000000' ]

# Static warehouse removal is visible in the production compilers themselves.
[ "$(size bin/fieldc | awk 'NR==2{print $3}')" -lt 1048576 ]
[ "$(size bin/topologyc-native256 | awk 'NR==2{print $3}')" -lt 1048576 ]

# Mature Newton-Jv must remain the exact historical machine image.
bin/whexc devtrash/tests/whex/newton_jv_mature_regression.whex -o "$T/newton" >/dev/null
[ "$(sha256sum "$T/newton" | awk '{print $1}')" = 'bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac' ]

echo ARCHITECTURE_AGING_1_3_56=PASS
