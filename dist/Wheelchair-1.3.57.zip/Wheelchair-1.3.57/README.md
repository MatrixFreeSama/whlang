# Wheelchair 1.3.57

## 1.3.57 ShapeFact-N

1.3.57 introduces a new sparse logical-shape authority without introducing a second Tensor runtime. `ShapeFact-N` stores axis identity and extent facts; rank, row-major stride relations and product cardinality are derived. The retired `rank_n_product` / `rank_n_source_rank` compatibility descriptor, product patch/offset and `__rankn_q` identity are deleted. Runtime extent names are ordinary data, so structurally identical shapes using `n` or `batch` compile to byte-identical executables.

Base and derived native512/native256 Tensor physicalizers consume the same ShapeFact authority. The current one-runtime-extent Tensor realization remains explicit as a consumer boundary while ShapeFact itself owns no such semantic limit and no fixed rank/extent capacity. Execution still collapses onto the existing single physical root `q`; no scheduler, nested-loop runtime, JIT, fallback backend or algorithm family is added.

The 1.3.57 release gate covers arbitrary runtime extent naming, base/derived 256/512 consumers, Rank-80, source-name erasure, current multi-runtime rejection, and all inherited gates. The mature Newton-Jv result remains exact; its generated RX segment shrinks from 1,737 B to 1,185 B (~31.8%). Same-host full-build median is about 1.8% slower, so no build-speed claim is made. See `SHAPEFACT_N_1_3_57.md`, `CORRECTNESS_1_3_57_SHAPEFACT_N.md`, and `PERFORMANCE_1_3_57.md`.

## 1.3.56 final compiler-workspace aging

1.3.56 removes the remaining safe-to-remove compiler capacity warehouses without adding source semantics. Field/access cardinality is now instance-sized through compiler metadata and both native runtimes, crossing the retired 8-field/128-access tiers. All four Tensor physicalizers use grow/replay code staging and graph-sized constant/affine optimizer metadata instead of fixed 4-MiB, 524288-fixup and 512/2048-fact tables. Rank-8 `WHFLD216`, Field four-VREG physicalization and Tensor one-runtime-extent semantics remain explicit because changing those would be a new representation/physicalizer rather than aging.

The release gate executes 10 fields with 130 access specifications and a strict Tensor graph carrying 600 distinct constants. Mature Newton-Jv remains byte-identical to the protected baseline. Static BSS falls by roughly 99% in the Field compilers and Tensor physicalizers; same-host full-build median is slightly slower (~5%), so no build/runtime speed claim is made. See `ARCHITECTURE_AGING_1_3_56.md`, `CORRECTNESS_1_3_56_ARCHITECTURE_AGING.md`, and `PERFORMANCE_1_3_56.md`.

## 1.3.55 runtime-record and AOT staging aging

1.3.55 adds no source-language feature, solver family, scheduler, ISA backend, or compatibility route. It continues the old-architecture convergence by removing fixed General program records and compiler-only code/graph staging ceilings where the existing AOT structure already owns the true size. General inputs, bindings, iterate states and outputs now live in one source-derived anonymous runtime arena; input/output type metadata and generated native code live in an exact-sized read-only trailer. The runtime template no longer reserves fixed 16-input, 240-binding, 64-state, 32-output records, a 256-MiB precision scratch slab, or a 512-KiB generated-code hole.

General code staging and Field code staging now use stable anonymous arenas with whole-pass retry/growth. Their initial source-derived estimate is only a first allocation, not an admission limit. Field compiler graph metadata likewise no longer carries the retired 8,192-op or 64-constant compiler tiers. The current Field physical ABI (8 fields, Rank 8, 128 accesses, four logical VREGs) is deliberately unchanged rather than hidden behind a permissive shell. Tensor multi-dynamic-axis semantics and the duplicated Tensor 4-MiB physicalizer staging remain explicit later debt.

The release gate executes 40 General inputs and 40 outputs, an 81-state iterate, and a General image containing 847,060 bytes of generated native code, crossing the retired 16/32/64/512-KiB tiers. It also compiles a 9,000-op Field graph containing 70 distinct constants, crossing the retired 8,192/64 compiler tiers. All inherited 1.3.54 semantic gates remain green.

The General target runtime template BSS falls from 403,316,736 B in 1.3.54 to 64 B in 1.3.55, while the template file falls from 557,816 B to 33,856 B. A representative generated General non-affine program falls from 557,816 B to about 38 KiB because it no longer carries the old fixed program hole and writable record. Mature WHEX Newton-Jv remains byte-identical to the actual 1.3.54 release baseline (`bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac`). No runtime-speed claim is made from small wall-clock differences.

See `ARCHITECTURE_AGING_1_3_55.md`, `CORRECTNESS_1_3_55_ARCHITECTURE_AGING.md`, and `PERFORMANCE_1_3_55.md`.


## 1.3.55 instance-structured runtime aging

1.3.55 adds no source semantics or execution family. General runtime storage is no longer a fixed 16-input/240-binding/64-state/32-output record: each AOT program measures its actual cardinalities and lays one instance-sized mutable arena. The historical 512-KiB General code slot is replaced by an exact mapped type/code trailer, and Rank-N decimal ingress no longer owns 8-MiB input or 1-MiB object strides; fpP work objects are derived from P itself. Field compiler graph/code staging likewise no longer inherits the retired 8192-op, 64-constant or 1-MiB compiler-only tiers.

Release probes execute 40 General inputs/outputs, 81 iterate states, more than 512 KiB of generated General code, a 9000-op Field graph and fp131073 decimal ingress. The mature Newton-Jv generated executable is byte-identical to 1.3.54. See `ARCHITECTURE_AGING_1_3_55.md`, `CORRECTNESS_1_3_55_ARCHITECTURE_AGING.md`, and `PERFORMANCE_1_3_55.md`.


## 1.3.54 large architecture aging

1.3.54 adds no new source semantics or execution family. It removes fixed implementation capacity where the existing structure already owns the true size. Human-Surface AST nodes now grow in non-moving slabs, serialization streams use growable arenas, Field human-shell scalar/reduction metadata and op serialization no longer carry their former 32/8/4-MiB parser ceilings, General binding mailboxes are sized from the actual AOT binding graph rather than a 240-slot ABI table, and advanced Matrix decomposition worksets are derived from matrix dimension instead of the historical `n^2 <= 16` scratch tier.

The release gate executes 300 WH bindings, compiles a Field human source with 40 scalar extent declarations, and executes 5x5 Cholesky. Real lower boundaries are preserved: General input/state/output records, Field runtime field/rank/access/VREG limits, Tensor dynamic-extent semantics and AOT code-image slots are not falsely advertised as generalized.

The physical footprint changes sharply: `wheelchairc` BSS drops from 124,802,112 B in 1.3.53 to 21,520 B in 1.3.54. `topologyc` BSS falls from 134,356,800 B to 9,576,208 B. Mature Newton-Jv generation is byte-identical across 1.3.53 and 1.3.54, so this release makes no runtime-speed claim for that probe.

See `ARCHITECTURE_AGING_1_3_54.md`, `CORRECTNESS_1_3_54_ARCHITECTURE_AGING.md`, and `PERFORMANCE_1_3_54.md`.


## 1.3.53 optional-iteration convergence

1.3.53 does not add a second mathematics runtime, solver family, precision-specific implementation, scheduler, or ISA route. Existing advanced mathematical semantics keep their old AOT relations, but iteration/refinement depth is no longer a hidden semantic ceiling. Omitting the final count preserves the historical default; supplying it makes that count an AOT-static user fact, using the same contract already established by `root(...[,iterations])`.

The common Semantic Registry now owns optional iteration arity for Lambert W, inverse erf, digamma/trigamma recurrence shift, zeta cutoff, polylog series depth, complete elliptic AGM refinement, matrix exp/log/sqrt, eigensystem and SVD projections. `integral(x,a,b,expr[,panels])` retains the same GL8 rule; an explicit count repeats that one old panel relation over equal subintervals rather than selecting another integrator. `root` and integral defaults are centralized beside the same fallback policy constants.

Default source remains structurally stable: representative omitted-default programs compiled by 1.3.52 and 1.3.53 produce byte-identical ELF files, and within 1.3.53 each omitted form is byte-identical to the same call with its historical default written explicitly. Runtime-variable iteration selectors remain rejected, so no runtime algorithm-control object is introduced.

See `ITERATION_CONTROL_CONVERGENCE_1_3_53.md` and `CORRECTNESS_1_3_53_OPTIONAL_ITERATION.md`.

## 1.3.52 architecture aging and historical-identity convergence

1.3.52 adds no source semantics, algorithm family, scheduler, compatibility route, or ISA backend. It removes historical release identity from the production architecture and makes the current implementation describe only present responsibilities. The active Tensor/Physical-Reality sources no longer carry `138`, `136`, `137`, `149`, `1348`, or similar revision identities in production filenames, symbols, or local labels. Physical Reality now has one current source authority: `compiler/physical_reality.inc`.

Dead production aliases and unreachable duplicate authorities are removed. `topologyc-wide` and `topologyc-wide-native256` were byte-copy aliases that the current driver no longer selected; they are deleted rather than preserved as compatibility names. The stale JSON parser, stale physical-vector-shape include, and obsolete native256 relink helper are removed after production-reachability analysis. Canonical compiler outputs remain `topologyc`, `topologyc-derived`, `topologyc-native256`, `topologyc-derived-native256`, `fieldc`, `fieldc-native256`, `wheelchairc`, and `whexc`.

The normal production build is aged from 1,219 lines to 199 lines by removing historical release-banner replay from the build path. Historical invariant tests remain in `devtrash/release_tests`; production build now builds the current architecture and checks current invariants only. On the release host, seven new full-build samples have a median of 0.804347 s versus 1.006139 s for five 1.3.51 samples: 1.2509x build throughput, or 20.06% less wall time.

This release deliberately does not claim runtime acceleration. The mature Newton-Jv probe generated by 1.3.51 and 1.3.52 is byte-for-byte identical with SHA-256 `bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac`; therefore the structural runtime speed change for that probe is 0%. A small wall-clock difference between identical binaries is measurement noise, not a compiler speedup claim.

See `ARCHITECTURE_AGING_1_3_52.md`, `CORRECTNESS_1_3_52_ARCHITECTURE_AGING.md`, and `PERFORMANCE_1_3_52.md`.

## 1.3.51 structural capacity convergence

1.3.51 is a large aging/convergence release with no new source semantics, algorithm families, schedulers, compatibility routes, or ISA backends. Fixed implementation cardinalities are removed where the existing structure already provides the true size: production source files are mapped from measured length, JSON nodes and Tensor binding metadata own structure-sized arenas, and General symbols/dependency relations no longer inherit fixed parser/bitmap tables.

The General parallel executor no longer embeds 256-node/1,024-edge graph storage. A small fixed executor template is followed by compact metadata derived from the actual `N` regions and `E` causal edges; state pages and node stacks are mapped from the actual node count. Dependency edges remain the same causal relation, only their storage authority changes.

Real lower boundaries are preserved rather than hidden. General runtime inputs/binding mailboxes/iterate states/outputs now share one ABI capacity authority, and Field Surface/frontend/native256/native512 share one Field ABI capacity authority. Tensor dynamic-extent semantics, Field VREG/type/rank execution limits, mathematical admissibility rules, architectural register limits, and final AOT image/workspace capacities are unchanged.

The release gate executes a General graph above the old 256-node tier, a 1,120-edge graph, a canonical source above the old 65,536-node JSON table, and a valid source above the old 8 MiB launcher ceiling, in addition to all inherited 1.3.50 gates.

See `STRUCTURAL_CAPACITY_CONVERGENCE_1_3_51.md` and `CORRECTNESS_1_3_51_STRUCTURAL_CAPACITY.md`.


## 1.3.50 human-surface convergence

1.3.50 removes independent human-shell ceilings that had survived after the underlying structural authorities had already generalized. Rank metadata is no longer stored as a declaration-by-Rank-16 rectangle; WH `for` and WHEX `each` accept arbitrary positive static radices; compile-time pure functions own flat lexical parameter facts and hygienic simultaneous substitution rather than a one-parameter tier; record, dictionary, nested and cascade structures no longer inherit small syntax-family tables.

Cascade dependencies are now an explicit compile-time relation edge set instead of a machine-word prerequisite mask. The historical `work <= 1,048,576` Surface rejection is removed. These changes erase before canonical emission. They do not add a runtime scheduler, fallback backend, workload selector, compatibility parser, or new execution authority.

Real lower-layer boundaries remain real. In particular the current General runtime state ABI still owns 64 iterate states, the General frontend still owns 240 runtime bindings, the current Tensor authority still has its existing dynamic-extent representation, and advanced matrix decompositions retain their current workset limits. 1.3.50 deliberately does not hide those limits behind a permissive shell.

The release gate crosses the retired Surface boundaries with Rank 80, an 80-parameter pure function, 20 pure declarations, 80 record fields, 140 dictionary entries, 40 nested facts, a 70-goal/69-edge cascade, and cascade work of 1,048,577. A lexical-capture probe verifies simultaneous pure substitution.

See `HUMAN_SURFACE_CONVERGENCE_1_3_50.md` and `CORRECTNESS_1_3_50_HUMAN_SURFACE_CONVERGENCE.md`.

## 1.3.49 unified sparse physical materialization

1.3.49 ages physical materialization into one architecture-neutral authority instead of adding another AVX2, AVX-512, base, wide, sparse, or benchmark route. The complete Physical DAG remains the logical authority, while a ValueFact becomes physically resident only when its consumer frontier and target capabilities justify that state. Long-lived and generation-scoped facts occupy disjoint lifetime domains derived by the AOT pass from the current DAG.

The common Field lowerer now gives native256 and native512 the same consumer-local materialization policy. Both widths may consume a stack-backed immutable ValueFact directly as an existing arithmetic memory operand and both widths may reuse the already-live regular-store mask/index state. VEX versus EVEX encoding, architectural register count, lane count, and predicate form remain physical capabilities rather than optimization-policy branches.

The primary native512 Tensor physicalizer no longer owns separate base and wide resource profiles. The old driver thresholds based on structural-load count are removed. Pass 0 measures generation-scoped transient high-register demand, long-lived AffineFact and ConstantFact candidates compete by AOT rematerialization value, and pass 1 partitions the one real high-ZMM bank into disjoint lifetime domains. Compatibility compiler names remain aliases of the same implementation. Native256 likewise has one real topology compiler and no fictional high-register bank.

This is sparse physical materialization rather than a runtime overload controller. There is no ready queue, work stealing, central scheduler, runtime register manager, or workload identity. Existing outward execution materialization remains governed by its older physical-cost authority.

On the release host, a diagnostic 64^3 strict Hex8 run using the same input files measured the new native512 code in the same performance class with a lower median than the frozen 1.3.48 native512 sample, while the native256 generated ELF was byte-identical across the two releases. These are host-specific diagnostics, not universal speed claims. The strict Field release oracle requires byte-identical native256/native512 outputs and preserves the same arithmetic operation count with no FMA contraction.

See `SPARSE_PHYSICAL_MATERIALIZATION_1_3_49.md` and `CORRECTNESS_1_3_49_SPARSE_PHYSICAL_MATERIALIZATION.md`.

## 1.3.48 native256 ValueFact lifetime convergence

1.3.48 continues aging the existing AVX2/native256 Field physicalizer rather
than adding an AVX2 fast path. Immutable LoadFacts and ConstantFacts share the
one real YMM ownership economy established in 1.3.47. A single compile-time
liveness proof now drives both resident demand and final emission: when an
immutable producer is consumed immediately as the second operand of a strict
`mul` and that version has no later observer, the producer transport disappears
and the existing `VMULPS` consumes the resident or stack-backed ValueFact
directly. No arithmetic operation is deleted or reassociated.

Contiguous output stores also consume the already-materialized episode mask/q
Physical Fact instead of calling the older store helper to rebuild the same
state and then reload residents. Runtime non-contiguous and non-temporal-policy
paths retain the mature helper authority. Native512 physicalization is unchanged
byte-for-byte on the release Hex8 graph.

On the release host, 61 alternating single-CPU whole-process runs of the strict
64^3 Hex8 validation graph measured 41.642 ms median for the 1.3.47 native256
binary and 40.154 ms for 1.3.48, a 1.037x speedup. The generated AVX2 graph
keeps 2304 `vmulps` and 1156 `vaddps`; explicit vector stack loads fall from
3207 to 1555 while 1153 strict multiplies consume a stack-backed ValueFact as
the existing memory operand. The three output fields remain byte-identical.

The next known debt is not another AVX2 branch: long strict recurrences still
reuse one logical carrier and therefore expose physical anti-dependencies. That
belongs to future versioned-carrier aging, not to this release. See
`VALUEFACT_LIFETIME_1_3_48.md` and
`CORRECTNESS_1_3_48_VALUEFACT_LIFETIME.md`.


## 1.3.47 native256 physical ownership aging

1.3.47 strengthens the existing AVX2/native256 backend without adding a new
algorithm family or workload route.  Native256 now describes one real YMM0..15
physical bank and gives Field ValueFacts, tail mask, strict reduction,
procedural indices and helper scratch disjoint roles inside that bank.  The
former v3/YMM4 tail-mask alias is closed by the common Field lowerer through a
compile-time native256 physical profile.

Tensor/native256 also drops the copied mutable high-register cache/constant
ownership state that could never be physical on AVX2.  Its existing direct
load/RIP-pool path remains authoritative.  Native512 physicalization is
unchanged.  See `AVX2_PHYSICAL_OWNERSHIP_1_3_47.md` and
`CORRECTNESS_1_3_47_AVX2_PHYSICAL_OWNERSHIP.md`.

## 1.3.46 human-shell static select erasure

1.3.46 changes only the WH human shell.  When contraction-axis substitution
makes a `select` predicate static, the surface chooses the live source branch
before cloning its data subtree.  This allows the existing `matrix`/`mget`,
`contract`, affine field-neighborhood and `select` semantics to compose in the
compact Hex8 form without growing dead compile-time AST.

No runtime/backend authority or field opcode is added.  The release gate runs
a compact static-select contraction and its strict hand-expanded source on the
same native field input and requires byte-identical outputs.


## 1.3.45 human-shell static structure bridge

1.3.45 changes only the WH field human shell. Existing `matrix`, `mget`, selected-axis `contract`, and neighborhood addressing can now compose directly in compact WH source and erase to the same canonical field graph as hand expansion. No runtime/backend authority is added.

The release gate requires byte-identical ELF output for compact vs hand-expanded probes.


Wheelchair is a handwritten-assembly, AOT, HPC-first general language organized around ValueFacts, Rank-N structural relations and a Physical DAG rather than a mandatory sequential instruction stream.

## 1.3.44 mathematics generalization

This release ages two formerly young regions without adding named-size or named-precision algorithm families. Square matrices now belong to one dimension-bearing Structured Matrix family; `matrix2/3/4` remain source aliases, while `matrix(n, ...)` can cross the historical sixteen-component boundary for generalized base algebra. Structured materialization/select/differentiation scratch is derived from actual component count. The one matrix inverse relation now includes dataflow partial pivoting. Advanced decompositions whose old workset is not yet generalized reject oversized facts safely rather than growing matrix5/matrix6 implementations.

The parameterized `fpP` algebra now natively supplies `sqrt`, `exp`, `log`, `sin`, and `cos` for `P > 64`. These relations absorb only the local-propagation idea: current scale determines local contraction and the current representation determines termination. No NRII solver or runtime is imported. Representative fp65/fp127/fp521 oracle anchors are within four significand ULPs on the release points; this is not a universal correct-rounding claim, and extreme trigonometric argument reduction remains a future maturity target.

A matched three-language diagnostic benchmark is recorded in `PERFORMANCE_1_3_44_C_FORTRAN.md`. On the release machine, the three-kernel geometric mean was 1.097813x C time for Wheelchair and 0.978267x C time for GFortran, with bit-identical final checksums. The result is retained without benchmark-specific routing.

## Parameterized floating precision

Native `f32` and `f64` keep direct CPU paths. Any finite floating precision wider than 64 bits is one generic semantic:

```text
fpP
```

where `P > 64` is the significand precision in bits. Precision is data. There are no dedicated 128-, 256-, 512- or 2048-bit implementations.

The existing precision meet remains upstream of physicalization:

```text
operands
  -> precision_propagation meet
  -> <=64: native scalar/SIMD
  -> >64: Rank-N precision ValueFact
  -> physicalization
```

`precision_propagation 0` selects lower precision and `precision_propagation 1` selects higher precision only at the real consumer edge. A child subtree keeps its natural precision until that edge.

## 1.3.43 root precision assimilation

RootRelation now consumes the same parameterized precision facts as ordinary arithmetic. There is no `root_fp128`, `root_fp256`, or wide-root fallback. A root expression remains in its current representation, including any `fpP` with `P > 64`.

The old f64-only acceptance constants have been removed. Root validity now uses Newton correction visibility in the current representation, and real projection uses the same representation-stability fact for the imaginary component. Precision-neutral zero/one identities inherit the consumer representation.

P>64 comparisons are now one shared numeric authority over sign, exponent, and significand, so RootRelation and every other general expression compare fpP values rather than carrier addresses. The native Fourier multiplication path also fixes the AOT packed-geometry boundary so the 32-bit `n64` fact cannot absorb the adjacent geometry word during final cross-limb digit extraction. This is one width-correct physical boundary, not a named-precision exception.

Release validation includes exact-oracle roots at fp65, fp127 and fp521 plus dense division-produced significand multiplication at fp127/fp191. See `devtrash/release_history/1.3.43/ROOT_PRECISION_FUSION_1_3_43.md`.

## 1.3.42 sparse root relation

`root` is now one compile-time relation rather than a scalar-only Newton spelling. The result is discovered on-site as sparse `valid`, `real`, and `imag` facts. No caller declares whether the answer is real, complex, or empty.

```text
root(x, expression, guess)
root(x, expression, guess, static_iterations)
```

Omitting the fourth argument means five AOT Newton generations. A scalar seed is lifted into the existing complex Structured Fact search space without creating a second complex-root solver. Symbolic differentiation is shared componentwise, zero derivatives are protected with dataflow select facts, and every generation checkpoints into the old scalar ValueFact authority. A real answer is simply a converged complex fact whose imaginary carrier collapses when it is no longer distinguishable in the current representation. If the AOT budget produces no acceptable candidate, `root_valid` is false and the numerical carriers project to zero. This is an unresolved/empty computation result, not a theorem that the mathematical relation has no root.

Existing complex `exp`, `sin`, and `cos` were also sparsified by checkpointing their scalar semantic components once, so RootRelation can parasitize them without regrowing dense transcendental trees. See `devtrash/release_history/ROOT_RELATION_1_3_42.md`.

## 1.3.41 sparse native mathematics fusion

1.3.41 does not add a second mathematics runtime or an algorithm selector. It folds overlapping old algorithms into shared compile-time facts and lets existing semantics project the result:

```text
old mathematical identity
  -> one shared semantic kernel
  -> sparse ValueFact projection
  -> existing Physical DAG
```

The release unifies the Euler/Lambert exponential seed for `exp`/`expm1`, a compensated `log1p` fact reused by inverse hyperbolic identities, the Abramowitz-Stegun complement tail for `erf`/`erfc`, one Lanczos core for the Gamma family, and one scale-safe Euclidean norm for scalar `hypot` and complex magnitude. Removable singularities such as `sinc(0)` are represented with existing select ValueFacts rather than a runtime control-flow branch.

The rule is intersection rather than addition: if A and B share a mathematical core, the core becomes the authority and A/B become projections. Existing bit-level release results are kept where they are already contractual, including `exp(1)`, `gamma(5)` and `factorial(5)`.

See `devtrash/release_history/MATHEMATICS_FUSION_1_3_41.md` for the identities and source map.

## 1.3.40 native Fourier assimilation

For `P > 64`, multiplication now has one production physical authority. The former singleton row-carry implementation, AVX-512 IFMA batch implementation and multiplication selector were deleted rather than retained as compatibility paths.

The common multiplication identity is:

```text
z = a + i*b
ab = Im( F^-1( F(z)^2 ) ) / 2
```

The local engine uses mixed-radix DIF forward stages and the reverse DIT inverse stages. Frequency order never has to be globally permuted before the pointwise square.

AOT derives one packed geometry fact from P:

```text
(b, a2, a3, a5)
N = 2^a2 * 3^a3 * 5^a5
```

subject to the native numerical safety condition

```text
ceil(P/b) * (2^b - 1)^2 * ceil(log2(N)) < 2^51
```

and one continuous physical cost surface. There is no named-precision threshold tree and no multiplication-algorithm enum. Generated programs carry the selected geometry in the existing Rank-N physical object header. Runtime geometry derivation exists only for ingress paths that do not have an AOT fact.

The transform implementation is local x86-64 assembly. FFTW, GMP, libm, JITs and external numerical runtimes are not production dependencies. GMP is used only in `devtrash/` release oracles and benchmarks.

Division remains the common base-2^32 Knuth digit implementation introduced before this release.

## Performance status

On the release machine, the fully local production multiplication path is within roughly ±20% of GMP `mpf_mul` from 262144 through 4194304 bits in the measured run, with several points faster. Smaller wide precisions retain the fixed cost of the single Fourier authority; this release deliberately does not add a small-P algorithm branch to hide that cost. See `devtrash/release_history/PERFORMANCE_1_3_40_NATIVE_FOURIER.md` and the raw CSV under `devtrash/benchmarks/native_fourier_1340/`.

## Architecture priority

1. Parasite the old architecture first.
2. Strengthen the old architecture second.
3. Create a new authority only when the old substrate cannot express the requirement.
4. Any unavoidable new authority must be high-affinity, high-extensibility and assimilatable into the common substrate.
5. Local performance irregularities are acceptable; architecture may not regrow a threshold-driven algorithm tree to erase them.

## Build

```sh
./build.sh
```

Production executables are emitted under `bin/`. Release validation lives under `devtrash/release_tests/`.
