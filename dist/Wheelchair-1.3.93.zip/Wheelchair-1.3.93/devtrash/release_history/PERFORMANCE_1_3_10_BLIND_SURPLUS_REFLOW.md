# Wheelchair 1.3.10 Performance: Blind Surplus Reflow

## Purpose

This report distinguishes elapsed time from total active CPU time. Wheelchair 1.3.10 does not treat high CPU occupancy as a success metric.

## Host

- Intel Xeon Platinum 8573C
- 5 visible vCPUs
- cgroup sustained CPU quota: 4 CPUs
- Linux process CPU accounting through `wait4`
- N = 100,000,000
- 15 interleaved measured runs per point
- same FSI diagnostic source

PMU retired-instruction and power counters are not available in this environment, so no transistor-level Active-Silicon Purity percentage is claimed.

## Results

| Contract | q | Version | Wall ms | CPU ms | Core-equivalent | Requested occupancy |
|---|---:|---|---:|---:|---:|---:|
| tolerant | 1 | 1.3.8 | 162.945 | 161.818 | 0.992 | 99.2% |
| tolerant | 1 | 1.3.10 | 161.662 | 160.132 | 0.992 | 99.2% |
| tolerant | 2 | 1.3.8 | 163.058 | 320.053 | 1.968 | 98.4% |
| tolerant | 2 | 1.3.10 | 164.698 | 269.260 | 1.640 | 82.0% |
| tolerant | 4 | 1.3.8 | 83.526 | 318.845 | 3.810 | 95.3% |
| tolerant | 4 | 1.3.10 | 85.106 | 270.973 | 3.182 | 79.6% |
| strict | 1 | 1.3.8 | 238.882 | 237.977 | 0.995 | 99.5% |
| strict | 1 | 1.3.10 | 239.859 | 238.578 | 0.995 | 99.5% |
| strict | 2 | 1.3.8 | 244.974 | 400.438 | 1.651 | 82.5% |
| strict | 2 | 1.3.10 | 246.708 | 404.288 | 1.651 | 82.5% |
| strict | 4 | 1.3.8 | 163.809 | 477.018 | 2.913 | 72.8% |
| strict | 4 | 1.3.10 | 124.686 | 402.070 | 3.220 | 80.5% |

## Interpretation

### Tolerant q2/q4

1.3.10 deliberately stops treating the capacity ceiling as a demand to keep all capacity active. Requested occupancy falls from roughly 98/95% to 82/80%, while CPU active time falls about 16/15%. Elapsed time remains within roughly 1 to 2% of 1.3.8.

This is not a regression in the 1.3.10 doctrine. It is evidence that the old execution fabric spent substantial CPU time maintaining concurrency that was not required for comparable elapsed time.

### Strict q4

1.3.8 exposed only about 2.91 effective cores under its exact canonical tree. 1.3.10 allows later causal expansion points to blindly claim capacity released elsewhere. The result rises to about 3.22 effective cores, but total CPU active time still falls about 15.7%, while wall time falls about 23.9%.

This demonstrates that Blind Surplus Reflow is not an anti-parallel policy. It can increase active width when real independent causal work exists and anonymous capacity becomes available.

## Arithmetic payload identity

The FSI generated arithmetic payload is byte-identical between 1.3.8 and 1.3.10:

- tolerant: `2b14f374f7adb2935e18485e5de5f5d0908dc6d708489ba666b3b4bd029aeda4`
- strict: `163f7f4b32907586c7b4dec540953f004ea208c7b5b19fdf1e96aa7ec2849648`

Therefore these measurements isolate execution-fabric changes from arithmetic-kernel changes for this diagnostic.

## Claim boundary

This report measures process CPU time, not individual transistor activity. It supports the Active-Silicon Purity direction but does not claim a literal 95% or 100% useful-transistor ratio.
