# Architecture aging 1.3.88

1.3.87 made silicon-domain placement executable, but the General causal graph still represented a cross-Region relation only as `(u,v)`, and runtime completion was implicitly defined by an x86 function return. Both assumptions block clean heterogeneous realization.

1.3.88 ages those assumptions into existing Physical Reality.

## Physical Edge Fact

The causal relation remains one graph. Each original edge now additionally carries a represented payload lower bound. Region contraction aggregates these facts without creating a target graph.

```text
semantic ValueFact relation
        -> causal edge
        -> Physical Edge transfer fact
        -> Region edge aggregation
```

The transfer fact is a lower bound, not an execution-count guess. Unsupported payload identity becomes unknown.

## Shared completion

Execution and completion are separate physical events.

```text
x86 Region return ---------+
                           +-> gr_publish_completion -> successor readiness
fabric completion bridge --+
```

The x86 path tail-publishes so the abstraction does not add a native call/return pair.

## Heterogeneous realization

A Region realization tag is now part of compact physical metadata. The current x86 target proves only tag `1`. Tag `2` is reserved for reconfigurable fabric and cannot appear until target facts prove a legal fabric realization.

This is intentionally not a backend selector. The semantic DAG is unchanged regardless of tags.
