# Heterogeneous fabric closure 1.3.88

## Objective

Allow x86 and reconfigurable fabric to participate simultaneously in one Physical DAG realization without turning Wheelchair into an FPGA DSL or a CPU-to-accelerator offload runtime.

## Current physical interface

General compact metadata now contains:

```text
edge_transfer_bytes[E]
realization_tag[N]
```

`edge_transfer_bytes` is available to future AOT cross-domain placement. `realization_tag` is target realization only and has no source syntax.

Defined realization tags:

```text
1 = x86 ISA realization
2 = reconfigurable fabric realization
```

Normal 1.3.88 compilation emits only tag `1` because no fabric target facts are proved in the current production probe.

## Completion bridge

`gr_publish_completion` is exported from the General release fabric and its offset is derived into `build/general_parallel_release_offsets.inc` and `.json`.

A future fabric activation thunk must not own readiness or successors. It may only:

```text
activate a proved fabric Region
wait or receive a physical completion event
enter gr_publish_completion(region)
```

The existing causal graph remains authoritative.

## Required next target facts

The next physical layer needs target facts for exposed fabric resources, such as logic, registers, arithmetic blocks, local storage, clock regions, routing domains, I/O, and CPU-fabric transport. Device names are diagnostic only; they must not choose algorithms.

Until those facts exist, fabric realization remains unmaterialized.
