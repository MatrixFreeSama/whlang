# Pure assembly release proof 1.3.88

Production Wheelchair remains a native static assembly build.

- production compiler/runtime sources are assembled with the system assembler;
- production linkage is static and has no dynamic section;
- production `build.sh` invokes no Python;
- Python remains confined to tests/reference analysis;
- heterogeneous Physical Edge facts are implemented in `compiler/general_frontend_x86_64.S`;
- shared causal completion is implemented in `runtime/general_parallel_release_x86_64.S`;
- release offsets are derived by shell/binutils tooling without Python;
- no C, LLVM, HLS compiler, FPGA vendor tool, or JIT is part of the production build.

The absence of FPGA vendor tooling is also why 1.3.88 makes no bitstream or place-and-route claim.
