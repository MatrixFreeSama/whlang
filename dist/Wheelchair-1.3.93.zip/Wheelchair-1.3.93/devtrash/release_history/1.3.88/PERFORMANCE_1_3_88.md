# Performance 1.3.88

## Measurement boundary

The release host has no proved reconfigurable-fabric physical domain. FPGA acceleration therefore cannot be measured and is not estimated.

The performance check measures whether the new heterogeneous substrate taxes the mature x86 path.

## Generated-program execution

Frozen 1.3.87 and current 1.3.88 compiled `mass3`, `chem6`, and `rigid7`. Each executable was run for 30 interleaved repetitions at 20,000,000 steps pinned to CPU 0.

| probe | 1.3.87 median | 1.3.88 median | 1.3.87 / 1.3.88 |
| --- | ---: | ---: | ---: |
| mass3 | 0.152780015 s | 0.151958954 s | 1.00540x |
| chem6 | 0.140784576 s | 0.141437276 s | 0.99539x |
| rigid7 | 0.242445459 s | 0.242012672 s | 1.00179x |
| geometric mean | | | **1.00085x** |

The geometric mean corresponds to about `+0.085%` and is treated as measurement noise. No x86 speedup is claimed.

The three generated executables are 80 bytes larger than 1.3.87. The added bytes carry the generalized completion path and heterogeneous physical metadata; the mature numerical loops are not deliberately rewritten by this release.

## Compiler cost

Thirty interleaved compile repetitions per probe give a geometric-mean 1.3.87/1.3.88 compile-time ratio of about `0.96305x`, or approximately `+3.7%` compile time for 1.3.88.

The absolute median increase is small because these compiles take roughly 1-2 ms:

- `mass3`: about +0.042 ms
- `chem6`: about +0.093 ms
- `rigid7`: about +0.055 ms

The additional work is the compile-time Physical Edge transfer proof and metadata construction. It is not runtime scheduling work.

Raw data is under `devtrash/benchmarks/heterogeneous_physical_edge_1388/`.
