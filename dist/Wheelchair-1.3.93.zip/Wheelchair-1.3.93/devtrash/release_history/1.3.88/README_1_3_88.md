# Wheelchair 1.3.88

![Build](https://img.shields.io/badge/build-19%2F19%20PASS-brightgreen) ![Release](https://img.shields.io/badge/release-1.3.88-blue)

Wheelchair is an HPC- and simulation-first general-purpose AOT language built around Rank-N semantics, matrix-free execution, ValueFacts, StateFacts, AddressFacts, RegionFacts, CoordinateFacts, GroupFact, Physical Reality, Traffic Reality, and Physical DAG execution.

The target is not hardware occupancy. It is convergence of real physical work toward the work required by mathematical structure and the exposed target:

```text
physical work / mathematical-physical lower bound -> 1
```

Idle silicon is valid when additional materialization costs more than the remaining necessary work.

## 1.3.88: heterogeneous Physical Edge closure

1.3.87 burned exact CPU locality placement into generated programs. 1.3.88 removes the next barrier to simultaneous x86 + reconfigurable-fabric realization: a cross-Region dependency is now a Physical Edge Fact rather than only graph connectivity.

```text
one Physical DAG
      |
      +-- Region facts
      +-- Physical Edge transfer facts
      +-- one causal completion law
      |
      +--> x86 physical domain
      +--> reconfigurable-fabric physical domain
```

The two target classes are not an exclusive choice. A future proved fabric target may realize some Regions while x86 realizes others. There is no source-visible FPGA annotation, hardware kernel language, HLS route, worker/task graph, runtime device selector, fixed PE count, fixed tile size, or target-private semantic IR.

General Region edges now carry a represented transfer lower bound derived from the actual ValueFact type. The compact generated image contains:

```text
indegree[N]
first_out[N]
entry_offsets[N]
work_ticks[N]
edge_v[E]
next_edge[E]
edge_transfer_bytes[E]
realization_tag[N]
```

Unknown transfer size is represented as unknown, never zero. Unproved fabric is never materialized.

## Shared completion

x86 return is no longer the universal definition of causal completion. The General runtime now has one `gr_publish_completion` authority. Native x86 Regions tail-publish into it immediately after returning. A later asynchronous fabric bridge can enter the same completion law after the fabric proves its Region complete.

This preserves one successor graph and one readiness law across heterogeneous silicon.

## Silicon contract

```sh
bin/topologyc --silicon-contract
bin/topologyc --silicon-audit
```

The current contract is `wheelchair.silicon-reality/5`. It publishes:

```text
simultaneous_heterogeneous_realization = true
physical_edge_facts = true
shared_causal_completion_law = true
x86_fpga_exclusive_target_selection = false
fpga_offload_kernel_model = false
runtime_device_selector = false
fabric_target_facts_present = false
fpga_bitstream_emitter_present = false
```

The final two fields are deliberately false on this release host. 1.3.88 establishes the coordination substrate; it does not fabricate an FPGA device, RTL backend, place-and-route result, or bitstream.

## Performance

The release host exposes no proved FPGA physical domain, so no FPGA acceleration number exists yet.

For x86 semantic-zero-flip validation, `mass3`, `chem6`, and `rigid7` were measured for 30 interleaved 20,000,000-step whole-episode repetitions against frozen 1.3.87. The geometric-mean runtime ratio is approximately `1.00085x`, about `+0.085%`, which is measurement noise. No x86 speedup is claimed.

Generated images are 80 bytes larger for these one-Region probes because the shared completion entry and heterogeneous metadata are now present. Compiler time increases by about 3.7% relatively on these tiny 1-2 ms compiles, approximately 0.04-0.09 ms in absolute terms.

See `PERFORMANCE_1_3_88.md`.

## Build and run

```sh
./build.sh

bin/whexc INPUT.whex -o OUTPUT
bin/wheelchairc INPUT.wh -o OUTPUT
bin/topologyc INPUT.whex -o OUTPUT
bin/fieldc INPUT.json -o OUTPUT
```

## Release authority

The current release gate contains 19 tests. Production authority remains under `compiler/`, `runtime/`, `surface/`, `tools/`, `build.sh`, and generated `bin/` executables. `devtrash/` contains regression, benchmark, historical, and archaeological material only.

See `ARCHITECTURE_AGING_1_3_88.md`, `HETEROGENEOUS_FABRIC_1_3_88.md`, `PERFORMANCE_1_3_88.md`, `TESTING_1_3_88.md`, and `WHEELCHAIR_CHARTER_1_3_88.md`.
