# Wheelchair charter 1.3.88

1. Mathematical structure is semantic authority.
2. Physical DAG is the single execution-structure authority.
3. Causal depth owns realization time.
4. Traffic and Physical Edge facts own spatial coupling and cross-domain transfer cost.
5. Fact lifetime owns storage residency.
6. GroupFact owns multiplicity subject to exposed physical carriers.
7. x86 and reconfigurable fabric may coexist in one realization.
8. No target may create a second semantic graph.
9. No source kernel, worker, task, PE count, tile size, or hardware pragma is required or authoritative.
10. Runtime may not choose devices from idle-resource observations.
11. Unproved physical resources remain unavailable rather than guessed.
12. Every physical domain publishes completion through the same causal law.
13. FPGA/ASIC implementation claims require real target facts and real implementation evidence.
14. The objective remains convergence toward necessary mathematical-physical work, not occupancy.
