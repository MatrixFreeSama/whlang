# Testing 1.3.88

The current release gate contains 19 tests.

The new heterogeneous closure test proves:

- simultaneous heterogeneous realization is an architecture law;
- exclusive x86/FPGA target selection is not an authority;
- Physical Edge transfer facts are present;
- `gr_publish_completion` is exported and has a derived template offset;
- the silicon contract is `wheelchair.silicon-reality/5`;
- a real multi-Region General image contains nonzero burned edge-transfer facts;
- unproved fabric remains absent from Region tags;
- the existing branch probe remains bit-exact;
- no source FPGA annotation, hardware-kernel route, or runtime device scheduler is introduced.

All earlier mathematical, CoordinateFact, mutable-StateFact, silicon-domain identity, and static-placement gates remain active.
