# Wheelchair 1.3.88 release notes

1.3.88 adds heterogeneous Physical Edge closure without introducing a second execution model.

## Changes

- General causal edges now own a qword `edge_transfer_bytes` lower-bound fact.
- Repeated semantic references accumulate on the same deduplicated edge.
- Unknown below-surface reuse saturates transfer size to unknown instead of pretending the cost is zero.
- Condensed Region edges preserve and aggregate the original Physical Edge transfer facts.
- Generated General images carry `edge_transfer_bytes[E]` and `realization_tag[N]` in compact metadata.
- Current x86 compilation burns realization tag `1`; fabric tag `2` is reserved for proved target closure only.
- `gr_publish_completion` is now the single General causal-completion authority.
- x86 Regions tail-publish completion, avoiding an extra call/return tax.
- `gr_publish_completion` has a derived template offset for future fabric completion bridges.
- Silicon contract advances to `wheelchair.silicon-reality/5`.

## Deleted assumptions

- x86 and FPGA are not mutually exclusive target choices.
- FPGA is not a kernel/offload sublanguage.
- runtime device selection is not admitted.
- unproved fabric cannot receive a Region.
- cross-domain transfer is not assumed free.

## Hardware boundary

No RTL, place-and-route, or FPGA bitstream is claimed in this release. Those require target fabric facts and a physical emitter that consumes the same Physical DAG.
