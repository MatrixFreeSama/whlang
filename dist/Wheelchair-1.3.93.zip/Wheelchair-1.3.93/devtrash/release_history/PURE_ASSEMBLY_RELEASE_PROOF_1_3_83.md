# Pure Assembly Release Proof 1.3.83

The production compiler/runtime path remains direct x86-64 assembly. The 1.3.83
StateFact change is implemented in `compiler/general_frontend_x86_64.S` and the
shared `compiler/physical_reality.inc` laws. No C, LLVM, JIT, Python runtime,
worker runtime, or state scheduler is introduced into production execution.

The generated General target uses an execution-local R15-relative state frame
inside each `iterate` episode. The old shared absolute mutable-state arena and
shared next-version mailbox are absent from production compiler source.
