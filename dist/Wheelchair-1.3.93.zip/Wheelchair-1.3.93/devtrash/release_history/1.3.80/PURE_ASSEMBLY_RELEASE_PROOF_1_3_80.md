# Pure Assembly Release Proof 1.3.80

Wheelchair 1.3.80 production compiler/runtime authority remains native assembly and shell build orchestration. The 1.3.80 execution changes are implemented in the existing x86-64 compiler/runtime sources:

- `compiler/general_frontend_x86_64.S`
- `runtime/general_parallel_release_x86_64.S`
- `compiler/field_frontend_common_x86_64.S`
- `compiler/physical_reality.inc`
- `compiler/physical_cost_ticks.inc`

No C/Python runtime wrapper, JIT, worker manager, work-stealing runtime, or benchmark-specific production source is introduced. `devtrash/` may contain benchmark and observation programs; it has no production authority.
