# Architecture Aging 1.3.80

1.3.80 applies one rule across General and Field execution:

> A mathematical fact should remain a physical fact until a real clobber, dependency, or transport boundary forces it to end.

## Readiness is not materialization

Causal readiness describes the mathematical DAG. OS execution describes one possible physical realization. Earlier General execution coupled the two too tightly at successor frontiers. 1.3.80 restores the separation already present in Field/Tensor leaf realization:

```text
causal successor ready
        |
        v
existing Physical Reality price
   /                 \
local continuation   outward execution
```

The comparison uses structural work and the existing outward lifecycle price. It does not ask which CPU is idle and does not transfer work between workers because there are no worker owners to consult.

## Ownership line, not ownership page

A General causal node needs isolated state, not a private virtual-memory page. The state stride is therefore reduced from 4096 bytes to 64 bytes. False-sharing isolation remains explicit while page-scale state and NUMA-placement probing disappear.

## Boundary facts do not lose identity

Field helper episodes historically returned a value through SIMD0 and forced it through stack authority before a resident carrier could own it. 1.3.80 distinguishes helper-clobbered and helper-sovereign carriers. If the chosen resident survives the remaining helper phase, the helper result moves directly into that resident; a stack copy exists only when a later clobber makes it necessary.

## What was deliberately not added

There is no:

- work stealing;
- global ready queue;
- idle-CPU query;
- runtime NUMA migration policy;
- benchmark-name route;
- fixed element/chunk threshold;
- second causal scheduler IR;
- boundary-specific algorithm selector.

The architecture becomes older by making existing facts live longer, not by growing another control family.
