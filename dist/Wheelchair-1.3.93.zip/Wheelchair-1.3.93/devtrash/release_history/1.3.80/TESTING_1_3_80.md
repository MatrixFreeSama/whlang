# Testing 1.3.80

`./test.sh` is the current-release verification entry.

Default release mode performs a clean production rebuild, writes current production binary hashes, and runs the 13 scripts listed in `devtrash/release_tests/current.list`. Historical scripts do not auto-admit themselves.

The 1.3.80-specific regression verifies:

- causal readiness is not an automatic `clone` request;
- General runtime no longer contains `getcpu`, `mbind`, or node-localization code;
- causal state is one 64-byte line per node;
- dynamic branch/iterate semantics remain exact;
- mixed-layout Field output remains byte-identical;
- boundary helper results can remain in helper-sovereign resident SIMD carriers;
- no workload-specific route, work stealing, global ready queue, or idle-CPU scan is introduced.

`./test.sh coverage` retains the external native coverage observer. Coverage is observation only and is not part of production code generation.
