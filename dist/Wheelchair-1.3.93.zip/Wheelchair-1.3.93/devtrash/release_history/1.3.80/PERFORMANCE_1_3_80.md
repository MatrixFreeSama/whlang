# Performance 1.3.80: Physical Work Convergence

The measurements in this file validate physical-work removal. They are not universal language-performance claims.

## General causal syscall audit

The same 1.3.79 and 1.3.80 source probes were compiled by their packaged compilers and executed under a syscall observer. Program outputs were identical.

| probe | release | clone | wait4 | getcpu | mbind | total syscalls |
|---|---:|---:|---:|---:|---:|---:|
| branch | 1.3.79 | 5 | 6 | 5 | 5 | 39 |
| branch | 1.3.80 | 2 | 3 | 0 | 0 | 20 |
| iterate | 1.3.79 | 5 | 6 | 5 | 5 | 39 |
| iterate | 1.3.80 | 2 | 3 | 0 | 0 | 20 |
| causal mesh | 1.3.79 | 4 | 5 | 4 | 4 | 32 |
| causal mesh | 1.3.80 | 1 | 2 | 0 | 0 | 15 |

This audit demonstrates removal of OS lifecycle/placement work for these causal shapes. It does not imply the same ratio for arbitrary dynamic graphs.

## Field mixed-layout codegen audit

The existing mixed-layout regression exercises the generic/gather boundary path.

| metric | 1.3.79 | 1.3.80 |
|---|---:|---:|
| generated ELF bytes | 25,380 | 25,348 |
| vector stack stores matching `vmovups [rsp+...]` | 13 | 9 |
| checksum | `0x47126d00` | `0x47126d00` |
| expected output comparison | byte-identical | byte-identical |

The removed stores are the direct consequence of carrying helper-sovereign ValueFacts in their final resident register instead of forcing an unconditional stack round trip.

## Boundary of the claim

1.3.80 does not yet model cache and DRAM residency as first-class TrafficFacts. It also does not yet turn periodic boundary address maps into maximal piecewise-affine regions, preserve sliding windows across Field packets, or fuse the time axis into Field regions. Those are remaining routes toward reducing physical work, not completed features of this release.
