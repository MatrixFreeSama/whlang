# Wheelchair 1.3.80

1.3.80 is a physical-work convergence release. It changes production compiler/runtime code, but does not add a second scheduler, worker system, workload selector, benchmark route, or runtime CPU-availability authority.

## General causal execution

A mathematically ready successor is no longer identical to a new Linux execution. The compiler publishes a per-region AOT work price for straight-line causal regions. The existing runtime compares that price with the existing outward lifecycle price. Regions that cannot repay outward materialization continue in the current execution; dynamic/unbounded regions remain outward candidates.

The change reuses the old causal-region graph and the old outward execution path. It does not add work stealing, a global ready queue, worker ownership, CPU-load observation, or a new runtime scheduler.

General causal state now occupies one 64-byte ownership line per node instead of one 4 KiB page. Runtime `getcpu`/`mbind` placement observation is removed.

## Field boundary ValueFacts

Regular Field regions already allowed proven immutable values to live directly in final SIMD carriers. 1.3.80 extends that lifetime rule through helper-backed boundary episodes when the assigned carrier is outside the helper clobber set. A stack backup is retained only when a later helper can actually destroy the resident fact.

The general/gather fallback remains intact. This is a lifetime convergence of the existing ValueFact authority, not a stencil-width or workload-specific path.

## Shared physical price

`physical_cost_ticks.inc` now also defines a conservative emitted-front-end byte price used by General straight-line causal regions when deciding whether outward execution can be repaid. It is a physical resource price in the existing 1/12-cycle domain, not a source-size threshold.

No claim is made that this is a full memory-hierarchy traffic model. Cache/DRAM transport is still a known boundary of the current Physical Reality model.

## Compatibility and correctness

Current regressions preserve human-shell order, semantic convergence, recursive execution-form convergence, Field human forms, Physical Region sparsification, ownership-local execution, launch-static realization, machine-fact burn, and Physical-DAG-to-ISA scheduling.

Representative General branch, iterate, and causal-mesh outputs remain bit-identical. The mixed-layout Field regression remains byte-identical to its expected output.
