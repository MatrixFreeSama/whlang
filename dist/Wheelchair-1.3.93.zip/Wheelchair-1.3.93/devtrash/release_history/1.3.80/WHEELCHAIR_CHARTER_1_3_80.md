# Wheelchair Charter 1.3.80

1. Mathematical causality is authoritative; parallelism is a possible physical realization, not a source semantic.
2. Idle hardware is allowed. Outward execution exists only when the remaining structural work can repay its physical lifecycle.
3. Completion returns capacity outward. It does not search for a receiver, inspect idle CPUs, or transfer ownership to another worker.
4. One Physical Reality / Physical DAG authority owns execution cost. New performance work must merge into that authority rather than create workload routes.
5. A proved fact remains resident until a real clobber or dependency boundary requires materialization.
6. No fixed element count, instruction count, chunk size, or benchmark name may decide outward execution.
7. Strict floating-point order remains semantic authority. Tolerance may relax only the explicitly admitted numerical relation.
8. Repair precedes convergence in the human shell. Successful automatic convergence is reported as `Cheesed successfully.` followed by `line N:` locations.
9. A final error dominates intermediate repair/convergence presentation.
10. Historical experiments belong under `devtrash/`; production authority remains small, current, and rebuildable.
