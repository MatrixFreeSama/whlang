# Pure Assembly Release Proof 1.3.38

The production compiler and runtime remain handwritten native assembly. The parameterized >64-bit floating authority is `runtime/rankn_precision_x86_64.inc`, assembled into the existing static General runtime image. Production build scripts do not invoke Python, C, LLVM or a JIT.

`fpP` does not create a runtime object manager or scheduler. Carrier addresses and spans are assigned by the AOT compiler from a static ownership workspace. Precision policy remains a compile-time semantic meet.
