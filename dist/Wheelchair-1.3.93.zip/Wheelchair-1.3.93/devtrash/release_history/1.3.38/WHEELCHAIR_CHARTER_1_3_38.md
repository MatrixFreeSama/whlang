# Wheelchair Charter 1.3.38

## Architecture priority, mandatory order

1. **Parasite old architecture first.** A new semantic must use existing ValueFact, Rank-N, Physical DAG, precision, topology and lifetime authorities whenever they can express it.
2. **Strengthen old architecture second.** If the old substrate is close but incomplete, generalize that substrate rather than opening a feature branch.
3. **New architecture is last resort.** It is permitted only when the old substrate cannot express the required semantics without contradiction.
4. Any unavoidable new authority must be high-affinity, high-extensibility and explicitly assimilatable. Its destination is the common substrate, not permanent parallel architecture.

## Floating precision authority

`f32` and `f64` are native precisions. A type spelling `fpP` with `P > 64` denotes one parameterized floating semantic whose significand precision is P bits.

No source implementation may branch on named wide precisions. P is data. The physical span is derived from P and represented by the Rank-N precision-limb axis. Finite arithmetic uses integer significands and round-to-nearest-even.

The existing precision meet remains authoritative. `precision_propagation` is evaluated before the physical path is selected. No wide-precision helper may override that choice or propagate a policy down a child subtree.

## Physical realization

The Rank-N precision axis describes causal structure; it does not authorize fake parallelism. A scalar realization may execute limb work serially when the physical substrate makes that cheaper. Batch/vector, tree-reduction, Karatsuba, Toom or other realizations may become physical candidates only when actually implemented and selected by structural physical cost. Fixed precision thresholds are not an architectural selector.
