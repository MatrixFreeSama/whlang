# Wheelchair 1.3.38 High-Precision C Battle

## Scope

This report measures the **released scalar parameterized Rank-N floating physical path**, not the separate experimental AVX-512 IFMA batch prototype. It therefore measures what 1.3.38 actually ships.

Machine: Intel Xeon Platinum 8573C, one CPU pinned, GCC 14.2, GMP 6.3.0, AVX2/AVX-512/AVX-512IFMA available.

Inputs use full-width random significands rather than small integers. Each row is the median of three timed runs after warmup. Results are throughput in million operations per second (Mops/s). C uses GMP `mpf_t` with the same requested precision for P=128..2048. At 113 bits, a separate C `__float128`/libquadmath run is included. GMP rounds requested precision to its own limb precision; the 128..2048 equal-precision table uses values that GMP reports exactly at those precisions.

## Equal requested precision: Wheelchair vs C + GMP

| P bits | op | Wheelchair Mops/s | C+GMP Mops/s | C advantage |
|---:|:---:|---:|---:|---:|
| 128 | + | 12.826 | 62.204 | 4.85x |
| 128 | * | 14.998 | 44.818 | 2.99x |
| 128 | / | 0.301 | 41.227 | 136.93x |
| 256 | + | 10.777 | 56.676 | 5.26x |
| 256 | * | 17.111 | 59.640 | 3.49x |
| 256 | / | 0.116 | 19.536 | 168.05x |
| 512 | + | 7.757 | 50.240 | 6.48x |
| 512 | * | 5.465 | 17.104 | 3.13x |
| 512 | / | 0.0453 | 10.256 | 226.32x |
| 1024 | + | 6.431 | 45.925 | 7.14x |
| 1024 | * | 2.119 | 6.973 | 3.29x |
| 1024 | / | 0.0174 | 4.233 | 243.76x |
| 2048 | + | 3.357 | 35.286 | 10.51x |
| 2048 | * | 0.445 | 1.965 | 4.42x |
| 2048 | / | 0.00423 | 1.428 | 337.62x |

The released scalar path loses this benchmark. The largest deficit is generic restoring division, whose current implementation is deliberately width-independent but not yet a competitive high-precision division algorithm.

## IEEE binary128-class comparison

At 113 significand bits, C `__float128` achieved 61.848 Mops/s add, 63.823 Mops/s multiply and 68.440 Mops/s divide. Wheelchair P=113 achieved 14.889, 23.369 and 0.381 Mops/s respectively in the same full-width benchmark. C therefore led by approximately 4.15x, 2.73x and 179.43x.

## Correctness boundary

Performance does not relax correctness. The 1.3.38 release gate separately verifies unrelated precisions P=65, 73, 127, 191, 257, 521 and 2048 against an exact rational oracle with round-to-nearest-even. It also verifies low/high precision propagation and nested meet-edge behavior.

## Interpretation

This result does **not** invalidate Rank-N as the carrier authority. It identifies the current scalar physical realization as the bottleneck. The old named-width architecture is gone; precision remains data. Future IFMA batch, balanced-reduction, Karatsuba, Toom or convolution realizations may compete as physical candidates, but 1.3.38 makes no production vector-speed claim until those realizations are actually integrated and release-tested.
