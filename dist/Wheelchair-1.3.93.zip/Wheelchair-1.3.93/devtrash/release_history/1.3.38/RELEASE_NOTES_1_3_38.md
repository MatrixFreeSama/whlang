# Wheelchair 1.3.38 Release Notes

1.3.38 removes the former dedicated two-width high-precision implementation at source level and replaces it with one parameterized Rank-N precision authority.

- `fpP`, P > 64, is parsed generically.
- P is encoded in the type fact rather than assigned a width-specific type ID.
- AOT carrier span is derived from `ceil(P/64)` and owned by the existing general image.
- The significand is a Rank-N limb axis; arithmetic is integer multi-limb with normalization and round-to-nearest-even.
- Existing low/high precision propagation is unchanged and remains upstream of physicalization.
- Input/output type patch tables are widened to carry encoded precision facts.
- Decimal typed input uses the same generic P and performs one final target-precision division rather than routing through f64.
- Old dedicated runtime source, tests and release documentation are removed rather than retained as compatibility code.

1.3.38 does not claim that the scalar limb realization is already the final parallel/AVX physical peak. Rank-N exposes the structure; future faster multiplication/reduction realizations must enter as cost-selected physical candidates without named-width branches.

## High-precision performance status

`PERFORMANCE_1_3_38_HIGH_PRECISION_C_BATTLE.md` records a full-width single-core comparison against C `__float128` and C+GMP. The released scalar Rank-N realization loses these mature C baselines, especially division. This is recorded as an engineering boundary rather than hidden behind the faster out-of-tree IFMA prototype.
