# Correctness: Parameterized Rank-N Floating Precision, 1.3.38

The release gate deliberately uses unrelated precisions (65, 73, 127, 191, 257, 521 and 2048 bits) so a hidden fixed-width implementation cannot satisfy the test.

Validation covers:

- native `fp64` remaining on the old native path and `fp65` entering the Rank-N precision path;
- exact rational `+`, `-`, `*` and `/` compared with a test-only exact Fraction oracle and round-to-nearest-even at P bits;
- exact long-decimal typed input at several unrelated P values;
- lower and higher precision propagation for native/wide and wide/wide pairs;
- a nested meet-edge case proving that high propagation does not tunnel into a naturally-f32 child expression;
- source scans rejecting dedicated fixed-width type IDs, semantic names, runtime files and compatibility aliases.

The compiler and production runtime do not depend on Python. Python is used only as an external release oracle.
