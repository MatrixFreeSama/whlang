# Performance Boundary 1.3.83

1.3.83 is a correctness-and-physical-ownership release. A benchmark is not
allowed to turn a wrong concurrent result into a speed claim.

The defect-reproduction workload contains four independent non-affine mutable
recurrences. 1.3.82 may produce different answers from run to run under four-CPU
affinity, so it has no valid parallel performance score on that workload.

1.3.83 preserves concurrency after correcting ownership. On the validation host,
a sampled two-million-update run measured roughly 35.6 ms under one-CPU affinity
and 17.2 ms under four-CPU affinity. The purpose of this measurement is only to
show that correctness was not restored by serializing the program.

For two u64 states, the mathematical mutable payload is 32 bytes per live
execution including simultaneous next-version values. The generated 1.3.83
frame is also 32 bytes. Four simultaneous branches therefore require 128 bytes
of mutable state payload, rather than a permanently shared arena or one permanent
copy per source binding.
