# Wheelchair 1.3.13 Charter

## Register-native causal transition physicalization

Wheelchair 1.3.13 closes the artificial serialization exposed by the 1.3.12 recurrence probes. The release is not a Fibonacci optimization and contains no workload-name dispatch. The architectural rule is broader:

> When a causal state transition can be proven at AOT compile time and its admitted value graph fits the physical register contract, the transition must be emitted as register-native dataflow rather than reconstructed through a machine-stack expression interpreter.

The intended lowering is now:

```text
WH / WHEX semantics
  -> old/new state generations
  -> causal transition relation
  -> admitted expression DAG
  -> typed physical value domain
  -> transition-wide output carriers / structural ISA pattern
  -> native machine instructions
```

The forbidden mature-path reconstruction is:

```text
semantic relation
  -> push operand
  -> push operand
  -> pop temporaries
  -> arithmetic
  -> push result
  -> pop state
```

## Physical invariants

For an admitted scalar causal transition:

1. Persistent integer state resides in GPR state registers.
2. Persistent floating state resides in XMM state registers.
3. Recursive expression intermediates use bounded compile-time scratch-register banks, never a runtime value stack.
4. Next-generation results are computed into output carriers disjoint from the old generation and are committed only after every next-state expression has consumed the old generation it requires.
5. A counted native transition uses a bottom-tested steady-state backedge when the proof permits it.
6. Reused floating constants may be selected at compile time and materialized once in preheader XMM registers.
7. Structural transition patterns may select a denser ISA realization only from the proven relation. No benchmark, source filename, function name, or workload identity may participate in selection.

## Simultaneous-state law

An update set is a relation between generation `t` and generation `t+1`, not a sequence of destructive assignments. A state from generation `t` remains semantically live until all expressions that consume it have been emitted. Only then may its physical resource be overwritten by the committed next generation.

This is the register-level form of blind cascading resource return: completed physical ownership is released by lifetime completion. No worker asks another worker for a register, no global ready queue exists, and no runtime graph manager walks dependencies.

## ISA patterns are structural, not named fast paths

1.3.13 currently includes two relation-proven integer transition patterns in addition to the generic register DAG path:

- a two-state swap-plus-wrap-add relation may lower to `xadd`;
- a three-state shift plus full wrap-add relation may lower to a compact register sequence.

These patterns are selected by state roles and expression structure. They do not inspect Fibonacci, Lucas, Tribonacci, benchmark names, filenames, or source-level labels.

## Strict semantic boundary

Native admission must never weaken language semantics merely to obtain faster code. The current direct physicalizer admits the proven scalar subset implemented in the compiler, including same-domain integer wrapping add/subtract/multiply and strict floating add/subtract/multiply used by the validated recurrence family. Unsupported, mixed-domain, trapping-integer, or otherwise unproven expression forms retain the established compatible lowering.

A fallback is therefore not a hidden optimization failure. It is a semantic firewall. 1.3.13 claims zero artificial stack traffic only for expressions admitted by the register-native proof, not for every possible Wheelchair expression.

Strict floating-point reassociation remains forbidden. The compiler does not rewrite `(a+b)+c` into `a+(b+c)` unless a future explicit semantic contract permits it.

## No runtime scheduler substitution

All transition analysis, native admission, constant selection, scratch assignment, and structural instruction selection occur AOT. Runtime contains no:

- transition graph walker;
- runtime register allocator;
- work stealing;
- global ready queue;
- centralized load balancer;
- C/LLVM/JIT backend dependency for this path.

The executable runs the already-physicalized machine instructions directly.

## Peak-preservation rule

1.3.13 extends the existing Technical Peak Preservation Contract. A generalized representation may not destroy a known machine-code peak and then recover it through a workload-specific shortcut. The structural property responsible for the peak must be promoted into the generic compiler proof.

Accordingly, the recurrence family is a probe corpus. Fibonacci, Lucas, Tribonacci, coupled integer recurrences, cyclic simultaneous updates, and floating recurrences are evidence for a shared physicalization rule, not compiler entry points.

## Release definition

1.3.13 is considered complete for this diagnosed architecture gap only when all of the following hold:

- the register-native physical-expression contract is present;
- old/new generation semantics are preserved;
- admitted hot transitions contain zero `push` / `pop` expression traffic;
- admitted hot transitions contain zero persistent state/temp-array traffic;
- admitted floating hot transitions contain no GPR-stack roundtrip for state transport;
- generic non-pattern transition DAGs pass correctness and disassembly gates;
- trapping integer fallback preserves exact semantics;
- the complete 1.3.12 native release authority remains passing;
- release binaries are rebuilt from pure-assembly sources and match the packaged prebuilt images;
- no workload-name specialization exists in compiler/runtime sources.

This release removes an artificial machine-stack serialization layer. It does not claim that every future Wheelchair expression, Rank-N graph, or device backend is already covered by the scalar physicalizer.
