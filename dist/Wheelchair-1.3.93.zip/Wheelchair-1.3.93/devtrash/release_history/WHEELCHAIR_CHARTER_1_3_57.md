# Wheelchair 1.3.57 ShapeFact-N charter

1. Shape is data, not control flow.  N logical axes never imply N nested executors.
2. ShapeFact-N stores only irreducible sparse facts.  Reconstructible rank/product/stride data must not become parallel authorities.
3. Runtime extent spelling is identity data, never a reserved variable name.
4. Consumer limitations belong to consumers.  The current Tensor one-runtime-extent rule must not become a ShapeFact semantic law.
5. Existing Tensor DAG, coordinate compression, Physical Reality, and one-root execution remain the execution authority.
6. New shape architecture must consume and delete old descriptors rather than coexist behind compatibility branches.
7. ShapeFact-N owns no fixed rank/axis/extent capacity.  Exhaustion may come only from actual source structure or machine/OS resources.
8. Static and runtime extents share one axis-fact vocabulary; no DynamicTensor parallel hierarchy is permitted.
9. Source naming must erase before physicalization.  Equivalent shapes with different extent names should converge to the same machine program.
10. Future multi-runtime shape work, if undertaken, extends the consumer/descriptor realization while preserving this ShapeFact authority and one physical execution root where valid.
