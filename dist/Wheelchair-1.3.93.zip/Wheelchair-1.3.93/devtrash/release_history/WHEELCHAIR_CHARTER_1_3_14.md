# Wheelchair 1.3.14 Charter

## Unified Physical Architecture Consolidation

Wheelchair 1.3.14 establishes **merge-and-reuse first** as a compiler architecture law. A newly exposed workload class does not earn a private backend merely because a local fast path can be built. The compiler must first express the new facts through the existing Rank-N / Axis / Operator / Region / Effect / Capability vocabulary and the Versioned Physical Reality / Physical DAG machinery.

The intended direction is:

```text
new problem structure
    -> existing semantic facts if representable
    -> Versioned Physical Reality
    -> one Physical DAG
    -> one lifetime / carrier / constant / ISA authority
    -> native machine code
```

The forbidden direction is:

```text
new benchmark or workload family
    -> new private allocator
    -> new private constant bank
    -> new private scheduler
    -> new private fallback backend
```

## Causal state is a Rank-N fact

The scalar state-transition class exposed by 1.3.12 and 1.3.13 is no longer treated as a permanent recurrence architecture. Its durable fact is a **causal axis** with versioned state values. Old/new generations are ordinary versioned ValueFacts; their dependencies are represented in the same Physical DAG used by the broader compiler.

The 1.3.13 machine-code peaks remain release obligations, but its temporary fixed-depth scratch architecture and duplicate stack-compatible recurrence backend are removed.

## One physical authority

1.3.14 requires compiler-time physical ownership to be expressed through shared facts:

- typed physical values rather than expression-stack positions;
- lifetime/future-use driven GPR and XMM carriers;
- last-consumer release rather than fixed expression-depth scratch ownership;
- constant residency competing for the same physical carrier authority as temporaries;
- three-operand scalar VEX lowering where semantic legality and target capability permit it;
- structural ISA selection from Physical DAG shape rather than workload identity.

Runtime register allocation, transition graph walking, work stealing, global ready queues and resource-recipient selection remain forbidden.

## Merge-before-add law

For every future optimization or language extension:

1. attempt to represent the new property using existing Axis / Operator / Region / Effect / Capability / Physical Reality facts;
2. reuse existing lifetime, residency, CSE, allocation and ISA-selection machinery;
3. add a new independent subsystem only if the existing algebra cannot represent the required semantics without loss;
4. if a temporary subsystem was needed to diagnose a gap, absorb its proven facts into the shared architecture and remove the scaffold once the common path reproduces the technical peak.

## Active-Silicon Purity

The objective is not maximum occupancy. The objective is to minimize physical activity that is not required by the mathematical problem or by unavoidable machine semantics.

```text
useful necessary physical work
--------------------------------  -> as high as physically possible
all active physical work
```

Register-to-register shuffling, repeated constant materialization, stack expression transport, load-balancing coordination and duplicate realization are all waste when the same semantics can be proved without them.

## Release definition

1.3.14 is complete only when:

- General, Tensor and Field share the compiler-wide Physical Reality vocabulary;
- causal state is represented as a causal-axis/versioned-state fact rather than a permanent private recurrence architecture;
- the duplicate 1.3.12 stack recurrence backend is absent;
- fixed expression-depth GPR/XMM scratch ownership is absent;
- integer and floating admitted transitions use compile-time lifetime carriers;
- scalar FP admitted transitions use three-operand VEX lowering and shared constant residency;
- historical 1.3.13 machine-code peaks are reproduced through the unified path;
- confirmed dead/placeholder helpers and ghost state are removed;
- native256 frontend duplication and Tensor runtime profile duplication are collapsed without machine-code regression;
- old release authorities remain passing;
- no workload-name specialization, runtime register allocator, transition walker, work stealing, global ready queue or resource-recipient selection appears;
- the final release is rebuilt from pure assembly sources and the packaged prebuilt images are byte-identical to a clean build.
