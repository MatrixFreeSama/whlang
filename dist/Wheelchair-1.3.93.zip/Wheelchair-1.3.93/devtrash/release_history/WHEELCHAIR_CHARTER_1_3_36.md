# Wheelchair Charter 1.3.36

## Architecture evolution priority

This order is mandatory and may not be reversed by a feature request.

1. **Parasite old architecture first.** A new semantic must first attempt to live on existing AST, ValueFact, Rank-N, Physical DAG, carrier lifetime, precision-meet and compile-time authorities.
2. **Strengthen old architecture second.** If an existing authority is too narrow, generalize that authority so old and new capabilities share one substrate.
3. **New architecture is last resort.** A new authority is permitted only when the common architecture genuinely cannot express the semantics without falsifying them.
4. **Any unavoidable new architecture must be high-affinity and high-extensibility.** It must connect directly to old authorities, expose reusable structure rather than one feature, avoid a second runtime/scheduler/executor, and have an assimilation path until it becomes ordinary old architecture.

```text
new need
  -> parasite old authority if possible
  -> otherwise strengthen old authority
  -> only if impossible, create a high-affinity reusable authority
  -> assimilate it into the common substrate
  -> it becomes ordinary old architecture
```

A permanent feature tree is architecture debt.

## Structured Fact assimilation

Structured Facts are compile-time containers for mathematical identities spanning multiple scalar facts, currently complex values and small structured matrices/vectors. At a user-visible structured `let` boundary, every scalar carrier checkpoints through the existing compute-binding / ValueFact path. The wrapper remains only as a compile-time projection map.

No dedicated Complex, Matrix, Eigen or SVD runtime authority is permitted.

## Mathematics is native semantics

Mathematical notation is language semantics, not a library boundary. A construct must become existing scalar facts, existing Rank-N relations, compile-time Structured Facts that collapse to scalar facts, or disappear during compile-time lowering.

## Less work remains a hard rule

- A shared mathematical fact should exist once.
- Precision conversion occurs only on a real consumer edge.
- Structured values checkpoint only where structure would otherwise duplicate scalar DAG work.
- Powers of two are optimization opportunities, never semantic dimensional restrictions.
- Iterative compile-time mathematics may checkpoint into old ValueFacts; it may not create a runtime solver object.
- A larger buffer is not a substitute for eliminating duplicated structure.

## Extended precision boundary

Wheelchair does not keep an experimental expansion-class extended-precision implementation merely to own the feature. If extended precision returns, it must use a mature numerical representation and remain subordinate to the same old ValueFact / Physical DAG authorities.

## Current decomposition boundary

The structured dense decomposition authority is intentionally small-matrix compile-time mathematics. Large general matrices remain Rank-N territory. LU/inverse are non-pivoted, eigensystem is symmetric small-matrix power-deflation, and SVD is formed from the symmetric eigensystem of `A^T A`.
