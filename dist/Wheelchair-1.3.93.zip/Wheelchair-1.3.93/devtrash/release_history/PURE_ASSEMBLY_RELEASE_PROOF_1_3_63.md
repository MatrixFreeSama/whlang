# Wheelchair 1.3.63 pure-assembly release proof

`build.sh` rebuilds all production compiler/runtime executables from handwritten assembly and shell-derived ELF metadata. The production build rejects Python invocation.

1.3.63 additionally proves at build time that the production source tree contains none of the retired Group width authorities: `schedule_unroll`, `schedule_carriers`, `physical_plan_group_body`, `physical_plan_group_carriers`, `physical_group_form`, `unroll_count_patch`, `reduction_carriers_patch`, `RUNTIME_UNROLL_OFF`, or `RUNTIME_CARRIERS_OFF`.

The runtime patch contract is `group_body_factor_patch` / `group_carrier_factor_patch`, with independent realized-group witness fields. The four Tensor physicalizers consume the common GroupFact factors directly.
