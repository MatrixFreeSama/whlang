# Pure Assembly Release Proof — Wheelchair 1.3.20

The production compiler/runtime remains handwritten x86-64 assembly. The production build invokes neither Python nor a C/LLVM backend.

The 1.3.20 change is confined to AOT general-frontend physicalization:

- historical 2-state and 3-state private transition-shape emitters are absent;
- the existing whole-episode CSE authority records carrier exhaustion;
- persistent next-version XMM residency and transient next-version handoff are two realizations of the same Physical DAG;
- a retry is admitted only after AOT shared-carrier exhaustion is observed;
- no runtime graph walker, allocator, cache manager, or workload selector is emitted;
- a generic machine-code canonicalizer can recover an ISA `xadd` sequence without state-count dispatch.

Release validation requires bit-identical semantic outputs for causal recurrences and the four simulation probes, plus arithmetic-count regression gates for the simulation hot loops.
