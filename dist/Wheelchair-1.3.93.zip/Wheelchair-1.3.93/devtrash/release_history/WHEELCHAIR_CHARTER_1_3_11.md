# Wheelchair 1.3.11 Charter

## Field Contiguous Physical Collapse & Complex Surface

Wheelchair 1.3.11 applies Active-Silicon Purity inside complex materialized Rank-N Field execution.

The supreme rule remains:

> **Activate no silicon without necessary work. Waste no activated silicon on avoidable work.**

### 1. Physical proof is work too

A direct regular Field load is not enough if the runtime repeatedly pays expensive Rank-N arithmetic merely to rediscover that the next SIMD episode is still inside the same contiguous row.

For non-power-of-two shapes, 1.3.11 proves the innermost row once for the active SIMD episode. After no-row-crossing is established, the outer coordinates are shared by all active lanes and are decoded once per axis. The proof is Rank-N structural and independent of workload names, rank-3 special cases, and benchmark sizes.

True periodic-boundary and irregular cases keep the existing fallback authority. Generality is not an excuse to charge regular interior work for irregularity it does not possess.

### 2. Residency is earned by reuse

Immutable Field neighbors may occupy AVX-512 high-register residency only when compile-time use count justifies it. The current ordinary Field authority admits at most seven reuse-selected facts in ZMM6..ZMM12. Single-use facts do not become persistent merely to increase register occupancy.

Lasting physical authority is a profitability decision, not a cache doctrine.

### 3. Complex human expressions remain AOT

The human WH/WHEX Field surface now has four sovereign floating logical carriers, v0..v3, mapped through the same canonical Field Physical-DAG. This raises the proven Sethi-Ullman expression slice without adding a runtime expression interpreter, JIT, C backend, LLVM backend, or second Field semantics.

A high-pressure three-output complex 3D expression that exceeded the former three-register surface now lowers directly through the handwritten assembly frontend into `wheelchair.field/1`.

### 4. FMA count is not an optimization objective

A broad tolerant mul-plus-add contraction was implemented and measured during development. It reduced static instruction count but increased accumulator recurrence pressure and degraded multi-capacity execution. It is intentionally absent from 1.3.11.

Wheelchair therefore rejects the false equation:

```text
fewer instructions == lower physical cost
more FMA sites      == better realization
```

Only measured and structurally justified physical profitability has authority.

### 5. 1.3.10 remains sovereign

Blind Surplus Reflow is unchanged. Hardware width remains a capacity ceiling, not work demand. Static equal partition, proportional executor splitting, work stealing, peer-load observation, global ready queues, and failed-claim spin remain forbidden.

1.3.11 optimizes what already-active Field silicon does. It does not resurrect machinery whose purpose is to keep more silicon busy.

### 6. No probe specialization

No CVRD3D name, field name, rank-3 dispatch, grid-size dispatch, or benchmark-size dispatch is permitted in compiler or runtime authority. The complex field is a probe, not an optimization trigger.
