# Testing 1.3.81

Run:

```sh
./test.sh
```

The release authority is `devtrash/release_tests/current.list`, currently 14 tests. The 1.3.81 gate adds mathematical/physical convergence checks on top of all retained 1.3.80 gates.

The new gate verifies:

- one shared Traffic Reality authority;
- no traffic second IR or runtime bandwidth probe;
- mathematical Field traffic floor and lower-bound invariant;
- piecewise-affine periodic RegionFact on AVX-512 and AVX2 paths;
- execution-local Region deltas, with no shared mutable periodic delta publication;
- Tensor traffic resource integration;
- General emitted-memory traffic integration;
- exact mixed-layout Field output on both machine widths;
- preserved dynamic General causal semantics;
- absence of work stealing, global ready queues, idle-CPU scans, workload-named routes, sliding-window matcher, forced layout manager and second spacetime scheduler.
