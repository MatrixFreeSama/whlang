# Wheelchair 1.3.81

1.3.81 is a mathematical/physical convergence release. It extends the existing Physical Reality / Physical DAG authority with transport facts and longer-lived periodic AddressFacts. It does not add work stealing, a worker pool, a global ready queue, runtime CPU scanning, runtime bandwidth probing, a second traffic IR, a Field spacetime scheduler, a fixed temporal tile, a sliding-window workload matcher, or a layout-copy manager.

## Traffic Reality

`physical_cost_ticks.inc` now defines a cache-line-equivalent traffic resource in the same 1/12-cycle domain as arithmetic, load issue, AGU and branch resources.

Field derives two facts for each ownership quantum:

1. current emitted line-equivalent traffic: unique immutable preloads plus mutable/uncached loads plus semantic stores;
2. mathematical affine-stream floor: accesses sharing field identity and every outer-axis affine coordinate belong to one advancing innermost stream, plus required semantic stores.

The mathematical floor is checked as a real lower bound. `floor > actual` is a compiler proof failure, not a value to clamp.

Tensor derives traffic as the eleventh resource bottleneck from the existing load facts. General counts emitted memory facts while fragments are generated and prices a static causal Region by `max(frontend_transport, memory_traffic)`. No second scheduling graph is retained.

## Piecewise-affine periodic RegionFact

Periodic Field topology no longer implies random gather for an entire boundary neighborhood. `field_regular_run_end` now proves the maximal affine class of the current execution-local Region:

- canonical interior;
- low-side wrap with a constant signed displacement;
- high-side wrap with a constant signed displacement;
- generic fallback only when a vector episode truly crosses a class boundary.

Power-of-two extents consume shift/mask coordinate facts inside the same proof. Arbitrary extents use exact integer coordinate proof. These are two realizations of one RegionFact, not compatibility backends.

An innermost wrap is intentionally left on the old generic episode when its short persistence cannot repay a new Region. Outer-axis wrap may remain direct across a row. This is a physical-cost decision, not a stencil-size threshold.

Region delta storage is execution-local. The first prototype exposed why this matters: Field executions share VM state, so mutable global Region deltas are not a valid ownership model. 1.3.81 removes that shared mutation.

## Cross-packet and time continuity

The compiler now records the affine transport-stream relation across advancing packets. It does not automatically replace loads with register shifts. Cache reuse, load-port pressure and permutation cost are target-dependent physical facts; a forced transformation would violate the same minimum-work rule it is meant to serve.

Time remains the existing Rank-N causal authority already used by General recurrence/transition-power machinery. A frontend timestep boundary is not a semantic materialization boundary. No separate Field temporal scheduler or fixed time tile is added.

## Compatibility deletion and convergence

The old global assumption that periodic boundary means generic gather is removed. The former power-of-two/generic Region proof split is folded into one RegionFact proof. Current release documents replace 1.3.80 root authority; old release documents are historical only under `devtrash/release_history/1.3.80/`.

## Correctness

The current 14-test authority preserves human-shell behavior, semantic and execution-form convergence, Field surface behavior, Physical Region sparsification, ownership-local execution, launch-static realization, machine-fact burn, Physical-DAG-to-ISA scheduling, 1.3.80 causal work convergence and the new 1.3.81 mathematical/physical convergence gate.
