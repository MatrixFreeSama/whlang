# Wheelchair Charter 1.3.81

The optimization target is not occupancy and not a language opponent.

For declared semantics and precision, Wheelchair minimizes physical work above the mathematical and unavoidable transport/causal lower bound.

1. Mathematical readiness does not imply a new OS execution.
2. Idle silicon is valid when outward realization costs more than the remaining structure can repay.
3. Observation, scheduling, ownership transfer and synchronization are physical work and require the same justification as arithmetic.
4. Address, value, region, traffic and causal facts live until a real physical boundary invalidates them, not until a frontend or packet boundary happens to end.
5. Periodicity, rank, recurrence and affine structure remain mathematical facts as far down the machine path as possible.
6. No workload name, benchmark name, fixed element threshold, fixed chunk, fixed temporal tile or candidate zoo may become optimization authority.
7. No work stealing, global ready queue, idle-CPU scan or runtime bandwidth probe is introduced to improve occupancy.
8. A possible transformation is not automatically a profitable transformation. If its total physical work cannot be proved lower, it is not materialized.
9. The reference comparison is `W_physical / W_mathematical-minimum`, with the target approaching one.
10. A theoretical lower bound may be revised downward by a stronger proof. Wheelchair may not be declared below a true lower bound.
