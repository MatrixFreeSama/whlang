# Architecture Aging 1.3.81

1.3.81 grows old architecture rather than adding parallel subsystems.

## Reused authority

- Rank-N / Axis / Operator / Region / Effect / Capability remain semantic authority.
- ValueFact, AddressFact, RegionFact and GroupFact remain physical facts.
- Physical Reality remains the single cost vocabulary.
- Physical DAG remains the single causal machine-order authority.
- Existing outward materialization remains the only external execution mechanism.
- Existing generic Field episode remains the truthful fallback for a genuinely non-affine packet.

## Folded into old authority

- Data traffic is now another Physical Reality resource, beside arithmetic, load issue, AGU and branch.
- Periodic wrap is a RegionFact class, not a separate boundary backend.
- Cross-packet window relation is an AddressFact transport-stream identity, not a named stencil optimization.
- Time remains a Rank-N causal axis rather than gaining a Field-specific temporal scheduler.
- Frontends produce physical facts; frontend names are not execution routes.

## Deleted or forbidden redundancy

- periodic-boundary-implies-gather authority;
- shared mutable Region delta publication;
- separate power-of-two compatibility Region backend;
- traffic second IR;
- runtime bandwidth probing/autotuning;
- sliding-window workload matcher or fixed window width;
- Field spacetime scheduler or fixed temporal tile;
- layout-copy/transpose manager created merely to improve occupancy;
- work stealing, global ready queues and idle-CPU scanning.

## Physicalization rule

A relation may exist mathematically without becoming a separate machine mechanism. The compiler records the fact first. A physical realization is admitted only when the shared cost model can prove less total work than leaving the existing realization in place.
