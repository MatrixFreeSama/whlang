# Performance Boundary 1.3.81

1.3.81 does not use a C/Fortran leaderboard as release authority. The architectural target is mathematical/physical convergence.

## Structural measurements

The new periodic Region proof was measured against the 1.3.80 Field path during development on the validation host. Results were workload- and host-sensitive, but the direction after proof-cost convergence was:

- 64^3 7-neighbor Field: approximately neutral to a small gain;
- 96^3: the strongest observed gain, especially when multiple executions were admitted;
- 128^3: a smaller positive gain.

These observations are not a universal performance claim and are deliberately not used as release gates. The important release properties are that numerical regressions pass, periodic RegionFacts are execution-local, and the new traffic lower bound remains below the emitted traffic fact.

## Why no forced sliding/window number is reported

The 7-neighbor graph exposes a 7-to-5 structural stream gap and the 27-neighbor cube exposes 27-to-9. That does not imply a register-shift implementation is automatically faster. Existing cache reuse may already remove external traffic while extra permutes consume front-end/vector resources. 1.3.81 therefore records the lower bound and leaves realization to the common cost authority.

## Measurement rule going forward

Performance work should report, where measurable:

- arithmetic work versus arithmetic lower bound;
- line/byte traffic versus transport lower bound;
- outward executions versus causally necessary materializations;
- synchronization/coordination work versus causally necessary joins;
- wall time and energy only as physical consequences, not as substitutes for the work accounting above.

A conventional language implementation may remain as an occasional machine sanity baseline, but it is not the optimization target.
