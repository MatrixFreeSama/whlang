# Mathematical / Physical Convergence 1.3.81

## Reference quantity

Wheelchair now treats the mathematical/physical ratio as the primary architectural measurement:

```text
R = W_physical / W_min
```

`W_min` is the best currently proved lower bound under the program's semantics, floating-point contract and unavoidable machine transport/causal constraints. `R = 1` is the target, not a promise that all hardware overhead can be removed.

The lower bound is multidimensional. Arithmetic operations, transported data and causal propagation are not added into a fake universal scalar unless a target Physical Reality profile supplies a common cost domain. The compiler may take the maximum of simultaneous resource bounds to avoid double-counting work that overlaps physically.

## Field traffic facts

For one 64-byte ownership quantum, 1.3.81 derives:

```text
actual_traffic_lines
transport_floor_lines
```

The first counts line-equivalent data-path operations the current Field realization emits. The second merges accesses that are the same field and the same outer affine coordinates into one advancing innermost data stream. Semantic stores remain required output streams.

The compiler enforces:

```text
transport_floor_lines <= actual_traffic_lines
```

A contradiction is a proof failure.

Examples of the structural model:

| local neighborhood | current explicit immutable access streams | affine advancing-stream floor | structural traffic ratio |
|---|---:|---:|---:|
| single-field 3-D 7-neighbor cross | 7 | 5 | 1.40 |
| single-field 3-D 27-neighbor cube | 27 | 9 | 3.00 |

The ratio is not an exact DRAM-transaction claim. Cache-line overlap, hardware prefetch, cache residency and permutation cost belong to later physical realization. The value identifies mathematical data-stream redundancy still visible to the compiler without forcing a particular optimization.

## Periodic Region convergence

A periodic neighbor is not treated as random solely because it wraps. Within a maximal wrap class its address remains affine. 1.3.81 therefore represents interior, low-wrap and high-wrap regions by constant signed AddressFact deltas. Only a packet that crosses a class boundary returns to the general gather path.

The proof itself is cost-sensitive. A short innermost wrap does not justify a new direct Region when the existing generic episode is cheaper. This keeps the theoretical structure from becoming physical proof overhead.

## General and Tensor

General static causal Regions count emitted memory facts during code generation. Their outward work price is the larger of front-end instruction transport and memory-traffic resource cost. Tensor exposes traffic as a derived resource bottleneck from the existing schedule facts.

Neither path creates another scheduling graph.

## Deliberately unmaterialized facts

1.3.81 records cross-packet affine stream identity but does not force register sliding. A register permutation can cost more than a load already satisfied by cache.

It also does not force layout conversion. A copy/transpose that costs a full input pass is physical work and is incorrect as a universal response to gather.

Time remains the existing General Rank-N causal/recurrence authority. A second Field temporal scheduler would duplicate structure rather than converge it.

These are not compatibility gaps. They are cases where a mathematical relation exists but no universally cheaper machine realization has been proved.
