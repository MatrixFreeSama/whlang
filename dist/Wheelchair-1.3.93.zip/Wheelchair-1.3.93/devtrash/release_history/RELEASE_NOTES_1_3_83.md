# Wheelchair 1.3.83 Release Notes

## Mutable StateFact Causal-Lifetime Ownership

1.3.83 fixes a compiler ownership error in General `iterate` lowering. 1.3.82
addressed mutable state only by local state ordinal. Independent non-affine
`iterate` fragments could therefore publish the same absolute state and
next-version addresses while the causal runtime correctly executed them at the
same time.

1.3.83 removes the shared mutable-state arena instead of protecting it with a
lock. Mutable state now follows the causal execution that owns it:

```text
causal execution
    |
    +-- current StateFact
    +-- next-version StateFact
    |
    `-- frame dies at causal return
```

The existing execution stack is the physical authority. Each scalar state owns
16 bytes in that frame: eight bytes for the current version and eight for the
next version. Concurrent executions already have disjoint stacks; sequential
causal episodes reuse the same offsets after death.

There is no mutex, spin lock, state owner table, worker identity, ready queue,
work stealing, state scheduler, or parallel-language route.

## Correctness evidence

A four-branch non-affine mutable recurrence with two u64 states per branch is
run twenty times under four-CPU affinity. 1.3.83 is bit-exact on every run.
The same probe compiled by 1.3.82 produces multiple different outputs because
simultaneous branches write the same shared state slots.

## Physical effect

For that probe, each live branch mathematically requires two current u64 values
and two next-version u64 values: 32 bytes. Four simultaneous branches therefore
require 128 bytes of state payload. 1.3.83 realizes exactly one 32-byte local
frame per live execution. It does not reserve a permanent state copy for every
source `iterate` binding.

The correction preserves real concurrency. On the validation host, the same
four independent non-affine recurrences at two million updates each measured
about 35.6 ms with one allowed CPU and 17.2 ms with four allowed CPUs in one
sampled run set. This measurement is evidence that the fix does not serialize
the branches; correctness, not timing, is release authority.

## Preserved architecture

General remains a causal language path, not a parallel DSL. Causal readiness,
Physical Reality, cost-gated outward materialization, Region contraction,
Traffic Reality, CoordinateFact aging, strict floating-point authority, and the
absence of runtime CPU-location queries remain unchanged.
