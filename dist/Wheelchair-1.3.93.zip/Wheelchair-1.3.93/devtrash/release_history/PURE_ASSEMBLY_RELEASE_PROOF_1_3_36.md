# Wheelchair 1.3.36 Pure-Assembly Release Proof

The production compiler/runtime path remains handwritten x86-64 assembly plus shell build orchestration. Structured mathematics is compile-time semantic construction in `compiler/surface_lowerer_x86_64.S`; it does not add C/C++, LLVM, Python, libm, BLAS, LAPACK, a JIT, or a second mathematical runtime.

Structured Facts are erased as runtime objects: scalar carriers become ordinary old compute bindings / ValueFacts before physical realization.
