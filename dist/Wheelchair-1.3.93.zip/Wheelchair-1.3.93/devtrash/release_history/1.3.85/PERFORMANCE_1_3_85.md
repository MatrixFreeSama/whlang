# Performance 1.3.85

1.3.85 primarily deepens physical authority rather than changing the current single-domain x86 hot path.

On the release host, all five admitted CPUs are inside one visible NUMA node and one visible L3 domain. The `mass3`, `chem6`, and `rigid7` whole-episode probes compiled by 1.3.84 and 1.3.85 are byte-identical for each corresponding program. Therefore the generated-program acceleration on these probes is **0% by construction**.

An interleaved 15-repetition wall-time check produced a geometric-mean 1.3.85/1.3.84 speedup of about `0.9911x`. Because the corresponding executables are byte-for-byte identical, that difference is measurement/environment noise rather than a generated-code regression or speedup. Raw data are under `devtrash/benchmarks/silicon_domain_1385/`.

The new domain graph matters when the admitted execution set spans distinct locality domains, or when a future spatial target exposes placement/routing domains. This release does not fabricate such a result on a host where no relevant cross-domain choice exists.
