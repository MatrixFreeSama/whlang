# Silicon Domain Graph 1.3.85

Wheelchair now closes mathematical structure against exposed silicon space:

```text
mathematical / causal structure
        -> Physical DAG
        -> Traffic + Region + lifetime + GroupFact
                       x
           exposed silicon domains
        -> target realization
```

## What the target may contribute

On current x86-64 the compiler records architectural sharing facts: threads per core, cores/logical contexts per package, and the logical-context widths sharing L1D, L2, and L3. These facts describe hierarchy and capacity. They do not claim physical die coordinates or wire distance.

`locality_domain_execution_ceiling` is the intersection of the externally admitted CPU set and the exposed LLC sharing width. It is immutable target geometry discovered at compile time, not free-capacity accounting.

## What remains authoritative

- Causal depth owns realization time.
- Traffic/Region facts own spatial coupling.
- The silicon-domain graph supplies the physical boundaries across which that traffic would travel.
- Fact lifetime owns storage residency.
- GroupFact owns multiplicity, degraded only by exposed target capacity.

Target topology may constrain a realization. It cannot alter program meaning or create a second program graph.

## Hard exclusions

Wheelchair does not infer geometric adjacency from CPU numbering. It does not ask which core is idle, migrate work toward a recipient, maintain a ready queue, or introduce a runtime topology autotuner. FPGA/ASIC realization remains a future consumer of the same facts, not a new source language.
