# Architecture Aging 1.3.85

1.3.85 does not add a new backend family. It ages target knowledge into the existing Physical Reality authority.

The important deletion is identity-based silicon policy. A CPU name is no longer allowed to choose the physical profile. Exposed facts are consumed directly. The same rule applies forward to FPGA and ASIC work: device identity may provide facts, but it may not become an algorithm or execution-route selector.

The old source-size affinity crossover is deleted rather than preserved as compatibility behavior. Unknown spatial information stays unknown. This keeps the architecture convergent: one Physical DAG, one Physical Reality, one target fact algebra.
