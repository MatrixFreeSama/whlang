# Wheelchair 1.3.85 Release Notes

## Silicon-space closure

1.3.85 extends Silicon Reality from resource presence to an exposed silicon-domain graph. The Physical DAG remains the only program graph. Target topology contributes physical capacity and locality boundaries only.

The x86 compiler now derives:

- SMT width and package logical/core counts from architectural topology leaves;
- L1D/L2/L3 sharing widths from deterministic cache topology;
- a locality-domain execution ceiling from the intersection of the externally admitted CPU set and the exposed LLC sharing domain.

Traffic/Region facts and the silicon-domain graph are therefore considered together during realization. Unknown die geometry remains unknown rather than being guessed from core numbers.

## Named profile removal

The `AuthenticAMD + Family 25 + Model 17` execution-profile branch is removed. Vendor/family/model remain audit metadata only. AVX-512 and AVX2 physical carrier facts are derived from exposed ISA resources and the compiler's actual hot-scan footprint.

The separate generic/Zen4 outward-materialization selector is collapsed into one Linux/x86-64 Physical Reality price. No device-name algorithm route survives.

## Cleanup and repair

The obsolete 32 MiB source-size affinity crossover and its dead reporting state are removed. Compiler placement remains external to Wheelchair instead of being toggled by source size.

A duplicate `syscall` after `mbind` is removed. Previously a successful bind could immediately execute an unintended second syscall and lose the success state.

## Anti-DSL boundary

No HLS kernel language, worker/task model, fixed tile, fixed PE count, runtime topology scheduler, source workload selector, or second semantic IR is introduced. General, Tensor, and Field continue to consume the same Physical Reality.
