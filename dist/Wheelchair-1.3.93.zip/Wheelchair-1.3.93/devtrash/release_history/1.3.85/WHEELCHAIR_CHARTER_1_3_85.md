# Wheelchair Charter 1.3.85

Structural execution is closed over both mathematical structure and exposed physical space.

1. Mathematical and causal facts remain semantic authority.
2. Silicon topology contributes realization cost and capacity, never semantics.
3. Traffic is evaluated against exposed physical-domain boundaries.
4. Unknown die geometry is not guessed.
5. Vendor/model names may describe a target but may not select an execution algorithm.
6. No fixed PE count, tile, pipeline depth, worker pool, ready queue, work stealing, runtime topology autotuner, HLS kernel route, or target-private semantic IR is admissible.
7. Resource release remains recipient-blind.
8. The optimization objective remains convergence of real physical work toward the mathematical-physical lower bound, not occupancy.
