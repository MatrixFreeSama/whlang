# Pure Assembly Release Proof 1.3.85

The production compiler/runtime path remains handwritten x86-64 assembly with direct ELF emission. The new silicon-domain discovery is implemented inside the assembly compiler/driver and uses architectural CPUID/cache-topology facts plus existing Linux affinity/NUMA interfaces.

No C, C++, LLVM, JIT, Python, HLS compiler, FPGA SDK, device runtime, worker pool, task scheduler, or topology autotuner is linked into production binaries. Python remains confined to release validation/benchmark material under `devtrash/`.

`compiler/silicon_reality.inc` and `compiler/physical_reality.inc` remain the single architectural authority. `topologyc --silicon-contract` is emitted directly by the production assembly compiler.
