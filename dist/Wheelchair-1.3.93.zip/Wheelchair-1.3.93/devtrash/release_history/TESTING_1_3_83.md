# Testing 1.3.83

The current release authority contains 16 tests.

The new `test_mutable_statefact_1383.sh` gate verifies:

- the shared General mutable-state arena is absent;
- current and next-version state are execution-local;
- no lock, state owner manager, work stealing, or parallel-DSL repair exists;
- a four-way, non-affine, mutable recurrence is bit-exact for 20/20 four-CPU runs;
- the generated target contains a 32-byte local frame for the two-state probe;
- generated state traffic is R15-relative rather than absolute shared state.

All retained 1.3.78 through 1.3.82 release gates remain current unless explicitly
archived by the release closure test.
