# Transport / issue orthogonality — 1.3.93

1.3.93 repairs one Physical Reality conflation introduced when Traffic Reality entered the Tensor schedule in 1.3.81.

The compiler had one `schedule_bound_ticks` value serving two different physical questions:

1. the total cost/bottleneck of realizing a body, where traffic is a valid resource;
2. the number of independent arithmetic recurrence carriers worth keeping live, where transport cost is not a dependency or issue-width fact.

For a lightweight reduction, line-equivalent traffic could therefore raise the total schedule bound and accidentally reduce the recurrence carrier count from two to one. The emitted loop then advanced eight elements through one accumulator instead of sixteen elements through two independent accumulators.

1.3.93 keeps the existing total bound and adds one narrower fact:

```text
issue/dependency resources -> schedule_issue_bound_ticks -> recurrence carriers

issue/dependency resources + Traffic Reality
    -> schedule_bound_ticks
    -> total physical cost / outward materialization / placement
```

Traffic is not removed. It may still be the reported total bottleneck and still prices transport. It simply no longer owns arithmetic recurrence width.

There is no Tensor-reduction name check, input-size threshold, carrier candidate table, runtime bandwidth probe, or compatibility path.
