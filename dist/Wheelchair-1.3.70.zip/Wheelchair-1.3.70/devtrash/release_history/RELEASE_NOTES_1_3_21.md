# Wheelchair 1.3.21 — Physical ValueFact Transport Sparsification

Wheelchair 1.3.21 strengthens the existing Physical Reality / Physical DAG implementation. It does not add a transport backend or a workload-specific fast path.

## Transport is no longer implied by a semantic boundary

For resident floating causal state, the compiler now derives the final effective consumer of every old-version ValueFact after selected episode-CSE subtrees have been removed from the update-time use graph. When a next-version result is complete and its matching old authority has no future consumer, the anonymous result carrier is moved directly into that old authority. The old carrier then becomes the next-version authority for the following timestep.

The existing `state_temp` handoff remains only where causality still forbids overwrite. It is no longer the default consequence of choosing transient next-version realization.

## Deleted fixed FP-state residency policy

The historical `G_PHYS_FP_RESIDENT_MAX=6` rule is removed. Resident old-state capacity is derived from the actual target XMM carrier geometry. Persistent next-version carriers are admitted only while they remain physically disjoint from already-owned carriers. A collision or anonymous-carrier exhaustion releases that physical candidate and retries the same DAG AOT; no state-count threshold or workload identity participates.

## Probe results

`chem6` remains only a pressure probe. Its hot loop changes from 89 to 59 instructions while preserving 15 `vmulsd` operations and the exact final IEEE-754 bits. The previously visible six-state `state_temp` handoff disappears from the hot loop.

The independent `ring8` causal test changes from 82 to 42 hot-loop instructions. On the validation host, 10,000,000 steps improved from roughly 68.8 ms to 52.0 ms in the direct before/after comparison. These timings are host-specific evidence, not universal language guarantees.

## No new private route

There is no chemistry matcher, ring matcher, state-count dispatch, runtime transport manager, runtime register allocator, or alternative recurrence backend. The implementation change is a general last-consumer lifetime rule inside the existing Physical Reality.
