# Wheelchair 1.3.57 ShapeFact-N

## Purpose

`ShapeFact-N` is the single logical-shape authority introduced in 1.3.57.  It describes mathematical space only.  It does not own an executor, scheduler, SIMD width, thread policy, solver, or algorithm selector.

The irreducible sparse facts are:

- axis identity;
- extent kind (`static` or `runtime`);
- extent payload (a positive static cardinality or the identity of a runtime u64 input).

Everything else is derived.  Rank is the number of axis facts.  Row-major stride relations are derived from trailing extents.  Product cardinality is derived from all extents.  Those values are deliberately not serialized as duplicate compatibility fields.

## One physical root

ShapeFact-N does not create one physical executor per logical axis.  A Tensor consumer may collapse the supported logical shape onto one physical product coordinate `q`.  The current Tensor realization consumes one runtime extent fact in the leading logical axis plus an arbitrary static suffix.  This is a Tensor-consumer capability boundary, not a ShapeFact-N semantic limit.

The generic Surface validator contains no limit on runtime-extent count or position.  The current consumer gate is separate (`s_tensor_shapefact_prepare`), so a future consumer can accept more runtime extent facts without changing the ShapeFact schema or creating `DynamicTensor2`.

## Sparse convergence

The old root compatibility scalars `rank_n_product` and `rank_n_source_rank` are removed.  `rank_n_product_patch`, `RUNTIME_RANK_N_PRODUCT_OFF`, and the old `__rankn_q` spelling are also removed from production authority.

Human Surface now emits one sparse root object:

```text
shape_fact_n.axes[]
    axis name
    extent fact
```

Base and derived Tensor physicalizers consume this same authority.  Base native512/native256 accept the rank-1/product-1 subset they can physically realize.  Derived native512/native256 consume productized ShapeFact-N.  No alternate human-surface descriptor is generated for direct `topologyc` invocation.

## Runtime extent identity

A runtime extent is no longer privileged by the source spelling `n`.  The Surface records the declared extent identity and the frontend resolves it against the canonical input relation.  `n`, `batch`, `rows`, or another declared u64 input are semantically equivalent when the same shape is described.

The release proof compiles structurally identical Rank-3 programs differing only in the runtime extent spelling (`n` versus `batch`) and requires their final AOT ELF files to be byte-identical.

## Existing architecture retained

ShapeFact-N reuses the existing AST, Tensor DAG, coordinate compression, affine induction, reduction/contraction, Physical Reality, AVX2/AVX-512 physicalization, and single physical execution root.  No new runtime scheduler, fallback backend, nested-loop executor, or compatibility route is introduced.

The current unsupported case `rows × cols` with both extents runtime remains rejected by the Tensor consumer.  1.3.57 does not claim multi-runtime Tensor realization; it makes the shape authority extensible enough that adding such a consumer later does not require another shape architecture.
