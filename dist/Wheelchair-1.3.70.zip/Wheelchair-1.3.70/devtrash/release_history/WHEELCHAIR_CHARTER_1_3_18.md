# Wheelchair 1.3.18 Charter

## Emergent Outward Expansion

Wheelchair owns work, never silicon. 1.3.18 strengthens that rule by removing the remaining equation `ready == must create an OS execution context`.

Semantic independence and physical execution-context materialization are different facts. A causal subtree may be independent and therefore legally executable in parallel without being large enough to justify a separate `clone -> exit -> wait4` lifetime. The semantic graph is never changed by resource supply.

## No hard-coded expansion condition

Production expansion must contain no fixed element-count, chunk-count, state-count, instruction-count, cycle-count, wall-time or executor-count threshold whose crossing means "clone now".

Expansion is one ordinary Physical Reality choice between two legal realizations of the same causal tree:

```text
Local continuation
Outward execution
```

The selected realization is the one with lower proved physical cost on the target profile.

## AOT physical facts only

The compiler selects a deterministic execution-substrate materialization price from the existing target Physical Reality profile during AOT compilation and converts it to the same physical tick domain used by existing scheduling facts. Tensor work cost is derived from the existing schedule bound, vector width and unroll. Field work cost is derived from the final physical operation graph.

Generated programs receive immutable physical facts. Runtime must not query current CPU availability, CPU utilization, free workers, credits, donor state or recipient state in order to decide expansion.

Changing host/OS execution-context cost may move the profitable expansion boundary naturally. Language semantics do not change.

## Canonical numerical tree remains authoritative

Choosing local continuation must not serialize a strict reduction into a different mathematical association. Tensor and Field local execution recursively reproduce the same canonical pairwise tree used by outward execution. Only execution lifetime changes; numerical topology does not.

## External silicon authority remains binding

1.3.18 does not restore any resource pool. The following remain forbidden:

- capacity credits or claim/release,
- free-core/free-worker inventory,
- runtime CPU pinning for causal work,
- work stealing,
- global ready queue,
- donor/recipient selection,
- runtime resource-availability expansion query.

Completed outward execution still terminates. No resource is returned to Wheelchair.

## General causal regions

General already performs AOT causal-region coarsening. 1.3.18 preserves that structure and does not add a second expansion manager. Future General work remains unmaterialized until true dependencies are ready.

## Physical objective

The target is not maximum number of runnable tasks. The target is minimum unnecessary physical work:

```text
independence permits expansion
profitability chooses realization
resource availability chooses neither
```

A tiny independent subtree may stay local because creating an OS task would cost more physical work than computing it. A heavy subtree may materialize outward because local continuation would cost more. No magic work-size boundary exists.
