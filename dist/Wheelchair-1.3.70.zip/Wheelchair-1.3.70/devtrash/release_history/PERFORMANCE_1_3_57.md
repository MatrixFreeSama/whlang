# Wheelchair 1.3.57 performance note

ShapeFact-N is primarily an architectural convergence release, not a benchmark-targeted optimization.

## Compiler build cost

On the release host, seven alternating clean full-build samples measured:

- 1.3.56 median: approximately 0.817 s
- 1.3.57 median: approximately 0.832 s

The new median is about 1.8% slower.  The cost comes from the shared ShapeFact parsing/validation authority and from allowing base and derived physicalizers to consume the same canonical shape.  This is reported as a cost, not hidden as noise.

## Newton-Jv code shape

The mature Newton-Jv source previously used the base rank-1 path.  Under ShapeFact-N, rank-1 human Tensor programs share the same logical shape authority used by productized Rank-N physicalization.

For the protected Newton-Jv probe:

- 1.3.56 generated executable: 9,929 bytes
- 1.3.57 generated executable: 9,377 bytes
- 1.3.56 generated RX segment: 1,737 bytes
- 1.3.57 generated RX segment: 1,185 bytes

The generated execution segment is therefore approximately 31.8% smaller.  Numerical output remains bit-identical for the release oracle.

A pinned single-core host diagnostic at n=10,000,000 measured medians of roughly 7.73 ms (1.3.56) and 7.50 ms (1.3.57), around 3% in favor of 1.3.57 in that run.  Because host frequency and scheduling remain external, this is not claimed as a universal runtime speedup.  The robust claim is the smaller generated code with preserved result bits.
