# Wheelchair 1.3.16 Whole-Episode Physical DAG evidence

Authority host: AMD EPYC 9V74 80-Core Processor virtualized as 5 single-thread vCPUs. Timings are CPU0-pinned whole-process wall medians from nine interleaved runs. C and Fortran references use GCC/GFortran 14.2-class strict FP flags (`-O3 -march=native -mtune=native -fno-fast-math -ffp-contract=off`, with `-fprotect-parens` for Fortran). These are structure-validation measurements, not a claim of universal language superiority.

The release fixes two generic failure modes exposed by unrelated simulation probes:

1. **Pressure admission cliff.** A deeper seven-state episode could remain register-native with two or three hot constants, then fall to the generic stack evaluator when one additional constant consumed the last anonymous XMM carrier. 1.3.16 profiles peak anonymous temporary pressure AOT and gives state, shared ValueFacts, constants and anonymous temporaries one carrier authority. Constant count no longer selects a backend.
2. **Fragmented simultaneous-update DAGs.** Repeated strict-order old-version subtrees were formerly rebuilt independently inside each next-state expression. 1.3.16 builds an exact whole-episode CSE domain, retains only a parent/child antichain, separates ready ValueFacts from future identities, and exposes retained facts through the existing Physical DAG source rules.

The strongest structural result is the full seven-state rigid-body probe: 1.3.15 emitted the generic stack evaluator and required about 100.49 ms for 1M steps on this host; 1.3.16 remains in the VEX Physical DAG and requires about 17.29 ms, a 5.81x same-host improvement. The shared-quaternion-norm probe reaches the same arithmetic counts as the strict C/Fortran references (38 multiply, 19 add, 4 subtract in the hot episode).

The six-species reaction network is deliberately reported without spin: hot multiply count falls from 33 to 25, but current whole-process wall time is about 10% slower than 1.3.15 on this host because retained shared facts still consume carrier/move budget. That remaining profitability problem is not hidden behind a workload-specific bypass and is left for the same Physical Reality architecture to solve in later releases.

See `PERFORMANCE_1_3_16_SIMULATION.csv` and `PERFORMANCE_1_3_16_PHYSICAL_DAG.csv` for the authority data.
