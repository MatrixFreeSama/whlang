# Wheelchair 1.3.63 architecture aging: GroupFact convergence

Automatic Grouping is no longer a layer wrapped around the historical body/unroll and carrier plan. The resource scheduler writes `group_body_factor` and `group_carrier_factor` directly. Group rank/form closure, canonical Tensor physicalization, outward-materialization geometry and runtime patching consume those same facts.

The four Tensor physicalizers no longer own `physical_plan_group_body`, `physical_plan_group_carriers` or `physical_group_form` shadow state. Backend probe results remain independent realization witnesses only, so they can reject a mismatch without becoming a second scheduling authority.

The runtime contract is renamed around GroupFact (`group_body_factor_patch`, `group_carrier_factor_patch`). Legacy `unroll_count_patch`, `reduction_carriers_patch`, `RUNTIME_UNROLL_OFF`, `RUNTIME_CARRIERS_OFF`, `schedule_unroll` and `schedule_carriers` are removed from production authority. The schedule diagnostic schema advances to `topology.resource-schedule/2` and exposes only Group-native structural factors.

No runtime group manager, workload selector, fixed group-size threshold, compatibility vectorizer or new algorithm family is introduced. Vector width remains target lane geometry; Scalar and Vector remain degradations of the same GroupFact.
