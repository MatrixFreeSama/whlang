# Wheelchair 1.3.23 Charter — Composition-Closed Transition Power

## Authority

1.3.23 strengthens the existing Physical Reality / Physical DAG. It does not introduce a recurrence backend. A counted recurrence may be algebraically contracted only when the published-result causal backward slice proves a transition family closed under composition.

For the first admitted family in 1.3.23, strict wrap-u64 semantics prove

```text
F(x) = A*x + B  (mod 2^64)
F2 o F1 = (A2*A1, A2*B1+B2)
```

so `F^N` can be materialized by binary composition. The proof is expression-algebraic: nested `add/sub` and literal scaling are collected into coefficients. State count, declaration order, workload name, benchmark name, or repetition count are not admission criteria.

## Backward-slice law

The physical program is derived from the published result's causal slice, not from every source-level state declaration. Semantic states outside that slice may remain meaningful source objects yet contribute zero physical work to the published result.

## Hard prohibitions

```text
FIXED_TWO_STATE_AFFINE_ROUTE=0
FIXED_AFFINE_AST_MATCHER=0
TRANSITION_POWER_STATE_COUNT_ROUTE=0
TRANSITION_POWER_REPEAT_MAGIC_THRESHOLD=0
RUNTIME_TRANSITION_POWER_MANAGER=0
WORKLOAD_SPECIFIC_TRANSITION_POWER_ROUTE=0
```

If closure cannot be proved, the ordinary Rank-N causal register-DAG remains authoritative.
