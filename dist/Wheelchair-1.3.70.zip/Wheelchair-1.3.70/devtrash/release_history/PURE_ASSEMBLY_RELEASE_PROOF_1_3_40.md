# Pure assembly release proof 1.3.40

Production compiler/runtime sources remain handwritten native assembly (`.S` / `.inc`) and linker scripts. C, Python and GMP occur only in `devtrash/` validation and benchmark material.

The `P > 64` Fourier multiplication implementation is contained in `runtime/rankn_precision_physical_x86_64.inc` and uses local x86-64/x87/AVX2 instructions. It does not call FFTW, libm, GMP, a JIT, a planner, a dynamic allocator, a scheduler or an executor.

`bin/wheelchairc` and `bin/whexc` are static executables on the release machine (`ldd` reports `not a dynamic executable`). The release gate scans production sources and binaries for FFTW references and the deleted multiplication symbols.

The build system also rejects the removed scalar-only wide source and dedicated fixed-width floating authorities.
