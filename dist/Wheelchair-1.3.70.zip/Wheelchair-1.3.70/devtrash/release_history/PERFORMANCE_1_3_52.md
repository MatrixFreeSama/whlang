# Performance 1.3.52

## Full self-build

Same host, same tree class, repeated clean `./build.sh` wall-clock measurements:

- 1.3.51 samples (s): 1.057276, 1.060587, 1.006139, 0.979758, 0.982103
- 1.3.51 median: 1.006139 s
- 1.3.52 samples (s): 0.789204, 0.797701, 0.828031, 0.850599, 0.804347, 0.802506, 0.805688
- 1.3.52 median: 0.804347 s
- throughput ratio: 1.2509x
- wall-time reduction: 20.06%

The gain comes from removing historical proof replay and dead alias construction from the normal production build, not from a new optimizer.

## Generated program execution

The mature Newton-Jv generated ELF is byte-identical across 1.3.51 and 1.3.52. Consequently its structural execution-speed change is 0%. Paired wall-clock medians at n=100,000,000 differed by roughly 1.9%, but identical machine images make that difference host noise rather than a release performance claim.

## Release footprint

Canonical `bin/` payload:

- 1.3.51: 7,383,384 bytes
- 1.3.52: 5,325,312 bytes
- reduction: 2,058,072 bytes, 27.88%

The dominant removal is the two dead wide compatibility aliases.
