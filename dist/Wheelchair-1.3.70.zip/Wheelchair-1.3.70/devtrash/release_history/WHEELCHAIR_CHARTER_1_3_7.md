# Wheelchair 1.3.7 Charter — Tensor Physical Reality Completion

## Prime rule

A Tensor expression tree is a semantic description, not a machine-work schedule. If two reachable Tensor consumers require the same still-valid physical fact, source-tree separation does not authorize a second realization.

1.3.7 extends the Physical Reality doctrine into the high-pressure `f64` Tensor native512 path. The compiler must decide persistence from proven future use, lifetime and physical profitability, not from recursive-emitter convenience.

## Required invariants

- AOT only; direct handwritten native code generation remains sovereign.
- No LLVM, MLIR, JIT, runtime autotuner, runtime fact manager or runtime residency manager.
- No work stealing, global ready queue, central scheduler or recipient-aware resource handoff.
- Resource release is recipient-blind: a fact dies immediately after its last proven consumer.
- No workload name, benchmark size, coefficient value, field name or variable name may select an optimization.
- Strict FP remains order sovereign. Tolerant FP may use only contract-legal reassociation/contraction.
- Persistent Tensor registers are admitted by future-use/profitability proof. A dead or one-use fact does not receive long-lived authority merely because a cache slot exists.
- Affine facts are selected by measured compile-time structural reuse. Coefficients have no semantic privilege.
- Exact constants are selected by exact-bit identity and weighted use, under the actual register budget of each physical profile.
- Three-operand ISA forms must not inherit unnecessary two-address copies.
- Native256 remains a truthful historical physicalization authority where the 1.3.7 native512 machinery is not yet equivalent; no fake AVX2 completion claim is permitted.

## Physical profile rule

The fact system is common, but hardware resource geometry is not flattened:

- native512 base profile: 10 persistent CSE/induction ZMM slots + 6 constant ZMM slots;
- native512 wide profile: 14 persistent CSE/induction ZMM slots + 2 constant ZMM slots;
- native256: historical authority preserved without pretending the 32-register ZMM strategy maps onto a 16-register YMM bank.

## Probe doctrine

The historical fluid-solid coupling workload is a diagnostic probe only. Compiler source contains no fluid/solid/FSI dispatch. A release may lose that benchmark and still be structurally valid; it may not win by recognizing the benchmark.
