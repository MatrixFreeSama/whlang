# 1.3.27 Carrier-Lifetime Correctness Closure

## Failure exposed in 1.3.26

In a regular Field episode, cache slot A could be assigned SIMD0 as its resident carrier. A later cache slot B that required a stack reload authority was still lowered through SIMD0 as an implicit transport scratch:

```text
A -> SIMD0                 resident authority
B -> SIMD0 -> stack        old preload transport
```

The second line destroyed A before arithmetic. With distinct inputs, a pressure-like product `0.4 * A * B` could become `0.4 * B * B`.

This was a phase-lifetime alias, not floating-point error and not a store formula error.

## 1.3.27 closure

Resident preload is now:

```text
memory -> final resident carrier
                    |
                    +-> stack backup   only if future use crosses a clobber
```

Nonresident preload uses a carrier that is semantically unowned during the preload phase and releases it before arithmetic begins.

The old global backup flag is deleted. Final load position and clobber position determine whether reload authority is physically necessary.

## Oracle

The release fixture uses two deliberately different 16×16×16 input fields. 1.3.27 AVX-512 and AVX2 both produce:

```text
checksum_f32_bits=0x4441ae02
```

and a byte-identical output field.

## Non-regression boundary

The established real-sparse no-store kernels `miniamr7`, `miniamr27`, `minife_heat21`, and `clover_xacc` were compiled with the final 1.3.26 and 1.3.27 Field compilers. Their complete generated executables are byte-identical across the two releases. The repair therefore does not perturb the previously measured hot paths when no carrier-lifetime overlap exists.
