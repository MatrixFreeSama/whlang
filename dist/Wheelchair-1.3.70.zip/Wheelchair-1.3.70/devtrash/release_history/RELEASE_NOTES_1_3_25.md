# Wheelchair 1.3.25 Release Notes

Wheelchair 1.3.25 reorganizes the release into a production surface and a non-production development archive.

## Changes

- `bin/` becomes the sole production executable authority.
- Root-level duplicates of `whexc`, `wheelchairc`, `topologyc*`, and `fieldc*` are removed.
- `tests/`, `benchmarks/`, historical source trees, frozen-native snapshots, historical release documents, and old release scripts move under `devtrash/`.
- The root retains only the current release identity, current release documents, build entry point, production source trees, tools, `bin/`, and `devtrash/`.
- `build/` is treated as reproducible scratch and is not shipped in the final archive.
- `build.sh` refreshes `bin/` directly after a successful build.
- A new release-surface gate proves production can build with `devtrash/` physically absent.
- A branch firewall forbids archived source and compatibility material from regaining production authority.

## Execution identity

No compiler/runtime algorithm was intentionally changed in this release. All ten production binaries rebuilt by 1.3.25 are byte-identical to the final 1.3.24 binaries.

Therefore 1.3.25 carries forward the 1.3.24 performance characteristics while reducing architectural surface area available for future private-branch growth.
