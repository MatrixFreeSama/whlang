# Wheelchair 1.3.62

Release-layout convergence only.

- `build/` is a generated workspace and is not distributed.
- `build.sh` recreates `build/` from the shipped source tree.
- Canonical production executables remain in `bin/`.
- Automatic Grouping and all 1.3.61 compiler/runtime semantics are unchanged.
- No compatibility layer, fallback implementation, or alternate execution path is introduced.
