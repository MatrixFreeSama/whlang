# Performance 1.3.40: Native Fourier vs GMP

This report covers the final fully local production `rankn_fp_mul` implementation. FFTW is not linked or called.

## Method

- one CPU selected from the process affinity mask;
- full-width random normalized significands;
- Wheelchair calls the production assembly entry point including unpack, forward transform, pointwise square, inverse transform, carry and final product materialization;
- GMP uses `mpf_mul` at the same requested precision;
- both sides are warmed;
- alternating measurement order;
- five runs, median reported;
- benchmark source and raw CSV are stored under `devtrash/benchmarks/native_fourier_1340/`.

## Final measured points

| P bits | WC ns | GMP ns | WC/GMP time | interpretation |
|---:|---:|---:|---:|---|
| 65536 | 167479 | 102903 | 1.628 | WC slower 62.8% |
| 131072 | 341944 | 264863 | 1.291 | WC slower 29.1% |
| 262144 | 717543 | 673300 | 1.066 | WC slower 6.6% |
| 524288 | 1509053 | 1798284 | 0.839 | WC time lower 16.1% |
| 1048576 | 3273333 | 2991984 | 1.094 | WC slower 9.4% |
| 2097152 | 7139085 | 7246904 | 0.985 | WC time lower 1.5% |
| 4194304 | 14920191 | 15758964 | 0.947 | WC time lower 5.3% |

The unified authority therefore sits within roughly ±20% of GMP in the measured 262144-4194304-bit range, with several natural crossovers. Smaller wide precisions expose the fixed cost of the common Fourier realization; the architecture deliberately does not add a second multiplication algorithm to erase those local impurities.

These are machine-specific measurements, not a universal performance guarantee.
