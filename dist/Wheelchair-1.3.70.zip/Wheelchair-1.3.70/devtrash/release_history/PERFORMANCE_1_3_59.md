# Wheelchair 1.3.59 physical-plan convergence performance

Release-host diagnostic: AMD EPYC 9V74, one pinned CPU, 100,000,000 logical elements, three warmups, 21 interleaved timed runs. These numbers are host-specific diagnostics, not universal language claims.

| Probe | 1.3.58 median | 1.3.59 median | 1.3.59 / 1.3.58 | ELF bytes 1.3.58 -> 1.3.59 |
|---|---:|---:|---:|---:|
| lightweight reduction | 18.143 ms | 18.072 ms | 0.9960 | 8,721 -> 8,721 |
| mature Newton-Jv | 65.925 ms | 65.379 ms | 0.9917 | 9,929 -> 9,281 |
| coupled FSI | 150.153 ms | 150.528 ms | 1.0025 | 12,041 -> 10,361 |

Three-probe geometric-mean time ratio is approximately `0.99675`, or about 0.33% lower elapsed time on this host. The important convergence result is structural: the lightweight reduction keeps the historical two-body machine image byte-for-byte, while heavier rank-1 probes no longer receive an unconditional duplicate body.

The raw measurements are retained in `devtrash/benchmarks/physical_plan_convergence_1359/raw.csv` and `summary.csv`.
