# Wheelchair 1.3.57 pure-assembly release proof

ShapeFact-N is implemented in handwritten x86-64 assembly (`compiler/shapefact_n.inc`, `compiler/shapefact_n_frontend.inc`, Surface and Tensor frontend assembly).  The production build continues to invoke no Python generator, LLVM backend, C compiler, JIT, bytecode VM, or interpreter.

The production executables remain static ELF64 files without an interpreter segment.  `build.sh` derives runtime offsets from native ELF symbols and verifies the ShapeFact source authority, absence of the retired product descriptor, and absence of fixed ShapeFact capacity constants.

The release gate compiles and executes ShapeFact programs through base/derived native512/native256 physicalizers and normal `whexc` dispatch.  The generated programs execute direct native machine code through the existing Tensor runtime and Physical Reality chain.
