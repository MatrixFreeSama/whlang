# Wheelchair 1.3.61 pure-assembly release proof

Automatic Grouping production authority is handwritten assembly plus declarative `.inc` constants. `compiler/topologyc_x86_64.S` owns the production GroupFact synthesizer. The Tensor physicalizers consume it directly. No generated C, LLVM, JIT, Python runtime, theorem engine, autotuner or runtime grouping service participates in target generation.

The production build still rejects Python invocation and produces static native executables with no ELF interpreter.
