# Wheelchair 1.3.69 performance note

1.3.69 is primarily a semantic-normalization release, so no universal runtime speedup is claimed.

The release gate demonstrates that several longer human forms now produce the same generated `.text` as their already-converged form: swapped integer addition, recursively nested operand-order variation, neutral-shell plus same-type-cast chains, and comparison duality. This removes duplicate semantic producers before Physical Reality sees them.

A representative strict floating whole-episode workload (`devtrash/benchmarks/general_whole_episode_1316/mass3.wh`) produces byte-identical `.text` under 1.3.68 and 1.3.69, SHA-256 `bb28c43d8c8b1251943905d59f56998483194fb4922397ad982a9415394aa578`. This is evidence that the broader proof closure did not perturb an unrelated strict-FP physical path.

The production topology compiler images grow because the handwritten proof code is now native compiler authority. The user-facing `wheelchairc` and `whexc` launchers remain byte-identical to 1.3.68. This release therefore claims stronger front-end convergence and less human-form materialization, not a general compile-time or runtime percentage improvement.

Representative downstream non-General paths were also checked against 1.3.68. `group_affine_probe.whex` produced byte-identical generated ELF (`dde7b79907071c34c2faf22e3432ed4ad10cfcc906f0b56fa0f6f5dd4d2ac15b`), and `field_surface_1218/sum.whex` produced byte-identical generated ELF (`46b0c01d91e96bb8d273a7f545d5a64095f1c270bd02ef3c6388ced2c25ed57d`). These checks support the intended architectural boundary: the new proof closure changes human General convergence without perturbing Tensor/Group or Field realization for unrelated programs.
