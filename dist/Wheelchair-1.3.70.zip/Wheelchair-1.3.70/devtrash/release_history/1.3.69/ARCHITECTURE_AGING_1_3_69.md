# Wheelchair 1.3.69 architecture aging

## Direction

1.3.69 does not add a new optimizer family. It ages the 1.3.68 human semantic representative into a proof-level convergence law on the already-typed General symbol DAG. Human spelling is allowed to disappear only before first fragment materialization and only when existing semantic facts prove zero observable change.

The authority remains the existing 64-byte symbol record. `+40` remains the canonical semantic representative and `+56` remains convergence fact storage. There is no canonical-AST copy, rewrite IR, algorithm dispatcher, pass list, runtime convergence manager, threshold, retry count, or workload route.

## New proof closure

The previous alias/exact-tree base case remains. The same closure now also admits:

- same-type cast shells around an existing immutable fact;
- integer neutral shells such as `x+0`, `x-0`, `x*1`, `x/1`, `x|0`, `x xor 0`, and zero-count shifts when the other operand is an existing representative;
- Boolean neutral shells when the non-neutral side is an existing representative;
- operand-order erasure for total commutative relations;
- comparison duality (`a<b == b>a`, `a<=b == b>=a`) over total operands;
- recursive composition of already-proved child equivalence.

The proof is deliberately not an algebra zoo. Associative regrouping remains absent. Strict floating-point arithmetic is not commuted or reassociated. State/axis/field/load/dictionary effects still do not enter this General closure unless an older authority has already reduced them to an immutable fact.

## Totality boundary

Operand order may disappear only when both sides are total semantic facts. Literals and existing immutable symbol facts are total. Exact Boolean/bit relations are total once their children are total. Integer min/max are total. Integer arithmetic is considered total as a nested expression only under the existing wrap contract; trap-sensitive nested arithmetic blocks operand-order erasure. This preserves the zero-flip rule without adding effect recovery or speculative fallback.

## Aging result

The execution chain stays one chain:

`human surface -> typed semantic facts -> semantic representative -> ValueFact / ShapeFact-N / GroupFact -> Physical Reality -> Physical DAG -> ISA`

The new capability therefore grows inside an old record and old causal path. It does not create a sibling subsystem that later needs compatibility glue.
