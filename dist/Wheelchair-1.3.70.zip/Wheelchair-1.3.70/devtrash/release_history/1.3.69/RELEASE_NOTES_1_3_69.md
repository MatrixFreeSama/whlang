# Wheelchair 1.3.69 release notes

## Proof-level human semantic convergence

The 1.3.68 semantic representative is extended rather than replaced. Before any General fragment is emitted, typed pure `compute` facts may now converge through a small proof closure instead of exact-tree identity alone.

New zero-flip relations include neutral integer/Boolean shells, same-type cast erasure, total commutative operand order, comparison duality, and recursive composition of already-proved child equivalence. The representative still lives in the existing symbol record and all consumers continue through the existing ValueFact / Physical Reality / Physical DAG / ISA path.

## Deliberate exclusions

There is no associative rewrite authority, strict-FP arithmetic commutation, algorithm-name matcher, workload route, second IR, fixed convergence round count, rewrite budget, runtime manager, JIT, or autotuner. Unproved expressions remain distinct.

## Regression

The new 1.3.69 semantic gate passes, the inherited 1.3.68 alias/exact gate passes with only its historical version assertion adapted, human-surface convergence and pure-composition convergence pass unchanged, and the Rank-N transition-power gate passes with only its historical version assertion adapted.
