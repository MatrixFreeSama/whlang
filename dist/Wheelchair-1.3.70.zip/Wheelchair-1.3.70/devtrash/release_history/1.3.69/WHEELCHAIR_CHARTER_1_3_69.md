# Wheelchair 1.3.69 charter

1. Human source is not a performance authority. Different legal spellings may converge only through proven semantic equality.
2. Semantic zero-flip is a hard boundary. A missing proof means no convergence.
3. New capability must grow into the existing Fact / Physical architecture. A second canonical AST, optimizer IR, algorithm zoo, or compatibility backend is forbidden.
4. Convergence is structural, not workload-named. Newton, FFT, Fibonacci, stencil, Krylov, sort, or any other application name is not an admission key.
5. No fixed convergence rounds, rewrite budgets, source-size thresholds, or runtime convergence managers are permitted.
6. Strict floating-point order remains semantic fact. No associative regrouping or arithmetic commutation is authorized by this release.
7. Effects and trap-sensitive order are preserved unless totality is proven from existing facts.
8. Physical realization remains downstream: semantic representative -> ValueFact / ShapeFact-N / GroupFact -> Physical Reality -> Physical DAG -> ISA.
