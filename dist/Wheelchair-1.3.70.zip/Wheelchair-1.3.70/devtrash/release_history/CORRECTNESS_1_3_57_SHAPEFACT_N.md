# Wheelchair 1.3.57 ShapeFact-N correctness proof

The permanent release gate is `devtrash/release_tests/test_shapefact_n_1357.sh`.

It proves the following invariants:

1. `compiler/shapefact_n.inc` and `compiler/shapefact_n_frontend.inc` contain no `MAX`, `CAP`, or `LIMIT` capacity authority.
2. The retired `rank_n_product`, `rank_n_source_rank`, product patch, product offset, and `__rankn_q` compatibility identities do not exist in production compiler/runtime/tool sources.
3. ShapeFact semantic validation is separate from the current Tensor-consumer capability gate.
4. Base native512 and native256 compile and execute a rank-1 ShapeFact whose runtime extent is named `batch`.
5. Derived native512 and native256 compile and execute a Rank-3 `batch × 3 × 5` ShapeFact with identical checksum bits.
6. `whexc` compiles the same Rank-3 program through normal production dispatch.
7. Renaming the runtime extent from `batch` to `n` yields byte-for-byte identical AOT ELF output.
8. Rank-80 remains executable, proving ShapeFact does not reintroduce a rank table ceiling.
9. Two runtime extents are rejected by the current Tensor consumer rather than silently advertised as implemented.
10. Mature Newton-Jv retains the exact expected numerical checksum after the shape-authority replacement.

All inherited mathematics, high-precision, RootRelation, Field, AVX2, ValueFact, Tensor Physical Reality, sparse materialization, human-surface convergence, structural-capacity, optional-iteration, and 1.3.54–1.3.56 aging gates remain green.
