# Wheelchair 1.3.45 Human-Shell Bridge

This release connects already-existing authorities rather than creating a new
algorithm family.

## Existing facts reused

- MatrixFact: compile-time structured coefficient data.
- `contract`: selected-axis compile-time reduction/expansion.
- field neighborhood addressing: canonical signed static offsets.
- scalar field AST and Physical DAG: unchanged final authority.

## Surface-only bridge

The field human shell may carry a MatrixFact through a compile-time `let`.
`mget` is permitted to wait for lexical contraction axes to become constants.
Affine field coordinates are normalized only when all non-domain-axis parts are
AOT-static integers.

Every bridge object must disappear before canonical field emission.

## Non-goals

No FEM-specific syntax, no runtime matrix, no new tensor backend, no new field
opcode, no algorithm selector.
