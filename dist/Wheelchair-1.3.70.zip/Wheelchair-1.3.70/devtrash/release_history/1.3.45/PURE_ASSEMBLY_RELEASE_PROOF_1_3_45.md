# Pure Assembly Release Proof 1.3.45

The 1.3.45 implementation change is confined to the handwritten assembly
surface lowerer:

- `compiler/field_surface_lowerer_x86_64.inc`
- `compiler/surface_lowerer_x86_64.S`

No C/LLVM/JIT/Python production path is introduced. The bridge is compile-time
only and erases before the existing canonical field backend.
