# Correctness 1.3.45 — Human-Shell Static Structure Bridge

Release invariant:

`compact WH shell -> existing static facts -> existing scalar field graph`

The bridge adds no runtime mathematical object and no backend opcode.

Verified properties:

1. `let K = matrix(...)` is accepted by the field shell only as a compile-time
   MatrixFact.
2. `mget(K, cell, node)` may remain surface-deferred only until selected-axis
   contraction substitution makes both indices static.
3. Field coordinates may contain the domain axis plus/minus AOT-static integer
   expressions such as `x - cell + node`; the shell folds them to the existing
   signed integer delta representation.
4. Compact and hand-expanded probes produce byte-identical ELF files.
5. Existing general structured lets, including RootFact, remain owned by the
   sovereign general surface.
