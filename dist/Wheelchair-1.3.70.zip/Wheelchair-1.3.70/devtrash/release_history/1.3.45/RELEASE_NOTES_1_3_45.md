# Wheelchair 1.3.45 Release Notes

Wheelchair 1.3.45 is a human-shell-only bridge release. It does not add a new
mathematics algorithm, field opcode, runtime object, execution backend, or ISA
escape path.

The existing 1.3.44 authorities were already sufficient:

- selected-axis `contract(axis in N, expr)`;
- dimension-bearing compile-time `MatrixFact` and `mget`;
- multi-axis field-neighborhood addressing;
- the existing scalar field canonical graph and Physical Reality.

The missing piece was surface composition. A WH field program may now keep a
compile-time `matrix(...)` as a static `let`, use contraction axes inside
`mget`, and use those same static axes in affine neighborhood coordinates. The
surface substitutes and folds those facts before canonical emission.

The release gate proves byte-identical ELF output between a compact source:

```text
contract(cell in 2,
  contract(node in 2,
    mget(K,cell,node) * u[x-cell+node,y,z]))
```

and its hand-expanded four-term strict source.
