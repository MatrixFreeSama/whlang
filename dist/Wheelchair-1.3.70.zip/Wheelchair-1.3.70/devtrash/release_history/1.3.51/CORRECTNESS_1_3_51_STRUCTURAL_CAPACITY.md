# Wheelchair 1.3.51 Structural Capacity Correctness

## Invariants

1. No 1.3.51 change adds a source semantic, mathematical operator, algorithm family, ISA route, scheduler or compatibility path.
2. Production JSON node storage is derived from the actual source allocation rather than a fixed 65,536-node table.
3. Production Tensor binding metadata is derived from the actual binding count rather than a sixteen-binding table.
4. General symbols and causal relations use structure-sized arenas. Causal dependencies are explicit relation edges, not a fixed node/edge table or machine-word mask.
5. The General parallel runtime owns variable N/E metadata and maps state/stack storage from actual node count.
6. Existing runtime ABI limits remain visible and shared by their consumers. Surface/frontend/runtime may not disagree about a retained capacity.
7. Existing final AOT image bounds remain checked; dynamic metadata is not permission to overrun the final executable slot.

## Regression oracles

The final release gate runs every inherited 1.3.50 gate and then exercises capacities beyond the retired implementation tiers. It verifies execution for a General graph whose materialized node count exceeds 256, another graph containing 1,120 dependency edges, a canonical source containing more than 65,536 JSON nodes, and a valid source larger than 8 MiB.

Generated General parallel offset metadata must report `graph_capacity: structural` and must not publish `max_nodes` or `max_edges`. Production compiler executables remain static ELF binaries.

## Non-claims

Passing the structural-capacity probes is not a claim that the language is mathematically or physically unbounded. Allocation can fail, final AOT image storage remains finite, and unchanged lower ABIs still reject structures they cannot represent. Those are intentionally outside this aging release.
