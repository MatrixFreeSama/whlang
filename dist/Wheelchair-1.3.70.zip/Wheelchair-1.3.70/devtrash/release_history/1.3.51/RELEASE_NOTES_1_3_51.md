# Wheelchair 1.3.51 Release Notes

## Structural capacity convergence

1.3.51 is a large aging release. It adds no source-language semantic, algorithm family, runtime scheduler, ISA route, compatibility parser, or workload selector. Its only purpose is to remove implementation cardinalities that had become accidental language ceilings and to make existing structures own their real size.

Production source ingestion no longer owns an 8 MiB launcher ceiling. The native launcher and Field launcher map the actual source file, while topologyc keeps its small static source buffer only as a storage optimization and maps larger sources from their measured size. The JSON DOM used by the production Tensor/General/Field frontends is likewise materialized from actual source structure rather than a 65,536-node table.

Tensor binding metadata no longer uses a sixteen-binding parser table. The existing binding list first determines its cardinality and then receives exactly the metadata arena needed by that program. This changes storage ownership only; Tensor's current dynamic-extent semantics and physical execution authorities are unchanged.

General compile-time symbols, causal fragments and dependency relations no longer use fixed symbol, 256-fragment, machine-word visit, or fixed edge tables. Symbols are materialized from the parsed structure, dependencies are explicit deduplicated relation edges, and the causal graph owns arenas sized from its actual N/E structure. The General parallel runtime likewise no longer embeds 256 node and 1,024 edge tables. The compiler appends compact `indegree[N]`, `first_out[N]`, `entry_offsets[N]`, `edge_v[E]`, and `next_edge[E]` metadata, while runtime state pages and per-node stacks are mapped from the actual node count.

Existing lower capabilities are not fabricated. General's currently materialized runtime ABI still owns 16 inputs, 240 binding mailboxes, 64 iterate states, and 32 outputs. These values now come from one shared ABI authority, removing a historical frontend/runtime mismatch in binding storage. Field's existing 8-field, Rank-8, 128-access runtime ABI is also centralized into one authority shared by Surface, frontend, and both native256/native512 runtimes. Field's four logical VREGs, Tensor's current dynamic-axis representation, mathematical admissibility rules, and final AOT image/workspace capacities remain real boundaries.

The release gate crosses the retired implementation tiers with a General runtime graph above the old 256-node boundary, a graph with 1,120 causal edges, a canonical program above the old 65,536 JSON-node table, and a valid source above the old 8 MiB launcher ceiling. All inherited 1.3.50 correctness gates remain part of the final release proof.
