# Structural Capacity Convergence 1.3.51

## Rule

A cardinality that merely describes how much compile-time or runtime metadata a represented structure owns must be derived from that structure whenever the existing semantics already admit the structure. Increasing a magic number is not convergence; deleting the number's authority is.

1.3.51 therefore changes ownership, not meaning:

```text
source bytes                  -> measured file mapping
JSON nodes                    -> source-derived node arena
Tensor bindings               -> binding-count-derived metadata arena
General symbols               -> parsed-structure-derived symbol arena
General causal relations      -> explicit growing edge arena
General parallel metadata     -> N/E-derived compact image
General runtime state/stack   -> actual-node-count mapping
```

No new operator, type, solver, scheduler, ISA, syntax family, or execution path is introduced.

## General causal graph

The former fixed graph representation encoded capacity into unrelated machine tables. The current representation owns an explicit relation set `(source,destination)` with duplicate suppression. Topological indegree/successor facts are derived from those relations. Dependency traversal uses storage indexed by the actual symbol set rather than a fixed-width visit mask.

The generated parallel image contains a fixed executor template followed by variable metadata:

```text
executor template
indegree[N]
first_out[N]
entry_offsets[N]
edge_v[E]
next_edge[E]
region code...
```

Runtime state pages and stack slices are mapped from `N`. The runtime therefore no longer declares a maximum graph node or edge cardinality independent of the final AOT image/resource frontier.

## One authority for real ABI capacities

Some capacities remain because they are part of the current materialized runtime representation, not because the human/compiler surface should invent freedom that the runtime cannot carry. Those capacities are centralized rather than duplicated.

General currently shares one ABI authority for 16 inputs, 240 binding mailboxes, 64 iterate states and 32 outputs. Field currently shares one ABI authority for 8 fields, Rank 8 and 128 accesses. This release intentionally does not generalize those runtime records.

## Boundaries deliberately retained

The following are not claimed removed by 1.3.51:

- mathematical domain/admissibility conditions;
- current Tensor dynamic-extent semantics;
- current Field type/rank/VREG execution representation;
- architectural register and ISA constraints;
- final generated-image/workspace capacities such as the existing AOT program slot;
- finite address space, available memory and OS mapping failure.

A dormant historical standalone JSON parser may still contain its frozen table because it is not a production authority. Production compiler paths use the dynamic DOM arena.
