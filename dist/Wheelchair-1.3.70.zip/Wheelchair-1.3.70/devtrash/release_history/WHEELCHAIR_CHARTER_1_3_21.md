# Wheelchair Charter 1.3.21 — Move Values Only When Physics Requires It

1. A semantic timestep, scope, phase, or version boundary is not by itself authority to move a physical ValueFact.
2. A resident authority may be overwritten only after its final proved effective consumer.
3. Effective consumers are counted after already-selected shared ValueFacts have been materialized; a CSE subtree does not keep its internal old-state leaves artificially alive during later updates.
4. If the next ValueFact can continue in a carrier already owned by the same semantic state, prefer continuity over `register -> memory -> register` transport.
5. Memory handoff remains legal only when real causality or physical pressure requires it.
6. State-count magic thresholds do not choose FP residency. Capacity comes from target carrier geometry and actual conflicts.
7. Carrier exhaustion may trigger an AOT re-realization of the same DAG, never a workload-specific backend.
8. A discovered benchmark may expose missing transport elimination, but it may never earn a named route.
9. No runtime transport manager, register allocator, ValueFact cache, scheduler, or workload selector is introduced.
10. Historical private branches discovered during this work are deleted rather than preserved beside the common path.
