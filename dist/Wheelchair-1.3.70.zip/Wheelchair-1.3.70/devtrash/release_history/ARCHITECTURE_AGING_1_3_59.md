# Wheelchair 1.3.59 physical-plan authority aging

## Removed stale authority

Before 1.3.59 the base native512, base native256, and derived native256 Tensor frontends all called the common `synthesize_resource_schedule` after pass-0 had counted the exact physical DAG, but then immediately replaced the resulting body width with a historical fixed two-body episode. The schedule was therefore computed but not sovereign.

1.3.59 removes that overwrite. `schedule_unroll` produced from pass-0 resource counts, target cost ticks, code-footprint closure, and physical capability caps is copied directly into `physical_plan_unroll`. Canonical pass 1 must reproduce that plan.

This is architecture aging rather than a new optimization route:

- no workload names are inspected;
- no element-count threshold is added;
- no source pattern dispatch is added;
- no runtime autotuner or retry backend is added;
- no second scheduler is introduced;
- reduction-carrier legality remains a separate physical fact;
- ShapeFact-N and the 1.3.58 base/derived consumer boundary are unchanged.

## Preserved realized-shape closure

`tensor_derived_frontend_x86_64.S` is intentionally different. Its dense/LICM emitter derives `physical_realized_unroll` from the machine shape actually emitted in the probe pass, then requires canonical pass 1 to reproduce that same shape. That is a measured physical closure, not the retired fixed-width overwrite, and remains authoritative.

## Resulting behavior

On the release host the same authority naturally retains the two-body form for the lightweight 100M reduction while selecting a one-body form for the mature Newton-Jv and coupled FSI probes. No benchmark identity participates in the decision.
