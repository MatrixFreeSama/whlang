# Wheelchair 1.3.63 performance/non-regression

This release is an authority-convergence change, not a new optimization family. The protected target-code paths are expected to remain unchanged while duplicate compiler state is removed.

Compared with 1.3.62, the following representative outputs were rebuilt and were byte-identical by SHA-256:

- Newton-Jv native512;
- coupled FSI native512;
- Rank-3 native512;
- ShapeFact-N Rank-3 native512;
- lightweight reduction native512;
- strict operator native512;
- Newton-Jv native256;
- Rank-3 native256;
- general u64 computation;
- iterate/control program;
- field WHEX;
- equivalent field WH human surface;
- feature-showcase WH human surface.

Representative executables also returned identical runtime checksums. No speedup is claimed from 1.3.63 itself; the purpose is to make future Group-native physical improvements act on one authoritative structure rather than cross a legacy width bridge.
