# Wheelchair 1.3.36 Release Notes

## Structured mathematics convergence

1.3.36 removes the experimental expansion-class extended-precision implementation completely rather than preserving a lower-quality private arithmetic format. The compiler retains no dedicated extended-precision semantic, carrier tag, arithmetic path, binary dispatch path or compatibility alias from that experiment.

The generic structured projection operation is now named `component(value,index)`, reflecting its actual role for vector/matrix-derived structured results such as eigensystem and SVD outputs.

## Retained mathematics

Complex arithmetic, structured matrix/vector facts, Cholesky, QR-R, LU, LDLT, inverse, symmetric eigensystem, SVD and matrix exp/log/sqrt remain on the assimilated Structured Fact path. Rank-N contraction, scalar/special mathematics, calculus and precision propagation remain inherited authorities.

## Architecture policy

The release charter fixes the order: parasite old architecture first, strengthen old architecture second, and create a new high-affinity/high-extensibility authority only as a last resort. New authorities must have an assimilation path back into the common substrate.
