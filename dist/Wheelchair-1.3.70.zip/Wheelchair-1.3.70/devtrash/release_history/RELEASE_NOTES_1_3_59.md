# Wheelchair 1.3.59

Compiler convergence and aging release. The Tensor pass-0 resource scheduler is now the final body-width authority for the base native512, base native256, and derived native256 physicalizers. Historical fixed `unroll=2` assignments that overwrote the scheduler after it had already measured the exact DAG are removed. No source semantics, algorithm family, runtime scheduler, ISA route, compatibility backend, or workload-specific selector is added.

The AVX-512 derived consumer keeps its separate realized-shape closure because its width is recomputed from bytes actually emitted by dense/LICM physicalization rather than imposed by a fixed source threshold.
