# Wheelchair 1.3.54

Large architecture-aging release.  No new language feature or execution family is added.

- replaces the monolithic static human-Surface AST/serialization slabs with structural arenas;
- ages Field human-shell op serialization and scalar/reduction metadata into the same source-sized ownership model;
- removes the General 240-binding mailbox capacity and sizes writable mailbox BSS from the actual AOT binding graph;
- removes the Matrix `n^2<=16` decomposition scratch tier and derives worksets from matrix dimension;
- preserves real current lower-layer boundaries instead of hiding them behind permissive syntax;
- preserves inherited mathematics, Rank-N precision, optional-iteration, Field, Tensor and Physical-Reality behavior;
- keeps the mature Newton-Jv generated executable byte-identical to 1.3.53.

The most visible physical result is compiler static-reservation collapse: `wheelchairc`
BSS falls from 124,802,112 bytes to 21,520 bytes.
