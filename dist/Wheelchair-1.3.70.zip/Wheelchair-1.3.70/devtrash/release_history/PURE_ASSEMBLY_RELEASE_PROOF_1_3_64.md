# Wheelchair 1.3.64 pure-assembly release proof

The sovereign compiler path remains handwritten assembly and emits native ELF targets directly. The 1.3.64 convergence work does not introduce C, C++, LLVM, JIT, a generated-code assembler/linker stage, or a runtime group scheduler into user-program realization.

The release can be rebuilt from a clean tree with no pre-existing `build/` directory. `build/` is generated workspace only and is excluded from the release ZIP.
