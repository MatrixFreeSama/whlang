# Wheelchair 1.3.55 architecture aging

1.3.55 continues convergence without adding a source-language feature, solver family, scheduler, ISA backend, compatibility route, or benchmark-specific path. The release removes implementation cardinality from existing General and Field ownership where the AOT graph already contains the true size.

## General runtime record

The historical fixed General record (`16` inputs, `240` binding mailboxes, `64` iterate states and `32` outputs) is no longer the runtime storage authority. The compiler measures the concrete program instance before final image layout and builds one writable arena containing input values/auxiliary state, binding mailboxes, iterate state pages, temporary state pages, output pages and Rank-N decimal-ingress workspace. State capacity is premeasured from the largest existing iterate relation before code emission.

The runtime template contains only patch points for the instance layout. It does not define a replacement enlarged capacity.

## Exact General code trailer

The old 512-KiB General `program_slot` is removed. Generated input/output type vectors and exact generated machine code are appended as a page-aligned read-only executable trailer. The runtime maps that trailer from its own file and calls the exact code region. Compiler staging may grow and replay the AOT pass; generated-code size no longer changes language acceptance by crossing a fixed slot.

## Rank-N precision input workspace

The old decimal fpP ingress reserved an 8-MiB input stride and six 1-MiB parser objects. 1.3.55 derives each object span from `P`: `N=ceil(P/64)`, then aligns the existing work-object formula and lays six private objects consecutively. The total Rank-N input workspace is the sum required by the actual fpP inputs. No new precision algorithm is introduced.

## Field compiler staging

Field compiler graph storage and generated-code staging are source/graph-derived arenas. The retired compiler-only `8192` op tier, `64` constant-pool tier and 1-MiB generated-code staging tier no longer define acceptance. Current Field runtime semantics remain unchanged: field/rank/access and logical-VREG constraints are still owned by the existing backend and are not advertised as generalized by this release.

## Deliberately unchanged boundaries

1.3.55 does not generalize Tensor multi-dynamic-axis semantics, Tensor fixed AOT staging/fixup tables, Field runtime field/rank/access/VREG representation, or the remaining f64-origin coefficients used by some advanced special-function recipes. Those are separate owners and remain visible debt rather than being hidden behind a larger constant.
