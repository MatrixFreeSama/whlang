# Wheelchair 1.3.58 selector convergence correctness

1.3.58 fixes one compiler-routing regression introduced by the ShapeFact-N authority replacement. The 1.3.57 launcher treated `shape_fact_n` presence as sufficient to choose `topologyc-derived`. Rank-1 coupled FSI therefore lost the base physicalizer that already correctly consumes the rank-1/product-1 ShapeFact subset.

The repair changes only the launcher classifier. `shape_fact_requires_derived` counts top-level ShapeFact axes in the canonical structure, tolerating JSON whitespace/strings. One axis selects the existing base consumer; two or more axes select the existing derived consumer. No backend retry, workload-name match, source semantic, ShapeFact field, physicalizer, numerical algorithm or runtime path is added.

The executable regression requires `whexc` FSI output to be byte-identical to direct `topologyc`, and `whexc` Rank-3 ShapeFact output to be byte-identical to direct `topologyc-derived`. Current two-runtime-extent rejection remains unchanged.
