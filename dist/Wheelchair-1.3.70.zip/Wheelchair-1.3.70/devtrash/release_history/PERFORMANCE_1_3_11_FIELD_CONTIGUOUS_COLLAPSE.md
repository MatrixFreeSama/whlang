# Wheelchair 1.3.11 Performance Evidence

Probe: a new 224^3 materialized complex 3D Field operator with five f32 inputs, three f32 outputs, 23 unique neighborhood accesses, nonlinear cross-component algebra, and full reduction.

Final same-host audit against the final Wheelchair 1.3.10 binaries:

| capacity | 1.3.10 wall | 1.3.11 wall | throughput | 1.3.10 CPU-time | 1.3.11 CPU-time |
|---:|---:|---:|---:|---:|---:|
| 1 | 180.614 ms | 164.780 ms | 1.096x | 179.913 ms | 164.067 ms |
| 2 | 149.694 ms | 143.305 ms | 1.045x | 209.940 ms | 203.347 ms |
| 4 | 105.734 ms | 83.971 ms | 1.259x | 269.465 ms | 223.353 ms |

Geometric-mean throughput ratio across the three cells: approximately **1.130x**.

At capacity 4, elapsed time is about **20.6% lower** and total active CPU-time is about **17.1% lower**. The canonical checksum remains `0x443cec18` in both versions.

The retained 1.3.11 mechanisms are:

1. Rank-N non-power-of-two regular-episode proof compression;
2. bounded reuse-weighted AVX-512 immutable-neighbor residency;
3. four-register complex human Field lowering, which closes a surface-capability gap but is not itself counted as the source of the canonical benchmark speedup.

A broad generic FMA contraction was tested and rejected because it worsened physical execution, especially multi-capacity recurrence pressure. It is not part of this release.
