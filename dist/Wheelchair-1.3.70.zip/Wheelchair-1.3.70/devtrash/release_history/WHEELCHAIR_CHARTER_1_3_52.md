# Wheelchair charter 1.3.52

## Historical-identity convergence 1.3.52

Production architecture is named by present responsibility, not by the release in which a component first appeared. Version-numbered production filenames, macros, local symbols, duplicate aliases and dead compatibility outputs must be retired when their behavior has become the common authority. Historical proof belongs in `devtrash`; it may not require the normal build to replay obsolete release banners.

A convergence release may remove identity and duplication but may not fabricate capability. Existing semantic, ABI, mathematical and physical boundaries remain owned by their current representations until those representations themselves are aged. No new source semantic, algorithm family, scheduler, workload selector, compatibility path or ISA backend may be smuggled into a pure aging release.


## Structural capacity convergence 1.3.51

A fixed table size may not become a semantic law merely because an early implementation used static storage. When an existing semantic already represents N objects or E relations, compiler/runtime metadata should be derived from N/E and fail only at an owning representation or physical-resource frontier.

Replacing 256 with 1024 is not generalization. Fixed-width dependency masks, parser tables, graph node tables, graph edge tables and copied capacity constants must age into structural arenas or one shared owning ABI authority. The represented relation remains unchanged.

Dynamic storage is not permission to fabricate a lower capability. A capacity that still belongs to a current runtime ABI, ISA carrier set, mathematical admissibility condition, or final executable image remains authoritative until that owning representation itself is generalized. Such retained capacities must be defined once and consumed by every layer that shares the representation.

Structural capacity convergence must not introduce a runtime scheduler, workload selector, compatibility route, alternate algorithm family, source semantic, or new ISA backend. This release is strictly subtractive with respect to architectural authorities.


## Human-surface convergence 1.3.50

Human syntax may not own a smaller semantic tier than the compile-time fact it describes. Rank, lexical-parameter, record, dictionary, nested, cascade and temporary metadata limits must arise from a real representation/resource authority, not from historical fixed tables.

A static axis extent is a positive cardinality. A power-of-two realization opportunity may influence physical lowering but may not become a source-language admission rule. Rank metadata must scale with represented axes rather than a declaration-by-fixed-rank rectangle.

Compile-time pure functions are lexical relations and must erase before canonical emission. Multiple formal parameters are substituted simultaneously and hygienically. A runtime call ABI, compatibility one-argument path or parameter-count algorithm family is prohibited.

Cascade causality is an explicit relation. Goal dependencies may not be encoded by a fixed-width machine-word mask, and compile-time work may not be rejected by an arbitrary workload threshold. Compiler resource exhaustion and mathematical invalidity remain legitimate failures.

This rule does not authorize the Surface to pretend a lower capability exists. General state ABI limits, runtime binding limits, Tensor/Field representation limits and algorithmic workset limits remain visible until their owning lower authority is generalized.


## Unified sparse physical materialization 1.3.49

A complete logical DAG does not imply complete simultaneous physical residency. Physical materialization is sparse: a fact remains logical until its consumer frontier and the AOT physical-cost authority justify residency or direct consumption. Last-use closes the physical lifetime immediately.

AVX2 and AVX-512 may differ in lane count, architectural carrier count, predicate representation, gather/scatter support and instruction encoding. They may not own different materialization policies merely because the ISA names differ. The common policy consumes capabilities.

Persistent and generation-scoped facts must belong to explicit, non-overlapping lifetime domains derived from the current DAG and target capacity before canonical emission. A fixed load-count profile selector, fixed reuse-count threshold, fixed carrier reserve, named base/wide physicalizer, workload identity or benchmark-size threshold may not decide residency.

Sparse materialization is not a runtime overload controller. Do not introduce a ready queue, worker query, work stealing, central scheduler or recipient-aware release. Existing outward execution materialization and recipient-blind resource release remain authoritative.


## Architecture order

1. Parasite the old architecture first.
2. Strengthen the old architecture second.
3. A new authority is last resort.
4. Any unavoidable new authority must be high-affinity, high-extensibility and assimilatable until it becomes common substrate.

## Precision is data

`f32` and `f64` are native. Every `fpP`, `P > 64`, is one parameterized floating semantic. The compiler encodes P in the type fact and derives the physical span from P. A named wide precision may not own a production implementation.

The existing `precision_propagation` meet is authoritative and executes before physicalization. Physical code may not tunnel a precision decision into a naturally lower-precision child.

## One multiplication authority above FP64

For every `P > 64`, multiplication belongs to one Rank-N Fourier factorization authority. Production code may not contain a parallel legacy multiplication candidate, compatibility fallback, named algorithm selector or fixed precision threshold switch.

The factorization is represented by one geometry fact

```text
g = (b, a2, a3, a5)
N = 2^a2 * 3^a3 * 5^a5
```

and one native numerical admissibility condition:

```text
ceil(P/b) * (2^b - 1)^2 * ceil(log2(N)) < 2^51
```

The physical geometry is chosen by the existing AOT physical-cost authority. The current common surface is:

```text
C = N * (100*a2 + 120*a3 + 180*a5 + 10*a3^2 + 30*a5^2) + 40*n
n = ceil(P/b)
```

These constants describe measured stage/materialization cost. They are not precision thresholds and may be retuned only as one continuous physical surface.

## Native realization

The product is recovered from

```text
z = a + i*b
ab = Im(F^-1(F(z)^2))/2
```

with local mixed-radix DIF forward stages and matching DIT inverse stages. No global frequency permutation is required. Twiddle recurrence is periodically re-anchored by local x87 `FSINCOS`; butterflies use local x86-64 SIMD where profitable.

No external FFT library, planner, allocator, scheduler or executor is a production authority.

## Deliberate performance policy

A smooth common realization may carry local performance impurities. It is prohibited to regrow a small/medium/large precision algorithm zoo merely to remove a local benchmark dip. A new mechanism must strengthen or generalize the common substrate rather than create a new precision region.


## Sparse mathematics fusion

A mathematical feature may not own a duplicate approximation merely because it has a different surface name. When two semantics share a stable algebraic core, that intersection is the authority and each surface semantic is a projection of it.

Runtime control-flow branches are not a mathematical stabilization mechanism. Domain/sign/removable-singularity decisions must first use existing dataflow facts (`min`, `max`, `select`, precision facts, structured facts) and remain sparse. A second runtime solver, math scheduler, algorithm enum or threshold zoo is prohibited.

Release 1.3.41 examples are authoritative design patterns: one Euler/Lambert seed for `exp` and `expm1`; one Lanczos core for Gamma-family semantics; one Abramowitz-Stegun complement kernel for `erf` and `erfc`; one scaled norm for scalar and complex magnitude.


## Sparse root relation

A root result may not be preclassified as real or complex by a parallel solver family. One RootRelation owns Newton work and emits sparse validity plus real/imaginary facts. Real output is a projection of the same relation, not a second solver.

Iteration count is an AOT work parameter. Omission means five generations. Exhausting that finite work without satisfying the representation-scale residual relation means “no accepted candidate,” not a global proof of nonexistence.

Zero derivative, domain growth and result projection must reuse existing Structured Fact, symbolic-differentiation, select and ValueFact authorities. Runtime root schedulers, compatibility fallbacks and real/complex algorithm selectors are prohibited.


## Root precision assimilation

RootRelation may not own a fixed floating width. Precision-neutral identities inherit the existing consumer precision, and every `P > 64` comparison belongs to one normalized fpP comparison authority. Root convergence and real projection must be expressed by facts of the current representation, not by binary64 epsilon, maximum-finite constants, named-width tables or precision selectors.

A physical metadata field must be consumed at its declared width. Adjacent AOT facts may not be widened into one accidental control value. The 1.3.43 Fourier `n64` correction is the canonical example: one exact field-width boundary strengthens the common physical authority instead of creating a precision exception.

## Mathematics generalization 1.3.44

A structured mathematical object's physical workset must be derived from its represented structure, not from a historical small-object tier. Named matrix dimensions may remain as surface aliases only; they may not own algorithms. Base Matrix relations therefore consume one dimension-bearing family. An advanced relation that has not yet generalized its internal workset must reject an unsupported structure safely rather than create a parallel named-size implementation or silently overrun scratch.

Partial pivoting is a relation inside elimination, not a second inverse algorithm. Pivot choice and row permutation should be represented by existing compare/select dataflow facts whenever possible.

For `P > 64`, elementary transcendental mathematics must parasitize the parameterized fpP algebra. A named precision may not own `sqrt`, `exp`, `log`, `sin`, or `cos`. Local contraction depth, series progress and termination should be driven by the current value and current representation. This charter imports no NRII solver; only the architecture-neutral idea of local information propagation is admissible.

A representative ULP regression is not a universal correct-rounding claim. Extreme-domain maturity, especially large-argument trigonometric reduction, must be documented separately until it has its own common authority.

## Human-shell static composition 1.3.45

Human syntax may expose compositions of existing compile-time facts only when
those surface objects erase before canonical emission. MatrixFact + selected
contraction + static affine field-neighborhood addressing is such a composition.
It must lower to the same scalar field graph as hand expansion.

## Human-shell static branch erasure 1.3.46

If existing lexical substitution closes a human-shell predicate at AOT time,
retain only the selected source relation before scalar AST materialization.
Do not create a runtime branch, alternate backend, named special case, or
threshold to represent information already static in the source relation.


## Native256 physical ownership aging 1.3.47

A narrower ISA may not inherit a fictional register topology from a wider ISA.
Physical carriers are architectural facts. Native256 therefore owns exactly
YMM0..YMM15, and every persistent role must be represented inside that one bank.
A semantic ValueFact, tail predicate, reduction recurrence, procedural index and
helper scratch may not silently alias the same physical carrier.

Register capacity must be derived from actual role liveness. A workload name,
stencil width, field count, benchmark size or fixed pressure threshold may not
select a second AVX2 backend. When a physical role is absent, its carrier may be
reused through the existing ownership/lifetime authority; when present, the role
reserves that carrier.

A copied high-register cache or constant domain that cannot exist on the target
ISA is not a compatibility feature. It must age to zero capacity and let the
existing direct-load/rematerialization path remain authoritative. Native512 may
not be perturbed merely to repair a narrower physical profile.

## Native256 ValueFact lifetime convergence 1.3.48

A Physical Fact may not be transported merely because an older emitter expected
a logical carrier boundary. Planning and emission must consume one liveness
proof. If an immutable value's next consumer can directly consume its existing
resident or memory authority and no later observer needs that version, the
transport is dead work and must disappear.

Resident allocation must compete on actual surviving physical demand after such
erasure. LoadFact and ConstantFact are not separate register classes. A new
stack cache, workload route, named stencil rule, access-count threshold or
AVX2-only arithmetic algorithm is prohibited as a substitute for ValueFact
lifetime closure.

An already-live mask, index or q/end Physical Fact must be reused by a consumer
when its ABI lifetime proves validity. Reconstructing the same fact through a
helper is permitted only when the existing authority is not live or the runtime
layout/policy requires the general path.

Strict arithmetic may not be reassociated, contracted, commuted solely to fit a
memory operand, or deleted by this transport rule.
