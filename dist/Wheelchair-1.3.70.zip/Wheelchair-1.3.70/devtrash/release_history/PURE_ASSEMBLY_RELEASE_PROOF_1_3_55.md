# Pure-assembly release proof — Wheelchair 1.3.55

The production compilers/runtimes remain assembled and linked directly from the project assembly sources. `build.sh` rejects Python invocation in the production build closure. Python remains permitted only inside development/release-test generators and independent validation scripts.

The canonical production executables are:

- `wheelchairc`, `whexc`
- `topologyc`, `topologyc-derived`
- `topologyc-native256`, `topologyc-derived-native256`
- `fieldc`, `fieldc-native256`

The final release gate checks all eight are static ELF executables without an `INTERP` program header. 1.3.55 does not add a dynamic runtime, JIT, LLVM/GCC backend, Python execution dependency or compatibility compiler.
