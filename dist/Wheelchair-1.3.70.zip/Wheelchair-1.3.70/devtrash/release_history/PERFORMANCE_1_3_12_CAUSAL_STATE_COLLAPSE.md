# Wheelchair 1.3.12 Performance Evidence
## Causal State Collapse & Register Recurrence

Host: Intel Xeon Platinum 8573C. The recurrence comparison is single-CPU (`taskset -c 0`) and uses rotating interleaved order. Wall time and child process CPU time are both recorded.

### 500M two-data counted recurrence

```text
Wheelchair 1.3.11 wall median: 2044.286 ms
Wheelchair 1.3.12 wall median:  427.384 ms
Expert C wall median:            177.460 ms
GFortran wall median:            178.169 ms

1.3.11 / 1.3.12 = 4.783x throughput
1.3.12 / C        = 2.408x time
1.3.12 / Fortran  = 2.399x time
```

CPU-time medians track wall time closely because the benchmark is single-threaded:

```text
1.3.11: 2041.844 ms
1.3.12:  426.433 ms
C:        176.900 ms
Fortran:  177.849 ms
```

All four implementations produce the same `fib(10)` oracle and the same 500M wrap-semantics recurrence result.

### Generality probes

```text
Lucas 100M:
  1.3.11 411.189 ms
  1.3.12  87.175 ms
  throughput 4.717x

Three-data Tribonacci 50M:
  1.3.11 361.069 ms
  1.3.12  73.526 ms
  throughput 4.911x

f64 two-data recurrence 10M:
  1.3.11 74.018 ms
  1.3.12 56.900 ms
  throughput 1.301x
```

The three-data probe is important because it proves the release is not merely a two-value Fibonacci transform. Its emitted hot loop carries three persistent values in R8/R9/R10 while RBX remains the independent counted-control authority.

### Machine-work evidence

The 1.3.11 two-data-plus-counter output contains direct references to the general runtime `state_values` and `state_temp` arrays in the generated program. The 1.3.12 admitted register recurrence contains neither. The 1.3.12 release gate rejects any tested register recurrence whose disassembly references the historical `state_values` or `state_temp` addresses.

The resulting Fibonacci hot loop still uses the machine stack as a local expression-evaluation carrier. 1.3.12 therefore does not claim the recurrence is machine-code minimal or equal to Expert C. It specifically removes persistent generic state/temp materialization and separates control authority from data-state authority.

Raw measurements are packaged under `benchmarks/general_causal_state_1312/`.
