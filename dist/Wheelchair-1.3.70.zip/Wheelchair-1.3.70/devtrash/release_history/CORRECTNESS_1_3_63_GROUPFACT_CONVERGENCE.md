# Wheelchair 1.3.63 GroupFact convergence correctness

Release validation requires:

- one `group_body_factor` authority from resource proof through canonical code generation;
- one `group_carrier_factor` authority through the same path;
- no shadow `physical_plan_group_*` or `physical_group_form` fields in any Tensor physicalizer;
- no legacy schedule-width or runtime unroll/carrier ABI names in production source;
- backend realization facts remain witnesses and reject mismatches;
- all four native/derived and 512/256 physicalizers assemble and link from the same current source authority;
- production build remains pure handwritten assembly with no Python in the build path.
