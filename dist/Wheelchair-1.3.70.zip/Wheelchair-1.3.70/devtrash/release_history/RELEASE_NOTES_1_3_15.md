# Wheelchair 1.3.15 Release Notes

Wheelchair 1.3.15 closes the fixed-state-count remainder in General causal physicalization by strengthening the existing unified Physical Reality architecture.

## Main changes

- removes the semantic three-data-state admission boundary from causal physicalization;
- raises the existing General/Surface compile-time state vocabulary to 64 entries without adding a runtime state manager;
- separates counted induction from persistent model-state carrier budgeting;
- introduces compile-time partial residency for scalar FP and integer ValueFacts inside the same causal Physical DAG;
- fixes spill-state identity so temporary-carrier allocation cannot overwrite the enclosing state-index fact;
- preserves register-native lowering after resident capacity is exceeded instead of falling back to the generic stack evaluator;
- keeps each spilled mutable state in its existing private 4 KiB ownership page and adds compile-time page-internal cache-set coloring, eliminating the 4 KiB-stride L1D set-alias cliff;
- integer, FP and mixed FP/integer causal state now share the same residency/spill discipline;
- removes the redundant speculative integer expression proof pass; the authoritative integer Physical-DAG emitter either proves exact wrap semantics or rolls back to the single generic semantic path;
- preserves the 1.3.13 XADD / shift-add peaks and the 1.3.14 VEX FP / unified constant residency peaks.

## Structural evidence

Release probes cover 4, 8, 16 and 32 FP states, eight wrap-u64 states, and a mixed 4-FP + 4-u64 state system. Eligible hot loops contain no artificial push/pop traffic. Beyond resident capacity, only necessary private-state-page traffic appears.

## Same-host simulation evidence

On the release host, CPU0 pinned, 20,000,000 steps, five measured runs after warm-up:

| workload | Wheelchair 1.3.15 | Expert C | GFortran |
|---|---:|---:|---:|
| four-node thermal ring | 66.812 ms | 63.927 ms | 60.398 ms |
| two-mass spring/damper | 117.189 ms | 116.472 ms | 113.616 ms |

All three implementations produced bit-identical FP64 outputs for each workload. These are same-host diagnostic measurements, not a universal language-wide performance claim.
