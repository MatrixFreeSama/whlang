# Wheelchair 1.3.8 — Strict Parallel Reduction Identity Repair

1.3.8 fixes the strict-FP executor-count bit-identity defect found after the 1.3.7 FSI strict comparison.

## Defect

On the historical 100,000,000-element FSI diagnostic, 1.3.7 produced:

```text
q1  checksum_bits=0x416522bcff4adb3a
q2  checksum_bits=0x416522bcff4adb39
q4  checksum_bits=0x416522bcff4adb39
```

The one-ULP difference was not caused by FMA contraction or Tensor arithmetic lowering. It came from the runtime partitioning the chunk leaves into equal executor ranges, reducing each range independently, and then combining range scalars. That changed the global pairwise addition tree relative to q1.

## Repair

1.3.8 adds an exact strict reduction fabric. For a range of N chunk leaves, the canonical q1 pairwise tree splits at N/2 when N is a power of two, otherwise at the largest power of two below N. Multi-executor strict execution recursively assigns executors to those exact tree subranges and evaluates independent left/right subtrees concurrently.

The final parent addition is therefore the exact same floating-point node as q1.

Tolerant mode is unchanged and continues to use the historical balanced executor partition.

## Coverage

The repair is applied to the production native512 and native256 Tensor runtimes and their base/wide compiler lanes. Derived runtime sources carry the same generic repair for graphs accepted by those lanes.

The historical FSI probe now produces, for native512 and native256 base/wide lanes:

```text
10M  q1 = q2 = q4 = checksum_bits=0x4130e896f42e1dd6
100M q1 = q2 = q4 = checksum_bits=0x416522bcff4adb3a
```

No FSI/fluid/solid name appears in the repaired compiler or runtime logic.

## Performance boundary

Exact strict tree identity can expose less load balance than tolerant execution when the number of chunk leaves is not a power of two. This is an intentional strict-contract cost, not hidden serial fallback. On the current 100M FSI diagnostic, q4 remains genuinely parallel and still materially faster than q1, while reproducing q1 bit-for-bit.
