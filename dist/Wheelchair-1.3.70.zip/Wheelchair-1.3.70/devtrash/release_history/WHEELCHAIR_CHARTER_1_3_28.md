# Wheelchair 1.3.28 Charter — Mathematics Is Native Semantics

1. Mathematics is source semantics, never justification for a parallel runtime hierarchy.
2. A mathematical construct must become an existing ValueFact, Rank-N relation, contraction/reduction, causal recurrence, or disappear at compile time.
3. No Math IR, Math Runtime, Math Scheduler, Math Executor, libm compatibility bridge, or per-function hidden backend is permitted.
4. Native hardware mathematics is consumed directly when it is the lowest physical-cost faithful realization.
5. Synthesized mathematics must lower into the same existing Physical DAG and ISA resource facts as ordinary arithmetic.
6. Mathematical names may be numerous; physical authorities must remain few.
7. A named semantic operation may not be advertised unless its mathematical meaning is exact. A convenient approximation to a different operation is rejection-worthy, not a compatibility feature.
8. Matrix/tensor algorithms must share the general selected-axis contraction authority rather than growing private matrix-multiply, Gram, QR, SPD, SVD or eigensolver execution lanes.
9. Workload names, benchmark identities, fixed tensor sizes, fixed stencil widths, and fixed math-function dispatch thresholds remain forbidden optimization authorities.
10. Existing Physical Reality remains the sole authority for carrier lifetime, dependency, resource realization and outward execution.
