# Wheelchair 1.3.28 — Native Mathematics Foundation

## Scope

1.3.28 begins the native-mathematics expansion by strengthening existing authorities only. No Math IR, runtime, scheduler, executor, library ABI, JIT, C backend, LLVM backend, or workload-specific math lane was added.

## Implemented

### Unary mathematical ValueFacts

`sqrt` is now a first-class unary surface operation and an ordinary existing ValueFact:

- General f32/f64: direct `sqrtss` / `sqrtsd` realization.
- Tensor f64 AVX-512: direct `vsqrtpd zmm` realization.
- Tensor f64 AVX2/native256: direct `vsqrtpd ymm` realization.
- Field f32 AVX-512: direct `vsqrtps zmm` realization.
- Field f32 AVX2/native256: direct `vsqrtps ymm` realization.

No libm call or runtime helper survives.

### Old AST arity cleanup

The human-call parser now creates a genuine `NK_UNARY` for one-argument native operators. The historical `abs` serializer exception caused by representing a unary call as `NK_BINARY` was deleted.

### General Physical-Reality arity generalization

Existing FP ValueFact equality, cost, CSE traversal, containment and effective-state-use traversal were generalized from binary-only trees to unary-or-binary pure FP facts. This is the reusable architectural work needed by later native unary mathematics.

### Native Rank-N reduction semantics

The human surface accepts:

- `dot`
- `inner`
- `frobenius_inner`
- `squared_norm` / `norm2_squared`
- `squared_distance`

Each disappears into the existing Rank-N arithmetic plus `sum` reduction before backend execution.

## Correctness boundary

The second source audit found that current Rank-N lowering still flattens logical axes before the tensor backend and the backend owns only a terminal scalar reduction. Therefore a true selected-axis contraction cannot yet preserve output axes.

For this reason 1.3.28 does **not** advertise fake implementations of matrix `trace`, `matmul`, Gram matrices, Gram-Schmidt, SPD construction/projection, SVD, eigendecomposition, or matrix functions. Their common prerequisite is selected-axis contraction in the existing Rank-N authority.

## Regression

The full inherited 1.3.27 architectural regression set passes after the changes. Dedicated 1.3.28 tests additionally verify scalar/Tensor/Field sqrt output, AVX-512 and AVX2 native sqrt instructions, exact linear-reduction semantics, static AOT output, and absence of a dynamic libm dependency.
