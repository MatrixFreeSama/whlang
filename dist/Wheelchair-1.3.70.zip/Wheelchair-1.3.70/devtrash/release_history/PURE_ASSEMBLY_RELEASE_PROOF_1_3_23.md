# Pure Assembly Release Proof — Wheelchair 1.3.23

Production authority remains handwritten assembly and static direct-native AOT.

```text
C_BACKEND=0
LLVM_BACKEND=0
JIT=0
PYTHON_PRODUCTION_BUILD=0
RUNTIME_TRANSITION_POWER_MANAGER=0
FIXED_TWO_STATE_AFFINE_ROUTE=0
FIXED_BOUNDARY_SELECT_MATCHER=0
```

`compiler/general_frontend_x86_64.S` performs the transition-closure proof at AOT time and emits direct x86-64 binary-composition instructions. No runtime graph walker, recurrence classifier, algebra engine, or register allocator is introduced.

`test_transition_power_1323.sh` verifies the old LCG peak, Rank-N state-count independence, nonlinear fallback, and physical deletion of old private source routes.
