# Wheelchair 1.3.12 Release Notes
## Causal State Collapse & Register Recurrence

### Why this release exists

A neutral iterative recurrence probe exposed a General physicalization cliff. Three semantic states such as two real recurrence values plus one loop counter exceeded the historical two-state register path and fell into the generic `state_values -> state_temp -> commit` route. On a 500M two-value recurrence this made 1.3.11 spend most active silicon work moving state rather than advancing the recurrence.

1.3.12 removes that source-variable-equals-physical-state assumption.

### Implemented

- General state declarations are classified into scalar physical roles at AOT time.
- A proved `counter < bound`, zero-initialized, `counter = counter + 1` state is assigned an independent counted-control authority.
- Counted control no longer consumes the persistent data-state register budget.
- The former hard-coded `<=2` semantic-state admission rule is removed.
- Up to three persistent scalar data states are admitted to the current register recurrence bank R8/R9/R10.
- The counted-control carrier is RBX; its invariant bound is RBP.
- Register recurrence supports u64, i64, f32, and f64 state bit authorities.
- Simultaneous transition results commit directly to persistent data registers rather than runtime state/temp arrays.
- A value-participating counter remains visible from its dedicated control register.
- Generic fallback remains for larger, unsafe, effectful, or unproved state graphs.

### Explicit non-goals

1.3.12 does not add runtime recursion. It does not special-case Fibonacci or any named recurrence. It does not add a runtime state-role manager or register scheduler. It does not alter Blind Surplus Reflow or restore any load-balancing mechanism.

### Same-host retained-mechanism evidence

On the same Intel Xeon Platinum 8573C host, fixed to one CPU, seven interleaved 500M recurrence rounds gave:

| implementation | median wall | median CPU time |
|---|---:|---:|
| Wheelchair 1.3.11 | 2044.286 ms | 2041.844 ms |
| Wheelchair 1.3.12 | 427.384 ms | 426.433 ms |
| Expert C | 177.460 ms | 176.900 ms |
| GFortran | 178.169 ms | 177.849 ms |

1.3.12 is about **4.783x** the 1.3.11 throughput on this probe. It still takes about **2.408x** the Expert C wall time. This release therefore does not claim a Fibonacci victory over C. The structural win is that the generic persistent state/temp traffic is absent from the admitted register recurrence.

Non-Fibonacci probes preserve the same mechanism:

| probe | scale | 1.3.11 | 1.3.12 | throughput ratio |
|---|---:|---:|---:|---:|
| Lucas two-data recurrence | 100M | 411.189 ms | 87.175 ms | 4.717x |
| Tribonacci three-data recurrence | 50M | 361.069 ms | 73.526 ms | 4.911x |
| f64 two-data recurrence | 10M | 74.018 ms | 56.900 ms | 1.301x |

The compared outputs are bit-identical between 1.3.11 and 1.3.12 for the measured probes.
