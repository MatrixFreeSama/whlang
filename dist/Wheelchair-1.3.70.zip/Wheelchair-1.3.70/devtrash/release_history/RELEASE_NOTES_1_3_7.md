# Wheelchair 1.3.7 — Tensor Physical Reality Completion

1.3.7 carries the 1.3.6 Global Physical Reality doctrine into the high-pressure `f64` Tensor native512 physicalizer.

## What changed

1. **Reachable-use graph before machine emission.** The compiler counts structurally reachable binding uses at AOT time and expands each definition once for profitability analysis.
2. **Demand-causal persistence.** One-use Tensor facts bypass persistent CSE ownership. Persistence now requires a future consumer.
3. **Cross-subtree indexed ValueFact reuse.** Exact indexed pure-map identities can be consumed directly from existing physical authority rather than copied into a fresh temporary.
4. **Pass-0 affine profiling.** Reused affine coefficients are counted before canonical emission. The most valuable facts receive induction carriers according to register capacity and competing live facts.
5. **Cross-vector affine induction.** Selected `c*i+d` facts advance by `c*W` at the vector back edge instead of rebuilding multiplication each block.
6. **Generic integer strength reduction.** `2^k`, `2^k-1` and `2^k+1` coefficient shapes lower without `vpmullq` when the structural form is cheaper.
7. **Weighted exact-bit constant selection.** Constant residency is selected after pass 0 rather than first-come. The base and wide profiles use their different physical register budgets.
8. **Three-operand copy elimination.** Existing PhysicalFact sources feed AVX-512 three-operand instructions directly where legal.
9. **Last-consumer square.** `X*X` for an exact twice-used direct load realizes `X` once and squares in place instead of manufacturing a side authority.
10. **Tolerant exact doubling.** In tolerant FP only, literal `2.0*x` may use direct `x+x`; strict FP does not enter this transform.
11. **Both native512 Tensor profiles use the 1.3.7 pass.** The physical fact rules are common while base/wide register geometry stays distinct.
12. **native256 historical authority is retained.** 1.3.7 does not claim that the native512 high-register lifetime planner has magically become an equivalent AVX2 planner.

## Structural disassembly result on the historical FSI probe

On the current native512 wide generated payload, compared with frozen 1.3.6 on the same source:

- `vpmullq`: 42 -> about 17 static sites across the generated hot RX payload;
- `vmovdqa64`: 86 -> about 36;
- first proven-interior vector body: 117 -> about 90 instructions.

These are code-shape observations for one probe, not universal ratios.

## Claim boundary

1.3.7 is not an FSI optimizer and is not a blanket claim of superiority over C/Fortran. It removes generic Tensor physical work exposed by that probe. The remaining gap, if any, is recorded in the performance report rather than hidden.

## Final same-host FSI diagnostic

The frozen release tree was remeasured on the Intel Xeon Platinum 8573C host with the historical `10M/100M x q=1/2/4` protocol, 3 warmups and 11 interleaved measured process-wall runs per row.

Wheelchair 1.3.7 medians were:

```text
10M q1   18.562580 ms
10M q2   17.419874 ms
10M q4    9.680088 ms
100M q1 166.156050 ms
100M q2 165.159177 ms
100M q4  84.035699 ms
```

Relative to the same-host 1.3.6 medians, the six-point geometric-mean speedup is `1.356215x` (about 26.27% lower elapsed time). Matched Expert C and Expert Fortran still win the aggregate; the detailed table and correctness boundary are in `PERFORMANCE_1_3_7_TENSOR_PHYSICAL_REALITY.md`.
