# Wheelchair 1.3.61 Automatic Grouping charter

1. Group is the complete structural form. Vector and Scalar are progressive degradations: `Group -> Vector -> Scalar`.
2. Automatic Grouping recovers operation-affine structure from existing ValueFact, Axis, ShapeFact-N, Operator and Physical-DAG facts. It is not a source annotation, backend family, autotuner or runtime object.
3. ShapeFact-N remains the sole owner of logical axis identity and extents. GroupFact may derive rank/form/physical factors but must not duplicate a fixed axis table.
4. No fixed group size, rank cap, tile size, chunk threshold, workload selector or "group if N > K" rule is admissible.
5. The resource scheduler proves machine cost/pressure. GroupFact then absorbs the exact legal body/carrier factors and is the only structural handoff to canonical physicalization.
6. SIMD is a physical degradation target, not the semantic definition of grouping. A one-axis Group may become Vector; a one-member Vector may become Scalar.
7. Operation-affine body replication, reduction-carrier structure, affine induction and operator composition are ordinary relation facts. They do not create private optimizers.
8. Existing mature machine-code peaks are protected. An architecture-only grouping lift must not perturb emitted bytes when the old physical realization was already optimal.
9. Runtime group managers, runtime group selectors, compatibility vectorizers, hidden scalar fallbacks and workload-name routing are forbidden.
10. New domains extend the old facts. They do not add `matrix grouper`, `stencil grouper`, `proof grouper` or other algorithm families.
