# Wheelchair 1.3.18 Pure Assembly Release Proof

The production compiler/runtime remains direct static x86-64 GNU assembler/linker code. No C/LLVM backend, JIT, Python production generator or runtime graph manager is introduced.

1.3.18 adds one AOT target-profile fact for the execution-context lifetime and reuses existing Physical Reality work facts. Generated runtimes receive immutable cost values.

Release prohibitions:

- hard-coded work-size expansion threshold: 0
- runtime resource-availability expansion query: 0
- runtime CPU-count expansion selector: 0
- execution credit bitmap: 0
- capacity claim/release: 0
- runtime CPU pinning: 0
- work stealing: 0
- global ready queue: 0
- donor/recipient selection: 0
- ready-equals-must-clone rule: 0

Release obligations:

- Tensor/Field local and outward paths implement the same canonical causal tree;
- expansion is selected from physical profitability only;
- outward lifecycle price is selected AOT from the target profile, not queried from runtime capacity;
- local work price comes from existing physical schedule/operator facts;
- 1.3.17 external-silicon ownership law remains authoritative;
- inherited strict numerical and machine-code authorities remain mandatory.
