# Wheelchair 1.3.63

Automatic Grouping aging and convergence release.

- Fuses resource scheduling into GroupFact body/carrier factors.
- Deletes Tensor shadow group-plan state.
- Deletes legacy schedule unroll/carrier authority names.
- Renames runtime width contract to GroupFact-native terminology.
- Keeps backend realization data only as physical proof witnesses.
- Keeps Group -> Vector -> Scalar degradation and all existing mathematical semantics.
- Adds no compatibility route, workload selector, runtime group manager or fixed group threshold.
