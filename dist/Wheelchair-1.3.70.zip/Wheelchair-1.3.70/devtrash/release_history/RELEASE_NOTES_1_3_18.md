# Wheelchair 1.3.18 Release Notes

## Emergent Outward Expansion

1.3.17 correctly deleted Wheelchair-owned execution capacity, but its Tensor/Field rule still mapped every eligible split to an outward Linux execution context. Lightweight probes exposed a clone/wait/exit/context-switch storm.

1.3.18 deletes that remaining specialization. `Ready` now means "may execute independently", not "must clone".

### Existing architecture strengthened

Tensor and Field now realize the same canonical causal subtree in one of two ways:

- local continuation inside the current execution lifetime;
- outward execution through the external OS/hardware substrate.

The decision uses existing Physical Reality costs. The AOT compiler selects outward execution-context materialization cost from the existing target Physical Reality profile and derives local work cost from existing physical schedule/operator facts. No workload name and no fixed work-size threshold is involved.

### Deleted old rule

The following old equation is gone:

```text
independent split -> unconditional clone
```

It is replaced by:

```text
same causal subtree
    -> local physical realization
    -> outward physical realization
    -> choose lower proved physical cost
```

### Preserved resource law

No credit bitmap, capacity accounting, CPU availability query, runtime pinning, work stealing, global ready queue, donor lookup or recipient lookup is reintroduced. `--executors N` remains compatibility syntax and cannot choose the semantic graph.

### Strict numerical identity

Local execution reconstructs the exact canonical pairwise reduction tree. Strict-FP bit identity across historical executor spellings remains a release gate.

### Same-host diagnostic evidence

On the same constrained host used for the 1.3.17 resource A/B, a 100M lightweight Tensor reduction fell from a median 14.481 ms in 1.3.17 to 6.953 ms in 1.3.18. Median voluntary context switches fell from 2699 to 337 and median user CPU time from 61.271 ms to 28.898 ms. This is a workload/host-specific diagnostic, not a universal speed claim.

The heavy 100M FSI probe remained essentially unchanged: 57.532 ms vs 57.375 ms median wall time. Its per-chunk physical work is already expensive enough that outward execution remains profitable.
