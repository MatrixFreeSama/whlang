# Wheelchair 1.3.27 Pure-Assembly Release Proof

The production compiler/runtime remains handwritten x86-64 assembly plus shell build orchestration.

Production paths contain no C, C++, LLVM, MLIR, JIT, Python compiler generator, or runtime carrier-lifetime manager.

The 1.3.27 repair is implemented in the existing Field assembly frontend by extending compile-time Physical Reality facts:

- cache-slot final load position;
- first clobber position;
- phase-local preload scratch authority;
- direct resident-to-backup materialization.

No application identity or benchmark route is admitted.

The release gate requires static native binaries and re-runs the complete inherited regression authority together with the new distinct-input regular-store oracle.
