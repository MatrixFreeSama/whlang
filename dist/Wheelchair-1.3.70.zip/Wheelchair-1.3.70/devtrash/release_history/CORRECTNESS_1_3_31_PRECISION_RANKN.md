# Correctness — Wheelchair 1.3.31 Precision / Rank-N Closure

## Precision propagation

Validated policies:

- omitted policy == `precision_propagation 0`;
- `0`: f64/f32 meet emits a local f64→f32 edge conversion;
- `1`: f64/f32 meet emits a local f32→f64 edge conversion;
- nested child subtrees retain natural precision before the outer meet;
- strict and tolerant FP contracts remain orthogonal.

Release gate: `devtrash/release_tests/test_precision_propagation_1331.sh`.

## Low-precision historical rule

The 1.3.30 late-contagion gate remains green. A high-precision subtree completes before its result is narrowed at the actual low-precision consumer edge.

Release gate: `devtrash/release_tests/test_low_precision_contagion_1330.sh`.

## Rank-N and contraction

Validated on both `topologyc-derived` and `topologyc-derived-native256`:

- arbitrary radix 3 coordinate recovery;
- 3×3 matrix multiplication, checksum 729;
- 6×6 matrix multiplication, checksum 77706;
- 7×7 matrix multiplication, checksum 223979;
- true 3×3 trace `trace(k in 3, M[b,k,k])`, checksum 15.

Release gate: `devtrash/release_tests/test_rankn_contraction_1331.sh`.

## Defects closed by the probes

1. A high-rank map no longer contaminates a later low-rank reduction's physical extent.
2. Rank-1 consumers no longer bypass source-shape rewriting.
3. Multi-index source tuples retain every successor across AST-builder calls.
4. A source load is flattened using the source declaration's persisted strides, not the consumer's rank.
5. Arbitrary-radix div/mod carrier identities survive emitter calls and use the existing carrier lifetime authority.
