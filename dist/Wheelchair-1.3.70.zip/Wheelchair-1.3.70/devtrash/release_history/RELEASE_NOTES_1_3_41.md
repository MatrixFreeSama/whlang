# Wheelchair 1.3.41 Release Notes

1.3.41 is a mathematics-convergence release. It adds no new runtime mathematics subsystem and no algorithm selector. Existing native mathematics is folded toward shared sparse facts: A∩B instead of A+B.

## Shared old-algorithm authorities

- **Euler/Lambert exponential seed**: the common seed is now `q = exp(x/64)-1`. `exp` projects `1+q` and squares; `expm1` stays in the shifted coordinate with `q <- q(q+2)`. This removes the `exp(x)-1` cancellation while keeping the existing `exp(1)` release bits.
- **Compensated `log1p`**: Kahan's `y=1+x`, `c=y-1`, `log(y)*x/c` correction is represented with a protected denominator and an existing sparse select. Tiny x survives even when `1+x` rounds to one.
- **Inverse hyperbolics**: `asinh`, `acosh` and `atanh` are identities over the same `log1p`/scaled-norm facts rather than separate magnitude-specialized approximation families.
- **Abramowitz-Stegun complement kernel**: one `q≈erfc(|x|)` tail feeds both `erf` and `erfc`; positive `erfc` no longer passes through `1-erf(x)`.
- **Lanczos Gamma core**: one rational Lanczos core emits the shared sum, t and exponent facts. `gamma` keeps its historical operation order for bit-level compatibility; `lgamma`, `beta`, binomial and rising/falling factorial ratios consume the same core in the log domain.
- **Scaled Euclidean norm**: scalar `hypot(x,y)` and complex `cabs(z)` are now projections of one max/min-scaled norm authority.
- **Removable singularity**: `sinc(0)` is exactly one through existing dataflow select semantics, without a runtime mathematical branch.
- **Semantic metadata repair**: differentiable semantics whose result is a select are projected through the identity `*1` before origin metadata is attached, so the metadata slot cannot overwrite the select false edge.

## Non-regression policy

The 1.3.34 native-mathematics and 1.3.36 structured-mathematics bit contracts remain passing. The 1.3.40 Rank-N/Fourier precision authority remains unchanged.

## Deliberately not added

1.3.41 does not add Brent/bisection root protection, Gauss-Kronrod integration, pivoting, Householder/Givens transforms, adaptive error controllers or a new linear-solve semantic. Those are separate maturation work; this release first converges functionality already present in the source.
