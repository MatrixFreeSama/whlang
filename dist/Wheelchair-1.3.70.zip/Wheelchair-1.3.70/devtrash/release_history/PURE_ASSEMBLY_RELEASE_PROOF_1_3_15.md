# Wheelchair 1.3.15 Pure-Assembly Release Proof

1.3.15 remains a pure AOT native release. The production build invokes no Python, C, LLVM, JIT, runtime dependency graph, runtime register allocator, runtime state manager, work-stealing queue, or recipient-aware resource distributor.

The causal-state extension is compile-time only. `g_phys_assign_state_carriers` maps Versioned ValueFacts to resident carriers or existing private state pages. The state count does not choose a backend. Nonresident FP and integer facts are materialized only at their true consumption/commit boundaries while their expressions remain register-native.

The old private-page storage model is retained and strengthened with deterministic in-page cache coloring. No packed global state manager is introduced.

Release authority requires:

1. 4/8/16/32-state FP bit identity;
2. eight-state wrap-u64 bit identity;
3. mixed FP/u64 bit identity;
4. zero artificial stack traffic in admitted small and large-N causal hot loops;
5. preservation of 1.3.13 and 1.3.14 machine-code peaks;
6. full historical release-chain passage;
7. clean-build identity for distributed native compiler/runtime images;
8. static ELF verification and whole-package SHA-256 verification.
