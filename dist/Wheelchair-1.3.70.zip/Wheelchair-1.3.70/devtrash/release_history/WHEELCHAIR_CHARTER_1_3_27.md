# Wheelchair 1.3.27 Charter Addendum

## Physical carrier lifetime is authority

A SIMD register is not permanently owned by a subsystem name. Its authority is a causal interval.

A carrier may be reused only after the previous authority has ended, and a phase-local scratch carrier may exist only while no semantic ValueFact owns it in that phase.

For Field execution:

```text
preload carrier ownership
        -> arithmetic carrier ownership
        -> helper ABI ownership
        -> released capacity
```

must be represented as one Physical Reality. Overlapping authorities are illegal even if each individual mechanism is locally correct.

## No repair by de-optimization

A correctness failure caused by a carrier overlap must not be repaired by disabling residency for a workload, store graph, integer graph, neighbor count, or access count. The old architecture must absorb the missing lifetime fact; obsolete eligibility and compatibility branches are then deleted.

## Permanent 1.3.27 red lines

```text
IMPLICIT_SIMD0_PRELOAD_TRANSPORT=0
GLOBAL_RESIDENT_STACK_BACKUP_FLAG=0
STORE_DISABLES_RESIDENCY=0
WORKLOAD_SPECIFIC_STORE_ROUTE=0
PRELOAD_PHASE_HAS_EXPLICIT_AUTHORITY=1
RESIDENT_BACKUP_USES_ACTUAL_CARRIER=1
LAST_LOAD_POSITION_IS_LIFETIME_FACT=1
CLOBBER_POSITION_IS_LIFETIME_FACT=1
```
