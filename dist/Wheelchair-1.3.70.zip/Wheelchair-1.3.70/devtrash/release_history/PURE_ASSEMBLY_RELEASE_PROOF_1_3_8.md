# Wheelchair 1.3.8 Pure Assembly Release Proof

Production 1.3.8 remains direct native AOT.

The strict reduction repair is implemented in handwritten x86-64 assembly runtime/compiler sources. It adds no C, LLVM, MLIR, JIT, Python production generator, bytecode interpreter, work-stealing runtime, global ready queue, central reduction scheduler, or runtime autotuner.

The release gate compiles the historical strict Tensor probe with 1, 2 and 4 executors through native512 and native256 base/wide lanes and requires exact checksum-bit identity at 10M and 100M. It separately freezes the historical tolerant outputs so strict repair cannot silently reroute tolerant execution.
