# Wheelchair 1.3.27 — Physical Carrier Lifetime Closure

1.3.27 is a correctness and architecture-closure release over 1.3.26.

A real shallow-causal Field store probe exposed a regular-episode preload alias. In 1.3.26, SIMD0 could simultaneously be selected as a sovereign immutable resident carrier and still be used implicitly as the transport scratch for a later regular preload that needed stack reload authority. With two distinct resident inputs, the later preload could overwrite the earlier resident before arithmetic began.

The repair does not disable residency, restore the old reuse threshold, or add a store/workload fast path. The existing Field Physical Reality is extended so preload, resident backup, helper clobber, and arithmetic ownership are governed by carrier lifetime.

## Deleted obsolete behavior

- implicit `regular load -> SIMD0 -> stack -> resident` transport;
- global `ff_resident_stack_backup` flag;
- graph-wide backup caused merely by the existence of any later store/helper;
- the assumption that SIMD0 is always free during regular preload.

## Generic replacement

- regular resident loads materialize directly into their final physical carrier;
- a reload authority is kept only when the fact's final `OP_LOAD` lies after the first clobbering arithmetic helper;
- backup is written from the actual resident carrier, not from a fixed ABI scratch register;
- nonresident regular preload borrows logical v0's physical carrier only during the preload phase, before that logical register acquires arithmetic ownership;
- after a helper, only resident facts whose final consumer-copy is still in the future are restored.

There is no solver, stencil, workload, field-name, store-count, or access-count admission route.

## Regression result

A deterministic 16×16×16 two-input regular Field probe reproduces the 1.3.26 failure and is now a permanent release gate. The correct checksum is:

```text
checksum_f32_bits=0x4441ae02
```

Both AVX-512 `fieldc` and AVX2 `fieldc-native256` produce output byte-identical to the fixed oracle.

The 1.3.26 27-neighbor high-carrier capability remains present; the repair does not solve correctness by removing SIMD0 from the post-helper carrier bank.
