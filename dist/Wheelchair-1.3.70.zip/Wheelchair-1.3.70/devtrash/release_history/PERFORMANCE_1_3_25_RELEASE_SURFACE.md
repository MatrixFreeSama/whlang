# Wheelchair 1.3.25 Performance Note

1.3.25 is a release-surface change, not a machine-code optimization release.

The ten production executables rebuilt from the 1.3.25 production tree have the same SHA-256 hashes as the final 1.3.24 executables. This is stronger than a noisy timing comparison: the production compiler binaries are byte-identical.

Consequently the measured 1.3.24 execution characteristics carry forward unchanged, including the approximately 1.047x `chem6`, 1.053x `ring8`, 1.056x 100M FSI whole-process, and approximately 1.076x FSI steady-state improvements previously measured against 1.3.23.

The performance purpose of 1.3.25 is preventative: archived matchers, compatibility routes and benchmark-shaped experiments can no longer be casually imported by the production build. Future acceleration must enter through current general architecture rather than branch accumulation.
