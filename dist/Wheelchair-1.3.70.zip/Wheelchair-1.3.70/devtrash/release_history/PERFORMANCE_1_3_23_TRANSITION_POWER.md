# Wheelchair 1.3.23 Transition-Power Evidence

Same-host whole-process medians, 15 launches per point, historical `lcg64_iterate_wrap.wh`:

| steps | 1.3.22 | 1.3.23 |
|---:|---:|---:|
| 1,000,000 | 1.544 ms | 0.287 ms |
| 10,000,000 | 12.194 ms | 0.272 ms |
| 100,000,000 | 116.291 ms | 0.278 ms |

1.3.22 executes the recurrence step-by-step after deletion of the private affine route. 1.3.23 emits binary transition composition (`test n&1`, affine apply/square, `shr n`) through the generic counted-recurrence Physical Reality. The nearly flat 1.3.23 wall time is dominated by process launch and output, so these timings are evidence of complexity recovery rather than a portable absolute performance claim.

A second release probe starts from the existing nine-state `int8_ring` source, changes only the published `s0` update to `s0=s0+10`, and leaves the other seven states coupled. The result enters the same transition-power path because state count is not an admission criterion and the coupled siblings are absent from the published-result backward slice.
