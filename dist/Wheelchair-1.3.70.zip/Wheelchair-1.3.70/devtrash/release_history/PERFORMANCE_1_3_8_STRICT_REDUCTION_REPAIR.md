# Wheelchair 1.3.8 — Strict Reduction Repair Diagnostic

Host: Intel Xeon Platinum 8573C environment used by the preceding FSI strict comparison.

The release objective is correctness across executor counts, not a new speed leaderboard.

A seven-run process-wall diagnostic after the repair observed approximately:

| N | q1 | q2 | q4 |
|---:|---:|---:|---:|
| 10M | 23.54 ms | 24.30 ms | 15.96 ms |
| 100M | 234.74 ms | 244.68 ms | 159.98 ms |

These measurements are noisy diagnostics rather than release performance guarantees. The important result is that all three executor counts now return identical strict checksum bits. q4 remains genuinely parallel; the slower q4 result versus 1.3.7 reflects the cost of preserving the exact non-power-of-two q1 reduction topology.

The tolerant path remains on the 1.3.7 balanced fabric and was observed around 16.44/16.16/8.77 ms at 10M and 159.18/157.54/79.79 ms at 100M in a small five-run diagnostic.
