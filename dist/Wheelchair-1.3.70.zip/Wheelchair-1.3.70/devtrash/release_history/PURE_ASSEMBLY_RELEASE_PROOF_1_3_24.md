# Wheelchair 1.3.24 Pure-Assembly Release Proof

The production compiler/runtime remains handwritten x86-64 assembly plus shell build orchestration.

Release gates verify:

- no Python source is shipped as production compiler/runtime authority;
- `build.sh` invokes no Python compiler generator;
- `build.sh` invokes no GCC/Clang/LLVM backend;
- produced compiler/runtime images are static AOT executables;
- active production sources contain no deleted Factor2/FactorGroup, fixed boundary-select, fixed two-state affine, fixed historical chunk, or source-text routing private path;
- `frozen_native` is inert regression material and is not a production build input;
- prebuilt root/bin compiler images are byte-identical to the release build;
- final ZIP is re-extracted, checksummed, rebuilt and release-tested from a clean directory.
