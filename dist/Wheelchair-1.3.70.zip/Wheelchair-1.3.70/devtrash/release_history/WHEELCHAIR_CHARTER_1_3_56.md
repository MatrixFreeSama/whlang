# Wheelchair 1.3.56 aging charter

1. Existing structure is the capacity authority. Source/graph/code cardinality must not be shadowed by an unrelated fixed compiler table.
2. Aging removes a wall; it does not replace `8` with `64` or `512` with `4096`.
3. A fixed number may remain only when it describes a real current representation, physical resource or mathematical contract.
4. External-format changes are semantic changes. `WHFLD216` Rank-8 is therefore not silently widened in an aging release.
5. Physical-register ownership is not faked. Field's four logical VREGs remain until a real spill/rematerialization physicalizer owns more logical values.
6. Tensor multi-runtime-axis support is not claimed until a real descriptor/runtime path carries those extents.
7. Compiler arena relocation may never leave live generated-code/fixup pointers behind; growable code workspaces replay the complete AOT pass.
8. Existing mature machine-code peaks are protected byte-for-byte where the release does not intentionally change physical execution.
9. No compatibility shell, hidden retry backend, workload dispatch or algorithm family is added to make a gate pass.
