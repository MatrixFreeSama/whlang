# Wheelchair 1.3.61

Introduces Automatic Grouping as a compiler-wide structural architecture. `Group -> Vector -> Scalar` is now the degradation hierarchy: vectors are one-axis groups and scalars are final one-member degradations, rather than three sibling optimization families.

GroupFact is compile-time-only and is fused into existing ShapeFact-N, Operator, Physical DAG and Physical Reality. The four Tensor physicalizers delete their old `physical_tensorized`, `physical_plan_unroll` and `physical_plan_carriers` authorities. Resource/pressure proof feeds GroupFact; canonical physicalization consumes the resulting group body/carrier structure.

No source syntax, runtime manager, fixed rank/group/tile cap, workload route, compatibility vectorizer, hidden scalar fallback or new algorithm family is added. Protected mature generated ELFs remain byte-identical to 1.3.60.
