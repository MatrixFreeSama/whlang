# Wheelchair 1.3.17 Charter

## External Silicon Authority

Wheelchair owns work, never silicon.

A causal work fragment is permitted to exist because its mathematical dependencies are satisfied, not because a Wheelchair resource counter says capacity is available. Resource availability may delay physical execution at the OS/hardware layer; it must never rewrite the semantic parallel graph.

## Mandatory execution law

```text
not-ready work -> semantic fact only
ready work     -> materialize outward immediately
running work   -> owns only its current execution lifetime
finished work  -> terminate Wheelchair execution authority immediately
```

There is no Wheelchair-owned interval between completion and later reuse.

## Forbidden internal resource ownership

Production runtime must contain no:

- execution credit bitmap,
- capacity claim/release protocol,
- free-worker or free-core table,
- donor or recipient lookup,
- work stealing,
- global ready queue,
- load-balancing family,
- runtime CPU pinning used to place causal work,
- pre-created future executor sleeping until dependencies arrive,
- resource handoff from one Wheelchair task to another.

`Ready -> Materialize` is not a resource request. It merely exposes runnable work to the external execution substrate. `Done -> Evaporate` is not a resource return to Wheelchair. The executor ends and OS/hardware regains complete placement authority.

## True causal synchronization remains legal

This charter does not delete mathematical causality.

- a reduction parent may join a real child result;
- a successor with multiple true predecessors must prove all predecessors complete;
- a successor with one predecessor requires no atomic arrival counter;
- memory ownership and strict numerical ordering remain binding facts.

Synchronization is legal only where it represents a real dependency, never where it represents silicon inventory management.

## Tensor and Field

Every proved independent split may be exposed outward without consulting capacity. The current execution continues one branch; the independent branch is materialized directly. Child completion terminates. There is no `try_claim_credit`, `release_credit`, credit cache line or CPU-pinning step.

A failed OS execution-context materialization is not converted into a Wheelchair retry/credit loop. The same causal subtree remains correct and can execute locally; Wheelchair does not create an internal resource manager to compensate.

## General causal regions

Future regions must not be physically created before they are ready. Root regions materialize because indegree is zero. A successor with indegree one becomes ready directly when its predecessor finishes. A successor with indegree greater than one uses only the arrival composition required to identify the final true predecessor. Once ready, it is materialized outward immediately.

No `futex` sleeping future executor is part of the active design.

## Affinity and compatibility fields

CPU affinity/topology may be observed as read-only environment facts for AOT ISA or NUMA reasoning. Wheelchair must not turn those facts into silicon ownership. It must not pin generated causal work or its compiler merely to maintain an internal execution model.

The historical `--executors N` spelling may remain accepted to avoid source breakage, but in 1.3.17 it is not a capacity request, not a concurrency ceiling, and not permission to change the computation graph. Historical binary patch locations may remain dormant where changing the old image layout would add unrelated ABI churn; current runtimes must not read them as resource authority.

## Scope

This release intentionally changes only silicon/execution-resource management. It does not claim to remove unavoidable idle time caused by true dependencies, cache/DRAM latency, OS scheduling delay, interrupts, power management or CPU microarchitectural bubbles.

The target removed by this release is narrower and stricter: **Wheelchair itself must not create idle silicon through avoidable internal resource accounting or pre-created waiting executors.**
