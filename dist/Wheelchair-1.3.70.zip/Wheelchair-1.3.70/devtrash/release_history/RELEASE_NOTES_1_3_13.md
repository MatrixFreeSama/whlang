# Wheelchair 1.3.13 Release Notes

## Main change

Wheelchair 1.3.13 introduces register-native causal transition lowering for the scalar state-transition class exposed by the 1.3.12 recurrence audit.

1.3.12 had already made persistent recurrence state register-resident, but its general expression emitter still used the machine stack as an operand/result transport. 1.3.13 adds a separate proven physical-expression path whose generated values remain in typed physical register domains.

## Implemented

- register-native physical-expression emitter;
- explicit integer GPR and floating XMM result domains;
- old-generation state residency and disjoint next-generation output carriers;
- transition-wide simultaneous commit after old-state consumers have completed;
- bounded depth-indexed GPR/XMM scratch banks for admitted recursive expressions;
- persistent XMM state for admitted floating recurrences;
- reuse-weighted floating constant residency in preheader XMM registers;
- relation-driven two-state swap/add `xadd` selection;
- relation-driven three-state shift/full-add compact lowering;
- bottom-tested counted native loop backedge;
- generic non-pattern register-DAG path for unrelated coupled wrapping recurrences;
- explicit compatible fallback for trapping integer arithmetic and unsupported expressions;
- disassembly regression gates for artificial stack traffic, state/temp traffic, floating-domain residency, and unconditional native backedges.

## What was deliberately not done

There is no Fibonacci/Lucas/Tribonacci switch, no recurrence-name switch, no generated-C wrapper, no LLVM lowering, no JIT, no runtime dependency walker, no runtime register allocator, no work stealing, and no global ready queue.

The direct scalar physicalizer is intentionally proof-bounded. Forms outside its current admitted arithmetic/type set keep the pre-existing semantic path instead of silently changing behavior.

## Structural result

For validated admitted native transition kernels, the steady-state hot transition has:

```text
artificial expression push/pop = 0
persistent state/temp-array traffic = 0
runtime transition graph walk = 0
runtime register allocation = 0
```

The validated floating transition additionally keeps persistent floating state in XMM registers and removes the previous state transport through GPR/stack machinery.

## Compatibility

The 1.3.12 release authority remains part of the 1.3.13 gate. Existing unsupported or trapping cases are not forced into native admission. The fallback preserves prior semantics.
