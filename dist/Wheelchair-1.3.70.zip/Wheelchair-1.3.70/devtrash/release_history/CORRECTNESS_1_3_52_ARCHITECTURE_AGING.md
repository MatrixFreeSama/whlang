# Correctness proof: architecture aging 1.3.52

The release gate requires all inherited 1.3.51 semantic tests to pass after the convergence. It additionally verifies:

- production Tensor and Physical-Reality paths use current semantic filenames;
- there is exactly one production Physical-Reality include authority;
- dead wide compiler aliases are absent from build and release binaries;
- removed unreachable production sources/helpers remain absent;
- production build does not depend on `devtrash`;
- production build does not replay historical version banners;
- canonical release binary set is complete and statically linked.

A mature Newton-Jv AOT probe was compiled with both 1.3.51 and 1.3.52. The resulting ELFs are byte-for-byte identical and share SHA-256 `bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac`. This is the runtime non-regression oracle for the naming/build-path aging.
