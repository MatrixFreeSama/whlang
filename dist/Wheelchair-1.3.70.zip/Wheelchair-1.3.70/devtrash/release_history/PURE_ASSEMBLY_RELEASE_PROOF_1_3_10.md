# Wheelchair 1.3.10 Pure Assembly Release Proof

Wheelchair 1.3.10 remains an AOT direct-native implementation. The production compiler/runtime path does not invoke Python, C, LLVM, MLIR or a JIT backend.

## Execution authority

Tensor and Field production runtimes implement:

```text
run_causal_tree
try_claim_credit
release_credit
worker_range
```

No production Tensor/Field runtime contains the historical `g_exec` or `run_tree_strict` authority.

The old static equal-partition and proportional executor-split formulas are absent from production compiler/runtime/frozen assembly authority.

## Anonymous capacity fabric

Four 64-byte-separated credit words encode anonymous capacity slots. Credits are striped across these lines. A claim performs one bounded pass and uses atomic bit-test-and-reset. Release uses atomic bit-test-and-set.

There is no single global surplus counter, worker-load table, donor table, recipient table or global ready queue.

A failed claim contains no `pause`, `sched_yield`, futex poll or sleep-poll loop. It continues existing causal work. At later real causal expansion points a new bounded claim may occur.

## Compatibility boundary

Production source authority uses `tensor_capacity_ceiling`, `MAX_CAPACITY_SLOTS` and `RUNTIME_CAPACITY_CEILING_OFF`.

Historical `tensor_executor_count`, `executor_count_patch` and executor offset names are retained only as same-address compatibility aliases where old binaries/tests require them. They are not used as work-demand authorities.

## Protected non-balancing structures

- General causal futex/indegree execution is retained.
- AOT topology queues are retained.
- compile-time physical scheduling is retained.
- intra-kernel SIMD reduction carriers are retained.

These structures operate on causal dependencies or already-active machine work and do not redistribute runtime work to equalize worker occupancy.

## Numerical authority

The 1.3.8 strict capacity-count bit identity remains intact on native512 and native256. The canonical 1.3.10 causal tree also makes the FSI tolerant diagnostic capacity-independent at q1/q2/q4.

## Machine-code isolation

For the FSI audit, the 1.3.8 and 1.3.10 generated arithmetic payloads are byte-identical while the runtime execution image changes. This isolates the measured active-CPU-time change to the execution fabric rather than to arithmetic-kernel specialization.

## Release boundary

The definitive executable checks are in:

- `test_blind_surplus_reflow_1310.sh`
- `test_strict_parallel_reduction_138.sh`
- `test_release_native_1310.sh`

The release is valid only if the complete historical authority and the new 1.3.10 gates pass from the packaged tree.
