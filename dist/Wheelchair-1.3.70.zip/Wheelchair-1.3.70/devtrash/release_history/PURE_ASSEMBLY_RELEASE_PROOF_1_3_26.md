# Pure Assembly Release Proof 1.3.26

Wheelchair 1.3.26 production implementation remains handwritten x86-64 assembly plus shell build tooling.

The Field lifetime change is implemented inside `compiler/field_frontend_common_x86_64.S`. It introduces no C/C++, Fortran, Python, LLVM, MLIR, JIT, runtime register allocator, or workload dispatcher into the production path.

The direct regular-neighborhood path consumes existing invocation-stable AddressFacts. Resident LoadFacts are placed directly into the final post-helper physical carrier when no later clobber requires reload authority. Irregular/padded layouts keep the existing truthful gather/helper authority.

The release gate checks static linkage and the complete inherited native suite.
