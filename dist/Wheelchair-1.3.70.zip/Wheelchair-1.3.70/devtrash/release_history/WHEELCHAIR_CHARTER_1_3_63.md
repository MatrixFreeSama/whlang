# Wheelchair 1.3.63 charter: one Group authority

Automatic Grouping is part of the old architecture, not a selectable optimization family.

- ShapeFact-N owns logical axes.
- GroupFact owns derived group form plus body/carrier factors.
- Physical Reality prices and constrains those same factors.
- Physical DAG / backend realization may prove or reject the realization, but may not create a second width authority.
- Vector is a degraded Group realization; Scalar is a degraded Vector realization.
- No workload route, fixed group threshold, runtime group manager, compatibility vectorizer, shadow plan width, or legacy unroll authority is permitted.
- Existing protected machine-code peaks remain binding regression anchors.
