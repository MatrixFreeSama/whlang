# Wheelchair 1.3.65 performance note

1.3.65 is the first Automatic Grouping release in which representative generated target ELFs intentionally diverge from 1.3.64 because GroupFact changes the Physical DAG and hot-loop control shape.

A final release-candidate measurement was run on the current shared AMD EPYC 9V74 environment using `devtrash/benchmarks/execution_compression_1213/dense_bilinear_128.whex` with `n=8192`. The 1.3.64 and 1.3.65 results were bit-identical (`checksum_bits=0x4100fa446c000000`) while their target ELF SHA-256 values differed. Across nine interleaved runs, median wall time changed from 16.248 ms to 14.766 ms (about 1.100x), and median aggregate process CPU time changed from 56.485 ms to 54.163 ms (about 1.043x).

This probe keeps the realized body factor at two in both releases. The gain therefore does not come from selecting a larger fixed unroll width; it comes from the Group episode replacing repeated per-Vector control/countdown work with one Group-level edge while preserving the same mathematical result.

Finite Rank-N probes also demonstrate a structural capability change. On the release target, a 512-wide Rank-2 probe that realized body factor 4 in 1.3.64 realizes body factor 8 in 1.3.65 after removal of the historical fixed 32-packet dense gate. The factor is selected from measured body footprint, ShapeFact divisibility and target physical facts, not from a width candidate table.

The shared host is noisy and other probes range from small gains to near parity or small regressions. The release therefore makes no universal speedup claim. The hard result is that Group execution now changes machine code and can remove control work that ordinary Vector physicalization retains, while workloads with no higher-order structure canonically degrade to the mature Vector path.
