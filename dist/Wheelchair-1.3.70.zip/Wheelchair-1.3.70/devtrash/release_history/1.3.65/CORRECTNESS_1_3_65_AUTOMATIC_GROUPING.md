# Correctness: Wheelchair 1.3.65 Automatic Grouping

1.3.65 closes GroupFact into executable Physical Reality without adding a second optimizer family. The authority chain remains `ValueFact / ShapeFact-N / Axis / Operator -> GroupFact -> Physical Reality -> Physical DAG -> ISA realization`.

Release validation covers base/derived AVX-512 and native256 production compilers. Strict programs preserve strict semantics. Tolerant programs are checked against their declared numerical contract rather than requiring invalid universal bitwise equality after legal reassociation.

Current release gates prove the following structural laws:

- Group is primary; Vector and Scalar are canonical degradations.
- The mature Vector physical episode is preserved when no higher-order Group relation survives.
- Group body extent is derived from measured one-body footprint, ShapeFact geometry and target physical facts.
- Necessary arithmetic work is conserved when outward execution materialization is priced; widening a Group cannot pretend the work disappeared.
- Realized body/carrier witnesses close over the same GroupFact factors instead of creating a second width authority.
- Complete Group episodes use one Group-level countdown/back-edge; interior packets may consume strengthened boundary facts.
- The historical fixed 32-packet dense full-unroll gate is absent.
- No runtime group selector/manager, workload identity route, fixed candidate width set, fixed expansion threshold, compatibility vectorizer or duplicate shape authority exists.

Representative Newton-Jv, ShapeFact-N Rank-3 and native256 light-reduction correctness probes pass. A finite 512-wide Rank-2 probe also verifies that selected and realized Group body/carrier factors agree exactly and that the new release is no longer constrained by the historical four-body fallback produced beyond the old dense gate.
