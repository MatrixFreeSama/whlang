# Wheelchair 1.3.65 release notes

Automatic Grouping now executes as a native Physical-DAG episode instead of remaining only a structural fact. One-body code/resource measurement, ShapeFact-N geometry, Operator relations and target silicon facts feed the existing Physical Reality authority; the canonical generator can emit a complete Group with one control edge, strengthened interior facts and vectorized remainder handling.

The mature Vector physicalization is the canonical degradation floor. Group may widen or compress it only when additional structure is proved; an unbounded stream with no higher-order structure stays on the mature Vector episode. Reduction carrier demand cannot manufacture Group width, and realized carrier/body witnesses close over what the episode can actually emit.

Group-aware outward-materialization pricing now conserves necessary arithmetic work over the complete episode. Wider Groups may erase control/materialization edges, but they cannot appear cheaper merely because the original probe measured one body.

The historical fixed 32-packet dense full-unroll gate is removed. Finite Rank-N grouping is selected from measured body footprint, ShapeFact divisibility and target physical facts instead of a 2/4/8/16/32 candidate zoo. There is no runtime group manager, profitability selector, workload-name route, fixed expansion threshold or compatibility vectorizer.

A final dense-bilinear probe produced different 1.3.64/1.3.65 ELFs with bit-identical results and measured about 1.10x median wall-time and 1.043x aggregate-CPU improvement on the current shared host. This is a structure-specific measurement, not a universal speedup guarantee.
