#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ -x bin/topologyc ] || ./build.sh >/dev/null

# One authority chain: Group -> Vector -> Scalar. Vector is the canonical
# degradation floor when no higher-order relation survives.
for law in \
  GF_VECTOR_IS_DEGENERATE_GROUP \
  GF_VECTOR_PHYSICAL_BASELINE_PRESERVED \
  GF_GROUP_BODY_FROM_MEASURED_PHYSICAL_COST \
  GF_GROUP_LEVEL_CONTROL_EDGE \
  GF_INTERIOR_RELATION_STRENGTHENING \
  GF_NECESSARY_WORK_CONSERVED \
  GF_REALIZATION_CLOSED_OVER_BODY \
  GF_VECTOR_DEGRADATION_IS_CANONICAL; do
  grep -q "^.equ ${law},1$" compiler/groupfact.inc
done
for law in \
  GF_GROUP_WIDTH_CANDIDATE_SET \
  GF_GROUP_PROFITABILITY_WORKLOAD_ROUTE \
  GF_FIXED_DENSE_PACKET_GATE; do
  grep -q "^.equ ${law},0$" compiler/groupfact.inc
done
for law in \
  PR_GROUP_EXECUTING_PHYSICAL_EPISODE \
  PR_GROUP_MEASURED_BODY_FOOTPRINT \
  PR_GROUP_PRESERVES_VECTOR_BASELINE \
  PR_GROUP_INTERIOR_FACT_STRENGTHENING \
  PR_GROUP_NECESSARY_WORK_CONSERVED \
  PR_GROUP_REALIZATION_CLOSED_OVER_BODY \
  PR_VECTOR_DEGRADATION_IS_CANONICAL \
  PR_GROUP_CONTROL_EDGE_PER_EPISODE; do
  grep -q "^.equ ${law},1$" compiler/physical_reality.inc
done
for law in PR_GROUP_RUNTIME_PROFITABILITY_SELECTOR PR_GROUP_FIXED_EXPANSION_THRESHOLD PR_FIXED_DENSE_PACKET_GATE; do
  grep -q "^.equ ${law},0$" compiler/physical_reality.inc
done

# Deleted double-authority / compatibility vocabulary must not return to
# production source. Historical copies under devtrash are intentionally excluded.
for pat in \
  vec_dense_unroll4 \
  vec_dense_unroll_packets \
  shape_legacy_input \
  TENSOR_RUNTIME_GROUP_BODY_MAX \
  schedule_unroll; do
  ! grep -Rqs "$pat" compiler runtime surface tools
 done
! grep -Rqs 'physical_plan_group_body' compiler runtime surface tools
! grep -RqsE 'group_(candidate|threshold)_(2|4|8|16|32)|workload.*group.*route' compiler runtime surface tools

# Necessary arithmetic work is priced over the complete Group episode.
grep -q 'imul rbx,rcx' compiler/outward_materialization_profile_x86_64.S
grep -q 'mul rcx' compiler/outward_materialization_profile_x86_64.S

# Group-level control exists in the base paths; dense Rank-N owns its equivalent
# countdown and no longer has the old fixed 32-packet full-unroll gate.
grep -q '^vec_emit_group_countdown_backedge:' compiler/tensor_frontend_x86_64.S
grep -q '^vec_emit_group_countdown_backedge:' compiler/tensor_frontend_native256_x86_64.S
grep -q '^vec_dense_emit_group_countdown:' compiler/tensor_derived_frontend_x86_64.S
grep -q '^vec_dense_group_preflight:' compiler/tensor_derived_frontend_x86_64.S
! grep -Fq 'bounded full-unroll text budget' compiler/tensor_derived_frontend_x86_64.S

T=$(mktemp -d); trap 'rm -rf "$T"' EXIT

# Mature Vector-degeneration correctness remains intact.
bin/topologyc devtrash/tests/whex/newton_jv_mature_regression.whex -o "$T/newton" >/dev/null
[ "$("$T/newton" 4)" = 'checksum_bits=0xbfaa960790000000' ]
bin/topologyc-native256 devtrash/tests/whex/emergent_light_reduction_1318.whex -o "$T/light256" >/dev/null
[ "$("$T/light256" 4)" = 'checksum_bits=0x4078400000000000' ]

# Finite ShapeFact geometry now produces an executing arbitrary Group. The
# realized witness must close exactly over the selected GroupFact factors.
R=devtrash/benchmarks/automatic_grouping_1365/group_rank2_512_light.whex
bin/topologyc-derived "$R" -o "$T/rank2_512" >/dev/null
body=$(od -An -tu4 -j 4132 -N4 "$T/rank2_512" | tr -d ' \n')
carrier=$(od -An -tu4 -j 4128 -N4 "$T/rank2_512" | tr -d ' \n')
rbody=$(od -An -tu4 -j 4140 -N4 "$T/rank2_512" | tr -d ' \n')
rcarrier=$(od -An -tu4 -j 4136 -N4 "$T/rank2_512" | tr -d ' \n')
[ "$body" -ge 1 ]
[ "$carrier" -ge 1 ]
[ "$body" = "$rbody" ]
[ "$carrier" = "$rcarrier" ]

# The historical 32-packet dense gate is gone: 512-wide finite Rank-N geometry
# is not forced back to the old four-body fallback on this release target.
[ "$body" -gt 4 ]

# Representative current ShapeFact result remains correct.
bin/topologyc-derived devtrash/tests/shapefact_1357/rank3_batch.whex -o "$T/r3" >/dev/null
[ "$("$T/r3" 2)" = 'checksum_bits=0x405a400000000000' ]

echo AUTOMATIC_GROUPING_EXECUTION_1_3_65=PASS
