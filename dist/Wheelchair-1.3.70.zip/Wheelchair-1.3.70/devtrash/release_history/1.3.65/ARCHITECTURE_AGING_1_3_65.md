# Wheelchair 1.3.65 Automatic Grouping execution convergence

1.3.65 turns GroupFact from a structural authority into an executing Physical-DAG form without adding a second optimizer family.

The authority chain remains:

`ValueFact / ShapeFact-N / Axis / Operator -> GroupFact -> Physical Reality -> Physical DAG -> ISA realization`

Vector is the mature physical degradation floor of Group, not a competing backend. If higher-order structure does not survive, the compiler preserves that Vector episode. When finite ShapeFact/Operator geometry proves a larger computation group, the body factor is derived from measured one-body code/resource facts, divisibility and target front-end/L1I facts. No fixed width candidate table participates.

A complete Group episode owns one hot control edge. The Group guard proves the complete episode; strictly interior packets inherit stronger boundary facts; the complete Group performs one countdown/back-edge; the remainder stays vectorized. Dense Rank-N lowering uses the same Group authority and no longer contains the historical fixed 32-packet full-unroll gate.

Resource truth is conserved across the architecture. One-body probe work is multiplied by the realized Group body when outward execution materialization is priced, so grouping may remove redundant control/materialization but cannot erase necessary arithmetic from the AOT cost model. Carrier demand is also closed over the body the canonical episode can actually realize rather than creating an independent width authority.

There is no scalar oracle, runtime group manager, runtime profitability selector, work queue, workload-name route, fixed group/tile size, fixed expansion threshold or compatibility vectorizer. Group, Vector and Scalar remain one physical degradation chain.
