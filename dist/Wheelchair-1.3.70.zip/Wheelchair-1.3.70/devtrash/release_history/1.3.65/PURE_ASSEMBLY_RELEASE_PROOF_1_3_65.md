# Pure assembly release proof 1.3.65

The production compiler/runtime path remains handwritten assembly and direct ELF emission. Automatic Grouping adds no C/LLVM/JIT/runtime autotuner or generated-language backend.

`build.sh` reconstructs all production binaries from the source tree. The release archive excludes the generated `build/` workspace. Group execution is decided AOT from existing semantic/physical facts and emitted directly into the target image.
