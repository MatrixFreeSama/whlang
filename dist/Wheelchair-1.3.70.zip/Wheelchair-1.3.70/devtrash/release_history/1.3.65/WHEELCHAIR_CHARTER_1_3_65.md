# Wheelchair Charter 1.3.65

- Group is the complete structural computation form; Vector and Scalar are degradations.
- Automatic Grouping must emerge from existing ValueFact, ShapeFact-N, Axis, Operator, Region, Effect, Capability and Physical Reality facts.
- A new Group mechanism may strengthen the mature Vector physicalization but must not weaken or replace it with a poorer baseline.
- Group extent is a derived physical fact, never a fixed source-size threshold or candidate table.
- Complete Group episodes should erase redundant control/materialization edges where the relation proves them unnecessary.
- No work stealing, global ready queue, runtime grouping manager, JIT, workload-name dispatch or hidden serial coordinator is admissible.
- Finished work releases resources recipient-blind; Group execution does not redistribute work.
