# Wheelchair 1.3.7 Pure Assembly Release Proof

The production compiler/runtime remains shell plus handwritten x86-64 assembly. The release contains no Python source and `build.sh` invokes no Python, GCC, Clang, LLVM `llc`, LLVM `opt`, MLIR or JIT backend.

The new Tensor Physical Reality machinery lives in:

- `compiler/tensor_frontend_137_x86_64.S`
- `compiler/physical_reality_137.inc`

All use counting, fact profitability, lifetime selection, constant selection and affine selection occur while compiling. The generated program contains no fact manager, residency manager, autotuner, work-stealing loop, global ready queue or resource-recipient selector.

The base and wide native512 profiles assemble the same semantic fact machinery with different compile-time register budgets. Native256 remains on the inherited sovereign assembly path and is covered by historical release authority.
