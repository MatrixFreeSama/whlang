# Wheelchair 1.3.56 final compiler-workspace aging

1.3.56 continues the convergence rule: if the existing graph, source instance or emitted code already contains the true size, a compiler table is not allowed to redefine that size as a language capability. No new source syntax, mathematical algorithm family, scheduler, ISA backend, compatibility route or benchmark-specialized path is introduced.

## Field instance cardinality

Field and access counts are no longer runtime/compiler capacity constants. The compiler allocates field/access metadata from the parsed instance, appends exact field-mode/rank/access-delta metadata to the generated image, and both native Field runtimes allocate launch metadata from the patched concrete counts. The retired `8 fields` and `128 accesses` tiers therefore disappear without a larger replacement constant.

`FIELD_RUNTIME_RANK_CAP=8` deliberately remains. It is the width of the current `WHFLD216` external file header (eight extent/stride slots) and is consumed by rank-specialized runtime helpers. Changing it would define a new external representation, not age an implementation workspace.

The four logical Field VREGs likewise remain the current physical expression-carrier model. 1.3.56 does not pretend a new spill-capable Field physicalizer exists.

## Tensor compiler workspace

All four Tensor physicalizers now size scalar/vector/init code staging from the source instance and replay the whole AOT pass if the arena grows. Fixup metadata is derived from the same code arena rather than an independent 524,288-entry table.

Constant-interning and affine-linear optimizer facts are allocated from the actual parsed JSON-node population. The retired 512/2048 constant/fact tables no longer define acceptance. The optimizer state is compiler metadata only; generated Tensor semantics and runtime descriptors are unchanged.

Tensor's single external dynamic-extent semantic slice remains visible. Generalizing that descriptor to multiple runtime extents would add Tensor semantics and is outside architecture aging.

## What this release intentionally does not call a capacity bug

- `WHFLD216` rank width;
- the current four-logical-VREG Field physicalizer;
- Tensor's current one-runtime-extent canonical descriptor;
- finite ISA register ownership and OS/address-space failure;
- mathematical admissibility such as division by zero or singular inverse;
- f64-origin coefficient accuracy in some advanced special-function recipes. That is numerical recipe precision, not a fixed compiler-storage capacity.

Those owners remain explicit rather than being hidden behind larger constants.
