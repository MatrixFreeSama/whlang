# Wheelchair 1.3.16 Release Notes

## Whole-Episode Physical DAG Strengthening

1.3.16 continues the 1.3.14/1.3.15 consolidation line. It does not add a chemistry backend, rigid-body backend, reaction-rate cache, large-expression backend, runtime CSE manager or runtime register scheduler.

### Removed cliffs

- Constant count is no longer a causal-episode admission class. The seven-state pressure probe remains in VEX Physical DAG form from two through eight distinct hot constants.
- Temporary-carrier shortage no longer forces the entire admitted episode into the legacy stack evaluator merely because additional constants are profitable.

### Strengthened old Physical Reality

- Peak anonymous FP temporary pressure is measured by speculative AOT physicalization.
- Persistent state, whole-episode shared ValueFacts and immutable constants request XMM carriers from the same compile-time authority.
- Exact strict-order FP add/sub/mul subtrees are discovered across all simultaneous next-state expressions.
- Ready and future shared-fact identities are separated.
- Retained shared facts form a parent/child antichain.
- Retained shared carriers cannot be returned by anonymous temporary release.

### Correctness

Strict FP operation order is part of ValueFact identity. No reassociation or commutative canonicalization is used. Release probes for six-species mass-action kinetics, a seven-state quaternion/rigid-body system, a shared-quaternion-norm system and a six-state three-mass chain are bit-identical to strict C/Fortran references at the authority checkpoints.

### Performance evidence

On the authority AMD EPYC 9V74 host, the full seven-state rigid-body probe changes from 1.3.15 generic-stack realization (~100.49 ms / 1M steps) to 1.3.16 VEX Physical DAG realization (~17.29 ms), about 5.81x faster on the same host. The shared quaternion-norm hot episode falls from 53/28/7 multiply/add/sub instructions to 38/19/4, matching strict reference arithmetic counts.

The chemical network is intentionally not presented as a wall-time win: multiply count falls from 33 to 25 but the current retained-fact carrier cost makes this authority run slower than 1.3.15. The unresolved profitability work remains inside the same old architecture rather than being hidden by a workload-specific path.
