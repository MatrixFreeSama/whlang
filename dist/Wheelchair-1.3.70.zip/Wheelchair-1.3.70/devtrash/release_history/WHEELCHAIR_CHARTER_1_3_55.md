# Wheelchair charter addendum — 1.3.55

## Instance structure owns capacity

When an existing AOT structure already provides cardinality, a fixed implementation table must not become a language capability boundary. Inputs, outputs, bindings, iterate states, generated code and precision workspaces should derive storage from the actual program instance or from the precision fact that consumes them.

Increasing an old constant is not convergence. The preferred sequence is: measure the existing structure, derive exact or conservatively growable physical storage, emit once or replay the existing AOT pass, and preserve the same semantic authority.

## No semantic camouflage

A lower-layer boundary that has not been generalized remains explicit. 1.3.55 therefore does not claim generalized Field runtime rank/VREG semantics, Tensor multiple runtime extents, or arbitrary special-function coefficient precision merely because neighboring storage has been aged.

## Preserve technical peaks

Architecture aging must not reduce established generated-code quality merely to simplify implementation. Byte-identical Newton-Jv generation across 1.3.54 and 1.3.55 is a release invariant for this work.
