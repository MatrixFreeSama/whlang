# Correctness: Rank-N Precision Physical Assimilation, 1.3.39

The 1.3.39 release requires two independent layers of correctness.

The inherited parameterized semantic gate checks arbitrary precisions, exact rational `+ - * /`, decimal ingress, round-to-nearest-even, low/high precision propagation and nested meet-edge behavior.

The new physical gate then checks the replacement implementation itself:

- full-width random significands at P = 65, 73, 113, 127, 191, 257, 521, 1024, 2048 and 4096;
- AVX-512 IFMA batch products checked against a Python exact-integer/Fraction oracle, not only against Wheelchair singleton multiplication;
- full-width Knuth division checked against the same independent oracle with final P-bit RNE;
- `rankn_fp_mul_span` checked against singleton canonical results for the same values;
- post-object and post-scratch canaries checked for overwrite;
- source scans proving the old scalar-only file, old product carry-walk label and old bitwise quotient loop are absent;
- source scans rejecting named-precision conditions in the physical cost selector.

Python and the C harness are test-only external oracles. Production compiler/runtime artifacts remain handwritten assembly.
