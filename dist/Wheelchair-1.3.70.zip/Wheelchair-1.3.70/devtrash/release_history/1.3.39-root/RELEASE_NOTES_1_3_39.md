# Wheelchair 1.3.39 Release Notes

1.3.39 keeps the parameterized `fpP` language semantics from 1.3.38 and replaces the wide-precision physical realization underneath them.

## Removed

- `runtime/rankn_precision_x86_64.inc` scalar-only implementation;
- the old multiplication path whose partial-product overflow could walk an unbounded carry chain through the product plane;
- bit-by-bit restoring division;
- any requirement for a named precision width in physical selection.

## Added to the common Rank-N authority

- `runtime/rankn_precision_physical_x86_64.inc` as the single wide physical source;
- bounded canonical-u64 row-carry singleton multiplication;
- a base-2^52 SoA product plane for eight independent logical values;
- AVX-512 IFMA (`vpmadd52luq`/`vpmadd52huq`) batch multiplication when genuine same-depth work and ISA support exist;
- a structural multiplication cost comparison derived from limb span/vector work rather than a fixed P threshold;
- base-2^32 Knuth digit division;
- compiler/runtime carrier-span capacity derived from the same P-dependent physical bound.

## Correctness

The inherited arbitrary-P gate still validates unrelated precisions 65, 73, 127, 191, 257, 521 and 2048 bits for exact-rational arithmetic, RNE and precision propagation. The new 1.3.39 physical gate additionally validates full-width random multiplication/division through 4096 bits against an independent exact Fraction oracle, validates IFMA batch output rather than merely comparing two Wheelchair paths, and places canaries after every object/scratch domain.

## Performance

The single-value path remains slower than C/GMP, but the former catastrophic restoring-division deficit is greatly reduced: at 256/512/1024/2048 bits the measured division throughput improved by roughly 22.4x, 24.4x, 22.0x and 13.6x relative to the 1.3.38 release benchmark.

For true Rank-N multiplication spans on the release Xeon Platinum 8573C, the structural selector begins preferring the IFMA product plane only once its estimated work is lower. Median measurements show the span candidate about 1.78x faster than the new singleton candidate at 3072 bits, 1.83x at 4096, 2.93x at 8192 and 3.28x at 16384. C/GMP remains faster in these tests; the report does not disguise that boundary.
