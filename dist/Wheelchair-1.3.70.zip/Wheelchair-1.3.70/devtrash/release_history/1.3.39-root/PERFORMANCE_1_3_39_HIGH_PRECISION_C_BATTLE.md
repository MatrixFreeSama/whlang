# Wheelchair 1.3.39 High-Precision C Battle

Machine: Intel Xeon Platinum 8573C, one CPU pinned, GCC 14.2, GMP 6.3.0, AVX2/AVX-512/AVX-512IFMA available. Inputs use full-width random significands. Timed results are medians after warmup. C/GMP is a test baseline only.

## Ordinary singleton path

| P bits | op | Wheelchair Mops/s | C+GMP Mops/s | C advantage |
|---:|:---:|---:|---:|---:|
| 256 | + | 11.365 | 56.629 | 4.98x |
| 256 | * | 18.183 | 59.184 | 3.25x |
| 256 | / | 2.604 | 18.003 | 6.91x |
| 512 | + | 8.632 | 48.907 | 5.67x |
| 512 | * | 8.218 | 19.532 | 2.38x |
| 512 | / | 1.108 | 10.320 | 9.32x |
| 1024 | + | 5.209 | 45.546 | 8.74x |
| 1024 | * | 2.990 | 6.149 | 2.06x |
| 1024 | / | 0.382 | 4.140 | 10.83x |
| 2048 | + | 3.071 | 34.242 | 11.15x |
| 2048 | * | 0.842 | 1.821 | 2.16x |
| 2048 | / | 0.0575 | 1.518 | 26.40x |

At 113 significand bits, Wheelchair measured 13.893 Mops/s add, 26.224 multiply and 4.500 divide. C `__float128` measured 76.592, 74.250 and 41.517 Mops/s respectively.

The singleton path therefore still loses mature C implementations. The important 1.3.39 change is that division is no longer the 1.3.38 bit-restoring implementation. Against the recorded 1.3.38 benchmark, division throughput improved about 22.4x at 256 bits, 24.4x at 512, 22.0x at 1024 and 13.6x at 2048.

## Rank-N multiplication span

The following test contains 64 independent full-width values at one causal depth. `rankn_fp_mul_span` is allowed to choose the IFMA product plane only when its structural cost estimate beats eight singleton products. No precision threshold is coded.

| P bits | singleton ns/value | Rank-N span ns/value | C+GMP ns/value | span speedup vs singleton | C advantage vs span |
|---:|---:|---:|---:|---:|---:|
| 1024 | 364.290 | 336.888 | 178.787 | 1.08x | 1.88x |
| 2048 | 1329.625 | 1446.675 | 542.403 | 0.92x | 2.67x |
| 3072 | 2696.919 | 1518.326 | 1287.197 | 1.78x | 1.18x |
| 4096 | 5084.112 | 2781.288 | 1524.268 | 1.83x | 1.82x |
| 8192 | 20642.860 | 7052.889 | 5086.737 | 2.93x | 1.39x |
| 16384 | 69564.467 | 21224.566 | 13461.602 | 3.28x | 1.58x |

The span path is therefore a real production physical improvement over the singleton candidate at the larger measured widths, but it does not yet beat C/GMP in the median comparison. The release makes no contrary claim.

## Interpretation

1.3.39 removes the old scalar-only architecture rather than hiding it behind a vector wrapper. A singleton still needs a legal singleton physical candidate because no parallel peer work exists. Independent Rank-N values can instead be materialized through the IFMA product plane. The remaining gap to GMP at very large precision is primarily algorithmic: the current product plane is still quadratic work, while mature big-number libraries may use Karatsuba/Toom/convolution families. Those are future physical candidates, not reasons to reintroduce named precision branches.
