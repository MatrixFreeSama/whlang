# Wheelchair Charter 1.3.39

## Mandatory architecture order

1. **Parasite old architecture first.** Existing ValueFact, Rank-N, Physical DAG, precision, topology and lifetime authorities are the first destination of every new semantic.
2. **Strengthen old architecture second.** If the common substrate is almost sufficient, generalize it instead of opening a feature branch.
3. **New architecture is last resort.** It is permitted only where the old substrate cannot express the requirement without contradiction.
4. Any unavoidable new authority must be high-affinity, high-extensibility and explicitly assimilatable. Its destination is the common substrate.

## Precision is data

`f32` and `f64` are native. `fpP`, P > 64, is one parameterized floating semantic. No production source may select an implementation by named wide precision. The compiler encodes P in the type fact and derives physical limb span from P.

The existing precision meet is authoritative and executes before physicalization. `precision_propagation` may act only at a real ValueFact consumer edge.

## Rank-N physicalization

Wide precision is a logical ValueFact plus a Rank-N precision-limb relation. Physical candidates may include singleton limb arithmetic or an ISA-width product plane when genuine independent work exists. A physical candidate may not invent independence, hide a serial dependency, or require a width-specific branch.

Selection must be based on structure such as limb span, vector width, materialization/rejoin work, locality and available ISA. A fixed precision threshold is not an architectural selector.

The 1.3.39 multiplication span candidate uses AVX-512 IFMA only when structural cost predicts lower work and the OS/CPU exposes usable ZMM state. Otherwise the same common authority falls back without changing language semantics.

## Deleted legacy realization

The 1.3.38 scalar-only physical source is not retained as compatibility code. Its unbounded product carry walk and bit-by-bit restoring quotient path are deleted. The singleton replacement is bounded row-carry multiplication and base-2^32 Knuth digit division under the same Rank-N precision authority.
