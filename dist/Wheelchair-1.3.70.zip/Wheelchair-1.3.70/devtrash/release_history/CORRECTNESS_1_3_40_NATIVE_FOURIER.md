# Correctness 1.3.40: Native Fourier high precision

## Authority boundary

`rankn_fp_mul` is the sole production `P > 64` multiplication entry point. It preserves the existing ValueFact ABI, sign/exponent semantics, precision meet and final RNE machinery. Only the integer-significand product realization changed.

## Geometry

A geometry fact contains coefficient width `b` and mixed-radix exponents `a2`, `a3`, `a5` with:

```text
n = ceil(P/b)
N = 2^a2 * 3^a3 * 5^a5
N >= 2*n - 1
```

The native rounding guard requires:

```text
n * (2^b - 1)^2 * ceil(log2(N)) < 2^51
```

AOT generated programs store the packed geometry in the existing object header. Ingress-only calls without an AOT fact derive the same geometry from the same closure.

## Product identity

For coefficient vectors `a` and `b`, the runtime packs `z=a+i*b` and evaluates:

```text
z*z = (a*a - b*b) + i*2*a*b
```

Therefore the desired coefficient convolution is the imaginary part of the inverse transform divided by two. Forward DIF and inverse DIT use matching mixed-radix geometry, so frequency-domain pointwise squaring does not require a global permutation.

## Release oracle

`devtrash/release_tests/test_rankn_precision_fourier_1340.sh` compares the production assembly directly against GMP integer products and independently applies exact P-bit round-to-nearest-even.

Test precisions include both regular and deliberately awkward widths:

```text
65 73 113 127 191 257 521 1024 2048 4096 8192 16384 32768
65536 65537 100003 131071 131072 262144 262147 524288 524309
1048576 1048583 2097152 2097169 4194304 4194319
```

The oracle uses random full-width significands, the all-ones worst-case significand, and an alternating-bit pattern. Canary bytes after every tested physical object must remain untouched.

The inherited `test_parametric_rankn_fp_1340.sh` validates language-level arithmetic, long decimal ingress, unrelated precision values, low/high propagation and nested meet-edge behavior.
