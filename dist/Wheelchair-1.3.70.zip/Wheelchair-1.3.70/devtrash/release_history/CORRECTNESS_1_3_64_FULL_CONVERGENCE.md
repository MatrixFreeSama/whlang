# Wheelchair 1.3.64 full convergence correctness

## Build proof

The complete handwritten-assembly build succeeds after removing the compatibility aliases and native256 pseudo-domains. The 1.3.64 release gate reports:

- `FULL_CONVERGENCE_1_3_64=PASS`
- `INTERNAL_COMPATIBILITY_ALIASES=0`
- `NATIVE256_GHOST_CONSTANT_DOMAIN=0`
- `WHEELCHAIR_1_3_64_BUILD=PASS`

## Differential machine-code proof

The following 13 representative sources were compiled with both the 1.3.63 production compiler and the 1.3.64 candidate. Every resulting user target ELF compared byte-for-byte identical:

1. Newton-Jv / canonical x86-64 Tensor path
2. coupled FSI / canonical x86-64 Tensor path
3. Rank-3 / derived Tensor path
4. Rank-6 / derived Tensor path
5. lightweight reduction
6. strict operator subspace
7. ShapeFact-N Rank-3 / derived Tensor path
8. Newton-Jv / native256
9. Rank-3 / derived native256
10. ShapeFact-N Rank-3 / derived native256
11. general iterate
12. human-surface feature showcase
13. English human-surface equivalence example

Therefore the removed native256 cache and compatibility structures were not part of the realized semantics for these protected paths. Their deletion changes compiler bookkeeping only, while preserving generated machine code.
