# Correctness 1.3.46: Human-Shell Static Select

The release gate checks three properties:

1. A compact `contract(t in 4, select(...))` program compiles.
2. The compact and hand-expanded strict programs execute on the same native
   WHFLD216 input and produce byte-identical output field files.
3. The complete compact Hex8 FEM source compiles through the production WH
   frontend without exposing a runtime field select.

During development, the compact Hex8 source and the prior expanded WH source
were also run on the same 64^3 five-field input set.  All three output `.whfld`
files compared byte-for-byte.
