# Pure Assembly Release Proof 1.3.46

The 1.3.46 implementation change is a handwritten x86-64 assembly surface
change in `compiler/surface_lowerer_x86_64.S` only.  Relative to the released
1.3.45 compiler source, runtime and physicalization sources are unchanged.

The new path calls the already existing static integer evaluator during lexical
substitution and chooses an existing AST branch.  Production compilation
remains AOT and the release binaries remain static executables.
