# Wheelchair 1.3.46 Release Notes

Wheelchair 1.3.46 closes one remaining WH human-shell composition gap from
1.3.45.  It does not add a mathematical algorithm, runtime object, field
opcode, execution backend, or physicalization authority.

When selected-axis `contract` substitution makes a `select(predicate,a,b)`
predicate compile-time static, the surface now evaluates that predicate first
and clones only the selected source branch.  The discarded branch never enters
the scalar AST.

This lets existing authorities compose naturally in compact field source:

```text
MatrixFact + mget + contract + affine neighborhood + static select
```

The release test executes a compact static-select contraction probe and its
strict hand-expanded source on the same native WHFLD216 input and requires
byte-identical output field files.  The full Hex8
FEM compact source is retained under `devtrash/benchmarks/human_shell_1346/`;
it preserves the original 384-term accumulation order per output component.
