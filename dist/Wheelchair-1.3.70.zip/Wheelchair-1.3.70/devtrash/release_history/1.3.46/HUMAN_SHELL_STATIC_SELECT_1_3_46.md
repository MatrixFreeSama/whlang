# Wheelchair 1.3.46 Human-Shell Static Select Erasure

## Scope

The change is confined to lexical AST substitution in
`compiler/surface_lowerer_x86_64.S`.

Before 1.3.46, contraction-axis substitution could make a `select` predicate
fully static, but the clone path still materialized both data branches before
later processing.  Large compact expressions therefore created compile-time
AST that was known to be dead.

1.3.46 asks the existing `s_eval_static_u64` authority to evaluate the cloned
predicate immediately.  If static, exactly one old AST branch is cloned.  If
not static, ordinary select handling is unchanged.

No new evaluator, threshold, runtime branch, field opcode, tensor backend or
execution path is introduced.
