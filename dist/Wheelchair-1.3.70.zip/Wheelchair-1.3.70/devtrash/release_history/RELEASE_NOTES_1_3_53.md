# Wheelchair 1.3.53 release notes

1.3.53 converges iteration ownership across existing advanced mathematics. It adds no new algorithm family, mathematics runtime, precision-specific solver, scheduler, compatibility route, or ISA backend.

Advanced relations that already contained a compile-time refinement budget now accept one optional final AOT-static count. Omission preserves the historical fallback. Explicit input controls the same existing relation. This follows the contract already used by `root(...[,iterations])`.

The shared registry contract covers Lambert W, inverse erf, digamma/trigamma recurrence shift, zeta cutoff, polylog series depth, complete elliptic AGM refinement, matrix exponential/logarithm/square-root refinement, eigensystem power iteration, and SVD spectral iteration. Integral keeps its historical GL8 formula and optionally repeats that same panel over a user-selected number of equal subintervals.

Default lowering is preserved. Representative omitted-default scalar and matrix programs produce byte-identical ELFs under 1.3.52 and 1.3.53, and the 1.3.53 release gate requires omitted forms to be byte-identical to calls spelling the historical defaults explicitly.

Runtime-variable iteration selection remains invalid. The feature is AOT source control rather than a runtime algorithm selector.
