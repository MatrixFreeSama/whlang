# Wheelchair 1.3.47 AVX2 Correctness Record

Release gate: `devtrash/release_tests/test_avx2_physical_ownership_1347.sh`.

Validated properties:

- Native256 exposes one real SIMD bank, YMM0..YMM15, and no synthetic high bank.
- The generic four-ValueFact v3/tail-mask probe matches native512 checksum
  `0x45b13000` and writes a byte-identical output field.
- Constant integer div/mod with both procedural-index carriers matches native512.
- Strict Field reduction matches native512 on multiple extents and gather input.
- Complete 8-node Hex8 strict-f32 local operator remains exact on both widths.
- 2304 logical Hex8 loads still canonicalize to 97 load identities and 27
  coordinate episodes; irregular gather fallback remains present.
- Native256 Tensor sqrt returns the same exact checksum as native512 and its
  generated code contains YMM `vsqrtpd` with no ZMM instruction.
- Existing Physical Reality, unified ownership and execution-granularity tests
  pass after the Tensor/native256 high-bank state is aged out.

The 64^3 Hex8 output fields produced by current native256 and native512 were
byte-identical for all three output components.  Their printed reduction
checksums may differ when vector-width grouping differs; the output field bytes
are the strict per-point oracle.
