# Wheelchair 1.3.47 Pure Assembly Release Proof

The production build remains handwritten x86-64 assembly plus GNU assembler and
linker.  1.3.47 adds no C, C++, LLVM, JIT, Python production generator, runtime
scheduler or external numerical library.

The native256 ownership repair is expressed by compile-time assembly constants,
a Field carrier lookup table, existing Physical-DAG liveness facts, and removal
of impossible Tensor high-bank ownership state.  The emitted programs remain
static ELF images.

`build.sh` and the 1.3.47 release gate reject workload-specific register routes,
synthetic native256 high-bank ownership, and runtime register-management
mechanisms.
