# Native256 Physical Ownership 1.3.47

## Problem

The old materialized-Field lowerer used a contiguous logical mapping:

```text
v0..v3 -> SIMD1..4
```

That remained valid on native512 because predicate state lives in k-registers.
On native256, however, YMM4 is the persistent tail mask.  Therefore logical v3
and the tail mask could own the same physical register.

A minimal strict probe is sufficient to expose the defect:

```text
load -> v0
const -> v1
add(v0,v1) -> v3
store(v3)
reduce(v3)
```

On 1.3.46 native256 the output field was written correctly but the reduction
checksum became `0xffffffff`; native512 produced `0x45b13000`.

## Aged physical profile

1.3.47 defines one native256 architectural fact:

```text
SIMD bank = YMM0..YMM15
high SIMD bank = none
```

The Field roles are:

```text
v0,v1,v2 = YMM1,YMM2,YMM3
v3       = YMM12
tail mask = YMM4
reduction = YMM5
procedural i0/i1 = YMM13/YMM14
phase-local high scratch / gather mask = YMM15
```

These are physical ABI facts, not workload decisions.  Resident selection
removes a role only when the Physical DAG proves that role live.  Helper edges
continue to use the existing resident reload authority.

## Tensor aging

Tensor/native256 historically retained copied high-bank ownership masks and
allocators even though both masks were permanently zero.  1.3.47 removes those
mutable fake-bank states.  The old direct load and RIP-relative constant pool
remain the realization when the real YMM bank has no persistent capacity.

No native256 workload name, stencil width, tensor size or benchmark identity is
consulted.

## Native512 isolation

The native512 Field mapping remains the historical `add-one` mapping in the
common lowerer.  During release audit, compiling the same canonical Field source
with the 1.3.46 and 1.3.47 native512 compiler under the same AOT conditions
produced byte-identical executable output.  No native512 runtime file was
modified.
