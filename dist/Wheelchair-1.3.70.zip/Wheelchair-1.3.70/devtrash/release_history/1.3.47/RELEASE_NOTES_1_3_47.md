# Wheelchair 1.3.47 Release Notes

Wheelchair 1.3.47 ages the native256/AVX2 physical backend without adding a
workload branch, algorithm selector, runtime scheduler, register manager or new
Field opcode.  Native512 physicalization is intentionally unchanged.

The repair closes a physical ownership alias that had accumulated across older
Field upgrades.  Logical Field ValueFact `v3` inherited the historical
contiguous mapping to YMM4 while the native256 runtime also owned YMM4 as the
persistent tail mask.  Small three-carrier programs could miss the conflict;
a four-carrier strict reduction exposed it as a wrong checksum.

Native256 now has one compile-time physical profile for the architectural
YMM0..YMM15 bank.  Field expression carriers, tail mask, hidden reduction,
procedural-index carriers and phase scratch consume disjoint named roles.  The
common Field lowerer maps logical carriers through that profile only for the
256-bit realization; the mature native512 mapping is unchanged.

The same aging pass removes a second historical fiction from Tensor/native256:
the copied high-register cache/constant ownership masks that represented a
ZMM16+ style bank even though AVX2 has only sixteen YMM registers.  Those masks
were already initialized to zero; 1.3.47 makes that zero capacity explicit and
keeps existing direct-load/RIP-pool realization as the natural path.

Release validation includes a workload-neutral four-ValueFact tail/reduction
probe, procedural integer div/mod, Field reduction, the complete Hex8 local
operator, irregular gather/regular-load gates, and a native256 Tensor sqrt
probe.  Generated native256 Tensor code contains YMM operations and no ZMM
instructions.

On the release host, the strict 64^3 Hex8 paper graph measured 41.61 ms median
for 1.3.47 native256 versus 41.64 ms for 1.3.46 native256 in 15 single-CPU
whole-process runs.  This release therefore repairs ownership without a
measurable regression.  It does not claim to close the remaining AVX2 versus
AVX-512 width/register-pressure gap.
