# Wheelchair charter 1.3.64

Wheelchair remains a static AOT HPC-general language whose optimization authority follows program structure and physical reality rather than workload names.

Binding rules for this release:

- Reuse and strengthen common architecture before adding a new mechanism.
- Rank-N, Axis, Operator, Region, Effect, Capability, ValueFact, ShapeFact-N, GroupFact, Physical Reality, and Physical DAG form the common substrate.
- Group -> Vector -> Scalar is a physical degradation relation, not an algorithm selector hierarchy.
- No hardcoded expansion threshold, workload-name dispatch, hidden serial scheduler, or work stealing.
- Completed work releases its resources; it does not become a global redistribution authority.
- Do not chase shallow same-depth parallelism when execution materialization, OS scheduling, synchronization, or join cost dominates the saved work.
- Remove compatibility and shadow authority once the canonical architecture fully covers it.
- User-visible aliases that are real language semantics are not compatibility garbage and remain supported.
