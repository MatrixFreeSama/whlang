# Wheelchair 1.3.59 physical-plan convergence correctness

1.3.59 removes three historical post-scheduler fixed-width assignments. The common resource scheduler already receives pass-0 resource counts and target capability caps. Its result is now copied to `physical_plan_unroll` instead of being overwritten by the literal value two.

Permanent release checks require:

1. base native512, base native256, and derived native256 frontends contain no fixed `schedule_unroll = 2` / `physical_plan_unroll = 2` overwrite after scheduling;
2. each of those frontends copies the scheduler result into the physical plan;
3. derived native512 retains its actual-emitted-shape closure;
4. the lightweight tolerant reduction, mature Newton-Jv, coupled FSI, Rank-3 native, and Rank-3 strict-neighborhood probes compile and execute with their expected numerical contracts;
5. the 1.3.58 FSI selector identity (`whexc == topologyc`) and Rank-3 selector identity (`whexc == topologyc-derived`) remain intact;
6. all inherited 1.3.58 component release gates remain green.

For coupled FSI, changing the legal tolerant reduction shape changes the 1M checksum from `0x40fb0db28f8ed7fa` to `0x40fb0db28f8ed8a6`. The relative numerical difference is approximately `2.26e-14`, far inside the source contract `tolerance 1e-8`. Strict probes remain exact.
