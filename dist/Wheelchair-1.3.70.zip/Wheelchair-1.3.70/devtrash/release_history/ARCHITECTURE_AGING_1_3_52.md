# Architecture aging 1.3.52

The rule of this release is subtractive: a historical version number, dead alias, duplicate source authority, or release-proof ritual may not remain part of the production architecture merely because older releases used it.

Production identity now describes responsibility rather than ancestry. Tensor sources use current semantic names; Physical Reality has one include authority; current binaries have one canonical name per actual implementation. Historical release evidence belongs in `devtrash`, not in the construction path.

No retained lower capability is disguised as generalized. Field ABI limits, General runtime-record limits, Tensor dynamic-extent semantics, mathematical admissibility, code-generation workspaces, and target ISA resources are unchanged. Their future aging must occur at their owning representation rather than through aliases or compatibility wrappers.
