# Wheelchair Charter 1.3.43

## Architecture order

1. Parasite the old architecture first.
2. Strengthen the old architecture second.
3. A new authority is last resort.
4. Any unavoidable new authority must be high-affinity, high-extensibility and assimilatable until it becomes common substrate.

## Precision is data

`f32` and `f64` are native. Every `fpP`, `P > 64`, is one parameterized floating semantic. The compiler encodes P in the type fact and derives the physical span from P. A named wide precision may not own a production implementation.

The existing `precision_propagation` meet is authoritative and executes before physicalization. Physical code may not tunnel a precision decision into a naturally lower-precision child.

## One multiplication authority above FP64

For every `P > 64`, multiplication belongs to one Rank-N Fourier factorization authority. Production code may not contain a parallel legacy multiplication candidate, compatibility fallback, named algorithm selector or fixed precision threshold switch.

The factorization is represented by one geometry fact

```text
g = (b, a2, a3, a5)
N = 2^a2 * 3^a3 * 5^a5
```

and one native numerical admissibility condition:

```text
ceil(P/b) * (2^b - 1)^2 * ceil(log2(N)) < 2^51
```

The physical geometry is chosen by the existing AOT physical-cost authority. The current common surface is:

```text
C = N * (100*a2 + 120*a3 + 180*a5 + 10*a3^2 + 30*a5^2) + 40*n
n = ceil(P/b)
```

These constants describe measured stage/materialization cost. They are not precision thresholds and may be retuned only as one continuous physical surface.

## Native realization

The product is recovered from

```text
z = a + i*b
ab = Im(F^-1(F(z)^2))/2
```

with local mixed-radix DIF forward stages and matching DIT inverse stages. No global frequency permutation is required. Twiddle recurrence is periodically re-anchored by local x87 `FSINCOS`; butterflies use local x86-64 SIMD where profitable.

No external FFT library, planner, allocator, scheduler or executor is a production authority.

## Deliberate performance policy

A smooth common realization may carry local performance impurities. It is prohibited to regrow a small/medium/large precision algorithm zoo merely to remove a local benchmark dip. A new mechanism must strengthen or generalize the common substrate rather than create a new precision region.


## Sparse mathematics fusion

A mathematical feature may not own a duplicate approximation merely because it has a different surface name. When two semantics share a stable algebraic core, that intersection is the authority and each surface semantic is a projection of it.

Runtime control-flow branches are not a mathematical stabilization mechanism. Domain/sign/removable-singularity decisions must first use existing dataflow facts (`min`, `max`, `select`, precision facts, structured facts) and remain sparse. A second runtime solver, math scheduler, algorithm enum or threshold zoo is prohibited.

Release 1.3.41 examples are authoritative design patterns: one Euler/Lambert seed for `exp` and `expm1`; one Lanczos core for Gamma-family semantics; one Abramowitz-Stegun complement kernel for `erf` and `erfc`; one scaled norm for scalar and complex magnitude.


## Sparse root relation

A root result may not be preclassified as real or complex by a parallel solver family. One RootRelation owns Newton work and emits sparse validity plus real/imaginary facts. Real output is a projection of the same relation, not a second solver.

Iteration count is an AOT work parameter. Omission means five generations. Exhausting that finite work without satisfying the representation-scale residual relation means “no accepted candidate,” not a global proof of nonexistence.

Zero derivative, domain growth and result projection must reuse existing Structured Fact, symbolic-differentiation, select and ValueFact authorities. Runtime root schedulers, compatibility fallbacks and real/complex algorithm selectors are prohibited.


## Root precision assimilation

RootRelation may not own a fixed floating width. Precision-neutral identities inherit the existing consumer precision, and every `P > 64` comparison belongs to one normalized fpP comparison authority. Root convergence and real projection must be expressed by facts of the current representation, not by binary64 epsilon, maximum-finite constants, named-width tables or precision selectors.

A physical metadata field must be consumed at its declared width. Adjacent AOT facts may not be widened into one accidental control value. The 1.3.43 Fourier `n64` correction is the canonical example: one exact field-width boundary strengthens the common physical authority instead of creating a precision exception.

## Mathematics generalization 1.3.44

A structured mathematical object's physical workset must be derived from its represented structure, not from a historical small-object tier. Named matrix dimensions may remain as surface aliases only; they may not own algorithms. Base Matrix relations therefore consume one dimension-bearing family. An advanced relation that has not yet generalized its internal workset must reject an unsupported structure safely rather than create a parallel named-size implementation or silently overrun scratch.

Partial pivoting is a relation inside elimination, not a second inverse algorithm. Pivot choice and row permutation should be represented by existing compare/select dataflow facts whenever possible.

For `P > 64`, elementary transcendental mathematics must parasitize the parameterized fpP algebra. A named precision may not own `sqrt`, `exp`, `log`, `sin`, or `cos`. Local contraction depth, series progress and termination should be driven by the current value and current representation. This charter imports no NRII solver; only the architecture-neutral idea of local information propagation is admissible.

A representative ULP regression is not a universal correct-rounding claim. Extreme-domain maturity, especially large-argument trigonometric reduction, must be documented separately until it has its own common authority.
