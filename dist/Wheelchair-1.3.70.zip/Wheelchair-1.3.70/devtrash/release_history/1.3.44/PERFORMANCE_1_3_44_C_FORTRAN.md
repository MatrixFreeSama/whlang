# Wheelchair 1.3.44 C / Fortran matched-kernel benchmark

This release records a diagnostic three-language comparison on three pre-existing scalar recurrence kernels. The equations, initial conditions and update order are matched across Wheelchair, C and Fortran. This is not a claim that these three kernels represent all HPC workloads.

## Environment

- CPU: Intel Xeon Platinum 8573C
- Visible CPUs: 5; one hardware thread per visible core in this container
- Linux: 6.18.44 x86-64
- GCC: 14.2.0
- GFortran: 14.2.0
- Timing pin: `taskset -c 0`
- Work: 20,000,000 steps per timed run
- Repetitions: 9 per language per kernel
- Statistic: median wall time; execution order rotates across repetitions
- Correctness: each kernel's final f64 checksum is bit-identical across all three languages

C was built with:

```text
gcc -O3 -march=native -fno-fast-math -ffp-contract=off
```

Fortran was built with:

```text
gfortran -O3 -march=native -fno-fast-math -ffp-contract=off -fprotect-parens
```

Wheelchair was built by the current release compiler with the corresponding `.wh` source.

## Median wall time

| Kernel | Wheelchair 1.3.44 | C / GCC 14.2 | Fortran / GFortran 14.2 | Wheelchair / C time | Fortran / C time |
|---|---:|---:|---:|---:|---:|
| mass3 | 202.667 ms | 187.367 ms | 182.538 ms | 1.0817x | 0.9742x |
| chem6 | 214.011 ms | 196.286 ms | 181.870 ms | 1.0903x | 0.9266x |
| rigid7 | 291.580 ms | 259.901 ms | 269.556 ms | 1.1219x | 1.0371x |

Geometric mean of per-kernel time ratios versus C:

```text
Wheelchair: 1.097813x C time
C:          1.000000x C time
Fortran:    0.978267x C time
```

Equivalently on these measurements, Wheelchair delivered about 0.911x C throughput, while Fortran delivered about 1.022x C throughput on the geometric-mean ratio.

The result is intentionally retained without a benchmark-specific optimization branch. Release 1.3.44 primarily generalizes native mathematics and precision structure; it does not introduce a separate fast path for these scalar recurrence kernels.

## Reproduction files

All inputs, build commands, timing script and raw results are under:

```text
devtrash/benchmarks/math_generalization_1344/
```

The authoritative tables are `three_kernel_threeway_raw.csv` and `three_kernel_threeway_summary.csv`; `environment.txt` records the machine/compiler environment. Cloud scheduling and frequency variation can change absolute wall times, so the raw data are retained rather than presenting the medians as universal language constants.
