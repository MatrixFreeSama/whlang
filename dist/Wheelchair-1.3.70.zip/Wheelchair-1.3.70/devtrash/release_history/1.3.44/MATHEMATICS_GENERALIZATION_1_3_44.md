# Mathematics Generalization 1.3.44

## Rule

The release follows the same sparse fusion law as 1.3.41:

```text
A ∩ B -> shared authority
```

not:

```text
A + B -> selector + duplicated implementation
```

## Matrix family

A square matrix is one Structured Fact whose tag contains its AOT-static dimension. `matrix2/3/4` are spelling aliases of the same family. The base relations derive component count from `n*n`; no matrix5/matrix6 implementation exists.

The generalized base relations are construction, component access, transpose, trace, Hadamard/componentwise algebra, scalar scale, matrix multiplication, structured select, structured differentiation, and structured materialization.

The inverse relation keeps one Gauss-Jordan body and assimilates partial pivoting as dataflow compare/select facts. This fixes legal matrices with a zero first diagonal pivot without creating `pivoted_inverse`.

Some advanced dense decompositions still use the historical sixteen-component local workset. Their 1.3.44 contract is safe structural rejection beyond that workset. They are explicitly not claimed as arbitrary-n implementations yet.

## Local propagation for fpP mathematics

The wider-than-f64 transcendental layer reuses the one fpP carrier and arithmetic authority.

### sqrt

Classical Newton iteration:

```text
y_{k+1} = (y_k + x/y_k)/2
```

The seed is derived from the local exponent. Work stops when the current P-bit representation stabilizes rather than after a named-width iteration count.

### exp

The argument is contracted only as far as its current binary exponent requires, evaluated by a local Taylor relation, then restored by repeated squaring. The removed fixed extra contraction is deliberate: unnecessary squaring only multiplies rounding noise and physical work.

### log

Repeated square-root contraction moves the value toward one. The local logarithm is evaluated through the atanh identity

```text
log(x) = 2 * (t + t^3/3 + t^5/5 + ...)
t = (x-1)/(x+1)
```

and the removed scale is restored afterward.

### sin and cos

One synchronized local kernel carries both series. The argument is contracted according to its own scale, then the pair is restored using coupled double-angle identities:

```text
sin(2x) = 2 sin(x) cos(x)
cos(2x) = cos(x)^2 - sin(x)^2
```

This is one `sin ∩ cos` authority, not two wide-math implementations.

## What was not imported

NRII itself is absent. No NRII root solver, interval search, branch selector, runtime state, or compatibility path was added. The only assimilated idea is local information propagation: work and local representation are derived from the current mathematical fact instead of a global named precision table.
