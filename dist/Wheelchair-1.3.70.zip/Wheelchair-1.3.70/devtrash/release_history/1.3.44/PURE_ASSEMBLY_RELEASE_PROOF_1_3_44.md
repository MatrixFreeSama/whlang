# Pure Assembly Release Proof 1.3.44

The production compiler and parameterized precision runtime remain handwritten x86-64 assembly sources under `compiler/` and `runtime/`. Release 1.3.44 does not introduce a C/C++/Fortran numerical runtime, BLAS/LAPACK dependency, libm dependency, JIT, NRII runtime, matrix runtime, or external arbitrary-precision mathematics library into production.

C, Fortran, Python, GMP and shell files under `devtrash/` are test/oracle/benchmark material only. They are not linked into production binaries.

The 1.3.44 additions are realized by:

- one dimension-bearing Structured Matrix family in the handwritten surface compiler;
- dynamic compile-time structured scratch derived from component count;
- dataflow partial pivoting expressed with existing AST compare/select facts;
- one fpP transcendental family implemented in `runtime/rankn_precision_physical_x86_64.inc` and reached by the existing general frontend.

`build.sh` and the final release gate scan for prohibited named-width/named-size production authorities and rebuild all production executables from these assembly sources.
