# Wheelchair 1.3.44 Release Notes

Wheelchair 1.3.44 ages two young mathematics regions without adding named-size or named-precision algorithm families.

## Generalized Matrix family

`matrix2`, `matrix3`, and `matrix4` remain source aliases, but the compiler now represents them as one dimension-bearing Matrix Structured Fact. The generic constructor is:

```text
matrix(n, a00, a01, ..., a[n*n-1])
```

`n` is an AOT-static structural fact. Construction, structured materialization, componentwise binary algebra, transpose, trace, scalar scale, multiplication, structured differentiation, and structured select use scratch derived from the actual component count rather than a sixteen-component matrix tier.

`matrix_inverse` now uses dataflow partial pivoting inside the existing Gauss-Jordan relation. It does not expose a second pivoted-inverse algorithm. Advanced decompositions whose old workset has not yet been generalized reject oversized MatrixFacts cleanly instead of indexing past fixed scratch.

## P>64 native transcendental assimilation

The existing parameterized fpP algebra now carries native `sqrt`, `exp`, `log`, `sin`, and `cos` for every supported `P > 64`. There are no fp128/fp256/fp521 variants.

The design absorbs only the local-propagation idea: the current value's scale determines the minimum local contraction; classical Newton/series identities operate in that local neighborhood; representation stability supplies the stopping fact; and the removed scale is restored. No NRII solver, interval engine, runtime scheduler, or NRII module enters production.

Representative fp65/fp127/fp521 release anchors are within four significand ULPs of independent high-precision RNE oracles. This is a release regression contract for the tested points, not a claim of universal correct rounding. Large-argument trigonometric phase reduction is not yet a full Payne-Hanek-class implementation.

## Benchmark

Three pre-existing matched scalar recurrence kernels were measured against GCC C and GFortran on the release machine. All final checksums are bit-identical across languages. Across the three kernels, the geometric mean is:

```text
Wheelchair 1.3.44: 1.097813x C time
C / GCC 14.2:      1.000000x C time
Fortran 14.2:      0.978267x C time
```

The release keeps this result without a benchmark-specific branch. See `PERFORMANCE_1_3_44_C_FORTRAN.md` and the raw CSV files under `devtrash/benchmarks/math_generalization_1344/`.
