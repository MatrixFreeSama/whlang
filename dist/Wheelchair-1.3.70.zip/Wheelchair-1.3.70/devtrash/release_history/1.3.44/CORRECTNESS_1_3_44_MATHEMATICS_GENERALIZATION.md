# Correctness 1.3.44 Mathematics Generalization

The release gate is `devtrash/release_tests/test_math_generalization_1344.sh`.

It verifies:

1. a 5x5 generic `matrix(5, ...)` crosses the historical sixteen-component boundary and correctly executes transpose, Hadamard product, matrix multiplication, component access, and matrix trace;
2. the zero-first-pivot matrix `[[0,1],[1,0]]` is inverted correctly by the one dataflow-pivoted inverse relation;
3. an oversized advanced decomposition with a still-historical fixed local workset rejects cleanly rather than indexing out of bounds;
4. fp65, fp127, and fp521 all use the same native fpP `sqrt/exp/log/sin/cos` authority and preserve their fpP carrier;
5. representative results are checked against independent high-precision RNE significand anchors with a <=4 ULP release bound for the tested values;
6. invalid `sqrt`/`log` domains fail cleanly;
7. no named-width transcendental implementation or named-size matrix implementation is admitted.

Historical mathematical release gates through the 1.3.43 Root Precision Fusion remain part of the final release test.
