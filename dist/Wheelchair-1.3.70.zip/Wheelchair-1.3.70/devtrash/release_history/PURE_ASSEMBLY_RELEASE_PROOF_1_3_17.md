# Wheelchair 1.3.17 Pure Assembly Release Proof

The production compiler and runtime remain direct GNU assembler/linker driven static x86-64. No C backend, LLVM backend, JIT or Python production generator is introduced.

The 1.3.17 execution-resource change is implemented directly in the existing assembly Tensor, Field and General runtimes.

Release prohibitions:

- internal execution-capacity accounting: 0
- credit bitmap: 0
- capacity claim: 0
- capacity release: 0
- runtime causal-work CPU pinning: 0
- pre-created future executors: 0
- sleeping future executors: 0
- executor resource handoff: 0
- work stealing: 0
- global ready queue: 0
- resource recipient selection: 0
- load-balancing family: 0

Release obligations:

- ready causal work directly materializes outward;
- completed execution terminates Wheelchair ownership;
- Tensor/Field split decisions do not query silicon capacity;
- General indegree-one successors need no atomic arrival;
- true General multi-predecessor joins use only the required last-arrival composition;
- inherited 1.3.16 numerical and machine-code authority remains mandatory.

Dormant legacy binary fields are not active resource authority and are never read by current generated runtimes.
