# Wheelchair 1.3.22 Predicate Sparsification Evidence

## Canonical probe

Source occurrences of the exact predicate `x < y`:

1. named bool `p1`;
2. first inline `select` guard;
3. second inline `select` guard;
4. named bool `p2`.

| Metric | 1.3.21 | 1.3.22 |
|---|---:|---:|
| `ucomisd` | 4 | 1 |
| `setb` | 4 | 1 |
| predicate runtime/cache | 0 | 0 |
| repetition threshold | 0 | 0 |

The true-direction input `(1.0, 2.0)` produces `p1=1, a=2.0, b=3.0, p2=1`; the false-direction input `(2.0, 1.0)` produces `p1=0, a=2.0, b=3.0, p2=0`, with exact emitted output bit patterns checked by the release test.

## Structural deletion

The release additionally removes the historical fixed two-state affine iterate lowering and the fixed axis±1 interior boundary-select matcher. Their source symbols are required to be absent.

This release does not claim that every dynamically changing predicate can be hoisted. Predicate persistence ends when its input-version proof ends. Mutable-state predicates continue to be evaluated according to the ordinary causal/versioned path.
