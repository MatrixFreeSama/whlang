# Wheelchair 1.3.57 release notes

1.3.57 introduces `ShapeFact-N`, a sparse logical-shape authority that replaces the old precomputed Rank-N product/rank compatibility markers.  ShapeFact stores axis identity and extent facts only; rank, row-major stride relations, and product cardinality are derived rather than duplicated.

Runtime extent identity is now data.  Human Tensor source no longer depends on the special spelling `n`; arbitrary declared u64 extent names are resolved through ShapeFact and erase before physical code generation.  Structurally identical `n` and `batch` programs produce byte-identical executables.

All four Tensor physicalizers consume the same ShapeFact authority.  Base native512/native256 consume their rank-1/product-1 physical subset; derived native512/native256 consume productized shapes.  The old `rank_n_product`, `rank_n_source_rank`, product patch/offset, and `__rankn_q` compatibility identities are deleted rather than preserved.

ShapeFact itself has no rank or extent-count capacity constant and does not encode the current one-runtime-extent Tensor restriction.  That restriction is localized to the Tensor consumer.  The physical model remains one execution root `q`; no multi-axis executor, nested runtime loop object, scheduler, JIT, fallback backend, or algorithm family is added.

All inherited release gates remain green.  The mature Newton-Jv result remains exact while its generated RX segment is about 31.8% smaller than 1.3.56.  Full compiler self-build median on the release host is about 1.8% slower, so no build-speed improvement is claimed.
