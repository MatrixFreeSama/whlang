# Wheelchair 1.3.14 Pure-Assembly Release Proof

The 1.3.14 production compiler/runtime images are built by `build.sh` from repository assembly/include sources. The release gate rejects Python source in the release tree and rejects production build invocations of GCC, Clang, LLVM `llc`, or LLVM `opt`.

The release gate performs a clean native build and byte-compares every required compiler image with both the top-level packaged image and the corresponding `bin/` image. It also verifies that designated compiler/runtime/AOT artifacts contain no dynamic ELF section.

The 1.3.14 architecture test compiles and executes integer and FP causal-state probes, including unrelated simulation-style programs, then disassembles their admitted hot loops. The gate rejects artificial `push`/`pop`, persistent General state/temp traffic, unconditional steady-state backedge jumps and hot-loop FP constant rematerialization in the validated subset.

The 1.3.13 Fibonacci/Lucas/Tribonacci probes remain only as peak-regression evidence. Compiler/runtime source is searched for those names and for the unrelated simulation probe names; workload-name specialization is forbidden.

The consolidation does not replace semantic uncertainty with unsafe native admission. Trapping integer behavior remains protected by the established General semantic path when the unified Physical Reality proof cannot admit the direct physical form.
