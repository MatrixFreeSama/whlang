# Wheelchair 1.3.12 Pure Assembly Release Proof

Wheelchair 1.3.12 retains the production architecture of the previous release:

- native compiler/runtime implementation remains handwritten assembly plus shell build orchestration;
- no Python source is admitted to the release implementation path;
- no C, LLVM, MLIR, or JIT production backend is invoked;
- General Causal State Collapse is implemented in `compiler/general_frontend_x86_64.S`;
- state-role analysis and register assignment are compile-time only;
- no runtime state-role manager or register scheduler exists;
- Blind Surplus Reflow remains the protected execution fabric.

The dedicated release gate checks static AOT native images and the complete historical 1.3.11 release authority before declaring 1.3.12 PASS.
