# Wheelchair 1.3.64 release notes

1.3.64 is a full convergence and aging release. It does not add a competing execution subsystem. Instead it removes internal compatibility surfaces and pseudo-resources already superseded by GroupFact, Physical Reality, Physical DAG, and the real ISA ownership model.

## Convergence

- Removed internal one-jump vector emitter aliases and canonicalized the internal multiply emitter ABI.
- Removed obsolete constant/induction selector aliases from the canonical Tensor physicalizer.
- Removed the native256 resident-constant pseudo-domain. Constants have one authority: the immutable RIP-relative pool.
- Removed the native256 persistent high-register CSE/cache pseudo-domain. AVX2 lowering now operates directly on the real YMM0..15 ownership set instead of consulting an allocator that could only fail.
- Direct and indexed pure-map lowering on native256 now follows the already-realized primary-register path without dead cache bookkeeping.
- Historical release reports were moved from the release root to `devtrash/release_history/`.
- Generated `build/` content is not shipped.

No workload-specific branch, runtime Group manager, fixed Group threshold, or algorithm selector was introduced.

## Preservation

A 13-case differential compilation suite against 1.3.63 produced byte-identical target ELFs for Newton-Jv, coupled FSI, Rank-3, Rank-6, lightweight reduction, strict operators, ShapeFact-N Rank-3, native256 Newton-Jv, native256 Rank-3, native256 ShapeFact-N Rank-3, iterate, feature showcase, and the English human-surface equivalence program.
