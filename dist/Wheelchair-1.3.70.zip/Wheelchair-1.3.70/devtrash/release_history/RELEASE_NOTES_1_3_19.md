# Wheelchair 1.3.19 — Structural Execution Theory Consolidation

1.3.19 formalizes the execution law exposed by the 1.3.17–1.3.18 resource work: Wheelchair executes causal structure rather than source order. Work at the same causal depth is independently executable; serialization is represented only by increased causal depth.

The release introduces the structural performance model

`S_struct(P) = W / (max(W/P, S) + H)`

with ideal form

`S_struct_ideal(P) = min(P, W/S)`.

`W` is necessary physical work, `S` is weighted causal span, `H` is critical-path realization overhead, and `W/S` is Intrinsic Causal Parallelism.

### New diagnostic authority

`tools/structural_execution_model.sh` evaluates the model without entering the runtime. It has a raw `(W,S,H,P)` mode and Tensor/Field modes that read immutable AOT Physical Reality costs from a generated ELF and combine them with the existing canonical causal tree. No CPU availability, worker count, credit state, runtime causal-depth queue, or serial-fraction scheduler is introduced.

### W/S/H classification

Future optimization evidence must state whether it reduces `W`, `S`, or `H`. This turns performance investigation into a structural diagnosis instead of an invitation to add another scheduler or workload-specific fast path.

### No hot-path rewrite

The production numerical/compiler hot paths remain the 1.3.18 paths. 1.3.19 is deliberately a theory-and-diagnostic consolidation release: the new theory must describe existing execution without creating extra runtime work.

### Evidence

Existing strong/weak-scaling probes are carried forward as structural evidence. Independent heavy FSI work approaches linear strong scaling as useful work dominates realization overhead, while causal state-transition probes remain unchanged because their mathematical span is the limit. Lightweight independent work occupies the realization-limited region until local continuation amortizes lifecycle cost.
