# Wheelchair 1.3.13 Pure-Assembly Release Proof

The 1.3.13 production compiler path is built from the repository's assembly sources by `build.sh`. The release gate rejects Python release sources and rejects production build invocations of GCC, Clang, LLVM `llc`, or LLVM `opt`.

The release test rebuilds the native images and byte-compares each required compiler image against both its repository top-level image and its `bin/` image. It also verifies that the designated AOT/compiler/runtime artifacts have no dynamic ELF section.

The register-native transition implementation resides in `compiler/general_frontend_x86_64.S`. Its proof and emission occur before runtime. No generated-C compatibility layer, JIT compiler, runtime transition graph walker, or runtime register allocator is inserted into this execution path.

The machine-code audit is behavioral rather than documentary: programs are compiled by the freshly built compiler, executed for checksum equality, disassembled, and rejected if an admitted hot transition contains artificial expression `push`/`pop` or persistent state/temp-array traffic.

A trapping-integer probe intentionally remains on the historical compatible expression path. This proves that native admission is conditional on semantic proof rather than obtained by weakening overflow behavior.
