# Wheelchair 1.3.20 — Unified ValueFact Pressure Remap

Wheelchair 1.3.20 strengthens the existing Physical Reality / Physical DAG architecture. It does not add a chemistry backend, a recurrence backend, a runtime allocator, or any workload-name dispatch.

## Removed old private branches

The historical whole-transition selectors for the two-state `xadd` recurrence and the three-state shift/add recurrence were deleted. Rank-2, Rank-3 and Rank-N causal state now enter the same register-DAG lowering. ISA compression may still emerge from the generic emitted-machine-sequence canonicalizer; it is no longer selected by state count or recurrence shape.

## Shared-pressure remap

The persistent next-version XMM bank is no longer treated as mandatory. It remains the first physical realization candidate. During AOT profiling, existing whole-episode CSE competes for the same XMM authority. If profitable reusable ValueFacts are blocked specifically because the shared carrier pool is exhausted, the compiler re-materializes the same Physical DAG with transient next-version ValueFacts using the already-existing `state_temp` version handoff. There is no second backend and no runtime decision.

This fixes the six-state reaction-network probe without naming or recognizing chemistry. Its hot loop drops from 25 to 15 scalar multiplies while unrelated `mass3`, `rigid7`, and `rigid7_cseprobe` retain their 1.3.19 arithmetic counts.

## Architectural rule

A discovered workload may expose missing physical competition, but it may not earn a private route. Strengthen the existing Physical Reality, then delete the probe-specific explanation from the implementation.
