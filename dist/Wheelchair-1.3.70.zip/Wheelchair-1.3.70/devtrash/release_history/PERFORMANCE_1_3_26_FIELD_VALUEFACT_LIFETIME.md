# Wheelchair 1.3.26 — Field ValueFact Phase-Lifetime Measurement

Validation host: AMD EPYC 9V74, 5 visible CPUs, Linux/KVM. Measurements used CPU affinity 0-4 and 256^3 materialized f32 fields. Each implementation was warmed and interleaved; values below are medians of 16 measured runs per implementation.

These kernels come from established simulation miniapps and are stored as non-production artifacts under `devtrash/benchmarks/real_sparse_1326/`.

| kernel | C | Fortran | Wheelchair 1.3.25 | Wheelchair 1.3.26 | 1.3.26 vs 1.3.25 |
|---|---:|---:|---:|---:|---:|
| miniAMR 7-point | 12.481 ms | 12.773 ms | 15.209 ms | 12.113 ms | 1.256x |
| miniAMR 27-point | 17.750 ms | 31.001 ms | 31.560 ms | 24.636 ms | 1.281x |
| miniFE Hex8 heat interior, 21 numeric neighbors | 17.358 ms | 50.167 ms | 26.993 ms | 25.817 ms | 1.046x |
| CloverLeaf x-acceleration kernel | 15.635 ms | 31.704 ms | 28.317 ms | 24.371 ms | 1.162x |

On this host 1.3.26 slightly exceeds the measured C implementation on miniAMR 7-point (about 3.0%) and exceeds the measured Fortran implementation on all four kernels. C remains substantially faster on the wider miniAMR 27-point, miniFE21, and CloverLeaf cases, so the release does not claim universal sparse superiority.

The important release claim is narrower: deleting default stack transport and releasing helper-owned carriers back into the existing Physical Reality materially improves several unrelated real simulation kernels without adding kernel-specific branches.
