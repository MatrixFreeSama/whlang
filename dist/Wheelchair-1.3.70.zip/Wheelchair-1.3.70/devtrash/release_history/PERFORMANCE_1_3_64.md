# Wheelchair 1.3.64 performance note

1.3.64 is intentionally not advertised as a new user-program speedup release. The protected benchmark corpus produces byte-identical target ELFs versus 1.3.63, so mature runtime performance is preserved by construction.

The improvement is compiler-side convergence: native256 no longer executes searches, transaction snapshots, generation accounting, and failed allocation attempts for a persistent high-register CSE/cache domain that the AVX2 physicalizer cannot own. This reduces compiler source and binary machinery without inventing a second optimization path.

Automatic Grouping remains ready to produce runtime speedups only when GroupFact causes canonical physicalization to choose a cheaper Physical DAG than the pre-Grouping architecture. 1.3.64 does not fake such a gain by changing protected benchmark code.
