# Wheelchair 1.3.19 Pure-Assembly Release Proof

1.3.19 does not introduce a C, LLVM, Python, JIT, bytecode, runtime scheduler, runtime causal-level queue, worker pool, or resource manager.

Production compiler/runtime authorities remain handwritten x86-64 assembly plus the existing shell build/test tooling. The new structural execution diagnostic is an offline shell utility that reads immutable fields already emitted into direct-native ELFs; it cannot alter execution and is not linked into generated binaries.

The complete 1.3.18 release authority is rerun before 1.3.19 can pass. Root, `bin/`, and clean `build/` native compiler images must remain byte-identical. The 1.3.19 gate additionally proves:

- `PROGRAM_ORDER_IS_NOT_CAUSAL_AUTHORITY=PASS`
- `EQUAL_CAUSAL_DEPTH_PARALLELISM=PASS`
- `STRUCTURAL_EXECUTION_W_S_H_MODEL=PASS`
- `INTRINSIC_CAUSAL_PARALLELISM_W_OVER_S=PASS`
- `RUNTIME_CAUSAL_DEPTH_QUEUE=0`
- `RUNTIME_SERIAL_FRACTION_MANAGER=0`
- `STRUCTURAL_EXECUTION_HOT_RUNTIME_DELTA=0`

The model is deliberately falsifiable: increasing causal span or realization overhead must never improve predicted speedup, a fully causal chain (`S=W,H=0`) must predict 1x, and an independent zero-overhead structure must approach `min(P,W/S)`.
