# Wheelchair 1.3.56 pure-assembly release proof

Production Wheelchair remains a static, no-INTERP, handwritten x86-64 assembly AOT toolchain. 1.3.56 changes storage ownership inside those assembly compilers/runtimes only.

The production build invokes no Python generator. Python is used by release tests solely to construct independent stress fixtures. All eight shipped production executables are rebuilt by `build.sh`, contain no ELF interpreter, and the final release gate re-runs inherited numerical/structural authorities plus the new 1.3.56 aging gate.

The release adds no C/LLVM/JIT backend, runtime solver selector, compatibility compiler, or benchmark-name dispatch.
