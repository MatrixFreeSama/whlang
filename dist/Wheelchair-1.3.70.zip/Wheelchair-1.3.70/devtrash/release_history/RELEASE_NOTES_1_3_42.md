# Wheelchair 1.3.42 Release Notes

1.3.42 matures the existing native `root` semantic into one sparse RootRelation. The release removes the assumption that a root result is scalar and does not add parallel real/complex solvers.

## Root relation

- `root(x, expr, guess)` keeps the historical default of five AOT Newton generations.
- `root(x, expr, guess, iterations)` accepts an AOT-static nonnegative iteration count.
- The result is discovered during computation as one sparse RootFact with validity, real and imaginary carriers.
- `root_valid`, `real`, and `imag` are projections of that common result.
- Real and complex roots use the same Newton relation and the existing Structured Fact arithmetic.
- Structured symbolic differentiation is componentwise over the existing scalar differentiation authority.
- Zero derivative is protected by select facts, so unsuccessful work becomes empty instead of producing a divide-by-zero runtime failure.
- Each Newton generation checkpoints into the existing scalar ValueFact boundary to stop algebraic tree regrowth.
- Acceptance is a backward-error relation tied to native f64 representation scale. No user tolerance mode or root runtime is added.

## Existing complex mathematics strengthened

Complex exponential, sine and cosine now checkpoint their scalar semantic components once before rebuilding a complex fact. This is a shared sparsity improvement, not root-specific implementations, and lets RootRelation reuse existing transcendental semantics at the default budget without dense repeated trees.

## Semantics of empty

A false `root_valid` means the finite AOT work did not produce an acceptable candidate. It is deliberately not presented as a proof that no mathematical root exists.
