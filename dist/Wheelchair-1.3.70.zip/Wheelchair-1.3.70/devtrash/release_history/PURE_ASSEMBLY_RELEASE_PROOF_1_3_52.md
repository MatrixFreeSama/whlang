# Pure assembly release proof 1.3.52

The production compiler/runtime remains handwritten x86-64 assembly plus shell construction/link control. 1.3.52 introduces no Python, JIT, LLVM/GCC code-generation backend, runtime scheduler, compatibility compiler, or alternate algorithm authority into production.

The active production dependency closure is rooted in `build.sh`, `compiler/`, `runtime/`, `surface/`, and the current tool scripts. Historical tests and records remain under `devtrash` and are not production dependencies.
