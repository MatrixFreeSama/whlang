# Wheelchair 1.3.11 Release Notes

Wheelchair 1.3.11 is **Field Contiguous Physical Collapse & Complex Surface**.

A new 3D five-input, three-output complex Field probe exposed two general sources of avoidable active-silicon work and one human-surface limitation.

## Rank-N regular-episode proof compression

On non-power-of-two extents, the previous generic regular-episode proof could repeatedly divide both ends of a SIMD episode by cycle and logical stride for every affected axis. In a rank-3 interior episode this could approach roughly twelve scalar integer divisions per episode merely to rediscover that the lanes remained inside the same innermost row.

1.3.11 instead proves the innermost row once, verifies no row crossing, and then decodes each outer coordinate once. A typical rank-3 non-power-of-two proof is therefore reduced to roughly four divisions per episode. The power-of-two shift/mask path remains intact and true boundary/irregular fallback remains available.

## Reuse-weighted AVX-512 neighbor residency

Ordinary AVX-512 Field physicalization now allows a bounded high-register bank for immutable neighbor facts selected by existing compile-time use counts. ZMM6..ZMM12 are available to the seven most profitable reusable facts. Integer/stateful paths retain their existing safety restrictions.

This is not "keep everything in registers". Facts with insufficient reuse are allowed to die or remain stack/memory-backed when that is cheaper.

## Four-register complex WH/WHEX Field surface

The human Field expression lowerer and canonical Field Physical-DAG now support four floating logical registers, v0..v3. The previous three-register surface could reject a complex expression even though the canonical Field backend was capable of executing the operator. The fourth carrier closes that proven surface gap without adding a runtime interpreter or alternate backend.

The retained 32^3 complex regression compiles and runs both canonical Field IR and human WHEX at capacity ceilings 1 and 4. The human and canonical forms use different legal tolerant expression trees, so their reductions are not required to be bit-identical to each other, but each is capacity-independent and stable under its own AOT realization.

## A rejected optimization is part of the release evidence

A broad generic tolerant FMA contraction was tested and rejected. It increased accumulator dependency pressure and slowed multi-capacity execution. 1.3.11 deliberately does not include it. Active-Silicon Purity is a physical-cost rule, not an instruction-count or FMA-count contest.

## Same-host retained-mechanism audit

On the 224^3 complex materialized Field probe, using the final 1.3.10 binaries and the final 1.3.11 candidate on the same Intel Xeon Platinum 8573C host, tmpfs data, fixed CPU affinity, two warmups and nine interleaved measured rounds:

| capacity ceiling | 1.3.10 wall median | 1.3.11 wall median | throughput ratio | 1.3.10 CPU-time | 1.3.11 CPU-time |
|---:|---:|---:|---:|---:|---:|
| 1 | 180.614 ms | 164.780 ms | 1.096x | 179.913 ms | 164.067 ms |
| 2 | 149.694 ms | 143.305 ms | 1.045x | 209.940 ms | 203.347 ms |
| 4 | 105.734 ms | 83.971 ms | 1.259x | 269.465 ms | 223.353 ms |

The three-cell geometric-mean throughput ratio is about **1.130x**. The q4 wall time falls about **20.6%** while total CPU-time falls about **17.1%**. All six binaries report the same retained canonical checksum `checksum_f32_bits=0x443cec18` for the canonical probe.

These numbers are host- and workload-specific. They are evidence for the retained mechanisms, not a universal language ranking.
