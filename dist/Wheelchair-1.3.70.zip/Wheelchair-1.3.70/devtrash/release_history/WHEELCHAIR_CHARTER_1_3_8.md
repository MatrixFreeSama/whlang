# Wheelchair 1.3.8 Charter — Strict Parallel Reduction Identity Repair

1.3.8 is a narrow correctness release. It does not add a new workload optimizer and does not reopen the 1.3.7 Tensor Physical Reality design.

## Rule

For `strict` floating-point reduction, changing the requested executor count must not change the arithmetic reduction tree. Parallel execution may expose independent true subtrees of that tree, but it may not replace them with a different balanced partition merely because more executors are available.

In technical form:

```text
strict semantic leaves
    -> one canonical q=1 pairwise chunk tree
    -> true independent subtrees may execute concurrently
    -> each parent performs the same left + right FP addition as q=1
    -> bit-identical final result across executor counts
```

The fix must never be implemented by silently forcing `--executors N` to one executor. It must not introduce a root O(P) reduction sweep, global partial array, global ready queue, work stealing, recipient selection, runtime autotuning, or a central scheduler.

Tolerant FP retains the 1.3.7 balanced executor partition and its explicit numerical contract. Strict and tolerant reduction authority are intentionally different.
