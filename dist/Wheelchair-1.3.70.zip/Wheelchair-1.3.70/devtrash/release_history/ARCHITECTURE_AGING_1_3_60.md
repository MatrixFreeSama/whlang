# Wheelchair 1.3.60 architecture aging

1.3.60 closes two generic human-surface / sovereign-consumer mismatches exposed by the proof standard library. It does not add a proof runtime, stdpf-specific compiler route, helper-count selector, theorem kernel, scheduler, ISA backend, or compatibility fallback.

## Pure-function composition

The common call parser materializes an AST node with three possible child slots. Unary calls consume only `A`; historically the scratch register later written into unused `B` was not initialized. The dormant value was harmless until a pure function body containing a unary call was cloned by another pure function. Recursive cloning then treated that stale scalar as an AST pointer.

The fix is at the common call-construction boundary: all three operand carriers are initialized before parsing. Unused children are therefore structurally empty for every unary callable, independent of library, function name, proof domain, or composition depth.

No stdpf special case exists. A 512-function composition stress and the complete 148-helper stdpf-1909261354 import use the same authority.

## Decimal scientific notation

The human number scanner already described decimal exponent syntax and the JSON parser already accepted it, but digit-leading disambiguation classified `1e-13` as an identifier candidate while only `1.0e-13` reached numeric lowering. The native executable f64 parser also rejected exponent characters.

1.3.60 makes exponent recognition structural: `e/E` becomes numeric only when followed by an optional sign and at least one decimal digit. Digit-leading identifiers otherwise retain their old path. All four Tensor/General consumers now include one shared `compiler/numeric_literal_parser.inc`; the duplicated executable f64 parsers are removed. Exponent scaling extends the existing decimal fact by exponentiation-by-squaring and creates no second literal family.

## Structural self-check

The source-derived Surface fact arena retains its existing 432-byte per-source-fact layout. A layout-end equality check now verifies at compiler startup that the columns actually laid out consume exactly the mapped structural arena, making future drift fail explicitly instead of depending on manual accounting.
