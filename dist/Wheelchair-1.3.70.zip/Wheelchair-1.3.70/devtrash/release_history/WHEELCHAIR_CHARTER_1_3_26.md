# Wheelchair Charter 1.3.26

## Field carrier lifetime rule

A physical carrier is owned only for the causal lifetime of the fact that requires it.

```text
helper work complete -> helper carrier ownership ends immediately
```

A register may not remain reserved merely because an earlier phase used it.

## Residency authority

Immutable Field LoadFacts compete for currently free physical carriers through the existing Physical Reality. One real consumer is sufficient demand when a carrier would otherwise be idle. Reuse count, stencil width, field count, source spelling, benchmark identity, and solver identity are not admission authorities.

## Reload authority

A resident fact receives a stack backup only when a later physical operation can clobber the resident before its final consumer. Backup storage is therefore a lifetime consequence, not a default cache ritual.

## Red lines

```text
WORKLOAD_SPECIFIC_NEIGHBOR_ROUTE=0
STENCIL_WIDTH_DISPATCH=0
LOADFACT_REUSE_THRESHOLD_ROUTE=0
GLOBAL_INTEGER_RESIDENCY_KILL_SWITCH=0
RUNTIME_RESIDENCY_MANAGER=0
HELPER_COMPLETION_RELEASES_CARRIERS=1
PHYSICAL_CARRIER_TABLE_IS_CAPACITY_AUTHORITY=1
```
