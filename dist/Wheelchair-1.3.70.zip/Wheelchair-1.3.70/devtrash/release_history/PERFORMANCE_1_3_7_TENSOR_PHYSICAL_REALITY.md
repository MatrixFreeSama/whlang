# Wheelchair 1.3.7 Tensor Physical Reality — Performance Evidence

This file records the final same-host rematch from the frozen 1.3.7 release tree. These numbers are workload- and host-specific evidence, not a universal language ranking.

## Probe and protocol

Historical two-field fluid-solid coupling Tensor workload, unchanged from the earlier revenge test:

- Intel Xeon Platinum 8573C host, 5 visible vCPUs, sustained 4-CPU cgroup quota;
- `N = 10,000,000` and `100,000,000`;
- executor counts `q = 1, 2, 4`;
- tolerant `f64` contract;
- identical source and CPU affinity per row;
- 3 interleaved warm-up runs per contender;
- 11 interleaved measured process-wall runs per contender;
- medians reported;
- Expert C and Expert Fortran use the unchanged matched historical controls.

Correctness was also checked on `N = 4, 31, 32, 33, 4096, 65535, 65536, 65537, 100000` at `q = 1, 2, 4`.

Maximum relative error versus Expert C:

```text
Wheelchair 1.3.7: 6.0738672624316495e-15
Expert Fortran:   3.7572168721023880e-16
required bound:   1e-8
```

## Final same-host medians

| N | q | Wheelchair 1.3.7 | Expert C | Expert Fortran | WC/C |
|---:|---:|---:|---:|---:|---:|
| 10,000,000 | 1 | 18.562580 ms | 15.982408 ms | 16.438099 ms | 1.161438x |
| 10,000,000 | 2 | 17.419874 ms | 15.279888 ms | 16.219935 ms | 1.140052x |
| 10,000,000 | 4 | 9.680088 ms | 8.957137 ms | 9.699174 ms | 1.080712x |
| 100,000,000 | 1 | 166.156050 ms | 133.844059 ms | 134.165666 ms | 1.241415x |
| 100,000,000 | 2 | 165.159177 ms | 136.428004 ms | 133.416763 ms | 1.210596x |
| 100,000,000 | 4 | 84.035699 ms | 67.916047 ms | 67.559549 ms | 1.237347x |

Six-case geometric means:

```text
Wheelchair 1.3.7 / Expert C       = 1.177172x time
Wheelchair 1.3.7 / Expert Fortran = 1.149596x time
```

Therefore the historical FSI revenge workload still favors the matched expert native controls overall. 1.3.7 does not claim otherwise.

## 1.3.6 -> 1.3.7 improvement on the same probe

The previous same-host 1.3.6 medians were:

| N | q | Wheelchair 1.3.6 | Wheelchair 1.3.7 | 1.3.6 / 1.3.7 |
|---:|---:|---:|---:|---:|
| 10,000,000 | 1 | 23.492073 ms | 18.562580 ms | 1.265561x |
| 10,000,000 | 2 | 23.848989 ms | 17.419874 ms | 1.369068x |
| 10,000,000 | 4 | 13.476095 ms | 9.680088 ms | 1.392146x |
| 100,000,000 | 1 | 220.330370 ms | 166.156050 ms | 1.326045x |
| 100,000,000 | 2 | 233.774595 ms | 165.159177 ms | 1.415450x |
| 100,000,000 | 4 | 115.503216 ms | 84.035699 ms | 1.374454x |

Across the six points, the geometric-mean 1.3.6/1.3.7 ratio is:

```text
1.356215x
```

That corresponds to about **35.62% more throughput** or about **26.27% lower geometric-mean elapsed time** for Wheelchair 1.3.7 on this probe.

## Structural machine-code result

For the unchanged native512-wide FSI source, compared with frozen 1.3.6:

```text
vpmullq sites:     42 -> 17
vmovdqa64 sites:   86 -> 36
vpbroadcastq sites:81 -> 53
```

The first proven-interior vector body also contracts from roughly 117 instructions to roughly 90 instructions.

These changes correspond to generic Tensor Physical Reality work:

- reachable-use/lifetime admission;
- cross-subtree PhysicalFact reuse;
- affine fact profiling and induction;
- generic `2^k`, `2^k-1`, `2^k+1` strength reduction;
- weighted exact-bit constant selection;
- AVX-512 three-operand copy elimination;
- last-consumer square formation;
- tolerant exact doubling.

No fluid/solid/FSI workload-name dispatch exists in the compiler path.

## Boundary

The release result is deliberately narrower than a language-wide victory claim. 1.3.7 materially removes generic Tensor machine work and closes a large fraction of the historical FSI gap, but matched Expert C and Expert Fortran remain faster on the six-case aggregate on this host.
