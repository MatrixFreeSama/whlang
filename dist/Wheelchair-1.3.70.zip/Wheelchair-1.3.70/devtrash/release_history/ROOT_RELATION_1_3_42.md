# Sparse Root Relation 1.3.42

## Principle

`root` is a mathematical relation, not a pretyped scalar-returning routine and not a family of real/complex solvers.

```text
root(x, expression, guess)
root(x, expression, guess, static_iterations)
```

The fourth argument is an AOT-static nonnegative integer. When omitted it is exactly 5. It controls generated Newton work only; it is not a proof-of-existence threshold.

## One relation

The compiler differentiates the lexical expression once with the existing symbolic differentiation authority. A scalar seed is lifted into the already-existing complex Structured Fact representation with a scale-derived non-real direction. Every Newton generation is then only

```text
f  = substitute(expression, x, z)
df = substitute(derivative, x, z)
z' = z - f / df
```

Arithmetic reconstruction goes through the existing scalar/structured constructors. There is no `real_root`, `complex_root`, fallback solver, runtime solver object, or algorithm selector.

Structured differentiation is componentwise: the old scalar `s_ast_diff` authority is reused for every component and the original structured tag is rebuilt. Existing complex arithmetic therefore supplies the complex Newton algebra without a second Newton implementation.

## Sparse singular protection

A zero derivative is represented as a dataflow validity fact. The denominator selects a harmless unit fact when invalid, and the next candidate selects the old candidate back. This prevents divide-by-zero execution failure without introducing runtime solver control flow.

Each Newton generation is immediately materialized through the old Structured-Fact-to-scalar-ValueFact boundary. This prevents AST regrowth and makes later generations consume compact existing facts.

## Result

The result is one `STF_ROOT` compile-time structured fact:

```text
[ valid, real, imag ]
```

`root_valid(r)`, `real(r)`, and `imag(r)` are projections. The caller does not declare the result domain in advance.

Acceptance uses a native-representation backward-error relation:

```text
|f(z)| <= eps * (1 + |z|) * |f'(z)|
```

with f64 machine epsilon. This is representation evidence, not a user tolerance mode. A converged imaginary component within native resolution collapses to exact zero, so a real root is a sparse projection of the same RootFact rather than a separate result type.

If no acceptable candidate is produced inside the requested AOT budget, `valid` is false and the real/imag carriers project to zero. This means “no accepted result from this finite computation,” not “a global mathematical proof that no root exists.”

## Existing mathematics is parasitized

RootRelation reuses the existing complex arithmetic and semantic identities. `complex_exp`, `complex_sin`, and `complex_cos` now checkpoint their old scalar semantic components once before rebuilding the complex fact, avoiding dense repeated serialization when they are consumed inside root work.
