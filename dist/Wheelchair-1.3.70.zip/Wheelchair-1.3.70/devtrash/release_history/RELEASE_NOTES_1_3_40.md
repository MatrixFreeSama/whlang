# Wheelchair 1.3.40 Release Notes

1.3.40 keeps the `fpP` language semantics and the old precision/RNE authorities, while replacing the production `P > 64` multiplication realization underneath them.

## Deleted, not deprecated

The following former production multiplication mechanisms are removed from the active runtime source and binaries:

- bounded row-carry singleton multiplication;
- AVX-512 IFMA batch multiplication;
- the span/singleton multiplication selector and its ISA branch;
- the former scalar-only `runtime/rankn_precision_x86_64.inc` source;
- any compatibility entry point for those multiplication paths.

The release gate scans source and production binaries for their former symbols/instructions. Historical reports remain only under `devtrash/release_history/`.

## Assimilated into the old Rank-N authority

- one native mixed-radix Fourier multiplication realization for every `fpP`, `P > 64`;
- AOT geometry closure stored in the existing physical-object header;
- one native-SIMD numerical safety budget;
- one continuous geometry cost surface;
- packed complex input `z=a+i*b`, one forward transform, one pointwise square and one inverse transform;
- DIF/DIT pairing that removes the need for a global FFT permutation;
- local x87 phase re-anchoring plus local SIMD butterflies;
- the existing normalization and round-to-nearest-even authority unchanged after the exact integer product is recovered.

Division remains the common base-2^32 Knuth digit path.

## Correctness aging

The release oracle checks full-width random significands and all-ones worst-case significands against independent GMP integer arithmetic and exact P-bit RNE from 65 bits through 4194304 bits. Object canaries guard every tested carrier. The inherited arbitrary-P language gate still checks unrelated precisions, decimal ingress and precision-propagation meet edges.

## Performance

The release benchmark compares the complete local `rankn_fp_mul` path against GMP `mpf_mul`, pinned to one CPU and using alternating measurement order with median-of-five runs. In the final run, Wheelchair/GMP time ratios were approximately 1.066 at 262144 bits, 0.839 at 524288, 1.094 at 1048576, 0.985 at 2097152 and 0.947 at 4194304.

The same unified Fourier authority is intentionally retained below that range even where fixed transform cost makes it slower. 1.3.40 does not add a small-precision multiplication branch to improve benchmark cosmetics.
