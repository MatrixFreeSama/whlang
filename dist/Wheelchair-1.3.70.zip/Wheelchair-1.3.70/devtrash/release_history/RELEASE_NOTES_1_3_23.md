# Wheelchair 1.3.23 Release Notes

## What changed

- Restored the old affine recurrence `O(log N)` peak **without restoring the deleted two-state private lowering**.
- Added transition-power proof inside `g_try_emit_reg_iterate`, after generic counted-axis recognition.
- Added a wrap-u64 affine collector that derives `A,B` algebraically instead of matching one fixed AST spelling.
- Added published-result backward slicing: irrelevant sibling states do not force physical execution.
- Preserved ordinary causal execution for nonlinear/non-closed recurrences.
- Removed the unused `g_affine_init_expr` fossil.
- Removed stale `vec_select_interior_false` / `expr_is_axis_delta1` private matcher code from frozen-native source snapshots and regenerated their manifest.

## Generalization boundary

1.3.23's first composition-closed family is a scalar wrap-u64 affine self-map on the published-result slice. The architecture is no longer tied to two semantic states, but this release does not claim arbitrary coupled vector-affine matrix powering. Such a family must enter later through the same closure proof authority, not through a new solver/state-count branch.

## Evidence

- Historical LCG: exact output restored with binary exponentiation machine structure.
- Nine-state test: the same transition-power path is admitted despite eight data states plus the induction state; irrelevant coupled siblings are erased by backward slicing.
- Non-affine recurrence: remains on ordinary `cmp rbx,rbp` causal iteration.
