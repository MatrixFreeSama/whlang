# Wheelchair 1.3.9: Active-Silicon Purity Charter Reset

Wheelchair 1.3.9 is a doctrine-only release.

No compiler, runtime, backend, executable, benchmark, test implementation, ISA path, reduction implementation, or generated binary has been modified from 1.3.8.

## Why this release exists

Earlier project language sometimes treated high CPU occupancy, wide worker utilization, or balanced executor loading as if those values were themselves optimization goals. That interpretation is rejected.

The project objective is now stated without ambiguity:

```text
not: CPU utilization -> 100%

but: Useful Active Silicon Fraction -> 100%
```

Idle or released silicon is not a failure when no necessary independent work exists. Active silicon performing avoidable coordination, polling, redistribution, duplicate realization, synchronization, or occupancy-maintenance work is the failure.

## Load balancing is removed from the doctrine

Wheelchair no longer recognizes load balancing as an optimization authority.

Runtime peer-load observation, worker equality, idle-worker discovery, busy-worker discovery, work redistribution, work migration for occupancy, push/pull balancing, work stealing, destination-aware handoff, and central balancing machinery are prohibited.

Compile-time decomposition remains legal only when it follows true dependency structure, semantic independence, locality, numerical contract, and physical profitability. Equal worker loads are not an objective.

## Recipient-blind release clarified

A completed domain releases its own physical authority immediately and stops participating in resource allocation decisions.

Release does not imply redistribution. The releasing domain does not know and must not care where the freed capacity is used next.

## Strict reduction interpretation

The 1.3.8 strict exact-reduction implementation is unchanged. 1.3.9 clarifies that natural idle capacity caused by the canonical strict reduction tree is acceptable. The implementation must not be judged by whether every executor is equally busy.

Future changes must not add balancing machinery merely to improve q4 occupancy.

## No false implementation claim

Because 1.3.9 intentionally changes no code, inherited 1.3.8 mechanisms are not magically reclassified as already compliant with every strengthened statement in the new charter.

Any inherited behavior whose actual purpose is load equality rather than causal decomposition is now legacy non-authoritative machinery and a future deletion target.

## Release identity

`IMPLEMENTATION_IDENTITY_1_3_9.txt` proves that the protected 1.3.8 implementation payload carried by 1.3.9 is byte-identical. Only documentation and release metadata differ.
