# Wheelchair 1.3.64 architecture aging

The purpose of this release is to make recently added architecture indistinguishable from the old common substrate.

The authority chain remains:

`ShapeFact-N / ValueFact -> GroupFact -> Physical Reality -> Physical DAG -> ISA realization`

Group is not a parallel runtime object. It is a structural fact used by the same physical planner that already owns locality, register pressure, memory traffic, causal depth, and execution materialization. Vector and scalar forms are physical degradations of the same fact, not separate optimization families.

1.3.64 removes the remaining internal compatibility aliases that merely renamed canonical emitters. On native256 it also removes two impossible pseudo-domains: resident high-register constants and persistent high-register CSE/cache. The physicalizer now states the hardware truth directly: the usable primary YMM ownership set is the resource domain, while immutable constants live in the shared RIP-relative pool.

No compatibility vectorizer, duplicated scheduler, runtime work manager, work stealing, hardcoded Group width threshold, or workload-name selector is present.
