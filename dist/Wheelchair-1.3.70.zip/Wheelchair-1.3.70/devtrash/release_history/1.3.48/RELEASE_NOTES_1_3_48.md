# Wheelchair 1.3.48 Release Notes

Wheelchair 1.3.48 continues the native256 aging begun in 1.3.47. The release is
an old-architecture convergence pass: it removes transport that the existing
Physical DAG already proves unnecessary. It adds no AVX2 workload path, runtime
scheduler, register manager, arithmetic selector or new Field opcode.

The Field resident allocator now treats immutable LoadFacts and ConstantFacts as
one physical-carrier economy. Consumer-local liveness is one shared compile-time
proof used by both planning and emission. If an immutable producer is consumed
immediately as strict `mul` operand B and no later observer sees that version,
the standalone carrier load disappears and the existing `VMULPS` consumes the
resident or stack authority directly. Arithmetic order and operation count do
not change.

Contiguous output stores similarly consume the episode mask/q Physical Fact that
is already live. The general non-contiguous and non-temporal helper authority is
retained rather than cloned.

A rejected experiment attempted to cache repeated Pure ArithmeticFacts in a new
stack cache. It reduced multiplication count but increased transport and slowed
the benchmark. That experiment is not present in 1.3.48. Exact arithmetic reuse
will only return when it can live inside the common ValueFact lifetime authority
without creating a parallel cache system.

On the release host, 61 alternating single-CPU whole-process runs of the strict
64^3 Hex8 graph measured 41.641721 ms median for released 1.3.47 native256 and
40.153676 ms for 1.3.48, or 1.037059x. Static generated-code inspection changed
from 3207 explicit vector stack loads to 1555 and introduced 1153 direct
`VMULPS` stack memory operands. The graph still contains 2304 `vmulps` and 1156
`vaddps`; all three output fields are byte-identical.

Native512 physicalization is unchanged. Release audit produced byte-identical
native512 Hex8 ELF files from 1.3.47 and 1.3.48.
