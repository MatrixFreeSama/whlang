# Wheelchair 1.3.48 ValueFact Lifetime Correctness

1.3.48 changes transport only. Strict arithmetic order and operation count stay
unchanged.

Release validation requires:

- the 1.3.47 native256 physical-ownership gate to keep passing;
- the full strict Hex8 Field authority and locality/regularity gates to pass;
- native256 and native512 Hex8 output fields to agree byte-for-byte on the
  packaged 3x5x7 oracle inputs;
- the 1.3.48 native512 Hex8 ELF to remain byte-identical to the 1.3.47 native512
  ELF in release audit;
- native256 generated code to contain no ZMM instructions;
- strict Hex8 arithmetic counts to remain 2304 `vmulps` and 1156 `vaddps`;
- consumer-local memory operands to be present without an ArithmeticFact stack
  cache or workload-specific route.

The release-host 64^3 validation also compared all three native256 output files
between the released 1.3.47 binary and 1.3.48 byte-for-byte. Both reported the
same native256 reduction checksum `0xbcd65a00` on that dataset.
