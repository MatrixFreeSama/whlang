# Wheelchair 1.3.48 Pure Assembly Release Proof

The production build remains handwritten x86-64 assembly plus GNU assembler and
linker. 1.3.48 adds no C, C++, LLVM, JIT, Python production generator, runtime
scheduler or external numerical library.

ValueFact lifetime convergence is implemented inside the existing common Field
assembly lowerer. Planning and emission share a compile-time liveness proof;
regular stores consume existing runtime Physical Facts. No new runtime register
manager or arithmetic cache is introduced.

Native512 code generation is kept on its mature path. Release audit compiled the
same strict Hex8 graph with the released 1.3.47 and 1.3.48 native512 compilers
and required byte-identical ELF output.
