# Wheelchair 1.3.48 Native256 ValueFact Lifetime Convergence

## Scope

1.3.48 strengthens the existing native256 Field physicalizer. It does not add a
second AVX2 backend, workload route, runtime scheduler, arithmetic algorithm or
Field opcode. Native512 physicalization is intentionally unchanged.

## Old-architecture debt

1.3.47 made YMM ownership truthful, but the old episode cache still transported
many immutable values through a logical carrier and back out again even when the
next strict arithmetic instruction was their only remaining consumer. The
information flow was already known by the Physical DAG; the transport survived
only because resident selection and emission asked separate questions.

The same drift existed at output stores. The episode tail mask and q position
were already live Physical Facts, yet the mature helper path reconstructed them
again and then forced resident reloads.

## Convergence

The 1.3.48 lowerer gives planning and emission one shared compile-time liveness
proof:

```text
immutable ValueFact
  -> next physical consumer is strict MUL operand B
  -> this version has no later observer before redefinition
  -> erase standalone transport
  -> consume resident/stack authority directly as the existing MUL operand
  -> last use retires the logical carrier
```

This is not arithmetic CSE. `mul` is still executed exactly where strict source
semantics require it. No reassociation, FMA contraction or NaN-sensitive operand
swap is introduced.

LoadFacts and ConstantFacts also compete in the same native256 resident-carrier
economy. Demand is measured after consumer-local transport has been erased, so
resident capacity is not awarded to a transport that no longer exists.

For contiguous output fields under the existing cache-coherent policy, store
emission consumes the already-live YMM4 tail mask and q/end facts directly.
Non-contiguous output and active non-temporal policy use the mature helper path.

## Measured structural effect

On the strict 64^3 Hex8 validation graph, compared with the released 1.3.47
native256 binary:

```text
vmulps                         2304 -> 2304
vaddps                         1156 -> 1156
explicit vector stack loads   3207 -> 1555
VMULPS stack memory operands     0 -> 1153
```

The arithmetic DAG is therefore unchanged while redundant transport is reduced.
The three output fields are byte-identical between 1.3.47 and 1.3.48.

## Measured timing

Release host: AMD EPYC 9V74 virtualized, one CPU affinity, strict f32, 64^3
Hex8 graph, 61 alternating whole-process runs using the same `/dev/shm` fields.

```text
1.3.47 native256 median  41.641721 ms
1.3.48 native256 median  40.153676 ms
ratio                      1.037059x
```

This is a diagnostic release-host result, not a universal language-speed claim.

## Remaining debt

The remaining long strict accumulation chains mostly reuse one logical floating
carrier. Register ownership is now correct and transport is substantially
smaller, so the next generic pressure point is versioned-carrier renaming and
anti-dependency removal. A workload-specific three-output schedule or AVX2-only
algorithm branch is explicitly not part of 1.3.48.
