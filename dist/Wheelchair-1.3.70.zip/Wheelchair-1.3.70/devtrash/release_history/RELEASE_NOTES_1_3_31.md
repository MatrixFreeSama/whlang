# Wheelchair 1.3.31 Release Notes

## Scope

1.3.31 closes the old-architecture debt exposed by native mathematics, mixed floating precision, and selected-axis tensor contraction. No parallel math subsystem was added.

## Precision propagation contract

A new compile-time declaration selects the existing numeric type-meet policy:

```text
precision_propagation 0
precision_propagation 1
```

`0` is the default and preserves Wheelchair's low-precision-contagion rule. `1` mirrors the same consumer-edge mechanism so the higher floating precision dominates. Both policies realize each child at its natural precision before any edge conversion. The policy is orthogonal to strict/tolerant floating-point semantics.

## Rank-N contraction closure

The handwritten surface now lowers selected-axis `sum`, `contract`, `dot`, `inner`, `matmul`, and true matrix `trace` into the existing Rank-N expression DAG. Contracted axes disappear at compile time; retained axes remain ordinary output dimensions.

Validated native cases include 3×3, 6×6 and 7×7 matrix multiplication, true 3×3 trace, and arbitrary-radix Rank-N coordinate recovery on both derived AVX-512 and derived native256 lanes.

## Old-architecture defects removed

- Compile-time substitution no longer aliases one AST occurrence into multiple index chains.
- Arbitrary-radix coordinate helpers no longer keep temporary carrier identities in caller-saved compiler registers.
- Constant-radix quotient/remainder realization reuses dead temporary carriers rather than expanding a private register budget.
- AOT constant/fixup capacity is unified under the existing compiler authority instead of failing at particular matrix sizes.
- Source Rank-N shapes and strides are persisted per declaration.
- Rank-1 expressions now pass through the same Rank-N rewrite authority with identity axis semantics, allowing them to load higher-rank sources correctly.
- The physical execution-domain product belongs to the final reduction domain rather than leaking from an earlier high-rank map.
- Tuple successor identity is owned by the rewrite stack frame across recursive rewrite and AST-builder calls.

## Explicit non-features

There is no BLAS wrapper, matrix runtime, trace special path, matmul special backend, mixed-precision runtime, runtime shape manager, or workload-name dispatch.
