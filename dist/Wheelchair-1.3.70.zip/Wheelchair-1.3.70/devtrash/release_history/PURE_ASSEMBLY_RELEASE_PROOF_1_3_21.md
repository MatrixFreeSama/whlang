# Pure Assembly Release Proof — Wheelchair 1.3.21

The production compiler and runtime remain handwritten x86-64 assembly. The production build invokes neither Python nor a C/LLVM/JIT backend.

The 1.3.21 production change is confined to AOT physicalization in the existing general frontend:

- post-CSE state last-consumer analysis is compile-time only;
- next-version FP results may recycle a dead old-state XMM authority directly;
- `state_temp` is retained only for causally unsafe overwrite cases;
- the fixed `G_PHYS_FP_RESIDENT_MAX=6` policy is physically absent;
- resident FP capacity is derived from target XMM carrier geometry;
- carrier collisions and anonymous-carrier exhaustion remap the same DAG rather than selecting a new backend;
- no runtime transport manager, allocator, graph walker, or workload selector is emitted.

Release validation requires exact semantic outputs across the inherited causal-state and simulation suites, protected arithmetic counts, no hot stack fallback, and explicit machine-code checks showing zero `movabs ds:` state handoff in the `chem6` steady-state loop.
