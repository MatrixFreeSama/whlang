# Wheelchair 1.3.30 — Local Low-Precision Contagion

## Governing rule

Implicit mixed floating-point arithmetic uses a **local precision meet**, not C-style widening and not eager whole-expression narrowing.

For the currently materialized scalar formats:

```text
meet(f32, f32) = f32
meet(f32, f64) = f32
meet(f64, f32) = f32
meet(f64, f64) = f64
```

When an integer ValueFact meets a floating ValueFact, the integer is converted to the floating precision selected by that local operation. Explicit `cast(...)` remains explicit authority and is not part of implicit contagion.

## Evaluation boundary

For an expression node `z = op(x, y)`:

1. `x` is first evaluated at its own inferred precision.
2. `y` is first evaluated at its own inferred precision.
3. Only on the dependency edges entering `op` are mismatched precisions converted to `meet(type(x), type(y))`.
4. `op` executes at that meet precision.
5. The resulting ValueFact naturally carries that precision into later consumers.

Therefore a low-precision fact can propagate upward through the DAG, but it cannot tunnel downward into a high-precision child subtree.

The discriminating probe is:

```text
(16777217_f64 - 16777216_f64) + 1_f32
```

The f64 subtree must produce exactly `1` before the f32 meet. Eagerly narrowing the complete expression would first turn `16777217` into `16777216` and would produce the wrong result.

## Physical-DAG realization

1.3.30 extends the existing General ValueFact / Physical-DAG realization instead of adding a mixed-precision backend.

A native mixed expression now realizes as, for example:

```text
vaddsd      # high-precision child subtree
cvtsd2ss    # exactly at the f64 -> f32 consumer edge
vaddss      # low precision has now propagated
```

Supported Physical-DAG arithmetic now includes strict `add`, `sub`, `mul`, `div`, and unary `sqrt` across the existing f32/f64 carriers.

There is no precision runtime, graph walker, mixed-precision scheduler, or library ABI.

## Shared projections and zero mandatory redundancy

A precision projection is still an ordinary compile-time ValueFact consequence. The existing whole-episode CSE authority keys a repeated subtree together with the precision required at its consumer edge.

If the same high-precision ValueFact feeds repeated low-precision consumers and carrier reality admits retention, the high subtree is evaluated once, narrowed once, and the projected f32 ValueFact is reused. No separate precision cache or runtime manager exists.

CSE recursion follows the natural precision of the current node when descending into children. This is essential: the consumer precision of a parent is never recursively imposed on the interior of a high-precision child subtree.

Recomputation remains a physical-cost option only when retaining a projected fact would cost more carrier/lifetime resources; the architecture does not mandate duplicate conversions.

## Lane audit

- **General:** real f32/f64 mixed arithmetic; local low-precision contagion is authoritative.
- **Field:** current sovereign Field semantics are f32-only, and hidden f64 promotion remains forbidden. There is no mixed Field precision to merge yet.
- **Tensor:** current sovereign Tensor arithmetic is f64-only. There is no mixed Tensor precision to merge yet.


## Regression gates

`devtrash/release_tests/test_low_precision_contagion_1330.sh` checks:

- late f64 -> f32 propagation using a value that would expose eager narrowing;
- continued upward contagion after the first low-precision meet;
- no implicit f32 -> f64 promotion in pure f32 arithmetic;
- one retained projection reused by multiple low-precision consumers;
- deep CSE does not push an outer f32 requirement into an inner f64 subtree;
- native Physical-DAG realization rather than mixed-expression stack fallback.

Current gate:

```text
LOW_PRECISION_CONTAGION_1_3_30=PASS
```
