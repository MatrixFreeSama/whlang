# Wheelchair 1.3.49 Pure Assembly Release Proof

The production compiler remains handwritten x86-64 assembly assembled and linked by GNU binutils. 1.3.49 adds no C/C++ backend, LLVM, JIT, Python production generator, external numerical library, runtime register manager, task scheduler, work-stealing runtime, or global ready queue.

Sparse physical materialization is implemented by aging the existing Field and Tensor AOT physicalizers. Field native256/native512 continue to share one assembly lowerer. Tensor profile selection is removed from the native driver rather than replaced by another selector. Target differences remain assembly capabilities and encodings.

The release build scans production sources for workload-specific selectors and hidden serial scheduling vocabulary, and the final artifacts are static executables.
