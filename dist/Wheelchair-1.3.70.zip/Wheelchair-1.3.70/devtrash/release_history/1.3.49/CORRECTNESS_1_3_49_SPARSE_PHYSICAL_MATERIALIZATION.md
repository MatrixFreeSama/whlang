# Wheelchair 1.3.49 Sparse Physical Materialization Correctness

Release correctness is structural as well as numerical.

Field validation requires native256 and native512 to compile the same strict Hex8 oracle, preserve 2304 `vmulps`, emit no FMA contraction, and produce byte-identical output files. Both widths must demonstrate consumer-local stack-backed direct consumption in generated code.

Tensor validation requires `topologyc` and its historical `topologyc-wide` name to be byte-identical compiler implementations, and the same for native256. Representative FSI output must remain inside the established tolerant-width ULP envelope. The generated native512 probe must remain inside the former wide machine-work envelope without selecting a wide profile.

Architecture validation rejects the old structural-load profile dispatcher, fixed persistent-reserve policy, fixed reuse-use threshold, workload identity selectors, work stealing, a global ready queue, and a central scheduler. Persistent and generation-scoped high-register lifetime domains must be disjoint before pass-1 emission.
