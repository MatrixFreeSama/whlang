# Sparse Physical Materialization 1.3.49

## Principle

The logical Physical DAG may be arbitrarily wide without requiring equally wide simultaneous physical state. A fact is logical information first. Physical residency is created only when a consumer frontier needs it and the current target makes retention cheaper than rematerialization or direct consumption.

```text
complete Physical DAG
        |
Global Fact identity / use / last-consumer facts
        |
AOT materialization authority
        |
retain | direct-consume | rematerialize at consumer
        |
target capability and encoding
```

This is the execution analogue of matrix-free computation: preserve the complete relation while avoiding unnecessary complete materialization.

## Field convergence

The common Field x86-64 lowerer owns one materialization policy for native256 and native512. The target supplies physical facts such as lane count, carrier count, mask representation and VEX/EVEX encoding. Policy does not ask whether the target is called AVX2 or AVX-512 before deciding whether a consumer-local immutable fact may be consumed directly.

The release keeps strict arithmetic order. Direct memory operands erase transport only. They do not reassociate, contract, commute or delete arithmetic.

## Tensor convergence

The primary native512 Tensor lane no longer selects a base or wide register profile from a fixed structural-load count. Pass 0 observes generation-scoped transient use of the real high ZMM bank. It also estimates long-lived rematerialization value for AffineFact and ConstantFact candidates. Pass 1 reserves disjoint lifetime domains before code emission:

```text
real high-ZMM bank
  -> generation-scoped transient domain
  -> long-lived persistent domain
```

The sizes come from the current DAG and target capacity. No fixed `reserve2`, `max8`, `use>=4`, or load-count `10/14` policy is authoritative.

Binding/value caches remain generation-scoped. Their temporary physical existence is borrowed at the consumer frontier and released with that generation. Native256 has no synthetic high bank and therefore naturally rematerializes through its existing direct-load/RIP-pool authority.

## Non-goals

1. This release does not add a runtime scheduler.
2. It does not replace the existing outward execution cost model.
3. It does not claim every derived Tensor lane has already been source-merged with the primary Tensor frontend.
4. It does not introduce a workload-specific sparse mode.
5. It does not turn tolerant floating-point transformations on in strict mode.
