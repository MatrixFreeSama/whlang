# Wheelchair 1.3.49 Release Notes

## Unified sparse physical materialization

1.3.49 converges physical materialization rather than adding an ISA-specific optimization family.

Field native256 and native512 now use one policy in the existing common x86-64 lowerer. Consumer-local immutable ValueFacts may be consumed directly from their existing resident or stack authority on either width. Direct regular stores reuse an already-live episode mask/index authority on either width. VEX/EVEX bytes, lane count, predicate representation and architectural carrier count remain target capabilities.

The primary native512 Tensor physicalizer retires the historical base/wide resource-profile split and the native driver no longer chooses a profile from fixed structural-load-count thresholds. Pass 0 observes generation-scoped transient high-register occupancy. Long-lived AffineFact and ConstantFact candidates compete for the remaining real high-ZMM capacity by AOT rematerialization value. Pass 1 assigns persistent and transient lifetime domains before canonical emission so a hoisted persistent fact cannot alias a generation-scoped carrier at runtime.

`topologyc` and `topologyc-wide` are compatibility names for one native512 implementation. `topologyc-native256` and `topologyc-wide-native256` likewise denote one native256 implementation. Native256 retains its real YMM0..15 authority and does not invent a high register bank.

No runtime materialization manager, ready queue, work stealing, central scheduler, workload selector, Hex8 selector, or named-size policy was introduced. Existing outward execution materialization remains unchanged.

## Validation

The release gate requires strict Field native256/native512 byte equality on the packaged Hex8 oracle, unchanged strict multiplication count, zero FMA contraction, one Tensor base/wide implementation, Tensor tolerant-width results inside the established ULP envelope, and a machine-work probe no worse than the established wide profile envelope.

A release-host diagnostic on the same 64^3 strict Hex8 input measured approximately 39.071 ms median for frozen 1.3.48 native512 and 33.913 ms for the current unified native512 sample. Frozen and current native256 generated ELF files for that graph were byte-identical; measured native256 medians were approximately 49.578 ms and 50.089 ms respectively and are treated as noise-level variation. These numbers are diagnostic observations on one virtualized host, not general language-speed guarantees.
