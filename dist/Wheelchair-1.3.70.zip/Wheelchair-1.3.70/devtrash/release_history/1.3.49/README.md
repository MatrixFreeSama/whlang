# Wheelchair 1.3.49

## 1.3.49 unified sparse physical materialization

1.3.49 ages physical materialization into one architecture-neutral authority instead of adding another AVX2, AVX-512, base, wide, sparse, or benchmark route. The complete Physical DAG remains the logical authority, while a ValueFact becomes physically resident only when its consumer frontier and target capabilities justify that state. Long-lived and generation-scoped facts occupy disjoint lifetime domains derived by the AOT pass from the current DAG.

The common Field lowerer now gives native256 and native512 the same consumer-local materialization policy. Both widths may consume a stack-backed immutable ValueFact directly as an existing arithmetic memory operand and both widths may reuse the already-live regular-store mask/index state. VEX versus EVEX encoding, architectural register count, lane count, and predicate form remain physical capabilities rather than optimization-policy branches.

The primary native512 Tensor physicalizer no longer owns separate base and wide resource profiles. The old driver thresholds based on structural-load count are removed. Pass 0 measures generation-scoped transient high-register demand, long-lived AffineFact and ConstantFact candidates compete by AOT rematerialization value, and pass 1 partitions the one real high-ZMM bank into disjoint lifetime domains. Compatibility compiler names remain aliases of the same implementation. Native256 likewise has one real topology compiler and no fictional high-register bank.

This is sparse physical materialization rather than a runtime overload controller. There is no ready queue, work stealing, central scheduler, runtime register manager, or workload identity. Existing outward execution materialization remains governed by its older physical-cost authority.

On the release host, a diagnostic 64^3 strict Hex8 run using the same input files measured the new native512 code in the same performance class with a lower median than the frozen 1.3.48 native512 sample, while the native256 generated ELF was byte-identical across the two releases. These are host-specific diagnostics, not universal speed claims. The strict Field release oracle requires byte-identical native256/native512 outputs and preserves the same arithmetic operation count with no FMA contraction.

See `SPARSE_PHYSICAL_MATERIALIZATION_1_3_49.md` and `CORRECTNESS_1_3_49_SPARSE_PHYSICAL_MATERIALIZATION.md`.

## 1.3.48 native256 ValueFact lifetime convergence

1.3.48 continues aging the existing AVX2/native256 Field physicalizer rather
than adding an AVX2 fast path. Immutable LoadFacts and ConstantFacts share the
one real YMM ownership economy established in 1.3.47. A single compile-time
liveness proof now drives both resident demand and final emission: when an
immutable producer is consumed immediately as the second operand of a strict
`mul` and that version has no later observer, the producer transport disappears
and the existing `VMULPS` consumes the resident or stack-backed ValueFact
directly. No arithmetic operation is deleted or reassociated.

Contiguous output stores also consume the already-materialized episode mask/q
Physical Fact instead of calling the older store helper to rebuild the same
state and then reload residents. Runtime non-contiguous and non-temporal-policy
paths retain the mature helper authority. Native512 physicalization is unchanged
byte-for-byte on the release Hex8 graph.

On the release host, 61 alternating single-CPU whole-process runs of the strict
64^3 Hex8 validation graph measured 41.642 ms median for the 1.3.47 native256
binary and 40.154 ms for 1.3.48, a 1.037x speedup. The generated AVX2 graph
keeps 2304 `vmulps` and 1156 `vaddps`; explicit vector stack loads fall from
3207 to 1555 while 1153 strict multiplies consume a stack-backed ValueFact as
the existing memory operand. The three output fields remain byte-identical.

The next known debt is not another AVX2 branch: long strict recurrences still
reuse one logical carrier and therefore expose physical anti-dependencies. That
belongs to future versioned-carrier aging, not to this release. See
`VALUEFACT_LIFETIME_1_3_48.md` and
`CORRECTNESS_1_3_48_VALUEFACT_LIFETIME.md`.


## 1.3.47 native256 physical ownership aging

1.3.47 strengthens the existing AVX2/native256 backend without adding a new
algorithm family or workload route.  Native256 now describes one real YMM0..15
physical bank and gives Field ValueFacts, tail mask, strict reduction,
procedural indices and helper scratch disjoint roles inside that bank.  The
former v3/YMM4 tail-mask alias is closed by the common Field lowerer through a
compile-time native256 physical profile.

Tensor/native256 also drops the copied mutable high-register cache/constant
ownership state that could never be physical on AVX2.  Its existing direct
load/RIP-pool path remains authoritative.  Native512 physicalization is
unchanged.  See `AVX2_PHYSICAL_OWNERSHIP_1_3_47.md` and
`CORRECTNESS_1_3_47_AVX2_PHYSICAL_OWNERSHIP.md`.

## 1.3.46 human-shell static select erasure

1.3.46 changes only the WH human shell.  When contraction-axis substitution
makes a `select` predicate static, the surface chooses the live source branch
before cloning its data subtree.  This allows the existing `matrix`/`mget`,
`contract`, affine field-neighborhood and `select` semantics to compose in the
compact Hex8 form without growing dead compile-time AST.

No runtime/backend authority or field opcode is added.  The release gate runs
a compact static-select contraction and its strict hand-expanded source on the
same native field input and requires byte-identical outputs.


## 1.3.45 human-shell static structure bridge

1.3.45 changes only the WH field human shell. Existing `matrix`, `mget`, selected-axis `contract`, and neighborhood addressing can now compose directly in compact WH source and erase to the same canonical field graph as hand expansion. No runtime/backend authority is added.

The release gate requires byte-identical ELF output for compact vs hand-expanded probes.


Wheelchair is a handwritten-assembly, AOT, HPC-first general language organized around ValueFacts, Rank-N structural relations and a Physical DAG rather than a mandatory sequential instruction stream.

## 1.3.44 mathematics generalization

This release ages two formerly young regions without adding named-size or named-precision algorithm families. Square matrices now belong to one dimension-bearing Structured Matrix family; `matrix2/3/4` remain source aliases, while `matrix(n, ...)` can cross the historical sixteen-component boundary for generalized base algebra. Structured materialization/select/differentiation scratch is derived from actual component count. The one matrix inverse relation now includes dataflow partial pivoting. Advanced decompositions whose old workset is not yet generalized reject oversized facts safely rather than growing matrix5/matrix6 implementations.

The parameterized `fpP` algebra now natively supplies `sqrt`, `exp`, `log`, `sin`, and `cos` for `P > 64`. These relations absorb only the local-propagation idea: current scale determines local contraction and the current representation determines termination. No NRII solver or runtime is imported. Representative fp65/fp127/fp521 oracle anchors are within four significand ULPs on the release points; this is not a universal correct-rounding claim, and extreme trigonometric argument reduction remains a future maturity target.

A matched three-language diagnostic benchmark is recorded in `PERFORMANCE_1_3_44_C_FORTRAN.md`. On the release machine, the three-kernel geometric mean was 1.097813x C time for Wheelchair and 0.978267x C time for GFortran, with bit-identical final checksums. The result is retained without benchmark-specific routing.

## Parameterized floating precision

Native `f32` and `f64` keep direct CPU paths. Any finite floating precision wider than 64 bits is one generic semantic:

```text
fpP
```

where `P > 64` is the significand precision in bits. Precision is data. There are no dedicated 128-, 256-, 512- or 2048-bit implementations.

The existing precision meet remains upstream of physicalization:

```text
operands
  -> precision_propagation meet
  -> <=64: native scalar/SIMD
  -> >64: Rank-N precision ValueFact
  -> physicalization
```

`precision_propagation 0` selects lower precision and `precision_propagation 1` selects higher precision only at the real consumer edge. A child subtree keeps its natural precision until that edge.

## 1.3.43 root precision assimilation

RootRelation now consumes the same parameterized precision facts as ordinary arithmetic. There is no `root_fp128`, `root_fp256`, or wide-root fallback. A root expression remains in its current representation, including any `fpP` with `P > 64`.

The old f64-only acceptance constants have been removed. Root validity now uses Newton correction visibility in the current representation, and real projection uses the same representation-stability fact for the imaginary component. Precision-neutral zero/one identities inherit the consumer representation.

P>64 comparisons are now one shared numeric authority over sign, exponent, and significand, so RootRelation and every other general expression compare fpP values rather than carrier addresses. The native Fourier multiplication path also fixes the AOT packed-geometry boundary so the 32-bit `n64` fact cannot absorb the adjacent geometry word during final cross-limb digit extraction. This is one width-correct physical boundary, not a named-precision exception.

Release validation includes exact-oracle roots at fp65, fp127 and fp521 plus dense division-produced significand multiplication at fp127/fp191. See `devtrash/release_history/1.3.43/ROOT_PRECISION_FUSION_1_3_43.md`.

## 1.3.42 sparse root relation

`root` is now one compile-time relation rather than a scalar-only Newton spelling. The result is discovered on-site as sparse `valid`, `real`, and `imag` facts. No caller declares whether the answer is real, complex, or empty.

```text
root(x, expression, guess)
root(x, expression, guess, static_iterations)
```

Omitting the fourth argument means five AOT Newton generations. A scalar seed is lifted into the existing complex Structured Fact search space without creating a second complex-root solver. Symbolic differentiation is shared componentwise, zero derivatives are protected with dataflow select facts, and every generation checkpoints into the old scalar ValueFact authority. A real answer is simply a converged complex fact whose imaginary carrier collapses when it is no longer distinguishable in the current representation. If the AOT budget produces no acceptable candidate, `root_valid` is false and the numerical carriers project to zero. This is an unresolved/empty computation result, not a theorem that the mathematical relation has no root.

Existing complex `exp`, `sin`, and `cos` were also sparsified by checkpointing their scalar semantic components once, so RootRelation can parasitize them without regrowing dense transcendental trees. See `devtrash/release_history/ROOT_RELATION_1_3_42.md`.

## 1.3.41 sparse native mathematics fusion

1.3.41 does not add a second mathematics runtime or an algorithm selector. It folds overlapping old algorithms into shared compile-time facts and lets existing semantics project the result:

```text
old mathematical identity
  -> one shared semantic kernel
  -> sparse ValueFact projection
  -> existing Physical DAG
```

The release unifies the Euler/Lambert exponential seed for `exp`/`expm1`, a compensated `log1p` fact reused by inverse hyperbolic identities, the Abramowitz-Stegun complement tail for `erf`/`erfc`, one Lanczos core for the Gamma family, and one scale-safe Euclidean norm for scalar `hypot` and complex magnitude. Removable singularities such as `sinc(0)` are represented with existing select ValueFacts rather than a runtime control-flow branch.

The rule is intersection rather than addition: if A and B share a mathematical core, the core becomes the authority and A/B become projections. Existing bit-level release results are kept where they are already contractual, including `exp(1)`, `gamma(5)` and `factorial(5)`.

See `devtrash/release_history/MATHEMATICS_FUSION_1_3_41.md` for the identities and source map.

## 1.3.40 native Fourier assimilation

For `P > 64`, multiplication now has one production physical authority. The former singleton row-carry implementation, AVX-512 IFMA batch implementation and multiplication selector were deleted rather than retained as compatibility paths.

The common multiplication identity is:

```text
z = a + i*b
ab = Im( F^-1( F(z)^2 ) ) / 2
```

The local engine uses mixed-radix DIF forward stages and the reverse DIT inverse stages. Frequency order never has to be globally permuted before the pointwise square.

AOT derives one packed geometry fact from P:

```text
(b, a2, a3, a5)
N = 2^a2 * 3^a3 * 5^a5
```

subject to the native numerical safety condition

```text
ceil(P/b) * (2^b - 1)^2 * ceil(log2(N)) < 2^51
```

and one continuous physical cost surface. There is no named-precision threshold tree and no multiplication-algorithm enum. Generated programs carry the selected geometry in the existing Rank-N physical object header. Runtime geometry derivation exists only for ingress paths that do not have an AOT fact.

The transform implementation is local x86-64 assembly. FFTW, GMP, libm, JITs and external numerical runtimes are not production dependencies. GMP is used only in `devtrash/` release oracles and benchmarks.

Division remains the common base-2^32 Knuth digit implementation introduced before this release.

## Performance status

On the release machine, the fully local production multiplication path is within roughly ±20% of GMP `mpf_mul` from 262144 through 4194304 bits in the measured run, with several points faster. Smaller wide precisions retain the fixed cost of the single Fourier authority; this release deliberately does not add a small-P algorithm branch to hide that cost. See `devtrash/release_history/PERFORMANCE_1_3_40_NATIVE_FOURIER.md` and the raw CSV under `devtrash/benchmarks/native_fourier_1340/`.

## Architecture priority

1. Parasite the old architecture first.
2. Strengthen the old architecture second.
3. Create a new authority only when the old substrate cannot express the requirement.
4. Any unavoidable new authority must be high-affinity, high-extensibility and assimilatable into the common substrate.
5. Local performance irregularities are acceptable; architecture may not regrow a threshold-driven algorithm tree to erase them.

## Build

```sh
./build.sh
```

Production executables are emitted under `bin/`. Release validation lives under `devtrash/release_tests/`.
