# Wheelchair 1.3.34 Advanced Dev Merge

This directory is not a new formal release. It is the 1.3.34 release baseline with the later Library development `surface_lowerer_x86_64.S` merged into the existing compiler architecture and rebuilt.

## Proven integration

- Base 1.3.34 release source and directory structure retained.
- Later surface lowerer merged into `compiler/surface_lowerer_x86_64.S`.
- No new math runtime, scheduler, executor, BLAS dependency, or libm dependency added.
- `build.sh` completes successfully.
- Existing 1.3.34 release gates still pass:
  - `PRECISION_POLICY_1_3_34=PASS`
  - `NATIVE_MATHEMATICS_1_3_34=PASS`
  - `RANKN_MATHEMATICS_1_3_34=PASS`
  - `WHEELCHAIR_1_3_34_FINAL_RELEASE=PASS`

## Development-head expansion

The merged surface grows the math registry from 60 to 97 entries and adds compile-time Structured Facts:

- complex structured values and basic complex arithmetic/functions;
- matrix2/matrix3/matrix4 structured values;
- transpose, trace, Hadamard, SPD construction;
- Cholesky, Modified Gram-Schmidt, QR-R, LU, LDLT;
- inverse, eigensystem, SVD;
- matrix exp/log/sqrt;
- complex sin/cos/sqrt.

Structured Facts remain compile-time containers over the existing scalar AST/ValueFact authority and do not become a second runtime representation.

## Smoke-test status

Working through the normal `.wh` compiler entry in this merged tree:

- complex: real/imag, multiplication, complex exp/log/sin compile and run in tested cases.
- matrix: Cholesky, QR-R, LU and inverse compile and return correct tested 2x2 values.
- all inherited 1.3.34 precision, native mathematics and Rank-N gates remain green.

## Known development defects

This tree is more capable than the 1.3.34 release but is not yet release-mature.

- Structured `let` aliases are not fully admitted by the sovereign main-entry route; inline projection works more broadly.
- `cabs` and `complex_sqrt` reject on the tested normal-entry path.
- LDLT tested projections can crash the compiler.
- eig/SVD tested projections have rejection/crash paths.
- `matrix_exp` currently applies the series coefficient in the wrong direction. A test on diag(1,0) returns 2 for the (0,0) element instead of e.
- `matrix_log` likewise multiplies odd-series terms rather than dividing them. A test on diag(2,1) returns 0.888888... instead of ln(2).
- `matrix_sqrt` rejected on the tested normal-entry path.

Therefore this merge is an advanced development head, not a replacement release.

## Provenance note

The later Library source was only exportable as indexed text ranges, not as authorized raw bytes. The reconstructed assembly source builds successfully and preserves all inherited release gates, but its byte identity is not claimed to equal the inaccessible Library raw file.
