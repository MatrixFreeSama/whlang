# Pure Assembly Release Proof — Wheelchair 1.3.34

Production compiler and runtime authorities remain handwritten assembly/native code. The production build does not invoke Python, LLVM, GCC as a code-generation backend, libm, BLAS or MPFR.

Native mathematics is realized either by direct ISA-level primitives/ordinary ValueFacts or by compile-time lowering into existing arithmetic and Rank-N facts. The Semantic Registry is compile-time compiler data; it is not a runtime dispatch table.

`devtrash/` has no production authority and is not referenced by `build.sh`.
