# Correctness — Wheelchair 1.3.34 Native Mathematics

## Release gates

- `test_precision_policy_1334.sh`: low/high precision meet policies and emitted conversion ISA.
- `test_native_mathematics_1334.sh`: representative elementary, special-function and calculus outputs.
- `test_rankn_mathematics_1334.sh`: Rank-N statistics plus inherited arbitrary-radix matmul/trace contraction gates.
- `lcg64_iterate_wrap.wh`: mature General causal-state regression.

## Representative numeric proofs

Validated current f64 bit patterns include:

- `sin(1)` = `0x3feaed548f090cee`;
- `exp(1)` = `0x4005bf0a8b145769`;
- `log(2)` = `0x3fe62e42fefa39ef`;
- `zeta(2)` = `0x3ffa51a6625307d3`;
- `elliptic_k(0.5)` = `0x3ffdaa4a35759e4a`;
- `elliptic_e(0.5)` = `0x3ff59c3cc21a46c7`;
- `root(x,x*x-2,1)` = `0x3ff6a09e667f3bcd`.

`integral(x,0,1,x*x)` produces `0x3fd5555555555556` (nearest f64 to 1/3). Symbolic `derivative(sin(x),x)` at x=1 produces the same f64 bits as `cos(1)`.

## Rank-N proof

The final gate reuses the 3×3 / 6×6 / 7×7 matrix multiplication and true trace tests from 1.3.31 on both derived AVX-512 and derived native256 lanes. Statistics over `[1,2,3,4]` validate mean/norm/variance composition on both lanes.

## Explicit numerical scope

Some special-function implementations are finite-domain approximations rather than correctly rounded universal libm replacements. The release claims the tested semantic and numerical domains documented by the gates, not every branch cut or extreme argument in mathematical analysis.
