# Wheelchair Charter 1.3.34

## Mathematics is native semantics

Mathematical notation is language semantics, not a library boundary. A mathematical construct must do one of the following:

1. become an ordinary existing ValueFact;
2. become an existing Rank-N relation/contraction/reduction;
3. disappear during compile-time semantic lowering.

It may not justify a second runtime, scheduler, executor or workload-specific backend.

## Semantic Registry is shared infrastructure

New scalar mathematical vocabulary is registered rather than added to the parser control-flow tree. The registry owns name, arity and semantic properties. Structural calls use a finite structural parse-class registry and immediately return to the existing authorities.

The registry is infrastructure for future language semantics, not a private special-function subsystem.

## Less work

- A shared mathematical fact should exist once.
- Precision conversion occurs only on a real consumer edge.
- A high-level operation should erase if its structure can be represented by existing facts.
- Powers of two are optimization opportunities, not dimensional restrictions.
- No precomputation/table/runtime layer may replace a cheaper direct structural representation without proof.

## Physical authority

Runtime execution remains governed by Physical Reality, Physical DAG, ValueFact lifetime, carrier ownership and Rank-N causality. Source spelling cannot create an execution branch.

## Honest capability boundary

