# Wheelchair 1.3.34 Release Notes

## Semantic Fact convergence

1.3.34 turns the mathematical expansion work into a reusable architecture rather than a growing family of parser/backend branches. The handwritten surface owns a Semantic Registry carrying mathematical names, arity, semantic identity and properties. Structural mathematical calls use a corresponding parse registry and then return to the existing AST / Rank-N authorities.

`exp` and `log` were promoted from giant surface expansions to ordinary native ValueFacts. This collapses higher functions such as real powers and Gamma-family expressions without adding a math runtime. Shared `square` semantics similarly prevents repeated serialization of the same self-product structure.

## Native mathematics

Validated representative families include elementary/transcendental functions, reciprocal/hyperbolic functions, erf/Gamma/Beta, Lambert W, Bessel J/I, zeta/polylog, elliptic K/E, digamma/trigamma, inverse erf, normal distribution helpers, factorial/binomial/rising/falling factorial, tetration and small fixed determinants.

## Native calculus

Symbolic differentiation erases before canonical execution. Gauss-Legendre integration and Newton root solving are compile-time mathematical lowering over the same arithmetic facts; no integration or solver object survives at runtime.

## Rank-N mathematics

The selected-axis contraction authority from 1.3.31 is reused for matrix/tensor products and statistics. Arbitrary-radix static extents and both derived AVX-512/native256 paths remain validated.

## Precision policy

`precision_propagation 0/1` is kept as one compile-time type-meet policy. Current release tests use type-closed destinations so the policy is tested at the actual expression meet rather than conflating propagation with assignment/storage typing.

## Program validity

Embedded `test` declarations are validation metadata, not a semantic prerequisite. A source with valid outputs compiles with or without embedded tests.

## No parallel math architecture

No math runtime, scheduler, executor, matrix runtime, BLAS/libm dependency or workload-specific math route is introduced.
