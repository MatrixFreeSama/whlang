# Wheelchair Charter 1.3.31

## One architecture

Mathematics, precision policy, matrix algebra and tensor contraction are surface semantics over the existing AST, Rank-N, ValueFact, Physical Reality and Physical DAG authorities.

No feature may introduce a parallel runtime, scheduler, executor or workload-specific backend merely because its source spelling is mathematical.

## Precision locality

Every ValueFact is realized at its natural precision. A precision policy acts only on a real consumer edge.

- `precision_propagation 0`: lower floating precision dominates.
- `precision_propagation 1`: higher floating precision dominates.

A consumer may project a ValueFact to the selected precision. It may not retroactively change the internal precision of that ValueFact's producing subtree. Reusable projections belong to ordinary ValueFact/CSE lifetime authority.

## Rank-N ownership

A declaration owns its logical shape. Shape, stride and source-index interpretation are compile-time facts attached to that declaration.

The execution domain is owned by the final physical reduction being executed. No prior declaration may enlarge or shrink another declaration's work domain.

Static extents are arbitrary positive cardinalities. Powers of two are optimization facts only.

## Contraction

Selected-axis contraction is a Rank-N transformation, not a matrix backend. `matmul`, `trace`, dot products and higher tensor contractions must erase into the same ordinary arithmetic and load DAG.

## Red lines

```text
MATH_RUNTIME=0
MATRIX_RUNTIME=0
BLAS_DEPENDENCY=0
MIXED_PRECISION_RUNTIME=0
RUNTIME_SHAPE_MANAGER=0
WORK_STEALING=0
GLOBAL_READY_QUEUE=0
WORKLOAD_SPECIFIC_MATH_ROUTE=0
```
