# Wheelchair 1.3.58

Regression-only convergence release. The ShapeFact-N launcher selector now chooses the already-existing base consumer for rank-1/product-1 shape and the already-existing derived consumer for productized Rank-N shape. This repairs the 1.3.57 coupled-FSI routing regression without adding semantics or execution authorities.
