# Wheelchair 1.3.24 Branch-Extinction Performance Evidence

## Host

- AMD x86-64 cloud host
- visible CPU affinity: 0-4 (5 CPUs)
- AVX2, FMA3 and usable AVX-512F

All timings below are same-host, alternating 1.3.23/1.3.24 whole-process runs. They are evidence, not universal performance promises.

| Probe | Work | 1.3.23 median | 1.3.24 median | ratio |
|---|---:|---:|---:|---:|
| chem6 | 20,000,000 steps | 165.380 ms | 157.962 ms | 1.047x |
| ring8 | 10,000,000 steps | 54.100 ms | 51.387 ms | 1.053x |
| rigid7 | 1,000,000 steps | 13.592 ms | 13.989 ms | 0.972x |
| mass3 | 5,000,000 steps | 43.001 ms | 43.905 ms | 0.979x |
| rigid7_cseprobe | 500,000 steps | 6.609 ms | 6.747 ms | 0.979x |

The last three are short, strongly causal scalar probes where process/host noise is comparable to the observed difference. Their exact output bits remain unchanged.

## FSI leaf-geometry rematch

| Elements | 1.3.23 median | 1.3.24 median | ratio |
|---:|---:|---:|---:|
| 10,000,000 | 6.798 ms | 7.297 ms | 0.932x |
| 50,000,000 | 30.128 ms | 29.521 ms | 1.021x |
| 100,000,000 | 57.396 ms | 54.371 ms | 1.056x |

The 10M case is dominated by the larger fixed launch cost of deriving and realizing the new physical leaf geometry. A linear fit over 10M/50M/100M separates that fixed cost from steady-state work:

- 1.3.23 slope: about 0.562 ns/element
- 1.3.24 slope: about 0.522 ns/element
- steady-state throughput ratio: about 1.076x

The important result is that removing fixed chunk geometry does not trade away large-work throughput. It improves the asymptotic physical rate while avoiding a new hard-coded replacement chunk.

## Machine-work evidence

- Tensor FSI probe: `vpmullq` sites <= 20, `vmovdqa64` sites = 44, `vpbroadcastq` sites = 53 under the current release gate.
- High-pressure tolerant Field corpus: common-factor closure keeps >=1000 FMA sites while reducing scalar/vector multiply sites to <=600 without restoring private Factor opcodes.
- Three-term common-factor probe proves admission is not tied to the deleted two-term template.
