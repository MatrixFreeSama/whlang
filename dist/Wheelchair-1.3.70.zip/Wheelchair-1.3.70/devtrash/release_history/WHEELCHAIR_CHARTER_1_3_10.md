# Wheelchair 1.3.10 Charter

## Blind Surplus Reflow and Load-Balancing Extinction

Wheelchair 1.3.10 turns the Active-Silicon Purity doctrine of 1.3.9 into executable architecture.

The supreme objective is not CPU occupancy. It is the fraction of activated physical work that is necessary work.

```text
not: maximize active hardware
but: maximize necessary work among hardware that is active
```

Idle silicon is legal when no independent causal work exists. Activated silicon performing avoidable coordination, polling, redistribution, duplicated realization, artificial synchronization or occupancy maintenance is a design failure.

## 1. Work exists before execution capacity

Hardware width is never demand authority. Affinity, CPU count and `--executors N` define only an upper bound on simultaneous physical activation.

The existence of independent causal work is the only authority that may request additional execution capacity.

```text
causal work -> eligibility to activate silicon
hardware     -> maximum permission ceiling
```

A machine with eight available CPUs and only three independent causal regions is allowed to activate only three execution domains. The five idle CPUs are not a defect.

## 2. Load balancing is extinct

Wheelchair must not balance workers because worker equality is not an optimization target.

The following mechanisms are forbidden as execution authorities:

- static equal work partitioning by worker count;
- proportional capacity assignment by subtree size;
- work stealing;
- push balancing or pull balancing;
- peer load observation;
- idle-worker or busy-worker discovery for redistribution;
- queue-length feedback;
- global load tables;
- global ready queues;
- post-completion work search;
- runtime occupancy autotuning;
- work migration whose purpose is to make processors look equally busy.

No optimization is valid merely because it raises a task-manager utilization percentage.

## 3. Canonical causal-work topology

Tensor and Field execution topology is derived from the canonical causal chunk tree, not from executor IDs.

The canonical reduction tree exists independently of hardware width. The same mathematical tree is retained whether the capacity ceiling is 1, 2, 4 or 256. Capacity availability may change how many independent subtrees execute simultaneously. It must not change which causal work exists.

This unifies strict and tolerant execution topology while retaining their numerical contracts.

## 4. Blind Surplus Reflow

Wheelchair 1.3.10 completes the resource-reflow loop without introducing a load balancer.

A completed causal region releases anonymous execution capacity. It does not select a recipient.

A causal region that already owns another independently executable subtree may make a blind bounded claim for anonymous capacity. It does not search for a donor.

```text
finished causal work
        |
        v
anonymous capacity release
        |
        v
unowned execution permission
        ^
        |
blind bounded claim
        |
pre-existing independent causal work
```

The object being claimed is execution permission, not another thread's work.

Therefore:

```text
release is recipient-blind
acquisition is donor-blind
```

There is no donor-to-recipient relationship.

## 5. Distributed anonymous credits

Anonymous surplus capacity is represented by four cache-line-isolated credit bitsets. Consecutive credits are striped across the four lines.

There is no single global surplus counter and no central capacity queue.

At a causal expansion point, a claimant performs one bounded pass over the four anonymous credit lines. If the claim fails, it does not spin, sleep-poll, inspect peers or retry the same causal point.

A failed claim never creates work. The already-owned causal subtree remains valid local work.

If the capacity ceiling is greater than one, execution continues down the canonical tree. A later real causal expansion point may make one new blind claim. This is not retry spinning. It is a distinct piece of already-existing causal structure becoming eligible later.

If the capacity ceiling is one, no surplus capacity can ever exist, so the direct local subtree evaluator is used without useless credit probes.

## 6. Release semantics

A claimed capacity slot remains owned only until its causal result has been consumed safely and its private stack slice can be reused.

At that physical handoff point the capacity is returned anonymously. The releasing region does not know which region, if any, will claim it next.

Wheelchair does not promise that capacity reaches the globally most needy region. Such a promise would require global load knowledge and would recreate a load balancer.

## 7. No fake parallelism

A capacity claim cannot create causal work. It may activate only an independent subtree that already exists in the semantic and physical dependency graph.

Wheelchair therefore accepts natural causal width smaller than hardware width.

```text
available CPUs = 8
natural causal width = 3
legal active width = 3
```

Artificially splitting a dependent region merely to increase occupancy is forbidden.

## 8. Affinity and compatibility spelling

Affinity is a permission and locality boundary only. Counting an affinity mask cannot create execution demand.

`--executors N` remains as a compatibility spelling, but its 1.3.10 semantics are strictly:

```text
maximum permitted concurrent capacity = N
```

It does not mean "create N workers".

The source and runtime authority names are now `capacity_ceiling`, `MAX_CAPACITY_SLOTS` and `RUNTIME_CAPACITY_CEILING_OFF`. Historical executor-count names remain only where binary/source compatibility requires a same-address alias. They possess no architectural authority.

## 9. Protected mechanisms

The load-balancing purge must not destroy mechanisms whose purpose is actual causal or machine work.

The following remain protected:

- General causal futex waiting on a region's own indegree;
- AOT Kahn topology queues used only during compilation;
- intra-kernel SIMD carrier scheduling that removes dependency stalls inside already-active silicon;
- locality constraints that express physical permission or cost, not peer load;
- compile-time physical scheduling that reduces instructions or dependencies without runtime worker redistribution.

A causal futex wait is especially important: when no legal work exists, the execution context yields CPU instead of burning active silicon in a spin loop.

## 10. Active-Silicon Purity

Wheelchair evaluates execution changes using both elapsed time and total active CPU time.

A lower occupancy percentage can be a success if it removes unnecessary active work. A higher occupancy percentage can also be a success if newly activated silicon is executing real independent causal work and total physical cost improves.

Therefore no occupancy number is intrinsically good or bad.

The governing question is always:

> Is activated silicon performing necessary work, or is it being kept active only to preserve the appearance of busyness?

## Permanent red lines

```text
HARDWARE_WIDTH_IS_DEMAND_AUTHORITY=0
STATIC_EQUAL_WORK_PARTITION=0
PROPORTIONAL_EXECUTOR_SPLIT=0
EXECUTOR_ID_WORK_TOPOLOGY=0
WORK_STEALING=0
PUSH_BALANCING=0
PULL_BALANCING=0
PEER_LOAD_OBSERVATION=0
PEER_WORK_OBSERVATION=0
GLOBAL_LOAD_TABLE=0
GLOBAL_READY_QUEUE=0
GLOBAL_SURPLUS_COUNTER=0
POST_COMPLETION_WORK_SEARCH=0
FAILED_CLAIM_SPIN=0
RUNTIME_BALANCING_AUTOTUNE=0
OCCUPANCY_AS_OPTIMIZATION_TARGET=0

CAUSAL_WORK_IS_DEMAND_AUTHORITY=1
HARDWARE_WIDTH_IS_ONLY_CEILING=1
ANONYMOUS_SURPLUS_RELEASE=1
BLIND_CAPACITY_CLAIM=1
RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1
RESOURCE_ACQUISITION_IS_DONOR_BLIND=1
CLAIM_REQUIRES_PREEXISTING_CAUSAL_WORK=1
ACTIVE_SILICON_PURITY_IS_PRIMARY=1
```

## Final rule

**Activate no silicon without necessary work. Waste no activated silicon on avoidable work.**
