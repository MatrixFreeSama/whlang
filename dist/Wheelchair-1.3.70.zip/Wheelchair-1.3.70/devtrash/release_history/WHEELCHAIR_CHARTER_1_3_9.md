# Wheelchair 1.3.9 Charter: Active-Silicon Purity Doctrine

Wheelchair 1.3.9 is a charter-only release. It changes no compiler, runtime, executable, backend, ISA realization, benchmark program, or test implementation from 1.3.8. Its purpose is to correct the highest-level optimization doctrine and remove an earlier conceptual ambiguity.

## Supreme objective

Wheelchair does not exist to maximize operating-system CPU utilization, worker occupancy, executor occupancy, thread occupancy, or the percentage shown by a task manager.

Wheelchair exists to maximize the fraction of work performed by activated silicon that is strictly necessary for the requested semantics.

The target is not:

```text
CPU utilization -> 100%
```

The target is:

```text
Useful Active Silicon Fraction -> 100%
```

Define:

```text
Useful Active Silicon Fraction
=
necessary semantic / numerical / physical work
-----------------------------------------------
all work executed by activated silicon resources
```

This is the governing metric. A lower CPU-utilization percentage is acceptable, and may be preferable, if it removes avoidable active work.

A machine at 70% CPU utilization with more than 95% useful active-silicon work is architecturally superior to a machine at 95% CPU utilization that burns a large fraction of its active execution on coordination, polling, redistribution, duplicate realization, avoidable movement, speculative bookkeeping, artificial synchronization, or other non-semantic work.

## Idle is not the enemy. Active waste is the enemy.

Wheelchair makes a strict distinction:

```text
inactive / released silicon
    no necessary independent work exists
    -> legitimate

active silicon doing avoidable work
    coordination / polling / balancing / duplicate work / waiting machinery
    -> violation
```

Wheelchair must never manufacture work merely to make hardware look busy.

If the current causal graph exposes only three independent physical regions on a four-core machine, three busy cores and one released core can be the correct result. Filling the fourth core by adding coordination, repartitioning, stealing, migration, or artificial splitting is forbidden unless that added physical work is itself necessary to preserve semantics or demonstrably reduces total necessary physical work without introducing forbidden coupling.

## No load-balancing authority

Load balancing is not a Wheelchair optimization objective.

No Wheelchair execution domain may observe peer load for the purpose of balancing work. No domain may ask which executor is idle, which executor is busy, which executor has less work, or where released capacity should be sent.

The following concepts are forbidden as runtime optimization authorities:

```text
worker load equality
executor load equality
peer utilization inspection
idle-worker discovery
busy-worker discovery
push balancing
pull balancing
work redistribution
work migration for occupancy
work stealing
victim selection
destination-aware handoff
global ready queue
central balancing scheduler
occupancy chasing
```

A compile-time decomposition is legal only when it follows true semantic independence, dependency topology, exact floating-point contract, locality, and physical profitability. Compile-time partitioning must not optimize for equal worker loads as an end in itself.

The compiler asks:

```text
Which work is truly independent and necessary?
```

It must not ask:

```text
How do I keep every worker equally busy?
```

## Causal width is authoritative

Parallel width is a property of the problem's currently exposed independent physical work, not a target occupancy number.

Wheelchair must expose natural parallelism aggressively, but it must never fabricate parallelism to satisfy a utilization target.

Therefore:

```text
available hardware width > causal physical width
```

is not a defect.

Unused hardware capacity must remain unused or be released when no additional independent necessary work exists.

## Recipient-blind release is one-way

Wheelchair's cascade release has exactly one responsibility:

```text
my necessary work ended
    -> my authority ends
    -> my occupied resources are released immediately
    -> my responsibility ends
```

There is no next question.

The releasing domain does not ask who needs the resource, where the resource should go, what another executor is doing, whether another worker is overloaded, or whether global occupancy can be improved.

Release is not redistribution. Release is not balancing. Release is not stealing. Release is not scheduling diplomacy between workers.

The compiler, operating system, and hardware may subsequently make released physical capacity available to other independent work. That is outside the releasing domain's semantic authority.

## Activated silicon must earn its activation

Every persistent register fact, load, store, conversion, arithmetic operation, synchronization edge, executor, queue element, memory transfer, branch, address construction, cache-maintenance action, and coordination operation must have a physical justification.

The justification must be one of:

```text
required by semantics
required by the declared numerical contract
required by a true dependency
required by target-ISA correctness
or proven to remove more necessary physical work than it introduces
```

"It increases utilization" is not a valid justification.

"It keeps another worker busy" is not a valid justification.

"It makes the workload more balanced" is not a valid justification.

"Traditional schedulers do this" is not a valid justification.

## Anti-busywork rule

Wheelchair rejects any optimization that primarily increases hardware activity rather than useful physical progress.

Forbidden examples include:

- spinning to preserve apparent occupancy;
- polling peer state without a true dependency;
- waking an executor without necessary independent work;
- splitting a causal region solely to fill idle hardware;
- moving work between executors solely to equalize load;
- duplicating a value because recomputation keeps a unit busy;
- preserving dead register authority;
- maintaining queues whose only purpose is dynamic balancing;
- adding synchronization to support redistribution machinery;
- performing bookkeeping whose only reward is a higher utilization percentage.

## True parallelism definition

Wheelchair true parallelism means:

```text
independent necessary work executes independently
without hidden serial coordination
and without manufactured coordination whose purpose is to preserve occupancy
```

More active workers do not automatically mean more true parallelism.

A smaller number of workers executing only necessary independent work can be more faithful to Wheelchair than a fully occupied machine dominated by coordination and redistribution.

## Strict floating-point consequence

The 1.3.8 strict exact-reduction repair remains valid implementation authority. Its canonical arithmetic tree exists because strict floating-point semantics require exact operation identity across executor counts.

1.3.9 changes the interpretation of the remaining partition language:

- exact dependency subtrees are legitimate because they are semantic structure;
- equalizing executor loads is not a goal;
- natural idle capacity created by the canonical tree is acceptable;
- future implementations must prefer direct causal decomposition over any mechanism whose purpose is load equality.

No strict-FP semantic requirement may be weakened to increase occupancy.

## Performance doctrine

Performance is measured by useful progress per physical cost, not by visual busyness.

Preferred evidence includes:

```text
fewer unnecessary dynamic instructions
fewer redundant loads/stores
fewer redundant fact births
fewer avoidable broadcasts/conversions
fewer synchronization operations
fewer coordination instructions
less active energy spent on non-semantic work
lower latency for the same contract
higher throughput for the same contract
higher useful work per joule
```

CPU utilization by itself is not evidence of optimization quality.

A regression in utilization with an improvement in useful active-silicon purity can be a design success.

## No benchmark occupancy theater

No benchmark may be optimized by increasing worker count, occupancy, or apparent parallelism when those actions do not reduce total necessary physical cost.

No workload-name specialization, benchmark-size dispatch, hidden table, runtime autotuning, or opponent-specific path may be introduced to improve a utilization chart or benchmark ranking.

Wheelchair wins only when the machine performs less unnecessary physical work while preserving the declared semantics.

## Relationship to earlier charters

This charter supersedes any earlier wording that can be read as requiring all cores, all execution units, all workers, or all transistors to remain busy.

The historical phrase "squeeze the silicon limit" is hereby defined precisely:

> Activate no silicon without necessary work. Waste no activated silicon on avoidable work.

The goal is not maximum active silicon.

The goal is maximum purity of active silicon work.

Any earlier reference to "load balancing", "keeping hardware full", "filling workers", or equivalent language is non-authoritative when it conflicts with this charter.

## 1.3.9 implementation boundary

1.3.9 deliberately changes no implementation code.

The complete 1.3.8 compiler/runtime/build/test/benchmark/executable implementation is carried forward byte-for-byte. This release changes doctrine, documentation, release metadata, and interpretation only.

Therefore 1.3.9 does not falsely claim that every inherited 1.3.8 mechanism has already been rewritten to the stronger doctrine. Any inherited mechanism whose purpose is genuinely load balancing rather than causal decomposition is now classified as legacy non-authoritative machinery and a future deletion target.

It may not be cited as precedent for new Wheelchair design.

## Absolute red lines

Wheelchair rejects, without qualification:

1. Work stealing.
2. Runtime load balancing.
3. Peer-load observation for redistribution.
4. Global ready queues.
5. Central runtime scheduling authority.
6. Post-completion peer queries.
7. Destination-aware resource handoff.
8. Artificial work creation for occupancy.
9. Artificial dependency edges for coordination.
10. Hidden serial coordination inside a claimed parallel mechanism.
11. Runtime autotuning whose purpose is worker balancing.
12. Persistent physical facts without justified future consumers.
13. Redundant physical realization of an already valid fact when retention is physically cheaper.
14. Benchmark-specific optimization disguised as general architecture.
15. Any optimization justified only by a higher task-manager percentage.

## Final doctrine

Wheelchair is not an occupancy machine.

Wheelchair is an anti-waste machine.

It does not exist to make silicon busy.

It exists to make busy silicon useful.

The asymptotic target is:

```text
Useful Active Silicon Fraction -> 100%
Avoidable Active Silicon Work  -> 0%
```

Everything else is subordinate.
