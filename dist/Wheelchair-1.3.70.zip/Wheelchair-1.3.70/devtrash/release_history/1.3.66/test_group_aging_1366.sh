#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ -x bin/topologyc ] || ./build.sh >/dev/null

# Single Group authority. Physical Reality may price GroupFact, but must not
# mirror its semantic constitution or own a private packet width.
for law in \
  GF_VECTOR_IS_DEGENERATE_GROUP \
  GF_SCALAR_IS_DEGENERATE_VECTOR \
  GF_SINGLE_BODY_FACTOR_AUTHORITY \
  GF_SINGLE_CARRIER_FACTOR_AUTHORITY \
  GF_CANONICAL_BODY_FACTOR_DRIVES_ALL_TENSOR_EMITTERS; do
  grep -q "^.equ ${law},1$" compiler/groupfact.inc
done
for law in \
  GF_PRIVATE_DENSE_PACKET_WIDTH \
  GF_ZERO_DOMAIN_CAP_IS_CODEGEN_GATE \
  GF_GROUP_IS_OPTIMIZER_BRANCH \
  GF_RUNTIME_GROUP_MANAGER \
  GF_GROUP_WIDTH_CANDIDATE_SET \
  GF_GROUP_PROFITABILITY_WORKLOAD_ROUTE; do
  grep -q "^.equ ${law},0$" compiler/groupfact.inc
done
grep -q '^.equ PR_GROUPFACT_IS_SINGLE_SEMANTIC_AUTHORITY,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUPFACT_CANONICAL_FACTORS_DRIVE_EXECUTION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_PRIVATE_WIDTH_AUTHORITY,0$' compiler/physical_reality.inc
grep -q '^.equ PR_GROUP_DOMAIN_CAP_CODEGEN_GATE,0$' compiler/physical_reality.inc
! grep -Rqs 'vec_dense_group_packets' compiler runtime surface tools
! grep -RqsE 'group_(candidate|threshold)_(2|4|8|16|32)|workload.*group.*route' compiler runtime surface tools
for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  ! grep -Fq 'cmp dword ptr [rip+group_body_cap],0' "$f"
done

T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
LIGHT=devtrash/benchmarks/automatic_grouping_1365/group_light_probe.whex
STRENGTH=devtrash/benchmarks/automatic_grouping_1365/group_strength_big.whex
R2=devtrash/benchmarks/automatic_grouping_1365/group_rank2_1024_light.whex
NEWTON=devtrash/tests/whex/newton_jv_mature_regression.whex

# The body/carrier facts already selected by 1.3.65 are now actually consumed by
# every Tensor emitter. Correctness stays bit exact for these exact-sum probes.
for C in topologyc topologyc-native256 topologyc-derived-native256; do
  bin/$C "$LIGHT" -o "$T/light.$C" >/dev/null
  [ "$("$T/light.$C" 1024)" = 'checksum_bits=0x411ff80000000000' ]
  set -- $(od -An -tu4 -j 4128 -N16 "$T/light.$C")
  [ "$1" = 2 ] && [ "$2" = 2 ] && [ "$3" = 2 ] && [ "$4" = 2 ]
  bin/$C "$STRENGTH" -o "$T/strength.$C" >/dev/null
  [ "$("$T/strength.$C" 1024)" = 'checksum_bits=0x411e100000000000' ]
done

# Finite Rank-N dense grouping consumes GroupFact directly without a private
# dense packet-width copy. Native512 and native256 may realize different bodies
# because physical carriers and measured costs differ, not because of branches.
bin/topologyc-derived "$R2" -o "$T/r2.512" >/dev/null
[ "$("$T/r2.512" 1024)" = 'checksum_bits=0x41bff80000000000' ]
set -- $(od -An -tu4 -j 4128 -N16 "$T/r2.512")
[ "$1" = 1 ] && [ "$2" = 8 ] && [ "$3" = 1 ] && [ "$4" = 8 ]
bin/topologyc-derived-native256 "$R2" -o "$T/r2.256" >/dev/null
[ "$("$T/r2.256" 1024)" = 'checksum_bits=0x41bff80000000000' ]

# Strict mature path remains bit exact across both physical widths.
for C in topologyc topologyc-native256; do
  bin/$C "$NEWTON" -o "$T/newton.$C" >/dev/null
  [ "$("$T/newton.$C" 4)" = 'checksum_bits=0xbfaa960790000000' ]
done

echo GROUP_AGING_1_3_66=PASS
