# Wheelchair 1.3.66 Automatic Grouping aging

1.3.66 removes remaining places where Automatic Grouping was described by one authority and enabled by another. No new optimizer family is introduced.

The canonical chain is:

`ValueFact / ShapeFact-N / Axis / Operator -> GroupFact -> Physical Reality -> Physical DAG -> ISA`

## What was deleted

- `vec_dense_group_packets`, the derived-native512 private copy of the selected Group body width. Dense countdown, emission and realization now read `group_body_factor` directly.
- Tensor codegen gates that interpreted `group_body_cap == 0` as "disable Group". A zero cap now means only that ShapeFact supplies no finite domain bound.
- The duplicated Physical Reality Group constitution (`PR_AUTOMATIC_GROUPING`, hierarchy mirrors, width-authority mirrors and execution mirrors). `groupfact.inc` is the semantic authority; Physical Reality owns only target facts/costs used to realize it.
- The 1.3.65 current release test from the active release-test directory; it is archived under `devtrash/release_history/1.3.65/` and replaced by the 1.3.66 single-authority gate.

## What became canonical

All Tensor physicalizers consume the same `group_body_factor` / `group_carrier_factor` pair. Finite Rank-N geometry may cap the body, but the cap is not a second policy switch. Body one remains the mature Vector degeneration. A body larger than one is emitted as one Group control episode when the common Physical Reality relation selected it.

Derived-native512 retains its stronger finite dense-axis proof and interior-packet relation. Base/native256 paths reuse their existing Group emitters instead of carrying an unreachable branch behind a zero-cap gate. No target-specific workload route was added.

## Producer/consumer and Field

This release deliberately does not add a separate Group fusion pass around Field. Field already builds Global Physical Reality and a def/use Physical DAG, performs exact duplicate-fact elimination, common-factor contraction under tolerant semantics, and dependency-depth ordering before final ISA emission. Tensor binding expansion likewise already keeps producer/consumer structure inside the expression DAG. A second Group-specific producer/consumer subsystem would duplicate authority. The aging direction is to let Group consume those existing relations, not rebuild them.

## Hard prohibitions preserved

No fixed Group candidate set, fixed source-size threshold, workload-name route, runtime Group manager, JIT/autotune, global ready queue, work stealing, recipient selection or compatibility vectorizer is introduced.
