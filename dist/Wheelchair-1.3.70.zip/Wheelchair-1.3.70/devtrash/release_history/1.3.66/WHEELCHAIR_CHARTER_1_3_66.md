# Wheelchair Charter 1.3.66

- Group is the complete structural computation form; Vector and Scalar are degradations.
- `GroupFact` is the single semantic and width authority for Group execution.
- Physical Reality prices GroupFact from actual target facts; it does not mirror a second Group constitution.
- ShapeFact-N owns logical geometry. A finite domain may bound Group extent; absence of a finite cap does not disable an already-proved Group.
- Producer/consumer, shared-input and materialization relations must reuse the existing ValueFact / Physical-DAG authorities rather than create a Group-specific optimizer zoo.
- Group extent is derived from measured physical cost and relation structure, never from workload identity or a fixed candidate table.
- No work stealing, global ready queue, runtime Group manager, JIT/autotune, hidden serial coordinator or recipient-selection policy is admissible.
- Finished work releases resources recipient-blind; Group execution does not redistribute work.
