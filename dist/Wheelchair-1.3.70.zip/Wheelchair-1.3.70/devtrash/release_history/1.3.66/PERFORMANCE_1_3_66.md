# Wheelchair 1.3.66 performance note

The performance purpose of 1.3.66 is not a wider fixed Group. It removes the old codegen gate that prevented already-selected GroupFact body/carrier relations from reaching several Tensor emitters.

Measurements below are diagnostics from the current shared AMD EPYC 9V74 environment, pinned to one logical CPU and run interleaved. They are not universal speed guarantees.

For 400,000,000 elements, 31-run medians:

| Probe | 1.3.65 | 1.3.66 | Change |
| --- | ---: | ---: | ---: |
| native512 light reduction | 46.058 ms | 46.071 ms | -0.03% |
| native512 strength | 69.457 ms | 70.262 ms | -1.15% |
| native256 light reduction | 119.791 ms | 59.941 ms | +99.85% throughput |
| native256 strength | 158.400 ms | 85.013 ms | +86.32% throughput |

The native256 changes are real target-machine-code changes with bit-identical results. The native512 light result is statistically neutral on this shared host; the arithmetic-heavy native512 probe shows a small regression, so the release does not claim that every body>1 Group is profitable on every microarchitecture. The architecture intentionally keeps profitability in Physical Reality rather than adding a benchmark exception.

The finite Rank-N derived-native512 path already executed Group in 1.3.65. Removing its private `vec_dense_group_packets` copy therefore preserves representative target ELFs byte-for-byte while reducing compiler authority duplication. Representative Field targets are likewise byte-identical to 1.3.65.
