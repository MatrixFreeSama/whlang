# Correctness: Wheelchair 1.3.66 Group aging

The 1.3.66 release gate requires one Group authority and verifies that the selected factors are consumed by every Tensor emitter without private width copies or zero-cap codegen gates.

Validated invariants include:

- `Group -> Vector -> Scalar` remains one degradation chain.
- `group_body_factor` and `group_carrier_factor` remain the only production width facts.
- `vec_dense_group_packets` is absent from production source.
- `group_body_cap == 0` is not used by base/native256 Tensor emitters as a Group-disable branch.
- Physical Reality does not mirror a second Group semantic constitution.
- No fixed 2/4/8/16/32 candidate family, workload Group route or runtime Group selector is present.
- Representative native512/native256 light and strength probes preserve exact checksum bits after the newly enabled Group episode.
- Rank-2 x 1024 derived-native512 preserves exact checksum and closes selected/realized Group factors at body 8 on the release host.
- Mature strict Newton-Jv remains bit exact on native512 and native256.
- Strict Rank-3 and neighborhood Rank-3 representative outputs remain unchanged.
- Representative Field sum and neighborhood target ELFs are byte-identical to 1.3.65, proving that Group aging did not insert a duplicate Field backend.

`devtrash/release_tests/test_group_aging_1366.sh` is the current structural/functional release gate.
