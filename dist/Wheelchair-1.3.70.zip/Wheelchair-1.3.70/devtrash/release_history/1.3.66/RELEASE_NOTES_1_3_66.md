# Wheelchair 1.3.66 release notes

1.3.66 is an architecture-aging release for Automatic Grouping.

The release deletes the private derived-native512 dense Group width copy, removes zero-domain-cap Group-disable gates from the remaining Tensor emitters, and collapses the duplicated Physical Reality Group constitution into the existing `GroupFact` semantic authority. The generated `build/` workspace remains excluded from release archives.

No source syntax changes are required. No new optimizer family, workload-specific path, runtime scheduler, JIT, autotuner, work stealing, fixed Group candidate set or compatibility backend is added.

The current release gate is `devtrash/release_tests/test_group_aging_1366.sh`. Representative strict, Rank-N, native256 and Field regressions pass.
