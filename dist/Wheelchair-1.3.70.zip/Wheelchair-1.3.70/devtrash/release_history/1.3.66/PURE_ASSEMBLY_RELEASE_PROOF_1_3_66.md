# Pure assembly release proof 1.3.66

The production compiler/runtime path remains handwritten assembly with direct ELF emission. Group aging adds no C, LLVM, JIT, runtime autotuner or generated-language backend.

`build.sh` reconstructs production binaries from `compiler/`, `runtime/`, `surface/` and `tools/`. Python remains absent from production build authority. The release archive excludes generated `build/`.

The 1.3.66 Group changes are compile-time authority convergence and direct machine-code emission changes inside the existing Tensor physicalizers. Field continues to use its existing Global Physical Reality and Physical-DAG pipeline rather than a duplicate Group backend.
