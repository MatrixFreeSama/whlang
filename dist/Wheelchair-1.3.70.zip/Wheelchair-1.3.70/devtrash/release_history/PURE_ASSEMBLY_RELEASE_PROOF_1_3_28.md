# Wheelchair 1.3.28 Pure-Assembly Release Proof

Production compiler and runtime sources remain handwritten x86-64 assembly plus linker scripts/shell build glue. `build.sh` invokes no Python, GCC, Clang, LLVM optimizer, JIT or external mathematical library for production code generation.

Native mathematics in this release is realized inside the existing assembly compiler:

- General scalar sqrt is emitted as `sqrtss` / `sqrtsd`.
- Tensor sqrt is emitted as `vsqrtpd` for AVX-512 or AVX2.
- Field sqrt is emitted as `vsqrtps` for AVX-512 or AVX2.
- Rank-N linear-reduction semantics are erased into ordinary existing arithmetic/reduction graphs before native realization.

Every production executable remains static. There is no dynamic `libm` dependency and no new math runtime object.
