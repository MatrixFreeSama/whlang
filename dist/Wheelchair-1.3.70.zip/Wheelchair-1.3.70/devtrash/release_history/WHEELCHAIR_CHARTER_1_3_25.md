# Wheelchair 1.3.25 Charter

## Release Surface Cleanup / Branch-Growth Firewall

1.3.25 changes repository authority, not execution semantics.

### Production authority

Only these trees may define current production behavior:

- `compiler/`
- `runtime/`
- `surface/`
- production helpers in `tools/`
- `build.sh`

Production executables exist only in `bin/`.

### Development archive

`devtrash/` contains tests, benchmarks, historical releases, old source snapshots, frozen regression material, and release evidence. It is intentionally non-authoritative.

Production source must not depend on `devtrash/` by include, link, copy, parse, code generation, fallback, compatibility dispatch, or runtime lookup.

### Branch-growth rule

A historical special case may not return to production merely because it was fast. Its useful property must first be represented as a general fact or proof in the existing architecture:

```text
semantic fact
    -> ValueFact / structural proof
    -> Physical Reality
    -> Physical DAG
    -> native realization
```

A workload name, solver name, benchmark name, fixed state count, fixed AST shape, old compatibility format, or archived source file is never optimization authority.

### Release-root rule

The repository root describes the present release only. Historical release documents and regression machinery belong in `devtrash/`.
