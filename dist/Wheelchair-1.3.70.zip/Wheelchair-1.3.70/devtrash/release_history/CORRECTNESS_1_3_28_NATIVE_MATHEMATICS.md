# Wheelchair 1.3.28 Native Mathematics Correctness Evidence

## Scalar

`sqrt(9.0)` emits a sovereign General ELF and returns IEEE-754 f64 bits `0x4008000000000000` (3.0). Generated code contains `sqrtsd`.

## Tensor

For `sqrt([1,2,3,4])` followed by the established f64 reduction, both AVX-512 and AVX2 generated executables return:

`checksum_bits=0x401895c653b5e21e`

which is `sqrt(1)+sqrt(2)+sqrt(3)+sqrt(4) = 6.146264369941973` under the generated reduction path. Generated code contains `vsqrtpd`.

## Materialized Field

On the existing 3×5×7 f32 field containing values 1..105, `sum sqrt(a)` returns for both AVX-512 and AVX2:

`checksum_f32_bits=0x44348d32`

Generated code contains `vsqrtps`. The decoded f32 result is 722.2061767578125; the high-precision scalar reference is approximately 722.2062090208681, consistent with f32 vector/reduction rounding.

## Native linear reductions

For `a=[1,2,3,4]` and `b=[1,3,5,7]`:

- `dot(a,b)` = 50
- `squared_norm(a)` = 30
- `squared_distance(a,b)` = 14

The generated General ELF reports exact f64 bit patterns for all three.

## Rejection boundary

True matrix `trace`, `matmul`, Gram/Gram-Schmidt, SPD, SVD and eigensystem semantics are not claimed by 1.3.28. The current missing common authority is selected-axis contraction preserving non-contracted Rank-N output axes. No fake all-axis substitute is installed.
