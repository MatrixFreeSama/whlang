# Wheelchair 1.3.61 architecture aging: Automatic Grouping

1.3.61 inserts no compatibility layer. The historical Tensor physical-plan fields `physical_tensorized`, `physical_plan_unroll` and `physical_plan_carriers` are deleted from all four Tensor physicalizers. The resource scheduler remains the machine-cost authority, but it no longer hands a one-dimensional width directly to canonical code generation.

A new sparse compile-time `GroupFact` authority is absorbed by `Physical Reality`. It receives logical rank from ShapeFact-N, operation relations recovered from the scalar expression DAG, target lane geometry, and the exact body/reduction factors already proven legal by the backend probe. It derives a structural form and then canonical physicalization consumes `physical_plan_group_body` and `physical_plan_group_carriers`.

There is no Group runtime, no group syntax, no second scheduler, no fixed rank table, no fixed group/tile size and no group admission threshold. Group cardinality overflow is diagnostic-only and becomes unknown rather than a compile rejection.

The hierarchy is architectural rather than cosmetic: Scalar is rank-0 degradation, Vector rank-1 degradation, and richer operation-native geometry remains Group. Existing ShapeFact-N continues to own logical axes, so GroupFact does not become a second shape database.
