# Wheelchair 1.3.10 Release Notes

## Blind Surplus Reflow and Load-Balancing Extinction

Wheelchair 1.3.10 is the implementation release that follows the doctrine reset of 1.3.9. It removes the remaining Tensor/Field load-balancing family from the production execution path and adds donor-blind, recipient-blind anonymous execution-capacity reflow.

### Removed

- Tensor static `id * chunks / P` equal partitioning.
- Field static `id * chunks / P` equal partitioning.
- Strict proportional executor-capacity split derived from subtree size.
- Executor-ID work topology as an execution authority.
- Hardware-width-as-worker-demand semantics.
- Tolerant reliance on the historical balanced partition fabric.

### Added

- Canonical causal chunk tree shared by strict and tolerant Tensor execution.
- Canonical causal tree for Field reduction execution.
- Anonymous capacity credits distributed across four cache-line-isolated bitsets.
- Blind bounded capacity claim at real causal expansion points.
- Anonymous release after safe causal-result handoff.
- Deeper causal expansion after a failed claim, allowing later released capacity to be claimed without spinning or retrying the same point.
- Capacity-ceiling terminology throughout production source authority.

### Capacity semantics

`--executors N` is retained only as a compatibility spelling. It now means `capacity ceiling N`. Affinity-derived CPU count is also a ceiling, never demand.

### Numerical behavior

The original FSI diagnostic graph is not a specialization trigger. It is used only as a regression probe.

For 10M elements, current AVX-512 wide results are identical across capacity ceilings q1/q2/q4:

```text
tolerant: checksum_bits=0x4130e896f42e1d94
strict:   checksum_bits=0x4130e896f42e1dd6
```

For 100M elements:

```text
tolerant: checksum_bits=0x416522bcff4adae6
strict:   checksum_bits=0x416522bcff4adb3a
```

The 1.3.8 strict 100M one-ULP repair remains preserved, and tolerant execution now also follows the same capacity-independent causal reduction tree.

### 1.3.8 to 1.3.10 active-silicon audit

Host: Intel Xeon Platinum 8573C, 5 visible vCPUs, sustained cgroup quota 4 CPUs. Each point is the median of 15 interleaved process runs at N=100M. CPU time includes child processes through `wait4`.

The FSI arithmetic hot payload is byte-identical between 1.3.8 and 1.3.10:

```text
tolerant hot payload SHA-256:
2b14f374f7adb2935e18485e5de5f5d0908dc6d708489ba666b3b4bd029aeda4

strict hot payload SHA-256:
163f7f4b32907586c7b4dec540953f004ea208c7b5b19fdf1e96aa7ec2849648
```

The change is execution-resource topology, not a benchmark-specific arithmetic rewrite.

Selected results:

```text
tolerant q2:
1.3.8  wall 163.058 ms, CPU 320.053 ms, 1.968 core-equivalent
1.3.10 wall 164.698 ms, CPU 269.260 ms, 1.640 core-equivalent
CPU active time: -15.87%, wall: +1.01%

tolerant q4:
1.3.8  wall 83.526 ms, CPU 318.845 ms, 3.810 core-equivalent
1.3.10 wall 85.106 ms, CPU 270.973 ms, 3.182 core-equivalent
CPU active time: -15.01%, wall: +1.89%

strict q4:
1.3.8  wall 163.809 ms, CPU 477.018 ms, 2.913 core-equivalent
1.3.10 wall 124.686 ms, CPU 402.070 ms, 3.220 core-equivalent
CPU active time: -15.71%, wall: -23.88%
```

Across q1/q2/q4, geometric mean CPU active time changes are:

```text
tolerant: -10.89%
strict:    -5.16%
```

Geometric mean elapsed-time changes are:

```text
tolerant: +0.70%
strict:    -8.36%
```

The tolerant result is a deliberate example of the 1.3.9/1.3.10 doctrine: Task-Manager-style occupancy may fall substantially while total active CPU work falls much more, even if elapsed time remains approximately flat. Strict q4 demonstrates the other half of the design: anonymous reflow can reactivate released capacity at later causal expansion points and improve elapsed time while still reducing total active CPU work.

These are host- and workload-specific measurements. They are not a transistor-level measurement of Active-Silicon Purity and are not a universal performance claim.
