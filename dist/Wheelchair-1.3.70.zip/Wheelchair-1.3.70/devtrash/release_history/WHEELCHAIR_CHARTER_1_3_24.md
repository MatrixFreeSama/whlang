# Wheelchair 1.3.24 Charter

## Branch extinction rule

An optimization may not be admitted because a workload name, solver name, source spelling, fixed state count, fixed term count, fixed recursion depth, historical chunk size, or compatibility flag matches a private branch.

Useful mathematics must enter through existing semantic facts and Physical Reality:

1. establish the ValueFact / dependency identity;
2. prove the algebraic or causal property;
3. reduce necessary work, state, transport, communication, span, or physical realization cost;
4. realize the resulting Physical DAG directly;
5. delete the old route rather than preserving it as fallback compatibility.

## Current authority

- ValueFact identity and lifetime;
- Physical Reality cost and carrier competition;
- Physical DAG causality;
- affine/modulo canonical forms;
- composition-closed transition power;
- predicate persistence;
- transport sparsification;
- structural leaf geometry from work and outward-materialization price;
- target silicon profile and actual machine carrier geometry.

No runtime optimizer, work-stealing scheduler, global ready queue, workload dispatcher, C/LLVM backend or JIT is introduced.
