# Wheelchair 1.3.21 — Transport Sparsification Evidence

All measurements below are local validation evidence, not universal performance claims.

## Machine-work changes

| Probe | 1.3.20 hot instructions | 1.3.21 hot instructions | Arithmetic preserved |
|---|---:|---:|---|
| `chem6` | 89 | 59 | `vmulsd=15` |
| `ring8` | 82 | 42 | `vmulsd=8` |
| `mass3` | 85 | 85 | `vmulsd=18` |
| `rigid7` | 175 | 134 | `vmulsd=41` |
| `rigid7_cseprobe` | 151 | 98 | `vmulsd=38` |

The `chem6` steady-state loop contains no `movabs ds:` state-mailbox access after transport sparsification. State values recycle their old XMM authority when their final effective consumer has completed.

## Direct before/after timing samples

On the validation host, repeated whole-process samples gave approximately:

| Probe | 1.3.20 | 1.3.21 |
|---|---:|---:|
| `chem6`, 10M steps | 90.2 ms | 73.6 ms |
| `ring8`, 10M steps | 68.8 ms | 52.0 ms |
| `rigid7`, 5M steps | 74.6 ms | 61.0 ms |
| `rigid7_cseprobe`, 5M steps | 65.4 ms | 57.0 ms |

A multi-size linear fit for `chem6` measured about 7.40 ns/step after the change versus about 8.82 ns/step for 1.3.20. The same local C and Fortran references measured about 5.95 ns/step, so the remaining gap is no longer attributable to the deleted timestep state handoff.

## Architectural interpretation

The gain is attributed to eliminating physically unnecessary value transport, not to changing the numerical algorithm. The next remaining scalar frontier is constant realization, composite ValueFact reuse, and mature register scheduling; those are not claimed solved by this release.
