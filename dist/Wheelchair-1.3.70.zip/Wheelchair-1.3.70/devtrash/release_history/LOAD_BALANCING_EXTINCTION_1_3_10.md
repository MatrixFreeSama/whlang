# Wheelchair 1.3.10 Load-Balancing Extinction Record

The 1.3.9 source audit identified the remaining load-balancing family. 1.3.10 removes its production execution authority.

## Removed from Tensor/Field production execution

1. `id * chunks / P` static equal partition.
2. `(id + 1) * chunks / P` static equal partition.
3. strict `P * left_n / N` proportional capacity assignment.
4. executor-ID midpoint tree as work topology.
5. CPU-count-derived worker demand.
6. tolerant historical balanced-partition reduction authority.

## Replaced by

1. canonical causal chunk tree;
2. capacity ceiling only;
3. four-line anonymous credit fabric;
4. recipient-blind release;
5. donor-blind bounded claim;
6. no-spin failure path;
7. later claim opportunities only at later real causal expansion points.

## Explicit non-targets

The purge does not remove:

- General causal futex waits;
- compile-time topology queues;
- SIMD carrier scheduling;
- physical register scheduling;
- locality permission/profitability logic.

Those mechanisms do not exist to equalize runtime worker load.

## Source-language residue

Legacy `cascade ... executors N chunk M` annotations remain accepted only for source compatibility and are erased immediately. New cascade syntax may proceed directly to `axis`. These annotations do not request workers or steer runtime capacity.
