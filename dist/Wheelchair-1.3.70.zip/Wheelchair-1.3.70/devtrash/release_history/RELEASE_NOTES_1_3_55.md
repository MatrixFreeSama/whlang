# Wheelchair 1.3.55

Large architecture-aging release. No new language feature, mathematical algorithm family, scheduler, compatibility backend, or ISA route is added.

- removes the fixed General input/binding/state/output runtime record and lays out mutable storage from each AOT program instance;
- removes the fixed 512-KiB General generated-code slot and appends exact type/code metadata as a mapped executable trailer;
- premeasures iterate-state cardinality before image layout, so state storage follows the actual largest iterate relation;
- removes the historical 8-MiB fpP input stride and 1-MiB parser-object tier; decimal Rank-N ingress is sized directly from precision `P`;
- ages Field compiler graph and generated-code staging past the old 8192-op, 64-constant and 1-MiB compiler-only tiers;
- preserves existing Tensor, Field runtime and mathematical semantics rather than hiding their still-real boundaries.

The release gate crosses 40 General inputs/outputs, 81 iterate states, >512 KiB generated General code, 9000 Field operations and fp131073 decimal ingress. Mature Newton-Jv output remains byte-identical to 1.3.54.
