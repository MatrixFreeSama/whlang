# Wheelchair 1.3.16 Charter — Whole-Episode Physical DAG Strengthening

## Governing rule

**Merge and reuse first. Strengthen the old architecture before adding an abstraction. Delete a specialized path when the strengthened old path can carry its facts.**

A new simulation family is a structural probe, not a reason to create a new backend. Chemistry, rigid-body dynamics, constitutive models, control systems and recurrences do not receive named optimization paths. Their old-version values, operators, effects and next-version consumers enter the existing Rank-N / Axis / Operator / Region / Effect / Capability + Versioned Physical Reality + Physical DAG system.

## 1. Whole-episode authority

A simultaneous causal update set is one physical episode. Exact strict-order subtrees shared by multiple next-state expressions are one compile-time ValueFact, not independent expression-local calculations. Identity includes operation order, type and old-version inputs. There is no commutative canonicalization, reassociation, FMA substitution or numerical-contract relaxation.

## 2. One physical carrier authority

Persistent state, retained shared ValueFacts, immutable constants and anonymous temporaries must compete under the same compile-time XMM pressure authority. A profitable constant may lose residency when the proven anonymous temporary peak requires the carrier. Physical pressure may add a materialization, but it must not switch the entire episode to a generic stack backend.

## 3. Ready is not future

A selected future ValueFact does not become a physical source until it has actually been materialized. Ready-set authority is independent from candidate identity. This prevents a future subgraph from reading an uninitialized carrier merely because it has already been selected by AOT planning.

## 4. Retained facts form an antichain

A retained parent and its retained child must not both be materialized as independent episode facts. The retained set is a parent/child antichain in the exact Physical DAG. This prevents a CSE pass from recreating the duplicate work it was introduced to remove.

## 5. Blind release remains law

The final proven consumer ends a ValueFact lifetime. Its carrier is released immediately and without choosing the next recipient. No work stealing, global ready queue, recipient selection, occupancy target or runtime register allocator is introduced.

## 6. AOT only

Candidate discovery, structural equality, subtree topology, temporary-pressure proof, carrier retention and ready/future proof are compiler work. Generated programs contain no CSE cache, graph walker, ValueFact manager or register allocator.

## 7. Technical Peak Preservation Contract

1.3.13 register-native transition peaks, 1.3.14 unified VEX/constant physicalization and 1.3.15 Rank-N causal partial residency remain release obligations. Generalization may remove historical implementation shapes but may not flatten a proven machine-code peak without a stronger general realization.

## 8. Release definition

1.3.16 is complete only when:

- constant-pressure probes with two through eight distinct hot constants stay in the same register-native Physical DAG;
- shared quaternion-norm arithmetic is not duplicated across four simultaneous next-state expressions;
- unrelated chemistry, rigid-body and mechanical probes are bit-identical to strict references;
- no workload name appears in compiler/runtime dispatch;
- no artificial push/pop appears in admitted hot episodes;
- inherited 1.3.15 and earlier release authorities pass;
- clean-build, root and `bin/` native images are byte-identical;
- the release archive is internally SHA-256 verified after extraction.
