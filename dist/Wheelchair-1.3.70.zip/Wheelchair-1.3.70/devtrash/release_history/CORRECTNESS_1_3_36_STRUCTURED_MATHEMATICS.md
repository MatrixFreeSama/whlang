# Wheelchair 1.3.36 Structured Mathematics Correctness

The release gate `devtrash/release_tests/test_structured_mathematics_1336.sh` compiles every case through the normal `wheelchairc` `.wh` entry and executes the emitted native ELF.

Verified cases include complex magnitude, principal complex logarithm quadrant, principal complex square root, Cholesky, LDLT, inverse, matrix exponential/logarithm/square-root, symmetric eigensystem, SVD singular values, neutral structured component projection, and a chained structured-let Cholesky reconstruction.

The inherited precision-policy, native-mathematics and Rank-N release gates are mandatory dependencies of the final release gate.
