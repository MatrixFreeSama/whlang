# Wheelchair 1.3.56 performance and physical footprint

1.3.56 is an architecture-aging release, not a runtime-speed release.

## Static compiler storage

Representative production BSS, 1.3.55 -> 1.3.56:

| executable | 1.3.55 BSS | 1.3.56 BSS | reduction |
|---|---:|---:|---:|
| wheelchairc | 16,464 B | 11,984 B | 27.21% |
| topologyc | 8,518,992 B | 78,992 B | 99.07% |
| topologyc-derived | 8,567,056 B | 77,904 B | 99.09% |
| topologyc-native256 | 14,802,768 B | 77,456 B | 99.48% |
| topologyc-derived-native256 | 14,802,768 B | 77,520 B | 99.48% |
| fieldc | 8,457,040 B | 8,208 B | 99.90% |
| fieldc-native256 | 8,457,040 B | 8,208 B | 99.90% |

The eight production files total about 3.32 MB in both releases; dynamicization removes zero-filled virtual warehouses rather than merely optimizing compression.

## Build time

Five same-host full builds gave medians of roughly 0.77 s for the 1.3.55 release tree and 0.81 s for the 1.3.56 work tree. That is about a 5% build-time cost. The release does not present this noise/overhead as an acceleration.

## Generated execution

Mature Newton-Jv remains byte-identical to the protected baseline:

`bf099bc95653dd2ec72e780740c686b9cef3206e208af27569bf0999618549ac`

Therefore the structural runtime-speed change for that mature probe is exactly 0%. The benefit of 1.3.56 is capacity truth and dramatically smaller static compiler state, not a claimed faster Newton kernel.
