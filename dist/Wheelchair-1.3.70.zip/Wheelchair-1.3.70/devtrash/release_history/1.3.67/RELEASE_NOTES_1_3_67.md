# Wheelchair 1.3.67 release notes

1.3.67 is a transition-power aging release. It does not add a second recurrence optimizer. The 1.3.23 scalar wrap-u64 affine self-map has been deleted as a production authority and absorbed into one Rank-N affine closure over the published result's existing causal backward slice.

A counted recurrence may now prove its relevant simultaneous state update as `x' = A*x+b (mod 2^64)`. The state dimension is structural data. One native composition kernel realizes `F^N` by binary powering for every admitted dimension, including the old scalar case as `N=1`. There is no Fibonacci route, fixed state-count table, repetition threshold, fixed dimension family, runtime selector, JIT, autotuner, or compatibility scalar backend.

The compiler also converges runtime scratch ownership. Wide Rank-N floating temporaries and transition-power scratch now consume one compile-time exact runtime-temp allocator rather than separate subsystem counters.

The old two-state 500M recurrence from 1.3.12 now proves as a two-lane linear relation and changes from an `O(N)` emitted recurrence to `O(log N)` transform composition. Non-affine published slices still fall back to the ordinary causal DAG.

The current release gate is `devtrash/release_tests/test_transition_power_rankn_1367.sh`.
