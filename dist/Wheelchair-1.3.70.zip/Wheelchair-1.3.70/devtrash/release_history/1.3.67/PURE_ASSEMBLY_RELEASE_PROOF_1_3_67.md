# Pure assembly release proof 1.3.67

The production compiler/runtime path remains handwritten x86-64 assembly with direct static ELF emission. Rank-N transition-power aging adds no C/C++ backend, LLVM, MLIR, JIT, bytecode VM, runtime autotuner, Python compiler generator, or vendor code-generation layer.

The affine closure proof and coefficient materialization live in `compiler/general_frontend_x86_64.S`. The dimension-generic binary-composition kernel `rankn_affine_power_u64` lives in `runtime/general_runtime_template_x86_64.S`. Its virtual address is derived by the existing shell/native-ELF offset generator and called directly by generated native code.

The runtime helper is a mathematical execution kernel, not a selector or scheduler. All admission decisions, backward-slice construction, dimension discovery, affine proof and exact scratch sizing occur at AOT compile time.

`build.sh` reconstructs canonical production binaries from `compiler/`, `runtime/`, `surface/` and `tools/`. Python remains outside production build authority; the release test uses Python only as a validation byte scanner for generated-call evidence.

The generated `build/` workspace is excluded from the release archive after final production binaries are copied into `bin/`.
