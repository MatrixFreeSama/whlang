# Correctness: Wheelchair 1.3.67 Rank-N transition power

The 1.3.67 release gate verifies structural authority and execution semantics together.

Validated invariants include:

- the scalar transition collector and scalar power snippets are absent from production source;
- `PR_TRANSITION_POWER_RANKN_AFFINE_CLOSURE=1`, while scalar shadow authority, fixed dimensions, state-count routing, repetition thresholds and runtime selection remain zero;
- the historical one-state LCG keeps its previous wrap-u64 outputs through the same Rank-N mechanism;
- the historical 1.3.12 two-state recurrence produces exact known outputs at 10, 100 and 500,000,000 steps and contains a generated call to the native Rank-N power kernel;
- the existing eight-state coupled ring preserves historical outputs and enters the same power kernel without a state-count branch;
- a new three-data-state probe proves literal scaling, subtraction and bias over the relevant `x/y` slice while erasing an unrelated non-affine `z'=z*z+1` state;
- a genuinely non-affine published recurrence preserves its historical output and contains no generated call to the power kernel, proving ordinary causal-DAG fallback remains authoritative;
- English, Simplified Chinese, Traditional Chinese and mixed human-surface examples still compile to byte-identical ELF output, and damaged/clean auto-repair examples remain byte-identical;
- representative Automatic Grouping light/strength probes preserve their exact checksums on native512/native256 consumers, mature strict Newton-Jv remains bit exact on native512/native256, and strict Rank-3 neighborhood output agrees across derived native512/native256.

The generated-call check scans the emitted program bytes for the exact absolute call to `rankn_affine_power_u64`; merely finding the runtime symbol embedded in the ELF is not accepted as evidence.

`devtrash/release_tests/test_transition_power_rankn_1367.sh` is the current transition-power release gate.
