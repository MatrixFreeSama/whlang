# Wheelchair 1.3.67 performance note

1.3.67 changes the complexity of one proved recurrence family rather than trying to schedule the same `O(N)` loop more aggressively.

The diagnostic below uses the unchanged 1.3.12 two-state wrap-u64 source (`a'=b`, `b'=a+b`) on the current Intel Xeon Platinum 8272CL environment. All processes inherit affinity to CPU 0. GCC C uses `-O3 -march=native -flto`. Each point is an 11-run interleaved median, and all three executables produce identical output bits at every measured `N`.

| Steps | Wheelchair 1.3.66 | Wheelchair 1.3.67 | GCC C |
| ---: | ---: | ---: | ---: |
| 10,000,000 | 8.911 ms | 1.994 ms | 9.399 ms |
| 100,000,000 | 71.510 ms | 2.187 ms | 48.722 ms |
| 500,000,000 | 352.066 ms | 2.263 ms | 226.040 ms |

At 500M steps the measured whole-process time is about 155.6x lower than 1.3.66 and about 99.9x lower than this GCC C loop. This is not an instruction-throughput claim. The old Wheelchair and C programs still execute a linear recurrence, while 1.3.67 proves the same semantic relation as a two-lane transform and evaluates the exponent by binary composition.

A separate launch-floor probe of the 1.3.67 executable measured roughly 1.7 to 1.8 ms median from `N=0` through large `N`, so the new whole-process measurement is dominated by process/runtime startup on this host. It should therefore be read primarily as evidence that linear scaling disappeared, not as a portable 100x language-speed claim.

Raw interleaved measurements are retained under `devtrash/benchmarks/transition_power_1367/`.
