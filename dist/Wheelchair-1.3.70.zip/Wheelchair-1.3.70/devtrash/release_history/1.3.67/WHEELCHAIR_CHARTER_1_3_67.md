# Wheelchair Charter 1.3.67

- Transition power is a property of a proved composition-closed recurrence relation, not a named algorithm or workload.
- The published result grows its exact semantic backward slice before physicalization. Unrelated states perform no work for that result.
- A wrap-u64 affine slice is represented as one Rank-N relation `x' = A*x+b`; state cardinality is data, never a dispatch key.
- Scalar affine power is the one-lane degeneration of the Rank-N relation. No scalar compatibility backend remains.
- Affine proof and coefficient emission are one recursive traversal. A second AST matcher is not allowed to shadow the semantic authority.
- Repetition count changes exponent data only. No fixed repeat threshold decides whether transition power exists.
- Non-affine or otherwise unproved slices return to the ordinary causal DAG without approximation or a private fallback algorithm.
- Runtime scratch size is derived exactly at AOT time from the proved Rank-N relation and comes from the common runtime-temp authority.
- The native power kernel performs composition only. It is not a runtime scheduler, selector, autotuner, JIT, or work manager.
- Workload names, Fibonacci recognition, fixed dimensions, fixed state-count families, and compatibility routes are prohibited.
