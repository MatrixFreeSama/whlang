# Wheelchair 1.3.67 Transition Power aging

1.3.67 generalizes an old capability by deleting its scalar boundary rather than adding another optimizer family.

The canonical recurrence chain is now:

`published ValueFact -> causal backward state slice -> Rank-N affine relation -> Physical Reality -> native composition -> ISA`

## What was deleted

The production scalar collector `g_collect_u64_transition_affine` and its scalar `A/B` machine-code snippets are removed. The previous assumption that a powered published result must be an affine self-map of one state is gone. There is no retained scalar compatibility route beside the new implementation.

The old subsystem-specific runtime-temp counter is also removed. Runtime scratch ownership now has one compile-time allocator. Existing wide Rank-N floating allocation and transition-power allocation consume that same authority.

The superseded 1.3.23 transition-power release test and the 1.3.66 current-release gate are moved to `devtrash/release_history/` as evidence rather than active authority.

## What became canonical

The compiler starts from the published semantic state and computes a fixed-point backward slice through simultaneous update dependencies. Reachable states receive dense lanes only after the slice is closed. The same recursive traversal that proves affine structure emits coefficients into the relation

`x' = A*x+b (mod 2^64)`.

Nested addition, subtraction, and multiplication by compile-time literals are admitted by the common algebra. A sibling state is simply another basis lane. An unrelated state may be arbitrarily non-affine without poisoning the published result because it is outside the slice.

One handwritten native runtime kernel realizes every admitted dimension using binary composition. It receives an AOT-materialized state vector, matrix and bias plus the dynamic exponent. No state-count switch or dimension-specific body exists. For one state, the exact same mechanism degenerates to the historical scalar case.

If any reachable update is non-affine, the proof rewinds emitted code and exact scratch ownership, clears temporary slice facts, and returns to the existing ordinary causal-DAG recurrence path. Failure therefore does not create a second approximation family.

## Structural consequence

The historical Fibonacci-style two-state recurrence

`a'=b, b'=a+b`

is no longer treated as an irreducible 500M-step causal loop. Its two-lane relation is closed under composition, so `N` repeated applications are represented as `F^N`. This changes the execution depth from linear in the repeat count to logarithmic in the exponent without recognizing Fibonacci as a workload.

## Prohibitions preserved

No workload-name route, Fibonacci matcher, fixed state-count family, fixed dimension, repeat threshold, runtime selector, JIT/autotune, compatibility scalar backend, work stealing, or global scheduler is introduced.
