#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = 1.3.53 ]

had_build=0
[ -d build ] && had_build=1
cleanup() {
  rm -f /tmp/wheelchair_1353_build_$$.log
  if [ "$had_build" -eq 0 ] && [ "${ALLOW_BUILD_DIR:-0}" != 1 ]; then rm -rf build; fi
}
trap cleanup EXIT HUP INT TERM

./build.sh > /tmp/wheelchair_1353_build_$$.log 2>&1
grep -Fqx 'ADVANCED_MATH_OPTIONAL_ITERATION_AUTHORITY=PASS' /tmp/wheelchair_1353_build_$$.log
grep -Fqx 'NEW_ALGORITHM_FAMILIES_1_3_53=0' /tmp/wheelchair_1353_build_$$.log
grep -Fqx 'NEW_RUNTIME_SOLVER_AUTHORITIES_1_3_53=0' /tmp/wheelchair_1353_build_$$.log
grep -Fqx 'WHEELCHAIR_1_3_53_BUILD=PASS' /tmp/wheelchair_1353_build_$$.log

for t in \
 test_precision_policy_1334.sh \
 test_native_mathematics_1334.sh \
 test_rankn_mathematics_1334.sh \
 test_structured_mathematics_1336.sh \
 test_parametric_rankn_fp_1340.sh \
 test_rankn_precision_fourier_1340.sh \
 test_math_fusion_1341.sh \
 test_root_relation_1342.sh \
 test_root_precision_fusion_1343.sh \
 test_math_generalization_1344.sh \
 test_field_human_shell_1345.sh \
 test_field_human_shell_1346.sh \
 test_avx2_physical_ownership_1347.sh \
 test_valuefact_lifetime_1348.sh \
 test_tensor_physical_reality_137.sh \
 test_sparse_physical_materialization_1349.sh \
 test_human_surface_convergence_1350.sh \
 test_structural_capacity_convergence_1351.sh \
 test_field_locality_1217.sh \
 test_optional_iteration_convergence_1353.sh
do
  bash "devtrash/release_tests/$t" >/dev/null
done

# Preserve the 1.3.52 architecture-aging invariants without requiring a current
# release to impersonate the historical 1.3.52 build banner.
[ -f compiler/physical_reality.inc ]
[ ! -e compiler/physical_reality_136.inc ]
[ ! -e compiler/physical_reality_137.inc ]
[ ! -e compiler/physical_reality_138.inc ]
[ ! -e compiler/json_parser_x86_64.S ]
[ ! -e compiler/physical_vector_shapes.inc ]
[ ! -e tools/relink_native256_mature_128.sh ]
! find compiler runtime tools surface -type f -name '*138*' -print | grep -q .
! grep -RniE '\b(PR|T)138_|physical_reality_138|tensor_(derived_)?frontend_138|tensor_runtime_138' compiler runtime tools surface >/dev/null 2>&1
! grep -Rni 'devtrash/' compiler runtime tools surface >/dev/null 2>&1
[ ! -e build/topologyc-wide ]
[ ! -e build/topologyc-wide-native256 ]
[ ! -e bin/topologyc-wide ]
[ ! -e bin/topologyc-wide-native256 ]

for f in \
 README.md RELEASE_NOTES_1_3_53.md ITERATION_CONTROL_CONVERGENCE_1_3_53.md \
 CORRECTNESS_1_3_53_OPTIONAL_ITERATION.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_53.md \
 WHEELCHAIR_CHARTER_1_3_53.md; do
  [ -s "$f" ]
done

for f in wheelchairc whexc topologyc topologyc-derived topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  [ -x "bin/$f" ]
  ! readelf -l "bin/$f" | grep -q 'INTERP'
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 8 ]

echo 'WHEELCHAIR_1_3_53_FINAL_RELEASE=PASS'
