#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
./build.sh >/dev/null
bash devtrash/release_tests/test_precision_propagation_1331.sh
bash devtrash/release_tests/test_low_precision_contagion_1330.sh
bash devtrash/release_tests/test_rankn_contraction_1331.sh
./bin/whexc surface/examples/lcg64_iterate_wrap.wh -o /tmp/wheelchair_1331_lcg >/dev/null
[ "$(/tmp/wheelchair_1331_lcg 42 10)" = 'out00_bits=0x06593f7b1358c594' ]
echo WHEELCHAIR_1_3_31_FINAL_RELEASE=PASS
