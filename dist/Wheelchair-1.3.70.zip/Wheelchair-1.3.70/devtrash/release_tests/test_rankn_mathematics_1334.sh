#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
cat >"$TMP/stats.whex" <<'SRC'
program stats
strict
input n: u64 range 1..1
field A[b in n, k in 4]: f64 = cast(f64, k+1)
field M[b in n]: f64 = mean(k in 4, A[b,k])
field N[b in n]: f64 = norm(k in 4, A[b,k])
field V[b in n]: f64 = variance(k in 4, A[b,k])
sum checksum[b in n]: f64 = M[b] + N[b] + V[b]
output checksum
SRC
for C in topologyc-derived topologyc-derived-native256; do
  CC="$ROOT/build/$C"
  [ -x "$CC" ] || CC="$ROOT/bin/$C"
  "$CC" "$TMP/stats.whex" -o "$TMP/$C" >/dev/null
  [ "$("$TMP/$C" 1)" = 'checksum_bits=0x40227456e91b52c8' ]
done
bash "$ROOT/devtrash/release_tests/test_rankn_contraction_1331.sh" >/dev/null
echo RANKN_MATHEMATICS_1_3_34=PASS
