#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT INT TERM

# Source-structure authority: generic coordinate algebra, no workload-name dispatch.
grep -q '^s_rankn_dynamic_affine_mod:' compiler/surface_lowerer_x86_64.S
grep -q 'Rank-N coordinate algebra' compiler/surface_lowerer_x86_64.S
grep -q 'tensor_domain_min' devtrash/frozen_native/generated_derived/tensor_derived_frontend_x86_64.S
grep -q 'tensor_domain_min' devtrash/frozen_native/generated_native256/tensor_frontend_derived_native256.S
! grep -Eq 'Taichi|elasticity|rank3_neighborhood_periodic_1215|rank3_local_operator_1215' compiler/surface_lowerer_x86_64.S

echo 'RANKN_COORDINATE_ALGEBRA=PASS'
echo 'NEIGHBORHOOD_WORKLOAD_DISPATCH=0'

check_out() {
  exe=$1; n=$2; expected=$3
  got=$($exe "$n")
  [ "$got" = "$expected" ] || {
    echo "numeric mismatch: $exe n=$n got=$got expected=$expected" >&2
    exit 1
  }
}

# Generic driver path must select the derived Rank-N authority and preserve values.
for q in 1 2 4; do
  build/whexc devtrash/tests/whex/rank3_neighborhood_periodic_1215.whex -o "$T/p$q" >/dev/null
  check_out "$T/p$q" 4 checksum_bits=0x4103800000000000
  check_out "$T/p$q" 5 checksum_bits=0x411a024800000000
  check_out "$T/p$q" 7 checksum_bits=0x4140ae8500000000

  build/whexc devtrash/tests/whex/rank3_neighborhood_negative_1215.whex -o "$T/m$q" >/dev/null
  check_out "$T/m$q" 4 checksum_bits=0x4103800000000000
  check_out "$T/m$q" 5 checksum_bits=0x41202da400000000
  check_out "$T/m$q" 7 checksum_bits=0x41463c6500000000

done
echo 'RANKN_DYNAMIC_PERIODIC_RADIUS=PASS'

build/whexc devtrash/tests/whex/rank3_neighborhood_clamp_1215.whex -o "$T/clamp" >/dev/null
check_out "$T/clamp" 4 checksum_bits=0x411ce40000000000
check_out "$T/clamp" 5 checksum_bits=0x4133487200000000
check_out "$T/clamp" 7 checksum_bits=0x4154559280000000
echo 'RANKN_DATAIZED_BOUNDARY_TRANSFORM=PASS'

build/whexc devtrash/tests/whex/rank3_neighborhood_strict_1215.whex -o "$T/strict" >/dev/null
check_out "$T/strict" 4 checksum_bits=0x40b3900000000000
check_out "$T/strict" 5 checksum_bits=0x40c0220000000000
check_out "$T/strict" 7 checksum_bits=0x40d0c30000000000
echo 'RANKN_NEIGHBORHOOD_STRICT_FP=PASS'

# Rank is not special-cased to 3. A six-axis product with four simultaneous
# transformed coordinates must survive both native512 and native256 realizers.
for backend in build/topologyc-derived build/topologyc-derived-native256; do
  name=$(basename "$backend")
  "$backend" devtrash/tests/whex/rank6_neighborhood_1215.whex -o "$T/r6_$name" >/dev/null
  check_out "$T/r6_$name" 4 checksum_bits=0x4110a28000000000
  check_out "$T/r6_$name" 5 checksum_bits=0x412176a000000000
  check_out "$T/r6_$name" 7 checksum_bits=0x4140680000000000

  "$backend" devtrash/tests/whex/rank3_local_operator_1215.whex -o "$T/local_$name" >/dev/null
  check_out "$T/local_$name" 4 checksum_bits=0x4121b4a000000000
  check_out "$T/local_$name" 5 checksum_bits=0x4132ec7400000000
  check_out "$T/local_$name" 7 checksum_bits=0x414d148e00000000
done
echo 'RANK6_NEIGHBORHOOD_GENERICITY=PASS'
echo 'MULTIFIELD_LOCAL_OPERATOR=PASS'
echo 'NATIVE256_NEIGHBORHOOD_EQUIVALENCE=PASS'

# The upgrade must not fake deeper ABI/type capabilities. These remain explicit
# frontiers rather than silent widening, scalar fallback, or benchmark wrappers.
cat > "$T/two_dynamic.whex" <<'SRC'
program two_dynamic_frontier
strict
input n: u64 range 4..64
sum checksum[i in n, j in n, k in 4]: f64 = cast(f64, i + j + k)
output checksum
test (4) => { checksum = 0.0 }
SRC
if build/whexc "$T/two_dynamic.whex" -o "$T/two_dynamic" >/dev/null 2>&1; then
  echo 'unexpected multi-dynamic admission' >&2; exit 1
fi
cat > "$T/f32_rankn.whex" <<'SRC'
program f32_rankn_frontier
strict
input n: u64 range 4..64
field x[i in n, j in 2, k in 4]: f32 = cast(f32, i + j + k)
sum checksum[i in n, j in 2, k in 4]: f32 = x[i,j,k]
output checksum
test (4) => { checksum = 0.0 }
SRC
if build/whexc "$T/f32_rankn.whex" -o "$T/f32_rankn" >/dev/null 2>&1; then
  echo 'unexpected f32 tensor admission' >&2; exit 1
fi
echo 'MULTI_DYNAMIC_EXTENT_FRONTIER=EXPLICIT_REJECT'
echo 'F32_RANKN_FRONTIER=EXPLICIT_REJECT'

echo 'RANKN_NEIGHBORHOOD_SEMANTICS_1_2_15=PASS'
