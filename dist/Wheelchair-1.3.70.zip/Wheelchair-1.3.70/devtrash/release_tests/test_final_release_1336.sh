#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = '1.3.36' ]
bash devtrash/release_tests/test_precision_policy_1334.sh
bash devtrash/release_tests/test_native_mathematics_1334.sh
bash devtrash/release_tests/test_rankn_mathematics_1334.sh
bash devtrash/release_tests/test_structured_mathematics_1336.sh
grep -q 'Parasite old architecture first' WHEELCHAIR_CHARTER_1_3_36.md
grep -q 'Strengthen old architecture second' WHEELCHAIR_CHARTER_1_3_36.md
grep -q 'New architecture is last resort' WHEELCHAIR_CHARTER_1_3_36.md
grep -q 'WHEELCHAIR_1_3_36_BUILD=PASS' build.sh
[ -x bin/wheelchairc ]
echo WHEELCHAIR_1_3_36_FINAL_RELEASE=PASS
