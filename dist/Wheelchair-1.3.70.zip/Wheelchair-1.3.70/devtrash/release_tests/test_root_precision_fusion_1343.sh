#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

# One P>64 numeric-comparison authority.  Comparisons must see represented
# numbers, never carrier pointers or a named precision route.
cat >"$T/cmp.wh" <<'SRC'
program fp_compare_authority
precision_propagation 1
let a = cast(fp127, -2)
let b = cast(fp127, -1)
let z = cast(fp127, 0)
let d = cast(fp127, 3)
output q0 = a < b
output q1 = b < z
output q2 = z < d
output q3 = d > a
output q4 = a == a
output q5 = b != d
SRC
"$CC" "$T/cmp.wh" -o "$T/cmp" >/dev/null
[ "$("$T/cmp")" = $'out00_bits=0x0000000000000001\nout01_bits=0x0000000000000001\nout02_bits=0x0000000000000001\nout03_bits=0x0000000000000001\nout04_bits=0x0000000000000001\nout05_bits=0x0000000000000001' ]

# The AOT packed geometry sits next to n64 in the Fourier local frame.  Dense
# significands produced by division exercise the final cross-limb digit and
# therefore guard the exact 32-bit n64 boundary that used to read geometry as
# its upper half.  This is one physical-width fix, not a precision exception.
for p in 127 191; do
cat >"$T/dense_$p.wh" <<SRC
program dense_$p
precision_propagation 1
let a = cast(fp$p, 17)
let b = cast(fp$p, 12)
let x = a / b
let y = x * x
output y = y
SRC
"$CC" "$T/dense_$p.wh" -o "$T/dense_$p" >/dev/null
done

# The same RootRelation must stay in its current fpP carrier.  No output cast,
# root-width fork or f64 tolerance is allowed.  Nine generations are enough for
# these three unrelated precisions and produce exact RNE sqrt(2) significands.
for p in 65 127 521; do
cat >"$T/root_$p.wh" <<SRC
program root_$p
precision_propagation 1
let one = cast(fp$p, 1)
let two = cast(fp$p, 2)
let r = root(x, x*x - two, one, 9)
let valid = root_valid(r)
let re = real(r)
let im = imag(r)
output valid = valid
output re = re
output im = im
SRC
"$CC" "$T/root_$p.wh" -o "$T/root_$p" >/dev/null
done

python3 - "$T" <<'PY'
from decimal import Decimal, getcontext, ROUND_HALF_EVEN
from fractions import Fraction
from pathlib import Path
import subprocess, sys
T=Path(sys.argv[1])

def parse(line):
    key,val=line.strip().split('=',1)
    if not key.endswith('_rankn_fp'):
        raise SystemExit(f'not wide: {line}')
    typ,sign,exp,n,sig=val[2:].split(':')
    return int(typ,16),int(sign,16),int(exp,16),int(n,16),int(sig,16)

def round_even(fr):
    q,r=divmod(fr.numerator,fr.denominator)
    t=2*r
    if t>fr.denominator or (t==fr.denominator and (q&1)): q+=1
    return q

def canon(fr,p):
    sign=int(fr<0); fr=abs(fr)
    if fr == 0: return sign,0,0
    n,d=fr.numerator,fr.denominator
    e=n.bit_length()-d.bit_length()
    if e>=0:
        if n < (d<<e): e-=1
    elif (n<<(-e)) < d: e-=1
    shift=p-1-e
    scaled=fr*(1<<shift) if shift>=0 else fr/Fraction(1<<(-shift),1)
    q=round_even(scaled)
    if q==(1<<p): q>>=1; e+=1
    return sign,e,q

for p in (127,191):
    got=subprocess.check_output([str(T/f'dense_{p}')],text=True).strip()
    typ,sg,ee,nl,sig=parse(got)
    # x is first rounded to fpP by division, then that represented x is squared.
    xs,xe,xq=canon(Fraction(17,12),p)
    xfr=Fraction(xq,1 << (p-1-xe)) if (p-1-xe)>=0 else Fraction(xq << (xe-(p-1)),1)
    es,ex,eq=canon(xfr*xfr,p)
    assert typ==(0x40000000|p) and sg==es and ee==(ex & ((1<<64)-1)) and sig==eq,(p,got,hex(eq))

for p in (65,127,521):
    lines=subprocess.check_output([str(T/f'root_{p}')],text=True).splitlines()
    assert lines[0]=='out00_bits=0x0000000000000001',(p,lines)
    typ,sg,ee,nl,sig=parse(lines[1])
    t2,sg2,ee2,nl2,sig2=parse(lines[2])
    getcontext().prec=max(100,int(p*0.31)+60)
    expected=int((Decimal(2).sqrt()*(Decimal(2)**(p-1))).to_integral_value(rounding=ROUND_HALF_EVEN))
    assert typ==(0x40000000|p) and sg==0 and ee==0 and sig==expected,(p,hex(sig),hex(expected))
    assert t2==(0x40000000|p) and sg2==0 and ee2==0 and sig2==0,(p,lines[2])
print('ROOT_PRECISION_RNE_ORACLE_1_3_43=PASS')
PY

R="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
G="$ROOT/compiler/general_frontend_x86_64.S"
S="$ROOT/compiler/surface_lowerer_x86_64.S"
O="$ROOT/tools/generate_general_runtime_offsets.sh"
grep -q '^\.global rankn_fp_cmp$' "$R"
[ "$(grep -c '^rankn_fp_cmp:' "$R")" -eq 1 ]
grep -q 'cmp r10d,dword ptr \[rsp+40\]' "$R"
grep -q '^g_emit_rankn_fp_compare_top2:' "$G"
grep -q 'GENERAL_RANKN_FP_CMP_VA' "$G"
grep -q 'va_rankn_cmp=$(need rankn_fp_cmp)' "$O"
grep -q '^s_root_negligible_ast:' "$S"
grep -q '^s_root_nonzero_ast:' "$S"
grep -q '^s_root_zero_const:' "$S"
grep -q 'representation-stability' "$S"
! grep -RIEqi --include='*.S' --include='*.inc' 'root_fp(65|73|127|128|191|256|257|521)|fp(65|73|127|128|191|256|257|521)_root|root_width_selector|root_precision_selector' "$ROOT/compiler" "$ROOT/runtime"
! grep -Eq '0x3cb0000000000000|0x7fefffffffffffff' "$S"

echo ROOT_PRECISION_FUSION_1_3_43=PASS
