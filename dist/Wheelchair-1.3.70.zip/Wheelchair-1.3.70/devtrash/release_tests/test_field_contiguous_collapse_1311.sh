#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1311_field_$$
mkdir -p "$T/canon_q1" "$T/canon_q4" "$T/whex_q1" "$T/whex_q4"
trap 'rm -rf "$T"' EXIT HUP INT TERM

# Structural source authority. The proof is Rank-N, residency is reuse-weighted,
# and the fourth logical Field carrier is part of the same canonical AOT graph.
grep -q '1.3.11 Rank-N contiguous physical proof' runtime/field_runtime_512_x86_64.S
grep -q '1.3.11 Rank-N contiguous physical proof' runtime/field_runtime_256_x86_64.S
grep -q '^\.equ FF_VREG_COUNT,4' compiler/field_frontend_common_x86_64.S
grep -q '^\.equ FF_VREG_MAX,3' compiler/field_frontend_common_x86_64.S
grep -q 'cmp eax,4; ja .sfh_co_fail' compiler/field_surface_lowerer_x86_64.inc
grep -q 'mov r8d,3; call sfh_compile_node' compiler/field_surface_lowerer_x86_64.inc
! grep -Eq 'CVRD3D|cvrd3d' compiler/field_frontend_common_x86_64.S compiler/field_surface_lowerer_x86_64.inc runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S

echo 'FIELD_RANKN_ROW_PROOF=PASS'
echo 'NON_POWER2_REDUNDANT_AXIS_DIVISION=REMOVED'
echo 'AVX512_REUSE_WEIGHTED_NEIGHBOR_RESIDENCY=PASS'
echo 'FIELD_FLOATING_LOGICAL_REGISTERS=4'
echo 'NO_CVRD3D_SPECIALIZATION=PASS'

# The human WHEX surface must compile a high-pressure four-register expression
# directly into the same canonical Field backend. No expression interpreter is
# admitted at runtime.
F=devtrash/tests/field_complex_surface_1311
build/fieldc "$F/complex.json" -o "$T/canon1" >/dev/null
build/fieldc "$F/complex.json" -o "$T/canon4" >/dev/null
build/fieldc "$F/complex.whex" -o "$T/whex1" >/dev/null
build/fieldc "$F/complex.whex" -o "$T/whex4" >/dev/null

run_case() {
  bin=$1; od=$2
  for o in ru rv rw; do cp "$F/data32/$o.whfld" "$od/$o.whfld"; done
  "$bin" \
    "$F/data32/u.whfld" "$F/data32/v.whfld" "$F/data32/w.whfld" \
    "$F/data32/kappa.whfld" "$F/data32/beta.whfld" \
    "$od/ru.whfld" "$od/rv.whfld" "$od/rw.whfld"
}

c1=$(run_case "$T/canon1" "$T/canon_q1")
c4=$(run_case "$T/canon4" "$T/canon_q4")
w1=$(run_case "$T/whex1" "$T/whex_q1")
w4=$(run_case "$T/whex4" "$T/whex_q4")
case "$c1" in checksum_f32_bits=0x*) ;; *) exit 1 ;; esac
[ "$c4" = "$c1" ]
case "$w1" in checksum_f32_bits=0x*) ;; *) exit 1 ;; esac
[ "$w4" = "$w1" ]

echo 'WHEX_COMPLEX_FIELD_SURFACE=PASS'
echo 'WHEX_COMPLEX_FIELD_CAPACITY_INDEPENDENT=PASS'
echo 'CANONICAL_COMPLEX_FIELD_CAPACITY_INDEPENDENT=PASS'
echo 'WHEX_COMPLEX_FIELD_RUNTIME_INTERPRETER=0'

# 1.3.10 execution philosophy is immutable under this Field-local optimization.
bash devtrash/release_tests/test_blind_surplus_reflow_1310.sh >/dev/null
echo 'BLIND_SURPLUS_REFLOW_PRESERVED=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'PEER_LOAD_OBSERVATION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'

echo 'FORCED_GENERIC_FMA=REJECTED_BY_PHYSICAL_PROFITABILITY'
echo 'WHEELCHAIR_FIELD_CONTIGUOUS_COLLAPSE_1_3_11=PASS'
