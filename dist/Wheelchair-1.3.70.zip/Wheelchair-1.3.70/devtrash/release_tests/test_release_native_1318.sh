#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

rm -rf build
./build.sh > .release_build_1318.log 2>&1
for marker in \
 WHEELCHAIR_1_3_17_BUILD=PASS \
 EMERGENT_OUTWARD_EXPANSION_1_3_18=BUILT \
 READY_EQUALS_MUST_CLONE=0 \
 EXPANSION_WORKSIZE_MAGIC_THRESHOLD=0 \
 RUNTIME_RESOURCE_AVAILABILITY_EXPANSION_QUERY=0 \
 RUNTIME_CPU_COUNT_EXPANSION_SELECTOR=0 \
 AOT_OUTWARD_MATERIALIZATION_TARGET_PROFILE=BUILT \
 AOT_LOCAL_WORK_PHYSICAL_COST=BUILT \
 LOCAL_VS_OUTWARD=PHYSICAL_REALIZATION_PROFITABILITY \
 TENSOR_LOCAL_CANONICAL_TREE=BUILT FIELD_LOCAL_CANONICAL_TREE=BUILT \
 STRICT_REDUCTION_TREE_PRESERVED=1 \
 INTERNAL_EXECUTION_CAPACITY_ACCOUNTING=0 \
 CREDIT_BITMAP=0 CAPACITY_CLAIM=0 CAPACITY_RELEASE=0 \
 RUNTIME_CPU_PINNING=0 WORK_STEALING=0 GLOBAL_READY_QUEUE=0 RESOURCE_RECIPIENT_SELECTION=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_18_BUILD=PASS
 do grep -q "^$marker$" .release_build_1318.log; done

echo 'BUILD_1_3_18_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_release_native_1317.sh >/dev/null
echo 'COMPLETE_1_3_17_RELEASE_AUTHORITY_PRESERVED=PASS'
devtrash/release_tests/test_emergent_outward_expansion_1318.sh

for f in \
 build/topologyc build/topologyc build/topologyc-derived \
 build/topologyc-native256 build/topologyc-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

# Current production and frozen-current authorities cannot regenerate the retired
# silicon pool or a magic expansion threshold.
if grep -R -n -E '^(try_claim_credit:|release_credit:)|g_credit_lines|g_capacity_ceiling|^pin_cpu:|SYS_sched_setaffinity' \
  runtime compiler devtrash/frozen_native --include='*.S' >/dev/null 2>&1; then
  echo 'INTERNAL_SILICON_OWNERSHIP_LEAK=FAIL' >&2; exit 1
fi
if grep -R -n -E 'EXPAND(_|)THRESHOLD|CLONE(_|)THRESHOLD|MIN(_|)GRAIN|MIN(_|)CHUNKS|MIN(_|)WORK(_|)FOR(_|)CLONE' \
  runtime compiler --include='*.S' >/dev/null 2>&1; then
  echo 'HARDCODED_EXPANSION_THRESHOLD=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_18.md RELEASE_NOTES_1_3_18.md RELEASE_GATES_1_3_18.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_18.md PERFORMANCE_1_3_18_EMERGENT_EXPANSION.md \
 PERFORMANCE_1_3_18_RESOURCE_AB.csv devtrash/tests/whex/emergent_light_reduction_1318.whex \
 test_emergent_outward_expansion_1318.sh test_release_native_1318.sh
 do test -s "$f"; done

echo 'READY_EQUALS_MUST_CLONE=0'
echo 'HARDCODED_EXPANSION_THRESHOLD=0'
echo 'NO_INTERNAL_SILICON_POOL=PASS'
echo 'NO_RUNTIME_RESOURCE_AVAILABILITY_QUERY=PASS'
echo 'STRICT_CANONICAL_TREE_PRESERVED=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_18_RELEASE=PASS'
