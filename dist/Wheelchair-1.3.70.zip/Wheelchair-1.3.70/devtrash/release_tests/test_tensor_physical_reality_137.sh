#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
./devtrash/release_tests/test_sparse_physical_materialization_1349.sh >/dev/null
# Core 1.3.7 semantic invariants remain explicit even though its profile
# implementation has been aged into the unified 1.3.49 authority.
grep -q '^\.equ PR_RUNTIME_FACT_MANAGER,0$' compiler/physical_reality.inc
grep -q '^\.equ PR_RUNTIME_RESIDENCY_MANAGER,0$' compiler/physical_reality.inc
grep -q '^\.equ PR_RUNTIME_AUTOTUNE,0$' compiler/physical_reality.inc
grep -q '^\.equ PR_GLOBAL_READY_QUEUE,0$' compiler/physical_reality.inc
grep -q '^\.equ PR_WORK_STEALING,0$' compiler/physical_reality.inc
grep -q '^\.equ PR_RESOURCE_RECIPIENT_SELECTION,0$' compiler/physical_reality.inc
echo TENSOR_1_3_7_SEMANTIC_AUTHORITY_AGED_INTO_1_3_49=PASS
