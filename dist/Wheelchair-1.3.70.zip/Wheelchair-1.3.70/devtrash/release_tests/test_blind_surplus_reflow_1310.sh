#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1310_reflow_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'BLIND_REFLOW_INVARIANTS_SUPERSEDED_CLEANLY=PASS'

RUNTIMES="
runtime/tensor_runtime_x86_64.S
runtime/field_runtime_512_x86_64.S
runtime/field_runtime_256_x86_64.S
devtrash/frozen_native/generated_derived/tensor_derived_runtime_template_x86_64.S
devtrash/frozen_native/generated_native256/tensor_runtime_native256_template_x86_64.S
devtrash/frozen_native/generated_native256/tensor_derived_runtime_native256_template_x86_64.S
"
for S in $RUNTIMES; do
  grep -q '^run_causal_tree:' "$S"
  grep -q 'SYS_clone' "$S"
  grep -q 'SYS_wait4' "$S"
  grep -q '^run_causal_tree_local:' "$S"
  grep -q 'outward_materialization_ticks_patch' "$S"
  ! grep -q '^try_claim_credit:' "$S"
  ! grep -q '^release_credit:' "$S"
  ! grep -q 'g_credit_lines' "$S"
  ! grep -q 'g_capacity_ceiling' "$S"
  ! grep -q '^pin_cpu:' "$S"
  ! grep -q 'lock btr' "$S"
  ! grep -q 'lock bts' "$S"
done
echo 'INTERNAL_CREDIT_FABRIC=0'
echo 'RUNTIME_CPU_PINNING=0'
echo 'READY_WORK_LOCAL_OR_OUTWARD_BY_PHYSICAL_PROFITABILITY=PASS'

! grep -q 'SYS_futex' runtime/general_parallel_release_x86_64.S
! grep -q '^gr_run_node_tree:' runtime/general_parallel_release_x86_64.S
grep -q '^gr_materialize_node:' runtime/general_parallel_release_x86_64.S
grep -Fq 'lock xadd dword ptr [rdi],eax' runtime/general_parallel_release_x86_64.S
grep -q 'CLONE_OUTWARD_SUCCESSOR' runtime/general_parallel_release_x86_64.S
echo 'GENERAL_PRECREATED_FUTURE_EXECUTORS=0'
echo 'GENERAL_TRUE_JOIN_ONLY_ATOMIC=PASS'

# Compatibility --executors values may still be accepted by image format, but
# cannot create/suppress semantic work or change the canonical result.
SRC=devtrash/tests/whex/strength_probe.whex
build/topologyc "$SRC" -o "$T/q1" >/dev/null
build/topologyc "$SRC" -o "$T/q256" >/dev/null
[ "$("$T/q1" 1)" = "$("$T/q256" 1)" ]
[ "$("$T/q1" 100000)" = "$("$T/q256" 100000)" ]
echo 'LEGACY_EXECUTOR_FIELD_DOES_NOT_OWN_SILICON=PASS'

if grep -R -n -E 'global_surplus_counter|worker_load\[|queue_length\[|idle_worker_list|busy_worker_list|victim_selection|donor_selection|work[ -]?steal' \
  runtime compiler devtrash/frozen_native --include='*.S' --include='*.inc' > "$T/forbidden" 2>/dev/null; then
  cat "$T/forbidden" >&2; exit 1
fi

echo 'WORK_STEALING=0'
echo 'PUSH_BALANCING=0'
echo 'PULL_BALANCING=0'
echo 'RESOURCE_RELEASE_IS_RECIPIENT_BLIND=1'
echo 'RESOURCE_ACQUISITION_IS_DONOR_BLIND=SUPERSEDED_BY_NO_INTERNAL_ACQUISITION'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_BLIND_SURPLUS_REFLOW_1_3_10=PASS'
