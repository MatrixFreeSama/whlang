#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
one() {
  local name=$1 expr=$2 bits=$3
  cat >"$TMP/$name.wh" <<SRC
program math_$name
let x: f64 = $expr
output x = x
SRC
  "$CC" "$TMP/$name.wh" -o "$TMP/$name" >/dev/null
  [ "$("$TMP/$name")" = "out00_bits=$bits" ]
}
one sin 'sin(1.0)' 0x3feaed548f090cee
one exp 'exp(1.0)' 0x4005bf0a8b145769
one log 'log(2.0)' 0x3fe62e42fefa39ef
one gamma 'gamma(5.0)' 0x4037fffffffffff6
one lambertw 'lambertw(1.0)' 0x3fe22609af8e9658
one zeta 'zeta(2)' 0x3ffa51a6625307d3
one elliptick 'elliptic_k(0.5)' 0x3ffdaa4a35759e4a
one elliptice 'elliptic_e(0.5)' 0x3ff59c3cc21a46c7
one det3 'det3(1.0,2.0,3.0,0.0,1.0,4.0,5.0,6.0,0.0)' 0x3ff0000000000000
one factorial 'factorial(5.0)' 0x405e000000000016
cat >"$TMP/derivative.wh" <<'SRC'
program derivative_native
input x: f64
let y: f64 = derivative(sin(x), x)
output y = y
SRC
"$CC" "$TMP/derivative.wh" -o "$TMP/derivative" >/dev/null
[ "$("$TMP/derivative" 1.0)" = 'out00_bits=0x3fe14a280fb5068c' ]
cat >"$TMP/integral.wh" <<'SRC'
program integral_native
let y: f64 = integral(x, 0.0, 1.0, x*x)
output y = y
SRC
"$CC" "$TMP/integral.wh" -o "$TMP/integral" >/dev/null
[ "$("$TMP/integral")" = 'out00_bits=0x3fd5555555555556' ]
cat >"$TMP/root.wh" <<'SRC'
program root_native
let y: f64 = real(root(x, x*x - 2.0, 1.0))
output y = y
SRC
"$CC" "$TMP/root.wh" -o "$TMP/root" >/dev/null
[ "$("$TMP/root")" = 'out00_bits=0x3ff6a09e667f3bcc' ]
# Registry/architecture invariants: math expands or becomes ValueFacts; no libm/runtime subsystem.
! grep -RIl --include='*.S' --include='*.inc' 'call.*\<sin\>\|call.*\<cos\>\|call.*\<exp\>\|call.*\<log\>' "$ROOT/compiler" >/dev/null 2>&1 || exit 1
grep -q 's_math_builtin_table:' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q 'MB_DET3' "$ROOT/compiler/surface_lowerer_x86_64.S"
echo NATIVE_MATHEMATICS_1_3_34=PASS
