#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
HAD_BUILD=0
[ -d "$ROOT/build" ] && HAD_BUILD=1

for t in \
 test_precision_policy_1334.sh \
 test_native_mathematics_1334.sh \
 test_rankn_mathematics_1334.sh \
 test_structured_mathematics_1336.sh \
 test_parametric_rankn_fp_1340.sh \
 test_rankn_precision_fourier_1340.sh \
 test_math_fusion_1341.sh \
 test_root_relation_1342.sh \
 test_root_precision_fusion_1343.sh \
 test_math_generalization_1344.sh \
 test_field_human_shell_1345.sh \
 test_field_human_shell_1346.sh \
 test_avx2_physical_ownership_1347.sh \
 test_valuefact_lifetime_1348.sh \
 test_tensor_physical_reality_137.sh \
 test_sparse_physical_materialization_1349.sh \
 test_human_surface_convergence_1350.sh; do
  "$ROOT/devtrash/release_tests/$t" >/dev/null
done

"$ROOT/devtrash/release_tests/test_field_locality_1217.sh" >/dev/null

grep -q '^1\.3\.50$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_50_BUILD=PASS' "$ROOT/build.sh"
grep -q 'HUMAN_SURFACE_CONVERGENCE_1_3_50=BUILT' "$ROOT/build.sh"
grep -q '^# Wheelchair 1\.3\.50' "$ROOT/README.md"
for f in \
 RELEASE_NOTES_1_3_50.md HUMAN_SURFACE_CONVERGENCE_1_3_50.md \
 CORRECTNESS_1_3_50_HUMAN_SURFACE_CONVERGENCE.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_50.md WHEELCHAIR_CHARTER_1_3_50.md; do
  [ -s "$ROOT/$f" ]
done
[ -s "$ROOT/devtrash/release_history/1.3.49/RELEASE_NOTES_1_3_49.md" ]

[ ! -e "$ROOT/bin/topologyc" ]
[ ! -e "$ROOT/bin/topologyc-native256" ]

for f in \
 "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc" "$ROOT/bin/fieldc" \
 "$ROOT/bin/fieldc-native256" "$ROOT/bin/topologyc" "$ROOT/bin/topologyc-native256"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

if find "$ROOT/compiler" "$ROOT/runtime" -type f \( -name '*.py' -o -name '*.pyc' \) 2>/dev/null | grep -q .; then
  echo PYTHON_PRODUCTION_GENERATOR=FAIL >&2; exit 1
fi

# In a packaged tree the inherited gates may create build/ transiently.  Restore
# the tree to its entry state rather than forcing release users to keep debris.
if [ "$HAD_BUILD" = 0 ]; then
  rm -rf "$ROOT/build"
fi
[ ! -d "$ROOT/build" ] || [ "${ALLOW_BUILD_DIR:-0}" = 1 ]
echo WHEELCHAIR_1_3_50_FINAL_RELEASE=PASS
