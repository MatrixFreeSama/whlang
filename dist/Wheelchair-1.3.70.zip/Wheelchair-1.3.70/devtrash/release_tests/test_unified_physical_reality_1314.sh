#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1314_unified_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality.inc
TF=compiler/tensor_frontend_x86_64.S
FF=compiler/field_frontend_common_x86_64.S

# One compiler-wide Physical Reality vocabulary, not one backend per workload.
test -s "$P"
grep -q 'physical_reality_138.inc' "$G"
grep -q 'physical_reality_138.inc' "$TF"
grep -q 'physical_reality_138.inc' "$FF"
grep -q 'PR_AXIS_CAUSAL' "$P"
grep -q 'PR_VALUE_VERSIONED_STATE' "$P"
grep -q 'PR_RUNTIME_REGISTER_ALLOCATOR,0' "$P"
grep -q 'PR_WORK_STEALING,0' "$P"
grep -q 'PR_RESOURCE_RECIPIENT_SELECTION,0' "$P"

# 1.3.13 temporary architecture is absorbed, not kept beside the unified path.
! grep -q 'g_emit_phys_expr:' "$G"
! grep -q 'g_emit_phys_save_scratch:' "$G"
! grep -q 'g_emit_phys_.*_depth:' "$G"
! grep -q 'g_reg_iter_native' "$G"
! grep -q 'gtri_update_stack_compat' "$G"
grep -q 'g_emit_phys_fp_expr_to:' "$G"
grep -q 'g_emit_phys_int_expr_to:' "$G"
grep -q 'g_phys_fp_temp_alloc:' "$G"
grep -q 'g_phys_int_temp_alloc:' "$G"
! grep -q 'g_match_transition_physical_pattern:' "$G"
grep -q '^g_phys_machine_canonicalize:' "$G"

echo 'CAUSAL_AXIS_IN_UNIFIED_PHYSICAL_REALITY=PASS'
echo 'FIXED_DEPTH_SCRATCH_ARCHITECTURE=0'
echo 'DUPLICATE_STACK_RECURRENCE_BACKEND=0'

# Confirmed dead/placeholder helpers and ghost state are physically absent.
! grep -q '^ff_emit_const:' compiler/field_frontend_common_x86_64.S
! grep -q '^ff_emit_reused_coeff_facts_135:' compiler/field_frontend_common_x86_64.S
! grep -q '^s_ident_eq_const:' compiler/surface_lowerer_x86_64.S
! grep -q '^s_expect_for_index_tuple:' compiler/surface_lowerer_x86_64.S
! grep -q '^s_eval_literal_u64:' compiler/surface_lowerer_x86_64.S
! grep -q '^s_match_kw_const:' compiler/surface_lowerer_x86_64.S
! grep -R -q 'tensor_comm_elimination' compiler

# Active duplicate copies were collapsed into assembly-time physical profiles.
test ! -e compiler/tensor_frontend_137_x86_64.S
test ! -e compiler/tensor_frontend_base_native256_138.S
test ! -e compiler/tensor_frontend_wide_native256_138.S
test -s compiler/tensor_frontend_native256_x86_64.S
test ! -e runtime/tensor_runtime_template_x86_64.S
test ! -e runtime/tensor_derived_runtime_138_x86_64.S
test ! -e runtime/tensor_runtime_native256_138_x86_64.S
test ! -e runtime/tensor_derived_runtime_native256_138_x86_64.S
test -s runtime/tensor_runtime_x86_64.S
grep -q 'TENSOR_RUNTIME_DERIVED' runtime/tensor_runtime_x86_64.S
grep -q 'TENSOR_RUNTIME_NATIVE256' runtime/tensor_runtime_x86_64.S
! grep -R -q '^worker:' runtime/tensor_runtime_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S

echo 'DEAD_SOURCE_SWEEP=PASS'
echo 'NATIVE256_SINGLE_SOURCE_PROFILE=PASS'
echo 'TENSOR_RUNTIME_SINGLE_SOURCE_PROFILE=PASS'
echo 'INTERNAL_COMPAT_WORKER_WRAPPERS=0'

# No benchmark identity may participate in compiler/runtime decisions.
if grep -R -Eqi '\b(fibonacci|fib_iter|lucas|tribonacci|damped_oscillator|thermal3|maxwell_point|rlc_state)\b' compiler runtime; then
  echo 'WORKLOAD_NAME_SPECIALIZATION=FAIL' >&2; exit 1
fi
echo 'WORKLOAD_NAME_SPECIALIZATION=0'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]
}
F=devtrash/tests/general_causal_state_1312
R=devtrash/tests/general_register_dag_1313
S=devtrash/tests/general_unified_physical_1314
compile_run "$F/fib_iter.wh" fib 1000 'out00_bits=0x0b594dc75cc0604b'
compile_run "$F/lucas.wh" lucas 1000 'out00_bits=0xf0a8e2dd406a618f'
compile_run "$F/tribonacci.wh" tri 1000 'out00_bits=0x4215efb898bc7418'
compile_run "$F/float_recur.wh" float 1000 'out00_bits=0x3fefffff79ea9f6a'
compile_run "$R/coupled_wrap.wh" coupled 10 'out00_bits=0xffffffffffd66600'
compile_run "$R/cycle3.wh" cycle3 10 'out00_bits=0x0000000000000002'
compile_run "$R/trap_fallback.wh" trap 10 'out00_bits=0x00000000000000c7'
compile_run "$S/damped_oscillator.wh" damped 1000 'out00_bits=0x3fefffff79ece807'
compile_run "$S/thermal3.wh" thermal 1000 'out00_bits=0x3feff7d06b19425c'
compile_run "$S/maxwell_point.wh" maxwell 1000 'out00_bits=0x3f828cdba649ca69'
compile_run "$S/rlc_state.wh" rlc 1000 'out00_bits=0x3f5061e279a1ead4'

echo 'GENERAL_AND_SIMULATION_DIFFERENTIAL_CORPUS=PASS'

hot_body() {
  objdump -d -Mintel "$1" | awk '
    /cmp    rbx,rbp/ && !seen { seen=1; next }
    seen && /movabs ds:0x422100/ { exit }
    seen { print }
  '
}
for b in fib lucas tri float coupled cycle3 damped thermal maxwell rlc; do
  hot_body "$T/$b" > "$T/$b.hot"
  ! grep -Eq '(^|[[:space:]])(push|pop)([[:space:]]|$)' "$T/$b.hot"
  ! grep -Eq '0x462100|0x482100' "$T/$b.hot"
done

echo 'ADMITTED_HOT_PUSH_POP=0'
echo 'ADMITTED_HOT_STATE_TEMP_TRAFFIC=0'

# Historical structural peaks must emerge from the unified DAG without names.
grep -q 'xadd   r9,r8' "$T/fib.hot"
grep -q 'xadd   r9,r8' "$T/lucas.hot"
# Three-state recurrence remains on the generic register-DAG path; exact
# register-copy spelling is not a semantic/release authority.
grep -q 'add    rdx,r9' "$T/tri.hot"
grep -q 'add    rdx,r10' "$T/tri.hot"
! grep -q 'xadd' "$T/coupled.hot"
grep -q 'imul' "$T/coupled.hot"
echo 'PREVIOUS_TECHNICAL_PEAKS_PRESERVED=PASS'

# FP Physical DAG must use three-operand scalar VEX and keep constants outside
# steady-state loops. Thermal has four distinct update constants and therefore
# specifically guards against the historical three-slot constant ceiling.
for b in float damped thermal maxwell rlc; do
  grep -Eq 'v(add|sub|mul)sd' "$T/$b.hot"
  ! grep -Eq '[[:space:]]movabs[[:space:]]+rax,' "$T/$b.hot"
done
[ "$(grep -Ec 'v(add|sub|mul)sd' "$T/damped.hot")" -eq 6 ]
[ "$(grep -Ec 'v(add|sub|mul)sd' "$T/thermal.hot")" -eq 12 ]
[ "$(grep -Ec 'v(add|sub|mul)sd' "$T/maxwell.hot")" -eq 5 ]
[ "$(grep -Ec 'v(add|sub|mul)sd' "$T/rlc.hot")" -eq 7 ]

echo 'FP_THREE_OPERAND_PHYSICALIZATION=PASS'
echo 'FP_FIXED_THREE_CONSTANT_SLOT_LIMIT=0'
echo 'THERMAL_FOUR_CONSTANT_HOT_REMATERIALIZATION=0'

# Counted admitted loops retain one bottom-tested conditional backedge and no
# unconditional steady-state jump.
for b in fib tri float coupled cycle3 damped thermal maxwell rlc; do
  ! grep -Eq '[[:space:]]jmp[[:space:]]' "$T/$b.hot"
done

echo 'CAUSAL_BOTTOM_TEST_BACKEDGE=PASS'

# Generic semantic fallback remains the single authority for graphs whose exact
# integer trap semantics cannot be admitted. Correctness above is the gate; no
# duplicated recurrence fallback is allowed to reappear.
echo 'TRAPPING_INTEGER_SEMANTICS_PRESERVED=PASS'
echo 'RUNTIME_TRANSITION_GRAPH_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_UNIFIED_PHYSICAL_REALITY_1_3_14=PASS'
