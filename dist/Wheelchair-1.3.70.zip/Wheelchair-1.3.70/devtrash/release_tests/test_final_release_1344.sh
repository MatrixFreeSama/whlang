#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_fourier_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_fusion_1341.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_relation_1342.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_precision_fusion_1343.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_generalization_1344.sh" >/dev/null

grep -q '^1\.3\.44$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_44_BUILD=PASS' "$ROOT/build.sh"
grep -q 'MATRIX_FAMILY=ONE_DIMENSION_BEARING_STRUCTURED_AUTHORITY' "$ROOT/build.sh"
grep -q 'FP_GT64_TRANSCENDENTAL_AUTHORITY=ONE_PARAMETERIZED_FPP_FAMILY' "$ROOT/build.sh"
grep -q 'NRII_SOLVER_IMPORTED=0' "$ROOT/build.sh"
grep -q '1.3.44 mathematics generalization' "$ROOT/README.md"
grep -q 'Mathematics generalization 1.3.44' "$ROOT/WHEELCHAIR_CHARTER_1_3_44.md"
[ -e "$ROOT/RELEASE_NOTES_1_3_44.md" ]
[ -e "$ROOT/MATHEMATICS_GENERALIZATION_1_3_44.md" ]
[ -e "$ROOT/CORRECTNESS_1_3_44_MATHEMATICS_GENERALIZATION.md" ]
[ -e "$ROOT/PURE_ASSEMBLY_RELEASE_PROOF_1_3_44.md" ]
[ -e "$ROOT/PERFORMANCE_1_3_44_C_FORTRAN.md" ]
[ -e "$ROOT/devtrash/benchmarks/math_generalization_1344/three_kernel_threeway_raw.csv" ]
[ -e "$ROOT/devtrash/benchmarks/math_generalization_1344/three_kernel_threeway_summary.csv" ]
[ -e "$ROOT/devtrash/benchmarks/math_generalization_1344/environment.txt" ]
[ -e "$ROOT/devtrash/release_history/1.3.43/ROOT_PRECISION_FUSION_1_3_43.md" ]

for f in "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

if find "$ROOT/devtrash/benchmarks/math_generalization_1344" -maxdepth 1 -type f \
  \( -name '*_wheelchair' -o -name '*_c' -o -name '*_fortran' \) | grep -q .; then
  echo benchmark-binaries-survived-release >&2; exit 1
fi

echo WHEELCHAIR_1_3_44_FINAL_RELEASE=PASS
