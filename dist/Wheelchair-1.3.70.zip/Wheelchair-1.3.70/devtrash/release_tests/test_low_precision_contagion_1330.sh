#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/whexc"
[ -x "$CC" ] || CC="$ROOT/bin/whexc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

cat >"$TMP/late_meet.wh" <<'SRC'
program low_precision_late_meet
input steps: u64
iterate sim limit steps {
    state a: f64 = 16777217.0
    state b: f64 = -16777216.0
    state c: f32 = cast(f32, 1.0)
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update c = (a + b) + c
    update i = i + 1
    result c
}
publish sim
test (1) => { sim = 2.0 }
SRC
"$CC" "$TMP/late_meet.wh" -o "$TMP/late_meet" >/dev/null
out=$("$TMP/late_meet" 1)
grep -q 'out00_bits=0x0000000040000000' <<<"$out"
objdump -d -M intel "$TMP/late_meet" >"$TMP/late.dis"
python3 - "$TMP/late.dis" <<'PY'
import sys
lines=open(sys.argv[1]).read().splitlines()
for i,l in enumerate(lines):
    if 'vaddsd' not in l: continue
    w=lines[i:i+8]
    j=next((n for n,x in enumerate(w) if 'cvtsd2ss' in x),None)
    k=next((n for n,x in enumerate(w) if 'vaddss' in x),None)
    if j is not None and k is not None and 0 < j < k:
        between='\n'.join(w[:k+1])
        if '\tpush' in between or '\tpop' in between:
            raise SystemExit('mixed FP edge fell back to stack transport')
        break
else:
    raise SystemExit('missing f64 compute -> one edge narrow -> f32 compute sequence')
PY

cat >"$TMP/chain.wh" <<'SRC'
program low_precision_chain
input steps: u64
iterate sim limit steps {
    state a: f64 = 16777217.0
    state b: f64 = -16777216.0
    state c: f32 = cast(f32, 1.0)
    state d: f64 = 4.0
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update c = ((a + b) + c) + d
    update d = d
    update i = i + 1
    result c
}
publish sim
test (1) => { sim = 6.0 }
SRC
"$CC" "$TMP/chain.wh" -o "$TMP/chain" >/dev/null
out=$("$TMP/chain" 1)
grep -q 'out00_bits=0x0000000040c00000' <<<"$out"
objdump -d -M intel "$TMP/chain" >"$TMP/chain.dis"
python3 - "$TMP/chain.dis" <<'PY'
import sys
lines=open(sys.argv[1]).read().splitlines()
for i,l in enumerate(lines):
    if 'vaddsd' not in l: continue
    w=lines[i:i+16]
    ops=[x for x in w if any(k in x for k in ('vaddsd','vaddss','cvtsd2ss','cvtss2sd'))]
    if sum('vaddss' in x for x in ops) >= 2 and sum('cvtsd2ss' in x for x in ops) >= 2:
        if any('cvtss2sd' in x for x in ops):
            raise SystemExit('implicit low->high promotion appeared')
        break
else:
    raise SystemExit('missing chained low-precision contagion realization')
PY

cat >"$TMP/reuse.wh" <<'SRC'
program low_projection_reuse
input steps: u64
iterate sim limit steps {
    state a: f64 = 16777217.0
    state b: f64 = -16777216.0
    state x: f32 = cast(f32, 1.0)
    state y: f32 = cast(f32, 2.0)
    state c: f32 = cast(f32, 0.0)
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update x = x
    update y = y
    update c = ((a + b) + x) + ((a + b) + y)
    update i = i + 1
    result c
}
publish sim
test (1) => { sim = 5.0 }
SRC
"$CC" "$TMP/reuse.wh" -o "$TMP/reuse" >/dev/null
out=$("$TMP/reuse" 1)
grep -q 'out00_bits=0x0000000040a00000' <<<"$out"
objdump -d -M intel "$TMP/reuse" >"$TMP/reuse.dis"
python3 - "$TMP/reuse.dis" <<'PY'
import sys
lines=open(sys.argv[1]).read().splitlines()
for i,l in enumerate(lines):
    if 'vaddsd' not in l: continue
    w=lines[i:i+16]
    if sum('vaddss' in x for x in w) >= 2:
        if sum('vaddsd' in x for x in w) != 1 or sum('cvtsd2ss' in x for x in w) != 1:
            raise SystemExit('repeated precision projection was recomputed')
        break
else:
    raise SystemExit('missing shared mixed-precision native segment')
PY

cat >"$TMP/deep_cse.wh" <<'SRC'
program low_precision_deep_cse
input steps: u64
iterate sim limit steps {
    state a: f64 = 16777217.0
    state b: f64 = 1.0
    state d1: f64 = -16777216.0
    state d2: f64 = -16777216.0
    state x: f32 = cast(f32, 1.0)
    state y: f32 = cast(f32, 2.0)
    state c: f32 = cast(f32, 0.0)
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update d1 = d1
    update d2 = d2
    update x = x
    update y = y
    update c = (((a * b) + d1) + x) + (((a * b) + d2) + y)
    update i = i + 1
    result c
}
publish sim
test (1) => { sim = 5.0 }
SRC
"$CC" "$TMP/deep_cse.wh" -o "$TMP/deep_cse" >/dev/null
out=$("$TMP/deep_cse" 1)
grep -q 'out00_bits=0x0000000040a00000' <<<"$out"
objdump -d -M intel "$TMP/deep_cse" >"$TMP/deep.dis"
python3 - "$TMP/deep.dis" <<'PY'
import sys
lines=open(sys.argv[1]).read().splitlines()
for i,l in enumerate(lines):
    if 'vmulsd' not in l: continue
    w=lines[i:i+64]
    pos_add=[n for n,x in enumerate(w) if 'vaddsd' in x]
    pos_cvt=[n for n,x in enumerate(w) if 'cvtsd2ss' in x]
    if len(pos_add) >= 2 and len(pos_cvt) >= 2:
        if min(pos_cvt) < min(pos_add):
            raise SystemExit('low precision tunneled into a high-precision subtree')
        break
else:
    raise SystemExit('missing deep CSE precision-boundary segment')
PY

cat >"$TMP/f32_only.wh" <<'SRC'
program f32_only
input steps: u64
iterate sim limit steps {
    state x: f32 = cast(f32, 1.25)
    state y: f32 = cast(f32, 2.5)
    state i: u64 = 0
    while i < steps
    update x = x + y
    update y = y
    update i = i + 1
    result x
}
publish sim
test (1) => { sim = 3.75 }
SRC
"$CC" "$TMP/f32_only.wh" -o "$TMP/f32_only" >/dev/null
out=$("$TMP/f32_only" 1)
grep -q 'out00_bits=0x0000000040700000' <<<"$out"
objdump -d -M intel "$TMP/f32_only" >"$TMP/f32.dis"
grep -q 'vaddss' "$TMP/f32.dis"
if grep -q 'cvtss2sd' "$TMP/f32.dis"; then
  echo 'unexpected implicit f32->f64 promotion' >&2
  exit 1
fi

echo LOW_PRECISION_CONTAGION_1_3_30=PASS
