#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
SRC="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
[ -f "$SRC" ]
[ ! -e "$ROOT/runtime/rankn_precision_x86_64.inc" ]

# One active multiplication authority, one ABI entry point, no former candidate
# symbols/instructions, no external Fourier engine, and no runtime allocation.
grep -q '^\.global rankn_fp_mul$' "$SRC"
grep -q 'rpf_fourier_mul_u64' "$SRC"
grep -q 'Forward DIF order is 5 -> 3 -> 2' "$SRC"
grep -q 'inverse DIT is the exact reverse' "$SRC"
grep -q '0x0007ffffffffffff' "$SRC"   # 2^51-1 native SIMD guard budget
grep -q 'Base-2\^32 Knuth digit division' "$SRC"
! grep -Eqi 'rankn_fp_mul_span|rankn_fp_mul_batch8|rowcarry|vpmadd52|wide_float_x86_64' "$SRC"
! grep -Eqi '\b(fftw|malloc|calloc|realloc|free)\b' "$SRC"

# The compiler must materialize the same geometry fact AOT and store it in the
# existing carrier header rather than introducing a planner/runtime object.
G="$ROOT/compiler/general_frontend_x86_64.S"
grep -q '^g_rankn_fourier_geom_pack:' "$G"
grep -q 'packed AOT Fourier geometry fact' "$G"
grep -q '2\^51' "$G"
grep -q 'N\*(100\*a2 + 120\*a3 + 180\*a5 + 10\*a3\^2 + 30\*a5\^2) + 40\*n' "$G"
! grep -Eqi '\b(fftw|planner)\b' "$G"

# Active production trees contain no deleted multiplication implementation or
# compatibility entry point. Historical devtrash is intentionally excluded.
if grep -RIE --include='*.S' --include='*.inc' \
  'rankn_fp_mul_span|rankn_fp_mul_batch8|rowcarry|vpmadd52|wide_float_x86_64' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools" >/dev/null 2>&1; then
  echo deleted-multiplication-authority-survived >&2; exit 1
fi
if grep -RIE --include='*.S' --include='*.inc' '\bfftw' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools" >/dev/null 2>&1; then
  echo external-fourier-authority-survived >&2; exit 1
fi

cat >"$TMP/wrap.S" <<ASM
.intel_syntax noprefix
.text
.include "$SRC"
.section .note.GNU-stack,"",@progbits
ASM
gcc -c -O2 -mavx2 -mfma "$TMP/wrap.S" -o "$TMP/wrap.o"

# Independent exact oracle. GMP is test-only and never linked into production.
gcc -O2 -mavx2 -mfma "$ROOT/devtrash/benchmarks/native_fourier_1340/oracle_native_fourier_rne.c" \
    "$TMP/wrap.o" -lgmp -o "$TMP/oracle"
"$TMP/oracle" > "$TMP/oracle.log"
grep -q '^NATIVE_FOURIER_RNE_ORACLE_1_3_40=PASS$' "$TMP/oracle.log"

# Production binaries must not contain the removed IFMA instruction family or
# dynamic references to an external FFT implementation.
for f in "$ROOT"/bin/*; do
  [ -f "$f" ] || continue
  if objdump -d "$f" 2>/dev/null | grep -qi 'vpmadd52'; then
    echo deleted-ifma-machine-code-survived:"$f" >&2; exit 1
  fi
  if strings "$f" 2>/dev/null | grep -Eqi 'fftw|rankn_fp_mul_batch8|rankn_fp_mul_span|rowcarry'; then
    echo deleted-or-external-symbol-survived:"$f" >&2; exit 1
  fi
done

echo RANKN_PRECISION_FOURIER_EXACT_ORACLE_1_3_40=PASS
echo RANKN_PRECISION_FOURIER_1_3_40=PASS
