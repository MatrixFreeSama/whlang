#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = 1.3.27 ]

for p in * .*; do
  case "$p" in
    .|..|.git|build|bin|compiler|runtime|surface|tools|devtrash|README.md|VERSION|build.sh|SHA256SUMS|\
    RELEASE_NOTES_1_3_27.md|WHEELCHAIR_CHARTER_1_3_27.md|PURE_ASSEMBLY_RELEASE_PROOF_1_3_27.md|\
    CORRECTNESS_1_3_27_CARRIER_LIFETIME.md|PRODUCTION_BIN_SHA256_1_3_27.txt) ;;
    *) echo "ROOT_SURFACE_LEAK=$p" >&2; exit 1 ;;
  esac
done
echo 'CURRENT_RELEASE_ROOT_ONLY=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  test -x "bin/$f"
  test ! -e "$f"
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 10 ]
echo 'BIN_SOLE_EXECUTABLE_AUTHORITY=PASS'

for d in compiler runtime surface tools; do
  if grep -R -nF 'devtrash/' "$d" >/dev/null 2>&1; then
    echo "PRODUCTION_DEVTRASH_PATH_DEPENDENCY=$d" >&2; exit 1
  fi
done
if grep -nF 'devtrash/' build.sh >/dev/null 2>&1; then
  echo 'BUILD_DEVTRASH_PATH_DEPENDENCY=FAIL' >&2; exit 1
fi
if find compiler runtime surface tools -type l -print | grep -q .; then
  echo 'PRODUCTION_SYMLINK_AUTHORITY=FAIL' >&2; exit 1
fi
echo 'PRODUCTION_DEVTRASH_PATH_DEPENDENCY=0'

OFF=".devtrash_absent_1327_$$"
LOG=".release_build_1327_surface_$$.log"
restore_devtrash() {
  if [ -d "$OFF" ] && [ ! -e devtrash ]; then mv "$OFF" devtrash; fi
}
cleanup() {
  restore_devtrash
  rm -f "$LOG"
}
trap cleanup EXIT HUP INT TERM
mv devtrash "$OFF"
rm -rf build
./build.sh > "$LOG" 2>&1
restore_devtrash
grep -Fqx 'WHEELCHAIR_1_3_27_BUILD=PASS' "$LOG"
rm -f "$LOG"
trap - EXIT HUP INT TERM

echo 'BUILD_WITH_DEVTRASH_PHYSICALLY_ABSENT=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "bin/$f"
done
echo 'BUILD_BIN_IDENTITY=PASS'

# 1.3.27 changes only Field compiler authority. All unrelated executables remain
# byte-identical to the final 1.3.26 production manifest.
grep -v '  bin/fieldc' devtrash/release_history/PRODUCTION_BIN_SHA256_1_3_26.txt | sha256sum -c - >/dev/null
echo 'NON_FIELD_PRODUCTION_BINARY_IDENTITY_WITH_1_3_26=PASS'

sha256sum -c PRODUCTION_BIN_SHA256_1_3_27.txt >/dev/null
echo 'CURRENT_PRODUCTION_BINARY_MANIFEST=PASS'
echo 'DEVTRASH_NON_AUTHORITATIVE=PASS'
echo 'WHEELCHAIR_RELEASE_SURFACE_1_3_27=PASS'
