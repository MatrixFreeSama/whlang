#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_fourier_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_fusion_1341.sh" >/dev/null

grep -q '^1\.3\.41$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_41_BUILD=PASS' "$ROOT/build.sh"
grep -q 'A_INTERSECTION_B_NOT_A_PLUS_B' "$ROOT/build.sh"
grep -q 'A∩B' "$ROOT/RELEASE_NOTES_1_3_41.md"
[ -e "$ROOT/MATHEMATICS_FUSION_1_3_41.md" ]
[ -e "$ROOT/WHEELCHAIR_CHARTER_1_3_41.md" ]

for f in "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

echo WHEELCHAIR_1_3_41_FINAL_RELEASE=PASS
