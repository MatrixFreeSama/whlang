#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# Production source audit: retired capacity tiers must not return to current
# production authorities. The standalone frozen historical parser is not a
# production build input and is intentionally outside this assertion.
for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_derived_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S \
  compiler/tensor_frontend_x86_64.S; do
  ! grep -q '^\.equ MAX_NODES,65536$' "$ROOT/$f"
  ! grep -q '^\.equ MAX_BINDINGS,16$' "$ROOT/$f"
done
! grep -q 'GMAX_SYMBOLS' "$ROOT/compiler/general_frontend_x86_64.S"
! grep -q 'GMAX_FRAGMENTS' "$ROOT/compiler/general_frontend_x86_64.S"
! grep -q 'GMAX_EDGES' "$ROOT/compiler/general_frontend_x86_64.S"
! grep -q 'GR_MAX_NODES' "$ROOT/runtime/general_parallel_release_x86_64.S"
! grep -q 'GR_MAX_EDGES' "$ROOT/runtime/general_parallel_release_x86_64.S"
grep -q '^g_prepare_symbol_arena:' "$ROOT/compiler/general_frontend_x86_64.S"
grep -q '^g_grow_edge_arena:' "$ROOT/compiler/general_frontend_x86_64.S"
grep -q '^json_prepare_arena:' "$ROOT/compiler/tensor_frontend_x86_64.S"
grep -q '^tensor_prepare_binding_arena:' "$ROOT/compiler/tensor_frontend_x86_64.S"

# One authority for capacities that remain part of current runtime ABIs.
! grep -q 'GENERAL_RUNTIME_BINDING_SLOT_CAP' "$ROOT/compiler/general_runtime_capacity.inc"
grep -qi 'Program cardinalities (inputs/bindings/states/outputs) are instance data' "$ROOT/compiler/general_runtime_capacity.inc"
! grep -q 'GENERAL_RUNTIME_STATE_CAP' "$ROOT/compiler/general_runtime_capacity.inc"
grep -q '^\.equ GENERAL_RUNTIME_DYNAMIC_ARENA_VA,' "$ROOT/compiler/general_runtime_capacity.inc"
! grep -q 'FIELD_RUNTIME_FIELD_CAP' "$ROOT/compiler/field_runtime_capacity.inc"
grep -q '^\.equ FIELD_RUNTIME_RANK_CAP,8$' "$ROOT/compiler/field_runtime_capacity.inc"
! grep -q 'FIELD_RUNTIME_ACCESS_CAP' "$ROOT/compiler/field_runtime_capacity.inc"
grep -q '^\.include "compiler/general_runtime_capacity.inc"$' "$ROOT/runtime/general_runtime_template_x86_64.S"
grep -q '^\.include "compiler/field_runtime_capacity.inc"$' "$ROOT/runtime/field_runtime_256_x86_64.S"
grep -q '^\.include "compiler/field_runtime_capacity.inc"$' "$ROOT/runtime/field_runtime_512_x86_64.S"

# Build metadata itself must describe a structural graph rather than publish an
# implementation maximum.
if [ ! -s "$ROOT/build/general_parallel_release_offsets.json" ]; then
  "$ROOT/build.sh" >/dev/null
fi
grep -q '"graph_capacity": "structural"' "$ROOT/build/general_parallel_release_offsets.json"
! grep -q '"max_nodes"' "$ROOT/build/general_parallel_release_offsets.json"
! grep -q '"max_edges"' "$ROOT/build/general_parallel_release_offsets.json"

# Stress-input generation is validation tooling only. It is not a production
# build authority and no generated fixture enters compiler/ or runtime/.
python3 - "$TMP" <<'PY'
import json, pathlib, sys
p=pathlib.Path(sys.argv[1])
contracts={
    "deterministic":True,
    "integer_overflow":"wrap",
    "floating_point":"strict",
    "mixed_precision":"lower_precision_dominates",
}

def write(name,obj):
    (p/name).write_text(json.dumps(obj,separators=(",",":")))

# 240 existing runtime binding slots + 32 outputs produces a materialized causal
# graph above the retired 256-node runtime table without adding a new operation.
b=[]
for i in range(240):
    if i==0: expr={"literal":1,"type":"u64"}
    elif i==1: expr={"literal":2,"type":"u64"}
    else: expr={"op":"add","args":[{"var":f"b{i-1}"},{"var":f"b{i-2}"}]}
    b.append({"name":f"b{i}","op":"compute","expr":expr})
outs=[{"label":f"o{j}","expr":{"var":f"b{239-j}"}} for j in range(32)]
write("nodes.json",{
    "format":"wheelchair.tensor/1","program":"capacity_nodes","contracts":contracts,
    "inputs":[],"bindings":b,"outputs":outs,"tests":[],"_compiler_lane":"wheelchair.general/1"
})

# 70 independent existing bindings observed by 16 outputs = 1120 causal edges.
def sumexpr(names):
    xs=[{"var":n} for n in names]
    while len(xs)>1:
        nxt=[]
        it=iter(xs)
        for a in it:
            try: b=next(it)
            except StopIteration:
                nxt.append(a); break
            nxt.append({"op":"add","args":[a,b]})
        xs=nxt
    return xs[0]
b=[{"name":f"e{i}","op":"compute","expr":{"literal":i+1,"type":"u64"}} for i in range(70)]
outs=[{"label":f"o{j}","expr":sumexpr([f"e{i}" for i in range(70)])} for j in range(16)]
write("edges.json",{
    "format":"wheelchair.tensor/1","program":"capacity_edges","contracts":contracts,
    "inputs":[],"bindings":b,"outputs":outs,"tests":[],"_compiler_lane":"wheelchair.general/1"
})

# More than the retired 65,536 production JSON-node table. Tests are ignored by
# execution here; their only role is exercising the existing parser structure.
write("nodes70k.json",{
    "format":"wheelchair.tensor/1","program":"capacity_json_nodes","contracts":contracts,
    "inputs":[],
    "bindings":[{"name":"answer","op":"compute","expr":{"literal":42,"type":"u64"}}],
    "outputs":[{"label":"answer","expr":{"var":"answer"}}],
    "tests":[0]*70000,"_compiler_lane":"wheelchair.general/1"
})
PY

"$ROOT/bin/topologyc" "$TMP/nodes.json" -o "$TMP/nodes.bin" >/dev/null
"$TMP/nodes.bin" > "$TMP/nodes.out"
[ "$(wc -l < "$TMP/nodes.out")" -eq 32 ]

"$ROOT/bin/topologyc" "$TMP/edges.json" -o "$TMP/edges.bin" >/dev/null
"$TMP/edges.bin" > "$TMP/edges.out"
[ "$(wc -l < "$TMP/edges.out")" -eq 16 ]

# The 1.3.55 General image no longer carries a fixed in-ELF program slot, so
# historical direct PROGRAM_OFF probing is intentionally retired.  Execution of
# the >256-node and 1120-edge programs above remains the representation-neutral
# oracle; current graph metadata structure is separately guarded by the JSON
# authority checks above and the 1.3.55 architecture-aging release proof.

"$ROOT/bin/topologyc" "$TMP/nodes70k.json" -o "$TMP/nodes70k.bin" >/dev/null
"$TMP/nodes70k.bin" | grep -q 'out00_bits=0x000000000000002a'

# The production launcher used to reject source files above 8 MiB. Preserve the
# exact same valid canonical program and append legal JSON whitespace past 9 MiB.
cp "$ROOT/devtrash/tests/general/compute_u64.wh" "$TMP/source9m.wh"
current=$(wc -c < "$TMP/source9m.wh")
target=$((9*1024*1024))
if [ "$current" -lt "$target" ]; then
  head -c $((target-current)) /dev/zero | tr '\000' ' ' >> "$TMP/source9m.wh"
fi
[ "$(wc -c < "$TMP/source9m.wh")" -ge $((9*1024*1024)) ]
"$ROOT/bin/wheelchairc" "$TMP/source9m.wh" -o "$TMP/source9m.bin" >/dev/null
"$TMP/source9m.bin" | grep -q 'out00_bits=0x000000000000002a'

echo STRUCTURAL_CAPACITY_CONVERGENCE_1_3_51=PASS
