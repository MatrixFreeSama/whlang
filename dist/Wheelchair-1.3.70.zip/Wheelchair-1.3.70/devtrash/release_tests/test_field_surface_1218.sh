#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T16=devtrash/tests/field_1216
T18=devtrash/tests/field_surface_1218
TMP=${TMPDIR:-/tmp}/wheelchair1218_surface_$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

[ -x build/fieldc ]
[ -x build/fieldc-native256 ]
[ -x build/whexc ]

compile_cmp() {
  C=$1; A=$2; B=$3; TAG=$4
  build/$C "$A" -o "$TMP/$TAG-a" >/dev/null
  build/$C "$B" -o "$TMP/$TAG-b" >/dev/null
  cmp "$TMP/$TAG-a" "$TMP/$TAG-b"
}

# One canonical field graph, several human spellings.  WH fake-for, WHEX direct
# expression, WHEX region and explicit periodic() must erase before native code.
for C in fieldc fieldc-native256; do
  build/$C "$T18/neighbor.json" -o "$TMP/$C-neighbor-json" >/dev/null
  for S in neighbor.whex neighbor_region.whex neighbor.wh neighbor_explicit.whex; do
    build/$C "$T18/$S" -o "$TMP/$C-${S%.*}" >/dev/null
    cmp "$TMP/$C-neighbor-json" "$TMP/$C-${S%.*}"
  done

done
echo 'WH_WHEX_CANONICAL_ELF_IDENTITY=PASS'
echo 'WH_FAKE_FOR_FIELD_LOWERING=PASS'
echo 'WHEX_REGION_FIELD_LOWERING=PASS'
echo 'PERIODIC_BOUNDARY_SURFACE=PASS'

# Existing 1.2.16 canonical authorities must have byte-identical human surfaces.
for C in fieldc fieldc-native256; do
  compile_cmp "$C" "$T16/sum.json"   "$T18/sum.whex"   "$C-sum"
  compile_cmp "$C" "$T16/mixed.json" "$T18/mixed.whex" "$C-mixed"
  compile_cmp "$C" "$T16/inout.json" "$T18/inout.whex" "$C-inout"
  compile_cmp "$C" "$T16/copy.json"  "$T18/copy.whex"  "$C-copy"
  compile_cmp "$C" "$T16/alias.json" "$T18/alias.whex" "$C-alias"
  build/$C "$T18/component.json" -o "$TMP/$C-component-json" >/dev/null
  build/$C "$T18/component.whex" -o "$TMP/$C-component-whex" >/dev/null
  build/$C "$T18/component.wh" -o "$TMP/$C-component-wh" >/dev/null
  cmp "$TMP/$C-component-json" "$TMP/$C-component-whex"
  cmp "$TMP/$C-component-json" "$TMP/$C-component-wh"
done
echo 'FIELD_INPUT_OUTPUT_INOUT_SURFACE=PASS'
echo 'MATERIALIZED_FIELD_SUM_SURFACE=PASS'
echo 'MULTI_DYNAMIC_EXTENT_SURFACE=PASS'
echo 'RANK4_COMPONENT_AXIS_SURFACE=PASS'

# Pure functions are compile-time abstractions.  Exact lexical parameter identity
# outranks one-edit typo repair even for a one-character parameter.  Short name,
# long name, direct expression and canonical graph must be byte-identical.
for C in fieldc fieldc-native256; do
  for S in pure_direct.json pure_direct.whex pure_short.whex pure_long.whex; do
    build/$C "$T18/$S" -o "$TMP/$C-${S%.*}" >/dev/null
  done
  cmp "$TMP/$C-pure_direct" "$TMP/$C-pure_short"
  cmp "$TMP/$C-pure_direct" "$TMP/$C-pure_long"
  cmp "$TMP/$C-pure_direct" "$TMP/$C-pure_direct"
  # JSON and WHEX share the same basename, compile JSON once more under a unique name.
  build/$C "$T18/pure_direct.json" -o "$TMP/$C-pure-json" >/dev/null
  build/$C "$T18/pure_direct.whex" -o "$TMP/$C-pure-whex" >/dev/null
  cmp "$TMP/$C-pure-json" "$TMP/$C-pure-whex"
done
echo 'PURE_FN_SHORT_PARAMETER_SCOPE=PASS'
echo 'PURE_FN_ZERO_RUNTIME_ABSTRACTION=PASS'

# UTF-8 identifiers are human-surface names only and must not perturb field codegen.
for C in fieldc fieldc-native256; do
  build/$C "$T18/utf8.whex" -o "$TMP/$C-utf8" >/dev/null
  build/$C "$T16/copy.json" -o "$TMP/$C-copy-json-utf8" >/dev/null
  cmp "$TMP/$C-utf8" "$TMP/$C-copy-json-utf8"
done
echo 'UTF8_FIELD_IDENTIFIERS=PASS'

# Ordinary whexc must route the human Field semantic surface to the same sovereign
# field backend before general tensor lowering.  No failure-driven retry is allowed.
build/whexc "$T18/neighbor.whex" -o "$TMP/via-whexc-neighbor" >/dev/null
cmp "$TMP/via-whexc-neighbor" "$TMP/fieldc-neighbor-json"
build/whexc "$T18/pure_short.whex" -o "$TMP/via-whexc-pure" >/dev/null
build/fieldc "$T18/pure_direct.json" -o "$TMP/fieldc-pure-reference" >/dev/null
cmp "$TMP/via-whexc-pure" "$TMP/fieldc-pure-reference"
echo 'WHEXC_HUMAN_FIELD_SEMANTIC_ROUTE=PASS'

# Real WHFLD216 execution through human sources.
cp "$T16/out_3x5x7.whfld" "$TMP/neighbor-out.whfld"
[ "$("$TMP/fieldc-neighbor-json" "$T16/a_3x5x7.whfld" "$TMP/neighbor-out.whfld")" = 'checksum_f32_bits=0x45ade800' ]
cmp "$TMP/neighbor-out.whfld" "$T18/expected_neighbor_3x5x7.whfld"

build/fieldc "$T18/mixed.whex" -o "$TMP/human-mixed" >/dev/null
cp "$T16/out_3x5x7.whfld" "$TMP/mixed-out.whfld"
[ "$("$TMP/human-mixed" "$T16/a_3x5x7.whfld" "$T16/bpad_3x5x7.whfld" "$TMP/mixed-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
cmp "$TMP/mixed-out.whfld" "$T16/expected_mixed_3x5x7.whfld"

build/fieldc "$T18/inout.whex" -o "$TMP/human-inout" >/dev/null
cp "$T16/inout_3x5x7.whfld" "$TMP/inout.whfld"
[ "$("$TMP/human-inout" "$TMP/inout.whfld")" = 'checksum_f32_bits=0x45b7c000' ]
cmp "$TMP/inout.whfld" "$T16/expected_inout_3x5x7.whfld"

build/fieldc "$T18/component.whex" -o "$TMP/human-component" >/dev/null
cp "$T18/component_out.whfld" "$TMP/component-out.whfld"
[ "$("$TMP/human-component" "$T18/component_in.whfld" "$TMP/component-out.whfld")" = 'checksum_f32_bits=0x45a44000' ]
cmp "$TMP/component-out.whfld" "$T18/component_expected.whfld"

build/fieldc "$T18/pure_short.whex" -o "$TMP/human-pure" >/dev/null
cp "$T16/out_3x5x7.whfld" "$TMP/pure-out.whfld"
[ "$("$TMP/human-pure" "$T16/a_3x5x7.whfld" "$TMP/pure-out.whfld")" = 'checksum_f32_bits=0x462de800' ]
echo 'HUMAN_FIELD_RUNTIME_ORACLES=PASS'

# Boundary truth cannot be guessed.  Missing contracts reject with a human-facing
# diagnostic.  A static numeric component extent is also rejected until the ABI
# carries a real runtime-checkable static-shape contract.
set +e
build/fieldc "$T18/boundary_invalid.whex" -o "$TMP/bad-boundary" >/dev/null 2>"$TMP/bad-boundary.err"
BR=$?
build/fieldc "$T18/static_extent_invalid.whex" -o "$TMP/bad-static" >/dev/null 2>"$TMP/bad-static.err"
SR=$?
set -e
[ "$BR" -eq 65 ]
grep -q 'unproven field boundary access' "$TMP/bad-boundary.err"
[ "$SR" -eq 65 ]
grep -q 'same Rank-N logical axes and extents' "$TMP/bad-static.err"
echo 'STRICT_BOUNDARY_REJECTION=PASS'
echo 'NO_FAKE_STATIC_COMPONENT_CONTRACT=PASS'

# Surface syntax contains no manual physicalization obligations.
if grep -RniE '\b(stride|descriptor|flatten|vgather|zmm|ymm|simd|parallel[[:space:]]+for)\b' "$T18"/*.wh "$T18"/*.whex >/dev/null 2>&1; then
  echo 'HUMAN_SURFACE_PHYSICALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'NO_MANUAL_DESCRIPTOR=PASS'
echo 'NO_MANUAL_STRIDE=PASS'
echo 'NO_MANUAL_FLATTEN=PASS'
echo 'NO_SIMD_ANNOTATION=PASS'
echo 'NO_PARALLEL_FOR=PASS'

echo 'WHEELCHAIR_HUMAN_FIELD_SURFACE_1_2_18=PASS'
