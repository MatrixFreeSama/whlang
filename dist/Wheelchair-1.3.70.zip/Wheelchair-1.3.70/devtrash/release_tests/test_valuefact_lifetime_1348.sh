#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1348_valuefact_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null


grep -q '^ff_consumer_local_foldable:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_try_consumer_local_fold:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_vbin_stack:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_direct_regular_store_from:' compiler/field_frontend_common_x86_64.S
grep -q 'ff_const_pool_transport_demand' compiler/field_frontend_common_x86_64.S
! grep -q 'ff_build_arith_fact_cache' compiler/field_frontend_common_x86_64.S
! grep -q 'ff_arith_fact_cache_slot' compiler/field_frontend_common_x86_64.S

echo 'VALUEFACT_LIFETIME_ONE_AUTHORITY=PASS'
echo 'ARITHMETIC_STACK_CACHE=0'

# Existing native256 ownership and Field truthfulness remain authoritative.
sh devtrash/release_tests/test_avx2_physical_ownership_1347.sh >/dev/null
sh devtrash/release_tests/test_field_native_1216.sh >/dev/null
sh devtrash/release_tests/test_field_locality_1217.sh >/dev/null
sh devtrash/release_tests/test_physical_regularity_134.sh >/dev/null

# High-pressure strict graph: output bytes must remain the packaged oracle while
# the emitted arithmetic keeps its exact operation count. The memory operand is
# evidence that transport, not arithmetic, was erased.
F=devtrash/tests/field_1216
for C in fieldc fieldc-native256; do
  build/$C "$F/fem_hex8_full.json" -o "$T/$C-hex8" >/dev/null
  for u in 0 1 2; do cp "$F/fem_out${u}_3x5x7.whfld" "$T/$C-o${u}.whfld"; done
  "$T/$C-hex8" \
    "$F/fem_lambda_3x5x7.whfld" "$F/fem_mu_3x5x7.whfld" \
    "$F/fem_p0_3x5x7.whfld" "$F/fem_p1_3x5x7.whfld" "$F/fem_p2_3x5x7.whfld" \
    "$T/$C-o0.whfld" "$T/$C-o1.whfld" "$T/$C-o2.whfld" >/dev/null
  for u in 0 1 2; do cmp "$T/$C-o${u}.whfld" "$F/fem_expected_out${u}_3x5x7.whfld"; done
done
for u in 0 1 2; do cmp "$T/fieldc-o${u}.whfld" "$T/fieldc-native256-o${u}.whfld"; done

tools/disassemble_generated.sh "$T/fieldc-native256-hex8" > "$T/hex256.dis"
[ "$(grep -c '\bvmulps\b' "$T/hex256.dis")" -eq 2304 ]
[ "$(grep -c '\bvaddps\b' "$T/hex256.dis")" -eq 1156 ]
grep -q 'vmulps.*YMMWORD PTR \[rsp' "$T/hex256.dis"
! grep -q '\bzmm[0-9]' "$T/hex256.dis"
echo 'STRICT_ARITHMETIC_OPERATION_COUNT_UNCHANGED=PASS'
echo 'CONSUMER_LOCAL_MEMORY_OPERAND=PASS'
echo 'STRICT_256_512_OUTPUT_BYTES=PASS'

# Production source may not select the convergence by workload identity, named
# neighborhood width, fixed access count or benchmark size.
if grep -RniE 'taichi|hex8|elasticity|64\^3|64x64|benchmark[_ -]*mode|consumer_local_hex|valuefact_hex' \
  compiler/field_frontend_common_x86_64.S compiler/field_frontend_256_x86_64.S \
  runtime/field_runtime_256_x86_64.S tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'VALUEFACT_WORKLOAD_SPECIALIZATION=FAIL' >&2
  exit 1
fi
echo 'VALUEFACT_WORKLOAD_SPECIALIZATION=0'
echo 'VALUEFACT_NEW_FIELD_OPCODE=0'
echo 'VALUEFACT_NEW_RUNTIME_SCHEDULER=0'
echo 'WHEELCHAIR_VALUEFACT_LIFETIME_1_3_48=PASS'
