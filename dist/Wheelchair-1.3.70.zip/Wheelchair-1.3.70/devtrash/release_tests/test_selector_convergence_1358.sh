#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -x bin/whexc ] || ./build.sh >/dev/null

# Regression: ShapeFact-N presence alone must not force the derived consumer.
FSI=devtrash/benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
bin/whexc "$FSI" -o "$T/fsi-whexc" >/dev/null
bin/topologyc "$FSI" -o "$T/fsi-base" >/dev/null
cmp "$T/fsi-whexc" "$T/fsi-base"
[ "$("$T/fsi-whexc" 4)" = 'checksum_bits=0x3fb2acf007b0d71c' ]

# The complementary side must remain intact: productized Rank-N still selects
# the already-existing derived consumer, with no fallback or retry route.
R3=devtrash/tests/shapefact_1357/rank3_batch.whex
bin/whexc "$R3" -o "$T/r3-whexc" >/dev/null
bin/topologyc-derived "$R3" -o "$T/r3-derived" >/dev/null
cmp "$T/r3-whexc" "$T/r3-derived"
[ "$("$T/r3-whexc" 2)" = 'checksum_bits=0x405a400000000000' ]

# Selector fix only. ShapeFact semantics and its current consumer frontier stay
# exactly where 1.3.57 placed them.
if bin/whexc devtrash/tests/shapefact_1357/two_runtime_extents.whex -o "$T/two" >/dev/null 2>&1; then
  echo 'selector fix accidentally expanded Tensor semantics' >&2
  exit 1
fi

grep -q '^shape_fact_requires_derived:' compiler/native_driver_x86_64.S
! grep -RqsE 'rank_n_product|rank_n_source_rank|rank_n_product_patch|RUNTIME_RANK_N_PRODUCT|__rankn_q' compiler runtime tools

echo SELECTOR_CONVERGENCE_1_3_58=PASS
