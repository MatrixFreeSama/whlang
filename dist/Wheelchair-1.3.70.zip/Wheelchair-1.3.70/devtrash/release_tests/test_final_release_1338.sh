#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = '1.3.38' ]
bash devtrash/release_tests/test_precision_policy_1334.sh
bash devtrash/release_tests/test_native_mathematics_1334.sh
bash devtrash/release_tests/test_rankn_mathematics_1334.sh
bash devtrash/release_tests/test_structured_mathematics_1336.sh
bash devtrash/release_tests/test_parametric_rankn_fp_1338.sh
grep -q 'Parasite old architecture first' WHEELCHAIR_CHARTER_1_3_38.md
grep -q 'Strengthen old architecture second' WHEELCHAIR_CHARTER_1_3_38.md
grep -q 'New architecture is last resort' WHEELCHAIR_CHARTER_1_3_38.md
grep -q 'PARAMETRIC_RANKN_FP_1_3_38=BUILT' build.sh
grep -q 'WHEELCHAIR_1_3_38_BUILD=PASS' build.sh
grep -q 'released scalar path loses this benchmark' PERFORMANCE_1_3_38_HIGH_PRECISION_C_BATTLE.md
[ -x bin/wheelchairc ]
echo WHEELCHAIR_1_3_38_FINAL_RELEASE=PASS
