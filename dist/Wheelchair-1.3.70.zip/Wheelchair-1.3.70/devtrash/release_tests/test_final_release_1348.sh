#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_fourier_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_fusion_1341.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_relation_1342.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_precision_fusion_1343.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_generalization_1344.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_field_human_shell_1345.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_field_human_shell_1346.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_valuefact_lifetime_1348.sh" >/dev/null

grep -q '^1\.3\.48$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_48_BUILD=PASS' "$ROOT/build.sh"
grep -q 'VALUEFACT_LIFETIME_CONVERGENCE_1_3_48=BUILT' "$ROOT/build.sh"
grep -q '^# Wheelchair 1\.3\.48' "$ROOT/README.md"
for f in \
 RELEASE_NOTES_1_3_48.md VALUEFACT_LIFETIME_1_3_48.md \
 CORRECTNESS_1_3_48_VALUEFACT_LIFETIME.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_48.md \
 WHEELCHAIR_CHARTER_1_3_48.md; do [ -e "$ROOT/$f" ]; done
[ -e "$ROOT/devtrash/release_history/1.3.47/RELEASE_NOTES_1_3_47.md" ]

for f in "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc" "$ROOT/bin/fieldc-native256" "$ROOT/bin/topologyc-native256"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

[ ! -d "$ROOT/build" ] || [ "${ALLOW_BUILD_DIR:-0}" = 1 ]
echo WHEELCHAIR_1_3_48_FINAL_RELEASE=PASS
