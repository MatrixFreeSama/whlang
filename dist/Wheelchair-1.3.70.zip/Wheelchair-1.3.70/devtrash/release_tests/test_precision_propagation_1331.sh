#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/whexc"
[ -x "$CC" ] || CC="$ROOT/bin/whexc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

make_case() {
  local mode=$1 name=$2
  local decl=''
  [ "$mode" = default ] || decl="precision_propagation $mode"
  cat >"$TMP/$name.wh" <<SRC
program $name
$decl
input steps: u64
iterate sim limit steps {
    state a: f32 = cast(f32, 16777216.0)
    state b: f64 = 1.0
    state c: f64 = 0.0
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update c = a + b
    update i = i + 1
    result c
}
publish sim
SRC
}

make_case default default_low
make_case 0 explicit_low
make_case 1 explicit_high
for n in default_low explicit_low explicit_high; do
  "$CC" "$TMP/$n.wh" -o "$TMP/$n" >/dev/null
  "$TMP/$n" 1 >"$TMP/$n.out"
  objdump -d -M intel "$TMP/$n" >"$TMP/$n.dis"
done
# Omitted policy and explicit zero are exactly the historical low-dominant rule.
grep -q 'out00_bits=0x000000004b800000' "$TMP/default_low.out"
grep -q 'out00_bits=0x000000004b800000' "$TMP/explicit_low.out"
grep -q 'cvtsd2ss' "$TMP/explicit_low.dis"
grep -q 'vaddss\|addss' "$TMP/explicit_low.dis"
# Policy one mirrors only the real meet edge and returns f64.
grep -q 'out00_bits=0x4170000010000000' "$TMP/explicit_high.out"
grep -q 'cvtss2sd' "$TMP/explicit_high.dis"
grep -q 'vaddsd\|addsd' "$TMP/explicit_high.dis"

# High propagation must not tunnel downward through a naturally-f32 child.
# (16777216f + 1f) rounds to 16777216f first; only then is that ValueFact
# promoted at the outer f64 meet, yielding 16777217 rather than 16777218.
cat >"$TMP/high_nested.wh" <<'SRC'
program high_nested
precision_propagation 1
strict
input steps: u64
iterate sim limit steps {
    state a: f32 = cast(f32, 16777216.0)
    state b: f32 = cast(f32, 1.0)
    state d: f64 = 1.0
    state c: f64 = 0.0
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update d = d
    update c = (a + b) + d
    update i = i + 1
    result c
}
publish sim
SRC
"$CC" "$TMP/high_nested.wh" -o "$TMP/high_nested" >/dev/null
"$TMP/high_nested" 1 >"$TMP/high_nested.out"
grep -q 'out00_bits=0x4170000010000000' "$TMP/high_nested.out"
objdump -d -M intel "$TMP/high_nested" >"$TMP/high_nested.dis"
python3 - "$TMP/high_nested.dis" <<'PY'
import sys
ls=open(sys.argv[1]).read().splitlines()
for i,l in enumerate(ls):
    if 'addss' not in l: continue
    w=ls[i:i+8]
    p=next((j for j,x in enumerate(w) if 'cvtss2sd' in x),None)
    q=next((j for j,x in enumerate(w) if 'addsd' in x),None)
    if p is not None and q is not None and 0 < p < q:
        break
else:
    raise SystemExit('high propagation did not remain local to the consumer edge')
PY

# Precision propagation and strict/tolerant FP are orthogonal contracts.
cat >"$TMP/high_tol.wh" <<'SRC'
program high_tol
precision_propagation 1
tolerance 1e-10
input steps: u64
iterate sim limit steps {
    state a: f32 = cast(f32, 1.0)
    state b: f64 = 2.0
    state c: f64 = 0.0
    state i: u64 = 0
    while i < steps
    update a = a
    update b = b
    update c = a + b
    update i = i + 1
    result c
}
publish sim
SRC
"$CC" "$TMP/high_tol.wh" -o "$TMP/high_tol" >/dev/null
"$TMP/high_tol" 1 | grep -q 'out00_bits=0x4008000000000000'

echo PRECISION_PROPAGATION_SWITCH_1_3_31=PASS
