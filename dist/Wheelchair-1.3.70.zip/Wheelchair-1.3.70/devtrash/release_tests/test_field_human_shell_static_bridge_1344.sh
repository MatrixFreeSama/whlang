#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
cat > "$T/compact.wh" <<'SRC'
program shell_probe
strict
let K = matrix(2, 1.0, 2.0, 3.0, 4.0)
input nx: u64
input ny: u64
input nz: u64
input field u[x in nx periodic, y in ny periodic, z in nz periodic]: f32
output field out[x in nx, y in ny, z in nz]: f32
for x in nx, y in ny, z in nz {
  out[x,y,z] = contract(cell in 2,
      contract(node in 2,
          mget(K,cell,node) * u[x - cell + node,y,z]))
}
SRC
cat > "$T/expanded.wh" <<'SRC'
program shell_probe
strict
input nx: u64
input ny: u64
input nz: u64
input field u[x in nx periodic, y in ny periodic, z in nz periodic]: f32
output field out[x in nx, y in ny, z in nz]: f32
for x in nx, y in ny, z in nz {
  out[x,y,z] = (1.0 * u[x,y,z] + 2.0 * u[x+1,y,z])
             + (3.0 * u[x-1,y,z] + 4.0 * u[x,y,z])
}
SRC
"$CC" "$T/compact.wh" -o "$T/compact" >/dev/null
"$CC" "$T/expanded.wh" -o "$T/expanded" >/dev/null
cmp -s "$T/compact" "$T/expanded"
echo FIELD_HUMAN_SHELL_STATIC_BRIDGE_1_3_44=PASS
