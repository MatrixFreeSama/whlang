#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
case "$(cat VERSION)" in 1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1312.log 2>&1
for marker in \
 WHEELCHAIR_1_3_11_BUILD=PASS \
 GENERAL_CAUSAL_STATE_ROLE_ANALYSIS=BUILT \
 COUNTED_CONTROL_STATE_COLLAPSE=BUILT \
 CONTROL_STATE_CONSUMES_DATA_STATE_BUDGET=0 \
 HARDCODED_TWO_STATE_REGISTER_LIMIT=0 \
 REGISTER_RECURRENCE_DATA_CAPACITY=3 \
 PARALLEL_STATE_TRANSITION=BUILT \
 MANDATORY_STATE_TEMP_SLOT_COMMIT=0 \
 SCALAR_REGISTER_RECURRENCE_TYPES=u64,i64,f32,f64 \
 RUNTIME_STATE_ROLE_MANAGER=0 \
 RUNTIME_REGISTER_SCHEDULER=0 \
 RUNTIME_RECURSION=DEFERRED \
 BLIND_SURPLUS_REFLOW=PRESERVED \
 LOAD_BALANCING_FAMILY=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_12_BUILD=PASS
 do grep -q "^$marker$" .release_build_1312.log; done
echo 'BUILD_1_3_12_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# 1.3.12 is additive. The complete previous authority must remain green first.
devtrash/release_tests/test_release_native_1311.sh
echo 'COMPLETE_1_3_11_RELEASE_AUTHORITY_PRESERVED=PASS'

devtrash/release_tests/test_causal_state_collapse_1312.sh
echo 'GENERAL_1_3_12_AUTHORITY=PASS'

for f in \
 build/topologyc build/topologyc build/topologyc-derived \
 build/topologyc-native256 build/topologyc-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
 done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -R -Eqi '\b(fibonacci|fib_iter|lucas|tribonacci|counter_value)\b' \
 compiler runtime; then
  echo 'RECURRENCE_WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_12.md \
 RELEASE_NOTES_1_3_12.md \
 RELEASE_GATES_1_3_12.txt \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_12.md \
 PERFORMANCE_1_3_12_CAUSAL_STATE_COLLAPSE.md \
 test_causal_state_collapse_1312.sh \
 test_release_native_1312.sh
 do test -s "$f"; done

echo 'NO_RECURRENCE_WORKLOAD_SPECIALIZATION=PASS'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'RUNTIME_STATE_ROLE_MANAGER=0'
echo 'RUNTIME_REGISTER_SCHEDULER=0'
echo 'RUNTIME_RECURSION=DEFERRED'
echo 'BLIND_SURPLUS_REFLOW_PRESERVED=PASS'
echo 'LOAD_BALANCING_FAMILY=0'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_1_3_12_RELEASE=PASS'
