#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -x bin/whexc ] || ./build.sh >/dev/null

# 1. Unused children in the common call AST are explicit zeros.  A unary pure
# function may be composed by another pure function without parser scratch
# becoming a synthetic AST pointer.
cat > "$T/nested-unary.wh" <<'SRC'
program nested_unary_convergence
pure fn magnitude(x: f64) -> f64 = abs(x)
pure fn wrapped(y: f64) -> f64 = magnitude(y)
input x: f64
let out: f64 = wrapped(x)
output out
SRC
bin/whexc "$T/nested-unary.wh" -o "$T/nested-unary" >/dev/null
[ "$("$T/nested-unary" -2.0)" = 'out00_bits=0x4000000000000000' ]

# 2. Composition depth is represented by source structure, not a special stdpf
# count.  This crosses the current 148-helper library without introducing a
# semantic helper threshold.
{
  echo 'program pure_chain_convergence'
  echo 'pure fn f0(x: f64) -> f64 = abs(x)'
  for ((i=1;i<512;i++)); do echo "pure fn f$i(x: f64) -> f64 = f$((i-1))(x)"; done
  echo 'input x: f64'
  echo 'let out: f64 = f511(x)'
  echo 'output out'
} > "$T/chain.wh"
bin/whexc "$T/chain.wh" -o "$T/chain" >/dev/null
[ "$("$T/chain" -2.0)" = 'out00_bits=0x4000000000000000' ]

# 3. Frozen stdpf-1909261354 full import: 148 proof helpers must coexist in one
# human-surface compilation and the resulting dependent-value proof must run.
grep -q '^pure fn pf_value_evidence' devtrash/release_tests/stdpf_1354_full_import.wh
[ "$(grep -c '^pure fn ' devtrash/release_tests/stdpf_1354_full_import.wh)" -eq 148 ]
bin/whexc devtrash/release_tests/stdpf_1354_full_import.wh -o "$T/stdpf-full" >/dev/null
[ "$("$T/stdpf-full" true true)" = 'out00_bits=0x0000000000000001' ]

# 4. Scientific notation is one decimal-literal family across every current
# base/derived and native512/native256 consumer.  No library-specific spelling
# or alternate parser is admitted.
cat > "$T/scientific.wh" <<'SRC'
program scientific_literal_convergence
strict
let x: f64 = 1e-13
publish x
SRC
for C in topologyc topologyc-derived topologyc-native256 topologyc-derived-native256; do
  bin/$C "$T/scientific.wh" -o "$T/$C" >/dev/null
  [ "$("$T/$C")" = 'out00_bits=0x3d3c25c268497682' ]
done

echo PURE_COMPOSITION_CONVERGENCE_1_3_60=PASS
