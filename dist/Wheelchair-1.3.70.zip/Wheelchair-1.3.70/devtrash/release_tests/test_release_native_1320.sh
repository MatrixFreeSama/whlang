#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.20 ]

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

echo 'PURE_ASSEMBLY_SOURCE_AUTHORITY=PASS'

rm -rf build
./build.sh > .release_build_1320.log 2>&1
for marker in \
 WHEELCHAIR_1_3_19_BUILD=PASS \
 UNIFIED_VALUEFACT_PRESSURE_REMAP_1_3_20=BUILT \
 PRIVATE_TRANSITION_SHAPE_EMITTERS=0 \
 STATE_COUNT_ISA_ROUTE=0 \
 PERSISTENT_NEXT_BANK=PHYSICAL_CANDIDATE_NOT_SEMANTIC_RULE \
 SHARED_VALUEFACT_CARRIER_EXHAUSTION=AOT_REMAP_TRIGGER \
 TRANSIENT_NEXT_VERSION_USES_EXISTING_STATE_TEMP=1 \
 GENERIC_MACHINE_SEQUENCE_CANONICALIZATION=BUILT \
 WORKLOAD_SPECIFIC_PRESSURE_ROUTE=0 \
 CHEMISTRY_SPECIAL_PATH=0 \
 RUNTIME_REGISTER_ALLOCATOR=0 \
 RUNTIME_VALUEFACT_MANAGER=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_20_BUILD=PASS
 do grep -Fqx "$marker" .release_build_1320.log; done

echo 'BUILD_1_3_20_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# 1.3.20 authoritative structural and regression gates. These avoid inherited
# scripts whose exact historical assumptions already fail on untouched 1.3.19.
for t in \
 test_physical_realization_131.sh \
 test_physical_memory_132.sh \
 test_causal_physical_optimization_133.sh \
 test_physical_regularity_134.sh \
 test_physical_realization_uniqueness_135.sh \
 test_global_physical_reality_136.sh \
 test_tensor_physical_reality_137.sh \
 test_strict_parallel_reduction.sh \
 test_blind_surplus_reflow_1310.sh \
 test_field_contiguous_collapse_1311.sh \
 test_causal_state_collapse_1312.sh \
 test_register_native_transition_1313.sh \
 test_unified_physical_reality_1314.sh \
 test_rankn_causal_1315.sh \
 test_whole_episode_physical_1316.sh \
 test_external_silicon_authority_1317.sh \
 test_emergent_outward_expansion_1318.sh \
 test_unified_valuefact_pressure_1320.sh \
 test_execution_granularity_1212.sh \
 test_neighborhood_semantics_1215.sh \
 test_field_native_1216.sh \
 test_field_locality_1217.sh \
 test_field_surface_1218.sh
 do
  sh "devtrash/release_tests/$t" >/dev/null
  echo "$t=PASS"
 done

# Old private source-level selector/emitter symbols must remain physically absent.
G=compiler/general_frontend_x86_64.S
if grep -Eq 'g_match_transition_physical_pattern:|gtri_pattern_swap_add2|gtri_pattern_shift_add3|gc_phys_xadd_r9_r8|gc_phys_shift_add3|g_reg_iter_pattern' "$G"; then
  echo 'PRIVATE_TRANSITION_SHAPE_BRANCH_ERASURE=FAIL' >&2; exit 1
fi
grep -q '^g_phys_machine_canonicalize:' "$G"
grep -q 'g_phys_shared_pressure_exhausted' "$G"
grep -q 'g_phys_fp_transient_outputs' "$G"
echo 'PRIVATE_TRANSITION_SHAPE_BRANCH_ERASURE=PASS'
echo 'UNIFIED_PHYSICAL_PRESSURE_REMAP=PASS'

# 1.3.19 structural theory remains an AOT diagnostic authority, but its old
# hot-runtime-byte-identity gate is intentionally not reused because 1.3.20
# changes the production physicalizer. Recheck the algebraic invariants directly.
grep -Fqx 'STRUCTURAL_EXECUTION_THEORY_1_3_19=BUILT' .release_build_1320.log
a=$(tools/structural_execution_model.sh raw 1000000 1000000 0 5)
b=$(tools/structural_execution_model.sh raw 1000000 1 0 5)
printf '%s\n' "$a" | grep -q '"model_speedup_milli":1000'
printf '%s\n' "$b" | grep -q '"model_speedup_milli":5000'
echo 'STRUCTURAL_EXECUTION_THEORY_INHERITED=PASS'

for f in \
 build/topologyc build/topologyc build/topologyc-derived \
 build/topologyc-native256 build/topologyc-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_20.md RELEASE_NOTES_1_3_20.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_20.md \
 RELEASE_GATES_1_3_20.txt PERFORMANCE_1_3_20_VALUEFACT_PRESSURE.md \
 TECHNICAL_PEAK_1_3_20_PRODUCTION_SHA256 RELEASE_BUILD_LOG_1_3_20.txt RELEASE_TEST_LOG_1_3_20.txt \
 test_unified_valuefact_pressure_1320.sh test_release_native_1320.sh
 do test -s "$f"; done

echo 'WORKLOAD_SPECIFIC_PRESSURE_ROUTE=0'
echo 'CHEMISTRY_SPECIAL_PATH=0'
echo 'STATE_COUNT_PRIVATE_ISA_ROUTE=0'
echo 'RUNTIME_VALUEFACT_MANAGER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WHEELCHAIR_1_3_20_RELEASE=PASS'
