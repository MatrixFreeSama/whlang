#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
one() {
  local name=$1 expr=$2 bits=$3
  cat >"$TMP/$name.wh" <<SRC
program fusion_$name
let x: f64 = $expr
output x = x
SRC
  "$CC" "$TMP/$name.wh" -o "$TMP/$name" >/dev/null
  [ "$("$TMP/$name")" = "out00_bits=$bits" ]
}

# Old contractual projections remain bit-identical.
one exp_old 'exp(1.0)' 0x4005bf0a8b145769
one gamma_old 'gamma(5.0)' 0x4037fffffffffff6
one factorial_old 'factorial(5.0)' 0x405e000000000016
one cabs_old 'cabs(complex(3.0,4.0))' 0x4014000000000000

# Shared q coordinate preserves tiny expm1 information.
one expm1_tiny 'expm1(0.0000000000000001)' 0x3c9cd2b297d889bc
# Kahan correction preserves tiny log1p information.
one log1p_tiny 'log1p(0.0000000000000001)' 0x3c9cd2b297d889bc
# Removable singularity is a sparse dataflow identity.
one sinc_zero 'sinc(0.0)' 0x3ff0000000000000
# Scaled norm is shared by scalar and complex surfaces.
one hypot_345 'hypot(3.0,4.0)' 0x4014000000000000
# Log-domain Gamma-family ratios stay finite where direct Gamma products overflow.
one lgamma_200 'lgamma(200.0)' 0x408acf7827e2ba8f
one beta_100 'beta(100.0,100.0)' 0x3356b73dc3216bd7
# Complement tail is emitted directly rather than 1-erf.
one erfc_5 'erfc(5.0)' 0x3d7b3abf8df0da8a

SRC="$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^s_expand_exp_seed_q_ast:' "$SRC"
grep -q '^s_expand_log1p_ast:' "$SRC"
grep -q '^s_expand_erf_tail_ast:' "$SRC"
grep -q '^s_expand_lanczos_core_ast:' "$SRC"
grep -q '^s_expand_scaled_hypot_ast:' "$SRC"
grep -q 'OP_SELECT owns SN_C as its false dataflow edge' "$SRC"
grep -A2 '^\.semb_hypot:' "$SRC" | grep -q 's_expand_scaled_hypot_ast'
grep -A6 '^\.semb_cabs:' "$SRC" | grep -q 's_expand_scaled_hypot_ast'
grep -A2 '^\.semb_erfc:' "$SRC" | grep -q 's_expand_erfc_ast'
! grep -RIE --include='*.S' --include='*.inc' 'math_(runtime|scheduler|executor)|algorithm_selector.*math|math.*algorithm_selector' "$ROOT/compiler" "$ROOT/runtime" >/dev/null 2>&1 || exit 1

echo SPARSE_NATIVE_MATHEMATICS_FUSION_1_3_41=PASS
