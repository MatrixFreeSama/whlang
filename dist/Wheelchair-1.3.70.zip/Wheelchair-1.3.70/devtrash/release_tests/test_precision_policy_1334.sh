#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
cat >"$TMP/low.wh" <<'SRC'
program precision_low
precision_propagation 0
let a: f32 = cast(f32, 16777216.0)
let b: f64 = 1.0
let c: f32 = a + b
output c = c
SRC
cat >"$TMP/high.wh" <<'SRC'
program precision_high
precision_propagation 1
let a: f32 = cast(f32, 16777216.0)
let b: f64 = 1.0
let c: f64 = a + b
output c = c
SRC
"$CC" "$TMP/low.wh" -o "$TMP/low" >/dev/null
"$CC" "$TMP/high.wh" -o "$TMP/high" >/dev/null
[ "$("$TMP/low")" = 'out00_bits=0x000000004b800000' ]
[ "$("$TMP/high")" = 'out00_bits=0x4170000010000000' ]
# Since 1.3.55 generated General code is an exact-sized RX trailer mapped by the
# runtime rather than a fixed ELF PT_LOAD code hole.  objdump therefore no longer
# owns the generated code bytes.  The observable precision-policy results above
# are the cross-version invariant; instruction ownership is covered by the
# current General AOT trailer release proof.
echo PRECISION_POLICY_1_3_34=PASS
