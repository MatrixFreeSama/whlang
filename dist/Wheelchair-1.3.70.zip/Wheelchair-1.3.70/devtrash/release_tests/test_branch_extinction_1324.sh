#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1324_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null

# Deleted private branches/compatibility routes must not survive in production source.
! grep -R -nE 'OP_FACTOR2_ACC|OP_FACTOR_GROUP|vec_select_interior_false|expr_is_axis_delta1|g_try_emit_affine_iterate|g_match_affine_update|gc_affine_' \
  compiler runtime --include='*.S' --include='*.inc' >/dev/null 2>&1
! grep -R -nE 'communication_elimination_patch|RUNTIME_COMM_ELIM_OFF' compiler runtime tools >/dev/null 2>&1
! grep -R -nE 'CHUNK_SHIFT[[:space:]]*,[[:space:]]*(14|16)|CHUNK_SIZE[[:space:]]*,[[:space:]]*(16384|65536)' compiler runtime >/dev/null 2>&1
! grep -R -nE 'field_compute_offsets_f32:|field_load_f32:' runtime compiler >/dev/null 2>&1
! grep -n '\$FROZEN\|cp .*devtrash/frozen_native' build.sh >/dev/null 2>&1

echo 'PRIVATE_BRANCH_SOURCE_ERASURE=PASS'
echo 'PRODUCTION_FROZEN_SOURCE_AUTHORITY=0'

# Three terms prove that common-factor admission is not the deleted two-term template.
for C in fieldc fieldc-native256; do
  build/$C devtrash/tests/field_1324/common_factor_three_strict.json -o "$T/${C}_strict" >/dev/null
  build/$C devtrash/tests/field_1324/common_factor_three_tolerant.json -o "$T/${C}_tol" >/dev/null
  cp devtrash/tests/field_133/factor_out_3x5x7.whfld "$T/${C}_strict_out.whfld"
  cp devtrash/tests/field_133/factor_out_3x5x7.whfld "$T/${C}_tol_out.whfld"
  "$T/${C}_strict" devtrash/tests/field_133/factor_a_3x5x7.whfld devtrash/tests/field_133/factor_b_3x5x7.whfld devtrash/tests/field_133/factor_x_3x5x7.whfld "$T/${C}_strict_out.whfld" >/dev/null
  "$T/${C}_tol" devtrash/tests/field_133/factor_a_3x5x7.whfld devtrash/tests/field_133/factor_b_3x5x7.whfld devtrash/tests/field_133/factor_x_3x5x7.whfld "$T/${C}_tol_out.whfld" >/dev/null
  cmp "$T/${C}_strict_out.whfld" "$T/${C}_tol_out.whfld"
done
objdump -D -b binary -m i386:x86-64 -M intel "$T/fieldc-native256_strict" > "$T/strict.dis" 2>/dev/null
objdump -D -b binary -m i386:x86-64 -M intel "$T/fieldc-native256_tol" > "$T/tol.dis" 2>/dev/null
strict_mul=$(grep -c 'vmulps' "$T/strict.dis" || true)
tol_mul=$(grep -c 'vmulps' "$T/tol.dis" || true)
tol_fma=$(grep -c 'vfmadd231ps' "$T/tol.dis" || true)
[ "$strict_mul" -ge 6 ]
[ "$tol_mul" -lt "$strict_mul" ]
[ "$tol_mul" -le 1 ]
[ "$tol_fma" -ge 3 ]
if grep -q 'zmm' "$T/tol.dis"; then echo 'NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1; fi

echo 'COMMON_FACTOR_THREE_TERM_GENERALIZATION=PASS'
echo 'COMMON_FACTOR_FIXED_TERM_COUNT_ROUTE=0'

# High-pressure corpus must gain the same generic contraction.
build/fieldc-native256 devtrash/tests/field_1216/fem_hex8_full_tolerant_133.json -o "$T/high" >/dev/null
objdump -D -b binary -m i386:x86-64 -M intel "$T/high" > "$T/high.dis" 2>/dev/null
high_mul=$(grep -c 'vmulps' "$T/high.dis" || true)
high_fma=$(grep -c 'vfmadd231ps' "$T/high.dis" || true)
[ "$high_mul" -le 600 ]
[ "$high_fma" -ge 1000 ]
echo 'HIGH_PRESSURE_COMMON_FACTOR_CLOSURE=PASS'

# Current AOT grain is a patch derived by the compiler; runtime owns no historical fixed chunk.
grep -q 'ff_chunk_elements' compiler/field_frontend_common_x86_64.S
grep -q 'chunk_elements_patch' runtime/field_runtime_256_x86_64.S
grep -q 'chunk_elements_patch' runtime/field_runtime_512_x86_64.S
grep -q 'chunk_elements_patch' runtime/tensor_runtime_x86_64.S
echo 'AOT_PHYSICAL_LEAF_GRAIN=PASS'

# Frozen regression snapshots may exist, but cannot be production build inputs and are synchronized
# so deleted private code cannot hide there either.
! grep -R -nE 'OP_FACTOR2_ACC|OP_FACTOR_GROUP|vec_select_interior_false|expr_is_axis_delta1|CHUNK_SIZE[[:space:]]*,[[:space:]]*(16384|65536)|CHUNK_SHIFT[[:space:]]*,[[:space:]]*(14|16)' \
  devtrash/frozen_native --include='*.S' --include='*.inc' >/dev/null 2>&1
(cd devtrash/frozen_native && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
echo 'INERT_SNAPSHOT_PRIVATE_BRANCH_LEAK=0'

echo 'WHEELCHAIR_BRANCH_EXTINCTION_1_3_24=PASS'
