#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = 1.3.28 ]
T=${TMPDIR:-/tmp}/wheelchair1328_math_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

# General scalar sqrt is a native unary ValueFact, not libm.
cat > "$T/sqrt_general.wh" <<'SRC'
program sqrt_native
let x: f64 = sqrt(9.0)
output x = x
test () => { x = 3.0 }
SRC
build/wheelchairc "$T/sqrt_general.wh" -o "$T/sqrt_general" >/dev/null
[ "$("$T/sqrt_general")" = 'out00_bits=0x4008000000000000' ]
tools/disassemble_generated.sh "$T/sqrt_general" | grep -q 'sqrtsd'
echo 'GENERAL_NATIVE_SQRT=PASS'

# Tensor f64 sqrt, both production widths.
cat > "$T/sqrt_tensor.whex" <<'SRC'
program sqrt_tensor
input n: u64 range 4..4
field x[i in n]: f64 = cast(f64, i) + 1.0
field y[i in n]: f64 = sqrt(x[i])
sum checksum[i in n]: f64 = y[i]
output checksum
test (4) => { checksum = 6.146264369941973 }
SRC
build/topologyc "$T/sqrt_tensor.whex" -o "$T/sqrt_tensor512" >/dev/null
build/topologyc-native256 "$T/sqrt_tensor.whex" -o "$T/sqrt_tensor256" >/dev/null
[ "$("$T/sqrt_tensor512" 4)" = 'checksum_bits=0x401895c653b5e21e' ]
[ "$("$T/sqrt_tensor256" 4)" = 'checksum_bits=0x401895c653b5e21e' ]
tools/disassemble_generated.sh "$T/sqrt_tensor512" | grep -q 'vsqrtpd.*zmm'
tools/disassemble_generated.sh "$T/sqrt_tensor256" | grep -q 'vsqrtpd.*ymm'
echo 'TENSOR_NATIVE_SQRT_AVX512_AVX2=PASS'

# Materialized Field f32 sqrt must route through the existing field authority.
cat > "$T/sqrt_field.whex" <<'SRC'
program native_field_sqrt
strict
input nx: u64
input ny: u64
input nz: u64
input field a[x in nx, y in ny, z in nz]: f32
sum total[x in nx, y in ny, z in nz]: f32 = sqrt(a[x,y,z])
output total
SRC
build/fieldc "$T/sqrt_field.whex" -o "$T/sqrt_field512" >/dev/null
build/fieldc-native256 "$T/sqrt_field.whex" -o "$T/sqrt_field256" >/dev/null
build/whexc "$T/sqrt_field.whex" -o "$T/sqrt_field_route" >/dev/null
cmp "$T/sqrt_field512" "$T/sqrt_field_route"
IN=devtrash/tests/field_1216/a_3x5x7.whfld
[ "$("$T/sqrt_field512" "$IN")" = 'checksum_f32_bits=0x44348d32' ]
[ "$("$T/sqrt_field256" "$IN")" = 'checksum_f32_bits=0x44348d32' ]
tools/disassemble_generated.sh "$T/sqrt_field512" | grep -q 'vsqrtps.*zmm'
tools/disassemble_generated.sh "$T/sqrt_field256" | grep -q 'vsqrtps.*ymm'
echo 'FIELD_NATIVE_SQRT_AVX512_AVX2=PASS'

# Native linear-reduction semantics erase into the existing reduction DAG.
cat > "$T/linalg.wh" <<'SRC'
program native_linalg
input n: u64 range 4..4
tensor a[i: n]: f64 = cast(f64, i) + 1.0
tensor b[i: n]: f64 = cast(f64, i) * 2.0 + 1.0
reduce d[i: n]: f64 = dot a[i], b[i]
reduce n2[i: n]: f64 = squared_norm a[i]
reduce dsq[i: n]: f64 = squared_distance a[i], b[i]
output d = d
output n2 = n2
output dsq = dsq
test (4) => { d = 50.0, n2 = 30.0, dsq = 14.0 }
SRC
build/wheelchairc "$T/linalg.wh" -o "$T/linalg" >/dev/null
OUT=$("$T/linalg" 4)
printf '%s\n' "$OUT" | grep -qx 'out00_bits=0x4049000000000000'
printf '%s\n' "$OUT" | grep -qx 'out01_bits=0x403e000000000000'
printf '%s\n' "$OUT" | grep -qx 'out02_bits=0x402c000000000000'
echo 'NATIVE_LINEAR_REDUCTION_SEMANTICS=PASS'

# Do not silently fake selected-axis matrix mathematics.
cat > "$T/fake_trace.wh" <<'SRC'
program no_fake_trace
input n: u64 range 4..4
tensor a[i: n]: f64 = cast(f64, i)
reduce t[i: n]: f64 = trace a[i]
output t = t
test (4) => { t = 6.0 }
SRC
set +e
build/wheelchairc "$T/fake_trace.wh" -o "$T/fake_trace" >/dev/null 2>&1
TR=$?
set -e
[ "$TR" -ne 0 ]
echo 'FAKE_MATRIX_TRACE_ROUTE=0'

# Static direct-native proof: no dynamic section and no libm linkage.
for f in "$T/sqrt_general" "$T/sqrt_tensor512" "$T/sqrt_tensor256" "$T/sqrt_field512" "$T/sqrt_field256"; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'LIBM_DEPENDENCY=0'
echo 'MATH_RUNTIME=0'
echo 'MATH_SCHEDULER=0'
echo 'WHEELCHAIR_NATIVE_MATHEMATICS_1_3_28=PASS'
