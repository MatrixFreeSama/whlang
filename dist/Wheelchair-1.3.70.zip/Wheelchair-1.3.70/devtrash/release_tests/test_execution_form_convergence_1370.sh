#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.70" ]
CC=bin/wheelchairc
[ -x "$CC" ] || { echo 'missing bin/wheelchairc' >&2; exit 1; }
TMP=${TMPDIR:-/tmp}/wheelchair_execution_form_1370_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
T=devtrash/tests/execution_form_convergence_1370
P=compiler/physical_reality.inc
S=compiler/surface_lowerer_x86_64.S

# Architecture gates: execution spelling disappears into old iterate facts.
grep -q '^.equ PR_EXECUTION_FORM_CONVERGENCE,1$' "$P"
grep -q '^.equ PR_RECURSIVE_RELATION_TO_CANONICAL_ITERATE,1$' "$P"
grep -q '^.equ PR_RECURSION_SECOND_IR,0$' "$P"
grep -q '^.equ PR_RECURSION_RUNTIME_BACKEND,0$' "$P"
grep -q '^.equ PR_RECURSION_RUNTIME_MEMO_MANAGER,0$' "$P"
grep -q '^.equ PR_RECURSION_ALGORITHM_MATCHER,0$' "$P"
grep -q '^.equ PR_RECURSION_FIXED_ORDER_LIMIT,0$' "$P"
grep -q '^.equ PR_RECURSION_DEPTH_THRESHOLD,0$' "$P"
grep -q '^.equ PR_RECURSION_RUNTIME_SELECTOR,0$' "$P"
grep -q '^s_materialize_recursive_apply:' "$S"
grep -q '^s_emit_collected_iterate_binding:' "$S"

require_power_call() {
  bin=$1
  addr=$(nm -n "$bin" | awk '$3=="rankn_affine_power_u64" {print $1; exit}')
  [ -n "$addr" ]
  python3 - "$bin" "$addr" <<'PY'
import struct,sys
p=sys.argv[1]
a=int(sys.argv[2],16)
needle=b'\x48\xb8'+struct.pack('<Q',a)+b'\xff\xd0'
if needle not in open(p,'rb').read():
    raise SystemExit(1)
PY
}

compile() {
  name=$1
  "$CC" "$T/$name.wh" -o "$TMP/$name" >/dev/null
}

# The classic two-lag sandbag stays deliberately naive at the human surface.
# It must erase into the already-old iterate relation, then reach Rank-N power.
compile naive_two_lag
[ "$("$TMP/naive_two_lag" 0)" = 'out00_bits=0x0000000000000000' ]
[ "$("$TMP/naive_two_lag" 10)" = 'out00_bits=0x0000000000000037' ]
[ "$("$TMP/naive_two_lag" 100)" = 'out00_bits=0x33db76a7c594bfc3' ]
[ "$("$TMP/naive_two_lag" 500000000)" = 'out00_bits=0x3848ac567d65efc5' ]
require_power_call "$TMP/naive_two_lag"

# Reversing the guard/branch orientation is still the same proved relation.
compile reversed_guard
[ "$("$TMP/reversed_guard" 100)" = 'out00_bits=0x33db76a7c594bfc3' ]
objcopy --dump-section .text="$TMP/reversed.text" "$TMP/reversed_guard"
objcopy --dump-section .text="$TMP/naive.text" "$TMP/naive_two_lag"
cmp -s "$TMP/reversed.text" "$TMP/naive.text"

# Same semantic relation, hand-written as explicit state iteration.  Human
# execution spelling must have vanished before machine materialization.
"$CC" devtrash/benchmarks/general_causal_state_1312/fib_iter.wh -o "$TMP/explicit_iter" >/dev/null
objcopy --dump-section .text="$TMP/rec.text" "$TMP/naive_two_lag"
objcopy --dump-section .text="$TMP/iter.text" "$TMP/explicit_iter"
cmp -s "$TMP/rec.text" "$TMP/iter.text"

# A different affine second-order recurrence proves there is no workload-name
# shortcut hidden behind the classic sandbag.
compile affine_two_lag
[ "$("$TMP/affine_two_lag" 10)" = 'out00_bits=0x00000000000023b4' ]
[ "$("$TMP/affine_two_lag" 100)" = 'out00_bits=0xfffffffffffffd3e' ]
[ "$("$TMP/affine_two_lag" 1000000)" = 'out00_bits=0xffffffffff95303a' ]
require_power_call "$TMP/affine_two_lag"

# Structural lag span is semantic data, not a tiny hard-coded order family.
compile lag3
[ "$("$TMP/lag3" 100)" = 'out00_bits=0x924673dfe90e025f' ]
[ "$("$TMP/lag3" 1000000)" = 'out00_bits=0x27b3657682c2b987' ]
require_power_call "$TMP/lag3"
compile lag17
[ "$("$TMP/lag17" 100)" = 'out00_bits=0x00000000000ccd8b' ]
[ "$("$TMP/lag17" 1000000)" = 'out00_bits=0x909a326934fad000' ]
require_power_call "$TMP/lag17"

# Additional immutable parameters survive as ordinary facts; recursion still
# does not acquire a separate parameter/runtime authority.
compile invariant_arg
[ "$("$TMP/invariant_arg" 10 7)" = 'out00_bits=0x00000000000002a6' ]
[ "$("$TMP/invariant_arg" 100 7)" = 'out00_bits=0xb206c2e5b9864d26' ]
require_power_call "$TMP/invariant_arg"

# Zero-flip refusal gates.  A direct dependence on the recurrence axis, a
# non-static lag, or trap-sensitive arithmetic cannot be silently reinterpreted
# as the autonomous wrap-u64 relation.  No generic recursive runtime is grown as
# a fallback just to accept the spelling.
for name in reject_nonautonomous reject_dynamic_lag reject_trap_contract; do
  if "$CC" "$T/$name.wh" -o "$TMP/$name" >/dev/null 2>&1; then
    echo "unproved recursive relation unexpectedly admitted: $name" >&2
    exit 1
  fi
done

# Production source remains free of named-algorithm admission paths, recursion
# runtime/memo authorities, and numeric order/depth thresholds.
! grep -RqsE '(^|[^A-Za-z])(fibonacci|factorial|tribonacci|newton|fft|krylov|stencil)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'recurs(ion|ive).*(order|depth|lag|state).*(threshold|limit)[[:space:]]*=[[:space:]]*[1-9]' compiler runtime surface tools
! grep -RqsE '^recursive_(lowerer|backend|runtime|memo)|^recurrence_(ir|backend|runtime):' compiler runtime surface tools

printf '%s\n' \
  'EXECUTION_FORM_CONVERGENCE=PASS' \
  'NAIVE_RECURSION_TO_CANONICAL_ITERATE=PASS' \
  'REVERSED_GUARD_TEXT_IDENTITY=PASS' \
  'RECURSION_EXPLICIT_ITERATE_TEXT_IDENTITY=PASS' \
  'RANKN_TRANSITION_POWER_FROM_NAIVE_RECURSION=PASS' \
  'STRUCTURAL_LAG_17=PASS' \
  'INVARIANT_ARGUMENT_CONVERGENCE=PASS' \
  'UNPROVED_RECURSION_ZERO_FLIP_REJECTION=PASS' \
  'RECURSION_ALGORITHM_MATCHER=0' \
  'RECURSION_SECOND_IR=0' \
  'RECURSION_RUNTIME_MEMO_MANAGER=0' \
  'RECURSION_FIXED_ORDER_LIMIT=0' \
  'WHEELCHAIR_EXECUTION_FORM_CONVERGENCE_1_3_70=PASS'
