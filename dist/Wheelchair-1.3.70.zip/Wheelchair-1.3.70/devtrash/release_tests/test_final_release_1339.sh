#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

# Inherited release contracts must remain green.
"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1339.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_physical_1339.sh" >/dev/null

grep -q '^1\.3\.39$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_39_BUILD=PASS' "$ROOT/build.sh"
grep -q 'RANKN_PRECISION_PHYSICAL_1_3_39=BUILT' "$ROOT/build.sh"
grep -q 'rankn_precision_x86_64.inc.*scalar-only implementation' "$ROOT/RELEASE_NOTES_1_3_39.md"
grep -q 'C/GMP remains faster' "$ROOT/RELEASE_NOTES_1_3_39.md"
[ ! -e "$ROOT/runtime/rankn_precision_x86_64.inc" ]
[ -e "$ROOT/runtime/rankn_precision_physical_x86_64.inc" ]
if find "$ROOT" -path "$ROOT/devtrash/release_history" -prune -o -type f \( -name '*.S' -o -name '*.inc' \) -print | xargs grep -l 'TYPE_F128\|TYPE_F256\|GTYPE_F128\|GTYPE_F256' >/dev/null 2>&1; then
  echo dedicated-wide-type-survived >&2; exit 1
fi

echo WHEELCHAIR_1_3_39_FINAL_RELEASE=PASS
