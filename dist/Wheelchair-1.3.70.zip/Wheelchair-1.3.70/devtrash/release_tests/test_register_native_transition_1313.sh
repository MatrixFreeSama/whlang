#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25|1.3.26|1.3.27|1.3.28) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1313_peak_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
SRC=compiler/general_frontend_x86_64.S

# 1.3.13 authority is the machine-code peak, not preservation of its temporary
# private architecture. 1.3.14 may recover the same facts through the unified
# Physical Reality path.
! grep -q 'g_match_transition_physical_pattern:' "$SRC"
! grep -q 'gc_phys_xadd_r9_r8' "$SRC"
! grep -q 'gc_phys_shift_add3' "$SRC"
grep -q '^g_phys_machine_canonicalize:' "$SRC"
! grep -Eqi '\b(fibonacci|fib_iter|lucas|tribonacci)\b' "$SRC"
if [ "$(cat VERSION)" = 1.3.13 ]; then
  grep -q 'g_emit_phys_expr:' "$SRC"
else
  grep -q 'g_emit_phys_int_expr_to:' "$SRC"
  grep -q 'g_emit_phys_fp_expr_to:' "$SRC"
  ! grep -q 'g_emit_phys_save_scratch:' "$SRC"
fi

echo 'REGISTER_NATIVE_TRANSITION_PEAK_AUTHORITY=PASS'
echo 'WORKLOAD_NAME_SPECIALIZATION=0'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]
}
F=devtrash/tests/general_causal_state_1312
G=devtrash/tests/general_register_dag_1313
compile_run "$F/fib_iter.wh" fib 1000 'out00_bits=0x0b594dc75cc0604b'
compile_run "$F/lucas.wh" lucas 1000 'out00_bits=0xf0a8e2dd406a618f'
compile_run "$F/tribonacci.wh" tri 1000 'out00_bits=0x4215efb898bc7418'
compile_run "$F/float_recur.wh" float 1000 'out00_bits=0x3fefffff79ea9f6a'
compile_run "$F/counter_value.wh" counter 1000 'out00_bits=0x0000000000079f2c'
compile_run "$G/coupled_wrap.wh" coupled 10 'out00_bits=0xffffffffffd66600'
compile_run "$G/cycle3.wh" cycle3 10 'out00_bits=0x0000000000000002'
compile_run "$G/trap_fallback.wh" trap 10 'out00_bits=0x00000000000000c7'

hot_body() {
  objdump -d -Mintel "$1" | awk '
    /cmp    rbx,rbp/ && !seen { seen=1; next }
    seen && /movabs ds:0x422100/ { exit }
    seen { print }
  '
}
for b in fib lucas tri float counter coupled cycle3; do
  hot_body "$T/$b" > "$T/$b.hot"
  ! grep -Eq '(^|[[:space:]])(push|pop)([[:space:]]|$)' "$T/$b.hot"
  ! grep -Eq '0x462100|0x482100' "$T/$b.hot"
done

grep -q 'xadd   r9,r8' "$T/fib.hot"
grep -q 'xadd   r9,r8' "$T/lucas.hot"
! grep -q 'xadd' "$T/coupled.hot"
grep -q 'imul' "$T/coupled.hot"
# Three-state recurrence remains on the generic register-DAG path; exact
# register-copy spelling is not a semantic/release authority.
grep -q 'add    rdx,r9' "$T/tri.hot"
grep -q 'add    rdx,r10' "$T/tri.hot"

echo 'TRANSITION_PRIVATE_PATTERN_BRANCHES=0'
echo 'GENERIC_MACHINE_SEQUENCE_CANONICALIZATION=PASS'
echo 'GENERIC_NON_PATTERN_REGISTER_DAG=PASS'

if [ "$(cat VERSION)" != 1.3.13 ]; then
  grep -Eq 'v(add|sub|mul)sd' "$T/float.hot"
  ! grep -Eq '[[:space:]]movabs[[:space:]]+rax,' "$T/float.hot"
  echo 'FLOAT_PEAK_RECOVERED_BY_UNIFIED_PHYSICAL_DAG=PASS'
else
  grep -q 'mulsd' "$T/float.hot"
fi

for b in fib tri float counter coupled cycle3; do
  ! grep -Eq '[[:space:]]jmp[[:space:]]' "$T/$b.hot"
done

echo 'ADMITTED_HOT_PUSH_POP=0'
echo 'ADMITTED_HOT_STATE_TEMP_TRAFFIC=0'
echo 'NATIVE_BOTTOM_TEST_BACKEDGE=PASS'
echo 'TRAPPING_INTEGER_SEMANTICS_PRESERVED=PASS'
echo 'RUNTIME_TRANSITION_GRAPH_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'WHEELCHAIR_REGISTER_NATIVE_TRANSITION_1_3_13=PASS'
