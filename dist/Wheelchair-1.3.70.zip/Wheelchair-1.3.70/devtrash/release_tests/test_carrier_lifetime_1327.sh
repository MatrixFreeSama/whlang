#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1327_carrier_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null

echo 'FIELD_CARRIER_LIFETIME_BUILD=PASS'

SRC=compiler/field_frontend_common_x86_64.S
# Old global backup and implicit SIMD0 preload transport are physically extinct.
if grep -Fq 'ff_resident_stack_backup' "$SRC"; then
  echo 'GLOBAL_RESIDENT_STACK_BACKUP_FLAG=FAIL' >&2; exit 1
fi
grep -Fq '.equ FF_PRELOAD_SCRATCH,FF_VREG_BASE' "$SRC"
grep -Fq 'ff_emit_cache_store_from:' "$SRC"
grep -Fq 'ff_cache_last_load_pos' "$SRC"
grep -Fq 'ff_first_resident_clobber_pos' "$SRC"
# Resident regular preload must direct-load to its final carrier and back up from
# that same carrier; the old load-to-SIMD0 -> stack -> resident chain is absent.
sed -n '/\.fcg_regular_value_loop:/,/\.fcg_regular_next:/p' "$SRC" > "$T/preload.s"
if grep -Fq 'xor edx,edx' "$T/preload.s"; then
  echo 'REGULAR_PRELOAD_SIMD0_ALIAS=FAIL' >&2; exit 1
fi
grep -Fq 'call ff_emit_cache_store_from' "$T/preload.s"
grep -Fq 'FF_PRELOAD_SCRATCH' "$T/preload.s"

echo 'REGULAR_PRELOAD_SIMD0_ALIAS=0'
echo 'PRELOAD_PHASE_LIFETIME_AUTHORITY=PASS'

# No application identity may own the production repair.
if grep -RniE 'field_1327|pressure_store_tolerant|density_16x16x16|energy_16x16x16' \
  compiler runtime surface tools build.sh >/dev/null 2>&1; then
  echo 'WORKLOAD_SPECIFIC_CARRIER_ROUTE=FAIL' >&2; exit 1
fi
echo 'WORKLOAD_SPECIFIC_CARRIER_ROUTE=0'

# Regression: two distinct regular resident inputs, arithmetic, store, reduction.
# 1.3.26 could overwrite the first resident with the second during preload.
FIX=devtrash/tests/field_1327
for C in fieldc fieldc-native256; do
  build/$C "$FIX/pressure_store_tolerant.json" -o "$T/$C-probe" >/dev/null
  cp "$FIX/output_template_16x16x16.whfld" "$T/$C-out.whfld"
  [ "$("$T/$C-probe" "$FIX/density_16x16x16.whfld" "$FIX/energy_16x16x16.whfld" "$T/$C-out.whfld")" = 'checksum_f32_bits=0x4441ae02' ]
  cmp "$T/$C-out.whfld" "$FIX/expected_pressure_16x16x16.whfld"
done

echo 'REGULAR_RESIDENT_DISTINCT_INPUT_STORE_ORACLE=PASS'
echo 'AVX512_AVX2_STORE_IDENTITY=PASS'

# 1.3.26 broad sparse capability must remain: a 27-neighbor no-helper kernel
# naturally reaches the high carrier bank without any width-specific route.
build/fieldc devtrash/benchmarks/real_sparse_1326/miniamr27.json -o "$T/amr512" >/dev/null
dd if="$T/amr512" bs=1 skip=$((0x7000)) status=none > "$T/amr512.bin"
objdump -D -b binary -m i386:x86-64 -Mintel "$T/amr512.bin" > "$T/amr512.dis"
grep -Eq 'zmm31' "$T/amr512.dis"
echo 'FULL_CARRIER_BANK_PRESERVED=PASS'

echo 'WHEELCHAIR_FIELD_CARRIER_LIFETIME_1_3_27=PASS'
