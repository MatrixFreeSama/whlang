#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = 1.3.52 ]

./build.sh > /tmp/wheelchair_1352_build_$$.log 2>&1
trap 'rm -f /tmp/wheelchair_1352_build_$$.log' EXIT

grep -Fqx 'WHEELCHAIR_1_3_52_BUILD=PASS' /tmp/wheelchair_1352_build_$$.log
grep -Fqx 'PRODUCTION_BUILD_HISTORY_REPLAY=0' /tmp/wheelchair_1352_build_$$.log
grep -Fqx 'NEW_SOURCE_SEMANTICS_1_3_52=0' /tmp/wheelchair_1352_build_$$.log
grep -Fqx 'NEW_ALGORITHM_FAMILIES_1_3_52=0' /tmp/wheelchair_1352_build_$$.log
grep -Fqx 'NEW_ISA_ROUTES_1_3_52=0' /tmp/wheelchair_1352_build_$$.log

[ -f compiler/physical_reality.inc ]
[ ! -e compiler/physical_reality_136.inc ]
[ ! -e compiler/physical_reality_137.inc ]
[ ! -e compiler/physical_reality_138.inc ]
[ ! -e compiler/json_parser_x86_64.S ]
[ ! -e compiler/physical_vector_shapes.inc ]
[ ! -e tools/relink_native256_mature_128.sh ]

! find compiler runtime tools surface -type f -name '*138*' -print | grep -q .
! grep -RniE '\b(PR|T)138_|physical_reality_138|tensor_(derived_)?frontend_138|tensor_runtime_138' compiler runtime tools surface >/dev/null 2>&1
! grep -Rni 'devtrash/' compiler runtime tools surface >/dev/null 2>&1

[ ! -e build/topologyc-wide ]
[ ! -e build/topologyc-wide-native256 ]
[ ! -e bin/topologyc-wide ]
[ ! -e bin/topologyc-wide-native256 ]
! grep -q '^\.wide:' compiler/native_driver_x86_64.S
! grep -q 'name_wide' compiler/native_driver_x86_64.S

[ "$(wc -l < build.sh)" -lt 300 ]
for f in wheelchairc whexc topologyc topologyc-derived topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  [ -x "bin/$f" ]
  ! readelf -l "bin/$f" | grep -q 'INTERP'
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 8 ]

echo 'PRODUCTION_HISTORICAL_IDENTITY=0'
echo 'PHYSICAL_REALITY_SINGLE_AUTHORITY=PASS'
echo 'DEAD_WIDE_ALIAS=0'
echo 'PRODUCTION_BUILD_HISTORY_REPLAY=0'
echo 'ARCHITECTURE_AGING_1_3_52=PASS'
