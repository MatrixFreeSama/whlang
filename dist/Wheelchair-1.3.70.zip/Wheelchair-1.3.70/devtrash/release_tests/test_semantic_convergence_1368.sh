#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

[ "$(tr -d '\r\n' < VERSION)" = "1.3.68" ]
grep -q '^g_semantic_resolve_symbol:' compiler/general_frontend_x86_64.S
grep -q '^g_semantic_expr_is_pure:' compiler/general_frontend_x86_64.S
grep -q '^g_semantic_json_equal:' compiler/general_frontend_x86_64.S
grep -q '^g_semantic_converge_symbols:' compiler/general_frontend_x86_64.S
grep -q '^.equ PR_HUMAN_SEMANTIC_CONVERGENCE,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_ZERO_FLIP,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_SECOND_IR,0$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_ALGORITHM_MATCHER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_SEMANTIC_CONVERGENCE_FIXED_ROUNDS,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_SEMANTIC_CONVERGENCE_MANAGER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_STRICT_FP_SEMANTIC_REASSOCIATION,0$' compiler/physical_reality.inc

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
for name in direct alias_chain repeated strict_order; do
  ./bin/wheelchairc "devtrash/tests/semantic_convergence_1368/${name}.wh" -o "$TMP/${name}.bin" >/dev/null
  objcopy --only-section=.text -O binary "$TMP/${name}.bin" "$TMP/${name}.text"
done

for name in direct alias_chain repeated; do
  out="$($TMP/${name}.bin 5)"
  grep -q 'out00_bits=0x000000000000000c' <<<"$out"
done
cmp "$TMP/direct.text" "$TMP/alias_chain.text"
cmp "$TMP/direct.text" "$TMP/repeated.text"

strict_out="$($TMP/strict_order.bin)"
grep -q 'out00_bits=0x3ff0000000000000' <<<"$strict_out"
grep -q 'out01_bits=0x0000000000000000' <<<"$strict_out"

# The first proof class must stay narrow: it may erase human aliases and exact
# pure duplicates, but it must not grow state/load/field/axis or reassociation
# into a private optimizer authority.
grep -q 'operation order is preserved' compiler/general_frontend_x86_64.S
! grep -RqsE 'semantic_(newton|fft|fibonacci|stencil|krylov|sort)_|semantic_algorithm_match' compiler runtime surface tools

echo 'SEMANTIC_ALIAS_CONVERGENCE=PASS'
echo 'SEMANTIC_EXACT_TREE_CONVERGENCE=PASS'
echo 'STRICT_FP_ORDER_PRESERVED=PASS'
echo 'HUMAN_FORM_TEXT_IDENTITY=PASS'
echo 'WHEELCHAIR_SEMANTIC_CONVERGENCE_1_3_68=PASS'
