#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_fourier_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_fusion_1341.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_relation_1342.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_precision_fusion_1343.sh" >/dev/null

grep -q '^1\.3\.43$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_43_BUILD=PASS' "$ROOT/build.sh"
grep -q 'ROOT_PRECISION_AUTHORITY=CURRENT_VALUEFACT_REPRESENTATION' "$ROOT/build.sh"
grep -q 'ROOT_NAMED_WIDTH_BRANCHES=0' "$ROOT/build.sh"
grep -q 'root precision assimilation' "$ROOT/README.md"
grep -q 'Root precision assimilation' "$ROOT/WHEELCHAIR_CHARTER_1_3_43.md"
grep -q 'parameterized floating precision into the existing sparse RootRelation' "$ROOT/RELEASE_NOTES_1_3_43.md"
[ -e "$ROOT/ROOT_PRECISION_FUSION_1_3_43.md" ]
[ -e "$ROOT/CORRECTNESS_1_3_43_ROOT_PRECISION_FUSION.md" ]
[ -e "$ROOT/PURE_ASSEMBLY_RELEASE_PROOF_1_3_43.md" ]
[ -e "$ROOT/devtrash/release_history/ROOT_RELATION_1_3_42.md" ]

for f in "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

echo WHEELCHAIR_1_3_43_FINAL_RELEASE=PASS
