#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
C="$ROOT/bin/whexc"
T="$ROOT/devtrash/tests/human_surface_1350"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

compile_run() {
  local src=$1 out=$2 expected=$3
  shift 3
  "$C" "$T/$src" -o "$TMP/$out" >/dev/null
  local got
  got=$("$TMP/$out" "$@" 2>&1)
  grep -Fq "$expected" <<<"$got"
}

# Static source audit: retired human-shell ceilings and the machine-word
# cascade dependency representation may not reappear.
! grep -Eq '\.(equ|set)[[:space:]]+(RANK_MAX|SCOPE_MAX|DECL_MAX|DICT_MAX|DICT_ENTRY_MAX|NESTED_MAX|CASCADE_GOAL_MAX|STRUCT_TEMP_MAX|TYPE_CAPTURE_CAP),' "$ROOT/compiler/surface_lowerer_x86_64.S"
! grep -q 's_cascade_goal_prereq' "$ROOT/compiler/surface_lowerer_x86_64.S"
! grep -q 'cmp rax,1048576' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^s_clone_subst_pure_multi:' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^s_cascade_prereqs_ready:' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q 's_decl_shape_stride_pool' "$ROOT/compiler/surface_lowerer_x86_64.S"

# Arbitrary positive static radix in both human spellings.
compile_run for_radix3.wh for3 'checksum_bits=0x4050800000000000' 4
compile_run each_radix3.whex each3 'checksum_bits=0x4050800000000000' 4

# Rank is no longer Rank-16 storage.  One runtime extent plus static unit axes
# still obeys the current Tensor consumer while ShapeFact-N owns the shape.
compile_run rank80.whex rank80 'checksum_bits=0x4018000000000000' 4

# Pure functions are compile-time lexical relations, not a one-argument or
# sixteen-function syntax tier.  The capture case proves simultaneous, hygienic
# substitution rather than sequential text-like replacement.
compile_run pure80.wh pure80 'out00_bits=0x000000000000004f'
compile_run functions20.wh funcs20 'out00_bits=0x0000000000000014'
compile_run pure_capture.wh purecap 'checksum_bits=0x402c000000000000' 4

# Compile-time structures cross the old independent table ceilings.
compile_run record80.wh record80 'out00_bits=0x000000000000004f'
compile_run dict140.wh dict140 'out00_bits=0x000000000000008b'
compile_run nested40.wh nested40 'out00_bits=0x0000000000000002'

# Cascade no longer stores predecessors in one machine-word mask, and work is
# no longer rejected by the historical 1,048,576 Surface threshold.
compile_run cascade70.wh cascade70 'out00_bits=0x0000000000000001'
compile_run cascade_work_plus1.wh cascadebig 'out00_bits=0x0000000000000000'

echo HUMAN_SURFACE_CONVERGENCE_1_3_50=PASS
