#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -f build/topologyc_core.o ] || ./build.sh >/dev/null

# Production architecture: one GroupFact authority, no fixed group/rank/tile cap,
# no compatibility vectorizer, and no runtime group manager.
grep -q '^.equ GF_VECTOR_IS_DEGENERATE_GROUP,1$' compiler/groupfact.inc
grep -q '^.equ GF_SCALAR_IS_DEGENERATE_VECTOR,1$' compiler/groupfact.inc
grep -q '^.equ GF_FIXED_RANK_CAP,0$' compiler/groupfact.inc
grep -q '^.equ GF_FIXED_EXTENT_CAP,0$' compiler/groupfact.inc
grep -q '^.equ GF_FIXED_GROUP_SIZE,0$' compiler/groupfact.inc
grep -q '^.equ GF_FIXED_TILE_SIZE,0$' compiler/groupfact.inc
grep -q '^.equ GF_RUNTIME_GROUP_MANAGER,0$' compiler/groupfact.inc
grep -q '^.equ GF_COMPATIBILITY_VECTORIZER,0$' compiler/groupfact.inc

for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_derived_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  grep -q 'call synthesize_group_fact' "$f"
  grep -q 'group_logical_rank' "$f"
  grep -q 'group_lane_factor' "$f"
  grep -q 'physical_plan_group_body' "$f"
  grep -q 'physical_plan_group_carriers' "$f"
  ! grep -q 'physical_tensorized' "$f"
  ! grep -q 'physical_plan_unroll' "$f"
  ! grep -q 'physical_plan_carriers' "$f"
done

# Exercise the production GroupFact synthesizer directly. topologyc_core.o owns
# the real implementation; this harness supplies only unrelated link stubs.
cat > "$T/group_harness.S" <<'ASM'
.intel_syntax noprefix
.include "compiler/groupfact.inc"
.equ SYS_exit,60
.extern synthesize_group_fact
.extern group_logical_rank
.extern group_relation_mask
.extern group_lane_factor
.extern group_rank
.extern group_form
.extern group_body_factor
.extern group_carrier_factor
.extern group_cardinality_exact
.extern group_cardinality
.extern schedule_unroll
.extern schedule_carriers
.section .text
.global group_test_start
group_test_start:
    # scalar = rank0, one lane, one body, one carrier
    mov dword ptr [rip+group_logical_rank],0
    mov dword ptr [rip+group_relation_mask],0
    mov dword ptr [rip+group_lane_factor],1
    mov dword ptr [rip+schedule_unroll],1
    mov dword ptr [rip+schedule_carriers],1
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],0; jne fail1
    cmp dword ptr [rip+group_form],GF_FORM_SCALAR; jne fail1

    # vector = one structural axis; the lane factor is a physical realization
    # of that axis, not a second semantic axis.
    mov dword ptr [rip+group_logical_rank],1
    mov dword ptr [rip+group_relation_mask],GF_REL_INDEPENDENT
    mov dword ptr [rip+group_lane_factor],8
    mov dword ptr [rip+schedule_unroll],1
    mov dword ptr [rip+schedule_carriers],1
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],1; jne fail2
    cmp dword ptr [rip+group_form],GF_FORM_VECTOR; jne fail2

    # Rank-2 logical geometry is a real group.
    mov dword ptr [rip+group_logical_rank],2
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],2; jne fail3
    cmp dword ptr [rip+group_form],GF_FORM_GROUP; jne fail3

    # Operation-affine body replication adds a group axis automatically.
    mov dword ptr [rip+group_logical_rank],1
    mov dword ptr [rip+schedule_unroll],2
    mov dword ptr [rip+schedule_carriers],1
    mov dword ptr [rip+group_relation_mask],GF_REL_INDEPENDENT
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],2; jne fail4
    cmp dword ptr [rip+group_form],GF_FORM_GROUP; jne fail4

    # A second recurrence carrier is a group axis only when a reduction
    # relation actually exists. This prevents shape invention from raw width.
    mov dword ptr [rip+schedule_unroll],1
    mov dword ptr [rip+schedule_carriers],2
    mov dword ptr [rip+group_relation_mask],GF_REL_INDEPENDENT
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],1; jne fail5
    cmp dword ptr [rip+group_form],GF_FORM_VECTOR; jne fail5
    or dword ptr [rip+group_relation_mask],GF_REL_REDUCTION
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],2; jne fail6
    cmp dword ptr [rip+group_form],GF_FORM_GROUP; jne fail6

    # No rank table/capacity tier: a large logical rank remains data.
    mov dword ptr [rip+group_logical_rank],65535
    mov dword ptr [rip+group_lane_factor],1
    mov dword ptr [rip+schedule_unroll],1
    mov dword ptr [rip+schedule_carriers],1
    mov dword ptr [rip+group_relation_mask],GF_REL_INDEPENDENT
    call synthesize_group_fact
    cmp dword ptr [rip+group_rank],65535; jne fail7
    cmp dword ptr [rip+group_form],GF_FORM_GROUP; jne fail7

    # Diagnostic cardinality overflow degrades to unknown, never rejection.
    mov dword ptr [rip+group_logical_rank],1
    mov dword ptr [rip+group_lane_factor],0xffffffff
    mov dword ptr [rip+schedule_unroll],0xffffffff
    mov dword ptr [rip+schedule_carriers],0xffffffff
    mov dword ptr [rip+group_relation_mask],GF_REL_REDUCTION
    call synthesize_group_fact
    cmp dword ptr [rip+group_cardinality_exact],0; jne fail8

    xor edi,edi
    mov eax,SYS_exit
    syscall
fail1: mov edi,1; jmp die
fail2: mov edi,2; jmp die
fail3: mov edi,3; jmp die
fail4: mov edi,4; jmp die
fail5: mov edi,5; jmp die
fail6: mov edi,6; jmp die
fail7: mov edi,7; jmp die
fail8: mov edi,8
die: mov eax,SYS_exit; syscall

# Unrelated topology compiler dependencies, never called by this harness.
.global compile_general_source
compile_general_source: ret
.global compile_tensor_source
compile_tensor_source: ret
.global load_outward_materialization_ticks
load_outward_materialization_ticks: ret
.global surface_lower_to_json
surface_lower_to_json: ret
ASM
as --64 "$T/group_harness.S" -I "$ROOT" -o "$T/group_harness.o"
ld -nostdlib -static -z noexecstack -e group_test_start \
  build/topologyc_core.o "$T/group_harness.o" -o "$T/group_harness"
"$T/group_harness"

echo AUTOMATIC_GROUPING_1_3_61=PASS
