#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.22 ]

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
echo 'PURE_ASSEMBLY_SOURCE_AUTHORITY=PASS'

rm -rf build
./build.sh > .release_build_1322.log 2>&1
for marker in \
 WHEELCHAIR_1_3_21_BUILD=PASS \
 PREDICATE_VALUEFACT_PERSISTENCE_1_3_22=BUILT \
 REPEATED_PREDICATE_REEVALUATION_WITHOUT_VERSION_CHANGE=0 \
 PREDICATE_REPEAT_MAGIC_THRESHOLD=0 \
 PREDICATE_REUSE_DEPENDENCY=AOT_PHYSICAL_DAG \
 FIXED_BOUNDARY_SELECT_MATCHER=0 \
 FIXED_STATE_AFFINE_ITERATE_ROUTE=0 \
 RUNTIME_PREDICATE_MANAGER=0 \
 RUNTIME_VALUEFACT_MANAGER=0 \
 WORKLOAD_SPECIFIC_BOOLEAN_ROUTE=0 \
 ACTIVE_SILICON_PURITY_IS_PRIMARY=1 \
 WHEELCHAIR_1_3_22_BUILD=PASS
 do grep -Fqx "$marker" .release_build_1322.log; done

echo 'BUILD_1_3_22_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

for t in \
 test_physical_realization_131.sh \
 test_physical_memory_132.sh \
 test_causal_physical_optimization_133.sh \
 test_physical_regularity_134.sh \
 test_physical_realization_uniqueness_135.sh \
 test_global_physical_reality_136.sh \
 test_tensor_physical_reality_137.sh \
 test_strict_parallel_reduction.sh \
 test_blind_surplus_reflow_1310.sh \
 test_field_contiguous_collapse_1311.sh \
 test_causal_state_collapse_1312.sh \
 test_register_native_transition_1313.sh \
 test_unified_physical_reality_1314.sh \
 test_rankn_causal_1315.sh \
 test_whole_episode_physical_1316.sh \
 test_external_silicon_authority_1317.sh \
 test_emergent_outward_expansion_1318.sh \
 test_unified_valuefact_pressure_1320.sh \
 test_transport_sparsification_1321.sh \
 test_predicate_sparsification_1322.sh \
 test_execution_granularity_1212.sh \
 test_neighborhood_semantics_1215.sh \
 test_field_native_1216.sh \
 test_field_locality_1217.sh \
 test_field_surface_1218.sh
 do
  sh "devtrash/release_tests/$t" >/dev/null
  echo "$t=PASS"
 done

G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality.inc
grep -q '^g_phys_predicate_equal:' "$G"
grep -q '^g_find_materialized_predicate_fact:' "$G"
grep -q '^g_note_fragment_dependency:' "$G"
grep -q 'PR_PREDICATE_VALUEFACT_PERSISTENCE,1' "$P"
grep -q 'PR_PREDICATE_REPEAT_THRESHOLD,0' "$P"
! grep -R -q 'g_try_emit_affine_iterate\|g_match_affine_update\|gc_affine_' compiler --include='*.S' --include='*.inc'
! grep -R -q 'vec_select_interior_false\|expr_is_axis_delta1' compiler --include='*.S' --include='*.inc'
echo 'PRIVATE_BOOLEAN_AND_FIXED_AFFINE_ROUTES_ERASED=PASS'

for f in \
 build/topologyc build/topologyc build/topologyc-derived \
 build/topologyc-native256 build/topologyc-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_22.md RELEASE_NOTES_1_3_22.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_22.md \
 PERFORMANCE_1_3_22_PREDICATE_SPARSIFICATION.md \
 test_predicate_sparsification_1322.sh test_release_native_1322.sh
 do test -s "$f"; done

echo 'PREDICATE_REPEAT_MAGIC_THRESHOLD=0'
echo 'RUNTIME_PREDICATE_MANAGER=0'
echo 'FIXED_BOUNDARY_SELECT_MATCHER=0'
echo 'FIXED_STATE_AFFINE_ITERATE_ROUTE=0'
echo 'WORKLOAD_SPECIFIC_BOOLEAN_ROUTE=0'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WHEELCHAIR_1_3_22_RELEASE=PASS'
