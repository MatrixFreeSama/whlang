#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
[ "$(cat VERSION)" = 1.3.61 ]
LOG=$(mktemp)
trap 'rm -f "$LOG"' EXIT HUP INT TERM
./build.sh >"$LOG" 2>&1
for gate in \
  ARCHITECTURE_AGING_1_3_56=PASS \
  SHAPEFACT_N_1_3_57=PASS \
  SELECTOR_CONVERGENCE_1_3_58=PASS \
  PHYSICAL_PLAN_CONVERGENCE_1_3_59=PASS \
  PURE_COMPOSITION_CONVERGENCE_1_3_60=PASS \
  AUTOMATIC_GROUPING_1_3_61=PASS \
  GROUP_FIXED_HARD_LIMITS=0 \
  GROUP_RUNTIME_MANAGERS=0 \
  WHEELCHAIR_1_3_61_BUILD=PASS; do
  grep -Fqx "$gate" "$LOG"
done

for t in \
  test_architecture_aging_1356.sh \
  test_shapefact_n_1357.sh \
  test_selector_convergence_1358.sh \
  test_physical_plan_convergence_1359.sh \
  test_pure_composition_convergence_1360.sh \
  test_automatic_grouping_1361.sh \
  test_valuefact_lifetime_1348.sh \
  test_sparse_physical_materialization_1349.sh \
  test_tensor_physical_reality_137.sh \
  test_strict_parallel_reduction.sh; do
  bash "devtrash/release_tests/$t" >/dev/null
done

for f in wheelchairc whexc topologyc topologyc-derived topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  [ -x "bin/$f" ]
  ! readelf -l "bin/$f" | grep -q INTERP
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 8 ]

for f in \
  WHEELCHAIR_CHARTER_1_3_61.md \
  ARCHITECTURE_AGING_1_3_61.md \
  CORRECTNESS_1_3_61_AUTOMATIC_GROUPING.md \
  PERFORMANCE_1_3_61.md \
  RELEASE_NOTES_1_3_61.md \
  PURE_ASSEMBLY_RELEASE_PROOF_1_3_61.md; do
  [ -s "$f" ]
done

! grep -RqsE 'physical_tensorized|physical_plan_unroll|physical_plan_carriers' compiler/tensor_*frontend*.S
! grep -Eq '\.(equ|set)[[:space:]]+.*(MAX|CAP|LIMIT)' compiler/groupfact.inc
grep -q '^.equ GF_COMPATIBILITY_VECTORIZER,0$' compiler/groupfact.inc

echo WHEELCHAIR_1_3_61_FINAL_RELEASE=PASS
