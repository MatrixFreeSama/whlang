#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# Omission and an explicit historical default must lower to the same old graph,
# not merely the same numerical answer.
scalar_equiv() {
  local name=$1 old=$2 explicit=$3
  cat >"$TMP/${name}_old.wh" <<SRC
program optional_iteration_${name}
let x: f64 = $old
output x=x
SRC
  cat >"$TMP/${name}_explicit.wh" <<SRC
program optional_iteration_${name}
let x: f64 = $explicit
output x=x
SRC
  "$CC" "$TMP/${name}_old.wh" -o "$TMP/${name}_old" >/dev/null
  "$CC" "$TMP/${name}_explicit.wh" -o "$TMP/${name}_explicit" >/dev/null
  cmp -s "$TMP/${name}_old" "$TMP/${name}_explicit"
}

scalar_equiv lambertw 'lambertw(1.0)' 'lambertw(1.0,3)'
scalar_equiv erfinv 'erfinv(0.5)' 'erfinv(0.5,2)'
scalar_equiv digamma 'digamma(2.0)' 'digamma(2.0,8)'
scalar_equiv trigamma 'trigamma(2.0)' 'trigamma(2.0,8)'
scalar_equiv zeta 'zeta(2)' 'zeta(2,16)'
scalar_equiv polylog 'polylog(2,0.5)' 'polylog(2,0.5,24)'
scalar_equiv elliptick 'elliptic_k(0.5)' 'elliptic_k(0.5,6)'
scalar_equiv elliptice 'elliptic_e(0.5)' 'elliptic_e(0.5,6)'
scalar_equiv integral 'integral(x,0.0,1.0,x*x)' 'integral(x,0.0,1.0,x*x,1)'
scalar_equiv root 'real(root(x,x*x-2.0,1.0))' 'real(root(x,x*x-2.0,1.0,5))'
scalar_equiv matrixexp 'mget(matrix_exp(matrix2(1.0,0.0,0.0,0.0)),0,0)' 'mget(matrix_exp(matrix2(1.0,0.0,0.0,0.0),12),0,0)'
scalar_equiv matrixlog 'mget(matrix_log(matrix2(2.0,0.0,0.0,1.0)),0,0)' 'mget(matrix_log(matrix2(2.0,0.0,0.0,1.0),9),0,0)'
scalar_equiv matrixsqrt 'mget(matrix_sqrt(matrix2(4.0,0.0,0.0,9.0)),1,1)' 'mget(matrix_sqrt(matrix2(4.0,0.0,0.0,9.0),6),1,1)'
scalar_equiv eigvalues 'component(eig_values(matrix2(4.0,1.0,1.0,3.0)),0)' 'component(eig_values(matrix2(4.0,1.0,1.0,3.0),20),0)'
scalar_equiv eigvectors 'mget(eig_vectors(matrix2(4.0,1.0,1.0,3.0)),0,0)' 'mget(eig_vectors(matrix2(4.0,1.0,1.0,3.0),20),0,0)'
scalar_equiv svdvalues 'component(svd_values(matrix2(3.0,0.0,0.0,4.0)),0)' 'component(svd_values(matrix2(3.0,0.0,0.0,4.0),20),0)'
scalar_equiv svdu 'mget(svd_u(matrix2(3.0,0.0,0.0,4.0)),0,0)' 'mget(svd_u(matrix2(3.0,0.0,0.0,4.0),20),0,0)'
scalar_equiv svdv 'mget(svd_v(matrix2(3.0,0.0,0.0,4.0)),0,0)' 'mget(svd_v(matrix2(3.0,0.0,0.0,4.0),20),0,0)'

# Representative non-default values actually alter the old expansion depth.
cat >"$TMP/custom_scalar.wh" <<'SRC'
program optional_iteration_custom_scalar
let a: f64 = lambertw(1.0,1)
let b: f64 = zeta(2,9)
let c: f64 = polylog(2,0.5,13)
let d: f64 = elliptic_k(0.5,3)
let e: f64 = elliptic_e(0.5,3)
let f: f64 = digamma(2.0,4)
let g: f64 = trigamma(2.0,4)
let h: f64 = erfinv(0.5,1)
let q: f64 = integral(x,0.0,1.0,x*x,2)
let o: f64 = a+b+c+d+e+f+g+h+q
output o=o
SRC
"$CC" "$TMP/custom_scalar.wh" -o "$TMP/custom_scalar" >/dev/null
[ "$("$TMP/custom_scalar")" = 'out00_bits=0x401f82a198cdfb71' ]

cat >"$TMP/custom_matrix.wh" <<'SRC'
program optional_iteration_custom_matrix
let ME = matrix_exp(matrix2(1.0,0.0,0.0,0.0),4)
let ML = matrix_log(matrix2(2.0,0.0,0.0,1.0),3)
let MS = matrix_sqrt(matrix2(4.0,0.0,0.0,9.0),2)
let EV = eig_values(matrix2(4.0,1.0,1.0,3.0),4)
let EX = eig_vectors(matrix2(4.0,1.0,1.0,3.0),4)
let SV = svd_values(matrix2(3.0,0.0,0.0,4.0),4)
let SU = svd_u(matrix2(3.0,0.0,0.0,4.0),4)
let SX = svd_v(matrix2(3.0,0.0,0.0,4.0),4)
let o0: f64 = mget(ME,0,0)+mget(ML,0,0)+mget(MS,1,1)
let o1: f64 = component(EV,0)+mget(EX,0,0)+component(SV,0)+mget(SU,0,0)+mget(SX,0,0)
output o0=o0
output o1=o1
SRC
"$CC" "$TMP/custom_matrix.wh" -o "$TMP/custom_matrix" >/dev/null
[ "$("$TMP/custom_matrix")" = $'out00_bits=0x401b3ed124e59463\nout01_bits=0x402390d790d2db1f' ]

# The soft-coded count is an AOT-static source fact, exactly like root's fourth
# argument; it is not a runtime solver knob.
cat >"$TMP/dynamic_reject.wh" <<'SRC'
program optional_iteration_dynamic_reject
input n: u64
let x: f64 = lambertw(1.0,n)
output x=x
SRC
if "$CC" "$TMP/dynamic_reject.wh" -o "$TMP/dynamic_reject" >/dev/null 2>&1; then
  echo 'runtime iteration selector unexpectedly accepted' >&2
  exit 1
fi

SRCFILE="$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^\.equ MSF_OPTIONAL_ITER,64' "$SRCFILE"
grep -q '^\.equ MATH_DEFAULT_ROOT_ITER,5' "$SRCFILE"
grep -q '^\.equ MATH_DEFAULT_INTEGRAL_PANELS,1' "$SRCFILE"
grep -q '^s_math_iteration_count:' "$SRCFILE"
[ "$(grep -c 'MSF_OPTIONAL_ITER' "$SRCFILE")" -ge 17 ]
! grep -RIE --include='*.S' --include='*.inc' '(root_fp(128|256|512)|matrix_exp_custom|eig_custom|integral_custom|lambertw_custom)' "$ROOT/compiler" "$ROOT/runtime" >/dev/null 2>&1 || exit 1

echo 'OPTIONAL_ITERATION_CONVERGENCE_1_3_53=PASS'
