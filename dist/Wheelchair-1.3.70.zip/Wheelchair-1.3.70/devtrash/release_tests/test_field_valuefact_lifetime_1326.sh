#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1326_field_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

# Current build authority must describe the generic phase-lifetime architecture.
./build.sh >/dev/null

echo 'FIELD_VALUEFACT_PHASE_LIFETIME_BUILD=PASS'

# Production source must not know the benchmark/application identities that exposed
# the missing physical fact.  They belong only to devtrash evidence.
if grep -RniE 'miniAMR|miniFE|CloverLeaf|stencil.?7|stencil.?27|heat21|clover_xacc' \
  compiler runtime surface tools build.sh >/dev/null 2>&1; then
  echo 'WORKLOAD_NAMED_FIELD_ROUTE=FAIL' >&2; exit 1
fi

echo 'WORKLOAD_NAMED_FIELD_ROUTE=0'

SRC=compiler/field_frontend_common_x86_64.S
# Capacity is derived from one physical carrier table, not a 7/10/27 workload width.
grep -Fq 'ff_resident_reg_table_end-ff_resident_reg_table' "$SRC"
grep -Fq 'ff_resident_reg_table: .byte 0,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31' "$SRC"
grep -Fq 'ff_resident_reg_table: .byte 6,7,8,9,10,11,12,13,14,15' "$SRC"

# The deleted old admission rules must not reappear inside the residency allocator.
sed -n '/^ff_assign_resident_loads:/,/^\.farl_ret:/p' "$SRC" > "$T/resident.s"
if grep -E 'cmp[[:space:]]+eax,1|mov[[:space:]].*ff_resident_limit.*,[[:space:]]*0' "$T/resident.s" >/dev/null 2>&1; then
  echo 'OLD_RESIDENCY_QUALIFICATION_BRANCH=FAIL' >&2; exit 1
fi
# 1.3.27 supersedes the coarse global backup flag with emitted-op lifetime facts.
if grep -Fq 'ff_resident_stack_backup' "$SRC"; then
  echo 'GLOBAL_RESIDENT_STACK_BACKUP_FLAG=FAIL' >&2; exit 1
fi
grep -Fq 'ff_cache_last_load_pos' "$SRC"
grep -Fq 'ff_first_resident_clobber_pos' "$SRC"

echo 'OLD_RESIDENCY_QUALIFICATION_BRANCH=0'
echo 'INTEGER_HELPER_GLOBAL_RESIDENCY_KILL=0'
echo 'GLOBAL_RESIDENT_STACK_BACKUP_FLAG=0'

# Compile one established 27-neighbor simulation kernel.  This is structural proof,
# not a benchmark-name route: all admission happened before code generation from
# LoadFact/AddressFact liveness.
build/fieldc devtrash/benchmarks/real_sparse_1326/miniamr27.json -o "$T/amr512" >/dev/null
build/fieldc-native256 devtrash/benchmarks/real_sparse_1326/miniamr27.json -o "$T/amr256" >/dev/null

# The third executable LOAD segment is the generated Field body by the published
# Field ABI.  Disassemble raw bytes because released executables intentionally have
# no section table.
dd if="$T/amr512" bs=1 skip=$((0x7000)) status=none > "$T/gen512.bin"
dd if="$T/amr256" bs=1 skip=$((0x7000)) status=none > "$T/gen256.bin"
objdump -D -b binary -m i386:x86-64 -Mintel "$T/gen512.bin" > "$T/gen512.dis"
objdump -D -b binary -m i386:x86-64 -Mintel "$T/gen256.bin" > "$T/gen256.dis"

grep -Eq 'vmovups[[:space:]]+zmm31\{k1\}\{z\},.*\[rax\+rdx\*4\]' "$T/gen512.dis"
grep -Eq 'ymm15' "$T/gen256.dis"
if grep -q 'zmm' "$T/gen256.dis"; then echo 'NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1; fi

echo 'AVX512_POST_HELPER_HIGH_CARRIER_REALIZATION=PASS'
echo 'AVX2_POST_HELPER_SAFE_CARRIER_REALIZATION=PASS'

# Existing irregular truthfulness remains mandatory: generic direct regular loads
# do not replace real gather/boundary fallback.
sh devtrash/release_tests/test_physical_regularity_134.sh >/dev/null
echo 'IRREGULAR_FALLBACK_TRUTHFULNESS=PASS'

# Small executable smoke in both widths.  The fixture has zero boundary-interior
# checksum for this averaging probe; equality protects execution/ABI while the
# machine-code checks above protect the carrier generalization itself.
for x in "$T/amr512" "$T/amr256"; do
  "$x" devtrash/tests/field_134/lambda_16x16x16.whfld > "$T/run.out"
  grep -Eq '^checksum_f32_bits=0x[0-9a-fA-F]{8}$' "$T/run.out"
done

echo 'REAL_SPARSE_EXECUTION_SMOKE=PASS'
echo 'WORKLOAD_SPECIFIC_FIELD_FAST_PATH=0'
echo 'WHEELCHAIR_FIELD_VALUEFACT_LIFETIME_1_3_26=PASS'
