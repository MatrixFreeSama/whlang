#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
T=${TMPDIR:-/tmp}/wheelchair138_strict_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'STRICT_REDUCTION_BUILD_AUTHORITY=PASS'

for S in runtime/tensor_runtime_x86_64.S devtrash/frozen_native/generated_native256/tensor_runtime_native256_template_x86_64.S; do
  grep -q '^run_causal_tree:' "$S"
  grep -q '^worker_range:' "$S"
  grep -q 'SYS_clone' "$S"
  ! grep -q '^run_tree_strict:' "$S"
  ! grep -q '^try_claim_credit:' "$S"
  ! grep -q 'g_credit_lines' "$S"
done
echo 'STRICT_EXACT_TREE_SOURCE_AUTHORITY=PASS'

SRC=devtrash/benchmarks/fluid_solid_coupling_1212/fsi_coupled.whex
STRICT="$T/fsi_strict.whex"
sed 's/"floating_point":"tolerant"/"floating_point":"strict"/' "$SRC" > "$STRICT"
if cmp -s "$SRC" "$STRICT"; then sed 's/tolerance 1e-8/strict/' "$SRC" > "$STRICT"; fi
grep -Eqi 'strict|"floating_point"[[:space:]]*:[[:space:]]*"strict"' "$STRICT"

for C in topologyc topologyc-native256; do
  for q in 1 2 4; do build/$C "$STRICT" -o "$T/${C}_q$q" >/dev/null; done
  a=$("$T/${C}_q1" 10000000); b=$("$T/${C}_q2" 10000000); c=$("$T/${C}_q4" 10000000)
  [ "$a" = "$b" ]; [ "$a" = "$c" ]
done
echo 'STRICT_EXECUTOR_COUNT_BIT_IDENTITY=PASS'
echo 'STRICT_NATIVE512_BIT_IDENTITY=PASS'
echo 'STRICT_NATIVE256_BIT_IDENTITY=PASS'

# Preserve the former 100M one-ULP repair on both production wide ISAs.
for C in topologyc topologyc-native256; do
  [ "$("$T/${C}_q1" 100000000)" = "$("$T/${C}_q4" 100000000)" ]
done
echo 'STRICT_100M_ONE_ULP_REGRESSION=FIXED'

echo 'STRICT_TRUE_PARALLEL_FABRIC=PRESERVED'
echo 'WORK_STEALING=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_STRICT_PARALLEL_REDUCTION_1_3_8=PASS'
