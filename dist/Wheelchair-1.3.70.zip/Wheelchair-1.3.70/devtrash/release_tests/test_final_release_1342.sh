#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_fourier_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_math_fusion_1341.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_root_relation_1342.sh" >/dev/null

grep -q '^1\.3\.42$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_42_BUILD=PASS' "$ROOT/build.sh"
grep -q 'ROOT_RESULT_TYPE_PREDECLARATION=0' "$ROOT/build.sh"
grep -q 'ROOT_REAL_COMPLEX_SOLVER_FORK=0' "$ROOT/build.sh"
grep -q 'one sparse RootRelation' "$ROOT/RELEASE_NOTES_1_3_42.md"
grep -q 'Sparse root relation' "$ROOT/WHEELCHAIR_CHARTER_1_3_42.md"
[ -e "$ROOT/ROOT_RELATION_1_3_42.md" ]
[ -e "$ROOT/CORRECTNESS_1_3_42_ROOT_RELATION.md" ]
[ -e "$ROOT/PURE_ASSEMBLY_RELEASE_PROOF_1_3_42.md" ]

for f in "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

echo WHEELCHAIR_1_3_42_FINAL_RELEASE=PASS
