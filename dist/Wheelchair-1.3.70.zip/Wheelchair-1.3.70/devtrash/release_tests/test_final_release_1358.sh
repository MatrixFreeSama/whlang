#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
[ "$(cat VERSION)" = 1.3.58 ]
had_build=0; [ -d build ] && had_build=1
cleanup(){ if [ "$had_build" -eq 0 ] && [ "${ALLOW_BUILD_DIR:-0}" != 1 ]; then rm -rf build; fi; }
LOG=/tmp/wheelchair_1358_build_$$.log
cleanup_all(){ rm -f "$LOG"; cleanup; }
trap cleanup_all EXIT HUP INT TERM
./build.sh >"$LOG" 2>&1

grep -Fqx 'ARCHITECTURE_AGING_1_3_55=PASS' "$LOG"
grep -Fqx 'WHEELCHAIR_1_3_55_BUILD=PASS' "$LOG"
grep -Fqx 'ARCHITECTURE_AGING_1_3_56=PASS' "$LOG"
grep -Fqx 'WHEELCHAIR_1_3_56_BUILD=PASS' "$LOG"
grep -Fqx 'SHAPEFACT_N_1_3_57=PASS' "$LOG"
grep -Fqx 'SHAPEFACT_COMPATIBILITY_PRODUCT_DESCRIPTOR=0' "$LOG"
grep -Fqx 'SHAPEFACT_FIXED_CAPACITY=0' "$LOG"
grep -Fqx 'WHEELCHAIR_1_3_57_BUILD=PASS' "$LOG"
grep -Fqx 'SELECTOR_CONVERGENCE_1_3_58=PASS' "$LOG"
grep -Fqx 'WHEELCHAIR_1_3_58_BUILD=PASS' "$LOG"

for t in \
 test_precision_policy_1334.sh \
 test_native_mathematics_1334.sh \
 test_rankn_mathematics_1334.sh \
 test_structured_mathematics_1336.sh \
 test_parametric_rankn_fp_1340.sh \
 test_rankn_precision_fourier_1340.sh \
 test_math_fusion_1341.sh \
 test_root_relation_1342.sh \
 test_root_precision_fusion_1343.sh \
 test_math_generalization_1344.sh \
 test_field_human_shell_1345.sh \
 test_field_human_shell_1346.sh \
 test_avx2_physical_ownership_1347.sh \
 test_valuefact_lifetime_1348.sh \
 test_tensor_physical_reality_137.sh \
 test_sparse_physical_materialization_1349.sh \
 test_human_surface_convergence_1350.sh \
 test_structural_capacity_convergence_1351.sh \
 test_field_locality_1217.sh \
 test_optional_iteration_convergence_1353.sh \
 test_architecture_aging_1354.sh \
 test_architecture_aging_1355.sh \
 test_architecture_aging_1356.sh \
 test_shapefact_n_1357.sh \
 test_selector_convergence_1358.sh
 do
  bash "devtrash/release_tests/$t" >/dev/null
 done

for f in wheelchairc whexc topologyc topologyc-derived topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  [ -x "bin/$f" ]
  ! readelf -l "bin/$f" | grep -q INTERP
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 8 ]

for f in \
 SHAPEFACT_N_1_3_57.md \
 CORRECTNESS_1_3_57_SHAPEFACT_N.md \
 PERFORMANCE_1_3_57.md \
 RELEASE_NOTES_1_3_57.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_57.md \
 WHEELCHAIR_CHARTER_1_3_57.md \
 CORRECTNESS_1_3_58_SELECTOR_CONVERGENCE.md \
 RELEASE_NOTES_1_3_58.md; do
  [ -s "$f" ]
done

# Production authority must not retain the deleted pre-ShapeFact product descriptor.
! grep -RqsE 'rank_n_product|rank_n_source_rank|rank_n_product_patch|RUNTIME_RANK_N_PRODUCT|__rankn_q' \
  compiler runtime tools surface
# The new authority itself must remain sparse and capacity-free.
! grep -Eq '\.(equ|set)[[:space:]]+.*(MAX|CAP|LIMIT)' \
  compiler/shapefact_n.inc compiler/shapefact_n_frontend.inc

echo WHEELCHAIR_1_3_58_FINAL_RELEASE=PASS
