#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
one() {
  local name=$1 expr=$2 bits=$3
  cat >"$TMP/$name.wh" <<SRC
program structured_$name
let x: f64 = $expr
output x = x
SRC
  "$CC" "$TMP/$name.wh" -o "$TMP/$name" >/dev/null
  [ "$("$TMP/$name")" = "out00_bits=$bits" ]
}

# Complex functions, including principal-argument quadrant handling.
one complex_abs 'cabs(complex(3.0,4.0))' 0x4014000000000000
one complex_log_neg_im 'imag(complex_log(complex(-1.0,0.0)))' 0x400921fb54442d18
one complex_sqrt_real 'real(complex_sqrt(complex(3.0,4.0)))' 0x4000000000000001
one complex_sqrt_imag 'imag(complex_sqrt(complex(3.0,4.0)))' 0x3fefffffffffffff

# Small structured dense algebra.
one chol11 'mget(cholesky(matrix2(4.0,1.0,1.0,3.0)),1,1)' 0x3ffa887293fd6f34
one ldlt11 'mget(ldlt_d(matrix2(4.0,2.0,2.0,3.0)),1,1)' 0x4000000000000000
one inv00 'mget(matrix_inverse(matrix2(4.0,1.0,1.0,3.0)),0,0)' 0x3fd1745d1745d174
one mexp00 'mget(matrix_exp(matrix2(1.0,0.0,0.0,0.0)),0,0)' 0x4005bf0a8b145770
one mlog00 'mget(matrix_log(matrix2(2.0,0.0,0.0,1.0)),0,0)' 0x3fe62e42fef8d562
one msqrt11 'mget(matrix_sqrt(matrix2(4.0,0.0,0.0,9.0)),1,1)' 0x4008000000000000
one eig0 'component(eig_values(matrix2(4.0,1.0,1.0,3.0)),0)' 0x401278dde6e5fcea
one eig1 'component(eig_values(matrix2(4.0,1.0,1.0,3.0)),1)' 0x40030e44323406a7
one svd0 'component(svd_values(matrix2(3.0,0.0,0.0,4.0)),0)' 0x400ffffffff3d66e
one svd1 'component(svd_values(matrix2(3.0,0.0,0.0,4.0)),1)' 0x40080000001cd451

# Structured let boundaries must collapse carriers into ordinary old bindings.
cat >"$TMP/structlet.wh" <<'SRC'
program structured_let_old_authority
let A = matrix2(4.0,1.0,1.0,3.0)
let L = cholesky(A)
let B = L * transpose(L)
let x: f64 = mget(B,0,0)
output x = x
SRC
"$CC" "$TMP/structlet.wh" -o "$TMP/structlet" >/dev/null
[ "$("$TMP/structlet")" = 'out00_bits=0x4010000000000000' ]

SRC="$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^\.equ NK_STRUCT,14' "$SRC"
grep -q '^\.equ MB_LAST,96' "$SRC"
grep -q '^s_materialize_struct:' "$SRC"
grep -q 'old scalar compute-binding/ValueFact authority' "$SRC"
! grep -RIE --include='*.S' --include='*.inc' '(^|[^[:alnum:]_])(complex_runtime|matrix_runtime|svd_runtime|eig_runtime)([^[:alnum:]_]|$)' "$ROOT/compiler" "$ROOT/runtime" >/dev/null 2>&1 || exit 1

echo STRUCTURED_MATHEMATICS_1_3_36=PASS
