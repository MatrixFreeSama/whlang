#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)

# Inherited semantic/math contracts.
"$ROOT/devtrash/release_tests/test_precision_policy_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_native_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_mathematics_1334.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_structured_mathematics_1336.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_parametric_rankn_fp_1340.sh" >/dev/null
"$ROOT/devtrash/release_tests/test_rankn_precision_fourier_1340.sh" >/dev/null

# Release identity and current authority.
grep -q '^1\.3\.40$' "$ROOT/VERSION"
grep -q 'WHEELCHAIR_1_3_40_BUILD=PASS' "$ROOT/build.sh"
grep -q 'RANKN_PRECISION_FOURIER_1_3_40=BUILT' "$ROOT/build.sh"
grep -q 'one native mixed-radix Fourier multiplication realization' "$ROOT/RELEASE_NOTES_1_3_40.md"
grep -q '0.839' "$ROOT/PERFORMANCE_1_3_40_NATIVE_FOURIER.md"
[ -e "$ROOT/runtime/rankn_precision_physical_x86_64.inc" ]
[ ! -e "$ROOT/runtime/rankn_precision_x86_64.inc" ]

# Former root release identity is not allowed to masquerade as current state.
for f in "$ROOT"/*1_3_39*; do [ ! -e "$f" ] || { echo stale-root-1.3.39:"$f" >&2; exit 1; }; done

# No dedicated wide-width semantic authority may reappear.
if find "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools" -type f \( -name '*.S' -o -name '*.inc' -o -name '*.sh' \) -print0 | \
   xargs -0 grep -EIl 'TYPE_F(128|256)|GTYPE_F(128|256)|STF_FP(128|256)|wide_float_x86_64' >/dev/null 2>&1; then
  echo dedicated-wide-type-survived >&2; exit 1
fi

# Production tree is native and external-FFT-free.
if find "$ROOT/compiler" "$ROOT/runtime" "$ROOT/surface" "$ROOT/tools" -type f \( -name '*.c' -o -name '*.cc' -o -name '*.cpp' \) | grep -q .; then
  echo production-c-source-survived >&2; exit 1
fi
for f in "$ROOT/bin/wheelchairc" "$ROOT/bin/whexc"; do
  [ -x "$f" ]
  if ldd "$f" 2>&1 | grep -vq 'not a dynamic executable'; then
    echo dynamic-production-compiler:"$f" >&2; exit 1
  fi
done

echo WHEELCHAIR_1_3_40_FINAL_RELEASE=PASS
