#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
export TERM=${TERM:-xterm}
[ "$(cat VERSION)" = 1.3.19 ]

if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

rm -rf build
./build.sh > .release_build_1319.log 2>&1
for marker in \
 WHEELCHAIR_1_3_18_BUILD=PASS \
 STRUCTURAL_EXECUTION_THEORY_1_3_19=BUILT \
 PROGRAM_ORDER_IS_CAUSAL_AUTHORITY=0 \
 EQUAL_CAUSAL_DEPTH_PARALLELISM=AOT_CAUSAL_PARTIAL_ORDER \
 'STRUCTURAL_EXECUTION_MODEL=W/(max(W/P,S)+H)' \
 'STRUCTURAL_EXECUTION_IDEAL=min(P,W/S)' \
 INTRINSIC_CAUSAL_PARALLELISM=W/S \
 W_S_H_OPTIMIZATION_CLASSIFICATION=BUILT \
 AOT_STRUCTURAL_FACT_DIAGNOSTIC=BUILT \
 RUNTIME_CAUSAL_DEPTH_QUEUE=0 RUNTIME_SERIAL_FRACTION_MANAGER=0 \
 RUNTIME_STRUCTURAL_SCHEDULER=0 HARD_CODED_CAUSAL_DEPTH_THRESHOLD=0 \
 STRUCTURAL_EXECUTION_HOT_RUNTIME_DELTA=0 \
 WHEELCHAIR_1_3_19_BUILD=PASS
 do grep -Fqx "$marker" .release_build_1319.log; done
echo 'BUILD_1_3_19_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

devtrash/release_tests/test_release_native_1318.sh >/dev/null
echo 'COMPLETE_1_3_18_RELEASE_AUTHORITY_PRESERVED=PASS'
WC1319_REUSE_BUILD=1 devtrash/release_tests/test_structural_execution_1319.sh

sha256sum -c TECHNICAL_PEAK_1_3_18_PRODUCTION_SHA256 >/dev/null
echo 'STRUCTURAL_EXECUTION_HOT_RUNTIME_DELTA=0'

for f in \
 build/topologyc build/topologyc build/topologyc-derived \
 build/topologyc-native256 build/topologyc-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
 do readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'; done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -R -n -E 'causal[_ -]?depth[_ -]?(queue|scheduler|manager)|serial[_ -]?fraction[_ -]?(queue|scheduler|manager)' \
 runtime compiler --include='*.S' >/dev/null 2>&1; then
  echo 'RUNTIME_STRUCTURAL_MANAGER_LEAK=FAIL' >&2; exit 1
fi

for f in \
 WHEELCHAIR_CHARTER_1_3_19.md RELEASE_NOTES_1_3_19.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_19.md \
 RELEASE_GATES_1_3_19.txt PERFORMANCE_1_3_19_STRUCTURAL_EXECUTION.md \
 PERFORMANCE_1_3_19_STRUCTURAL_SCALING.csv PERFORMANCE_1_3_19_FSI_STRONG_RAW.csv \
 PERFORMANCE_1_3_19_FSI_WEAK_RAW.csv PERFORMANCE_1_3_19_REMATCH_SUMMARY.csv \
 TECHNICAL_PEAK_1_3_18_PRODUCTION_SHA256 tools/structural_execution_model.sh \
 test_structural_execution_1319.sh test_release_native_1319.sh
 do test -s "$f"; done

echo 'PROGRAM_ORDER_IS_NOT_CAUSAL_AUTHORITY=PASS'
echo 'EQUAL_CAUSAL_DEPTH_PARALLELISM=PASS'
echo 'STRUCTURAL_EXECUTION_W_S_H_MODEL=PASS'
echo 'INTRINSIC_CAUSAL_PARALLELISM_W_OVER_S=PASS'
echo 'W_S_H_OPTIMIZATION_CLASSIFICATION=PASS'
echo 'AOT_STRUCTURAL_FACT_DIAGNOSTIC=PASS'
echo 'RUNTIME_CAUSAL_DEPTH_QUEUE=0'
echo 'RUNTIME_SERIAL_FRACTION_MANAGER=0'
echo 'RUNTIME_STRUCTURAL_SCHEDULER=0'
echo 'HARD_CODED_CAUSAL_DEPTH_THRESHOLD=0'
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'WHEELCHAIR_1_3_19_RELEASE=PASS'
