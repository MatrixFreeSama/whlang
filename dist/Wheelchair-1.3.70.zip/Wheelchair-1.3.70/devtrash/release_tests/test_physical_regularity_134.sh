#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair134_regularity_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'PHYSICAL_REGULARITY_BUILD_AUTHORITY=PASS'

J=devtrash/tests/field_1216/fem_hex8_full_tolerant_133.json
JS=devtrash/tests/field_1216/fem_hex8_full.json
F=devtrash/tests/field_134

# Compile one dynamic-shape binary per contract.  The 16^3 fixture has a real
# vector interior and zero values, so direct and boundary paths can be checked
# without introducing a workload-specific numerical oracle.
for C in fieldc-native256 fieldc; do
  build/$C "$J" -o "$T/$C-tol" >/dev/null
  build/$C "$JS" -o "$T/$C-strict" >/dev/null
  for mode in tol strict; do
    for i in 0 1 2; do cp "$F/o${i}_16x16x16.whfld" "$T/$C-$mode-o$i.whfld"; done
    out=$("$T/$C-$mode" \
      "$F/lambda_16x16x16.whfld" "$F/mu_16x16x16.whfld" \
      "$F/p0_16x16x16.whfld" "$F/p1_16x16x16.whfld" "$F/p2_16x16x16.whfld" \
      "$T/$C-$mode-o0.whfld" "$T/$C-$mode-o1.whfld" "$T/$C-$mode-o2.whfld")
    [ "$out" = 'checksum_f32_bits=0x00000000' ]
  done
done
echo 'REGULAR_INTERIOR_BOUNDARY_EQUIVALENCE=PASS'
echo 'STRICT_FP_ADDRESS_OPTIMIZATION=PASS'

# Inspect generated code directly. Release images erase section headers, so the
# .generated payload begins at the frozen 0x8000 file offset.
dd if="$T/fieldc-native256-tol" of="$T/tol256.bin" bs=1 skip=$((0x8000)) status=none
dd if="$T/fieldc-native256-strict" of="$T/strict256.bin" bs=1 skip=$((0x8000)) status=none
objdump -D -b binary -m i386:x86-64 -Mintel "$T/tol256.bin" > "$T/tol256.S" 2>/dev/null
objdump -D -b binary -m i386:x86-64 -Mintel "$T/strict256.bin" > "$T/strict256.S" 2>/dev/null

# The direct regular episode must physically exist and be ordinary vector loads.
maskloads=$(grep -ci 'vmaskmovps' "$T/tol256.S" || true)
gathers=$(grep -ci 'vgather' "$T/tol256.S" || true)
[ "$maskloads" -ge 90 ]
# The fully general authority must remain present for boundary / genuinely
# irregular layouts; 1.3.4 never deletes truthful gather capability.
[ "$gathers" -ge 90 ]
if grep -qi 'zmm' "$T/tol256.S"; then echo 'NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1; fi
echo "REGULAR_DIRECT_VECTOR_LOADS=$maskloads"
echo "GENERAL_GATHER_FALLBACK_SITES=$gathers"
echo 'REGULAR_INTERIOR_GATHER=0'
echo 'GENERIC_GATHER_FALLBACK_PRESERVED=PASS'
echo 'NATIVE256_ZMM=0'

# Tolerant factor pairs now use mul + FMA + FMA. Strict preserves the original
# recurrence and must never acquire contraction from this release.
tfma=$(grep -ci 'vfmadd' "$T/tol256.S" || true)
tmul=$(grep -ci 'vmulps' "$T/tol256.S" || true)
tadd=$(grep -ci 'vaddps' "$T/tol256.S" || true)
sfma=$(grep -ci 'vfmadd' "$T/strict256.S" || true)
smul=$(grep -ci 'vmulps' "$T/strict256.S" || true)
[ "$tfma" -ge 1000 ]
[ "$tmul" -lt 700 ]
[ "$tadd" -lt 100 ]
[ "$sfma" -eq 0 ]
[ "$smul" -ge 2000 ]
echo "TOLERANT_FMA_SITES=$tfma"
echo "TOLERANT_MUL_SITES=$tmul"
echo "TOLERANT_ADD_SITES=$tadd"
echo 'WIDE_FACTOR_FMA_COVER=PASS'
echo 'FMA_WIDTH_PRESERVATION=PASS'
echo 'STRICT_FP_REASSOCIATION=0'

# Source-structural authority: the regular preload block can call only the
# fixed-displacement emitter; gather is confined to the later general fallback.
sed -n '/\.fcg_regular_value_loop:/,/\.fcg_regular_done:/p' compiler/field_frontend_common_x86_64.S > "$T/regular_source.txt"
if grep -q 'direct_gather' "$T/regular_source.txt"; then echo 'REGULAR_PATH_GATHER_LEAK=FAIL' >&2; exit 1; fi
sed -n '/ff_emit_direct_regular_load:/,/^# edi=field\.  Coordinate offset vector/p' compiler/field_frontend_common_x86_64.S | sed '$d' > "$T/direct_source.txt"
if grep -q 'vgather\|direct_gather' "$T/direct_source.txt"; then echo 'REGULAR_EMITTER_GATHER_LEAK=FAIL' >&2; exit 1; fi
echo 'FIXED_DISPLACEMENT_VECTOR_LOAD=PASS'
echo 'PHYSICAL_SIMD_CONTIGUOUS_AXIS=PASS'
echo 'ISA_ADDRESS_MODE_COVER=PASS'

# Existing padded / strided tests are the negative control: a non-contiguous
# input must remain on the generic physical path and produce the historical bits.
build/fieldc-native256 devtrash/tests/field_1216/mixed.json -o "$T/mixed" >/dev/null
cp devtrash/tests/field_1216/out_3x5x7.whfld "$T/mixed-out.whfld"
[ "$("$T/mixed" devtrash/tests/field_1216/a_3x5x7.whfld devtrash/tests/field_1216/bpad_3x5x7.whfld "$T/mixed-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
cmp "$T/mixed-out.whfld" devtrash/tests/field_1216/expected_mixed_3x5x7.whfld
echo 'MIXED_REGULAR_IRREGULAR_FIELD=PASS'
echo 'IRREGULAR_GATHER_PRESERVED=PASS'

if grep -RniE 'Taichi|SPGrid|compute_Ap|elasticity|fem_hex8|benchmark[_ -]*mode' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
echo 'NO_FEM_SPECIAL_CASE=PASS'
echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'PHYSICAL_REGULARITY_FIDELITY=PASS'
echo 'WHEELCHAIR_PHYSICAL_REGULARITY_COLLAPSE_1_3_4=PASS'
