#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# Production source invariants: the 1.3.38 scalar-only file is gone. The new
# common authority owns scalar fallback, Rank-N span materialization, IFMA
# product-plane realization and Knuth division in one width-parameterized file.
[ ! -e "$ROOT/runtime/rankn_precision_x86_64.inc" ]
SRC="$ROOT/runtime/rankn_precision_physical_x86_64.inc"
[ -f "$SRC" ]
grep -q '^\.global rankn_fp_mul_span' "$SRC"
grep -q '^\.global rankn_fp_mul_batch8' "$SRC"
grep -q 'vpmadd52luq' "$SRC"
grep -q 'vpmadd52huq' "$SRC"
grep -q 'Base-2\^32 Knuth digit division' "$SRC"
grep -q 'former bit-by-bit restoring path is intentionally absent' "$SRC"
grep -q 'Structural cost comparison for Rank-N multiplication physicalization' "$SRC"
! grep -q '^\.rpfd_bit_loop:' "$SRC"
! grep -q '^\.rpfms_prop:' "$SRC"
# No named precision switch is allowed in the physical selector.
if sed -n '/rpf_mul_batch_cost_wins:/,/^    ret$/p' "$SRC" | grep -Eq 'cmp[^#]*(65|73|113|127|128|191|256|257|512|521|1024|2048|3072|4096)'; then
  echo named-precision-threshold-survived >&2; exit 1
fi

cat >"$TMP/wrap.S" <<EOF
.intel_syntax noprefix
.text
.include "$SRC"
.section .note.GNU-stack,"",@progbits
EOF
gcc -c -x assembler-with-cpp "$TMP/wrap.S" -o "$TMP/wrap.o"

cat >"$TMP/oracle.c" <<'C'
#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern int rankn_fp_mul(void*,void*,void*,uint32_t);
extern int rankn_fp_div(void*,void*,void*,uint32_t);
extern int rankn_fp_mul_batch8(void**,void**,void**,uint32_t,void*);
extern int rankn_fp_mul_span(void**,void**,void**,uint32_t,uint64_t,void*);
#define FLAG 0x40000000u
#define GUARD 256
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t os(unsigned p){unsigned n=(p+63)/64;return ((136ull*n+1056+63)/64)*64;}
static size_t ss(unsigned p){unsigned n52=(p+51)/52,n64=(p+63)/64,pc=2*n52+4;return (size_t)n52*64*2+(size_t)pc*64+(size_t)pc*8+(size_t)(2*n64+4)*8+4096;}
static void* al(size_t z){unsigned char*q=aligned_alloc(64,(z+GUARD+63)&~63ull);if(!q)abort();memset(q,0,z);memset(q+z,0xa5,GUARD);return q;}
static int guard(void*v,size_t z){unsigned char*q=v;for(int i=0;i<GUARD;i++)if(q[z+i]!=0xa5)return 0;return 1;}
static void init(void*vv,unsigned p,uint64_t seed,int sign){unsigned char*o=vv;unsigned n=(p+63)/64;memset(o,0,os(p));*(uint32_t*)o=FLAG|p;*(uint32_t*)(o+4)=p;*(uint32_t*)(o+8)=n;*(uint64_t*)(o+16)=sign;*(int64_t*)(o+24)=p-1;uint64_t*L=(uint64_t*)(o+32);for(unsigned i=0;i<n;i++)L[i]=sm(&seed);unsigned top=p-64*(n-1);if(top<64)L[n-1]&=(1ULL<<top)-1;L[n-1]|=1ULL<<(top-1);}
static void hx(void*v,unsigned p){unsigned n=(p+63)/64;uint64_t*L=(uint64_t*)((unsigned char*)v+32);for(int i=(int)n-1;i>=0;i--)printf("%016llx",(unsigned long long)L[i]);}
static void out(const char*tag,unsigned p,int lane,void*a,void*b,void*d){printf("%s %u %d %llu ",tag,p,lane,(unsigned long long)*(uint64_t*)((char*)a+16));hx(a,p);printf(" %llu ",(unsigned long long)*(uint64_t*)((char*)b+16));hx(b,p);printf(" %llu %lld ",(unsigned long long)*(uint64_t*)((char*)d+16),(long long)*(int64_t*)((char*)d+24));hx(d,p);putchar('\n');}
int main(void){
  unsigned ps[]={65,73,113,127,191,257,521,1024,2048,4096};
  for(unsigned zz=0;zz<sizeof(ps)/sizeof(ps[0]);zz++){
    unsigned p=ps[zz]; size_t z=os(p), sc=ss(p); void *a[8],*b[8],*d[8],*span[8],*scalar[8];
    for(int i=0;i<8;i++){a[i]=al(z);b[i]=al(z);d[i]=al(z);span[i]=al(z);scalar[i]=al(z);init(a[i],p,0x13579+p*17+i*31,i&1);init(b[i],p,0x2468+p*29+i*43,(i>>1)&1);}
    void*scratch=al(sc);
    int have_ifma=0;
#if defined(__x86_64__)
    FILE*f=fopen("/proc/cpuinfo","r"); if(f){char line[4096];while(fgets(line,sizeof line,f))if(strstr(line,"avx512ifma")){have_ifma=1;break;}fclose(f);}
#endif
    if(have_ifma){if(rankn_fp_mul_batch8(d,a,b,FLAG|p,scratch)){fprintf(stderr,"batch status p=%u\n",p);return 2;}for(int i=0;i<8;i++)out("M",p,i,a[i],b[i],d[i]);}
    if(rankn_fp_mul_span(span,a,b,FLAG|p,8,scratch)){fprintf(stderr,"span status p=%u\n",p);return 3;}
    for(int i=0;i<8;i++){if(rankn_fp_mul(scalar[i],a[i],b[i],FLAG|p))return 4;if(memcmp(span[i],scalar[i],32+((p+63)/64)*8)){fprintf(stderr,"span mismatch p=%u lane=%d\n",p,i);return 5;}if(rankn_fp_div(d[i],a[i],b[i],FLAG|p))return 6;out("D",p,i,a[i],b[i],d[i]);if(!guard(a[i],z)||!guard(b[i],z)||!guard(d[i],z)||!guard(span[i],z)||!guard(scalar[i],z)){fprintf(stderr,"object canary p=%u lane=%d\n",p,i);return 7;}}
    if(!guard(scratch,sc)){fprintf(stderr,"scratch canary p=%u\n",p);return 8;}
    for(int i=0;i<8;i++){free(a[i]);free(b[i]);free(d[i]);free(span[i]);free(scalar[i]);}free(scratch);
  }
  return 0;
}
C
gcc -O2 -march=native -no-pie "$TMP/oracle.c" "$TMP/wrap.o" -o "$TMP/oracle"
"$TMP/oracle" >"$TMP/oracle.txt"

python3 - "$TMP/oracle.txt" <<'PY'
from fractions import Fraction
import sys

def rne(fr):
    q,r=divmod(fr.numerator,fr.denominator); t=r*2
    if t>fr.denominator or (t==fr.denominator and (q&1)): q+=1
    return q

def canon(x,p):
    sign=int(x<0); x=abs(x)
    if not x: return sign,0,0
    n,d=x.numerator,x.denominator
    e=n.bit_length()-d.bit_length()
    if e>=0:
        if n < (d<<e): e-=1
    elif (n<<(-e)) < d: e-=1
    sh=p-1-e
    scaled=x*(1<<sh) if sh>=0 else x/Fraction(1<<(-sh),1)
    sig=rne(scaled)
    if sig==(1<<p): sig>>=1; e+=1
    return sign,e,sig

count=0
for line in open(sys.argv[1]):
    tag,ps,lane,sa,ha,sb,hb,so,es,ho=line.split()
    p=int(ps); A=int(ha,16); B=int(hb,16)
    if int(sa): A=-A
    if int(sb): B=-B
    val=Fraction(A*B) if tag=='M' else Fraction(A,B)
    exp=canon(val,p); got=(int(so),int(es),int(ho,16))
    assert got==exp,(tag,p,lane,got,exp)
    count+=1
assert count>=80
print('RANKN_PHYSICAL_EXACT_ORACLE_1_3_39=PASS')
PY

echo RANKN_PRECISION_PHYSICAL_1_3_39=PASS
