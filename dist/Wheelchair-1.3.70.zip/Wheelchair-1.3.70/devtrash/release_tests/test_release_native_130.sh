#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"

case "$(cat VERSION)" in 1.3.0|1.3.7|1.3.8|1.3.10|1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19) ;; *) exit 1 ;; esac
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_130.log 2>&1
for marker in \
  WHEELCHAIR_1_3_0_BUILD=PASS \
  PHYSICAL_DAG_TENSOR_TWO_PASS=BUILT \
  PHYSICAL_DAG_FIELD_PLAN=BUILT \
  AUTOMATIC_RANKN_EXECUTION_TENSOR=BUILT \
  SCHEDULER_BEFORE_CANONICAL_CODEGEN=PASS \
  SCHEDULER_PLAN_RUNTIME_CLOSURE=PASS \
  POST_CODEGEN_SCHEDULE_OVERRIDE=0 \
  SEMANTIC_ISA_OVERRIDE=BUILT \
  DIRECT_MACHINE_ENCODING=PRESERVED \
  MAX_SEMANTIC_CAUSAL_NODES=256 \
  EMPTY_EXECUTOR_LEAVES=ERASED \
  GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS \
  GLOBAL_READY_QUEUE=0 \
  WORK_STEALING=0 \
  PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
do
  grep -q "$marker" .release_build_130.log
done

echo 'BUILD_1_3_0_AUTHORITY=PASS'

# Shipped compiler images must be exactly the production build.
for f in wheelchairc whexc topologyc topologyc topologyc-derived topologyc-native256 topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Historical semantic authorities whose contracts remain valid after the
# intentional machine-image/runtime-layout change in 1.3.0.  Old sparse-image
# SHA tests from 1.2.13/1.2.14 are historical byte snapshots and are not reused
# as invariants after the 256-executor/Physical-DAG backend change.
devtrash/release_tests/test_execution_granularity_1212.sh
devtrash/release_tests/test_neighborhood_semantics_1215.sh
devtrash/release_tests/test_field_native_1216.sh
devtrash/release_tests/test_field_locality_1217.sh
devtrash/release_tests/test_field_surface_1218.sh
devtrash/release_tests/test_physical_dag_130.sh

# General semantic probes at the new ceiling, including iterate state.
T=${TMPDIR:-/tmp}/wheelchair130_release_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
build/wheelchairc devtrash/tests/general_parallel_126/iterate_probe.wh -o "$T/iterate256" >/dev/null
[ "$("$T/iterate256" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ]
echo 'GENERAL_ITERATE_Q256=PASS'

# Direct-native closure across compiler and runtime artifacts.
for f in \
  build/topologyc build/topologyc build/topologyc-derived \
  build/topologyc-native256 build/topologyc-native256 build/topologyc-derived-native256 \
  build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
  build/tensor_runtime_template build/tensor_derived_runtime_template \
  build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
  build/field_runtime_512_template build/field_runtime_256_template \
  build/general_parallel_release.elf
do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# No wrapper compiler/runtime route may appear in the production build chain.
if grep -RniE '(^|[^[:alnum:]_])(LLVM|MLIR|JIT)([^[:alnum:]_]|$)' \
  build.sh compiler runtime devtrash/frozen_native --include='*.S' --include='*.sh' >/dev/null 2>&1; then
  # Documentation/comments can name rejected technologies, so only fail on
  # executable invocation patterns below.
  :
fi
if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi

echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_NEW_RUNTIME_SCHEDULER=PASS'
echo 'STRICT_FP_HISTORICAL_GATES=PASS'
echo 'WH_WHEX_FIELD_ABI_COMPATIBLE=PASS'
echo 'WHEELCHAIR_1_3_0_RELEASE=PASS'
