#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = 1.3.54 ]
had_build=0; [ -d build ] && had_build=1
cleanup(){ if [ "$had_build" -eq 0 ] && [ "${ALLOW_BUILD_DIR:-0}" != 1 ]; then rm -rf build; fi; }
trap cleanup EXIT HUP INT TERM
./build.sh >/tmp/wheelchair_1354_build_$$.log 2>&1
trap 'rm -f /tmp/wheelchair_1354_build_$$.log; cleanup' EXIT HUP INT TERM
grep -Fqx 'ARCHITECTURE_AGING_1_3_54=PASS' /tmp/wheelchair_1354_build_$$.log
grep -Fqx 'WHEELCHAIR_1_3_54_BUILD=PASS' /tmp/wheelchair_1354_build_$$.log
for t in \
 test_precision_policy_1334.sh \
 test_native_mathematics_1334.sh \
 test_rankn_mathematics_1334.sh \
 test_structured_mathematics_1336.sh \
 test_parametric_rankn_fp_1340.sh \
 test_rankn_precision_fourier_1340.sh \
 test_math_fusion_1341.sh \
 test_root_relation_1342.sh \
 test_root_precision_fusion_1343.sh \
 test_math_generalization_1344.sh \
 test_field_human_shell_1345.sh \
 test_field_human_shell_1346.sh \
 test_avx2_physical_ownership_1347.sh \
 test_valuefact_lifetime_1348.sh \
 test_tensor_physical_reality_137.sh \
 test_sparse_physical_materialization_1349.sh \
 test_human_surface_convergence_1350.sh \
 test_structural_capacity_convergence_1351.sh \
 test_field_locality_1217.sh \
 test_optional_iteration_convergence_1353.sh \
 test_architecture_aging_1354.sh
do
  bash "devtrash/release_tests/$t" >/dev/null
done
for f in wheelchairc whexc topologyc topologyc-derived topologyc-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  [ -x "bin/$f" ]
  ! readelf -l "bin/$f" | grep -q INTERP
done
[ "$(find bin -maxdepth 1 -type f | wc -l)" -eq 8 ]
echo WHEELCHAIR_1_3_54_FINAL_RELEASE=PASS
