#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
C="$ROOT/bin/topologyc"
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT

compile_run() {
  local name="$1" expected="$2"
  "$C" "$T/$name.wh" -o "$T/$name.bin" >/dev/null
  local got
  got="$($T/$name.bin)"
  [[ "$got" == "$expected" ]] || { echo "$name: expected [$expected], got [$got]" >&2; exit 1; }
}

cat >"$T/pi.wh" <<'W'
program t
let x: f64 = pi
output x=x
test () => { x=3.141592653589793 }
W
compile_run pi 'out00_bits=0x400921fb54442d18'

cat >"$T/pi_utf8.wh" <<'W'
program t
let x: f64 = π
output x=x
test () => { x=3.141592653589793 }
W
compile_run pi_utf8 'out00_bits=0x400921fb54442d18'

cat >"$T/e.wh" <<'W'
program t
let x: f64 = e
output x=x
test () => { x=2.718281828459045 }
W
compile_run e 'out00_bits=0x4005bf0a8b145769'

cat >"$T/e_script.wh" <<'W'
program t
let x: f64 = ℯ
output x=x
test () => { x=2.718281828459045 }
W
compile_run e_script 'out00_bits=0x4005bf0a8b145769'

cat >"$T/mixed.wh" <<'W'
program t
let x: f64 = π²÷2.0+√9.0×2.0
output x=x
test () => { x=10.934802200544679 }
W
compile_run mixed 'out00_bits=0x4025de9e64df22ef'

cat >"$T/pow.wh" <<'W'
program t
let x: f64 = 2.0 ^ 3 ^ 2
output x=x
test () => { x=512.0 }
W
compile_run pow 'out00_bits=0x4080000000000000'

cat >"$T/pow_call.wh" <<'W'
program t
let x: f64 = pow(3.0,4)
output x=x
test () => { x=81.0 }
W
compile_run pow_call 'out00_bits=0x4054400000000000'

cat >"$T/extra_ops.wh" <<'W'
program t
let x: f64 = 8.0⁄2.0∗3.0
let a: bool = 2.0≤2.0 ∧ ¬false
let b: bool = 3.0≥2.0 ∨ false
let c: bool = 3.0≠2.0
output x=x
output a=a
output b=b
output c=c
test () => { x=12.0,a=true,b=true,c=true }
W
compile_run extra_ops $'out00_bits=0x4028000000000000\nout01_bits=0x0000000000000001\nout02_bits=0x0000000000000001\nout03_bits=0x0000000000000001'

cat >"$T/xor.wh" <<'W'
program t
let a: u64 = xor(5,3)
let b: u64 = bit_xor(5,3)
output a=a
output b=b
test () => { a=6,b=6 }
W
compile_run xor $'out00_bits=0x0000000000000006\nout01_bits=0x0000000000000006'

for ty in fp32 float32 real32 fp64 float64 real64 double; do
  cat >"$T/type.wh" <<W
program t
let x: $ty = 1.5
output x=x
test () => { x=1.5 }
W
  "$C" "$T/type.wh" -o "$T/type.bin" >/dev/null
  "$T/type.bin" >/dev/null
done

echo 'NATIVE_HANDWRITING_1_3_29=PASS'
