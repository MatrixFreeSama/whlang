#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
C="$ROOT/build/wheelchairc"
[ -x "$C" ] || C="$ROOT/bin/wheelchairc"
T="$ROOT/devtrash/tests/field_human_shell_1346"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

"$C" "$T/compact.wh" -o "$TMP/compact"
"$C" "$T/expanded.wh" -o "$TMP/expanded"
"$C" "$ROOT/devtrash/benchmarks/human_shell_1346/fem_hex8_compact.wh" -o "$TMP/fem_hex8_compact"

# Build two independent WHFLD216 output objects plus one input object.
python3 - "$TMP" <<'PY'
import struct,sys
from pathlib import Path
D=Path(sys.argv[1])
def field(path, vals):
    nx,ny,nz=3,1,1
    h=bytearray(256)
    h[0:8]=b'WHFLD216'
    struct.pack_into('<IIIIQ',h,8,1,1,3,0,256)
    struct.pack_into('<8Q',h,32,nx,ny,nz,0,0,0,0,0)
    struct.pack_into('<8Q',h,96,ny*nz*4,nz*4,4,0,0,0,0,0)
    struct.pack_into('<Q',h,160,nx*ny*nz)
    Path(path).write_bytes(h+b''.join(struct.pack('<f',float(x)) for x in vals))
field(D/'in.whfld',[1,2,3])
field(D/'out_compact.whfld',[0,0,0])
field(D/'out_expanded.whfld',[0,0,0])
PY

"$TMP/compact" "$TMP/in.whfld" "$TMP/out_compact.whfld" >/dev/null
"$TMP/expanded" "$TMP/in.whfld" "$TMP/out_expanded.whfld" >/dev/null
cmp -s "$TMP/out_compact.whfld" "$TMP/out_expanded.whfld"

grep -q '^\.scs_static_select_false:' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q 's_eval_static_u64' "$ROOT/compiler/surface_lowerer_x86_64.S"

echo FIELD_HUMAN_SHELL_STATIC_SELECT_1_3_46=PASS
