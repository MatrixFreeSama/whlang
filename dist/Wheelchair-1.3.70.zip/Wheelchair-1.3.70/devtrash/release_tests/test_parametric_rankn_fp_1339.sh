#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
CC="$ROOT/build/wheelchairc"
[ -x "$CC" ] || CC="$ROOT/bin/wheelchairc"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# The threshold is architectural, not a width list: fp64 stays native; any fpP
# with P>64 enters the same encoded Rank-N precision-limb authority.
cat >"$TMP/p64.wh" <<'SRC'
program p64
input x: f64
let y: f64 = x
output x = y
SRC
cat >"$TMP/p65.wh" <<'SRC'
program p65
input x: fp65
output x = x
SRC
"$CC" "$TMP/p64.wh" -o "$TMP/p64" >/dev/null
"$CC" "$TMP/p65.wh" -o "$TMP/p65" >/dev/null
[ "$("$TMP/p64" 1.5)" = 'out00_bits=0x3ff8000000000000' ]
[[ "$("$TMP/p65" 1.5)" == out00_rankn_fp=0x40000041:* ]]

# No power-of-two or historical named-width prerequisite.  Deliberately odd
# precisions force the same parser/type/value/physical path.
for p in 65 73 127 191 257 521 2048; do
  cat >"$TMP/p$p.wh" <<SRC
program p$p
input a: fp$p
input b: fp$p
let q = a / b
output q = q
SRC
  "$CC" "$TMP/p$p.wh" -o "$TMP/p$p" >/dev/null
done

# Existing meet authority remains first.  Low chooses the smaller precision;
# high chooses the larger precision.  Physicalization happens only afterwards.
case_prog() {
  local name=$1 policy=$2 ta=$3 tb=$4
  cat >"$TMP/$name.wh" <<SRC
program $name
precision_propagation $policy
input a: $ta
input b: $tb
let x = a + b
output x = x
SRC
  "$CC" "$TMP/$name.wh" -o "$TMP/$name" >/dev/null
}
case_prog low_191_521 0 fp191 fp521
case_prog high_191_521 1 fp191 fp521
case_prog low_f64_191 0 f64 fp191
case_prog high_f64_191 1 f64 fp191
case_prog low_f32_521 0 f32 fp521
case_prog high_f32_521 1 f32 fp521
[[ "$("$TMP/low_191_521" 1 2)" == out00_rankn_fp=0x400000bf:* ]]
[[ "$("$TMP/high_191_521" 1 2)" == out00_rankn_fp=0x40000209:* ]]
[ "$("$TMP/low_f64_191" 1 2)" = 'out00_bits=0x4008000000000000' ]
[[ "$("$TMP/high_f64_191" 1 2)" == out00_rankn_fp=0x400000bf:* ]]
[ "$("$TMP/low_f32_521" 1 2)" = 'out00_bits=0x0000000040400000' ]
[[ "$("$TMP/high_f32_521" 1 2)" == out00_rankn_fp=0x40000209:* ]]

# High propagation may promote only at the outer consumer edge.  The f32 child
# must still perform its natural f32 rounding before meeting fp521.
cat >"$TMP/meet.wh" <<'SRC'
program rankn_precision_meet_edge
precision_propagation 1
input a: f32
input b: f32
input d: fp521
let inner = a + b
let x = inner + d
let y: f64 = cast(f64, x)
output y = y
SRC
"$CC" "$TMP/meet.wh" -o "$TMP/meet" >/dev/null
[ "$("$TMP/meet" 16777216 1 1)" = 'out00_bits=0x4170000010000000' ]

# Exact rational oracle for arbitrary P.  Python exists only in this release
# test; compiler/runtime production artifacts remain handwritten native code.
python3 - "$CC" "$TMP" <<'PY'
from fractions import Fraction
from pathlib import Path
import random, subprocess, sys
cc,tmp=sys.argv[1],Path(sys.argv[2])

def round_even(fr):
    q,r=divmod(fr.numerator,fr.denominator)
    twice=r*2
    if twice>fr.denominator or (twice==fr.denominator and (q&1)): q+=1
    return q

def canon(x,p):
    sign=int(x<0); x=abs(x); nlimbs=(p+63)//64
    if x==0:
        e=0; sig=0
    else:
        n,d=x.numerator,x.denominator
        e=n.bit_length()-d.bit_length()
        if e>=0:
            if n < (d<<e): e-=1
        else:
            if (n<<(-e)) < d: e-=1
        shift=p-1-e
        scaled=x*(1<<shift) if shift>=0 else x/Fraction(1<<(-shift),1)
        sig=round_even(scaled)
        if sig==(1<<p): sig>>=1; e+=1
    typ=0x40000000|p
    return f"out00_rankn_fp=0x{typ:08x}:{sign:x}:{e & ((1<<64)-1):016x}:{nlimbs:08x}:{sig:0{nlimbs*16}x}"

def build_run(name,src,args=()):
    wh=tmp/(name+'.wh'); exe=tmp/name
    wh.write_text(src)
    subprocess.run([cc,str(wh),'-o',str(exe)],check=True,stdout=subprocess.DEVNULL)
    return subprocess.check_output([str(exe),*map(str,args)],text=True).strip()

# Exact long-decimal input at unrelated precisions.
for p,s in [
    (127,'0.33333333333333333333333333333333333333'),
    (521,'0.'+'3'*150),
    (2048,'0.'+'3'*100),
]:
    exe=tmp/f'p{p}'
    got=subprocess.check_output([str(exe),s,'1'],text=True).strip()
    # pP program emits s/1.
    exp=canon(Fraction(s),p)
    assert got==exp,(p,got,exp)

rng=random.Random(0x1339)
for p in (65,73,127,191,257,521,2048):
    rounds=5 if p<1000 else 2
    for op,sym in [('add','+'),('sub','-'),('mul','*'),('div','/')]:
        for i in range(rounds):
            a=rng.randrange(1,1<<42); b=rng.randrange(1,1<<41)
            if op=='sub' and a<b: a,b=b,a
            val={'add':Fraction(a+b),'sub':Fraction(a-b),'mul':Fraction(a*b),'div':Fraction(a,b)}[op]
            src=f'''program oracle_{p}_{op}_{i}\nlet a = cast(fp{p}, {a})\nlet b = cast(fp{p}, {b})\nlet x = a {sym} b\noutput x = x\n'''
            got=build_run(f'o_{p}_{op}_{i}',src)
            exp=canon(val,p)
            assert got==exp,(p,op,a,b,got,exp)
print('PARAMETRIC_RANKN_FP_ORACLE_1_3_39=PASS')
PY

# Source-level erasure of the former dedicated widths. ISA mnemonics such as
# vextractf128 are unrelated vector instruction names and are intentionally not
# part of this semantic scan.
if grep -RIE --include='*.S' --include='*.inc' --include='*.sh' --include='*.md' \
  'TYPE_F(128|256)|GTYPE_F(128|256)|STF_FP(128|256)|(^|[^[:alnum:]_])(fp128|fp256|f128|f256|float128|float256)([^[:alnum:]_]|$)|wide_float_x86_64' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/tools" "$ROOT/README.md" \
  "$ROOT"/WHEELCHAIR_CHARTER_1_3_39.md "$ROOT"/RELEASE_NOTES_1_3_39.md "$ROOT"/CORRECTNESS_1_3_39_RANKN_PRECISION_PHYSICAL.md 2>/dev/null; then
  echo dedicated-width-source-survived >&2; exit 1
fi

grep -q 'Encoded type: RPF_TYPE_FLAG | significand_bits' "$ROOT/runtime/rankn_precision_physical_x86_64.inc"
grep -q 'precision is data, not a' "$ROOT/compiler/general_frontend_x86_64.S"
grep -q 'Precision policy is deliberately absent here' "$ROOT/compiler/general_frontend_x86_64.S"
echo PARAMETRIC_RANKN_FP_1_3_39=PASS
