#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
export TERM="${TERM:-xterm}"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
[ -x bin/whexc ] || ./build.sh >/dev/null

# ShapeFact-N owns logical shape, not a capacity tier or a second executor.
[ -f compiler/shapefact_n.inc ]
[ -f compiler/shapefact_n_frontend.inc ]
! grep -Eq '\.(equ|set)[[:space:]]+.*(MAX|CAP|LIMIT)' compiler/shapefact_n.inc compiler/shapefact_n_frontend.inc
! grep -RqsE 'rank_n_product|rank_n_source_rank|rank_n_product_patch|RUNTIME_RANK_N_PRODUCT|__rankn_q' compiler runtime tools
grep -q '^s_shapefact_validate:' compiler/surface_lowerer_x86_64.S
grep -q '^s_tensor_shapefact_prepare:' compiler/surface_lowerer_x86_64.S
grep -q '^s_emit_shapefact_json:' compiler/surface_lowerer_x86_64.S
grep -q '^shapefn_parse_root:' compiler/shapefact_n_frontend.inc
# The generic ShapeFact validator precedes the Tensor consumer restriction.
awk '/^s_shapefact_validate:/{p=1} /^s_tensor_shapefact_prepare:/{p=0} p' compiler/surface_lowerer_x86_64.S | grep -q 'SHAPEFN_EXTENT_RUNTIME'
# Source runtime extent identity is data, not the historical spelling `n`.
! grep -Eq 'v_n|name_n|"n"' compiler/shapefact_n.inc compiler/shapefact_n_frontend.inc

# Base 512/256 consume the rank-1/product-1 ShapeFact subset directly.
for C in topologyc topologyc-native256; do
  bin/$C devtrash/tests/shapefact_1357/rank1_batch.whex -o "$T/$C-r1" >/dev/null
  [ "$("$T/$C-r1" 2)" = 'checksum_bits=0x4008000000000000' ]
done

# Derived 512/256 consume the productized rank-N subset from the same authority.
for C in topologyc-derived topologyc-derived-native256; do
  bin/$C devtrash/tests/shapefact_1357/rank3_batch.whex -o "$T/$C-r3" >/dev/null
  [ "$("$T/$C-r3" 2)" = 'checksum_bits=0x405a400000000000' ]
done
bin/whexc devtrash/tests/shapefact_1357/rank3_batch.whex -o "$T/whexc-r3" >/dev/null
[ "$("$T/whexc-r3" 2)" = 'checksum_bits=0x405a400000000000' ]

# Extent spelling erases completely. `batch` and `n` are byte-identical after AOT.
sed 's/input batch:/input n:/; s/ in batch/ in n/g' \
  devtrash/tests/shapefact_1357/rank3_batch.whex > "$T/rank3_n.whex"
bin/whexc "$T/rank3_n.whex" -o "$T/rank3-n" >/dev/null
cmp "$T/rank3-n" "$T/whexc-r3"

# Shape cardinality itself remains sparse/unbounded by a rank table.
bin/whexc devtrash/tests/human_surface_1350/rank80.whex -o "$T/rank80" >/dev/null
[ "$("$T/rank80" 4)" = 'checksum_bits=0x4018000000000000' ]

# Current Tensor realization still owns one runtime extent fact.  Rejecting two
# runtime extents here is a consumer capability boundary, not a ShapeFact limit.
if bin/whexc devtrash/tests/shapefact_1357/two_runtime_extents.whex -o "$T/two" >/dev/null 2>&1; then
  echo 'Tensor consumer silently advertised unsupported multi-runtime shape' >&2
  exit 1
fi

# Mature Newton-Jv semantics survive the authority replacement.  Its codegen is
# intentionally allowed to converge under ShapeFact-N; numerical bits remain exact.
bin/whexc devtrash/tests/whex/newton_jv_mature_regression.whex -o "$T/newton" >/dev/null
[ "$("$T/newton" 4)" = 'checksum_bits=0xbfaa960790000000' ]

echo SHAPEFACT_N_1_3_57=PASS
