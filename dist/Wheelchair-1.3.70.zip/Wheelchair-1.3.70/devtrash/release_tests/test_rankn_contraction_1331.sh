#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
C512="$ROOT/build/topologyc-derived"
C256="$ROOT/build/topologyc-derived-native256"
[ -x "$C512" ] || C512="$ROOT/bin/topologyc-derived"
[ -x "$C256" ] || C256="$ROOT/bin/topologyc-derived-native256"

cat >"$TMP/radix3.whex" <<'SRC'
program radix3
strict
input n: u64 range 1..1000
field x[b in n, c in 3]: f64 = cast(f64, b*3+c+1)
sum checksum[b in n, c in 3]: f64 = x[b,c]
output checksum
test (1) => { checksum = 6.0 }
SRC

cat >"$TMP/mm3.whex" <<'SRC'
program mm3
strict
input n: u64 range 1..1000
field A[b in n, i in 3, k in 3]: f64 = cast(f64, i*3+k+1)
field B[b in n, k in 3, j in 3]: f64 = cast(f64, k*3+j+1)
field C[b in n, i in 3, j in 3]: f64 = matmul(k in 3, A[b,i,k], B[b,k,j])
sum checksum[b in n, i in 3, j in 3]: f64 = C[b,i,j]
output checksum
test (1) => { checksum = 729.0 }
SRC

cat >"$TMP/mm6.whex" <<'SRC'
program mm6
strict
input n: u64 range 1..1000
field A[b in n, i in 6, k in 6]: f64 = cast(f64, i*6+k+1)
field B[b in n, k in 6, j in 6]: f64 = cast(f64, k*6+j+1)
field C[b in n, i in 6, j in 6]: f64 = matmul(k in 6, A[b,i,k], B[b,k,j])
sum checksum[b in n, i in 6, j in 6]: f64 = C[b,i,j]
output checksum
test (1) => { checksum = 77706.0 }
SRC

cat >"$TMP/mm7.whex" <<'SRC'
program mm7
strict
input n: u64 range 1..1000
field A[b in n, i in 7, k in 7]: f64 = cast(f64, i*7+k+1)
field B[b in n, k in 7, j in 7]: f64 = cast(f64, k*7+j+1)
field C[b in n, i in 7, j in 7]: f64 = matmul(k in 7, A[b,i,k], B[b,k,j])
sum checksum[b in n, i in 7, j in 7]: f64 = C[b,i,j]
output checksum
test (1) => { checksum = 223979.0 }
SRC

cat >"$TMP/trace3.whex" <<'SRC'
program trace3
strict
input n: u64 range 1..1000
field M[b in n, i in 3, j in 3]: f64 = cast(f64, i*3+j+1)
field tr[b in n]: f64 = trace(k in 3, M[b,k,k])
sum checksum[b in n]: f64 = tr[b]
output checksum
test (1) => { checksum = 15.0 }
SRC

run_one() {
  local cc=$1 tag=$2 src=$3 bits=$4
  "$cc" "$TMP/$src.whex" -o "$TMP/${src}_${tag}" >/dev/null
  out=$("$TMP/${src}_${tag}" 1)
  grep -q "checksum_bits=$bits" <<<"$out" || {
    echo "$tag/$src wrong: $out" >&2; exit 1;
  }
}
for cc_tag in "$C512:avx512" "$C256:native256"; do
  cc=${cc_tag%%:*}; tag=${cc_tag##*:}
  run_one "$cc" "$tag" radix3 0x4018000000000000
  run_one "$cc" "$tag" mm3    0x4086c80000000000
  run_one "$cc" "$tag" mm6    0x40f2f8a000000000
  run_one "$cc" "$tag" mm7    0x410b575800000000
  run_one "$cc" "$tag" trace3 0x402e000000000000
done

echo ARBITRARY_RADIX_RANKN_1_3_31=PASS
echo SELECTED_AXIS_CONTRACTION_1_3_31=PASS
