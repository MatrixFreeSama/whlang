#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T16=devtrash/tests/field_1216
T17=devtrash/tests/field_1217
TMP=${TMPDIR:-/tmp}/wheelchair1217_locality_$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

[ -x build/fieldc ]
[ -x build/fieldc-native256 ]

# Load identity is structural, not access-number identity.  The two canonical
# accesses below have different access IDs but the same immutable field/delta.
for C in fieldc fieldc-native256; do
  build/$C "$T17/duplicate_load_identity.json" -o "$TMP/$C-dup" >/dev/null
  [ "$("$TMP/$C-dup" "$T16/a_3x5x7.whfld")" = 'checksum_f32_bits=0x462de800' ]
done
echo 'FIELD_LOAD_IDENTITY_ALGEBRA=PASS'

# Coordinate identity ignores field base when runtime proves equal input
# strides.  Distinct files keep the noalias contract while sharing layout.
cp "$T16/a_3x5x7.whfld" "$TMP/a-copy.whfld"
for C in fieldc fieldc-native256; do
  build/$C "$T17/cross_field_coordinate_identity.json" -o "$TMP/$C-coord" >/dev/null
  [ "$("$TMP/$C-coord" "$T16/a_3x5x7.whfld" "$TMP/a-copy.whfld")" = 'checksum_f32_bits=0x462de800' ]
done
echo 'NEIGHBORHOOD_COORDINATE_CSE=PASS'

# Runtime-proven power-of-two shape uses the shift/mask coordinate path. The
# same compiler still accepts the non-power-of-two fixtures in the 1.2.16 gate.
for C in fieldc fieldc-native256; do
  build/$C "$T17/pow2_neighbor.json" -o "$TMP/$C-pow2" >/dev/null
  [ "$("$TMP/$C-pow2" "$T17/pow2_4x4x4.whfld")" = 'checksum_f32_bits=0x45020000' ]
done
echo 'DYNAMIC_POW2_ADDRESS_STRENGTH_REDUCTION=PASS'

# Full integration oracle remains exact after locality compression.
for C in fieldc fieldc-native256; do
  build/$C "$T16/fem_hex8_full.json" -o "$TMP/$C-hex8" >/dev/null
  for u in 0 1 2; do cp "$T16/fem_out${u}_3x5x7.whfld" "$TMP/$C-o${u}.whfld"; done
  "$TMP/$C-hex8" \
    "$T16/fem_lambda_3x5x7.whfld" "$T16/fem_mu_3x5x7.whfld" \
    "$T16/fem_p0_3x5x7.whfld" "$T16/fem_p1_3x5x7.whfld" "$T16/fem_p2_3x5x7.whfld" \
    "$TMP/$C-o0.whfld" "$TMP/$C-o1.whfld" "$TMP/$C-o2.whfld" >/dev/null
  for u in 0 1 2; do cmp "$TMP/$C-o${u}.whfld" "$T16/fem_expected_out${u}_3x5x7.whfld"; done
done
echo 'STRICT_FP_LOCALITY_COMPRESSION_ORACLE=PASS'

# Machine-code autopsy of the AVX-512 integration image.  The validation
# source has 2304 logical load ops, 97 unique field/delta load identities and
# 27 unique coordinate deltas.  Fast code must therefore expose 27 coordinate
# helper calls + 97 direct gathers; the 97 field_load helper calls remain only
# in the runtime-layout fallback branch.
EXE="$TMP/fieldc-hex8"
read off va sz <<EOH
$(readelf -lW "$EXE" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOH
off_dec=$((off)); va_dec=$((va)); sz_dec=$((sz))
dd if="$EXE" of="$TMP/generated.bin" bs=1 skip="$off_dec" count="$sz_dec" status=none
objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma="$va_dec" "$TMP/generated.bin" > "$TMP/generated.dis"
# 1.3.1 AOT rank specialization preserves the same locality contract while
# replacing the generic runtime-axis loop with rank1..rank8 direct entry points.
offset_calls=0
for h in $(nm -n build/field_runtime_512_template | awk '$3 ~ /^field_compute_offsets_f32(_r[1-8])?$/ {print "0x"$1}'); do
  hx=$(printf '%x' $((h)))
  n=$(grep -Eci "call[[:space:]]+0x0*${hx}([^0-9a-f]|$)" "$TMP/generated.dis" || true)
  offset_calls=$((offset_calls+n))
done
load_calls=0
for h in $(nm -n build/field_runtime_512_template | awk '$3 ~ /^field_load_f32(_r[1-8])?$/ {print "0x"$1}'); do
  hx=$(printf '%x' $((h)))
  n=$(grep -Eci "call[[:space:]]+0x0*${hx}([^0-9a-f]|$)" "$TMP/generated.dis" || true)
  load_calls=$((load_calls+n))
done
gathers=$(grep -ci 'vgatherdps' "$TMP/generated.dis" || true)
[ "$offset_calls" -eq 27 ]
[ "$load_calls" -eq 97 ]
[ "$gathers" -eq 97 ]
echo 'HEX8_LOGICAL_LOADS=2304'
echo 'HEX8_UNIQUE_LOAD_IDENTITIES=97'
echo 'HEX8_UNIQUE_COORDINATE_EPISODES=27'
echo 'HEX8_FAST_DIRECT_GATHERS=97'
echo 'HEX8_FALLBACK_FIELD_LOAD_HELPERS=97'
echo 'FIELD_LOAD_REDUNDANCY_ELIMINATION=PASS'
echo 'MULTISINK_FIELD_REUSE=PASS'

# Source-level anti-specialization and anti-serial gates.
grep -q '^ff_build_access_cache:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_build_coord_cache:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_assign_resident_loads:' compiler/field_frontend_common_x86_64.S
grep -q 'g_input_uniform_layout' runtime/field_runtime_512_x86_64.S
grep -q 'g_shape_pow2' runtime/field_runtime_512_x86_64.S
if grep -RniE 'Taichi|FEM|elasticity|Hex8|2304|\b97\b|64\^3|64x64' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'FIELD_LOCALITY_SPECIAL_CASE=FAIL' >&2; exit 1
fi
if grep -RniE 'work[ _-]?steal|global[ _-]?ready[ _-]?queue|central[ _-]?scheduler' \
  compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'FIELD_LOCALITY_HIDDEN_COORDINATION=FAIL' >&2; exit 1
fi
echo 'NO_FIELD_LOCALITY_WORKLOAD_DISPATCH=PASS'
echo 'NO_FIELD_LOCALITY_HIDDEN_SERIAL_COORDINATOR=PASS'
echo 'FIELD_ABI_1_2_16_COMPATIBLE=PASS'
echo 'WHEELCHAIR_FIELD_LOCALITY_1_2_17=PASS'
