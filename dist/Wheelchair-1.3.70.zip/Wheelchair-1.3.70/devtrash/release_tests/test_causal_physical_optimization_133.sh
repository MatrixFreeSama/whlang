#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair133_opt_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'CAUSAL_PHYSICAL_OPTIMIZATION_BUILD_AUTHORITY=PASS'

F=devtrash/tests/field_133
# Generic shared-factor graph. The compiler sees no problem/benchmark name.
for C in fieldc fieldc-native256; do
  build/$C "$F/shared_factor_pair_strict.json" -o "$T/${C}_strict" >/dev/null
  build/$C "$F/shared_factor_pair_tolerant.json" -o "$T/${C}_tol" >/dev/null

  cp "$F/factor_out_3x5x7.whfld" "$T/${C}_strict_out.whfld"
  "$T/${C}_strict" "$F/factor_a_3x5x7.whfld" "$F/factor_b_3x5x7.whfld" "$F/factor_x_3x5x7.whfld" "$T/${C}_strict_out.whfld" >/dev/null
  cmp "$T/${C}_strict_out.whfld" "$F/factor_expected_strict_3x5x7.whfld"

  cp "$F/factor_out_3x5x7.whfld" "$T/${C}_tol_out.whfld"
  "$T/${C}_tol" "$F/factor_a_3x5x7.whfld" "$F/factor_b_3x5x7.whfld" "$F/factor_x_3x5x7.whfld" "$T/${C}_tol_out.whfld" >/dev/null
  cmp "$T/${C}_tol_out.whfld" "$F/factor_expected_tolerant_3x5x7.whfld"
done
echo 'ARITHMETIC_EQUIVALENCE_CONTRACT=PASS'
echo 'STRICT_FP_REASSOCIATION=0'

# Machine graph proof: strict keeps the original two-term arithmetic; tolerant
# must physically erase work and cover the surviving accumulation with FMA.
objdump -D -b binary -m i386:x86-64 -M intel "$T/fieldc-native256_strict" > "$T/strict.dis" 2>/dev/null
objdump -D -b binary -m i386:x86-64 -M intel "$T/fieldc-native256_tol" > "$T/tol.dis" 2>/dev/null
strict_fma=$(grep -c 'vfmadd231ps' "$T/strict.dis" || true)
tol_fma=$(grep -c 'vfmadd231ps' "$T/tol.dis" || true)
strict_mul=$(grep -c 'vmulps' "$T/strict.dis" || true)
tol_mul=$(grep -c 'vmulps' "$T/tol.dis" || true)
strict_add=$(grep -c 'vaddps' "$T/strict.dis" || true)
tol_add=$(grep -c 'vaddps' "$T/tol.dis" || true)
[ "$strict_fma" -eq 0 ]
[ "$tol_fma" -ge 1 ]
[ "$tol_mul" -lt "$strict_mul" ]
[ "$tol_add" -lt "$strict_add" ]
if grep -q 'zmm' "$T/tol.dis"; then echo 'NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1; fi
echo 'SHARED_FACTOR_FUSION=PASS'
echo 'FMA_SUBGRAPH_COVER=PASS'
echo 'ARITHMETIC_MACHINE_WORK_REDUCTION=PASS'
echo 'NATIVE256_AVX2_ONLY=PASS'

# The real high-pressure Rank-N neighborhood corpus must also receive the same
# generic optimization under tolerant FP, while the historical strict oracle is
# preserved exactly by the old release gate.
build/fieldc-native256 devtrash/tests/field_1216/fem_hex8_full_tolerant_133.json -o "$T/high_pressure_tol" >/dev/null
objdump -D -b binary -m i386:x86-64 -M intel "$T/high_pressure_tol" > "$T/high.dis" 2>/dev/null
high_fma=$(grep -c 'vfmadd231ps' "$T/high.dis" || true)
high_mul=$(grep -c 'vmulps' "$T/high.dis" || true)
high_add=$(grep -c 'vaddps' "$T/high.dis" || true)
[ "$high_fma" -ge 500 ]
[ "$high_mul" -lt 1500 ]
[ "$high_add" -lt 800 ]
if grep -q 'zmm' "$T/high.dis"; then echo 'HIGH_PRESSURE_NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1; fi
echo 'RANKN_NEIGHBORHOOD_GENERAL_FUSION=PASS'
echo 'FUSION_WIDTH_COLLAPSE=0'

# Physical memory access profitability: old element-count heuristic is gone.
for R in runtime/field_runtime_256_x86_64.S runtime/field_runtime_512_x86_64.S; do
  grep -q 'field_init_memory_profitability' "$R"
  grep -q 'cpuid' "$R"
  grep -q 'g_llc_bytes' "$R"
  grep -q 'g_nt_threshold_bytes' "$R"
  grep -q 'g_random_read_pressure' "$R"
  grep -q 'cmp byte ptr \[rip+g_nt_active\],1' "$R"
  if grep -q 'cmp qword ptr \[rip+g_total\],CHUNK_SIZE' "$R"; then
    echo 'ELEMENT_COUNT_NT_HEURISTIC_LEAK=FAIL' >&2; exit 1
  fi
done
# No speculative prefetch ISA is emitted merely because a memory optimizer exists.
if objdump -d -Mintel build/field_runtime_256_template build/field_runtime_512_template 2>/dev/null | grep -Eqi '\bprefetch'; then
  echo 'USELESS_PREFETCH_LEAK=FAIL' >&2; exit 1
fi
echo 'CACHE_CAPACITY_AWARE_STORE_SELECTION=PASS'
echo 'RANDOM_READ_PRESSURE_MODEL=PASS'
echo 'SMALL_OUTPUT_NT_ELEMENT_HEURISTIC=0'
echo 'USELESS_PREFETCH=0'

# Existing locality machinery is still the address/load CSE authority.
grep -q '^ff_build_access_cache:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_build_coord_cache:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_access_value:' compiler/field_frontend_common_x86_64.S
echo 'LOAD_IDENTITY_REUSE=PASS'
echo 'ADDRESS_CSE=PASS'

# Anti-wrapper / anti-dispatch closure.
if grep -RniE 'Taichi|SPGrid|elasticity|compute_Ap|benchmark[_ -]*mode' \
  compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'BENCHMARK_SPECIAL_PATH=FAIL' >&2; exit 1
fi
if grep -RniE 'trial[_ -]*run|work[ _-]*steal|global[ _-]*ready[ _-]*queue' \
  compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'RUNTIME_SELECTOR_OR_SCHEDULER=FAIL' >&2; exit 1
fi
echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_CENTRAL_OPTIMIZER_RUNTIME=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'PHYSICAL_OPTIMIZATION_FIDELITY=PASS'
echo 'WHEELCHAIR_CAUSAL_PHYSICAL_OPTIMIZATION_1_3_3=PASS'
