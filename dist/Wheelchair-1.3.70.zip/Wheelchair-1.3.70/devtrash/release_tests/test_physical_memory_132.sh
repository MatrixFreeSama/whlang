#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair132_memory_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'PHYSICAL_MEMORY_BUILD_AUTHORITY=PASS'

# Mutable address injectivity is a launch-time mathematical proof, not an
# executor-count workaround. A legal-span but self-aliasing writable layout is
# rejected by both native widths; the same overlapping layout is legal read-only.
for C in fieldc fieldc-native256; do
  build/$C devtrash/tests/field_1216/copy.json -o "$T/$C-copy" >/dev/null
  cp devtrash/tests/field_1216/out_3x5x7.whfld "$T/$C-badout.whfld"
  for off in 96 104 112; do
    printf '\004\000\000\000\000\000\000\000' | dd of="$T/$C-badout.whfld" bs=1 seek=$off conv=notrunc status=none
  done
  set +e
  "$T/$C-copy" devtrash/tests/field_1216/a_3x5x7.whfld "$T/$C-badout.whfld" >/dev/null 2>&1
  r=$?
  set -e
  [ "$r" -eq 2 ]

  build/$C devtrash/tests/field_1216/sum.json -o "$T/$C-sum" >/dev/null
  cp devtrash/tests/field_1216/a_3x5x7.whfld "$T/$C-aliasin.whfld"
  for off in 96 104 112; do
    printf '\004\000\000\000\000\000\000\000' | dd of="$T/$C-aliasin.whfld" bs=1 seek=$off conv=notrunc status=none
  done
  "$T/$C-sum" "$T/$C-aliasin.whfld" >/dev/null
done
echo 'MUTABLE_LAYOUT_INJECTIVITY=PASS'
echo 'READONLY_OVERLAPPING_VIEW=PASS'

# Build large rank-3 descriptors entirely with POSIX tools. 4*64*256 = 65536
# f32 values => four 16K-element chunks, enough to exercise physical ownership.
make_large_header() {
  f=$1; s0=$2; s1=$3; s2=$4
  cp devtrash/tests/field_1216/a_3x5x7.whfld "$f"
  # extents: 4, 64, 256
  printf '\004\000\000\000\000\000\000\000' | dd of="$f" bs=1 seek=32 conv=notrunc status=none
  printf '\100\000\000\000\000\000\000\000' | dd of="$f" bs=1 seek=40 conv=notrunc status=none
  printf '\000\001\000\000\000\000\000\000' | dd of="$f" bs=1 seek=48 conv=notrunc status=none
  case "$s0" in
    65536) b0='\000\000\001\000\000\000\000\000' ;;
    4)     b0='\004\000\000\000\000\000\000\000' ;;
    *) exit 99;;
  esac
  case "$s1" in
    1024) b1='\000\004\000\000\000\000\000\000' ;;
    16)   b1='\020\000\000\000\000\000\000\000' ;;
    *) exit 99;;
  esac
  case "$s2" in
    4)    b2='\004\000\000\000\000\000\000\000' ;;
    1024) b2='\000\004\000\000\000\000\000\000' ;;
    *) exit 99;;
  esac
  printf "$b0" | dd of="$f" bs=1 seek=96 conv=notrunc status=none
  printf "$b1" | dd of="$f" bs=1 seek=104 conv=notrunc status=none
  printf "$b2" | dd of="$f" bs=1 seek=112 conv=notrunc status=none
  # total = 65536
  printf '\000\000\001\000\000\000\000\000' | dd of="$f" bs=1 seek=160 conv=notrunc status=none
  truncate -s 262400 "$f"
  dd if=/dev/zero of="$f" bs=256 seek=1 count=1024 conv=notrunc status=none
}
make_large_header "$T/in-large.whfld" 65536 1024 4
make_large_header "$T/out-large.whfld" 65536 1024 4
# One non-zero datum proves streaming output really reaches the mapped file.
printf '\000\000\200\077' | dd of="$T/in-large.whfld" bs=1 seek=256 conv=notrunc status=none

build/fieldc devtrash/tests/field_1216/copy.json -o "$T/copy-large512" >/dev/null
"$T/copy-large512" "$T/in-large.whfld" "$T/out-large.whfld" >/dev/null
cmp "$T/in-large.whfld" "$T/out-large.whfld"
make_large_header "$T/out-large256.whfld" 65536 1024 4
build/fieldc-native256 devtrash/tests/field_1216/copy.json -o "$T/copy-large256" >/dev/null
"$T/copy-large256" "$T/in-large.whfld" "$T/out-large256.whfld" >/dev/null
cmp "$T/in-large.whfld" "$T/out-large256.whfld"
echo 'CONTIGUOUS_FIELD_FASTPATH_PRESERVED=PASS'
echo 'MEMORY_ISA_STREAMING_OUTPUT_RUNTIME_512_256=PASS'

# This transpose-like layout is injective.  Leaf geometry is now an AOT Physical
# Reality fact rather than a fixed chunk constant, so a layout is rejected only
# when the realized leaf ownership would actually overlap.  For this fixture the
# derived grain is a single writable leaf; both native widths must therefore
# accept it without relying on a user resource option.
make_large_header "$T/out-transpose.whfld" 4 16 1024
build/fieldc devtrash/tests/field_1216/copy.json -o "$T/copy-q1" >/dev/null
"$T/copy-q1" "$T/in-large.whfld" "$T/out-transpose.whfld" >/dev/null
make_large_header "$T/out-transpose2.whfld" 4 16 1024
"$T/copy-large512" "$T/in-large.whfld" "$T/out-transpose2.whfld" >/dev/null
echo 'STRIDED_WRITABLE_PHYSICAL_OWNERSHIP_GATE=PASS'
echo 'FIXED_CHUNK_OWNERSHIP_ASSUMPTION=0'

# ISA evidence: large pure output owns non-temporal full-vector stores, while
# every worker fences its own stream before causal ownership ends.
objdump -d build/field_runtime_512_template | grep -q 'vmovntps'
objdump -d build/field_runtime_256_template | grep -q 'vmovntps'
objdump -d build/field_runtime_512_template | grep -q 'sfence'
objdump -d build/field_runtime_256_template | grep -q 'sfence'
echo 'MEMORY_ISA_OVERRIDE_VERIFIED=PASS'

# General mutable objects are page mailboxes/state, never packed writable slots.
grep -q '^\.equ MUTABLE_SLOT_BYTES, 4096$' runtime/general_runtime_template_x86_64.S
grep -q '^binding_mailboxes:' runtime/general_runtime_template_x86_64.S
grep -q '^state_temp_mailboxes:' runtime/general_runtime_template_x86_64.S
grep -q '^output_pages:' runtime/general_runtime_template_x86_64.S
for fn in g_binding_slot_addr g_output_slot_addr; do
  grep "$fn:" compiler/general_frontend_x86_64.S | grep -q 'shl rax,12'
done
# 1.3.15 preserves one private 4 KiB ownership page per mutable state while
# coloring the scalar payload by 64 bytes inside successive pages.  The 4160
# byte address stride is page ownership plus in-page cache-set coloring, not
# packed writable sharing.
for fn in g_state_slot_addr g_state_temp_addr; do
  grep "$fn:" compiler/general_frontend_x86_64.S | grep -q 'imul rax,rax,4160'
done
grep -q '^\.equ ST_NODE_BYTES, 4096$' runtime/general_parallel_release_x86_64.S
grep -q 'ST_NODE_ARRIVED' runtime/general_parallel_release_x86_64.S
if grep -q 'ST_REMAIN' runtime/general_parallel_release_x86_64.S; then exit 1; fi
grep -q 'SYS_getcpu' runtime/general_parallel_release_x86_64.S
grep -q 'SYS_mbind' runtime/general_parallel_release_x86_64.S
grep -Fq 'lock xadd dword ptr [rdi],eax' runtime/general_parallel_release_x86_64.S
! grep -Fq 'lock add dword ptr [rdi],1' runtime/general_parallel_release_x86_64.S
echo 'UNRELATED_WRITABLE_PAGE_SHARING=0'
echo 'GENERAL_CAUSAL_PAGE_OWNERSHIP=PASS'
echo 'NUMA_OWNER_LOCALIZATION_PATH=PASS'

# Child-to-parent values live at the child-owned stack-slice base, not a parent
# writable cache line. Validate every runtime physicalization.
for f in \
 runtime/tensor_runtime_x86_64.S \
 devtrash/frozen_native/generated_derived/tensor_derived_runtime_template_x86_64.S \
 devtrash/frozen_native/generated_native256/tensor_runtime_native256_template_x86_64.S \
 devtrash/frozen_native/generated_native256/tensor_derived_runtime_native256_template_x86_64.S \
 runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S
do
  grep -q 'mov \[rsp+8\],rax' "$f"
  if grep -q '^run_causal_tree:' "$f"; then
    sed -n '/^run_causal_tree:/,/^# worker_range/p' "$f" | grep -q 'mov r15,rax'
    if sed -n '/^run_causal_tree:/,/^# worker_range/p' "$f" | grep -q 'mov r15,rsp'; then exit 1; fi
  elif grep -q '^run_tree:' "$f"; then
    sed -n '/^run_tree:/,/^# worker/p' "$f" | grep -q 'mov r15,rax'
    if sed -n '/^run_tree:/,/^# worker/p' "$f" | grep -q 'mov r15,rsp'; then exit 1; fi
  else
    echo "missing causal tree entry in $f" >&2
    exit 1
  fi
done
echo 'CHILD_RESULT_LINE_ISOLATION=PASS'
echo 'SINGLE_TOUCH_CAUSAL_HANDOFF=PASS'

# Parallel-runtime patch addresses are derived from the actual native ELF; no
# stale handwritten memory-layout constants remain in the compiler.
grep -q 'build/general_parallel_release_offsets.inc' compiler/general_frontend_x86_64.S
if grep -q '^\.equ GR_NODE_COUNT_OFF,0x' compiler/general_frontend_x86_64.S; then exit 1; fi
test -s build/general_parallel_release_offsets.inc
echo 'PHYSICAL_MEMORY_LAYOUT_OFFSET_CLOSURE=PASS'

# Dynamic causal semantics at both ordinary width and the 256-domain ceiling.
build/wheelchairc devtrash/tests/general_parallel_126/causal_mesh_probe.wh -o "$T/mesh4" >/dev/null
[ "$("$T/mesh4" 1)" = 'out00_bits=0x0000000000000018' ]
build/wheelchairc devtrash/tests/general_parallel_126/iterate_probe.wh -o "$T/iterate256" >/dev/null
[ "$("$T/iterate256" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ]
echo 'RECIPIENT_BLIND_CAUSAL_MEMORY_Q256=PASS'

if grep -RniE 'work[ _-]*steal|global[ _-]*(ready|memory)[ _-]*queue|central[ _-]*memory[ _-]*scheduler' \
  runtime/general_parallel_release_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S \
  | grep -v -E 'There is no|no .*work|CENTRAL_MEMORY_SCHEDULER' >/dev/null 2>&1; then
  echo 'CENTRAL_MEMORY_COORDINATOR=FAIL' >&2; exit 1
fi
echo 'NO_CENTRAL_MEMORY_SCHEDULER=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'PHYSICAL_MEMORY_FIDELITY_CHECK=PASS'
echo 'WHEELCHAIR_PHYSICAL_MEMORY_CAUSALITY_1_3_2=PASS'
