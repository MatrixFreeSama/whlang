#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
C="$ROOT/build/wheelchairc"
[ -x "$C" ] || C="$ROOT/bin/wheelchairc"
T="$ROOT/devtrash/tests/field_human_shell_1345"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

"$C" "$T/compact.wh" -o "$TMP/compact"
"$C" "$T/expanded.wh" -o "$TMP/expanded"
cmp -s "$TMP/compact" "$TMP/expanded"

grep -q '^\.equ NK_STATIC_MGET,16' "$ROOT/compiler/surface_lowerer_x86_64.S"
grep -q '^sfh_parse_static_struct_let:' "$ROOT/compiler/field_surface_lowerer_x86_64.inc"
grep -q '^sfh_index_affine_delta:' "$ROOT/compiler/field_surface_lowerer_x86_64.inc"


echo FIELD_HUMAN_SHELL_BRIDGE_1_3_45=PASS
