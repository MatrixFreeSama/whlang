#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gmp.h>
extern int rankn_fp_mul(void*,void*,void*,uint32_t);
#define FLAG 0x40000000u
#define GUARD 256
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t os(unsigned p){unsigned n=(p+63)/64;return ((512ull*n+4096+63)/64)*64;}
static void* al(size_t z){size_t t=(z+GUARD+63)&~63ull; unsigned char*q=aligned_alloc(64,t); if(!q) abort(); memset(q,0,z); memset(q+z,0xa5,GUARD); return q;}
static int guard(void*v,size_t z){unsigned char*q=v;for(int i=0;i<GUARD;i++)if(q[z+i]!=0xa5)return 0;return 1;}
static void init(void*vv,unsigned p,uint64_t seed,int sign,int pattern){
    unsigned char*o=vv; unsigned n=(p+63)/64; memset(o,0,os(p));
    *(uint32_t*)o=FLAG|p;*(uint32_t*)(o+4)=p;*(uint32_t*)(o+8)=n;
    *(uint64_t*)(o+16)=sign;*(int64_t*)(o+24)=p-1;
    uint64_t*L=(uint64_t*)(o+32);
    for(unsigned i=0;i<n;i++){
        if(pattern==1)L[i]=~0ULL;
        else if(pattern==2)L[i]=(i&1)?0xaaaaaaaaaaaaaaaaULL:0x5555555555555555ULL;
        else L[i]=sm(&seed);
    }
    unsigned top=p-64*(n-1);
    if(top<64)L[n-1]&=((1ULL<<top)-1);
    L[n-1]|=1ULL<<(top-1);
}
static void import_sig(mpz_t z,void*v,unsigned p){size_t n=(p+63)/64;mpz_import(z,n,-1,8,0,0,(char*)v+32);}
static int expected_mul(void*out,void*a,void*b,unsigned p){mpz_t A,B,G,Q,R,H,LIM; mpz_inits(A,B,G,Q,R,H,LIM,NULL);import_sig(A,a,p);import_sig(B,b,p);mpz_mul(G,A,B); size_t bl=mpz_sizeinbase(G,2); long long e=(long long)bl-1; if(bl>p){unsigned long sh=(unsigned long)(bl-p);mpz_fdiv_q_2exp(Q,G,sh);mpz_fdiv_r_2exp(R,G,sh);mpz_set_ui(H,1);mpz_mul_2exp(H,H,sh-1);int c=mpz_cmp(R,H);if(c>0||(c==0&&mpz_odd_p(Q)))mpz_add_ui(Q,Q,1);mpz_set_ui(LIM,1);mpz_mul_2exp(LIM,LIM,p);if(mpz_cmp(Q,LIM)==0){mpz_fdiv_q_2exp(Q,Q,1);e++;}}else{mpz_mul_2exp(Q,G,p-bl);} uint64_t sign=*(uint64_t*)((char*)a+16)^*(uint64_t*)((char*)b+16);int ok=(*(uint64_t*)((char*)out+16)==sign)&&(*(int64_t*)((char*)out+24)==e);size_t n=(p+63)/64;uint64_t*tmp=calloc(n,8);size_t c=0;mpz_export(tmp,&c,-1,8,0,0,Q);ok&=!memcmp(tmp,(char*)out+32,n*8);if(!ok){fprintf(stderr,"expected mismatch p=%u e=%lld got_e=%lld\n",p,e,(long long)*(int64_t*)((char*)out+24));}free(tmp);mpz_clears(A,B,G,Q,R,H,LIM,NULL);return ok;}
int main(){
  unsigned ps[]={65,73,113,127,191,257,521,1024,2048,4096,8192,16384,32768,
                 65536,65537,100003,131071,131072,262144,262147,524288,524309,
                 1048576,1048583,2097152,2097169,4194304,4194319};
  for(size_t k=0;k<sizeof(ps)/sizeof(ps[0]);k++){
    unsigned p=ps[k]; size_t z=os(p);
    for(int pattern=0;pattern<3;pattern++){
      int rounds=(pattern==0 ? (p<=65536?8:p<=1048576?2:1) : 1);
      for(int s=0;s<rounds;s++){
        void*a=al(z),*b=al(z),*d=al(z);
        init(a,p,0x13579ULL+p*17+s*991,s&1,pattern);
        init(b,p,0x2468ULL+p*29+s*313,(s>>1)&1,pattern);
        if(rankn_fp_mul(d,a,b,FLAG|p)||!expected_mul(d,a,b,p)||!guard(a,z)||!guard(b,z)||!guard(d,z)){
          fprintf(stderr,"FAIL p=%u pattern=%d seed=%d\n",p,pattern,s);return 1;
        }
        free(a);free(b);free(d);
      }
    }
    printf("%u PASS\n",p);fflush(stdout);
  }
  puts("NATIVE_FOURIER_RNE_ORACLE_1_3_40=PASS");
}
