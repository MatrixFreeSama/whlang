#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <gmp.h>
extern int rankn_fp_mul(void*,void*,void*,uint32_t);
extern int rankn_fp_mul_span(void**,void**,void**,uint32_t,uint64_t,void*);
#define FLAG 0x40000000u
static volatile uint64_t sink;
static double now(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void pin(){cpu_set_t av,s;CPU_ZERO(&av);sched_getaffinity(0,sizeof(av),&av);int c=0;while(c<CPU_SETSIZE&&!CPU_ISSET(c,&av))c++;CPU_ZERO(&s);CPU_SET(c,&s);sched_setaffinity(0,sizeof(s),&s);}
static uint64_t sm(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t os(unsigned p){unsigned n=(p+63)/64;return ((136ull*n+1056+63)/64)*64;}
static size_t ss(unsigned p){unsigned n52=(p+51)/52,n64=(p+63)/64,pc=2*n52+4;return (size_t)n52*64*2+(size_t)pc*64+(size_t)pc*8+(size_t)(2*n64+4)*8+4096;}
static void init(void*vv,unsigned p,uint64_t seed){unsigned char*o=vv;unsigned n=(p+63)/64;memset(o,0,os(p));*(uint32_t*)o=FLAG|p;*(uint32_t*)(o+4)=p;*(uint32_t*)(o+8)=n;*(int64_t*)(o+24)=p-1;uint64_t*L=(uint64_t*)(o+32);for(unsigned i=0;i<n;i++)L[i]=sm(&seed);unsigned top=p-64*(n-1);if(top<64)L[n-1]&=(1ULL<<top)-1;L[n-1]|=1ULL<<(top-1);}
static void to_mpf(mpf_t f,void*v,unsigned p){unsigned n=(p+63)/64;mpz_t z;mpz_init(z);mpz_import(z,n,-1,8,0,0,(char*)v+32);mpf_set_z(f,z);mpz_clear(z);}
static double med(double a,double b,double c){if(a>b){double t=a;a=b;b=t;}if(b>c){double t=b;b=c;c=t;}if(a>b){double t=a;a=b;b=t;}return b;}
int main(){pin();unsigned ps[]={1024,2048,3072,4096,8192,16384};enum{N=64};puts("p,scalar_ns,span_ns,c_gmp_ns,span_speedup_vs_scalar,c_gmp_advantage_vs_span");for(unsigned zz=0;zz<6;zz++){unsigned p=ps[zz];size_t z=os(p),sc=ss(p);void*a[N],*b[N],*d[N],*e[N];mpf_t ga[N],gb[N],gd[N];for(int i=0;i<N;i++){a[i]=aligned_alloc(64,z);b[i]=aligned_alloc(64,z);d[i]=aligned_alloc(64,z);e[i]=aligned_alloc(64,z);init(a[i],p,p+i*17);init(b[i],p,0x7777+p+i*31);mpf_init2(ga[i],p);mpf_init2(gb[i],p);mpf_init2(gd[i],p);to_mpf(ga[i],a[i],p);to_mpf(gb[i],b[i],p);}void*scratch=aligned_alloc(64,sc);long it=p<=2048?300:p<=4096?100:p<=8192?30:8;double sv[3],vv[3],gv[3];for(int R=0;R<3;R++){for(int k=0;k<3;k++){for(int i=0;i<N;i++)rankn_fp_mul(d[i],a[i],b[i],FLAG|p);rankn_fp_mul_span(e,a,b,FLAG|p,N,scratch);for(int i=0;i<N;i++)mpf_mul(gd[i],ga[i],gb[i]);}double s=now();for(long k=0;k<it;k++)for(int i=0;i<N;i++)rankn_fp_mul(d[i],a[i],b[i],FLAG|p);double t=now();sv[R]=(t-s)*1e9/(it*N);s=now();for(long k=0;k<it;k++)rankn_fp_mul_span(e,a,b,FLAG|p,N,scratch);t=now();vv[R]=(t-s)*1e9/(it*N);s=now();for(long k=0;k<it;k++)for(int i=0;i<N;i++)mpf_mul(gd[i],ga[i],gb[i]);t=now();gv[R]=(t-s)*1e9/(it*N);}double sn=med(sv[0],sv[1],sv[2]),vn=med(vv[0],vv[1],vv[2]),gn=med(gv[0],gv[1],gv[2]);sink^=*(uint64_t*)((char*)e[0]+32)^mpf_get_ui(gd[0]);printf("%u,%.3f,%.3f,%.3f,%.4f,%.4f\n",p,sn,vn,gn,sn/vn,vn/gn);for(int i=0;i<N;i++){mpf_clear(ga[i]);mpf_clear(gb[i]);mpf_clear(gd[i]);free(a[i]);free(b[i]);free(d[i]);free(e[i]);}free(scratch);}fprintf(stderr,"sink=%llu\n",(unsigned long long)sink);}
