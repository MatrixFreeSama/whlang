# 1.3.67 Rank-N Transition Power rematch

Probe: unchanged `devtrash/benchmarks/general_causal_state_1312/fib_iter.wh` and its matched `fib_iter.c`.

Host: Intel Xeon Platinum 8272CL @ 2.60 GHz, 5 visible vCPUs. The benchmark process and every child inherit affinity to CPU 0. GCC control: `gcc -O3 -march=native -flto`.

Each `N` uses 11 interleaved whole-process runs after warmup. All implementations produce identical wrap-u64 output bits. The new 1.3.67 path proves the two-state relation as Rank-N affine and emits a direct call to `rankn_affine_power_u64`; 1.3.66 and GCC C execute the original linear loop.

| N | 1.3.66 median | 1.3.67 median | GCC C median |
| ---: | ---: | ---: | ---: |
| 10,000,000 | 8.911 ms | 1.994 ms | 9.399 ms |
| 100,000,000 | 71.510 ms | 2.187 ms | 48.722 ms |
| 500,000,000 | 352.066 ms | 2.263 ms | 226.040 ms |

The new whole-process timing is close to process/runtime launch cost, so the meaningful result is the disappearance of linear scaling. Do not interpret the approximately 100x 500M whole-process C ratio as a universal instruction-throughput claim.

Raw and summarized measurements are in the adjacent CSV files.
