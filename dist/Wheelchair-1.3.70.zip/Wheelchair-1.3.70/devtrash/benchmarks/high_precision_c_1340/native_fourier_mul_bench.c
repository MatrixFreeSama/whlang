#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <gmp.h>

extern int rankn_fp_mul(void*,void*,void*,uint32_t);
#define FLAG 0x40000000u
#define RPF_TYPE 0
#define RPF_PREC 4
#define RPF_N 8
#define RPF_GEOM 12
#define RPF_SIGN 16
#define RPF_EXP 24
#define RPF_DATA 32
static volatile uint64_t sink_u64;

static double now_s(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (double)t.tv_sec+(double)t.tv_nsec*1e-9;}
static void pin_one(void){cpu_set_t a,s;CPU_ZERO(&a);if(sched_getaffinity(0,sizeof(a),&a))return;int c=-1;for(int i=0;i<CPU_SETSIZE;i++)if(CPU_ISSET(i,&a)){c=i;break;}if(c<0)return;CPU_ZERO(&s);CPU_SET(c,&s);sched_setaffinity(0,sizeof(s),&s);}
static uint64_t sm64(uint64_t*x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static unsigned cl2_u64(uint64_t x){if(x<=1)return 0;return 64u-(unsigned)__builtin_clzll(x-1);}
static size_t obj_span(unsigned p){uint64_t n=((uint64_t)p+63)/64;return (size_t)((512*n+4096+63)&~63ULL);}

/* Exact C twin of the AOT geometry closure. It chooses one Fourier geometry,
   not an algorithm. The safety budget is native binary64 with one SIMD guard bit. */
static uint32_t geom_pack(unsigned P){
    uint64_t best=UINT64_MAX; uint32_t bestp=0;
    for(int b=26;b>=1;b--){
        uint64_t n=((uint64_t)P+(uint64_t)b-1)/(uint64_t)b;
        uint64_t need=2*n-1;
        uint64_t md=(1ULL<<b)-1, md2=md*md;
        uint64_t b3=1; unsigned a3=0;
        while(b3<=2*need){
            uint64_t base=b3; unsigned a5=0;
            while(base<=2*need){
                uint64_t ratio=(need+base-1)/base;
                unsigned a2=cl2_u64(ratio);
                if(a2<=62){
                    uint64_t N=base<<a2;
                    if(N>=need){
                        unsigned L=cl2_u64(N);
                        if(L){
                            uint64_t threshold=((1ULL<<51)-1)/(uint64_t)L;
                            __uint128_t load=(__uint128_t)n*md2;
                            if(load < threshold){
                                uint64_t weight=100ULL*a2+120ULL*a3+180ULL*a5+10ULL*a3*a3+30ULL*a5*a5;
                                __uint128_t c=(__uint128_t)N*weight+40ULL*n;
                                if(c<best){
                                    best=(uint64_t)c;
                                    bestp=(uint32_t)b|((uint32_t)a2<<8)|((uint32_t)a3<<16)|((uint32_t)a5<<24);
                                }
                            }
                        }
                    }
                }
                if(base>UINT64_MAX/5)break;
                base*=5; a5++;
            }
            if(b3>UINT64_MAX/3)break;
            b3*=3; a3++;
        }
    }
    return bestp;
}

static void init_obj(unsigned char*o,unsigned p,uint64_t seed){
    size_t z=obj_span(p); unsigned n=(p+63)/64; memset(o,0,z);
    *(uint32_t*)(o+RPF_TYPE)=FLAG|p; *(uint32_t*)(o+RPF_PREC)=p; *(uint32_t*)(o+RPF_N)=n;
    *(uint32_t*)(o+RPF_GEOM)=geom_pack(p); *(uint64_t*)(o+RPF_SIGN)=0; *(int64_t*)(o+RPF_EXP)=p-1;
    uint64_t *L=(uint64_t*)(o+RPF_DATA); for(unsigned i=0;i<n;i++)L[i]=sm64(&seed);
    unsigned top=p-64*(n-1); if(top<64)L[n-1]&=((1ULL<<top)-1); L[n-1]|=1ULL<<(top-1);
}
static uint64_t hash_obj(unsigned char*o){unsigned n=*(uint32_t*)(o+RPF_N);uint64_t h=*(uint64_t*)(o+RPF_EXP);for(unsigned i=0;i<n;i++)h=(h<<7)^(h>>3)^*(uint64_t*)(o+RPF_DATA+8ULL*i);return h;}
static void import_mpf(mpf_t f,unsigned char*o,unsigned p){unsigned n=(p+63)/64;mpz_t z;mpz_init(z);mpz_import(z,n,-1,8,0,0,o+RPF_DATA);mpf_set_z(f,z);mpz_clear(z);}

struct WB {unsigned char *a,*b,*d; unsigned p;};
struct GB {mpf_t a,b,d;};
static void w_once(void*vp){struct WB*x=vp;if(rankn_fp_mul(x->d,x->a,x->b,FLAG|x->p))abort();}
static void g_once(void*vp){struct GB*x=vp;mpf_mul(x->d,x->a,x->b);}
static double calibrate(void(*fn)(void*),void*ctx){
    int n=1; double t=0; while(n<(1<<20)){double s=now_s();for(int i=0;i<n;i++)fn(ctx);t=now_s()-s;if(t>=0.008)break;n*=2;}
    double per=t/n; long target=(long)(0.060/(per>1e-12?per:1e-12)); if(target<3)target=3;if(target>1000000)target=1000000;return (double)target;
}
static double run(void(*fn)(void*),void*ctx,long it){double s=now_s();for(long i=0;i<it;i++)fn(ctx);return (now_s()-s)/it;}
static double med5(double *x){for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)if(x[j]<x[i]){double t=x[i];x[i]=x[j];x[j]=t;}return x[2];}

int main(void){
    pin_one();
    unsigned ps[]={65,73,113,257,521,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304};
    puts("p,geom_b,a2,a3,a5,wheelchair_ns,gmp_mpf_ns,wc_over_gmp,wc_Mops,gmp_Mops");
    for(size_t pi=0;pi<sizeof(ps)/sizeof(ps[0]);pi++){
        unsigned p=ps[pi];size_t z=obj_span(p);uint32_t gp=geom_pack(p);if(!gp){fprintf(stderr,"no geometry p=%u\n",p);return 2;}
        struct WB w={aligned_alloc(64,z),aligned_alloc(64,z),aligned_alloc(64,z),p}; if(!w.a||!w.b||!w.d)abort();
        init_obj(w.a,p,0x14000000ULL+p*131ULL);init_obj(w.b,p,0x9e3779b97f4a7c15ULL^p);memset(w.d,0,z);*(uint32_t*)(w.d+RPF_GEOM)=gp;
        struct GB g;mpf_init2(g.a,p);mpf_init2(g.b,p);mpf_init2(g.d,p);import_mpf(g.a,w.a,p);import_mpf(g.b,w.b,p);
        for(int k=0;k<3;k++){w_once(&w);g_once(&g);} 
        long wi=(long)calibrate(w_once,&w), gi=(long)calibrate(g_once,&g); double wt[5],gt[5];
        for(int r=0;r<5;r++){if(r&1){gt[r]=run(g_once,&g,gi);wt[r]=run(w_once,&w,wi);}else{wt[r]=run(w_once,&w,wi);gt[r]=run(g_once,&g,gi);}}
        double wm=med5(wt),gm=med5(gt);sink_u64^=hash_obj(w.d)^mpf_get_ui(g.d);
        printf("%u,%u,%u,%u,%u,%.3f,%.3f,%.6f,%.6f,%.6f\n",p,gp&255,(gp>>8)&255,(gp>>16)&255,(gp>>24)&255,wm*1e9,gm*1e9,wm/gm,1e-6/wm,1e-6/gm);fflush(stdout);
        mpf_clears(g.a,g.b,g.d,NULL);free(w.a);free(w.b);free(w.d);
    }
    fprintf(stderr,"sink=%llu\n",(unsigned long long)sink_u64);return 0;
}
