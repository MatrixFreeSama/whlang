# Human-shell compact Hex8 probe (1.3.46)

These two sources encode the same strict Hex8 FEM `A·p` benchmark used during
human-shell validation.

- `fem_hex8_compact.wh` uses compile-time MatrixFact, selected-axis `contract`,
  affine neighborhood addressing and static `select` erasure.
- `fem_hex8_expanded_reference.wh` is the earlier fully expanded WH reference.

The compact source preserves the original accumulation order with one static
term axis `t = 0..383` per output component.  Release development validation
compared all three output field files byte-for-byte on the 64^3 benchmark
input set.
