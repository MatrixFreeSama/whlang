# Automatic Grouping 1.3.66 diagnostic

Host: shared AMD EPYC 9V74 environment, one pinned logical CPU. Workload argument: 400,000,000. The JSON preserves the first 15-run interleaved diagnostic. A subsequent 31-run confirmation produced medians used by the root performance note: native512 light 46.058 -> 46.071 ms, native512 strength 69.457 -> 70.262 ms, native256 light 119.791 -> 59.941 ms, native256 strength 158.400 -> 85.013 ms.

These measurements validate that removing the zero-cap codegen gate can materially change execution on native256 while preserving exact checksums. They are host diagnostics, not universal performance guarantees.
