program rigid7cse
 use iso_fortran_env, only:int64,real64
 implicit none
 integer::argc; character(len=64)::arg
 integer(int64)::steps,i,bits
 real(real64)::q0,q1,q2,q3,wx,wy,wz,n,c,nq0,nq1,nq2,nq3,nwx,nwy,nwz
 steps=0_int64; argc=command_argument_count(); if(argc>=1) then; call get_command_argument(1,arg); read(arg,*) steps; end if
 q0=1.0_real64;q1=.01_real64;q2=-.02_real64;q3=.03_real64;wx=1.2_real64;wy=-.7_real64;wz=.9_real64
 do i=0_int64,steps-1_int64
  n=(((q0*q0)+(q1*q1))+(q2*q2))+(q3*q3); c=.5_real64*(1.0_real64-n)
  nq0=q0+(((.5_real64*(((q1*wx)+(q2*wy))+(q3*wz)))+(c*q0))*.00001_real64)
  nq1=q1+(((.5_real64*(((q0*wx)+(q2*wz))-(q3*wy)))+(c*q1))*.00001_real64)
  nq2=q2+(((.5_real64*(((q0*wy)+(q3*wx))-(q1*wz)))+(c*q2))*.00001_real64)
  nq3=q3+(((.5_real64*(((q0*wz)+(q1*wy))-(q2*wx)))+(c*q3))*.00001_real64)
  nwx=wx+(((.5_real64*wy)*wz)*.00001_real64); nwy=wy+(((.5_real64*wz)*wx)*.00001_real64); nwz=wz+(((.5_real64*wx)*wy)*.00001_real64)
  q0=nq0;q1=nq1;q2=nq2;q3=nq3;wx=nwx;wy=nwy;wz=nwz
 end do
 bits=transfer(q3,bits); write(*,'("out00_bits=0x",Z16.16)') bits
end program
