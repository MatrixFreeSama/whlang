#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char**argv){uint64_t steps=argc>1?strtoull(argv[1],0,10):0;double q0=1,q1=.01,q2=-.02,q3=.03,wx=1.2,wy=-.7,wz=.9;
for(uint64_t i=0;i<steps;i++){double n=(((q0*q0)+(q1*q1))+(q2*q2))+(q3*q3);double c=.5*(1.0-n);
double nq0=q0+(((.5*(((q1*wx)+(q2*wy))+(q3*wz)))+(c*q0))*.00001);
double nq1=q1+(((.5*(((q0*wx)+(q2*wz))-(q3*wy)))+(c*q1))*.00001);
double nq2=q2+(((.5*(((q0*wy)+(q3*wx))-(q1*wz)))+(c*q2))*.00001);
double nq3=q3+(((.5*(((q0*wz)+(q1*wy))-(q2*wx)))+(c*q3))*.00001);
double nwx=wx+(((.5*wy)*wz)*.00001);double nwy=wy+(((.5*wz)*wx)*.00001);double nwz=wz+(((.5*wx)*wy)*.00001);
q0=nq0;q1=nq1;q2=nq2;q3=nq3;wx=nwx;wy=nwy;wz=nwz;}uint64_t u;memcpy(&u,&q3,8);printf("out00_bits=0x%016llx\n",(unsigned long long)u);}
