program fib_iter
  use iso_fortran_env, only: int64
  implicit none
  integer(int64) :: steps, a, b, na, nb, i
  character(len=64) :: arg
  if (command_argument_count() >= 1) then
     call get_command_argument(1,arg)
     read(arg,*) steps
  else
     steps = 100000000_int64
  end if
  a = 0_int64
  b = 1_int64
  do i = 1_int64, steps
     na = b
     nb = a + b
     a = na
     b = nb
  end do
  write(*,'(A,Z16.16)') 'out00_bits=0x', a
end program
