#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char**argv){
    uint64_t steps = argc>1 ? strtoull(argv[1],0,10) : 100000000ULL;
    uint64_t a=0,b=1;
    for(uint64_t i=0;i<steps;i++){
        uint64_t na=b;
        uint64_t nb=a+b;
        a=na; b=nb;
    }
    printf("out00_bits=0x%016llx\n",(unsigned long long)a);
    return 0;
}
