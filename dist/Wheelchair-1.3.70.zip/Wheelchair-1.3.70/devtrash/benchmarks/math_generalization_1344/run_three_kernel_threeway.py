#!/usr/bin/env python3
import csv, statistics, subprocess, time
from pathlib import Path
D=Path(__file__).resolve().parent
steps=20_000_000
reps=9
kernels=['mass3','chem6','rigid7']
impls=['Wheelchair_1.3.44','C_GCC14.2','Fortran_GFortran14.2']
suffix={'Wheelchair_1.3.44':'wheelchair','C_GCC14.2':'c','Fortran_GFortran14.2':'fortran'}
orders=[impls,[impls[1],impls[2],impls[0]],[impls[2],impls[0],impls[1]]]
def run(k,n):
    exe=D/f'{k}_{suffix[n]}'
    t0=time.perf_counter_ns()
    cp=subprocess.run(['taskset','-c','0',str(exe),str(steps)],check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    t1=time.perf_counter_ns()
    return (t1-t0)/1e6, cp.stdout.strip().lower()
rows=[]
for k in kernels:
    for n in impls: run(k,n)
    for r in range(reps):
        for n in orders[r%3]:
            ms,out=run(k,n); rows.append((k,r,n,steps,ms,out))
with open(D/'three_kernel_threeway_raw.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['kernel','rep','implementation','steps','wall_ms','checksum']); w.writerows(rows)
summary=[]
for k in kernels:
    outs={r[5] for r in rows if r[0]==k}
    if len(outs)!=1: raise SystemExit(f'{k} checksum mismatch {outs}')
    med={}
    for n in impls:
        xs=[r[4] for r in rows if r[0]==k and r[2]==n]
        med[n]=statistics.median(xs)
        summary.append([k,n,steps,reps,min(xs),med[n],statistics.mean(xs),max(xs),None,next(iter(outs))])
    c=med['C_GCC14.2']
    for row in summary:
        if row[0]==k and row[8] is None: row[8]=row[5]/c
with open(D/'three_kernel_threeway_summary.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['kernel','implementation','steps','reps','min_ms','median_ms','mean_ms','max_ms','time_over_C','checksum']); w.writerows(summary)
for row in summary:
    print(f'{row[0]:6s} {row[1]:22s} median={row[5]:.6f} ms over_C={row[8]:.6f}')
# geometric mean of per-kernel ratios over C
import math
for n in impls:
    rs=[row[8] for row in summary if row[1]==n]
    gm=math.exp(sum(math.log(x) for x in rs)/len(rs))
    print(f'GEOMEAN {n:22s} time_over_C={gm:.6f}')
