#!/usr/bin/env python3
import csv, os, platform, statistics, subprocess, time
from pathlib import Path
D=Path(__file__).resolve().parent
steps=20_000_000
reps=9
bins={
    'Wheelchair_1.3.44': D/'rigid7_wheelchair',
    'C_GCC14.2': D/'rigid7_c',
    'Fortran_GFortran14.2': D/'rigid7_fortran',
}
orders=[
    ['Wheelchair_1.3.44','C_GCC14.2','Fortran_GFortran14.2'],
    ['C_GCC14.2','Fortran_GFortran14.2','Wheelchair_1.3.44'],
    ['Fortran_GFortran14.2','Wheelchair_1.3.44','C_GCC14.2'],
]
def run(name):
    cmd=['taskset','-c','0',str(bins[name]),str(steps)]
    t0=time.perf_counter_ns()
    cp=subprocess.run(cmd,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    t1=time.perf_counter_ns()
    return (t1-t0)/1e6, cp.stdout.strip().lower()
# warmup
for n in bins: run(n)
rows=[]
for r in range(reps):
    for n in orders[r%len(orders)]:
        ms,out=run(n)
        rows.append((r,n,steps,ms,out))
outs={row[4] for row in rows}
if len(outs)!=1:
    raise SystemExit(f'correctness mismatch: {outs}')
with open(D/'rigid7_threeway_raw.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['rep','implementation','steps','wall_ms','checksum'])
    w.writerows(rows)
summary=[]
for n in bins:
    xs=[r[3] for r in rows if r[1]==n]
    summary.append((n,steps,reps,min(xs),statistics.median(xs),statistics.mean(xs),max(xs),rows[0][4]))
base=next(x[4] for x in summary if x[0]=='C_GCC14.2')
with open(D/'rigid7_threeway_summary.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['implementation','steps','reps','min_ms','median_ms','mean_ms','max_ms','time_over_C','checksum'])
    for x in summary:
        w.writerow([*x[:7],x[4]/base,x[7]])
print('correctness', rows[0][4])
for x in summary:
    print(f'{x[0]} median_ms={x[4]:.6f} min_ms={x[3]:.6f} mean_ms={x[5]:.6f} over_C={x[4]/base:.6f}')
