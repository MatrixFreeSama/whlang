#!/usr/bin/env bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$D/../../.." && pwd)
WH="$ROOT/build/wheelchairc"
[ -x "$WH" ] || WH="$ROOT/bin/wheelchairc"
for k in mass3 chem6 rigid7; do
  "$WH" "$D/$k.wh" -o "$D/${k}_wheelchair"
  gcc -O3 -march=native -fno-fast-math -ffp-contract=off "$D/$k.c" -o "$D/${k}_c"
  gfortran -O3 -march=native -fno-fast-math -ffp-contract=off -fprotect-parens "$D/$k.f90" -o "$D/${k}_fortran"
done
