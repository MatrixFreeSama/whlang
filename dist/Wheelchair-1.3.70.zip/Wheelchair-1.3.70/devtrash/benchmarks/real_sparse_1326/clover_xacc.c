#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <omp.h>
static inline size_t I(size_t z,size_t y,size_t x,size_t n){return (z*n+y)*n+x;}
static float* mapf(const char*p,size_t bytes,int*fd,void**m){*fd=open(p,O_RDONLY);*m=mmap(0,bytes,PROT_READ,MAP_PRIVATE,*fd,0);return (float*)((char*)*m+256);}
int main(int ac,char**av){if(ac!=8)return 2;size_t n=strtoull(av[7],0,10),N=n*n*n,bytes=256+4*N;int fd[6];void*m[6];float*d=mapf(av[1],bytes,&fd[0],&m[0]),*v=mapf(av[2],bytes,&fd[1],&m[1]),*xa=mapf(av[3],bytes,&fd[2],&m[2]),*p=mapf(av[4],bytes,&fd[3],&m[3]),*q=mapf(av[5],bytes,&fd[4],&m[4]),*xv=mapf(av[6],bytes,&fd[5],&m[5]);float sum=0.0f;const float hdt=.005f;
#pragma omp parallel for collapse(2) schedule(static) reduction(+:sum)
for(size_t z=0;z<n;z++)for(size_t y=0;y<n;y++){size_t ym=y?y-1:n-1;for(size_t x=0;x<n;x++){size_t xm=x?x-1:n-1;size_t a=I(z,y,x,n),b=I(z,y,xm,n),c=I(z,ym,x,n),e=I(z,ym,xm,n);float mass=.25f*(d[a]*v[a]+d[e]*v[e]+d[b]*v[b]+d[c]*v[c]);float step=hdt/mass;float out=xv[a];out-=step*xa[a]*(p[a]-p[b]);out-=step*xa[c]*(p[c]-p[e]);out-=step*xa[a]*(q[a]-q[b]);out-=step*xa[c]*(q[c]-q[e]);sum+=out*out;}}
uint32_t bits;memcpy(&bits,&sum,4);printf("checksum_f32_bits=0x%08x\n",bits);for(int i=0;i<6;i++){munmap(m[i],bytes);close(fd[i]);}}
