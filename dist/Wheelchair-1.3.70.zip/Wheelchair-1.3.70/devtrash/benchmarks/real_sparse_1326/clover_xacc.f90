program p
use iso_c_binding;use omp_lib;implicit none
interface
 function c_open(path,flags) bind(C,name='open') result(fd);import c_char,c_int;character(c_char),dimension(*)::path;integer(c_int),value::flags;integer(c_int)::fd;end function
 function c_mmap(addr,len,prot,flags,fd,off) bind(C,name='mmap') result(q);import c_ptr,c_size_t,c_int,c_long;type(c_ptr),value::addr;integer(c_size_t),value::len;integer(c_int),value::prot,flags,fd;integer(c_long),value::off;type(c_ptr)::q;end function
 function c_munmap(addr,len) bind(C,name='munmap') result(rc);import c_ptr,c_size_t,c_int;type(c_ptr),value::addr;integer(c_size_t),value::len;integer(c_int)::rc;end function
 function c_close(fd) bind(C,name='close') result(rc);import c_int;integer(c_int),value::fd;integer(c_int)::rc;end function
end interface
integer(c_size_t)::n,ntot,bytes,z,y,x,ym,xm,a,b,c,e;integer(c_int)::fd(6),rc;type(c_ptr)::base(6),data;integer(c_intptr_t)::bi;real(c_float),pointer::d(:),v(:),xa(:),pr(:),qv(:),xv(:);real(c_float)::sum,mass,step,outv;character(4096)::arg,path;character(c_char),allocatable::cp(:);integer::L,t;integer(c_int32_t)::bits
if(command_argument_count()/=7)stop 2;call get_command_argument(7,arg);read(arg,*)n;ntot=n*n*n;bytes=256+4*ntot
call mapone(1,d);call mapone(2,v);call mapone(3,xa);call mapone(4,pr);call mapone(5,qv);call mapone(6,xv);sum=0.0
!$omp parallel do collapse(2) schedule(static) reduction(+:sum) private(z,y,x,ym,xm,a,b,c,e,mass,step,outv)
do z=0,n-1;do y=0,n-1;if(y==0)then;ym=n-1;else;ym=y-1;endif;do x=0,n-1;if(x==0)then;xm=n-1;else;xm=x-1;endif;a=1+(z*n+y)*n+x;b=1+(z*n+y)*n+xm;c=1+(z*n+ym)*n+x;e=1+(z*n+ym)*n+xm;mass=.25_c_float*(d(a)*v(a)+d(e)*v(e)+d(b)*v(b)+d(c)*v(c));step=.005_c_float/mass;outv=xv(a);outv=outv-step*xa(a)*(pr(a)-pr(b));outv=outv-step*xa(c)*(pr(c)-pr(e));outv=outv-step*xa(a)*(qv(a)-qv(b));outv=outv-step*xa(c)*(qv(c)-qv(e));sum=sum+outv*outv;enddo;enddo;enddo
!$omp end parallel do
bits=transfer(sum,bits);write(*,'(A,Z8.8)')'checksum_f32_bits=0x',bits;do t=1,6;rc=c_munmap(base(t),bytes);rc=c_close(fd(t));enddo
contains
subroutine mapone(num,u);integer,intent(in)::num;real(c_float),pointer,intent(out)::u(:);integer::i;call get_command_argument(num,path);L=len_trim(path);if(allocated(cp))deallocate(cp);allocate(cp(0:L));do i=1,L;cp(i-1)=path(i:i);enddo;cp(L)=c_null_char;fd(num)=c_open(cp,0);base(num)=c_mmap(c_null_ptr,bytes,1,2,fd(num),0_c_long);bi=transfer(base(num),bi)+256;data=transfer(bi,data);call c_f_pointer(data,u,[int(ntot)]);end subroutine
end program
