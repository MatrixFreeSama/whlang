#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <gmp.h>
#include <quadmath.h>
extern int rankn_fp_add(void*,void*,void*,uint32_t);
extern int rankn_fp_mul(void*,void*,void*,uint32_t);
extern int rankn_fp_div(void*,void*,void*,uint32_t);
#define FLAG 0x40000000u
#define RPF_TYPE 0
#define RPF_PREC 4
#define RPF_N 8
#define RPF_SIGN 16
#define RPF_EXP 24
#define RPF_DATA 32
static volatile uint64_t sink_u64;
static volatile __float128 sink_q;
static double now_s(void){struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW,&t); return t.tv_sec+t.tv_nsec*1e-9;}
static void pin0(void){cpu_set_t s;CPU_ZERO(&s);CPU_SET(0,&s);if(sched_setaffinity(0,sizeof(s),&s))perror("affinity");}
static uint64_t sm64(uint64_t *x){uint64_t z=(*x+=0x9e3779b97f4a7c15ULL);z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
static size_t span(unsigned p){size_t n=(p+63)/64;return ((32+(4*n+16)*8+63)/64)*64+4096;}
static void init_rpf(unsigned char *o,unsigned p,uint64_t seed,uint64_t **limbs_out){uint32_t n=(p+63)/64;memset(o,0,span(p));*(uint32_t*)(o+RPF_TYPE)=FLAG|p;*(uint32_t*)(o+RPF_PREC)=p;*(uint32_t*)(o+RPF_N)=n;*(uint64_t*)(o+RPF_SIGN)=0;*(int64_t*)(o+RPF_EXP)=p-1;uint64_t *L=(uint64_t*)(o+RPF_DATA);for(uint32_t i=0;i<n;i++)L[i]=sm64(&seed);unsigned topbits=p-64*(n-1);if(topbits<64)L[n-1]&=((1ULL<<topbits)-1);L[n-1]|=1ULL<<(topbits-1);*limbs_out=L;}
static uint64_t hash_obj(unsigned char *o){uint32_t n=*(uint32_t*)(o+RPF_N);uint64_t h=*(uint64_t*)(o+RPF_EXP);for(uint32_t i=0;i<n;i++)h=h*0x9e3779b97f4a7c15ULL+*(uint64_t*)(o+RPF_DATA+8*i);return h;}
typedef int(*wop)(void*,void*,void*,uint32_t);
static double bench_w(unsigned p,char op,long it,uint64_t seed){size_t z=span(p);unsigned char *a=aligned_alloc(64,z),*b=aligned_alloc(64,z),*d=aligned_alloc(64,z);uint64_t *la,*lb;init_rpf(a,p,seed,&la);init_rpf(b,p,seed^0xfeedbeef12345678ULL,&lb);wop f=op=='+'?rankn_fp_add:op=='*'?rankn_fp_mul:rankn_fp_div;for(int k=0;k<8;k++)if(f(d,a,b,FLAG|p))abort();double s=now_s();for(long i=0;i<it;i++)if(f(d,a,b,FLAG|p))abort();double e=now_s();sink_u64^=hash_obj(d);free(a);free(b);free(d);return(e-s)/it;}
static void import_mpf(mpf_t f,uint64_t *L,unsigned n){mpz_t z;mpz_init(z);mpz_import(z,n,-1,sizeof(uint64_t),0,0,L);mpf_set_z(f,z);mpz_clear(z);}
static double bench_g(unsigned p,char op,long it,uint64_t seed){size_t z=span(p);unsigned char *oa=aligned_alloc(64,z),*ob=aligned_alloc(64,z);uint64_t *la,*lb;init_rpf(oa,p,seed,&la);init_rpf(ob,p,seed^0xfeedbeef12345678ULL,&lb);unsigned n=(p+63)/64;mpf_t a,b,d;mpf_init2(a,p);mpf_init2(b,p);mpf_init2(d,p);import_mpf(a,la,n);import_mpf(b,lb,n);for(int k=0;k<8;k++){if(op=='+')mpf_add(d,a,b);else if(op=='*')mpf_mul(d,a,b);else mpf_div(d,a,b);}double s=now_s();for(long i=0;i<it;i++){if(op=='+')mpf_add(d,a,b);else if(op=='*')mpf_mul(d,a,b);else mpf_div(d,a,b);}double e=now_s();sink_u64^=mpf_get_ui(d);mpf_clear(a);mpf_clear(b);mpf_clear(d);free(oa);free(ob);return(e-s)/it;}
static __float128 q_a,q_b,q_d;
__attribute__((noinline,noclone)) static void qonce(char op){volatile __float128 a=q_a,b=q_b;__float128 d;if(op=='+')d=a+b;else if(op=='*')d=a*b;else d=a/b;asm volatile("" ::: "memory");q_d=d;}
static __float128 limbs_to_q(uint64_t *L,unsigned p){unsigned n=(p+63)/64;__float128 x=0;for(int i=(int)n-1;i>=0;i--)x=x*0x1p64Q+(__float128)L[i];return x;}
static double bench_q(char op,long it,uint64_t seed){unsigned p=113;size_t z=span(p);unsigned char *oa=aligned_alloc(64,z),*ob=aligned_alloc(64,z);uint64_t *la,*lb;init_rpf(oa,p,seed,&la);init_rpf(ob,p,seed^0xfeedbeef12345678ULL,&lb);q_a=limbs_to_q(la,p);q_b=limbs_to_q(lb,p);for(int k=0;k<16;k++)qonce(op);double s=now_s();for(long i=0;i<it;i++)qonce(op);double e=now_s();sink_q=q_d;free(oa);free(ob);return(e-s)/it;}
static long its(unsigned p,char op){if(op=='+')return p<=128?700000:p<=256?500000:p<=512?300000:p<=1024?150000:70000;if(op=='*')return p<=128?300000:p<=256?180000:p<=512?80000:p<=1024?25000:7000;return p<=128?15000:p<=256?7000:p<=512?2500:p<=1024?700:180;}
static double med3(double a[3]){if(a[0]>a[1]){double t=a[0];a[0]=a[1];a[1]=t;}if(a[1]>a[2]){double t=a[1];a[1]=a[2];a[2]=t;}if(a[0]>a[1]){double t=a[0];a[0]=a[1];a[1]=t;}return a[1];}
int main(){pin0();unsigned ps[]={113,256,512,1024,2048};char ops[]={'+','*','/'};puts("p,op,iters,wheelchair_ns,c_gmp_ns,c_quad_ns,wheelchair_Mops,c_gmp_Mops,c_quad_Mops");for(int pi=0;pi<5;pi++){unsigned p=ps[pi];for(int oi=0;oi<3;oi++){char op=ops[oi];long it=its(p,op);double w[3],g[3],q[3]={0};for(int r=0;r<3;r++){uint64_t seed=0x13800000ULL+p*131+op+r;w[r]=bench_w(p,op,it,seed);g[r]=bench_g(p,op,it,seed);if(p==113)q[r]=bench_q(op,it,seed);}double wm=med3(w),gm=med3(g),qm=p==113?med3(q):0;printf("%u,%c,%ld,%.3f,%.3f,",p,op,it,wm*1e9,gm*1e9);if(p==113)printf("%.3f,",qm*1e9);else printf(",");printf("%.6f,%.6f,",1e-6/wm,1e-6/gm);if(p==113)printf("%.6f\n",1e-6/qm);else puts("");fflush(stdout);}}fprintf(stderr,"sink=%llu\n",(unsigned long long)sink_u64);}
