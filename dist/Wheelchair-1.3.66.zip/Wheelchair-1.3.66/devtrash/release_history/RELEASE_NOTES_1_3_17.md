# Wheelchair 1.3.17 Release Notes

## External Silicon Authority

1.3.17 is a resource-management-only release. Numerical Physical DAG, Rank-N lowering and 1.3.16 whole-episode arithmetic rules are intentionally left unchanged.

### Deleted active resource logic

Tensor and Field runtime no longer contain:

- `g_credit_lines`,
- `g_capacity_ceiling`,
- `try_claim_credit`,
- `release_credit`,
- capacity-slot accounting,
- `lock btr` / `lock bts` credit arbitration,
- runtime causal-work CPU pinning.

A true independent split now materializes directly outward. Completion exits directly instead of returning a credit.

General causal execution no longer pre-creates all future node executors. The old future-executor `futex wait/wake` fabric and `gr_run_node_tree` are removed. Only ready nodes materialize. Single-predecessor readiness does not use an atomic arrival operation. True multi-predecessor joins use one `lock xadd` arrival composition so exactly the final predecessor exposes the successor.

### Compiler-side cleanup

Field compilation no longer counts affinity CPUs to invent a default execution capacity. Topology compilation no longer pins itself to the current CPU for large source files. Affinity and CPU topology remain observable hardware facts where needed for AOT/NUMA reasoning, but they are not ownership or demand authority.

`--executors N` is accepted and range-checked only for historical CLI compatibility. Its value does not suppress or create semantic parallelism and is not consumed by the 1.3.17 runtime resource model.

### Correctness boundary

True causal synchronization is preserved. Reduction joins still wait for the real child result. Multi-predecessor nodes still require all real predecessors. Field physical-ownership rejection no longer becomes legal merely because `--executors 1` was specified; a resource spelling cannot change mathematical parallelism.

### What this release does not claim

1.3.17 removes Wheelchair-induced resource accounting, resource-pool contention and sleeping-future-executor overhead. It does not eliminate true dependency stalls, memory/cache latency, OS scheduler delay, interrupts, power-state transitions or processor pipeline bubbles.
