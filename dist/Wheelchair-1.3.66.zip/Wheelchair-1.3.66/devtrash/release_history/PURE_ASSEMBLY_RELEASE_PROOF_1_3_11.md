# Wheelchair 1.3.11 Pure Assembly Release Proof

The production changes in 1.3.11 are handwritten x86-64 assembly and shell build/release authority. The production compiler does not pass through C, LLVM, MLIR, a JIT, or a Python generator.

Release facts:

- non-power-of-two regular-episode proof compression is implemented in both AVX-512 and AVX2 Field runtimes;
- true irregular and periodic-boundary fallback remains available;
- AVX-512 immutable-neighbor residency is bounded and selected from compile-time reuse counts;
- Field global fact and Physical-DAG arrays admit four floating logical vregs;
- the WH/WHEX Field Sethi-Ullman lowerer admits expressions requiring four floating carriers and emits the canonical Field graph directly;
- no runtime expression interpreter is introduced;
- a generic FMA contraction experiment is absent from the release because its measured physical cost was worse;
- Blind Surplus Reflow remains recipient-blind and donor-blind;
- load balancing, work stealing, peer-load observation, global ready queues, failed-claim spin, and runtime occupancy autotuning remain forbidden;
- no CVRD3D, rank-3, field-name, or benchmark-size dispatch exists in production compiler/runtime source.
