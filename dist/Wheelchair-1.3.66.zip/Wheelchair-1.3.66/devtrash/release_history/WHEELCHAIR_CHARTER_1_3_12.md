# Wheelchair 1.3.12 Charter
## Causal State Collapse & Register Recurrence

Wheelchair 1.3.12 applies Active-Silicon Purity to General recurrence execution.

A source variable is not physical-state authority. Only persistent causal value across iterations justifies persistent physical state.

### Governing rules

```text
SOURCE_VARIABLE_IS_PHYSICAL_STATE_AUTHORITY=0
CONTROL_STATE_CONSUMES_DATA_STATE_BUDGET=0
HARDCODED_TWO_STATE_REGISTER_LIMIT=0
MANDATORY_STATE_TEMP_SLOT_COMMIT=0

CAUSAL_STATE_ROLE_ANALYSIS=1
COUNTED_CONTROL_COLLAPSE=1
REGISTER_RECURRENCE_IS_PHYSICAL=1
PARALLEL_STATE_TRANSITION=1
ACTIVE_SILICON_PURITY_IS_PRIMARY=1
```

A proven counted control state is separated from persistent data state. In the current x86-64 General physicalizer, up to three profitable scalar data states use the sovereign R8/R9/R10 bank while a proven counted control authority uses RBX and its invariant bound uses RBP. The number three is the current safe physical carrier capacity of this path, not a semantic limit on Wheelchair programs. Larger or unproved state graphs retain the generic fallback.

The fast path supports u64, i64, f32, and f64 state values as register-resident bit authorities. Simultaneous updates preserve old-state semantics and commit directly back to the persistent data carriers. The runtime `state_values` and `state_temp` arrays do not participate in an admitted register recurrence.

A counter that also participates in value expressions remains observable through its dedicated control register. Control collapse therefore does not mean erasing a value that is semantically consumed.

Runtime recursion is not added in this release. Recursive Fibonacci is not used as an excuse to enlarge the language/runtime boundary. `RUNTIME_RECURSION=DEFERRED`.

### Permanent exclusions

```text
FIBONACCI_SPECIALIZATION=0
LUCAS_SPECIALIZATION=0
TRIBONACCI_SPECIALIZATION=0
WORKLOAD_NAME_SPECIALIZATION=0
BENCHMARK_SIZE_SPECIALIZATION=0
RUNTIME_STATE_ROLE_MANAGER=0
RUNTIME_REGISTER_SCHEDULER=0
```

All state-role proofs and register assignment decisions are AOT compiler work.

### Protected authority

Wheelchair 1.3.12 does not rewrite the 1.3.10 execution fabric or the 1.3.11 Field physicalizer. Blind Surplus Reflow, load-balancing extinction, strict reduction identity, Field complex-surface authority, and the previous historical release chain remain mandatory release gates.
