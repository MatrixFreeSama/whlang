# Wheelchair 1.2.8 distribution

This is the complete source distribution for the validated Wheelchair 1.2.8 release. The native target is Linux x86-64.

## Source identity and preservation

- Repository: https://github.com/MatrixFreeSama/whlang
- Source branch: `build-1.2.8-native256-maturity`
- Source commit: `749b12d3a9bfcafa285548018c29c74e4155fc48`
- Source tree: `2d6b397cc37fd7f8b531817fd94ce6a6ff408c04`
- Source files preserved: **314**, with unchanged bytes and executable permissions.

All tracked source files, tests, benchmark data, assets, and validation workflows are included. The original top-level README is retained at `release-evidence/original-root-README.md`; the distribution README identifies 1.2.8. No compiler, runtime, frontend, build generator, or test implementation was changed to package this release.

Earlier `dist/` archives remain in the repository and are not recursively embedded here. Existing older release notes and checksum records under `worktree/` remain byte-for-byte intact. For this distribution, use the **root** `SHA256SUMS`; `release-evidence/source-manifest.json` maps every preserved source file to its source commit and hashes.

## Validation evidence

The three hosted jobs in [run 34017756455](https://github.com/MatrixFreeSama/whlang/actions/runs/34017756455) succeeded on the exact source commit above. Their retained logs contain the normal-build, AVX2/YMM-only, coupled-execution, workload-blindness, and final native256 maturity markers. The hosted jobs used AMD EPYC 7763 and AMD EPYC 9V74 hosts.

The packaged source also passed a clean normal build, the 1.2.7 native256 regression, the 1.2.8 maturity gate, and the release document seal on **INTEL(R) XEON(R) PLATINUM 8573C**. The numeric gate covered all twelve combinations of `N = 4, 17, 100000, 10000000` and `Q = 1, 2, 4`. The executable audit required YMM operations and rejected ZMM/opmask state. The package check did not inject diagnostics or relink a second-stage compiler.

The raw CI logs, local validation logs, and machine-readable validation records are in `release-evidence/`. These results validate correctness and release structure; they are not a new performance benchmark.

## Verify and build

Before extracting, verify the adjacent archive checksum:

```bash
sha256sum -c Wheelchair-1.2.8.zip.sha256
unzip Wheelchair-1.2.8.zip
cd Wheelchair-1.2.8
sha256sum -c SHA256SUMS
cd worktree
./build.sh
```

The root checksum covers every packaged file except itself. Check it before building, because building creates generated files and may refresh generated offset includes.

Building needs Python 3, GNU binutils, and a POSIX shell. The full maturity test additionally needs GCC and an AVX2-capable Linux x86-64 host:

```bash
sh test_native256_maturity_128.sh
sh test_release_128.sh
```

The first command performs its own clean normal build. Expected terminal markers:

```text
WHEELCHAIR_NATIVE256_MATURITY_1_2_8=PASS
WHEELCHAIR_1_2_8_FINAL=PASS
```

## Archive properties

ZIP entries have a single `Wheelchair-1.2.8/` root, UTF-8 names, preserved executable permissions, sorted paths, and a fixed timestamp taken from the source commit. Temporary build products, Git internals, and historical distribution archives are excluded. ZIP CRC, every root checksum, source-file hashes, and extraction permissions are checked before publication.
