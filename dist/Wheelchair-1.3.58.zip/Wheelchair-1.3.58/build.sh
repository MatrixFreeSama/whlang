#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD="$ROOT/build"
rm -rf "$BUILD"
mkdir -p "$BUILD"
cd "$ROOT"

# 1.3.24 single-source production authority.  Historical frozen copies are no
# longer a build input: compiler/ and runtime/ are the only source authority.
# This prevents a deleted private matcher or compatibility path from surviving
# through a copied legacy physicalization.
echo 'SINGLE_CURRENT_SOURCE_AUTHORITY=PASS'
echo 'PRODUCTION_BUILD_PYTHON_GENERATORS=0'

# Mature native-512 runtime remains the protected physical peak.
as --64 runtime/tensor_runtime_x86_64.S -o "$BUILD/tensor_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_template.o" -o "$BUILD/tensor_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_template" compiler/runtime_offsets.inc

# Derived native-512 runtime from the same current runtime authority.
as --64 --defsym TENSOR_RUNTIME_DERIVED=1 runtime/tensor_runtime_x86_64.S -o "$BUILD/tensor_derived_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_template.o" -o "$BUILD/tensor_derived_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_template" "$BUILD/runtime_derived_offsets.inc"

# True AVX2/YMM runtimes from the same current runtime authority.
as --64 --defsym TENSOR_RUNTIME_NATIVE256=1 runtime/tensor_runtime_x86_64.S -o "$BUILD/tensor_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_native256_template.o" -o "$BUILD/tensor_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_native256_template" "$BUILD/runtime_native256_offsets.inc"

as --64 --defsym TENSOR_RUNTIME_NATIVE256=1 --defsym TENSOR_RUNTIME_DERIVED=1 runtime/tensor_runtime_x86_64.S -o "$BUILD/tensor_derived_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_native256_template.o" -o "$BUILD/tensor_derived_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_native256_template" "$BUILD/runtime_derived_native256_offsets.inc"

echo 'STRICT_REDUCTION_REPAIR_RUNTIME_OFFSETS=BUILT'

as --64 runtime/general_runtime_template_x86_64.S -o "$BUILD/general_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/general_runtime.ld \
  "$BUILD/general_runtime_template.o" -o "$BUILD/general_runtime_template"
./tools/generate_general_runtime_offsets.sh "$BUILD/general_runtime_template" compiler/general_runtime_offsets.inc

# Recipient-blind causal-region runtime. Offset derivation is shell + native ELF
# symbols only; no Python participates in production build authority.
as --64 runtime/general_parallel_release_x86_64.S -o "$BUILD/general_parallel_release.o"
ld -nostdlib -static -z noexecstack -T runtime/general_parallel_release.ld \
  "$BUILD/general_parallel_release.o" -o "$BUILD/general_parallel_release.elf"
objcopy -O binary --only-section=.text \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin"
sh tools/generate_general_parallel_release_offsets.sh \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin" \
  "$BUILD/general_parallel_release_offsets.json" "$BUILD/general_parallel_release_offsets.inc"
echo 'GENERAL_PARALLEL_RELEASE_OFFSETS_NO_PYTHON=PASS'

# Shared handwritten sovereign topology core with physical-shape capability algebra.
as --64 compiler/topologyc_x86_64.S -o "$BUILD/topologyc_core.o"
as --64 compiler/outward_materialization_profile_x86_64.S -o "$BUILD/outward_materialization_profile.o"
as --64 compiler/general_frontend_x86_64.S -o "$BUILD/general_frontend.o"
as --64 compiler/general_runtime_blob_x86_64.S -o "$BUILD/general_runtime_blob.o"
as --64 compiler/general_parallel_release_blob_x86_64.S -o "$BUILD/general_parallel_release_blob.o"
as --64 compiler/surface_lowerer_x86_64.S -o "$BUILD/surface_lowerer.o"

# Native/split 512 physicalizers.
as --64 compiler/tensor_frontend_x86_64.S -o "$BUILD/tensor_frontend.o"
as --64 compiler/runtime_blob_x86_64.S -o "$BUILD/runtime_blob.o"

# 1.2.17 sovereign native field lane.  This extends the separate direct-native AOT
# physicalization so the protected 1.2.15 f64 tensor path remains byte-authoritative.
# The field lane is pure handwritten assembly and maps materialized WHFLD216
# fields directly; it never routes through C, LLVM, JIT, Python, or a bytecode
# interpreter.
as --64 runtime/field_runtime_512_x86_64.S -o "$BUILD/field_runtime_512.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_512.o" -o "$BUILD/field_runtime_512_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_512_offsets.inc"

as --64 runtime/field_runtime_256_x86_64.S -o "$BUILD/field_runtime_256.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_256.o" -o "$BUILD/field_runtime_256_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_256_template" "$BUILD/field_runtime_256_offsets.inc"

as --64 compiler/field_runtime_blob_512_x86_64.S -o "$BUILD/field_runtime_blob_512.o"
as --64 compiler/field_runtime_blob_256_x86_64.S -o "$BUILD/field_runtime_blob_256.o"
as --64 compiler/field_frontend_512_x86_64.S -o "$BUILD/field_frontend_512.o"
as --64 compiler/field_frontend_256_x86_64.S -o "$BUILD/field_frontend_256.o"
as --64 compiler/fieldc_driver_x86_64.S -o "$BUILD/fieldc_driver.o"
as --64 compiler/field_parser_link_stubs_x86_64.S -o "$BUILD/field_parser_link_stubs.o"

# Fieldc links the current handwritten parser symbols from the tensor frontend.
# Unreachable tensor-only link references are satisfied by compile-time stubs;
# no tensor scheduler/runtime is entered by fieldc.
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_512.o" \
  "$BUILD/tensor_frontend.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_512.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/outward_materialization_profile.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc"
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_256.o" \
  "$BUILD/tensor_frontend.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_256.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/outward_materialization_profile.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc"
as --64 compiler/tensor_derived_frontend_x86_64.S -o "$BUILD/tensor_frontend_derived.o"
as --64 compiler/runtime_derived_blob_x86_64.S -o "$BUILD/runtime_derived_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend_derived.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived"

# Native256 physicalizers for every generic graph-resource class.
as --64 compiler/tensor_frontend_native256_x86_64.S -o "$BUILD/tensor_frontend_native256.o"
as --64 compiler/tensor_derived_frontend_native256_x86_64.S -o "$BUILD/tensor_frontend_derived_native256.o"
as --64 compiler/runtime_native256_blob_x86_64.S -o "$BUILD/runtime_native256_blob.o"
as --64 compiler/runtime_derived_native256_blob_x86_64.S -o "$BUILD/runtime_derived_native256_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/outward_materialization_profile.o" "$BUILD/tensor_frontend_derived_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived-native256"

# Native production launchers.  The driver performs only compile-time structural
# classification (base/derived from canonical structure); it never retries a failed compiler
# and never inspects workload names.
as --64 compiler/native_driver_x86_64.S -o "$BUILD/native_driver.o"
ld -nostdlib -static -z noexecstack "$BUILD/native_driver.o" "$BUILD/surface_lowerer.o" -o "$BUILD/wheelchairc"
cp "$BUILD/wheelchairc" "$BUILD/whexc"

for f in \
  "$BUILD/topologyc" "$BUILD/topologyc-derived" \
  "$BUILD/topologyc-native256" "$BUILD/topologyc-derived-native256" \
  "$BUILD/tensor_runtime_template" "$BUILD/tensor_derived_runtime_template" \
  "$BUILD/tensor_runtime_native256_template" "$BUILD/tensor_derived_runtime_native256_template" \
  "$BUILD/general_runtime_template" "$BUILD/general_parallel_release.elf" \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_256_template" \
  "$BUILD/fieldc" "$BUILD/fieldc-native256" \
  "$BUILD/wheelchairc" "$BUILD/whexc"; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# Production build closure must not invoke Python. Python remains allowed only
# in reference/validation tooling while the human surface is being migrated.
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'Python invocation leaked into production build' >&2; exit 1
fi

# Current release surface: bin/ contains only canonical production executables.
rm -rf "$ROOT/bin"
mkdir -p "$ROOT/bin"
for f in \
  wheelchairc whexc topologyc topologyc-derived \
  topologyc-native256 topologyc-derived-native256 \
  fieldc fieldc-native256; do
  cp "$BUILD/$f" "$ROOT/bin/$f"
done

# 1.3.53 optional-iteration convergence. Historical defaults remain fallback policy only.
[ ! -e "$BUILD/topologyc-wide" ]
[ ! -e "$BUILD/topologyc-wide-native256" ]
[ ! -e "$ROOT/bin/topologyc-wide" ]
[ ! -e "$ROOT/bin/topologyc-wide-native256" ]
[ -f compiler/physical_reality.inc ]
[ ! -e compiler/physical_reality_136.inc ]
[ ! -e compiler/physical_reality_137.inc ]
[ ! -e compiler/physical_reality_138.inc ]
[ ! -e compiler/json_parser_x86_64.S ]
[ ! -e compiler/physical_vector_shapes.inc ]
if find compiler runtime tools surface -type f -name '*138*' -print | grep -q .; then
  echo 'Historical 138 filename leaked into production authority' >&2; exit 1
fi
if grep -RniE '\b(PR|T)138_|physical_reality_138|tensor_(derived_)?frontend_138|tensor_runtime_138' \
  compiler runtime tools surface >/dev/null 2>&1; then
  echo 'Historical 138 identifier leaked into production authority' >&2; exit 1
fi
if grep -Rni 'devtrash/' compiler runtime tools surface >/dev/null 2>&1; then
  echo 'Production source depends on devtrash' >&2; exit 1
fi

echo 'CURRENT_PHYSICAL_REALITY_AUTHORITY=compiler/physical_reality.inc'
echo 'PRODUCTION_VERSION_TAGGED_ARCHITECTURE=0'
echo 'DEAD_WIDE_COMPILER_ALIAS=0'
echo 'PRODUCTION_UNUSED_SOURCE_AUTHORITY=0'
echo 'PRODUCTION_BUILD_HISTORY_REPLAY=0'
echo 'ADVANCED_MATH_OPTIONAL_ITERATION_AUTHORITY=PASS'
echo 'NEW_ALGORITHM_FAMILIES_1_3_53=0'
echo 'NEW_RUNTIME_SOLVER_AUTHORITIES_1_3_53=0'
echo 'WHEELCHAIR_1_3_53_BUILD=PASS'

# 1.3.54 large architecture aging: structural storage, not enlarged constants.
! grep -q '^\.equ SAST_MAX' compiler/surface_lowerer_x86_64.S
! grep -q '^\.equ SBUF_.*_CAP' compiler/surface_lowerer_x86_64.S
grep -q '^s_grow_ast_slab:' compiler/surface_lowerer_x86_64.S
grep -q '^s_out_reserve:' compiler/surface_lowerer_x86_64.S
grep -q '^s_alloc_pointer_workset:' compiler/surface_lowerer_x86_64.S
! grep -q 'GENERAL_RUNTIME_BINDING_SLOT_CAP' compiler/general_runtime_capacity.inc
! grep -q 'SFH_OPS_CAP' compiler/field_surface_lowerer_x86_64.inc
! grep -q 'SFH_MAX_SCALARS' compiler/field_surface_lowerer_x86_64.inc
! grep -q 'SFH_MAX_REDUCES' compiler/field_surface_lowerer_x86_64.inc
echo 'ARCHITECTURE_AGING_1_3_54=PASS'
echo 'WHEELCHAIR_1_3_54_BUILD=PASS'

# 1.3.55 runtime-record and code-staging aging. Program cardinality and generated
# code size are instance facts; the initial staging estimate may grow and retry.
! grep -Eq 'GENERAL_RUNTIME_(INPUT|BINDING_SLOT|STATE|OUTPUT)_CAP' compiler/general_runtime_capacity.inc
grep -q '^\.equ GENERAL_RUNTIME_DYNAMIC_ARENA_VA,' compiler/general_runtime_capacity.inc
! grep -q 'GCODE_CAP' compiler/general_frontend_x86_64.S
grep -q '^g_prepare_code_arenas:' compiler/general_frontend_x86_64.S
grep -q 'g_code_overflow' compiler/general_frontend_x86_64.S
grep -q '^dynamic_arena_bytes_patch:' runtime/general_runtime_template_x86_64.S
grep -q '^program_trailer_file_offset_patch:' runtime/general_runtime_template_x86_64.S
grep -q '^rankn_input_end_patch:' runtime/general_runtime_template_x86_64.S
grep -q '^g_measure_runtime_state_capacity:' compiler/general_frontend_x86_64.S
grep -q '^g_measure_rankn_input_workspace:' compiler/general_frontend_x86_64.S
! grep -Eq 'RPF_INPUT_(OBJ_)?STRIDE|GRPF_INPUT_STRIDE' compiler/general_frontend_x86_64.S runtime/general_runtime_template_x86_64.S
! grep -Eq '^\.equ (MAX_OPS|MAX_CONST_POOL|GEN_CAP),' compiler/field_frontend_common_x86_64.S
grep -q '^ff_prepare_graph_arena:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_prepare_code_arena:' compiler/field_frontend_common_x86_64.S
grep -q 'ff_code_overflow' compiler/field_frontend_common_x86_64.S
echo 'ARCHITECTURE_AGING_1_3_55=PASS'
echo 'WHEELCHAIR_1_3_55_BUILD=PASS'

# 1.3.56 final compiler-workspace aging. Field/access cardinality and Tensor
# staging/optimizer metadata are instance facts. Rank-8 remains the WHFLD216
# external-format width; logical VREG ownership remains the current physicalizer.
! grep -Rqs 'FIELD_RUNTIME_FIELD_CAP\|FIELD_RUNTIME_ACCESS_CAP' compiler runtime tools
! grep -RqsE '\bMAX_(FIELDS|SPECS|ACCESS)\b' compiler/field_frontend_common_x86_64.S runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S
grep -q '^\.equ FIELD_RUNTIME_RANK_CAP,8$' compiler/field_runtime_capacity.inc
grep -q '^ff_prepare_instance_arena:' compiler/field_frontend_common_x86_64.S
grep -q '^field_prepare_instance_arenas:' runtime/field_runtime_512_x86_64.S
for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_derived_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  grep -q '^tensor_prepare_code_arenas:' "$f"
  grep -q '^tensor_prepare_optimizer_arena:' "$f"
  ! grep -Eq 'EVAL_CAP|VEC_AOT_FACT_CAP|\.skip[[:space:]]+4194304|\.skip[[:space:]]+524288' "$f"
  ! grep -Eq '^vec_const_(bits|reg|addr):\.skip|^vec_linear_(binding|key_a|key_b|key_c|expr|coeff|mode):\.skip' "$f"
done
echo 'ARCHITECTURE_AGING_1_3_56=PASS'
echo 'WHEELCHAIR_1_3_56_BUILD=PASS'

# 1.3.57 ShapeFact-N convergence. Logical shape is one sparse semantic authority:
# axis identity + extent fact are stored; rank/product/stride are derived instead
# of serialized as compatibility scalars. Current Tensor consumers may collapse
# supported shapes onto one physical q root, but that capability restriction is
# not encoded into ShapeFact itself.
[ -f compiler/shapefact_n.inc ]
[ -f compiler/shapefact_n_frontend.inc ]
! grep -Eq '\.(equ|set)[[:space:]]+.*(MAX|CAP|LIMIT)' compiler/shapefact_n.inc compiler/shapefact_n_frontend.inc
! grep -RqsE 'rank_n_product|rank_n_source_rank|rank_n_product_patch|RUNTIME_RANK_N_PRODUCT|__rankn_q' compiler runtime tools
grep -q '^s_shapefact_validate:' compiler/surface_lowerer_x86_64.S
grep -q '^s_tensor_shapefact_prepare:' compiler/surface_lowerer_x86_64.S
grep -q '^s_emit_shapefact_json:' compiler/surface_lowerer_x86_64.S
grep -q '^shapefn_parse_root:' compiler/shapefact_n_frontend.inc
grep -q 'shape_fact_n' compiler/native_driver_x86_64.S
for f in \
  compiler/tensor_frontend_x86_64.S \
  compiler/tensor_frontend_native256_x86_64.S \
  compiler/tensor_derived_frontend_x86_64.S \
  compiler/tensor_derived_frontend_native256_x86_64.S; do
  grep -q 'compiler/shapefact_n' "$f"
done
echo 'SHAPEFACT_N_1_3_57=PASS'
echo 'SHAPEFACT_COMPATIBILITY_PRODUCT_DESCRIPTOR=0'
echo 'SHAPEFACT_FIXED_CAPACITY=0'
echo 'WHEELCHAIR_1_3_57_BUILD=PASS'

# 1.3.58 regression-only ShapeFact consumer-selector convergence. Presence of
# ShapeFact is not itself a derived-physicalizer predicate; the existing axis
# structure chooses between already-existing base and derived consumers.
grep -q '^shape_fact_requires_derived:' compiler/native_driver_x86_64.S
grep -q 'call shape_fact_requires_derived' compiler/native_driver_x86_64.S
echo 'SELECTOR_CONVERGENCE_1_3_58=PASS'
echo 'WHEELCHAIR_1_3_58_BUILD=PASS'
