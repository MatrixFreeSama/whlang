# Wheelchair 1.3.112 Release Notes

1.3.112 repairs the missing `P > 64` behavior of the existing whole-program `tolerance N` contract without creating a fast numerical mode.

- Surface preserves the numeric tolerance in canonical contracts instead of reducing it to the word `tolerant`.
- General derives one conservative binary `ToleranceFact`. If that fact cannot be exploited safely, the relation uses the pre-existing Strict convergence rule.
- `sqrt`, `exp`, `log`, and shared `sin/cos` consume relation-specific, mathematically conservative remainder/update bounds. Every inner add/sub/mul/div remains the same strict P-bit Rank-N operation.
- The single StrictClose/RNE arithmetic authority remains unchanged as the primitive result boundary. There is no tolerant add/mul/div family, precision selector, named-width backend, JIT, offload route, or source-visible parallel construct.
- The old `fpP ~(abs=...,rel=...)` local-type form is rejected instead of silently discarding its error object. 1.3.112 admits one real high-precision tolerance authority: program-level `tolerance N`.

At `tolerance 1e-10`, fixed-CPU A/B against 1.3.111 measures 5.0x-5.6x for 4096-bit exp/log/sin/cos, 12.6x-17.2x at 8192 bits, and 31.1x-43.1x at 16384 bits. sqrt improves about 1.11x, 1.49x and 1.81x respectively. These gains come from terminating proven-irrelevant iterations, not from reducing precision.

Strict output remains bit-identical on the retained fp127/fp521/fp4096/fp8192 advanced-math probes. A longer fixed-CPU recheck shows no structural Strict performance tax. Exact-rational tolerance validation covers 240 primary grid cases with zero bound violations; the worst observed error used under 9% of the admitted budget in that grid.
