# Testing 1.3.112

The current release authority remains the existing 29-test set under `devtrash/release_tests/current.list`; 1.3.112 extends the existing Rank-N physical-convergence gate instead of adding a thirtieth historical branch.

The Rank-N gate proves that the numeric tolerance reaches General, primitive add/sub/mul/div contain no tolerant path, advanced relations consume conservative tolerance proofs, and parameterized fpP type-local tolerance is not silently admitted. It also compares tolerant and Strict output by exact rational decoding.

Additional release validation covers fp127/fp521/fp4096/fp8192 Strict bit identity against 1.3.111 and broad positive/negative tolerance grids. The primary 240-case grid has zero violations of `abs_error <= tolerance + tolerance*abs(strict)`.
