# Performance 1.3.109

1.3.109 is primarily a physical-work and machine-code convergence release, not a broad wall-time speedup release.

For the same generated `sin(fp8192)` probe, General ELF `.text` falls from **16605 B** in unmodified 1.3.108 to **16029 B** in the final 1.3.109 candidate, a **576 B / 3.47%** reduction. Disassembly confirms that the obsolete limb-copy/shift helpers and the base-2^32 post-hoc high-length scanner are absent.

Fixed-CPU whole-process and same-process probes show small positive and negative movement, generally in the low-single-digit range. Some division and advanced-function samples improve by roughly 1.02x-1.07x while other samples are neutral or slightly slower. No universal runtime speedup is claimed. A temporary cross-span pointer-rotation realization produced clear locality regressions and was removed before release.

The retained changes are justified by fewer full-carrier passes, fewer global rescans, fewer whole-ValueFact copies, one less high-precision add in the sin double-angle relation, and smaller generated machine code. Raw A/B probes are retained under `devtrash/benchmarks/rankn_physical_convergence_13109/`.
