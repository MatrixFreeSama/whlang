# Testing 1.3.109

The current release authority remains 29 tests. The 1.3.108 Rank-N advanced-mathematics gate is replaced, not stacked, by `test_rankn_physical_convergence_13109.sh`; test-closure authority advances to 1.3.109.

The new gate proves:

- the established advanced-function local-propagation oracle still passes;
- obsolete carrier helpers are absent from production source;
- general division no longer performs post-hoc geometry rescans;
- RNE overflow no longer performs a full carrier shift;
- the zero twiddle is exact and does not invoke trigonometric reconstruction;
- the shared sin/cos series no longer clones a whole ValueFact merely to negate a temporary;
- the 1.3.108 fpP binding-kind lifetime, scalar quotient, ValueFact-silence and zero-relation repairs remain present;
- no second Rank-N math backend, named-width route, selector or local-float dialect appears.

The current 29 release gates pass in full. Independent A/B division probes over 65, 73, 127, 191, 257, 521, 1024, 4096 and 8192-bit precisions remain bit-identical to 1.3.108 on the sampled irregular operands.
