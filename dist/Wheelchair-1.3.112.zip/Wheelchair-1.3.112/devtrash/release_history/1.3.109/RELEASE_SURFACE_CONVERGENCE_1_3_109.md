# Release Surface Convergence 1.3.109

The source surface is unchanged. `fpP` remains the only arbitrary-precision floating surface and `PrecisionFact(P)` remains the precision authority.

Local propagation is an implementation invariant of the existing Rank-N architecture, not a user-visible mode. 1.3.109 adds no `localfp` keyword, no precision-family backend, no algorithm selector, no runtime dispatch surface and no source-visible parallel construct.

Historical 1.3.108 release documents are archived under `devtrash/release_history/1.3.108/`; the repository root carries only the current 1.3.109 release authority.
