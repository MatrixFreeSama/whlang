# Wheelchair 1.3.109 Release Notes

1.3.109 continues Rank-N aging by preserving local facts instead of reconstructing global facts after they are already known.

- Seven obsolete Rank-N helper authorities are removed from the production runtime. The old limb-copy/bit-shift helpers and the post-hoc base-2^32 high-length scanner no longer enter generated General ELFs.
- Knuth division carries geometry that is already implied by normalized `fpP` and by quotient production. It no longer rescans U/V/Q merely to rediscover their effective lengths.
- Strict RNE overflow closes directly onto the unique normalized top bit. The old full-P-bit right-shift after carry-out is gone.
- Fourier twiddle generation begins from the exact unit value `(1,0)` rather than evaluating `FSINCOS(0)`.
- `rankn_fp_neg`/`rankn_fp_abs` support true in-place sign realization, and the shared `sin/cos` series flips its disposable temporary sign in place rather than cloning a complete P-bit ValueFact only to negate it.
- `sin(2x)=2 sin(x) cos(x)` no longer materializes `sin+sin`; multiplication by two is the exact exponent relation after the product.
- Stable advanced-function scratch addresses are derived once where the current physical layout makes that profitable. Cross-span pointer rotation was measured and rejected because the current large private-span layout made locality worse; no compatibility branch is retained.

No named-width backend, precision selector, local-float dialect, alternate Rank-N engine, JIT, kernel-offload surface, scheduler, worker pool, or workload matcher is added.
