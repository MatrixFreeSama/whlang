# Testing 1.3.97

The current release authority contains 27 tests. 1.3.97 adds `test_general_state_authority_1397.sh`, which verifies the single FP-generation authority contract, absence of a partial hybrid/workload route, unchanged Strict reference bits, and removal of the generation transport tail when the complete proof succeeds on a wide-register host.

`test_general_scalar_physical_reality_1396.sh` remains active and continues to verify the 1.3.96 wide-register and residency repair. The full release gate is `./test.sh release`.
