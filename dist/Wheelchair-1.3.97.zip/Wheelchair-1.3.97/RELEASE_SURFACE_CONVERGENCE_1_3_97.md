# Release surface convergence 1.3.97

`bin/` remains the sole shipped executable authority. Generated `build/` content is excluded from the release archive. The 1.3.96 root release documents are retained only under `devtrash/release_history/1.3.96/`; root release names refer only to 1.3.97.

The General repair is a contraction of Physical Reality, not a new DSL surface: one complete FP generation either closes onto a fixed carrier authority or keeps the existing disjoint realization. No partial compatibility mode is shipped.
