# Wheelchair charter 1.3.97

The objective remains convergence of real physical work toward the mathematical-physical lower bound. Parallelism is a consequence of causal structure, never the language identity and never an occupancy target.

Compiler evolution must delete transport, duplicate authority and compatibility-shaped execution modes before adding machinery. 1.3.97 therefore accepts generation coalescing only as a complete causal proof inside the existing Physical Reality. It adds no source kernel language, worker pool, ready queue, work stealing, runtime silicon selector, benchmark route, or second semantic IR.
