# Architecture aging 1.3.96

This release does not add a General backend. It removes a stale boundary inside the existing Physical Reality: scalar FP carrier identity is now derived from compiler-wide ISA capability facts rather than a local 16-register constant.

Persistent constants and whole-episode CSE share the existing fact arena and carrier pressure authority. The source-order eight-value residency cliff and the artificial minimum-two transient reserve are gone. Wide and narrow register files are two realizations of one scalar FP geometry, not compatibility branches.
