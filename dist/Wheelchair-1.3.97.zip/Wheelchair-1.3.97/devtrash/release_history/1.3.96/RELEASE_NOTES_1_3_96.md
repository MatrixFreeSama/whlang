# Wheelchair 1.3.96

General scalar FP now consumes the same ISA capability authority already used by the wider physical architecture. `ISA_CAP_WIDE_REGFILE` exposes XMM16..31 as ordinary scalar carriers through one EVEX-capable Physical Reality; non-wide targets retain 16 carriers without a vendor or workload backend.

The old source-order eight-value constant/CSE residency cliffs and the arbitrary two-temporary reserve are deleted. Constant pressure now feeds the same remapping authority as repeated ValueFacts. Strict arithmetic order, rounding points, language semantics and the no-runtime-allocator rule are unchanged.

Same-host 20M-step Strict medians: mass3 149.417 -> 118.921 ms (1.256x), chem6 138.581 -> 136.311 ms (1.017x), rigid7 240.182 -> 189.122 ms (1.270x). No chem-specific path was added to hide its remaining next-generation transport cost.
