# Wheelchair charter 1.3.96

The objective remains convergence of real physical work toward the mathematical-physical lower bound, not occupancy and not benchmark-shaped parallelism. Parallelism is a consequence of causal structure; no source-visible kernel language, worker pool, ready queue, work stealing, runtime silicon selector, or DSL-specific execution branch is introduced.

Compiler evolution must prefer deletion, fusion and aging of existing Physical Reality authorities. A hardware capability may change physical geometry, but vendor names, workload names and historical package shapes do not own execution semantics.
