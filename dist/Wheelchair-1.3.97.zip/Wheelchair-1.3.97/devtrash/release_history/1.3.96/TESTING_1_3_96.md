# Testing 1.3.96

The current release authority contains 26 tests. 1.3.96 adds `test_general_scalar_physical_reality_1396.sh`, which verifies compiler-wide wide-register capability use, deletion of the old fixed General carrier/constant limits, exact Strict reference bits for mass3/chem6/rigid7, and high-XMM emission when the host exposes AVX-512.

The full release gate is `./test.sh release`. Field production binaries remain byte-identical to 1.3.95, and the representative Tensor strict output used during development remained byte-identical.
