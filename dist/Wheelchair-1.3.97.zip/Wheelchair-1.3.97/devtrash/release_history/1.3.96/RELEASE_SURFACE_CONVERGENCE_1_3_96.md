# Release surface convergence 1.3.96

`bin/` remains the sole shipped executable authority. Generated `build/` content is not packaged. The 1.3.95 root release documents are retained only under `devtrash/release_history/1.3.95/`; the root names only the current release.

General, Tensor and Field remain semantic surfaces over one compiler architecture. 1.3.96 converges General toward the mature capability/residency model rather than adding an alternate General/AMD/AVX-512 backend.
