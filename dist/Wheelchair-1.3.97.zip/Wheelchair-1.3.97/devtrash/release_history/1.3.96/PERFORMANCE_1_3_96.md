# Performance 1.3.96

Strict, 20,000,000 steps, eleven alternating rounds on the visible AMD EPYC 9V74 execution set (`taskset 0-4`). Values are medians.

| workload | 1.3.95 | 1.3.96 | speedup | C Strict | Fortran Strict |
|---|---:|---:|---:|---:|---:|
| mass3 | 149.417 ms | 118.921 ms | 1.256x | 110.943 ms | 110.387 ms |
| chem6 | 138.581 ms | 136.311 ms | 1.017x | 115.108 ms | 115.244 ms |
| rigid7 | 240.182 ms | 189.122 ms | 1.270x | 179.166 ms | 178.340 ms |

C: `gcc -O3 -march=native -fno-fast-math -ffp-contract=off`. Fortran additionally uses `-fprotect-parens`. Raw data: `devtrash/benchmarks/general_scalar_physical_reality_1396/general_fourway11.csv`.
