# Pure assembly release proof 1.3.96

Production compiler/runtime authority remains handwritten x86-64 assembly. The 1.3.96 General scalar change is implemented in `compiler/general_frontend_x86_64.S` and consumes the existing assembly ISA capability authority. No C/C++, Rust, LLVM, MLIR, Python, JIT, bytecode VM, HLS compiler, runtime register allocator, or workload-specific native helper enters production execution.
