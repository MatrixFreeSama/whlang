# Performance — 1.3.91

## Host scope

The release host exposes no proved FPGA target. Hardware acceleration cannot be measured and is not claimed.

## General whole-episode runtime

Frozen 1.3.90 and current 1.3.91 compiled `mass3`, `chem6`, and `rigid7`. Each executable ran for 20,000,000 steps over 30 interleaved measurements.

| Probe | 1.3.90 median | 1.3.91 median | old/new |
|---|---:|---:|---:|
| mass3 | 0.152114102 s | 0.151466581 s | 1.00428x |
| chem6 | 0.139141676 s | 0.139757524 s | 0.99559x |
| rigid7 | 0.239512689 s | 0.240163411 s | 0.99729x |
| geometric mean | | | **0.99905x** |

The probes disagree in direction. The geometric mean corresponds to about 0.095% slower for 1.3.91 and is treated as host noise. Truthful x86 runtime change: **0%**.

## Compiler time

Thirty interleaved compile measurements give geometric-mean `1.3.90/1.3.91 = 0.99412x`, about `+0.59%` compile time for 1.3.91. Median per-probe changes are on the order of hundredths of a millisecond.

## Image size

The three General images are each 128 bytes larger than 1.3.90 because the causal runtime now carries the direct activation entry and explicit-state completion ABI. The mathematical hot bodies are unchanged.

A representative production Field image keeps the same file size as 1.3.90. Unproved fabric emits zero datapath payload.

## Fabric proof

A proof-only fabric target serializes the existing seven-op Field `mixed.json` graph as a 344-byte datapath descriptor: 7 operations, 8 proved physical edges, maximum depth 3, and one memory barrier. Because no board bridge exists, the proof image rejects execution. This is an architecture proof, not a hardware benchmark.

Raw data: `devtrash/benchmarks/fabric_activation_field_datapath_1391/`.
