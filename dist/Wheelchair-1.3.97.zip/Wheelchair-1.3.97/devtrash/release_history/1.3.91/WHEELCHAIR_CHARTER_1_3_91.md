# Wheelchair charter — 1.3.91

Wheelchair remains a general-purpose AOT language. Hardware targets are realizations, never source-language subworlds.

1. Mathematical and causal facts remain semantic authority.
2. Physical Reality closes those facts against the exposed machine.
3. x86 and reconfigurable fabric may coexist in one Physical DAG realization.
4. Runtime may materialize an already-chosen domain but may not choose a device, query idle resources, steal work, or own a ready queue.
5. Fabric descriptors serialize existing Physical-DAG facts only. They may not become a second IR, kernel language, or scheduler.
6. Unknown hardware stays unknown. Missing fabric or bridge never authorizes x86 fallback.
7. Fixed PE counts, tile sizes, occupancy targets, and workload-name matchers are not architecture authority.
8. Optimization remains strict reduction of real physical work toward the mathematical-physical lower bound.
