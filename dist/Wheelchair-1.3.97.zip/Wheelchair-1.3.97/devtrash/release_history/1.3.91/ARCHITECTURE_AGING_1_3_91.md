# Architecture aging — 1.3.91

## Before

1.3.90 could prove heterogeneous placement and serialize each General Region, but fabric materialization still stopped at descriptor/admission boundaries. Field had a mature op-level Physical DAG but no target-consumable spatial projection.

## Aging

1.3.91 removes that split without creating another programming model:

```text
one semantic graph
-> one Physical DAG authority
-> one target realization tag
-> x86 native entry OR fabric activation entry
-> one causal completion law
```

General runtime consumes the AOT realization tag. It does not choose a device. Fabric activation receives the existing Region descriptor and an explicit-state completion callback.

Field fabric description is a serialization of facts that already existed before target selection: op records, causal depth, and physical order. It therefore cannot become a second scheduler or semantic IR.

Unknown fabric remains zero. Missing bridge remains failure. No compatibility fallback is retained.
