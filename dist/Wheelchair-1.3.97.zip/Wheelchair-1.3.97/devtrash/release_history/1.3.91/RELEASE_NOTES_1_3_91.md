# Wheelchair 1.3.91 release notes

1.3.91 deepens the same Physical Reality rather than adding an FPGA sublanguage.

- General fabric Regions now enter one direct activation-entry ABI instead of the x86 clone path.
- Fabric completion receives the invocation state base explicitly and rejoins the existing causal completion authority.
- General Physical Realization Descriptor format advances to version 2.
- Field serializes its existing op records, causal depths, and physical order into a fabric datapath descriptor only when external target facts prove a fabric domain.
- Production targets with no proved fabric emit zero Field fabric descriptor bytes.
- General and Field keep hard rejection for unbridged fabric; no x86 compatibility fallback exists.
- No kernel language, HLS authority, worker/task graph, fixed PE/tile model, runtime device selector, or second fabric IR was introduced.

The host has no real FPGA target. Measured x86 runtime change is 0% within noise. No FPGA speedup is claimed.
