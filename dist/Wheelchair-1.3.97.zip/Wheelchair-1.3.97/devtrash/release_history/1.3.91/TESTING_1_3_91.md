# Testing — 1.3.91

The current release authority contains 22 tests.

The new 1.3.91 gate proves:

- General direct fabric activation entry exists and is selected from the burned realization tag.
- external completion carries explicit causal-state identity;
- silicon contract format is `wheelchair.silicon-reality/8`;
- General descriptor format is version 2;
- production Field emits zero fabric descriptor bytes without proved hardware;
- proof-only Field target emits the exact existing op/depth/order projection;
- unbridged Field fabric execution is rejected;
- no FPGA/HLS kernel language, runtime device scheduler, fixed PE/tile route, or second fabric IR exists.

All earlier mathematical, Field, Tensor, General, Traffic, StateFact, CoordinateFact, silicon-domain and heterogeneous-edge gates remain active.
