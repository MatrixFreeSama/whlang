# Fabric activation and Field datapath — 1.3.91

## General activation ABI v2

`gr_materialize_node` consumes the already-burned realization tag. A reconfigurable-fabric Region enters `gr_activate_fabric_node` instead of the x86 clone path.

The bridge call receives:

```text
rdi = 48-byte Physical Realization Descriptor
esi = Region id
rdx = invocation causal-state base
ecx = successor materialization flags
r8  = gr_publish_completion_external
```

`gr_publish_completion_external` accepts the state base explicitly and enters the same `gr_publish_completion` authority used by x86. The bridge owns no successor graph.

Production does not provide a board activation entry, so fabric-tagged images remain non-executable rather than falling back to x86.

## Field datapath descriptor

When external fabric target facts are proved, Field appends:

```text
header[64]
op_record[N:32]
physical_depth[N:u32]
physical_order[N:u32]
```

Header fields are descriptor version, op count, proved physical-edge count, maximum causal depth, memory-barrier count, Traffic Reality ticks, chunk work ticks, and total descriptor bytes.

The payload is the existing Field compiler authority serialized directly. It is not Verilog, bytecode, HLS IR, a kernel graph, or a target-private scheduler.

The current release still does not contain a board driver, RTL emitter, place-and-route integration, or bitstream emitter.
