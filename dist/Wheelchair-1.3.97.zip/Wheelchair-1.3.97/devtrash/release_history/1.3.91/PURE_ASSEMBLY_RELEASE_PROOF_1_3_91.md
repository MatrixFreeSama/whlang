# Pure assembly release proof — 1.3.91

Production compiler and runtime authority remains handwritten x86-64 assembly plus shell build tooling. Production build invokes no Python generator, C compiler, LLVM backend, JIT, bytecode interpreter, HLS compiler, or FPGA kernel compiler.

The 1.3.91 fabric additions are assembly-level target metadata and ABI boundaries only. Proof tests may use Python to inspect generated ELF bytes; that inspection is not part of production compilation.
