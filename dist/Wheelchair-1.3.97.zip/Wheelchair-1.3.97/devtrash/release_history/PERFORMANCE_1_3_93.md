# Performance — 1.3.93

The primary regression witness is the historical lightweight Tensor reduction from 1.3.18, compiled on the current host with frozen 1.3.92 and repaired 1.3.93.

## 100M lightweight reduction, 15 interleaved rounds

| realization | 1.3.92 median | 1.3.93 median | 1.3.92 / 1.3.93 |
|---|---:|---:|---:|
| one execution | 36.833 ms | **24.723 ms** | **1.490x** |
| four admitted executions | 13.255 ms | **12.148 ms** | **1.091x** |

All outputs are bit-identical (`checksum_bits=0x422665f782000000`). The repaired image restores the two-carrier / sixteen-element loop and grows from 8561 B to 8825 B; this is useful code, not metadata.

## Contract-matched current references

A separate 15-round interleaved run of the repaired four-execution image measured:

| implementation | median |
|---|---:|
| Wheelchair 1.3.93 | **13.401 ms** |
| GCC fast-math reference | 15.011 ms |
| GFortran fast-math reference | 22.358 ms |

On that run, C time / Wheelchair time is **1.120x**. All three checksums are bit-identical.

## Continuity controls

Nine interleaved rounds show no meaningful broad regression:

| probe | 1.3.92 | 1.3.93 | old/new |
|---|---:|---:|---:|
| FSI 100M | 118.245 ms | 117.418 ms | 1.007x |
| dense Rank-3, n=8192 | 31.798 ms | 32.403 ms | 0.981x |

The dense change is small enough to treat as a continuity warning/noise-level result rather than a claimed regression. General `mass3`, `chem6`, and `rigid7` compiled to byte-identical executables between 1.3.92 and 1.3.93.

Raw data are under `devtrash/benchmarks/transport_issue_orthogonality_1393/`.
