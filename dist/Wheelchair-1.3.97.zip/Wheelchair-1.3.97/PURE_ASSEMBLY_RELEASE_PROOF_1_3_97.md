# Pure assembly release proof 1.3.97

Production compiler/runtime authority remains handwritten x86-64 assembly. The 1.3.97 StateFact lifetime repair is implemented in `compiler/general_frontend_x86_64.S` and the existing `compiler/physical_reality.inc` contract.

No C/C++, Rust, LLVM, MLIR, Python generator, JIT, bytecode VM, HLS compiler, runtime register allocator, workload helper, or alternate native recurrence backend enters production execution.
