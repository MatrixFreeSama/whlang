# Performance 1.3.97

Strict General, 20,000,000 steps, `taskset 0-4`, same visible AMD EPYC 9V74 execution set.

The authoritative old/new check is 31 alternating rounds. `mass3` and `rigid7` generate hot code with the same SHA256 as 1.3.96, so their timing variation is not attributed to this release. `chem6` proves the complete FP-generation fixed point and removes all six next-generation-to-old-generation scalar transports.

| workload | 1.3.96 median | 1.3.97 median | change |
|---|---:|---:|---:|
| mass3 | code-identical | code-identical | none |
| chem6 | 140.167 ms | **125.606 ms** | **1.1165x** |
| rigid7 | code-identical | code-identical | none |

Across these three equal-weight General probes, the geometric throughput change is about **1.0374x**. The gain is structural rather than a new arithmetic mode.

A separate 15-round four-way run measured `chem6` at 124.106 ms for 1.3.97, 117.507 ms for C Strict, and 118.969 ms for Fortran Strict. That leaves Wheelchair about 5.6% behind C and 4.3% behind Fortran in this residual deep-causal probe.

Raw evidence is retained in `devtrash/benchmarks/general_state_authority_1397/`.
