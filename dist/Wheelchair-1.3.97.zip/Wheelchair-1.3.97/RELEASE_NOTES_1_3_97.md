# Wheelchair 1.3.97

General scalar StateFact generations now close over one AOT carrier authority when the complete FP generation proves a fixed point under post-CSE liveness and exact Strict emitter order. Successful closure deletes the next-to-old transport boundary rather than moving it elsewhere.

The realization is deliberately all-or-none for one FP generation. Partial mixed authority is not retained as another mode. Failed proof uses the existing disjoint generation path unchanged. No workload matcher, vendor backend, runtime allocator, update reordering, source-visible kernel, worker model, or second General IR is introduced.

On the same host, the generic witness `chem6` removes six scalar generation transports and improves from 140.167 ms to 125.606 ms in 31 alternating 20M-step Strict rounds, a 1.1165x throughput gain. `mass3` and `rigid7` remain hot-code byte-identical to 1.3.96.
