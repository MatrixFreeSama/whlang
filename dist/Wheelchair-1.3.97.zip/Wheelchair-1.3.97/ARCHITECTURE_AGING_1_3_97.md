# Architecture aging 1.3.97

1.3.97 removes another scalar StateFact transport boundary from the existing General Physical Reality. It does not add a scheduler, recurrence backend, vendor route, or workload path.

After whole-episode CSE is fixed, the compiler proves whether the complete resident FP generation has one carrier fixed point: every next-state ValueFact must be able to be born in its own old-state authority after that authority's final effective consumer, while preserving the emitter's exact Strict operation order. If the complete proof succeeds, old and next carrier identity are the same and the timestep transport layer disappears. If any FP state fails, the entire FP generation retains the mature disjoint old/next realization.

Partial mixed-generation coalescing is deleted as an execution choice. One FP generation has one authority model.
