# Wheelchair 1.3.25

Wheelchair is an HPC- and simulation-first general-purpose language built around matrix-free execution, Rank-N semantics, AOT compilation, direct x86-64 machine code, ValueFacts, Physical Reality, and Physical DAG execution.

## Release surface

1.3.25 is the **Release Surface Cleanup / Branch-Growth Firewall** release. It deliberately does not change production machine code. The ten production binaries are byte-identical to 1.3.24; the change is structural authority.

```text
Wheelchair-1.3.25/
├── README.md
├── VERSION
├── SHA256SUMS
├── build.sh
├── RELEASE_NOTES_1_3_25.md
├── WHEELCHAIR_CHARTER_1_3_25.md
├── PURE_ASSEMBLY_RELEASE_PROOF_1_3_25.md
├── PERFORMANCE_1_3_25_RELEASE_SURFACE.md
├── PRODUCTION_BIN_SHA256_1_3_25.txt
├── bin/          # sole production executable authority
├── compiler/     # current compiler source authority
├── runtime/      # current runtime source authority
├── surface/      # current human/semantic surface authority
├── tools/        # current production build helpers
└── devtrash/     # non-production tests, benchmarks, history and archaeology
```

`bin/` is the only supported location for production executables. Root-level executable duplicates are forbidden.

`devtrash/` is intentionally shipped for research, regression, benchmarking and archaeology, but it has **zero production authority**. `build.sh`, `compiler/`, `runtime/`, `surface/` and production tools must not include, link, copy, parse, or otherwise depend on it. The 1.3.25 release gate physically removes `devtrash/` during a clean production build to prove this property.

## Why `devtrash/` exists

Wheelchair has accumulated many historical experiments and release gates. Keeping those artifacts beside current production source made it too easy for a successful old matcher, compatibility route, or benchmark-shaped optimization to grow another branch in the active compiler.

The rule from 1.3.25 onward is:

> Historical evidence may remain in `devtrash/`; historical architecture may not regain production authority from there.

A useful old optimization must be re-expressed as a general capability of the existing ValueFact / Physical Reality / Physical DAG architecture before it can re-enter production source.

## Build and run

```text
./build.sh
bin/whexc INPUT.wh -o OUTPUT
bin/wheelchairc INPUT.wh -o OUTPUT
bin/topologyc INPUT.whex -o OUTPUT
bin/fieldc INPUT.json -o OUTPUT
```

`build/` is reproducible scratch output and is not part of the shipped release surface.

See `WHEELCHAIR_CHARTER_1_3_25.md`, `RELEASE_NOTES_1_3_25.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_25.md`, and `PERFORMANCE_1_3_25_RELEASE_SURFACE.md`.
