#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1320_pressure_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc

# Deleted historical private transition-shape branches.
! grep -q 'g_match_transition_physical_pattern:' "$G"
! grep -q 'gc_phys_xadd_r9_r8' "$G"
! grep -q 'gc_phys_shift_add3' "$G"
! grep -q 'g_reg_iter_pattern' "$G"
grep -q '^g_phys_machine_canonicalize:' "$G"

# Same Physical Reality owns the remap; no workload-named path exists.
grep -q 'PR138_PRIVATE_TRANSITION_SHAPE_EMITTERS,0' "$P"
grep -q 'PR138_SHARED_PRESSURE_REMAP,1' "$P"
grep -q 'PR138_NEXT_VERSION_PRIVATE_BANK_MANDATORY,0' "$P"
grep -q 'PR138_WORKLOAD_SPECIFIC_PRESSURE_ROUTE,0' "$P"
! grep -Eqi '^g_.*(chem|reaction|rigid|mass3).*:' "$G"

echo 'PRIVATE_TRANSITION_SHAPE_BRANCHES=0'
echo 'UNIFIED_SHARED_PRESSURE_REMAP=PASS'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]
  objdump -d -Mintel "$T/$name" > "$T/$name.dis"
  awk '
    /cmp    rbx,rbp/ && !seen { seen=1; next }
    seen && /movabs ds:0x422100/ { exit }
    seen { print }
  ' "$T/$name.dis" > "$T/$name.hot"
  test -s "$T/$name.hot"
}

S=devtrash/benchmarks/general_whole_episode_1316
compile_run "$S/chem6.wh" chem 100000 'out00_bits=0x3fad4117d563218b'
compile_run "$S/mass3.wh" mass 100000 'out00_bits=0x3fa90c89b2e19b14'
compile_run "$S/rigid7.wh" rigid 100000 'out00_bits=0x3fd72fe2f4bace4b'
compile_run "$S/rigid7_cseprobe.wh" rigidcse 100000 'out00_bits=0x3fd92ec02dbff083'

# chem6 is only a probe. The generic pressure remap must expose the same 15
# multiply arithmetic floor as strict C/Fortran without adding a chemistry path.
[ "$(grep -c 'vmulsd' "$T/chem.hot")" -eq 15 ]
# Unrelated simulations retain their established machine-work counts.
[ "$(grep -c 'vmulsd' "$T/mass.hot")" -eq 18 ]
[ "$(grep -c 'vmulsd' "$T/rigid.hot")" -eq 41 ]
[ "$(grep -c 'vmulsd' "$T/rigidcse.hot")" -eq 38 ]

echo 'CHEM6_PROBE_VMUL_25_TO_15=PASS'
echo 'UNRELATED_SIMULATION_MACHINE_WORK_PRESERVED=PASS'

F=devtrash/tests/general_causal_state_1312
compile_run "$F/fib_iter.wh" fib 1000 'out00_bits=0x0b594dc75cc0604b'
compile_run "$F/lucas.wh" lucas 1000 'out00_bits=0xf0a8e2dd406a618f'
compile_run "$F/tribonacci.wh" tri 1000 'out00_bits=0x4215efb898bc7418'
# xadd may still emerge only as generic post-emission ISA canonicalization.
grep -q 'xadd   r9,r8' "$T/fib.hot"
grep -q 'xadd   r9,r8' "$T/lucas.hot"
! grep -q 'g_match_transition_physical_pattern:' "$G"

echo 'GENERIC_XADD_CANONICALIZATION=PASS'
echo 'STATE_COUNT_PRIVATE_ISA_ROUTE=0'
echo 'RUNTIME_VALUEFACT_MANAGER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'WHEELCHAIR_UNIFIED_VALUEFACT_PRESSURE_1_3_20=PASS'
