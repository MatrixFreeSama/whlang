#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1312_state_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

SRC=compiler/general_frontend_x86_64.S

# Structural authority: source variables are classified into physical roles.
grep -q 'causal-state register recurrence optimizer' "$SRC"
if [ "$(cat VERSION)" = 1.3.15 ] || [ "$(cat VERSION)" = 1.3.16 ] || [ "$(cat VERSION)" = 1.3.17 ] || [ "$(cat VERSION)" = 1.3.18 ] || [ "$(cat VERSION)" = 1.3.19 ] || case "$(cat VERSION)" in 1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac; then
  grep -q '^\.equ GMAX_STATES,64' "$SRC"
  ! grep -q 'cmp r14d,4; jae .gtri_no' "$SRC"
else
  grep -q 'cmp r14d,4; jae .gtri_no' "$SRC"
fi
grep -q 'g_reg_iter_data_count' "$SRC"
grep -q 'gc_reg_iter_cmp_rbx_rbp' "$SRC"
grep -q 'gc_reg_iter_inc_rbx' "$SRC"
grep -q 'gc_push_r10' "$SRC"
grep -q 'g_state_decl_scalar_type' "$SRC"
! grep -Eqi '\b(fibonacci|fib_iter|lucas|tribonacci|counter_value)\b' "$SRC"

echo 'GENERAL_CAUSAL_STATE_ROLE_ANALYSIS=PASS'
echo 'COUNTED_CONTROL_STATE_COLLAPSE=PASS'
echo 'CONTROL_STATE_CONSUMES_DATA_STATE_BUDGET=0'
echo 'HARDCODED_TWO_STATE_REGISTER_LIMIT=0'
if [ "$(cat VERSION)" = 1.3.15 ] || [ "$(cat VERSION)" = 1.3.16 ] || [ "$(cat VERSION)" = 1.3.17 ] || [ "$(cat VERSION)" = 1.3.18 ] || [ "$(cat VERSION)" = 1.3.19 ] || case "$(cat VERSION)" in 1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac; then
  echo 'REGISTER_RECURRENCE_DATA_CAPACITY=RANK_N_PHYSICAL_PRESSURE'
else
  echo 'REGISTER_RECURRENCE_DATA_CAPACITY=3'
fi
echo 'RUNTIME_STATE_ROLE_MANAGER=0'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]

  # Register recurrence must not materialize persistent state or transition
  # temp arrays in the emitted hot program. Historical generic fallback uses
  # these stable native runtime addresses; the fast path must contain neither.
  if objdump -d -Mintel "$T/$name" | grep -Eq '0x462100|0x482100'; then
    echo "REGISTER_RECURRENCE_STATE_SLOT_TRAFFIC=FAIL:$name" >&2
    exit 1
  fi
}

F=devtrash/tests/general_causal_state_1312
compile_run "$F/fib_iter.wh" fib 1000 'out00_bits=0x0b594dc75cc0604b'
compile_run "$F/lucas.wh" lucas 1000 'out00_bits=0xf0a8e2dd406a618f'
compile_run "$F/tribonacci.wh" tri 1000 'out00_bits=0x4215efb898bc7418'
compile_run "$F/float_recur.wh" float 1000 'out00_bits=0x3fefffff79ea9f6a'
compile_run "$F/counter_value.wh" counter_value 1000 'out00_bits=0x0000000000079f2c'

# Three true data states plus one counted control state must visibly use the
# third data carrier and the independent control carrier.
objdump -d -Mintel "$T/tri" > "$T/tri.dis"
grep -q 'mov    r10,rax' "$T/tri.dis"
grep -q 'cmp    rbx,rbp' "$T/tri.dis"
grep -q 'inc    rbx' "$T/tri.dis"

echo 'MULTI_STATE_REGISTER_RECURRENCE=PASS'
echo 'THREE_DATA_STATE_RECURRENCE=PASS'
echo 'FLOATING_REGISTER_RECURRENCE=PASS'
echo 'VALUE_PARTICIPATING_COUNTER=PASS'
echo 'PARALLEL_STATE_TRANSITION=PASS'
echo 'MANDATORY_STATE_TEMP_SLOT_COMMIT=0'
echo 'REGISTERIZED_RECURRENCE_STATE_LOADS=0'
echo 'REGISTERIZED_RECURRENCE_STATE_STORES=0'
echo 'FIBONACCI_SPECIALIZATION=0'
echo 'WORKLOAD_NAME_SPECIALIZATION=0'
echo 'BENCHMARK_SIZE_SPECIALIZATION=0'
echo 'RUNTIME_RECURSION=DEFERRED'
echo 'ACTIVE_SILICON_PURITY_IS_PRIMARY=1'
echo 'WHEELCHAIR_CAUSAL_STATE_COLLAPSE_1_3_12=PASS'
