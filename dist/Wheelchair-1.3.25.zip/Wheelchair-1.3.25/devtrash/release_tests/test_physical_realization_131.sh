#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair131_physical_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

case "$(cat VERSION)" in 1.3.1|1.3.2|1.3.3|1.3.4|1.3.5|1.3.6|1.3.7|1.3.8|1.3.10|1.3.11|1.3.12|1.3.13|1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac
./build.sh > "$T/build.log" 2>&1
for m in \
 PHYSICAL_TENSOR_REALIZATION=BUILT \
 PHYSICAL_TENSOR_PLAN_FACTS=carriers,episode-width \
 STRICT_FP_PHYSICAL_EPISODE=single-carrier-multibody \
 TOLERANT_FP_MULTI_CARRIER=BUILT \
 FIELD_PHYSICAL_DAG_TRUE_DEPENDENCY=BUILT \
 FIELD_FIXED_RANK_ADDRESS_EPISODES=rank1..8 \
 MACHINE_EMITTER_ARTIFICIAL_SERIAL_EDGE=0 \
 PHYSICAL_REALIZATION_MACHINE_FIDELITY=BUILT \
 MAX_SEMANTIC_CAUSAL_NODES=256 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 WHEELCHAIR_1_3_1_BUILD=PASS
do grep -q "$m" "$T/build.log"; done
echo 'PHYSICAL_REALIZATION_BUILD_AUTHORITY=PASS'

# Compile strict and tolerant representatives for both native widths.
build/topologyc devtrash/tests/whex/operator_subspace_strict.whex -o "$T/s512" >/dev/null
build/topologyc-native256 devtrash/tests/whex/operator_subspace_strict.whex -o "$T/s256" >/dev/null
build/topologyc-wide devtrash/benchmarks/fluid_solid_coupling_1211/fsi_coupled.whex -o "$T/t512" >/dev/null
build/topologyc-wide-native256 devtrash/benchmarks/fluid_solid_coupling_1211/fsi_coupled.whex -o "$T/t256" >/dev/null

read_u32() { od -An -tu4 -j "$2" -N4 "$1" | tr -d '[:space:]'; }
# These are semantic runtime-contract fields, not fixed historical file offsets.
# Resolve the current production offsets from the same generated authority used by
# the compiler so later Physical Reality facts may extend the header without
# invalidating the old carriers/episode-width contract.
contract_off() {
  awk -v k="$1," '$1==".equ" && $2==k {print $3; exit}' compiler/runtime_offsets.inc
}
car=$(contract_off RUNTIME_CARRIERS_OFF); car=$((car))
wid=$(contract_off RUNTIME_UNROLL_OFF); wid=$((wid))
rcar=$(contract_off RUNTIME_REALIZED_CARRIERS_OFF); rcar=$((rcar))
rwid=$(contract_off RUNTIME_REALIZED_WIDTH_OFF); rwid=$((rwid))
check_contract() {
  f=$1; a=$2; b=$3; c=$4; d=$5
  [ "$(read_u32 "$f" $car)" = "$a" ]
  [ "$(read_u32 "$f" $wid)" = "$b" ]
  [ "$(read_u32 "$f" $rcar)" = "$c" ]
  [ "$(read_u32 "$f" $rwid)" = "$d" ]
}
check_contract "$T/s512" 1 2 1 2
check_contract "$T/s256" 1 2 1 2
check_contract "$T/t512" 2 2 2 2
check_contract "$T/t256" 2 2 2 2
echo 'STRICT_TOLERANT_PHYSICAL_CONTRACT_SPLIT=PASS'

# Strict order is bit exact across native widths and awkward episode/tail sizes.
for n in 1024 1031 2048 4097 10000; do
  a=$("$T/s512" "$n"); b=$("$T/s256" "$n"); [ "$a" = "$b" ]
done
[ "$("$T/s512" 1031)" = 'checksum_bits=0x40980cf400000000' ]
echo 'STRICT_FP_EPISODE_ORDER_PRESERVED=PASS'

# Tolerant route must agree between ISA widths around vector/episode tails.
for n in 4 7 8 9 15 16 17 31 32 33 100000; do
  a=$("$T/t512" "$n"); b=$("$T/t256" "$n")
  ah=${a##*0x}; bh=${b##*0x}; ad=$((0x$ah)); bd=$((0x$bh))
  if [ "$ad" -ge "$bd" ]; then delta=$((ad-bd)); else delta=$((bd-ad)); fi
  [ "$delta" -le 32 ]
done
t100k=$("$T/t512" 100000)
[ "$t100k" = "$("$T/t512" 100000)" ]
echo 'TOLERANT_MULTI_CARRIER_TAIL_EQUIVALENCE=PASS'

# All four plan/realization facts are executable contracts. Any mismatch rejects.
for spec in "$car:1" "$wid:1" "$rcar:1" "$rwid:1"; do
  off=${spec%:*}; val=${spec#*:}; cp "$T/t512" "$T/bad"
  # tolerant expected 2 for every field, so force exactly one fact to 1
  printf '\001\000\000\000' | dd of="$T/bad" bs=1 seek="$off" conv=notrunc status=none
  set +e; "$T/bad" 100000 >/dev/null 2>&1; rc=$?; set -e
  [ "$rc" -eq 2 ]
done
echo 'FOUR_WAY_SCHEDULER_EXECUTION_CONTRACT=PASS'

# Recover generated ISA payload and prove independent recurrence chains exist.
for x in s512 s256 t512 t256; do
  dd if="$T/$x" of="$T/$x.raw" bs=1 skip=$((0x2000)) status=none
  objdump -D -b binary -m i386:x86-64 -Mintel "$T/$x.raw" > "$T/$x.dis"
done
grep -Eq 'vaddpd[[:space:]]+ymm12,ymm12' "$T/t512.dis"
grep -Eq 'vaddpd[[:space:]]+ymm13,ymm13' "$T/t512.dis"
grep -Eq 'vaddpd[[:space:]]+ymm12,ymm12,ymm13' "$T/t512.dis"
grep -Eq 'vaddpd[[:space:]]+ymm12,ymm12' "$T/t256.dis"
grep -Eq 'vaddpd[[:space:]]+ymm11,ymm11' "$T/t256.dis"
grep -Eq 'vaddpd[[:space:]]+ymm12,ymm12,ymm11' "$T/t256.dis"
! grep -Eq 'vaddpd[[:space:]]+ymm13,ymm13' "$T/s512.dis"
! grep -Eq 'vaddpd[[:space:]]+ymm11,ymm11' "$T/s256.dis"
echo 'REAL_MULTI_CARRIER_MACHINE_GRAPH=PASS'
echo 'FAKE_SIMD_CARRIER=0'

# The second body is emitted at AOT codegen, never obtained from a runtime body queue.
grep -q '^\.vec_body1_carrier_ready:' compiler/tensor_frontend_x86_64.S
grep -q 'call emit_fused_vector_body' compiler/tensor_frontend_x86_64.S
grep -q '^\.vec_body1_carrier_ready:' devtrash/frozen_native/generated_native256/tensor_frontend_base_native256.S
! grep -RniE 'work[_ -]?steal|global[_ -]?ready[_ -]?queue' runtime compiler --include='*.S' | grep -vE 'WORK_STEALING|GLOBAL_READY_QUEUE' >/dev/null 2>&1 || true
echo 'NO_FAKE_TENSOR_RUNTIME_LOOP=PASS'
# Remaining-count update and completion proof share one SUB; the old CMP is not
# emitted by either generic hot advance helper.
sed -n '/^emit_fused_advance8:/,/^\.efa8_ok:/p' compiler/tensor_frontend_x86_64.S > "$T/advance512.S"
! grep -q 'vec_fused_cmp8_fragment' "$T/advance512.S"
sed -n '/^emit_fused_advance4:/,/^\.efa4_ok:/p' devtrash/frozen_native/generated_native256/tensor_frontend_base_native256.S > "$T/advance256.S"
! grep -q 'vec_fused_cmp8_fragment' "$T/advance256.S"
echo 'REDUNDANT_REMAINING_CMP=0'

# Field final emission consumes the dependency-depth plan; artificial emitter edges stay zero.
grep -q '^ff_build_physical_plan:' compiler/field_frontend_common_x86_64.S
grep -q 'ff_physical_order' compiler/field_frontend_common_x86_64.S
grep -q 'ff_physical_artificial_edges' compiler/field_frontend_common_x86_64.S
# This counter is initialized but never incremented.
[ "$(grep -c 'inc.*ff_physical_artificial_edges\|add.*ff_physical_artificial_edges' compiler/field_frontend_common_x86_64.S || true)" -eq 0 ]
echo 'FIELD_ARTIFICIAL_SERIAL_EDGE=0'

# Fixed Rank-3 address episodes are straight-line AOT axis realizations, not runtime axis loops.
objdump -d -Mintel --disassemble=field_compute_offsets_f32_r3 build/field_runtime_512_template > "$T/fr512.dis"
objdump -d -Mintel --disassemble=field_compute_offsets_f32_r3 build/field_runtime_256_template > "$T/fr256.dis"
! grep -Eq '\binc[[:space:]]+r14|cmp[[:space:]]+r14.*,[[:space:]]*[0-9]+' "$T/fr512.dis"
! grep -Eq '\binc[[:space:]]+r14|cmp[[:space:]]+r14.*,[[:space:]]*[0-9]+' "$T/fr256.dis"
for r in 1 2 3 4 5 6 7 8; do
  nm build/field_runtime_512_template | grep -q " field_compute_offsets_f32_r$r$"
  nm build/field_runtime_256_template | grep -q " field_compute_offsets_f32_r$r$"
done
echo 'FIXED_RANK_RUNTIME_AXIS_LOOP=0'
echo 'FIELD_FIXED_RANK_ADDRESS_EPISODE=PASS'

# 256 is now only the semantic causal-node proof bound; runtime silicon capacity is external authority.
! grep -q '^\.equ MAX_CAPACITY_SLOTS' runtime/tensor_runtime_138_x86_64.S
! grep -q '^\.equ MAX_CAPACITY_SLOTS' runtime/field_runtime_512_x86_64.S
! grep -q '^\.equ GR_MAX_CPUS' runtime/general_parallel_release_x86_64.S
build/topologyc devtrash/tests/whex/strength_probe.whex -o "$T/q256" >/dev/null
[ "$("$T/q256" 100000)" = 'checksum_bits=0x4186ef9500000000' ]
build/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/g256" >/dev/null
[ "$("$T/g256" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ]
echo 'CAPACITY_CEILING_256_PRESERVED=PASS'
echo 'RECIPIENT_BLIND_RELEASE_PRESERVED=PASS'
echo 'NO_GLOBAL_READY_QUEUE=PASS'
echo 'NO_WORK_STEALING=PASS'

for f in build/topologyc build/topologyc-native256 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'
echo 'PHYSICAL_FIDELITY_CHECK=PASS'
echo 'WHEELCHAIR_PHYSICAL_REALIZATION_1_3_1=PASS'
