#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.14|1.3.15|1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1315_rankn_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc
S=compiler/surface_lowerer_x86_64.S

# Rank-N strengthens the existing causal Axis and Physical Reality.  There is no
# large-state backend, runtime state manager, or state-count workload dispatch.
grep -q 'PR138_CAUSAL_PARTIAL_RESIDENCY,1' "$P"
grep -q 'PR138_INDUCTION_IS_AXIS_AUTHORITY,1' "$P"
grep -q 'PR138_STATE_COUNT_ADMISSION_THRESHOLD,0' "$P"
grep -q 'PR138_PRIVATE_PAGE_CACHE_COLORING,1' "$P"
grep -q '^\.equ GMAX_STATES,64' "$G"
grep -q '^\.equ SCOPE_MAX,64' "$S"
grep -q '^g_phys_assign_state_carriers:' "$G"
grep -q '^g_state_slot_addr:' "$G"
grep -q 'imul rax,rax,4160' "$G"
# Rank-N no longer owns 2-state/3-state private transition selectors.
! grep -q 'g_match_transition_physical_pattern:' "$G"
! grep -Eq 'g_reg_iter_data_count.*,[23]' "$G"
! grep -Eq 'g_reg_iter_data_count.*(ja|jae|jg|jge).*gtri_no' "$G"
! grep -Eq '\b(large_state|int4|state4|ring32)_.*:' "$G"

echo 'CAUSAL_STATE_RANK_N_OLD_STRUCTURE=PASS'
echo 'STATE_COUNT_BACKEND_THRESHOLD=0'
echo 'INDUCTION_AS_PERSISTENT_MODEL_STATE=0'
echo 'RUNTIME_STATE_MANAGER=0'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]
  objdump -d -Mintel "$T/$name" > "$T/$name.dis"
}
S15=devtrash/tests/general_rankn_causal_1315
compile_run "$S15/ring4.wh" ring4 100000 'out00_bits=0x3fecf47569847127'
compile_run "$S15/ring8.wh" ring8 100000 'out00_bits=0x3fecf46d818b3308'
compile_run "$S15/ring16.wh" ring16 100000 'out00_bits=0x3fecf46d818b2b3b'
compile_run "$S15/ring32.wh" ring32 100000 'out00_bits=0x3fecf46d818b2b3b'
compile_run "$S15/int8_ring.wh" int8 100 'out00_bits=0xbbbff58564000000'
compile_run "$S15/mixed8.wh" mixed8 1000 'out00_bits=0x3feffbe7af931abb'
compile_run "$S15/mixed8_intout.wh" mixed8i 100 'out00_bits=0x0004000000000000'

echo 'RANKN_FP_INTEGER_MIXED_DIFFERENTIAL=PASS'

hot_body() {
  objdump -d -Mintel "$1" | awk '
    /cmp    rbx,rbp/ && !seen { seen=1; next }
    seen && /movabs ds:0x422100/ { exit }
    seen { print }
  '
}
for b in ring4 ring8 ring16 ring32 int8 mixed8 mixed8i; do
  hot_body "$T/$b" > "$T/$b.hot"
  ! grep -Eq '(^|[[:space:]])(push|pop)([[:space:]]|$)' "$T/$b.hot"
done
# Beyond resident capacity, memory traffic may appear only as physical pressure;
# it must not switch the whole episode back to the stack evaluator.
grep -Eq '0x46[0-9a-f]+' "$T/ring32.hot"
grep -Eq '0x46[0-9a-f]+' "$T/int8.hot"
grep -Eq 'v(add|sub|mul)sd' "$T/ring32.hot"
grep -Eq '[[:space:]]add[[:space:]]' "$T/int8.hot"

echo 'SMALL_N_ARTIFICIAL_STACK_TRAFFIC=0'
echo 'LARGE_N_ARTIFICIAL_STACK_TRAFFIC=0'
echo 'PARTIAL_RESIDENCY=PASS'
echo 'SPILL_CAUSE=PHYSICAL_PRESSURE_ONLY'

# Protect pre-existing peaks through the same architecture.
devtrash/release_tests/test_unified_physical_reality_1314.sh >/dev/null
devtrash/release_tests/test_register_native_transition_1313.sh >/dev/null
echo 'TECHNICAL_PEAK_PRESERVATION=PASS'

echo 'RUNTIME_DAG_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_RANKN_CAUSAL_PHYSICALIZATION_1_3_15=PASS'
