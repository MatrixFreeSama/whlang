#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.16|1.3.17|1.3.18|1.3.19|1.3.20|1.3.21|1.3.22|1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac
T=${TMPDIR:-/tmp}/wheelchair1316_episode_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc
S=devtrash/tests/general_whole_episode_1316

# 1.3.16 strengthens the old compiler-wide Physical Reality.  No workload
# family is allowed to own a separate cache, backend, runtime graph, or carrier
# manager merely because its simultaneous update set is deeper or has more
# distinct constants.
grep -q 'PR138_WHOLE_EPISODE_VALUEFACT_CSE,1' "$P"
grep -q 'PR138_EXACT_STRICT_ORDER_CSE,1' "$P"
grep -q 'PR138_AOT_TEMP_PRESSURE_PROOF,1' "$P"
grep -q 'PR138_CONSTANT_COUNT_ADMISSION_THRESHOLD,0' "$P"
grep -q 'PR138_PRESSURE_BACKEND_CLIFF,0' "$P"
grep -q 'PR138_RUNTIME_CSE_MANAGER,0' "$P"
grep -q 'PR138_RUNTIME_VALUEFACT_CACHE,0' "$P"
grep -q '^g_phys_cse_note_tree:' "$G"
grep -q '^g_phys_shared_xmm_alloc:' "$G"
grep -q '^g_phys_cse_overlaps_selected:' "$G"
grep -q '^g_emit_phys_episode_cse:' "$G"
grep -q 'g_phys_fp_temp_peak' "$G"
! grep -Eq '^g_phys_(chem|reaction|rigid|mass3|const[0-9]).*:' "$G"

echo 'WHOLE_EPISODE_OLD_STRUCTURE_STRENGTHENING=PASS'
echo 'WORKLOAD_SPECIFIC_CSE_BACKEND=0'
echo 'CONSTANT_COUNT_BACKEND_THRESHOLD=0'

compile_run() {
  src=$1; name=$2; n=$3; expect=$4
  build/wheelchairc "$src" -o "$T/$name" >/dev/null
  got=$("$T/$name" "$n")
  [ "$got" = "$expect" ]
  objdump -d -Mintel "$T/$name" > "$T/$name.dis"
  awk '
    /cmp    rbx,rbp/ && !seen { seen=1; next }
    seen && /movabs ds:0x422100/ { exit }
    seen { print }
  ' "$T/$name.dis" > "$T/$name.hot"
  test -s "$T/$name.hot"
  ! grep -Eq '(^|[[:space:]])(push|pop)([[:space:]]|$)' "$T/$name.hot"
  grep -q 'vmulsd' "$T/$name.hot"
}

compile_run "$S/const2.wh" const2 100000 'out00_bits=0x3fd74dc04a761d4c'
compile_run "$S/const3.wh" const3 100000 'out00_bits=0x3fd7465b5f763f84'
compile_run "$S/const4.wh" const4 100000 'out00_bits=0x3fd7de4fbcbcefe5'
compile_run "$S/const5.wh" const5 100000 'out00_bits=0x3fd4854936b40ed7'
compile_run "$S/const6.wh" const6 100000 'out00_bits=0x3fd2730a285f6a91'
compile_run "$S/const7.wh" const7 100000 'out00_bits=0x3fd6765a78f4a65a'
compile_run "$S/const8.wh" const8 100000 'out00_bits=0x3fdca347578b6156'

echo 'CONSTANT_PRESSURE_2_TO_8_NO_BACKEND_CLIFF=PASS'

compile_run "$S/rigid7_cseprobe.wh" rigidcse 100000 'out00_bits=0x3fd92ec02dbff083'
compile_run "$S/chem6.wh" chem6 100000 'out00_bits=0x3fad4117d563218b'
compile_run "$S/rigid7.wh" rigid7 100000 'out00_bits=0x3fd72fe2f4bace4b'
compile_run "$S/mass3.wh" mass3 100000 'out00_bits=0x3fa90c89b2e19b14'

# The quaternion norm probe must share its repeated strict-order subtree across
# four next-state expressions.  The resulting arithmetic count is the same
# protected count observed from strict C/Fortran references on this source.
[ "$(grep -c 'vmulsd' "$T/rigidcse.hot")" -eq 38 ]
[ "$(grep -c 'vaddsd' "$T/rigidcse.hot")" -eq 19 ]
[ "$(grep -c 'vsubsd' "$T/rigidcse.hot")" -eq 4 ]
# Chemical network used 33 multiplies before whole-episode exact ValueFacts;
# this release must retain the measured reduction without a special reaction path.
[ "$(grep -c 'vmulsd' "$T/chem6.hot")" -le 25 ]
# The mechanically unrelated 6-state chain keeps its mature arithmetic count.
[ "$(grep -c 'vmulsd' "$T/mass3.hot")" -eq 18 ]

echo 'CROSS_NEXT_STATE_EXACT_CSE=PASS'
echo 'PARENT_CHILD_RETAINED_CSE_ANTICHAIN=PASS'
echo 'HOT_ARTIFICIAL_PUSH_POP=0'

# Protected older architecture remains authoritative.
devtrash/release_tests/test_rankn_causal_1315.sh >/dev/null
devtrash/release_tests/test_register_native_transition_1313.sh >/dev/null

echo 'RANKN_CAUSAL_PEAK_PRESERVED=PASS'
echo 'REGISTER_NATIVE_PEAK_PRESERVED=PASS'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'RUNTIME_CSE_MANAGER=0'
echo 'RUNTIME_VALUEFACT_CACHE=0'
echo 'RUNTIME_DAG_WALKER=0'
echo 'RUNTIME_REGISTER_ALLOCATOR=0'
echo 'GLOBAL_READY_QUEUE=0'
echo 'WORK_STEALING=0'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_WHOLE_EPISODE_PHYSICAL_DAG_1_3_16=PASS'
