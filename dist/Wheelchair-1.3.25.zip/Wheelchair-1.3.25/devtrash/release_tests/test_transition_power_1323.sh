#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
case "$(cat VERSION)" in 1.3.23|1.3.24|1.3.25) ;; *) exit 1 ;; esac
TMP=${TMPDIR:-/tmp}/wheelchair_transition_power_1323_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"
G=compiler/general_frontend_x86_64.S
P=compiler/physical_reality_138.inc

# Architecture authority: this is inside the existing counted recurrence path.
grep -q '^g_try_emit_reg_iterate:' "$G"
grep -q '^g_try_emit_transition_power_slice:' "$G"
grep -q '^g_collect_u64_transition_affine:' "$G"
grep -q 'PR138_TRANSITION_POWER_CLOSED_FAMILY,1' "$P"
grep -q 'PR138_TRANSITION_POWER_BACKWARD_SLICE,1' "$P"
grep -q 'PR138_TRANSITION_POWER_STATE_COUNT_ROUTE,0' "$P"
grep -q 'PR138_TRANSITION_POWER_REPEAT_THRESHOLD,0' "$P"
grep -q 'PR138_FIXED_AFFINE_AST_MATCHER,0' "$P"
grep -q 'PR138_RUNTIME_TRANSITION_POWER_MANAGER,0' "$P"

# The deleted private route must stay absent, including frozen production sources.
! grep -R -q 'g_try_emit_affine_iterate\|g_match_affine_update\|gc_affine_' compiler devtrash/frozen_native --include='*.S' --include='*.inc'
! grep -R -q 'vec_select_interior_false\|expr_is_axis_delta1' compiler devtrash/frozen_native --include='*.S' --include='*.inc'

# Historical LCG: same semantics, but O(log N) must be recovered through the
# generic counted recurrence Physical Reality rather than the deleted 2-state route.
./build/wheelchairc devtrash/tests/general/lcg64_iterate_wrap.wh -o "$TMP/lcg" >/dev/null
[ "$("$TMP/lcg" 42 10)" = 'out00_bits=0x06593f7b1358c594' ]
[ "$("$TMP/lcg" 42 10000000)" = 'out00_bits=0x929c95aa45b914aa' ]
objdump -d -Mintel "$TMP/lcg" > "$TMP/lcg.dis"
grep -Eq 'shr[[:space:]]+r9,1' "$TMP/lcg.dis"
grep -Eq 'test[[:space:]]+r9,0x1' "$TMP/lcg.dis"

# State count must not be the admission gate. Nine semantic states enter the
# same proof; seven coupled siblings are outside the published-result backward
# slice and therefore need no physical work for this result.
cp devtrash/tests/general_rankn_causal_1315/int8_ring.wh "$TMP/rankn.wh"
sed -i 's/update s0 = s0 + s1/update s0 = s0 + 10/' "$TMP/rankn.wh"
./build/wheelchairc "$TMP/rankn.wh" -o "$TMP/rankn" >/dev/null
[ "$("$TMP/rankn" 10)" = 'out00_bits=0x0000000000000065' ]
[ "$("$TMP/rankn" 10000000)" = 'out00_bits=0x0000000005f5e101' ]
objdump -d -Mintel "$TMP/rankn" > "$TMP/rankn.dis"
grep -Eq 'shr[[:space:]]+r9,1' "$TMP/rankn.dis"

# Non-closed/non-affine recurrence must stay on the ordinary causal DAG.
./build/wheelchairc devtrash/tests/general/nonaffine_iterate_wrap.wh -o "$TMP/nonaff" >/dev/null
[ "$("$TMP/nonaff" 10)" = 'out00_bits=0x59d44b3118cfac50' ]
objdump -d -Mintel "$TMP/nonaff" > "$TMP/nonaff.dis"
grep -Eq 'cmp[[:space:]]+rbx,rbp' "$TMP/nonaff.dis"

printf '%s\n' \
 'LCG_OLD_OLOGN_CAPABILITY_RECOVERED=PASS' \
 'TRANSITION_POWER_STATE_COUNT_ROUTE=0' \
 'RANKN_PUBLISHED_RESULT_BACKWARD_SLICE=PASS' \
 'NONCLOSED_RECURRENCE_GENERIC_DAG_FALLBACK=PASS' \
 'FIXED_TWO_STATE_AFFINE_ROUTE=0' \
 'FIXED_AFFINE_AST_MATCHER=0' \
 'RUNTIME_TRANSITION_POWER_MANAGER=0' \
 'FROZEN_BOUNDARY_SELECT_PRIVATE_MATCHER=0' \
 'WHEELCHAIR_TRANSITION_POWER_1_3_23=PASS'
