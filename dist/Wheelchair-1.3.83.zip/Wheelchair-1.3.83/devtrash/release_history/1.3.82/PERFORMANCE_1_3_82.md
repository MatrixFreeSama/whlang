# Performance Notes 1.3.82

Performance measurements are evidence for physical-work removal. They are not release authority and are not universal superiority claims.

## Long generic Rank-N induction

Validation host: 5-vCPU AMD EPYC 9V74 KVM guest. The benchmark was pinned to one CPU. The logical field shape was `127 x 131 x 997`, f32, with padded/non-contiguous strides. The same strict checksum was produced by both releases.

Interleaved whole-process medians:

| release | median |
|---|---:|
| 1.3.81 | 81.87 ms |
| 1.3.82 | 57.34 ms |
| ratio | 1.43x |

The workload intentionally exercises long generic execution. 1.3.81 repeatedly reconstructs Rank-N packet coordinates; 1.3.82 carries and advances one canonical CoordinateFact.

## Small periodic 7-neighbor case

For the `64^3` all-ones periodic case, the measured whole-process improvement was about 1.04x on the same host. Static generated-segment inspection changed vector stack traffic around the coordinate/gather machinery from roughly 19 stores and 9 loads to 5 stores and 2 loads; the Native512 zmm17 offset round-trip is absent.

The modest wall-time change is consistent with the remaining costs: truly straddling gathers and fixed process/runtime work dominate a very small problem once repeated coordinate decode is removed.

Static instruction counts are not dynamic event counts. The release does not infer execution frequency from duplicated alternative code in the generated ELF.
