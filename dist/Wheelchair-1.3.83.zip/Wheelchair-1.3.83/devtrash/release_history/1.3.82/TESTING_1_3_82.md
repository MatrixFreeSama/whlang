# Testing 1.3.82

The current release authority is `devtrash/release_tests/current.list` and contains 15 executable tests.

1.3.82 adds `test_coordinatefact_aging_1382.sh` while retaining all prior semantic, human-shell, region, ownership, machine-fact, Physical-DAG/ISA, physical-work, and mathematical/physical convergence gates.

The new gate verifies:

- one CoordinateFact authority rather than a second optimizer family;
- exact non-power-of-two generic coordinate induction;
- padded/non-contiguous field strides;
- Native512 and Native256 strict checksum agreement;
- no Native512 zmm17 coordinate-offset stack round-trip;
- preservation of truthful gather for a genuinely straddling packet;
- absence of coordinate workload routing, fixed coordinate tiles, and coordinate work stealing.

`./test.sh release` rebuilds production and records the current release log and production executable hashes.
