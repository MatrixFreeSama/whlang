# Wheelchair 1.3.82 Release Notes

## Persistent Rank-N CoordinateFact

1.3.82 does not add a new optimization family. It extends the lifetime of an existing mathematical fact so that the Field backend no longer has to rediscover its Rank-N position for every access in long generic/boundary execution.

The common fact chain is now explicit:

```text
AxisFact -> CoordinateFact -> AddressFact -> ValueFact
```

### Native512

- ZMM24..31 are the execution-local canonical Rank-N coordinate carrier bank.
- Rank 1 through Rank 8 coordinate preparation, coordinate-relative offset construction, and exact coordinate advancement are part of the existing Field runtime authority.
- One packet coordinate parent is shared by all accesses and layouts in that packet.
- Continuous generic execution advances coordinates exactly across packets.
- Power-of-two extents use shift/mask as a physical realization of the same rule.
- Non-power-of-two extents use exact div/mod recurrence.
- Offset vectors are consumed directly by gathers and no longer acquire stack authority merely to be reloaded.

### Native256

Native256 keeps the exact existing coordinate realization. Its 16-vector-register budget does not provide an independent eight-register coordinate bank without displacing live ValueFacts. This is a physical ISA decision, not a compatibility route.

### Preserved boundaries

- Truly straddling periodic packets still gather.
- No boundary workload name appears in production routing.
- No fixed coordinate tile/window/chunk exists.
- No CoordinateFact scheduler, manager, second IR, runtime tuner, or work-stealing layer exists.
- Existing ValueFact, AddressFact, RegionFact, Traffic Reality, causal-region, and strict floating-point authorities remain unchanged.

## Correctness

The new release gate includes a padded non-power-of-two Rank-3 field with extents `3 x 5 x 37`. Native512 and Native256 both return the exact strict checksum `0x440ac000` for the same mathematical field.

The current release authority is 15/15 PASS.
