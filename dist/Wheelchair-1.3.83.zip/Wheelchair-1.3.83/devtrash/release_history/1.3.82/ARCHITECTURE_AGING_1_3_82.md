# Architecture Aging 1.3.82

1.3.82 continues the rule that new performance work must collapse into old authority rather than grow another mechanism.

## What was missing

Field already retained long-lived AddressFacts, RegionFacts, and ValueFacts. The generic path still treated Rank-N coordinates as short-lived helper output. That split caused the machine to rediscover a mathematical fact that had not changed.

Tensor already contained persistent dense-coordinate induction. 1.3.82 reuses that architectural idea in Field and moves it under the same Physical Reality laws.

## What was removed

Native512 no longer uses coordinate-offset stack slots as runtime authority. The frame namespace remains reserved because older constant/transient numbering shares the same address domain; partially renumbering the frame would add risk without reducing executed work. The slots are therefore names, not traffic.

Per-access Rank-N re-decoding is no longer the Native512 generic realization. Continuous generic packets carry their exact coordinate state forward.

## What was not added

There is no:

- boundary optimizer;
- stencil selector;
- CoordinateFact scheduler;
- coordinate-specific second IR;
- fixed window/tile/chunk;
- runtime bandwidth probe;
- idle-worker observer;
- work-stealing queue.

The change is a fact-lifetime extension only.
