# CoordinateFact Aging 1.3.82

## Mathematical fact

For a Rank-N packet, every field access starts from the same canonical logical coordinates and differs only by its affine access delta and physical field stride.

The old generic realization could repeatedly perform:

```text
linear q -> packet lanes -> Rank-N decode -> access delta -> physical offset
```

for different accesses that shared the same parent coordinate fact.

1.3.82 makes the parent explicit:

```text
linear q -> CoordinateFact
                 |
                 +-> delta_0 -> AddressFact_0
                 +-> delta_1 -> AddressFact_1
                 +-> ...
```

For continuous generic packets:

```text
CoordinateFact(k+1) = exact_successor(CoordinateFact(k), 16 lanes)
```

rather than another decode from `q`.

## Physical laws

`compiler/physical_reality.inc` fixes the release rules:

```text
PR_PERSISTENT_RANKN_COORDINATEFACT=1
PR_COORDINATEFACT_PER_ACCESS_REDECODE=0
PR_COORDINATEFACT_EXECUTION_LOCAL_CARRIERS=1
PR_COORDINATEFACT_SHARED_ACROSS_LAYOUTS=1
PR_AVX512_COORDINATE_OFFSET_STACK_AUTHORITY=0
PR_COORDINATEFACT_SECOND_IR=0
PR_COORDINATE_WORKLOAD_MATCHER=0
```

The carrier is execution-local. No shared mutable coordinate state is introduced.

## Correctness boundary

The release regression covers non-power-of-two extents, padding, non-contiguous strides, multi-packet induction, tail masking, Native512, and Native256. A truly straddling periodic packet must still contain `vgatherdps`; removing a necessary gather would fail the structural gate.
