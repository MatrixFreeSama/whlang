# Wheelchair Charter 1.3.82

Wheelchair minimizes physical work required to realize mathematical structure.

## Permanent rules

1. Mathematical dependence is primary; serial and parallel execution are physical consequences, not source-level goals.
2. Idle hardware is allowed. Work is externalized only when the remaining burden can repay its physical materialization cost.
3. Completed execution returns capacity without searching for a receiver or maintaining an idle-worker map.
4. Physical Reality, Traffic Reality, and Physical DAG remain single authorities. New benchmark-specific schedulers and selector families are forbidden.
5. Facts live until their last unavoidable physical consumer. 1.3.82 applies this rule to Rank-N CoordinateFacts as already applied to addresses and values.
6. A periodic or irregular mathematical relation is not treated as random merely because a generic machine instruction can represent it.
7. Performance claims are subordinate to semantic correctness and physical-work accounting.
8. The long-term comparison target is the mathematical-physical lower bound, not occupancy and not another language.
