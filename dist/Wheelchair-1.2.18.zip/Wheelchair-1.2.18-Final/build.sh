#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD="$ROOT/build"
FROZEN="$ROOT/frozen_native"
rm -rf "$BUILD"
mkdir -p "$BUILD/generated_derived" "$BUILD/generated_native256"
cd "$ROOT"

# Frozen native physicalizations remain source authority. 1.2.14 preserves
# the tensor runtime lifecycle sources under the manifest; every frozen byte is
# verified before it can enter the production build.
(cd "$FROZEN" && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
cp -a "$FROZEN/generated_derived/." "$BUILD/generated_derived/"
cp -a "$FROZEN/generated_native256/." "$BUILD/generated_native256/"
cp "$FROZEN/topologyc_multi_isa_x86_64.S" "$BUILD/topologyc_multi_isa_x86_64.S"
cp "$FROZEN/tensor_frontend_profile_base.S" "$BUILD/tensor_frontend_profile_base.S"
cp "$FROZEN/tensor_frontend_profile_wide.S" "$BUILD/tensor_frontend_profile_wide.S"

echo 'FROZEN_NATIVE_ASSEMBLY_SHA256=PASS'
echo 'PRODUCTION_BUILD_PYTHON_GENERATORS=0'

# Mature native-512 runtime remains the protected physical peak.
as --64 runtime/tensor_runtime_template_x86_64.S -o "$BUILD/tensor_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_template.o" -o "$BUILD/tensor_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_template" compiler/runtime_offsets.inc

# Mature derived native-512 runtime from frozen authoritative assembly.
as --64 "$BUILD/generated_derived/tensor_derived_runtime_template_x86_64.S" -o "$BUILD/tensor_derived_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_template.o" -o "$BUILD/tensor_derived_runtime_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_template" "$BUILD/runtime_derived_offsets.inc"
derived_product_va=$(nm -n "$BUILD/tensor_derived_runtime_template" | awk '$3=="rank_n_product_patch" {print "0x"$1; exit}')
[ -n "$derived_product_va" ]
printf '.equ RUNTIME_RANK_N_PRODUCT_OFF, 0x%x\n' $((derived_product_va-0x400000)) >> "$BUILD/runtime_derived_offsets.inc"

# True AVX2/YMM runtimes, also frozen as source rather than regenerated.
as --64 "$BUILD/generated_native256/tensor_runtime_native256_template_x86_64.S" -o "$BUILD/tensor_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_runtime_native256_template.o" -o "$BUILD/tensor_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_runtime_native256_template" "$BUILD/runtime_native256_offsets.inc"

as --64 "$BUILD/generated_native256/tensor_derived_runtime_native256_template_x86_64.S" -o "$BUILD/tensor_derived_runtime_native256_template.o"
ld -nostdlib -static -z noexecstack -T runtime/tensor_runtime.ld \
  "$BUILD/tensor_derived_runtime_native256_template.o" -o "$BUILD/tensor_derived_runtime_native256_template"
./tools/generate_tensor_runtime_offsets.sh "$BUILD/tensor_derived_runtime_native256_template" "$BUILD/runtime_derived_native256_offsets.inc"
derived256_product_va=$(nm -n "$BUILD/tensor_derived_runtime_native256_template" | awk '$3=="rank_n_product_patch" {print "0x"$1; exit}')
[ -n "$derived256_product_va" ]
printf '.equ RUNTIME_RANK_N_PRODUCT_OFF, 0x%x\n' $((derived256_product_va-0x400000)) >> "$BUILD/runtime_derived_native256_offsets.inc"

# The freshly derived offsets must remain byte-identical to the frozen proof.
cmp "$BUILD/runtime_derived_offsets.inc" "$FROZEN/runtime_derived_offsets.inc"
cmp "$BUILD/runtime_native256_offsets.inc" "$FROZEN/runtime_native256_offsets.inc"
cmp "$BUILD/runtime_derived_native256_offsets.inc" "$FROZEN/runtime_derived_native256_offsets.inc"

echo 'FROZEN_RUNTIME_OFFSETS_EQUIVALENCE=PASS'

as --64 runtime/general_runtime_template_x86_64.S -o "$BUILD/general_runtime_template.o"
ld -nostdlib -static -z noexecstack -T runtime/general_runtime.ld \
  "$BUILD/general_runtime_template.o" -o "$BUILD/general_runtime_template"
./tools/generate_general_runtime_offsets.sh "$BUILD/general_runtime_template" compiler/general_runtime_offsets.inc

# Recipient-blind causal-region runtime. Offset derivation is shell + native ELF
# symbols only; no Python participates in production build authority.
as --64 runtime/general_parallel_release_x86_64.S -o "$BUILD/general_parallel_release.o"
ld -nostdlib -static -z noexecstack -T runtime/general_parallel_release.ld \
  "$BUILD/general_parallel_release.o" -o "$BUILD/general_parallel_release.elf"
objcopy -O binary --only-section=.text \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin"
sh tools/generate_general_parallel_release_offsets.sh \
  "$BUILD/general_parallel_release.elf" "$BUILD/general_parallel_release_template.bin" \
  "$BUILD/general_parallel_release_offsets.json"
cmp "$BUILD/general_parallel_release_offsets.json" "$FROZEN/general_parallel_release_offsets.json"

echo 'GENERAL_PARALLEL_RELEASE_OFFSETS_NO_PYTHON=PASS'

# Shared handwritten sovereign topology core with physical-shape capability algebra.
as --64 "$BUILD/topologyc_multi_isa_x86_64.S" -o "$BUILD/topologyc_core.o"
as --64 compiler/general_frontend_x86_64.S -o "$BUILD/general_frontend.o"
as --64 compiler/general_runtime_blob_x86_64.S -o "$BUILD/general_runtime_blob.o"
as --64 compiler/general_parallel_release_blob_x86_64.S -o "$BUILD/general_parallel_release_blob.o"
as --64 compiler/surface_lowerer_x86_64.S -o "$BUILD/surface_lowerer.o"

# Native/split 512 physicalizers.
as --64 "$BUILD/tensor_frontend_profile_base.S" -o "$BUILD/tensor_frontend_base.o"
as --64 "$BUILD/tensor_frontend_profile_wide.S" -o "$BUILD/tensor_frontend_wide.o"
as --64 compiler/runtime_blob_x86_64.S -o "$BUILD/runtime_blob.o"

# 1.2.17 sovereign native field lane.  This extends the separate direct-native AOT
# physicalization so the protected 1.2.15 f64 tensor path remains byte-authoritative.
# The field lane is pure handwritten assembly and maps materialized WHFLD216
# fields directly; it never routes through C, LLVM, JIT, Python, or a bytecode
# interpreter.
as --64 runtime/field_runtime_512_x86_64.S -o "$BUILD/field_runtime_512.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_512.o" -o "$BUILD/field_runtime_512_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_512_offsets.inc"

as --64 runtime/field_runtime_256_x86_64.S -o "$BUILD/field_runtime_256.o"
ld -nostdlib -static -z noexecstack -T runtime/field_runtime.ld \
  "$BUILD/field_runtime_256.o" -o "$BUILD/field_runtime_256_template"
sh tools/generate_field_runtime_offsets.sh \
  "$BUILD/field_runtime_256_template" "$BUILD/field_runtime_256_offsets.inc"

as --64 compiler/field_runtime_blob_512_x86_64.S -o "$BUILD/field_runtime_blob_512.o"
as --64 compiler/field_runtime_blob_256_x86_64.S -o "$BUILD/field_runtime_blob_256.o"
as --64 compiler/field_frontend_512_x86_64.S -o "$BUILD/field_frontend_512.o"
as --64 compiler/field_frontend_256_x86_64.S -o "$BUILD/field_frontend_256.o"
as --64 compiler/fieldc_driver_x86_64.S -o "$BUILD/fieldc_driver.o"
as --64 compiler/field_parser_link_stubs_x86_64.S -o "$BUILD/field_parser_link_stubs.o"

# Reuse only the frozen handwritten JSON parser symbols from the mature tensor
# frontend.  Unreachable tensor-only parser link references are satisfied by
# compile-time stubs; no tensor scheduler/runtime is entered by fieldc.
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_512.o" \
  "$BUILD/tensor_frontend_base.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_512.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc"
ld -nostdlib -static -z noexecstack \
  "$BUILD/fieldc_driver.o" "$BUILD/field_frontend_256.o" \
  "$BUILD/tensor_frontend_base.o" "$BUILD/runtime_blob.o" \
  "$BUILD/field_runtime_blob_256.o" "$BUILD/field_parser_link_stubs.o" "$BUILD/surface_lowerer.o" \
  -o "$BUILD/fieldc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_base.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_wide.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-wide"
as --64 "$BUILD/generated_derived/tensor_derived_frontend_x86_64.S" -o "$BUILD/tensor_frontend_derived.o"
as --64 "$BUILD/generated_derived/runtime_derived_blob_x86_64.S" -o "$BUILD/runtime_derived_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_derived.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived"

# Native256 physicalizers for every generic graph-resource class.
as --64 "$BUILD/generated_native256/tensor_frontend_base_native256.S" -o "$BUILD/tensor_frontend_base_native256.o"
as --64 "$BUILD/generated_native256/tensor_frontend_wide_native256.S" -o "$BUILD/tensor_frontend_wide_native256.o"
as --64 "$BUILD/generated_native256/tensor_frontend_derived_native256.S" -o "$BUILD/tensor_frontend_derived_native256.o"
as --64 "$BUILD/generated_native256/runtime_native256_blob_x86_64.S" -o "$BUILD/runtime_native256_blob.o"
as --64 "$BUILD/generated_native256/runtime_derived_native256_blob_x86_64.S" -o "$BUILD/runtime_derived_native256_blob.o"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_base_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_wide_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-wide-native256"
ld -nostdlib -static -z noexecstack \
  "$BUILD/topologyc_core.o" "$BUILD/tensor_frontend_derived_native256.o" "$BUILD/general_frontend.o" \
  "$BUILD/runtime_derived_native256_blob.o" "$BUILD/general_runtime_blob.o" "$BUILD/general_parallel_release_blob.o" "$BUILD/surface_lowerer.o" -o "$BUILD/topologyc-derived-native256"

# Native production launchers.  The driver performs only compile-time structural
# classification (base/wide/derived from canonical structure); it never retries a failed compiler
# and never inspects workload names.
as --64 compiler/native_driver_x86_64.S -o "$BUILD/native_driver.o"
ld -nostdlib -static -z noexecstack "$BUILD/native_driver.o" "$BUILD/surface_lowerer.o" -o "$BUILD/wheelchairc"
cp "$BUILD/wheelchairc" "$BUILD/whexc"

for f in \
  "$BUILD/topologyc" "$BUILD/topologyc-wide" "$BUILD/topologyc-derived" \
  "$BUILD/topologyc-native256" "$BUILD/topologyc-wide-native256" "$BUILD/topologyc-derived-native256" \
  "$BUILD/tensor_runtime_template" "$BUILD/tensor_derived_runtime_template" \
  "$BUILD/tensor_runtime_native256_template" "$BUILD/tensor_derived_runtime_native256_template" \
  "$BUILD/general_runtime_template" "$BUILD/general_parallel_release.elf" \
  "$BUILD/field_runtime_512_template" "$BUILD/field_runtime_256_template" \
  "$BUILD/fieldc" "$BUILD/fieldc-native256" \
  "$BUILD/wheelchairc" "$BUILD/whexc"; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# Production build closure must not invoke Python. Python remains allowed only
# in reference/validation tooling while the human surface is being migrated.
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'Python invocation leaked into production build' >&2; exit 1
fi

echo 'GENERIC_PRODUCT_SUBTRACT_CONTRACTION=BUILT'
echo 'GENERIC_VECTOR_REDUCTION_RESIDENCY=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_BASE=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_WIDE=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_DERIVED=BUILT'
echo 'NATIVE_RESOURCE_PROFILE_WORKLOAD_DISPATCH=0'
echo 'NATIVE_RESOURCE_PROFILE_RUNTIME_SELECTOR=0'
echo 'MULTI_ISA_TOPOLOGYC=BUILT'
echo 'PHYSICAL_VECTOR_SHAPES=native256,split512x256,native512'
echo 'NATIVE256_BASE=BUILT'
echo 'NATIVE256_WIDE=BUILT'
echo 'NATIVE256_DERIVED=BUILT'
echo 'NATIVE256_SCALAR_FALLBACK=0'
echo 'PHYSICAL_VECTOR_PROFILE_WORKLOAD_DISPATCH=0'
echo 'PHYSICAL_VECTOR_RUNTIME_PROFITABILITY_SELECTOR=0'
echo 'GENERAL_PARALLEL_BLIND_RELEASE_ENGINE=BUILT'
echo 'GENERAL_PARALLEL_FABRIC_AUTHORITY=blind-release-program-slot'
echo 'GENERAL_PARALLEL_GLOBAL_READY_QUEUE=0'
echo 'GENERAL_PARALLEL_ROOT_SCHEDULER=0'
echo 'GENERAL_PARALLEL_RUNTIME_COST_SELECTOR=0'
echo 'GENERAL_PARALLEL_SERIAL_FALLBACK=0'
echo 'GENERAL_PARALLEL_RUNTIME_FIXED_HOME_OWNERSHIP=0'
echo 'GENERAL_PARALLEL_PERSISTENT_IDLE_WORKER_SPIN=0'
echo 'GENERAL_PARALLEL_POST_COMPLETION_WORK_SEARCH=0'
echo 'GENERAL_PARALLEL_POST_COMPLETION_PEER_QUERY=0'
echo 'GENERAL_PARALLEL_RESOURCE_RELEASE_DESTINATION=0'
echo 'GENERAL_PARALLEL_RESOURCE_HANDOFF=0'
echo 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS'
echo 'ACTIVE_SPECIAL_PURPOSE_NATIVE_ROUTE=0'
echo 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0'
echo 'PRODUCTION_NATIVE_LAUNCHERS=BUILT'
echo 'TENSOR_INVOCATION_STACK_ARENA=BUILT'
echo 'TENSOR_RECURSIVE_STACK_MMAP=0'
echo 'TENSOR_RECURSIVE_STACK_MUNMAP=0'
echo 'CAUSAL_MESH_COARSENING=BUILT'
echo 'CAUSAL_WIDTH_PRESERVATION_GATE=BUILT'
echo 'ADAPTIVE_EXECUTION_GRANULARITY=BUILT'
echo 'WHEELCHAIR_1_2_14_FROZEN_ASSEMBLY_BUILD=PASS'
echo 'WHEELCHAIR_1_2_14_NATIVE_PROFILE_SELECTOR=BUILT'
echo 'EXECUTION_REPRESENTATION_COMPRESSION=BUILT'
echo 'DENSE_RANKN_COORDINATE_INDUCTION=BUILT'
echo 'DENSE_RANKN_COALESCED_AXIS_CARRY=BUILT'
echo 'NO_NEGATIVE_STRUCTURAL_COMPRESSION=BUILT'
echo 'DERIVED_AFFINE_INDUCTION=BUILT'
echo 'CROSS_AXIS_LICM=BUILT'
echo 'DENSE_STATIC_INNER_UNROLL=BUILT'
echo 'DELAYED_ZMM_REDUCTION=BUILT'
echo 'BOUNDARY_IDENTITY_ELIMINATION=BUILT'
echo 'PROVEN_ZERO_TAIL_ELIMINATION=BUILT'
echo 'RANKN_LIFETIME_REGISTER_REUSE=BUILT'
echo 'DENSE_CARETAKER_OPTIMIZATION_1_2_14=BUILT'
echo 'WHEELCHAIR_BUILD=PASS'
# 1.2.15 capability markers. Historical 1.2.14 markers above remain for
# regression gates and do not imply an old release version.
echo 'RANKN_COORDINATE_ALGEBRA_1_2_15=BUILT'
echo 'RANKN_AFFINE_NEIGHBORHOOD_GATHER=BUILT'
echo 'RANKN_PERIODIC_PHYSICAL_RING_LOWERING=BUILT'
echo 'RANKN_PHYSICAL_DOMAIN_PROOFS=BUILT'
echo 'RANKN_NEIGHBORHOOD_NATIVE256_EQUIVALENCE=BUILT'
echo 'WHEELCHAIR_1_2_15_BUILD=PASS'

echo 'NATIVE_FIELD_ABI_1_2_16=BUILT'
echo 'RANKN_F32_NATIVE512=BUILT'
echo 'RANKN_F32_NATIVE256=BUILT'
echo 'MULTI_DYNAMIC_EXTENTS_FIELD=BUILT'
echo 'GENERAL_CONST_INTEGER_DIVMOD=BUILT'
echo 'FIELD_NOALIAS_CONTRACT=BUILT'
echo 'FIELD_INOUT_MODE=BUILT'
echo 'FIELD_INTERPRETER=0'
echo 'FIELD_SCALAR_FALLBACK=0'
echo 'FIELD_C_LLVM_JIT_BACKEND=0'
echo 'WHEELCHAIR_1_2_16_BUILD=PASS'

# 1.2.17 generic field-locality caretaker layer. No source/ABI change.
echo 'FIELD_LOAD_IDENTITY_ALGEBRA_1_2_17=BUILT'
echo 'NEIGHBORHOOD_COORDINATE_CSE_1_2_17=BUILT'
echo 'INPUT_LAYOUT_EQUIVALENCE_PROOF_1_2_17=BUILT'
echo 'DYNAMIC_POW2_ADDRESS_STRENGTH_REDUCTION_1_2_17=BUILT'
echo 'REUSE_WEIGHTED_FIELD_RESIDENCY_1_2_17=BUILT'
echo 'FIELD_VERSION_SAFE_CACHE_1_2_17=BUILT'
echo 'FIELD_LOCALITY_WORKLOAD_DISPATCH=0'
echo 'FIELD_LOCALITY_RUNTIME_READY_QUEUE=0'
echo 'FIELD_LOCALITY_WORK_STEALING=0'
echo 'WHEELCHAIR_1_2_17_BUILD=PASS'

# 1.2.18 human Field surface completion.  WH/WHEX materialized-field syntax is
# compile-time only and erases into the unchanged wheelchair.field/1 canonical
# graph before the 1.2.17 locality backend.  No new runtime or ABI layer exists.
echo 'NATIVE_FIELD_HUMAN_SURFACE_1_2_18=BUILT'
echo 'WH_WHEX_FIELD_BRIDGE_1_2_18=BUILT'
echo 'PURE_FN_LEXICAL_SCOPE_1_2_18=BUILT'
echo 'FIELD_SURFACE_NEW_RUNTIME_LAYER=0'
echo 'FIELD_SURFACE_CANONICAL_FORMAT=wheelchair.field/1'
echo 'FIELD_SURFACE_ABI=WHFLD216'
echo 'WHEELCHAIR_1_2_18_BUILD=PASS'
