# Wheelchair Charter 1.3.127

1.3.127 continues the same rule: structure is algebra before it is machinery. A peak and a basin are polarity-dual Facts, not two optimizer families. A product of sparse facts does not justify an active-set subsystem; it remains a RegionSet fact consumed by the existing Physical DAG.

Delete absent work before adding execution width. Do not encode material names, benchmark geometry, active counts, or source-visible scheduling choices.
