# Wheelchair 1.3.127 Performance

Retained real benchmark: localized elastoplastic return mapping on a 1D integration-point line. A fixed-width stress concentration yields about 3999 points while the surrounding elastic domain grows. The plastic increment and dissipation are thin arithmetic; useful plastic work is approximately independent of total `n`.

## Pinned one CPU, 17 interleaved rounds, n=8,000,000

| implementation | median |
|---|---:|
| Wheelchair 1.3.127 | 2.150 ms |
| Wheelchair 1.3.126 | 110.463 ms |
| C natural serial | 11.773 ms |
| Fortran natural serial | 12.924 ms |
| C hand-bounded active-zone ceiling | 3.176 ms |
| Fortran hand-bounded active-zone ceiling | 4.427 ms |

1.3.127 is **51.37x faster than 1.3.126**, **5.47x faster than natural C**, and **6.01x faster than natural Fortran** in this run. The hand-bounded controls contain problem-specific active-zone knowledge; Wheelchair obtains the support from the general SupportFact algebra.

Wheelchair strict checksum remains `0x41a3afe47af3fef6`; C/Fortran use a different legal reduction order and differ by a few ULP.

## Domain-size probe

| n | 1.3.126 | 1.3.127 | C | Fortran |
|---:|---:|---:|---:|---:|
| 1M | 24.656 ms | 2.617 ms | 5.740 ms | 7.318 ms |
| 4M | 65.044 | 2.849 | 11.573 | 9.646 |
| 8M | 110.490 | 2.430 | 14.141 | 12.606 |
| 16M | 220.711 | 2.196 | 21.067 | 21.507 |

The 1.3.126 path scales with the elastic background. 1.3.127 stays near fixed support/process cost.

## Four available CPUs, n=8,000,000

| implementation | median |
|---|---:|
| Wheelchair 1.3.127 | 1.919 ms |
| Wheelchair 1.3.126 | 115.032 ms |
| C natural OpenMP | 8.568 ms |
| Fortran natural OpenMP | 10.161 ms |

The shrunken RegionSet no longer needs full-domain parallel occupancy.
