# Release Surface Convergence 1.3.121

No source-visible construct is added. Deep indexed coordinates use the same existing WHEX syntax and converge earlier inside the existing CoordinateFact authority. There is no schedule annotation, parallel DSL, recurrence keyword, depth knob, compatibility spill language, workload selector, or second tensor IR.
