# Architecture Aging 1.3.121

The release moves indexed CoordinateFact composition ahead of vector realization. A chain `f_k o ... o f_1` is reduced in the existing affine/periodic coordinate algebra, then materialized once. `(1,0)` becomes identity; equivalent signed residues share one Z/nZ representation. The previous recursive lifetime pattern, where every indexed map held a live SIMD carrier until its child returned, is removed.

Derived persistent coordinate metadata now follows the existing physical ZMM16..25 Fact ownership pool instead of independent software capacities of 6 and 2. This deletes a private partition rather than enlarging it.
