# Wheelchair 1.3.121 Performance

The retained structural-inflation benchmark keeps mathematical work constant: every added pair is an exact `+17` / `-17` periodic remap, so the final field is bit-identical to depth zero. On one pinned CPU with 8,000,000 elements, same-host medians are:

| Pairs | 1.3.120 | 1.3.121 | speedup | C | Fortran |
|---:|---:|---:|---:|---:|---:|
| 0 | 99.018 ms | 98.684 ms | 1.00x | 35.876 ms | 32.499 ms |
| 4 | 162.779 ms | 99.233 ms | 1.64x | 114.273 ms | 110.978 ms |
| 8 | 272.056 ms | 100.247 ms | 2.71x | 153.922 ms | 149.383 ms |
| 12 | 394.124 ms | 99.647 ms | 3.96x | 199.103 ms | 200.410 ms |

1.3.120 executable size grows from 8513 to 11529 bytes over 0..12 pairs. 1.3.121 emits 8513 bytes at every tested depth; 0, 12, 13, 25, 50, 100 and 200 pairs produce the same executable SHA-256 and zero `div/idiv`. A non-identity 100x `+17` chain also emits exactly the same binary as direct `+1700`, demonstrating general composition rather than an inverse-pair benchmark route.
