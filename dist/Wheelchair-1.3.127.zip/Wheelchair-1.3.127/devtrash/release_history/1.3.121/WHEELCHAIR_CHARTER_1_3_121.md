# Wheelchair Charter 1.3.121

1.3.121 treats structural nesting as algebra to eliminate before physical work, not as a request to allocate more machinery. Limits caused only by stale software partitions are deleted; real ISA and discovered-machine facts remain explicit. Larger ABI frontiers are not disguised by replacing one magic constant with another.
