# Wheelchair 1.3.121 Release Notes

1.3.121 makes CoordinateFact composition canonical before physical realization. Indexed affine/periodic chains are composed in the existing integer coordinate algebra, exact identities are deleted, non-identity chains collapse to one fact, and signed representatives normalize in the same Z/nZ materializer. Source nesting therefore no longer consumes one SIMD carrier per indexed map or exposes AVX-512 register count as a language depth limit.

The derived tensor backend also removes the old private 6-slot dense/mixed/scaled partitions and 2-slot induction partition by deriving their metadata and ownership namespace from the existing persistent physical Fact register pool. Native256 dead induction state with no producer is deleted. The compiler does not add a spill compatibility path, benchmark matcher, rank-specific route, second coordinate backend, source-visible schedule, or DSL primitive.

Several unrelated heuristic constants are retired rather than retuned: the SIMD-byte-shaped front-end budget, Field's 8 MiB / 2x / 4x non-temporal-store selector, a dead mutable-slot constant, and the defensive 32-subleaf cache-enumeration cap. Physical facts remain the authority.
