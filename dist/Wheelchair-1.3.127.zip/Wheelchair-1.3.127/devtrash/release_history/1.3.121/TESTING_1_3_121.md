# Wheelchair 1.3.121 Testing

The current release authority contains 31 tests. The new CoordinateFact composition regression requires exact binary identity between depth zero and 64 canceling remap pairs, exact binary identity between a 32-step non-identity affine chain and its directly composed coordinate, correct signed-residue output, absence of workload-specific coordinate routes, absence of the retired private 6/2 derived partitions, and absence of the retired front-end/Field heuristic constants.

The prior mixed-radix TensorFact regression remains mandatory, preventing the hard-limit cleanup from trading old coordinate capability for the new path.
