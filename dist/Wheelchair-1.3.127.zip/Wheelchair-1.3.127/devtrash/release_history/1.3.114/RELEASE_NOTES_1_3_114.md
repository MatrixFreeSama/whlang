# Wheelchair 1.3.114 Release Notes

1.3.114 ages repeated scalar control facts into the same whole-episode Physical ValueFact authority already used by arithmetic CSE. It removes the next major General-control redundancy exposed after 1.3.113 without adding a workload route or second backend.

- Repeated compare/boolean expressions are now episode-scoped PredicateFacts and may remain resident exactly like repeated FP ValueFacts.
- Predicate payloads reuse the existing pressure-derived shared XMM carrier authority; no predicate-specific runtime table, cache manager, or hard-coded repetition threshold is introduced.
- Retained parent and child arithmetic facts are no longer forced into an artificial antichain. If both have independent future consumers, real carrier pressure alone decides whether both remain resident.
- Retained facts are emitted from lower structural cost toward parents, so a parent consumes already-realized child ValueFacts instead of recomputing them during episode materialization.
- The native iterate `while` condition now uses the same Physical predicate emitter instead of re-entering the generic expression stack.
- Dead antichain/containment code is deleted after the residency rule is removed.
- No Mandelbrot/fractal/pixel recognizer, JIT, runtime scheduler, source-visible parallel route, DSL selector, or second scalar backend is added.

Strict scalar Mandelbrot (768x768, 512-iteration bound, fixed CPU) improves from a 1.3.113 median of 513.52 ms to 347.94 ms across 15 interleaved runs, **1.476x**, with identical checksum `0x00000000032e223d`. Fresh comparison medians in the same run set are 140.28 ms for C and 140.96 ms for Fortran. Relative to the retained 1.3.112 median of 2252.69 ms, the cumulative control-path repair is **6.474x**.

Generated trailer counts confirm reduced physical work: `vucomisd` 8->1, `seta` 8->1, `setae` 8->1, `sete` 4->1, `vaddsd` 12->5, `movabs` 44->27, and trailer bytes 3661->3193.

The remaining gap to mature C/Fortran scalar code is still visible and is not hidden behind a benchmark-specific optimization.
