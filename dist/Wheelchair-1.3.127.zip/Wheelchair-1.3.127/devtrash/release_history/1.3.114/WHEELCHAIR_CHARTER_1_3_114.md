# Wheelchair Charter 1.3.114

Wheelchair remains an AOT, general-purpose, simulation/HPC-first language whose execution is derived from mathematical structure, causal facts and physical reality rather than from a source-visible parallel programming model.

Control is not a second language inside the language. Predicates are ValueFacts, lazy choices are causal regions, and StateFact versions remain governed by one dependency graph. Repeated facts should be represented once when physical lifetime permits; parent/child identity is not itself a reason to duplicate work.

Compatibility is not preserved when it would require duplicate execution authorities or false semantics. No workload route is accepted as a substitute for General convergence.
