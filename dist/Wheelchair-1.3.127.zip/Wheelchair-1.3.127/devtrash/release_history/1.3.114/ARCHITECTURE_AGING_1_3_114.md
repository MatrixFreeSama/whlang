# Architecture Aging 1.3.114

Repeated arithmetic and repeated control now use one episode ValueFact vocabulary:

```text
old StateFacts
    -> arithmetic ValueFacts
    -> PredicateFacts
    -> lazy select Regions
    -> next StateFacts
```

A PredicateFact is not a workload annotation or control-flow DSL object. It is an ordinary exact boolean relation whose lifetime is the current old-state epoch. If the same relation has multiple consumers in that epoch, the Physical Reality layer may retain its exact 0/1 payload in the same shared carrier authority used by other repeated facts.

Residency is no longer constrained by a parent/child antichain. A child fact and a parent fact may both remain resident when both still have independent consumers. Physical carrier pressure remains the only admission authority.

Materialization order follows structural dependency cost from leaves toward parents, so selected parent facts consume selected child facts rather than rebuilding them. No second DAG or runtime scheduler is introduced.

The native iterate condition now consumes the same Physical predicate emitter, retiring another generic-stack boundary. The obsolete containment/antichain implementation is deleted.
