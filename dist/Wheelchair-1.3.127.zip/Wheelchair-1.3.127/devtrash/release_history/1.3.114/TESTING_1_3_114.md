# Testing 1.3.114

The current release authority remains the 29 tests in `devtrash/release_tests/current.list`. All 29 pass after PredicateFact/CSE convergence and again produce the existing release semantics.

Additional checks:

- strict Mandelbrot checksum remains `0x00000000032e223d`;
- 15-run old/new/C/Fortran interleaving preserves identical output;
- repeated predicate counts contract in generated machine code rather than merely moving into another runtime path;
- no Mandelbrot/fractal/pixel/workload name exists in the production compiler route;
- the obsolete antichain/containment implementation has no remaining caller and is deleted.

The retained Rank-N, Tensor/Field, Physical DAG, execution-admission, silicon/fabric, hard-limit and human-shell gates remain in the same release authority.
