# Performance 1.3.114

## General scalar PredicateFact convergence

Strict scalar Mandelbrot diagnostic: 768x768, 512-iteration bound, f64, one fixed CPU, no SIMD workload rewrite, no fast-math/FMA contraction. All implementations produce checksum `0x00000000032e223d`.

15 interleaved runs:

| implementation | median wall | median CPU | relative to 1.3.114 |
|---|---:|---:|---:|
| Wheelchair 1.3.114 | **347.94 ms** | **347.58 ms** | 1.000x |
| Wheelchair 1.3.113 | 513.52 ms | 513.08 ms | 1.476x slower |
| GCC C strict scalar | 140.28 ms | 139.80 ms | 0.403x |
| GFortran strict scalar | 140.96 ms | 140.58 ms | 0.405x |

1.3.114 removes 32.24% of the 1.3.113 wall time. Relative to the retained 1.3.112 median of 2252.69 ms, cumulative General-control convergence is 6.474x.

Generated trailer, 1.3.113 -> 1.3.114:

| machine feature | 1.3.113 | 1.3.114 |
|---|---:|---:|
| trailer bytes | 3661 | 3193 |
| disassembly lines | 983 | 858 |
| `vucomisd` | 8 | 1 |
| `seta` | 8 | 1 |
| `setae` | 8 | 1 |
| `sete` | 4 | 1 |
| `vaddsd` | 12 | 5 |
| `movabs` | 44 | 27 |
| `push` | 39 | 36 |
| `pop` | 43 | 40 |

The remaining ~2.47x gap to C is still a maturity frontier. 1.3.114 does not claim scalar parity.
