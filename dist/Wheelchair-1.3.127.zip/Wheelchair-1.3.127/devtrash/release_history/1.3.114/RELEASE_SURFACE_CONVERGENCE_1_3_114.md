# Release Surface Convergence 1.3.114

1.3.114 adds no source surface. Existing comparisons, lazy boolean relations, `select`, StateFacts and iterate conditions simply converge further into the same Physical-DAG realization.

No compatibility syntax, benchmark annotation, parallel directive, JIT/offload selector, predicate-cache option, or workload-specific switch is added.
