# Wheelchair 1.3.124 Charter

Wheelchair remains a general-purpose AOT language whose execution follows mathematical and physical facts rather than programmer-authored parallel schedules. 1.3.124 narrows the distance between a composed periodic coordinate relation and its physical lower bound without changing that charter.

The release rejects depth-specific optimization, benchmark routes, compatibility evaluators, and new DSL surfaces. Existing facts are fused and retained only when proof and real physical ownership justify them.
