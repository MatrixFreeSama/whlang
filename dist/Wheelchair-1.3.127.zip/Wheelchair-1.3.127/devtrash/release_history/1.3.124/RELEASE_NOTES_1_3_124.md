# Wheelchair 1.3.124 Release Notes

1.3.124 ages dynamic `PeriodicAffineFact(c,d,n)` realization after 1.3.123 closed the semantic precision wall. The reciprocal proof now uses the affine relation itself instead of combining incompatible extrema: for `0 <= i < n`, the quotient is bounded from `c`, the integral `n` term, and `ceil(max(d,0)/n)`. An exact unsigned-u64 -> binary64 vector conversion removes the former signed-conversion boundary without scalar lanes.

When the correlated quotient proof is sufficient, a deep periodic affine relation remains on the mature reciprocal realization even when its unreduced integer representative exceeds signed-u64. When that proof is genuinely insufficient, the existing persistent AffineFact authority may retain the exact periodic value and packet step: exact ring work initializes the carrier once, then the hot loop advances the same fact by exact modular recurrence. Reduced modular addition itself contracts to add/subtract/min when ShapeFact proves `n <= 2^63`; wider extents retain the full overflow-safe relation.

No source depth, benchmark name, workload matcher, compatibility evaluator, second periodic IR, JIT, scheduler, or source-visible parallel/periodic DSL participates. The current release gate is 34/34 PASS.
