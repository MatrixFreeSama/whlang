# Wheelchair 1.3.124 Performance

Pinned one-CPU measurements, `n=16,000,000`, interleaved after warmup. The useful numerical payload is fixed; only the number of composed `i -> (3*i+b) mod n` coordinate stages changes.

## Former depth-23 cliff

Seven interleaved rounds:

| implementation | median |
|---|---:|
| Wheelchair 1.3.124 | 27.201 ms |
| Wheelchair 1.3.123 | 720.100 ms |
| C natural | 580.733 ms |
| Fortran natural | 588.603 ms |
| C manual ceiling | 25.001 ms |
| Fortran manual ceiling | 23.494 ms |

1.3.124 is **26.47x faster than 1.3.123**, **21.35x faster than natural C**, and **21.64x faster than natural Fortran**. It is within about 8.8% of the hand-composed C ceiling. The generated executable contracts from 21,833 to 8,985 bytes (-58.85%). All compared implementations produce checksum `0x421e829548000000`.

## Wider exact domain

Five interleaved rounds at depth 40:

| implementation | median |
|---|---:|
| Wheelchair 1.3.124 | 482.341 ms |
| Wheelchair 1.3.123 | 1070.342 ms |
| C natural | 894.258 ms |
| Fortran natural | 875.276 ms |
| C manual ceiling | 23.966 ms |

1.3.124 is **2.22x faster than 1.3.123**, **1.85x faster than natural C**, and **1.81x faster than natural Fortran**. The executable contracts from 28,137 to 13,977 bytes (-50.33%). The matching Fortran manual-ceiling binary from the retained old benchmark did not reproduce the same depth-40 checksum and is therefore excluded from the ceiling comparison rather than used as evidence.

Depth 40 remains far from the 23.966 ms hand-composed C ceiling. 1.3.124 records that gap instead of adding a depth/workload-specific fast route.
