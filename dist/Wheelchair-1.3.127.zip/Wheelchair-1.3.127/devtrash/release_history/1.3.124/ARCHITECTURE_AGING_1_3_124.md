# Wheelchair 1.3.124 Architecture Aging

## Correlated proof replaces an accidental physical cliff

The 1.3.123 reciprocal proof conservatively divided a maximum affine representative evaluated at `n_max` by an unrelated `n_min`. Those extrema cannot occur together. 1.3.124 derives the quotient bound from the already-proved affine relation itself. This keeps `PeriodicAffineFact` semantic identity independent of a loose host-side interval estimate.

## Unsigned coordinates stay one vector fact

The dynamic periodic representative may legitimately occupy the full u64 domain. A single exact vector conversion uses `u64_to_f64(x) = 2 * i64_to_f64((x>>1)|(x&1))`; there is no scalar-lane compatibility path and no second coordinate representation.

## Exact periodic work becomes retained AffineFact state

For genuinely wider domains, the existing persistent AffineFact ownership authority is extended from `(coefficient)` to `(coefficient, offset, modulus)`. A periodic fact owns its current value and packet step only when the same measured physical register authority admits both. Exact modular expansion initializes those carriers once. The hot loop advances by one exact modular relation per packet instead of re-evaluating binary modular multiplication for every packet.

This is not a depth-specific algorithm selector. It is the same compiled fact moving from repeated realization to retained physical state.

## Remaining frontier

The widest retained depth-40 case is much lighter than 1.3.123 but still materially above the hand-composed C ceiling. That gap remains a physical-aging target rather than being hidden behind a benchmark-specific route.
