# Wheelchair 1.3.124 Testing

The current release authority contains 34 tests and passes 34/34 when executed individually in the release work tree.

1.3.124 adds `test_periodic_affine_aging_13124.sh`. It checks:

- exact unsigned-u64 vector conversion authority exists;
- the reciprocal quotient proof is derived from the affine relation;
- exact periodic induction uses the existing AffineFact authority;
- no depth- or benchmark-specific periodic route exists;
- weighted depth-23 and depth-40 oracles are correct;
- the repaired generated-code shapes remain compact enough to catch a return to per-packet exact expansion.

The previous 1.3.123 periodic-integer gate remains current and passes unchanged.
