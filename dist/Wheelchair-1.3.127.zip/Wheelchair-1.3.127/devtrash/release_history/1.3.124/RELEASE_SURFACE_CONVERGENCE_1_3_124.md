# Wheelchair 1.3.124 Release Surface Convergence

1.3.124 adds no source syntax, runtime mode, scheduler, JIT interface, periodic keyword, benchmark selector, or compatibility evaluator. The repair is below the existing `PeriodicAffineFact` / Physical Reality boundary.

The release keeps historical evidence under `devtrash/` and canonical production executables under `bin/`. The generated `build/` tree is not a release payload and is removed after clean staging verification.
