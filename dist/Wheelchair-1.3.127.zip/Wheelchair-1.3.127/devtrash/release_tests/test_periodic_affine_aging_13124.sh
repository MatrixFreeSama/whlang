#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
T=${TMPDIR:-/tmp}/wheelchair_periodic13124_$$
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T"

EXACT="$ROOT/compiler/tensor_frontend_periodic_exact.inc"
PROF="$ROOT/compiler/tensor_frontend_profile_blocks.inc"
BASE="$ROOT/compiler/tensor_frontend_x86_64.S"

grep -q '^vec_vcvtuqq2pd_exact:$' "$EXACT"
grep -q 'floor((c\*i + k\*n + d)/n)' "$PROF"
grep -q '^vec_periodic_induct_get_reg:$' "$BASE"
grep -q '^vec_emit_u64_literal_mod_n:$' "$EXACT"
grep -q 'tensor_shape_extent_max' "$EXACT"
! grep -RqsE 'depth[ _-]*(13|21|22|23|40)|affine(13|21|22|23|40)|benchmark[ _-]*(periodic|affine)[ _-]*(route|matcher)' \
  "$ROOT/compiler" "$ROOT/runtime"

make_case() {
  d=$1; out=$2
  {
    printf '%s\n' 'program periodic_affine_aging' 'strict' 'input n: u64 range 1024..100000000' \
      'field x0[i in n]: f64 = cast(f64, (i * 37 + 11) % 4096)'
    k=1
    while [ "$k" -le "$d" ]; do
      prev=$((k-1)); b=$((2*k+1))
      printf 'field x%d[i in n]: f64 = x%d[(i * 3 + %d) %% n]\n' "$k" "$prev" "$b"
      k=$((k+1))
    done
    printf 'sum checksum[i in n]: f64 = x%d[i] * cast(f64, (i * 5 + 3) %% 1024)\noutput checksum\n' "$d"
  } > "$out"
}

make_case 23 "$T/d23.whex"
make_case 40 "$T/d40.whex"
"$ROOT/bin/whexc" "$T/d23.whex" -o "$T/d23" >/dev/null
"$ROOT/bin/whexc" "$T/d40.whex" -o "$T/d40" >/dev/null
[ "$("$T/d23" 4093)" = 'checksum_bits=0x41efdf4c2f600000' ]
[ "$("$T/d40" 4093)" = 'checksum_bits=0x41efe2d94b000000' ]

# Guard the generated RX payload itself. Runtime authority may legitimately age
# without making the periodic hot code fatter; total ELF bytes are not a codegen
# metric. PHDR #3 is the generated direct-AOT segment.
gen_size_hex() {
  readelf -lW "$1" | awk '$1=="LOAD" && $7=="R" && $8=="E" {n++; if(n==2){print $5; exit}}'
}
h=$(gen_size_hex "$T/d23"); [ $((h)) -lt 2000 ]
# The truly wider exact case remains bounded under the same semantic authority.
h=$(gen_size_hex "$T/d40"); [ $((h)) -lt 8000 ]

printf '%s\n' \
  'PERIODIC_AFFINE_CORRELATED_QUOTIENT_PROOF=PASS' \
  'PERIODIC_AFFINE_UNSIGNED_U64_CONVERSION=PASS' \
  'PERIODIC_AFFINE_EXACT_INDUCTION_REALIZATION=PASS' \
  'PERIODIC_AFFINE_DEPTH_SPECIALIZATION=0' \
  'WHEELCHAIR_PERIODIC_AFFINE_AGING_1_3_124=PASS'
