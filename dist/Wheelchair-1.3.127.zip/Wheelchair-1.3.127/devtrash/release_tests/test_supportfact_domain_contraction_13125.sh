#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
T=${TMPDIR:-/tmp}/wheelchair_support13125_$$
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T"

SUP="$ROOT/compiler/tensor_support_frontend.inc"
BASE="$ROOT/compiler/tensor_frontend_x86_64.S"
RUN="$ROOT/runtime/tensor_runtime_x86_64.S"

grep -q '^tensor_support_analyze_root:$' "$SUP"
grep -q '^tensor_emit_support_probe:$' "$SUP"
grep -q '^discover_support:$' "$RUN"
grep -q '^reprice_support_ownership:$' "$RUN"
grep -q '^worker_range_dense:$' "$RUN"
grep -q 'SUPPORT_EMPTY' "$SUP"
grep -q 'tensor_support_analyze_root' "$BASE"
! grep -RqsE '4473|8000000|Hertz|hertz|penalty_contact|contact_bench|support_depth_[0-9]+' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/tools"

cat > "$T/prefix.whex" <<'SRC'
program prefix_support
strict
input n: u64 range 1024..20000000
field p[i in n]: f64 = select(cast(f64, i) < 4096.0, cast(f64, i) * 0.125 + 1.0, 0.0)
sum checksum[i in n]: f64 = p[i]
output checksum
SRC

cat > "$T/suffix.whex" <<'SRC'
program suffix_support
strict
input n: u64 range 1024..20000000
field x[i in n]: f64 = cast(f64, n) - cast(f64, i)
field p[i in n]: f64 = select(x[i] < 4097.0, cast(f64, i) * 0.0625 + 2.0, 0.0)
sum checksum[i in n]: f64 = p[i]
output checksum
SRC

cat > "$T/empty.whex" <<'SRC'
program empty_support
strict
input n: u64 range 1024..20000000
field p[i in n]: f64 = select(cast(f64, i) < -1.0, cast(f64, i) + 1.0, 0.0)
sum checksum[i in n]: f64 = p[i]
output checksum
SRC

cat > "$T/zero.whex" <<'SRC'
program zero_reduction
strict
input n: u64 range 1024..20000000
sum checksum[i in n]: f64 = 0.0
output checksum
SRC

cat > "$T/basin.whex" <<'SRC'
program basin_support
strict
input n: u64 range 1024..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.000001
field g[i in n]: f64 = x[i] * x[i] * 10.0 - 0.00005
field p[i in n]: f64 = select(g[i] < 0.0, -1000000.0 * g[i], 0.0)
sum checksum[i in n]: f64 = p[i]
output checksum
SRC

for s in prefix suffix empty zero basin; do
  "$ROOT/bin/whexc" "$T/$s.whex" -o "$T/$s" >/dev/null
done

[ "$("$T/prefix" 8192)" = 'checksum_bits=0x41300f0000000000' ]
[ "$("$T/prefix" 16000000)" = 'checksum_bits=0x41300f0000000000' ]
[ "$("$T/suffix" 4093)" = 'checksum_bits=0x412038f4c0000000' ]
[ "$("$T/empty" 16000000)" = 'checksum_bits=0x0000000000000000' ]
[ "$("$T/zero" 16000000)" = 'checksum_bits=0x0000000000000000' ]
[ "$("$T/basin" 4093)" = 'checksum_bits=0x410201abff12c27a' ]
[ "$("$T/basin" 8000000)" = 'checksum_bits=0x410232798d10f51c' ]

printf '%s\n' \
  'PREDICATEFACT_SUPPORTFACT_CLOSURE=PASS' \
  'SUPPORTFACT_EXECUTION_DOMAIN_CONTRACTION=PASS' \
  'SUPPORTFACT_STRICT_TREE_ZERO_ERASURE=PASS' \
  'REDUCTION_EMPTY_SUPPORT_IDENTITY=PASS' \
  'SUPPORTFACT_PREFIX_SUFFIX_BASIN=PASS' \
  'SUPPORTFACT_WORKLOAD_MATCHER=0' \
  'SECOND_ACTIVE_SET_BACKEND=0' \
  'WHEELCHAIR_SUPPORTFACT_DOMAIN_CONTRACTION_1_3_125=PASS'
