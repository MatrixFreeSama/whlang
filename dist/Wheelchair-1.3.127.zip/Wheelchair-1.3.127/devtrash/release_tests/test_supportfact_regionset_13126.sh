#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
T=${TMPDIR:-/tmp}/wheelchair_regionset13126_$$
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T"

SUP="$ROOT/compiler/tensor_support_frontend.inc"
RUN="$ROOT/runtime/tensor_runtime_x86_64.S"
OFF="$ROOT/tools/generate_tensor_runtime_offsets.sh"

grep -q '^support_count_terms:$' "$SUP"
grep -q '^support_emit_terms:$' "$SUP"
grep -q '^support_range_class:$' "$RUN"
grep -q '^support_term_count_patch:' "$RUN"
grep -q '^g_support_regions:' "$RUN"
grep -q '^g_support_region_count:' "$RUN"
grep -q '^g_support_active_chunks:' "$RUN"
grep -q 'RUNTIME_SUPPORT_COUNT_OFF' "$OFF"
! grep -RqsE 'SUPPORT_(TWO|THREE|FOUR)_INTERVAL|REGIONSET_(MAX|CAP|LIMIT)|two_regions|levelset_two|narrowband|8000000|0\.02' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/tools"

cat > "$T/two.whex" <<'SRC'
program regionset_two
strict
input n: u64 range 1024..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.00000001
field dl[i in n]: f64 = x[i] + 0.02
field dr[i in n]: f64 = x[i] - 0.02
field sl[i in n]: f64 = select(dl[i] * dl[i] < 0.0000000004, 0.072 * (1.0 - dl[i] * dl[i] / 0.0000000004), 0.0)
field sr[i in n]: f64 = select(dr[i] * dr[i] < 0.0000000004, 0.072 * (1.0 - dr[i] * dr[i] / 0.0000000004), 0.0)
field source[i in n]: f64 = sl[i] + sr[i]
sum checksum[i in n]: f64 = source[i]
output checksum
SRC

cat > "$T/reverse.whex" <<'SRC'
program regionset_reverse
strict
input n: u64 range 1024..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.00000001
field dl[i in n]: f64 = x[i] + 0.02
field dr[i in n]: f64 = x[i] - 0.02
field sl[i in n]: f64 = select(dl[i] * dl[i] < 0.0000000004, 0.072 * (1.0 - dl[i] * dl[i] / 0.0000000004), 0.0)
field sr[i in n]: f64 = select(dr[i] * dr[i] < 0.0000000004, 0.072 * (1.0 - dr[i] * dr[i] / 0.0000000004), 0.0)
field source[i in n]: f64 = sr[i] + sl[i]
sum checksum[i in n]: f64 = source[i]
output checksum
SRC

cat > "$T/overlap.whex" <<'SRC'
program regionset_overlap
strict
input n: u64 range 1024..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.00000001
field d1[i in n]: f64 = x[i]
field d2[i in n]: f64 = x[i] - 0.00001
field s1[i in n]: f64 = select(d1[i] * d1[i] < 0.0000000004, 0.03 * (1.0 - d1[i] * d1[i] / 0.0000000004), 0.0)
field s2[i in n]: f64 = select(d2[i] * d2[i] < 0.0000000004, 0.02 * (1.0 - d2[i] * d2[i] / 0.0000000004), 0.0)
field source[i in n]: f64 = s1[i] + s2[i]
sum checksum[i in n]: f64 = source[i]
output checksum
SRC

for s in two reverse overlap; do "$ROOT/bin/whexc" "$T/$s.whex" -o "$T/$s" >/dev/null; done
for n in 4000000 8000000 16000000; do
  [ "$("$T/two" "$n")" = "$("$T/reverse" "$n")" ]
done
[ "$("$T/two" 4000000)" = 'checksum_bits=0x4067ffffe6d58c8f' ]
[ "$("$T/two" 8000000)" = 'checksum_bits=0x4077ffffe6d58c8e' ]
[ "$("$T/two" 16000000)" = 'checksum_bits=0x4077ffffe6d58c8e' ]
[ "$("$T/overlap" 8000000)" = 'checksum_bits=0x4060aaaa9930be0e' ]

printf '%s\n' \
  'SUPPORTFACT_ADD_SUB_UNION_CLOSURE=PASS' \
  'REGIONSET_SOURCE_CARDINALITY=PASS' \
  'REGIONSET_ORDER_CANONICALIZATION=PASS' \
  'REGIONSET_OVERLAP_MERGE=PASS' \
  'REGIONSET_STRICT_REDUCTION_ZERO_ERASURE=PASS' \
  'REGIONSET_FIXED_COUNT_CLASSES=0' \
  'REGIONSET_WORKLOAD_MATCHER=0' \
  'WHEELCHAIR_SUPPORTFACT_REGIONSET_1_3_126=PASS'
