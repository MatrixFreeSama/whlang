#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ -x test.sh ]
[ -x devtrash/coverage/run_native_coverage.sh ]
! grep -RqsE 'native_coverage|WHEELCHAIR_COVERAGE|coverage-real' compiler runtime surface tools build.sh
[ "$(grep -c '^test_.*\.sh$' devtrash/release_tests/current.list)" -eq 37 ]
[ "$(sort devtrash/release_tests/current.list | uniq -d | wc -l)" -eq 0 ]
grep -q '^test_execution_realization_13104.sh$' devtrash/release_tests/current.list
grep -q '^test_general_physical_reality_13104.sh$' devtrash/release_tests/current.list
grep -q '^test_tensor_fact_aging_13104.sh$' devtrash/release_tests/current.list
grep -q '^test_test_closure_13109.sh$' devtrash/release_tests/current.list
grep -q '^test_hard_limit_aging_13104.sh$' devtrash/release_tests/current.list
grep -q '^test_rankn_physical_convergence_13109.sh$' devtrash/release_tests/current.list
grep -q '^test_shapefact_periodic_affine_13120.sh$' devtrash/release_tests/current.list
grep -q '^test_coordinatefact_composition_13121.sh$' devtrash/release_tests/current.list
grep -q '^test_parallel_source_convergence_13122.sh$' devtrash/release_tests/current.list
grep -q '^test_periodic_integer_realization_13123.sh$' devtrash/release_tests/current.list
grep -q '^test_periodic_affine_aging_13124.sh$' devtrash/release_tests/current.list
grep -q '^test_supportfact_domain_contraction_13125.sh$' devtrash/release_tests/current.list
grep -q '^test_supportfact_regionset_13126.sh$' devtrash/release_tests/current.list
grep -q '^test_supportfact_algebra_13127.sh$' devtrash/release_tests/current.list
! grep -q '^test_test_closure_13107.sh$' devtrash/release_tests/current.list
! grep -q '^test_rankn_local_strict_aging_13107.sh$' devtrash/release_tests/current.list
while IFS= read -r t; do [ -x "devtrash/release_tests/$t" ]; done < devtrash/release_tests/current.list
printf '%s\n' \
  'TEST_OBSERVER_PRODUCTION_BACKEDGE=0' \
  'CURRENT_RELEASE_TEST_AUTHORITY=PASS' \
  'LEGACY_1_3_108_CURRENT_TEST_SPLIT=0' \
  'WHEELCHAIR_TEST_CLOSURE_1_3_109=PASS'
