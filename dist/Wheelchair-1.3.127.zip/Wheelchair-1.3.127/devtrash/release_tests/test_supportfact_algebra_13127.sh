#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
T=${TMPDIR:-/tmp}/wheelchair_support13127_$$
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T"
SUP="$ROOT/compiler/tensor_support_frontend.inc"
OFF="$ROOT/compiler/runtime_offsets.inc"

grep -q '^\.equ SUPPORT_SHAPE_CAP, 5$' "$SUP"
grep -q '^support_shape_superlevel_ok:$' "$SUP"
grep -q '^support_positive_finite_literal:$' "$SUP"
grep -q '^\.sct_mul:$' "$SUP"
grep -q '^\.set_mul:$' "$SUP"
! grep -RqsEi 'plasticity|yield[_ -]?zone|elastoplastic|3999|localized_plastic' \
  "$ROOT/compiler" "$ROOT/runtime" "$ROOT/tools"

cat > "$T/cap.whex" <<'SRC'
program support_cap
strict
input n: u64 range 16384..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.000001
field over[i in n]: f64 = 50000000.0 - 12500000000000.0 * x[i] * x[i]
field dep[i in n]: f64 = select(over[i] > 0.0, over[i] / 202000000000.0, 0.0)
sum checksum[i in n]: f64 = dep[i]
output checksum
SRC
cat > "$T/scalar.whex" <<'SRC'
program support_scalar_mul
strict
input n: u64 range 16384..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.000001
field over[i in n]: f64 = 50000000.0 - 12500000000000.0 * x[i] * x[i]
field dep[i in n]: f64 = select(over[i] > 0.0, over[i] / 202000000000.0, 0.0)
sum checksum[i in n]: f64 = 250000000.0 * dep[i]
output checksum
SRC
cat > "$T/square.whex" <<'SRC'
program support_product
strict
input n: u64 range 16384..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.000001
field over[i in n]: f64 = 50000000.0 - 12500000000000.0 * x[i] * x[i]
field dep[i in n]: f64 = select(over[i] > 0.0, over[i] / 202000000000.0, 0.0)
sum checksum[i in n]: f64 = dep[i] * dep[i]
output checksum
SRC
cat > "$T/full.whex" <<'SRC'
program support_polynomial
strict
input n: u64 range 16384..20000000
field x[i in n]: f64 = (cast(f64, i) - cast(f64, n) * 0.5) * 0.000001
field over[i in n]: f64 = 50000000.0 - 12500000000000.0 * x[i] * x[i]
field dep[i in n]: f64 = select(over[i] > 0.0, over[i] / 202000000000.0, 0.0)
field diss[i in n]: f64 = 250000000.0 * dep[i] + 1000000000.0 * dep[i] * dep[i]
sum checksum[i in n]: f64 = diss[i]
output checksum
SRC

mode_off=$(awk '/^\.equ RUNTIME_SUPPORT_MODE_OFF,/ {print $3}' "$OFF")
count_off=$(awk '/^\.equ RUNTIME_SUPPORT_COUNT_OFF,/ {print $3}' "$OFF")
mode_off=$((mode_off)); count_off=$((count_off))
read_u32() { od -An -t u4 -j "$2" -N 4 "$1" | tr -d ' '; }

for s in cap scalar square full; do
  "$ROOT/bin/whexc" "$T/$s.whex" -o "$T/$s" >/dev/null
  [ "$(read_u32 "$T/$s" "$mode_off")" -eq 1 ]
  [ "$(read_u32 "$T/$s" "$count_off")" -gt 0 ]
done

[ "$("$T/cap" 8000000)" = 'checksum_bits=0x3fe51f42a8cbb691' ]
[ "$("$T/scalar" 8000000)" = 'checksum_bits=0x41a3abe756ac5b3f' ]
[ "$("$T/square" 8000000)" = 'checksum_bits=0x3f2121c531545cd9' ]
[ "$("$T/full" 8000000)" = 'checksum_bits=0x41a3afe47af3fef6' ]

printf '%s\n' \
  'SUPPORTFACT_CAP_SUPERLEVEL_DUALITY=PASS' \
  'SUPPORTFACT_POSITIVE_SCALAR_TRANSPORT=PASS' \
  'SUPPORTFACT_PRODUCT_CLOSURE=PASS' \
  'SUPPORTFACT_POLYNOMIAL_REGIONSET=PASS' \
  'SUPPORTFACT_PLASTICITY_MATCHER=0' \
  'SECOND_SUPPORT_ALGEBRA_BACKEND=0' \
  'WHEELCHAIR_SUPPORTFACT_ALGEBRA_1_3_127=PASS'
