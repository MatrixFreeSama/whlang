#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
T=${TMPDIR:-/tmp}/wheelchair_periodic13123_$$
trap 'rm -rf "$T"' EXIT HUP INT TERM
mkdir -p "$T"

EXACT="$ROOT/compiler/tensor_frontend_periodic_exact.inc"
PROF="$ROOT/compiler/tensor_frontend_profile_blocks.inc"
[ -f "$EXACT" ]
grep -q '^vec_emit_reciprocal_mod_wide:$' "$EXACT"
grep -q '^vec_emit_periodic_exact:$' "$EXACT"
grep -q 'q_max.*2\^52' "$PROF"
! grep -RqsE 'depth[ _-]*(13|21|22)|affine13|affine21|affine22|benchmark[ _-]*(periodic|affine)[ _-]*(route|matcher)' \
  "$ROOT/compiler" "$ROOT/runtime"

make_case() {
  d=$1; out=$2
  {
    printf '%s\n' 'program periodic_integer_realization' 'strict' 'input n: u64 range 1024..100000000' \
      'field x0[i in n]: f64 = cast(f64, (i * 37 + 11) % 4096)'
    k=1
    while [ "$k" -le "$d" ]; do
      prev=$((k-1)); b=$((2*k+1))
      printf 'field x%d[i in n]: f64 = x%d[(i * 3 + %d) %% n]\n' "$k" "$prev" "$b"
      k=$((k+1))
    done
    printf 'sum checksum[i in n]: f64 = x%d[i] * cast(f64, (i * 5 + 3) %% 1024)\noutput checksum\n' "$d"
  } > "$out"
}

# 13/21 exercise the proof-expanded reciprocal realization; 22/40 force the
# exact integer ring realization.  Weighted checksums make the oracle sensitive
# to the actual permutation, not merely to permutation-invariant full sums.
make_case 13 "$T/d13.whex"
make_case 21 "$T/d21.whex"
make_case 22 "$T/d22.whex"
make_case 40 "$T/d40.whex"
for d in 13 21 22 40; do
  "$ROOT/bin/whexc" "$T/d$d.whex" -o "$T/d$d" >/dev/null
done
[ "$("$T/d13" 4093)" = 'checksum_bits=0x41efe22c83a00000' ]
[ "$("$T/d21" 4093)" = 'checksum_bits=0x41efe9444c600000' ]
[ "$("$T/d22" 4093)" = 'checksum_bits=0x41efe040ff000000' ]
[ "$("$T/d40" 4093)" = 'checksum_bits=0x41efe2d94b000000' ]

printf '%s\n' \
  'PERIODIC_AFFINE_FP_PRECISION_SEMANTIC_WALL=0' \
  'PERIODIC_AFFINE_RECIPROCAL_PROOF_REALIZATION=PASS' \
  'PERIODIC_AFFINE_EXACT_INTEGER_REALIZATION=PASS' \
  'PERIODIC_AFFINE_WEIGHTED_ORACLE=PASS' \
  'WORKLOAD_SPECIFIC_PERIODIC_ROUTE=0' \
  'WHEELCHAIR_PERIODIC_INTEGER_REALIZATION_1_3_123=PASS'
