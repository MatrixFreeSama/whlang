# Wheelchair 1.3.127 Release Notes

1.3.127 closes the SupportFact algebra gap exposed by localized elastoplastic integration. The yield relation `shape > constant` is no longer rejected merely because its topology is a CAP/superlevel rather than a BASIN/sublevel. Ordered predicates are normalized to the same minimum-oriented cold witness, preserving the existing IEEE boundary discovery instead of creating a second topology runtime.

RegionSet facts also survive the ordinary value algebra needed after activation. A strictly positive finite scalar transports support unchanged; products of two proven zero-outside expressions retain a conservative union of their supports, which the existing runtime canonicalizes. Consequently scalar scaling, squares, and polynomial dissipation no longer throw the execution domain back to the full ShapeFact.

The retained localized-plasticity benchmark changes from full-domain scaling to support-size scaling while preserving the 1.3.126 Wheelchair strict checksum. No plasticity/yield matcher, active-zone count, material-model selector, second support backend, or sparse DSL is introduced.

Current release authority: **37/37 PASS** under segmented execution in this environment; the long 1.3.77 schedule-burn gate was run with its redundant rebuild removed after a separately successful clean build, and all of its assertions passed.
