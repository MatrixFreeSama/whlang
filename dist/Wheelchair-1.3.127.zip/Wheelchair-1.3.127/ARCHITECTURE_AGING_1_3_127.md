# Wheelchair 1.3.127 Architecture Aging

## Support topology gains curvature duality

The Tensor support authority no longer treats only sublevel BASINs as first-class. `BASIN` and `CAP` are one curvature-dual topology: sublevel witnesses keep `+shape`, superlevel witnesses keep `-shape`, so the existing cold runtime boundary proof still searches one normalized minimum. The runtime is unchanged; the compiler removes the old polarity asymmetry.

`CONST - BASIN -> CAP`, `CONST - CAP -> BASIN`, negative scaling/division flips BASIN/CAP, and affine products with opposite monotone slope form CAP while equal slope forms BASIN. There is no material-model or yield-function classifier.

## RegionSet survives ordinary value algebra

RegionSet propagation is no longer limited to ADD/SUB. A strictly positive finite scalar preserves exact `+0` outside an operand support. If both multiplicands already have proven `+0`-outside RegionSets, their product is exact `+0` outside the union; the existing RegionSet canonicalizer merges duplicate/overlapping Regions. This is conservative execution support, so no cancellation or value-range guess is required.

The result closes the real chain `PredicateFact -> SupportFact -> MUL/polynomial ValueFact -> RegionSet -> Physical ownership` without adding a second active-set backend.
