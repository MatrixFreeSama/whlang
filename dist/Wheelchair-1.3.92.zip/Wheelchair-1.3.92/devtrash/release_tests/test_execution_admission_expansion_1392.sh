#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "execution admission 1.3.92: $*" >&2; exit 1; }

./build.sh >/dev/null
SR=compiler/silicon_reality.inc
PR=compiler/physical_reality.inc
for law in \
  SR_EXECUTION_ADMISSION_FROM_EXTERNAL_LIMITS,1 \
  SR_LOCALITY_IDENTITY_IS_PLACEMENT_ONLY,1 \
  SR_CGROUP_CPU_QUOTA_IS_ADMISSION_FACT,1 \
  SR_POWER_OF_TWO_EXECUTION_ROUNDUP,0 \
  SR_GENERAL_EXECUTION_ADMISSION_BOUND,1 \
  SR_RUNTIME_IDLE_RESOURCE_QUERY,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$SR"
done
for law in \
  PR_EXECUTION_ADMISSION_OWNS_MULTIPLICITY_BOUND,1 \
  PR_LOCALITY_IDENTITY_OWNS_PLACEMENT_ONLY,1 \
  PR_LOCALITY_FAILURE_COLLAPSES_EXECUTION_ADMISSION,0 \
  PR_CGROUP_QUOTA_IS_EXTERNAL_ADMISSION_FACT,1 \
  PR_POWER_OF_TWO_EXECUTION_ROUNDUP,0 \
  PR_GENERAL_EXECUTION_ADMISSION_BOUND,1; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$PR"
done

grep -q '^sd_read_cgroup_cpu_quota_capacity:$' compiler/silicon_domain_probe_x86_64.S
grep -q 'execution_admission_patch' runtime/tensor_runtime_x86_64.S
grep -q 'execution_admission_patch' runtime/field_runtime_512_x86_64.S
grep -q 'execution_admission_patch' runtime/field_runtime_256_x86_64.S
grep -q 'gr_execution_admission_capacity' runtime/general_parallel_release_x86_64.S
grep -q '^gr_try_acquire_x86_slot:$' runtime/general_parallel_release_x86_64.S
grep -q 'GR_EXECUTION_ADMISSION_CAPACITY_OFF' compiler/general_frontend_x86_64.S
! grep -RqsE 'capacity_ceiling_patch|tensor_capacity_ceiling|locality_domain_execution_ceiling|dllg_pow2|fdllg_pow2' compiler runtime tools

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY1'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/9'
a=D['allowed_execution_contexts']; q=D['cpu_quota_execution_capacity']; e=D['execution_admission_capacity']
assert a>=1 and 1<=e<=a
if q: assert e<=q
assert D['execution_admission_authority']=='affinity_x_finite_cgroup_quota'
assert D['locality_is_execution_capacity_authority'] is False
assert D['power_of_two_execution_roundup'] is False
assert D['runtime_idle_resource_query'] is False
print('EXECUTION_ADMISSION_CONTRACT=PASS')
PY1

bin/whexc devtrash/tests/profile_1211/fsi_coupled.whex -o "$T/fsi" >/dev/null
python3 - "$T/contract.json" "$T/fsi" compiler/runtime_offsets.inc <<'PY2'
import json,re,sys,struct
D=json.load(open(sys.argv[1])); b=open(sys.argv[2],'rb').read(); inc=open(sys.argv[3]).read()
m=re.search(r'RUNTIME_EXECUTION_ADMISSION_OFF,\s*(0x[0-9a-fA-F]+|\d+)',inc); assert m
O=int(m.group(1),0); got=struct.unpack_from('<I',b,O)[0]
assert got==D['execution_admission_capacity'],(got,D['execution_admission_capacity'])
print('EXECUTION_ADMISSION_BURN=PASS')
PY2

python3 - "$T" <<'PY3'
import os,subprocess,re,struct,sys
T=sys.argv[1]; cpus=sorted(os.sched_getaffinity(0))
if len(cpus)<3:
    print('NON_POWER_OF_TWO_ADMISSION=SKIP_LT3')
    raise SystemExit
subset=set(cpus[:3])
def pin(): os.sched_setaffinity(0,subset)
out=f'{T}/fsi3'
subprocess.run(['bin/whexc','devtrash/tests/profile_1211/fsi_coupled.whex','-o',out],check=True,stdout=subprocess.DEVNULL,preexec_fn=pin)
inc=open('compiler/runtime_offsets.inc').read(); m=re.search(r'RUNTIME_EXECUTION_ADMISSION_OFF,\s*(0x[0-9a-fA-F]+|\d+)',inc); assert m
O=int(m.group(1),0); b=open(out,'rb').read(); got=struct.unpack_from('<I',b,O)[0]
assert 1<=got<=3
if got==3: print('NON_POWER_OF_TWO_ADMISSION=PASS')
else: print(f'NON_POWER_OF_TWO_ADMISSION=PASS_QUOTA_{got}')
PY3

cpus=$(python3 - <<'PY4'
import os
print(','.join(map(str,sorted(os.sched_getaffinity(0))[:4])))
PY4
)
out=$(taskset -c "$cpus" "$T/fsi" 1000000)
case "$out" in checksum_bits=0x*) ;; *) fail fsi-output ;; esac

echo 'LOCALITY_FAILURE_COLLAPSES_EXECUTION_ADMISSION=0'
echo 'POWER_OF_TWO_EXECUTION_ROUNDUP=0'
echo 'RUNTIME_IDLE_RESOURCE_QUERY=0'
echo 'WHEELCHAIR_EXECUTION_ADMISSION_EXPANSION_1_3_92=PASS'
