#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "fabric activation / Field datapath 1.3.91: $*" >&2; exit 1; }

./build.sh >/dev/null

grep -q '^.equ SR_FABRIC_ACTIVATION_ENTRY_ABI,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_ACTIVATION_ABI_VERSION,2$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_EXTERNAL_COMPLETION_EXPLICIT_STATE,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FIELD_FABRIC_DATAPATH_DESCRIPTOR,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FIELD_FABRIC_DESCRIPTOR_SECOND_IR,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_FIELD_FABRIC_X86_FALLBACK,0$' compiler/silicon_reality.inc
grep -q '^gr_activate_fabric_node:$' runtime/general_parallel_release_x86_64.S
grep -q '^gr_publish_completion_external:$' runtime/general_parallel_release_x86_64.S
grep -q '^ff_close_fabric_datapath_descriptor:$' compiler/field_frontend_common_x86_64.S
grep -q 'call gr_activate_fabric_node' runtime/general_parallel_release_x86_64.S

grep -q '"gr_fabric_activation_entry"' build/general_parallel_release_offsets.json
grep -q '"gr_publish_completion_external"' build/general_parallel_release_offsets.json

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/9'
assert D['fabric_activation_abi_present'] is True
assert D['fabric_activation_abi_version']==2
assert D['fabric_activation_entry_abi'] is True
assert D['fabric_external_completion_explicit_state'] is True
assert D['fabric_realization_descriptor_version']==2
assert D['field_fabric_datapath_descriptor'] is True
assert D['field_fabric_descriptor_second_ir'] is False
assert D['field_fabric_x86_fallback'] is False
assert D['fabric_activation_bridge_present'] is False
PY

F=devtrash/tests/field_1216
bin/fieldc "$F/mixed.json" -o "$T/prod-field" >/dev/null

# Proof-only target facts exercise the exact same Field Physical DAG projection.
as --64 \
  --defsym FABRIC_TARGET_PRESENT=1 \
  --defsym FABRIC_LOGIC_UNITS=100000 \
  --defsym FABRIC_REGISTER_UNITS=200000 \
  --defsym FABRIC_DSP_UNITS=1000 \
  --defsym FABRIC_LOCAL_STORAGE_BYTES=67108864 \
  --defsym FABRIC_ROUTING_DOMAINS=4 \
  --defsym FABRIC_CLOCK_REGIONS=4 \
  --defsym FABRIC_COMPUTE_TICKS_NUM=1 \
  --defsym FABRIC_COMPUTE_TICKS_DEN=4 \
  --defsym FABRIC_ACTIVATION_TICKS=100 \
  --defsym FABRIC_TRANSPORT_FIXED_TICKS=20 \
  --defsym FABRIC_TRANSPORT_TICKS_PER_BYTE=1 \
  compiler/fabric_target_facts_x86_64.S -o "$T/facts.o"
ld -nostdlib -static -z noexecstack \
  build/fieldc_driver.o build/field_frontend_512.o \
  build/tensor_frontend.o build/runtime_blob.o \
  build/field_runtime_blob_512.o build/field_parser_link_stubs.o \
  build/silicon_domain_probe.o "$T/facts.o" build/outward_materialization_profile.o \
  build/surface_lowerer.o build/human_shell_feedback.o -o "$T/fieldc-proof"
"$T/fieldc-proof" "$F/mixed.json" -o "$T/proof-field" >/dev/null

python3 - "$T/prod-field" "$T/proof-field" build/field_runtime_512_offsets.inc <<'PY'
import os,re,struct,sys
inc=open(sys.argv[3]).read()
def eq(n):
    m=re.search(r'^\.equ\s+'+re.escape(n)+r',\s*(0x[0-9a-fA-F]+|[0-9]+)$',inc,re.M)
    assert m,n
    return int(m.group(1),0)
def info(path):
    b=open(path,'rb').read()
    va=struct.unpack_from('<Q',b,eq('FIELD_RUNTIME_FABRIC_DATAPATH_VA_OFF'))[0]
    sz=struct.unpack_from('<Q',b,eq('FIELD_RUNTIME_FABRIC_DATAPATH_BYTES_OFF'))[0]
    br=struct.unpack_from('<I',b,eq('FIELD_RUNTIME_FABRIC_BRIDGE_PRESENT_OFF'))[0]
    abi=struct.unpack_from('<I',b,eq('FIELD_RUNTIME_FABRIC_ACTIVATION_ABI_OFF'))[0]
    return b,va,sz,br,abi
P=info(sys.argv[1]); Q=info(sys.argv[2])
assert P[2]==0 and P[1]==0 and P[3]==0 and P[4]==1,P[1:]
assert Q[2]>64 and Q[1]!=0 and Q[3]==0 and Q[4]==1,Q[1:]
b,va,sz,br,abi=Q
off=eq('FIELD_RUNTIME_GENERATED_FILE_OFF')+(va-eq('FIELD_RUNTIME_GENERATED_VA'))
h=struct.unpack_from('<8Q',b,off)
version,N,E,maxdepth,barriers,traffic,work,total=h
assert version==1
assert N==7
assert E>0
assert maxdepth>0
assert barriers>0
assert traffic>0 and work>0
assert total==sz==64+40*N,(total,sz,N)
# Descriptor payload is not a second IR: it is the exact existing 32-byte op
# record array followed by the exact existing depth/order vectors.
depth=struct.unpack_from('<'+'I'*N,b,off+64+32*N)
order=struct.unpack_from('<'+'I'*N,b,off+64+36*N)
assert sorted(order)==list(range(N)),order
assert all(depth[order[i]]<=depth[order[i+1]] for i in range(N-1)),(depth,order)
print('FIELD_FABRIC_DESCRIPTOR_BYTES='+str(sz))
print('FIELD_FABRIC_OPS='+str(N))
print('FIELD_FABRIC_EDGES='+str(E))
print('FIELD_FABRIC_MAX_DEPTH='+str(maxdepth))
PY

# No board bridge exists in production. A proof fabric image must fail before
# semantic execution rather than reinterpret the descriptor through x86.
set +e
"$T/proof-field" "$F/a_3x5x7.whfld" "$F/b_3x5x7.whfld" "$F/out_3x5x7.whfld" >"$T/proof.out" 2>"$T/proof.err"
rc=$?
set -e
[ "$rc" -ne 0 ] || fail 'unbridged Field fabric image executed'
[ ! -s "$T/proof.out" ] || fail 'unbridged Field fabric image produced output'

! grep -RqsE '(@fpga|fpga[ _-]*kernel|hls[ _-]*kernel|runtime[ _-]*device[ _-]*(selector|scheduler)|fixed[ _-]*(pe|tile)|fabric[ _-]*workload[ _-]*matcher)' surface compiler runtime tools
printf '%s\n' \
  'FABRIC_ACTIVATION_ENTRY_ABI=PASS' \
  'EXTERNAL_COMPLETION_EXPLICIT_STATE=PASS' \
  'FIELD_FABRIC_DATAPATH_DESCRIPTOR=PASS' \
  'FIELD_FABRIC_SECOND_IR=0' \
  'FIELD_FABRIC_X86_FALLBACK=0' \
  'WHEELCHAIR_FABRIC_ACTIVATION_FIELD_DATAPATH_1_3_91=PASS'
