#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1383_statefact_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'MUTABLE_STATEFACT_BUILD=PASS'

PR=compiler/physical_reality.inc
SRC=compiler/general_frontend_x86_64.S
for law in \
  PR_MUTABLE_STATEFACT_CAUSAL_LIFETIME_OWNERSHIP,1 \
  PR_STATEFACT_EXECUTION_LOCAL_FRAME,1 \
  PR_STATEFACT_SHARED_RUNTIME_ARENA,0 \
  PR_STATEFACT_SHARED_NEXT_VERSION_MAILBOX,0 \
  PR_STATEFACT_LOCK_REPAIR,0 \
  PR_STATEFACT_RUNTIME_OWNER_MANAGER,0 \
  PR_STATEFACT_WORK_STEALING,0 \
  PR_STATEFACT_PARALLEL_DSL_ROUTE,0; do
  k=${law%,*}; v=${law#*,}
  grep -q "^.equ $k,$v$" "$PR"
done
! grep -q 'GSTATE_RUNTIME_STRIDE' "$SRC"
! grep -q 'g_runtime_state_base_va' "$SRC"
! grep -q 'g_runtime_state_temp_base_va' "$SRC"
grep -q '^g_emit_state_frame_enter:$' "$SRC"
grep -q '^g_emit_state_frame_leave:$' "$SRC"
echo 'SHARED_MUTABLE_STATE_ARENA=0'
echo 'CAUSAL_STATEFACT_FRAME_AUTHORITY=PASS'

cat > "$T/concurrent_nonaffine_4.wh" <<'WH'
program concurrent_nonaffine_4
contract integer_overflow = wrap
input s0: u64
input s1: u64
input s2: u64
input s3: u64
input n: u64
iterate a limit n {
    state x: u64 = s0
    state i: u64 = 0
    while i < n
    update x = (bit_xor(x, i)) * 6364136223846793005 + 1442695040888963407
    update i = i + 1
    result x
}
iterate b limit n {
    state x: u64 = s1
    state i: u64 = 0
    while i < n
    update x = (bit_xor(x, i)) * 6364136223846793005 + 1442695040888963407
    update i = i + 1
    result x
}
iterate c limit n {
    state x: u64 = s2
    state i: u64 = 0
    while i < n
    update x = (bit_xor(x, i)) * 6364136223846793005 + 1442695040888963407
    update i = i + 1
    result x
}
iterate d limit n {
    state x: u64 = s3
    state i: u64 = 0
    while i < n
    update x = (bit_xor(x, i)) * 6364136223846793005 + 1442695040888963407
    update i = i + 1
    result x
}
let ab = a + b
let cd = c + d
let total = ab + cd
output total = total
output a = a
output b = b
output c = c
output d = d
WH

build/wheelchairc "$T/concurrent_nonaffine_4.wh" -o "$T/probe" >/dev/null
cat > "$T/expected" <<'OUT'
out00_bits=0x9ffc0452ac1600ea
out01_bits=0x6393b20076658639
out02_bits=0x2e4f1519735acb92
out03_bits=0x3ebddfa4be48a2b3
out04_bits=0xcf5b5d94040d0c6c
OUT

# Long enough to overlap four mutable branches.  Every run must remain bit-exact.
i=0
while [ "$i" -lt 20 ]; do
  taskset -c 0-3 "$T/probe" 1 2 3 4 1000 > "$T/out"
  cmp "$T/expected" "$T/out"
  i=$((i+1))
done
echo 'CONCURRENT_NONAFFINE_MUTABLE_DETERMINISM=20/20'

# The target image must contain one 32-byte execution-local frame per iterate
# episode and R15-relative state traffic.  This checks the generated artifact,
# not merely compiler source comments.
python3 - "$T/probe" <<'PY'
import sys
b=open(sys.argv[1],'rb').read()
pro=bytes.fromhex('48 81 ec 20 00 00 00 49 89 e7')
assert b.count(pro) >= 4, b.count(pro)
assert b.count(bytes.fromhex('49 8b 87')) > 0
assert b.count(bytes.fromhex('49 89 87')) > 0
PY
echo 'STATEFACT_TARGET_LOCAL_FRAME=PASS'

# No concurrency repair is allowed to grow a scheduler/ownership subsystem.
! grep -RqsE 'statefact[ _-]*(lock|mutex|spin|owner[ _-]*manager|worker|steal|queue)|mutable[ _-]*state[ _-]*(lock|mutex|work[ _-]*steal)' compiler runtime surface tools
! grep -RqsE 'parallel[ _-]*(dsl|iterate[ _-]*scheduler|state[ _-]*scheduler)' compiler runtime surface tools
echo 'STATEFACT_LOCK_REPAIR=0'
echo 'STATEFACT_SCHEDULER=0'
echo 'WHEELCHAIR_MUTABLE_STATEFACT_1_3_83=PASS'
