#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair1382_coord_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh >/dev/null
echo 'COORDINATEFACT_AGING_BUILD=PASS'

PR=compiler/physical_reality.inc
SRC=compiler/field_frontend_common_x86_64.S
RT=runtime/field_runtime_512_x86_64.S
for law in \
  PR_PERSISTENT_RANKN_COORDINATEFACT,1 \
  PR_COORDINATEFACT_PER_ACCESS_REDECODE,0 \
  PR_COORDINATEFACT_EXECUTION_LOCAL_CARRIERS,1 \
  PR_COORDINATEFACT_SHARED_ACROSS_LAYOUTS,1 \
  PR_AVX512_COORDINATE_OFFSET_STACK_AUTHORITY,0 \
  PR_COORDINATEFACT_SECOND_IR,0 \
  PR_COORDINATE_WORKLOAD_MATCHER,0; do
  k=${law%,*}; v=${law#*,}
  grep -q "^.equ $k,$v$" "$PR"
done
grep -q '^field_prepare_coords_f32_r8:$' "$RT"
grep -q '^field_compute_offsets_from_coords_f32_r8:$' "$RT"
grep -q '^field_advance_coords_f32_r8:$' "$RT"
grep -q '^ff_runtime_prepare_coords_va_for_field:$' "$SRC"
grep -q '^ff_runtime_offsets_from_coords_va_for_access:$' "$SRC"
grep -q '^ff_runtime_advance_coords_va_for_field:$' "$SRC"
echo 'RANKN_COORDINATEFACT_SINGLE_AUTHORITY=PASS'

# Non-power-of-two, padded Rank-3 field.  This forces the launch-generic path for
# many packets.  The exact mathematical result is 3*5*37 = 555, so the test
# covers initial coordinate materialization, cross-packet induction, tail mask,
# and non-contiguous field strides without any benchmark-specific oracle.
python3 - "$T/padded.whfld" <<'PY'
import struct,sys
out=sys.argv[1]
b=bytearray(256)
b[:8]=b'WHFLD216'
struct.pack_into('<I',b,8,1)
struct.pack_into('<I',b,12,1)
struct.pack_into('<I',b,16,3)
struct.pack_into('<Q',b,24,256)
ext=(3,5,37); st=(1592,312,8)
for off,v in zip((32,40,48),ext): struct.pack_into('<Q',b,off,v)
for off,v in zip((96,104,112),st): struct.pack_into('<Q',b,off,v)
struct.pack_into('<Q',b,160,3*5*37)
span=(ext[0]-1)*st[0]+(ext[1]-1)*st[1]+(ext[2]-1)*st[2]+4
data=bytearray(span)
for i in range(ext[0]):
  for j in range(ext[1]):
    for k in range(ext[2]): struct.pack_into('<f',data,i*st[0]+j*st[1]+k*st[2],1.0)
open(out,'wb').write(b+data)
PY
build/fieldc devtrash/tests/field_1216/sum.json -o "$T/sum512" >/dev/null
[ "$("$T/sum512" "$T/padded.whfld")" = 'checksum_f32_bits=0x440ac000' ]
build/fieldc-native256 devtrash/tests/field_1216/sum.json -o "$T/sum256" >/dev/null
[ "$("$T/sum256" "$T/padded.whfld")" = 'checksum_f32_bits=0x440ac000' ]
echo 'NONPOW2_GENERIC_COORDINATE_INDUCTION=PASS'

# A periodic 7-neighbor graph must retain truthful gather at the genuinely
# straddling packet, while Native512 must not spill its zmm17 offset MachineFact
# merely to reload it for the gather.  This is a structural gate, not a speed
# assertion and not a workload-named production route.
build/fieldc devtrash/benchmarks/real_sparse_1326/miniamr7.json -o "$T/amr" >/dev/null
read off va sz <<EOF
$(readelf -lW "$T/amr" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOF
dd if="$T/amr" of="$T/gen.bin" bs=1 skip=$((off)) count=$((sz)) status=none
objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$T/gen.bin" > "$T/gen.dis"
grep -q 'vgatherdps' "$T/gen.dis"
! grep -Eq 'vmovups[[:space:]]+ZMMWORD PTR \[rsp[^]]*\],zmm17' "$T/gen.dis"
! grep -Eq 'vmovups[[:space:]]+zmm17,ZMMWORD PTR \[rsp' "$T/gen.dis"
echo 'AVX512_OFFSET_STACK_ROUNDTRIP=0'
echo 'TRUE_STRADDLING_GATHER_PRESERVED=PASS'

# New architecture must remain a fact lifetime extension, never a named route.
! grep -RqsE 'coordinate[ _-]*(optimizer|scheduler|manager)|boundary[ _-]*coordinate[ _-]*(route|matcher)|(^|[^A-Za-z])(poisson|stencil|miniAMR|miniFE)[_-]?(coordinate|matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'fixed[ _-]*coordinate[ _-]*(tile|window|chunk)|coordinate[ _-]*work[ _-]*steal' compiler runtime surface tools
echo 'COORDINATE_SECOND_OPTIMIZER=0'
echo 'COORDINATE_WORKLOAD_ROUTE=0'
echo 'WHEELCHAIR_COORDINATEFACT_AGING_1_3_82=PASS'
