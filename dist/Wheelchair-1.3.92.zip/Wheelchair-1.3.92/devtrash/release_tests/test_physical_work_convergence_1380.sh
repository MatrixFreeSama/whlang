#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

fail(){ echo "physical-work 1.3.80: $*" >&2; exit 1; }

# One old Physical Reality owns the new behavior; no queue/scheduler family.
grep -q '^.equ PR_CAUSAL_FRONTIER_COST_GATED,1$' compiler/physical_reality.inc
grep -q '^.equ PR_READY_IMPLIES_OUTWARD_EXECUTION,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_CPU_LOCATION_QUERY,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_NUMA_PAGE_MIGRATION,0$' compiler/physical_reality.inc
grep -q '^.equ PR_CAUSAL_STATE_CACHELINE_OWNERSHIP,1$' compiler/physical_reality.inc
grep -q '^.equ PR_CAUSAL_STATE_PAGE_PER_NODE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_BOUNDARY_VALUEFACT_RESIDENCY_CONTINUITY,1$' compiler/physical_reality.inc
grep -q '^.equ PR_BOUNDARY_FORCES_STACK_ROUNDTRIP,0$' compiler/physical_reality.inc
grep -q '^.equ PRC_FRONTEND_BYTE_TICKS,3$' compiler/physical_cost_ticks.inc

# General no longer observes CPU/NUMA placement and causal state is one line.
grep -q '^.equ ST_NODE_BYTES, 64$' runtime/general_parallel_release_x86_64.S
! grep -qE 'SYS_getcpu|SYS_mbind|gr_localize_node_state' runtime/general_parallel_release_x86_64.S
grep -q '^gr_should_materialize:$' runtime/general_parallel_release_x86_64.S
grep -q '^g_fragment_static_once:$' compiler/general_frontend_x86_64.S
grep -q 'work_ticks\[N\]' build/general_parallel_release_offsets.json

# Dynamic causal work remains correct while straight-line successors use the
# cost gate rather than readiness=>clone as a semantic identity.
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/branch" >/dev/null
[ "$("$T/branch" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail branch
bin/wheelchairc devtrash/tests/general_parallel_126/iterate_probe.wh -o "$T/iterate" >/dev/null
[ "$("$T/iterate" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ] || fail iterate

# Boundary/helper ValueFacts keep helper-sovereign residents alive.  Mixed
# layout exercises the generic/gather authority and must remain bit-exact.
F=devtrash/tests/field_1216
build/fieldc "$F/mixed.json" -o "$T/mixed" >/dev/null
cp "$F/out_3x5x7.whfld" "$T/out.whfld"
[ "$("$T/mixed" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/out.whfld")" = 'checksum_f32_bits=0x47126d00' ] || fail mixed
cmp "$T/out.whfld" "$F/expected_mixed_3x5x7.whfld"

read off va sz <<EOH
$(readelf -lW "$T/mixed" | awk '$1=="LOAD"{o=$2;v=$3;s=$5} END{print o,v,s}')
EOH
dd if="$T/mixed" of="$T/mixed.bin" bs=1 skip=$((off)) count=$((sz)) status=none
objdump -D -b binary -m i386:x86-64 -Mintel --adjust-vma=$((va)) "$T/mixed.bin" > "$T/mixed.dis"
grep -Eq 'vmovaps[[:space:]]+zmm6,zmm0' "$T/mixed.dis" || fail 'boundary resident continuity missing'
stack_vec=$(grep -Ec 'vmovups.*\[rsp\+' "$T/mixed.dis" || true)
[ "$stack_vec" -le 9 ] || fail "boundary stack vector traffic regressed: $stack_vec"

! grep -RqsE '(^|[^A-Za-z])(poisson|stencil|miniFE|miniAMR|CloverLeaf)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'work[ _-]*steal|global[ _-]*ready[ _-]*queue|idle[ _-]*cpu[ _-]*(query|scan)' compiler runtime surface tools

printf '%s\n' \
  'CAUSAL_FRONTIER_READY_IMPLIES_CLONE=0' \
  'GENERAL_CPU_LOCATION_QUERY=0' \
  'CAUSAL_STATE_BYTES_PER_NODE=64' \
  'BOUNDARY_VALUEFACT_STACK_ROUNDTRIP_REDUCED=PASS' \
  'DYNAMIC_CAUSAL_SEMANTICS=PASS' \
  'WORKLOAD_SPECIFIC_ROUTE=0' \
  'WHEELCHAIR_PHYSICAL_WORK_CONVERGENCE_1_3_80=PASS'
