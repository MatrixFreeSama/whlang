#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "silicon-domain 1.3.85: $*" >&2; exit 1; }

./build.sh >/dev/null
echo 'SILICON_DOMAIN_BUILD=PASS'

SR=compiler/silicon_reality.inc
PR=compiler/physical_reality.inc
for law in \
  SR_SILICON_DOMAIN_GRAPH_IS_TARGET_AUTHORITY,1 \
  SR_TRAFFIC_X_DOMAIN_BOUNDARY_IS_SPACE_COST,1 \
  SR_VENDOR_MODEL_ROUTE,0 \
  SR_GEOMETRIC_DIE_ADJACENCY_ASSUMED,0 \
  SR_SOURCE_SIZE_AFFINITY_CROSSOVER,0 \
  SR_DOMAIN_GRAPH_RUNTIME_SCHEDULER,0 \
  SR_DOMAIN_GRAPH_MAY_CHANGE_SEMANTICS,0 \
  SR_DOMAIN_GRAPH_MAY_CONSTRAIN_REALIZATION,1; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$SR"
done
for law in \
  PR_SILICON_DOMAIN_GRAPH_SINGLE_AUTHORITY,1 \
  PR_TRAFFIC_X_DOMAIN_GRAPH_SPATIAL_CLOSURE,1 \
  PR_VENDOR_MODEL_EXECUTION_ROUTE,0 \
  PR_GEOMETRIC_DIE_DISTANCE_GUESS,0 \
  PR_SOURCE_SIZE_AFFINITY_THRESHOLD,0 \
  PR_LOCALITY_DOMAIN_CAPS_EXECUTION_MULTIPLICITY,1 \
  PR_DOMAIN_GRAPH_SECOND_IR,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$PR"
done

grep -q '^detect_cpu_topology:$' compiler/topologyc_x86_64.S
grep -q 'l1d_share_threads' compiler/topologyc_x86_64.S
grep -q 'l2_share_threads' compiler/topologyc_x86_64.S
grep -q 'l3_share_threads' compiler/topologyc_x86_64.S
grep -q '^detect_field_llc_share_threads:$' compiler/fieldc_driver_x86_64.S
! grep -RqsE 'profile_zen4|OUTWARD_TICKS_ZEN4|PIN_AT_OR_ABOVE_32_MIB|33554432' compiler runtime tools
! grep -RqsE 'silicon[ _-]*(worker|task|ready[ _-]*queue|work[ _-]*steal|kernel[ _-]*dispatch)|fpga[ _-]*(worker|task|scheduler)|asic[ _-]*(worker|task|scheduler)' compiler runtime surface tools
python3 - <<'PY'
s=open('compiler/topologyc_x86_64.S').read()
a=s.index('prepare_source_memory:')
b=s.index('read_full:',a)
assert 'syscall\n    syscall' not in s[a:b]
PY
echo 'VENDOR_MODEL_EXECUTION_ROUTES=0'
echo 'SOURCE_SIZE_AFFINITY_CROSSOVER=0'
echo 'NUMA_DOUBLE_SYSCALL=0'

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
assert d['format']=='wheelchair.silicon-reality/2'
assert d['semantic_authority']=='physical_dag'
assert d['space_authority']=='traffic_x_silicon_domain_graph'
assert d['silicon_domain_graph_authority'] is True
assert d['geometric_die_adjacency_assumed'] is False
assert d['vendor_model_routes'] is False
assert d['source_size_affinity_crossover'] is False
assert d['allowed_execution_contexts'] >= 1
assert d['locality_domain_execution_ceiling'] >= 1
assert d['locality_domain_execution_ceiling'] <= d['allowed_execution_contexts']
assert d['threads_per_core'] >= 1
assert d['cores_per_package'] >= 1
assert d['logical_per_package'] >= 1
for k in ('runtime_silicon_allocator','runtime_idle_resource_query','runtime_ready_queue','runtime_work_stealing','parallel_dsl_route','hardware_kernel_language'):
    assert d[k] is False,(k,d[k])
print('SILICON_DOMAIN_CONTRACT_JSON=PASS')
PY

bin/topologyc --silicon-audit > "$T/audit.json"
python3 - "$T/audit.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
assert d['format']=='topology.silicon-audit/3'
assert d['microarchitecture_profile']=='fact-derived-x86_64'
assert d['affinity_policy']=='OS_EXTERNAL_NO_SIZE_CROSSOVER'
assert d['die_geometric_distance']=='UNEXPOSED_NOT_ASSUMED'
print('FACT_DERIVED_PROFILE=PASS')
PY

# Existing x86 realization stays zero-flip on unrelated General and Field paths.
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/general" >/dev/null
[ "$("$T/general" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail general
F=devtrash/tests/field_1216
bin/fieldc "$F/mixed.json" -o "$T/field" >/dev/null
cp "$F/out_3x5x7.whfld" "$T/out.whfld"
[ "$("$T/field" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/out.whfld")" = 'checksum_f32_bits=0x47126d00' ] || fail field
cmp "$T/out.whfld" "$F/expected_mixed_3x5x7.whfld"
echo 'X86_DOMAIN_REALIZATION_ZERO_FLIP=PASS'
echo 'WHEELCHAIR_SILICON_DOMAIN_GRAPH_1_3_85=PASS'
