#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "fabric target facts 1.3.89: $*" >&2; exit 1; }

./build.sh >/dev/null

grep -q '^.equ SR_FABRIC_TARGET_FACTS_EXTERNAL_ONLY,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_TARGET_FACTS_DEFAULT_ZERO,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_AOT_JOINT_DOMAIN_PLACEMENT,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_JOINT_PLACEMENT_STRICT_IMPROVEMENT,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_JOINT_PLACEMENT_FIXED_ROUND_LIMIT,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_USER_FABRIC_PLACEMENT_ANNOTATION,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_ACTIVATION_BRIDGE_PRESENT,0$' compiler/silicon_reality.inc
grep -q '^.equ PR_X86_FABRIC_JOINT_COST_CLOSURE,1$' compiler/physical_reality.inc
grep -q '^.equ PR_INCIDENT_EDGE_TRAFFIC_IN_DOMAIN_FLIP_COST,1$' compiler/physical_reality.inc
grep -q '^.equ PR_JOINT_DOMAIN_FIXED_ROUND_LIMIT,0$' compiler/physical_reality.inc
grep -q '^g_close_heterogeneous_placement:$' compiler/general_frontend_x86_64.S
grep -q '^fabric_target_facts_proved:$' compiler/fabric_target_facts_x86_64.S

# Production facts are intentionally absent. A normal release compiler must
# therefore preserve the proved x86 realization rather than fabricate hardware.
bin/topologyc --silicon-contract > "$T/prod-contract.json"
python3 - "$T/prod-contract.json" <<'PY'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/9'
assert D['target_kind']=='physical-domain-graph'
assert D['fabric_target_facts_proved']==0
for k in ('fabric_logic_units','fabric_register_units','fabric_dsp_units',
          'fabric_local_storage_bytes','fabric_routing_domains','fabric_clock_regions'):
    assert D[k]==0,(k,D[k])
assert D['joint_domain_placement']=='strict_improvement_coordinate_closure'
assert D['joint_domain_fixed_round_limit'] is False
assert D['fabric_activation_bridge_present'] is False
PY

bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/prod-branch" >/dev/null

# Build a proof-only target compiler from the same current sources. These values
# are synthetic physical target facts used only to prove the joint-placement
# algebra; the proof image is never installed as a production compiler.
as --64 \
  --defsym FABRIC_TARGET_PRESENT=1 \
  --defsym FABRIC_LOGIC_UNITS=100000 \
  --defsym FABRIC_REGISTER_UNITS=200000 \
  --defsym FABRIC_DSP_UNITS=1000 \
  --defsym FABRIC_LOCAL_STORAGE_BYTES=67108864 \
  --defsym FABRIC_ROUTING_DOMAINS=4 \
  --defsym FABRIC_CLOCK_REGIONS=4 \
  --defsym FABRIC_COMPUTE_TICKS_NUM=1 \
  --defsym FABRIC_COMPUTE_TICKS_DEN=4 \
  --defsym FABRIC_ACTIVATION_TICKS=100 \
  --defsym FABRIC_TRANSPORT_FIXED_TICKS=20 \
  --defsym FABRIC_TRANSPORT_TICKS_PER_BYTE=1 \
  compiler/fabric_target_facts_x86_64.S -o "$T/fabric_target_facts.o"

ld -nostdlib -static -z noexecstack \
  build/topologyc_core.o build/silicon_domain_probe.o "$T/fabric_target_facts.o" \
  build/outward_materialization_profile.o build/tensor_frontend.o build/general_frontend.o \
  build/runtime_blob.o build/general_runtime_blob.o build/general_parallel_release_blob.o \
  build/surface_lowerer.o build/human_shell_feedback.o -o "$T/topologyc-fabric-proof"

"$T/topologyc-fabric-proof" --silicon-contract > "$T/fabric-contract.json"
python3 - "$T/fabric-contract.json" <<'PY'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['fabric_target_facts_proved']==1
assert D['fabric_logic_units']==100000
assert D['fabric_register_units']==200000
assert D['fabric_dsp_units']==1000
assert D['fabric_local_storage_bytes']==67108864
assert D['fabric_routing_domains']==4
assert D['fabric_clock_regions']==4
assert D['fabric_compute_ticks_num']==1
assert D['fabric_compute_ticks_den']==4
assert D['fabric_activation_ticks']==100
assert D['fabric_transport_fixed_ticks']==20
assert D['fabric_transport_ticks_per_byte']==1
PY

"$T/topologyc-fabric-proof" devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/fabric-plan" >/dev/null

python3 - "$T/prod-branch" "$T/fabric-plan" compiler/general_runtime_offsets.inc build/general_parallel_release_offsets.json <<'PY'
import json,re,struct,sys
inc=open(sys.argv[3]).read(); o=json.load(open(sys.argv[4]))
def eq(name):
    m=re.search(r'^\.equ\s+'+re.escape(name)+r',\s*(0x[0-9a-fA-F]+|[0-9]+)$',inc,re.M)
    assert m,name
    return int(m.group(1),0)
def facts(path):
    b=open(path,'rb').read()
    trailer=struct.unpack_from('<Q',b,eq('GENERAL_PROGRAM_TRAILER_FILE_OFFSET_OFF'))[0]
    code_rel=struct.unpack_from('<Q',b,eq('GENERAL_PROGRAM_CODE_REL_OFFSET_OFF'))[0]
    base=trailer+code_rel; O=o['offsets']
    N=struct.unpack_from('<I',b,base+O['gr_node_count'])[0]
    E=struct.unpack_from('<I',b,base+O['gr_edge_count'])[0]
    m=base+o['template_size']
    work=struct.unpack_from('<'+'I'*N,b,m+12*N)
    transfers=struct.unpack_from('<'+'Q'*E,b,m+16*N+8*E)
    tags=struct.unpack_from('<'+'I'*N,b,m+16*N+16*E)
    return N,E,work,transfers,tags
P=facts(sys.argv[1]); F=facts(sys.argv[2])
assert P[:4]==F[:4],(P,F)
assert all(x==1 for x in P[4]),P[4]
# With the proof target facts the common physical-cost closure must admit both
# domains at once. The exact expected closure is deterministic for branch_probe.
assert F[4]==(2,2,1,2,1),F[4]
assert 1 in F[4] and 2 in F[4]
print('PRODUCTION_FABRIC_TAGS=0')
print('PROOF_JOINT_TAGS='+','.join(map(str,F[4])))
print('SIMULTANEOUS_X86_FABRIC_PLAN=PASS')
PY

! grep -RqsE '(@fpga|fpga[ _-]*kernel|hls[ _-]*kernel|runtime[ _-]*device[ _-]*(selector|scheduler)|fixed[ _-]*(pe|tile)|fabric[ _-]*workload[ _-]*matcher)' surface compiler runtime tools
printf '%s\n' \
  'FABRIC_TARGET_FACTS_EXTERNAL_ONLY=PASS' \
  'FABRIC_TARGET_DEFAULT_ZERO=PASS' \
  'AOT_JOINT_DOMAIN_PLACEMENT=PASS' \
  'JOINT_PLACEMENT_FIXED_ROUNDS=0' \
  'SOURCE_DEVICE_ANNOTATION=0' \
  'FABRIC_ACTIVATION_BRIDGE_PRESENT=0' \
  'WHEELCHAIR_FABRIC_TARGET_FACTS_1_3_89=PASS'
