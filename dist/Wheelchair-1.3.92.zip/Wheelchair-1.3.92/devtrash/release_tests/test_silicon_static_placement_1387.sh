#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "silicon static placement 1.3.87: $*" >&2; exit 1; }

./build.sh >/dev/null
echo 'SILICON_STATIC_PLACEMENT_BUILD=PASS'

for law in \
  SR_AOT_STATIC_DOMAIN_PLACEMENT,1 \
  SR_PLACEMENT_INHERITED_BY_OUTWARD_EXECUTIONS,1 \
  SR_RUNTIME_PLACEMENT_RESOURCE_MATCHING,0 \
  SR_RUNTIME_PLACEMENT_MIGRATION,0 \
  SR_CARDINALITY_FALLBACK_ON_IDENTITY_FAILURE,0 \
  SR_PLACEMENT_CPU_ORDINAL_TIEBREAK,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" compiler/silicon_reality.inc
done
for law in \
  PR_TRAFFIC_X_DOMAIN_IDENTITY_STATIC_PLACEMENT,1 \
  PR_STATIC_PLACEMENT_INHERITED,1 \
  PR_RUNTIME_PLACEMENT_SELECTOR,0 \
  PR_RUNTIME_PLACEMENT_MIGRATION,0 \
  PR_DOMAIN_IDENTITY_FAILURE_CARDINALITY_GUESS,0 \
  PR_STATIC_PLACEMENT_SECOND_IR,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" compiler/physical_reality.inc
done

grep -q '^sd_choose_preferred_l3_domain:$' compiler/silicon_domain_probe_x86_64.S
grep -q 'static_placement_required_patch' runtime/tensor_runtime_x86_64.S
grep -q 'static_placement_required_patch' runtime/field_runtime_512_x86_64.S
grep -q 'gr_static_placement_required' runtime/general_parallel_release_x86_64.S
! grep -RqsE 'runtime[ _-]*placement[ _-]*(selector|scheduler|autotune|migration)|placement[ _-]*(worker|task|kernel)|fixed[ _-]*placement[ _-]*(tile|pe)' compiler runtime surface tools

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY2'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/9'
assert D['placement_authority']=='traffic_x_exact_l3_domain_identity'
assert D['placement_is_aot_inherited'] is True
assert D['cardinality_fallback'] is False
assert D['static_placement_exact'] in (0,1)
assert D['static_placement_required'] in (0,1)
if D['static_placement_required']:
    assert D['static_placement_exact']==1
    assert D['l3_admitted_domain_count']>1
    assert 1 <= D['preferred_l3_execution_contexts'] < D['allowed_execution_contexts']
if D['static_placement_exact'] and D['l3_admitted_domain_count']:
    assert D['preferred_l3_execution_contexts']==D['l3_max_admitted_intersection']
for k in ('runtime_silicon_allocator','runtime_idle_resource_query','runtime_ready_queue','runtime_work_stealing','parallel_dsl_route','hardware_kernel_language'):
    assert D[k] is False
print('SILICON_STATIC_PLACEMENT_CONTRACT=PASS')
PY2

# Verify that the field image receives the same one-shot placement requirement
# published by the target contract. This reads the generated ELF patch directly;
# no runtime scheduler observation is involved.
F=devtrash/tests/field_1216
bin/fieldc "$F/mixed.json" -o "$T/field" >/dev/null
python3 - "$T/contract.json" "$T/field" build/field_runtime_512_offsets.inc <<'PY2'
import json,re,sys,struct
D=json.load(open(sys.argv[1]))
b=open(sys.argv[2],'rb').read()
t=open(sys.argv[3]).read()
def off(name):
    m=re.search(r'^\.equ '+re.escape(name)+r',\s*(0x[0-9a-fA-F]+|[0-9]+)$',t,re.M)
    assert m,name
    return int(m.group(1),0)
req=struct.unpack_from('<I',b,off('FIELD_RUNTIME_STATIC_PLACEMENT_REQUIRED_OFF'))[0]
mb=struct.unpack_from('<I',b,off('FIELD_RUNTIME_STATIC_PLACEMENT_MASK_BYTES_OFF'))[0]
assert req==D['static_placement_required'],(req,D['static_placement_required'])
if D['static_placement_required']:
    assert mb>0
print('FIELD_STATIC_PLACEMENT_BURN=PASS')
PY2
cp "$F/out_3x5x7.whfld" "$T/out.whfld"
[ "$("$T/field" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/out.whfld")" = 'checksum_f32_bits=0x47126d00' ] || fail field
cmp "$T/out.whfld" "$F/expected_mixed_3x5x7.whfld"

echo 'RUNTIME_PLACEMENT_SELECTOR=0'
echo 'CARDINALITY_FALLBACK=0'
echo 'WHEELCHAIR_SILICON_STATIC_PLACEMENT_1_3_87=PASS'
