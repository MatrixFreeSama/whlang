#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "silicon-domain identity 1.3.86: $*" >&2; exit 1; }

./build.sh >/dev/null
echo 'SILICON_DOMAIN_IDENTITY_BUILD=PASS'

SR=compiler/silicon_reality.inc
PR=compiler/physical_reality.inc
for law in \
  SR_DOMAIN_IDENTITY_FROM_ARCHITECTURAL_TOPOLOGY,1 \
  SR_ALLOWED_SET_X_DOMAIN_IDENTITY_IS_CAPACITY,0 \
  SR_CPU_ORDINAL_IS_PHYSICAL_ADJACENCY,0 \
  SR_CARDINALITY_ONLY_DOMAIN_APPROXIMATION_IS_AUTHORITY,0 \
  SR_COMPILETIME_TOPOLOGY_IDENTITY_PROBE,1 \
  SR_RUNTIME_TOPOLOGY_IDENTITY_PROBE,0 \
  SR_PROBE_AFFINITY_IS_PROGRAM_PLACEMENT,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$SR"
done
for law in \
  PR_SILICON_DOMAIN_IDENTITY_CLOSURE,1 \
  PR_ALLOWED_SET_X_CACHE_IDENTITY_INTERSECTION,1 \
  PR_CPU_NUMBER_ADJACENCY_AUTHORITY,0 \
  PR_DOMAIN_WIDTH_ONLY_NORMAL_AUTHORITY,0 \
  PR_COMPILETIME_APIC_DOMAIN_PROBE,1 \
  PR_RUNTIME_APIC_DOMAIN_PROBE,0 \
  PR_DOMAIN_PROBE_WORK_SCHEDULER,0 \
  PR_DOMAIN_PROBE_IDLE_CAPACITY_QUERY,0; do
  k=${law%,*}; v=${law#*,}; grep -q "^.equ $k,$v$" "$PR"
done

grep -q '^silicon_domain_probe:$' compiler/silicon_domain_probe_x86_64.S
grep -q 'SYS_sched_setaffinity,203' compiler/silicon_domain_probe_x86_64.S
grep -q 'sd_read_apic_id:' compiler/silicon_domain_probe_x86_64.S
grep -q 'sd_execution_admission_capacity' compiler/topologyc_x86_64.S
grep -q 'sd_execution_admission_capacity' compiler/fieldc_driver_x86_64.S
! grep -q '^detect_runtime_topology:$' compiler/topologyc_x86_64.S
! grep -q 'fieldc_affinity_mask' compiler/fieldc_driver_x86_64.S
! grep -RqsE 'cpu[ _-]*(id|number|ordinal)[ _-]*(distance|adjacen|near)|fixed[ _-]*llc[ _-]*group' compiler runtime surface tools
! grep -RqsE 'silicon[ _-]*(worker|task|ready[ _-]*queue|work[ _-]*steal|kernel[ _-]*dispatch)|fpga[ _-]*(worker|task|scheduler)|asic[ _-]*(worker|task|scheduler)' compiler runtime surface tools

echo 'CPU_ORDINAL_ADJACENCY_AUTHORITY=0'
echo 'RUNTIME_TOPOLOGY_IDENTITY_PROBE=0'

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
assert d['format']=='wheelchair.silicon-reality/9'
assert d['semantic_authority']=='physical_dag'
assert d['space_authority']=='traffic_x_silicon_domain_graph'
assert d['domain_identity_authority']=='apic_x_cache_share_intersection'
assert d['cpu_number_adjacency_assumed'] is False
assert d['geometric_die_adjacency_assumed'] is False
assert d['allowed_execution_contexts'] >= 1
assert d['execution_admission_capacity'] >= 1
assert d['execution_admission_capacity'] <= d['allowed_execution_contexts']
assert d['locality_is_execution_capacity_authority'] is False
assert d['power_of_two_execution_roundup'] is False
assert d['domain_identity_exact'] in (0,1)
for level in ('l1d','l2','l3'):
    share=d[f'{level}_share_threads']
    count=d[f'{level}_admitted_domain_count']
    width=d[f'{level}_max_admitted_intersection']
    if width:
        assert width <= d['allowed_execution_contexts']
        if share: assert width <= share
    if d['domain_identity_exact'] and share:
        assert count >= 1
        assert width >= 1
for k in ('runtime_silicon_allocator','runtime_idle_resource_query','runtime_ready_queue','runtime_work_stealing','parallel_dsl_route','hardware_kernel_language'):
    assert d[k] is False,(k,d[k])
print('SILICON_DOMAIN_IDENTITY_CONTRACT=PASS')
PY

bin/topologyc --silicon-audit > "$T/audit.json"
python3 - "$T/audit.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
assert d['format']=='topology.silicon-audit/9'
assert d['microarchitecture_profile']=='fact-derived-x86_64'
assert d['affinity_policy']=='AOT_EXACT_L3_DOMAIN_INHERITED_PLACEMENT'
assert d['die_geometric_distance']=='UNEXPOSED_NOT_ASSUMED'
print('SILICON_DOMAIN_IDENTITY_AUDIT=PASS')
PY

# Semantic zero-flip on unrelated General and Field paths.
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/general" >/dev/null
[ "$("$T/general" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail general
F=devtrash/tests/field_1216
bin/fieldc "$F/mixed.json" -o "$T/field" >/dev/null
cp "$F/out_3x5x7.whfld" "$T/out.whfld"
[ "$("$T/field" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/out.whfld")" = 'checksum_f32_bits=0x47126d00' ] || fail field
cmp "$T/out.whfld" "$F/expected_mixed_3x5x7.whfld"
echo 'X86_DOMAIN_IDENTITY_ZERO_FLIP=PASS'
echo 'WHEELCHAIR_SILICON_DOMAIN_IDENTITY_1_3_86=PASS'
