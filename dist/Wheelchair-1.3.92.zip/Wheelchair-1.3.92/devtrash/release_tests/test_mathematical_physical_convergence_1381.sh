#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "mathematical-physical 1.3.81: $*" >&2; exit 1; }

# One Physical Reality owns transport. No traffic scheduler, runtime bandwidth
# probe, workload matcher, or frontend-named execution route is admitted.
grep -q '^.equ PR_TRAFFIC_REALITY,1$' compiler/physical_reality.inc
grep -q '^.equ PR_TRAFFIC_SECOND_IR,0$' compiler/physical_reality.inc
grep -q '^.equ PR_RUNTIME_BANDWIDTH_PROBE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_PIECEWISE_AFFINE_REGIONFACT,1$' compiler/physical_reality.inc
grep -q '^.equ PR_PERIODIC_BOUNDARY_IMPLIES_GATHER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_BOUNDARY_COMPATIBILITY_BACKEND,0$' compiler/physical_reality.inc
grep -q '^.equ PR_AFFINE_TRANSPORT_STREAM_FACT,1$' compiler/physical_reality.inc
grep -q '^.equ PR_MATHEMATICAL_TRANSPORT_FLOOR_IS_LOWER_BOUND,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SLIDING_WINDOW_WORKLOAD_MATCHER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_FIXED_WINDOW_WIDTH,0$' compiler/physical_reality.inc
grep -q '^.equ PR_SPACETIME_IS_RANKN_CAUSAL_REGION,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SPACETIME_SECOND_SCHEDULER,0$' compiler/physical_reality.inc
grep -q '^.equ PR_FIXED_TEMPORAL_TILE,0$' compiler/physical_reality.inc
grep -q '^.equ PR_FRONTEND_PHYSICAL_AUTHORITY_UNIFIED,1$' compiler/physical_reality.inc
grep -q '^.equ PR_FRONTEND_NAME_EXECUTION_ROUTE,0$' compiler/physical_reality.inc
grep -q '^.equ PRC_TRAFFIC_LINE_TICKS,12$' compiler/physical_cost_ticks.inc
grep -q '^.equ PRC_TRAFFIC_LINE_BYTES,64$' compiler/physical_cost_ticks.inc

# Field publishes both actual transport work and the mathematical affine-stream
# floor. The floor is a fact, not a forced sliding-window implementation.
grep -q '^ff_derive_transport_facts:$' compiler/field_frontend_common_x86_64.S
grep -q '^ff_actual_traffic_lines:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_transport_floor_lines:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_actual_traffic_ticks:' compiler/field_frontend_common_x86_64.S
grep -q '^ff_transport_floor_ticks:' compiler/field_frontend_common_x86_64.S
grep -q 'call ff_derive_transport_facts' compiler/field_frontend_common_x86_64.S

# Periodic topology is piecewise-affine. Region deltas must live in the current
# execution, never in the CLONE_VM-shared global delta table.
for f in runtime/field_runtime_512_x86_64.S runtime/field_runtime_256_x86_64.S; do
  grep -q '1.3.81 Piecewise-Affine RegionFact' "$f"
  grep -q 'execution-local RegionFact deltas' "$f"
  grep -q '^\.fre81_piecewise:' "$f"
  grep -q '^\.fre81_fast_interior:' "$f"
  grep -q 'An innermost wrap occupies only a local row fragment' "$f"
  block=$(sed -n '/^field_regular_run_end:/,/^\.fre81_fail:/p' "$f")
  printf '%s\n' "$block" | grep -q 'mov rbp,rdi'
  ! printf '%s\n' "$block" | grep -q 'g_spec_linear_delta_bytes_ptr.*mov\|mov.*g_spec_linear_delta_bytes_ptr'
done

# Tensor and General derive traffic as a peer resource of the same schedule/work
# price. General counts emitted memory facts; no source/workload name is used.
grep -q 'mov edx, 11' compiler/topologyc_x86_64.S
grep -q '^bottleneck_traffic:' compiler/topologyc_x86_64.S
grep -q 'g_fragment_memory_ops_ptr' compiler/general_frontend_x86_64.S
grep -q 'g_current_fragment_memory_ops' compiler/general_frontend_x86_64.S
grep -q 'imul rax,PRC_TRAFFIC_LINE_TICKS' compiler/general_frontend_x86_64.S
grep -q 'cmovb r15d,ebp' compiler/general_frontend_x86_64.S

# Field semantics remain exact on both machine widths for the admitted mixed
# layout boundary case.
F=devtrash/tests/field_1216
for C in build/fieldc build/fieldc-native256; do
  tag=$(basename "$C")
  "$C" "$F/mixed.json" -o "$T/$tag" >/dev/null
  cp "$F/out_3x5x7.whfld" "$T/$tag.out"
  [ "$("$T/$tag" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/$tag.out")" = 'checksum_f32_bits=0x47126d00' ] || fail "$tag checksum"
  cmp "$T/$tag.out" "$F/expected_mixed_3x5x7.whfld"
done

# Dynamic General semantics survive the new traffic price.
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/branch" >/dev/null
[ "$("$T/branch" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail branch

# Architectural negatives: no occupancy machinery, benchmark route, forced
# layout-copy manager, or second spacetime/sliding scheduler may grow beside the
# old facts.
! grep -RqsE 'work[ _-]*steal|global[ _-]*ready[ _-]*queue|idle[ _-]*cpu[ _-]*(query|scan)|runtime[ _-]*bandwidth[ _-]*(probe|autotune)' compiler runtime surface tools
! grep -RqsE '(^|[^A-Za-z])(poisson|stencil|miniFE|miniAMR|CloverLeaf)[_-]?(matcher|route|selector|optimizer)' compiler runtime surface tools
! grep -RqsE 'sliding[ _-]*window[ _-]*(matcher|scheduler)|spacetime[ _-]*(scheduler|tile)[ _-]*(manager|selector)|layout[ _-]*(copy|transpose)[ _-]*(manager|scheduler)' compiler runtime surface tools

printf '%s\n' \
  'TRAFFIC_REALITY_SHARED=PASS' \
  'FIELD_MATHEMATICAL_TRAFFIC_FLOOR=PASS' \
  'PIECEWISE_AFFINE_PERIODIC_REGIONFACT=PASS' \
  'REGION_DELTA_SHARED_MUTATION=0' \
  'TENSOR_TRAFFIC_RESOURCE=PASS' \
  'GENERAL_TRAFFIC_RESOURCE=PASS' \
  'FORCED_SLIDING_WINDOW_REALIZATION=0' \
  'FORCED_LAYOUT_CONVERSION=0' \
  'SECOND_SPACETIME_SCHEDULER=0' \
  'WHEELCHAIR_MATHEMATICAL_PHYSICAL_CONVERGENCE_1_3_81=PASS'
