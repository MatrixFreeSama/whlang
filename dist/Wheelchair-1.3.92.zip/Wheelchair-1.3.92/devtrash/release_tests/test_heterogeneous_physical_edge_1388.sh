#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "heterogeneous physical edge 1.3.88: $*" >&2; exit 1; }

./build.sh >/dev/null

grep -q '^.equ SR_SIMULTANEOUS_HETEROGENEOUS_REALIZATION,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_X86_FPGA_EXCLUSIVE_TARGET_SELECTION,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_PHYSICAL_EDGE_FACT_AUTHORITY,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_SHARED_CAUSAL_COMPLETION_LAW,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FPGA_OFFLOAD_KERNEL_MODEL,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_RUNTIME_DEVICE_SELECTOR,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_UNPROVEN_FABRIC_MAY_BE_MATERIALIZED,0$' compiler/silicon_reality.inc
grep -q '^.equ PR_PHYSICAL_EDGE_FACTS,1$' compiler/physical_reality.inc
grep -q '^.equ PR_EDGE_TRANSFER_LOWER_BOUND,1$' compiler/physical_reality.inc
grep -q '^.equ PR_HETEROGENEOUS_DOMAINS_MAY_COEXIST,1$' compiler/physical_reality.inc
grep -q '^.equ PR_SHARED_CAUSAL_COMPLETION_PUBLICATION,1$' compiler/physical_reality.inc
grep -q '^g_edge_accumulate_type_transfer:$' compiler/general_frontend_x86_64.S
grep -q '^gr_publish_completion:$' runtime/general_parallel_release_x86_64.S
grep -q 'edge_transfer_bytes\[E:qword\],realization_tag\[N\]' build/general_parallel_release_offsets.json

grep -q 'gr_publish_completion' build/general_parallel_release_offsets.json
nm -n build/general_parallel_release.elf | grep -q ' gr_publish_completion$'

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/9'
assert D['simultaneous_heterogeneous_realization'] is True
assert D['physical_edge_facts'] is True
assert D['edge_traffic_cross_domain_cost'] is True
assert D['shared_causal_completion_law'] is True
assert D['x86_fpga_exclusive_target_selection'] is False
assert D['fpga_offload_kernel_model'] is False
assert D['runtime_device_selector'] is False
assert D['fabric_target_facts_proved']==0
assert D['unproven_fabric_materialized'] is False
assert D['fpga_bitstream_emitter_present'] is False
PY

# Compile a real multi-Region General program and inspect the Physical Edge facts
# burned into its compact image metadata. No FPGA is invented on this host: every
# Region must remain tagged as the proved x86 realization.
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/branch" >/dev/null
[ "$("$T/branch" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail general
python3 - "$T/branch" compiler/general_runtime_offsets.inc build/general_parallel_release_offsets.json <<'PY'
import json,re,struct,sys
b=open(sys.argv[1],'rb').read()
inc=open(sys.argv[2]).read()
o=json.load(open(sys.argv[3]))
def eq(name):
    m=re.search(r'^\.equ\s+'+re.escape(name)+r',\s*(0x[0-9a-fA-F]+|[0-9]+)$',inc,re.M)
    assert m,name
    return int(m.group(1),0)
trailer=struct.unpack_from('<Q',b,eq('GENERAL_PROGRAM_TRAILER_FILE_OFFSET_OFF'))[0]
code_rel=struct.unpack_from('<Q',b,eq('GENERAL_PROGRAM_CODE_REL_OFFSET_OFF'))[0]
base=trailer+code_rel
O=o['offsets']; N=struct.unpack_from('<I',b,base+O['gr_node_count'])[0]; E=struct.unpack_from('<I',b,base+O['gr_edge_count'])[0]
assert N>=2 and E>=1,(N,E)
m=base+o['template_size']
transfer_off=m+16*N+8*E
transfers=struct.unpack_from('<'+'Q'*E,b,transfer_off)
tag_off=transfer_off+8*E
tags=struct.unpack_from('<'+'I'*N,b,tag_off)
assert all(x>0 for x in transfers),transfers
assert all(x==1 for x in tags),tags
print('PHYSICAL_EDGE_FACTS_BURNED=PASS')
print('UNPROVEN_FABRIC_TAGS=0')
PY

! grep -RqsE '(@fpga|fpga[ _-]*kernel|hls[ _-]*kernel|runtime[ _-]*device[ _-]*(selector|scheduler)|fpga[ _-]*(worker|task|ready[ _-]*queue|work[ _-]*steal))' surface compiler runtime tools
printf '%s\n' \
  'SIMULTANEOUS_HETEROGENEOUS_REALIZATION=PASS' \
  'PHYSICAL_EDGE_FACT_AUTHORITY=PASS' \
  'SHARED_CAUSAL_COMPLETION_LAW=PASS' \
  'FPGA_OFFLOAD_KERNEL_MODEL=0' \
  'RUNTIME_DEVICE_SELECTOR=0' \
  'WHEELCHAIR_HETEROGENEOUS_PHYSICAL_EDGE_1_3_88=PASS'
