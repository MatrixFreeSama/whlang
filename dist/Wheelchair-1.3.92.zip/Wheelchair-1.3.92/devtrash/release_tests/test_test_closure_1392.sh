#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.92" ]
[ -x test.sh ]
[ -x devtrash/coverage/run_native_coverage.sh ]
! grep -RqsE 'native_coverage|WHEELCHAIR_COVERAGE|coverage-real' compiler runtime surface tools build.sh
[ "$(grep -c '^test_.*\.sh$' devtrash/release_tests/current.list)" -eq 23 ]
[ "$(sort devtrash/release_tests/current.list | uniq -d | wc -l)" -eq 0 ]
grep -q '^test_mathematical_physical_convergence_1381.sh$' devtrash/release_tests/current.list
grep -q '^test_silicon_domain_identity_1386.sh$' devtrash/release_tests/current.list
grep -q '^test_silicon_static_placement_1387.sh$' devtrash/release_tests/current.list
grep -q '^test_heterogeneous_physical_edge_1388.sh$' devtrash/release_tests/current.list
grep -q '^test_fabric_target_facts_1389.sh$' devtrash/release_tests/current.list
grep -q '^test_fabric_realization_descriptor_1390.sh$' devtrash/release_tests/current.list
grep -q '^test_fabric_activation_field_datapath_1391.sh$' devtrash/release_tests/current.list
grep -q '^test_execution_admission_expansion_1392.sh$' devtrash/release_tests/current.list
grep -q '^test_test_closure_1392.sh$' devtrash/release_tests/current.list
! grep -q '^test_test_closure_1391.sh$' devtrash/release_tests/current.list
while IFS= read -r t; do [ -x "devtrash/release_tests/$t" ]; done < devtrash/release_tests/current.list
printf '%s\n' \
  'TEST_OBSERVER_PRODUCTION_BACKEDGE=0' \
  'CURRENT_RELEASE_TEST_AUTHORITY=PASS' \
  'WHEELCHAIR_TEST_CLOSURE_1_3_92=PASS'
