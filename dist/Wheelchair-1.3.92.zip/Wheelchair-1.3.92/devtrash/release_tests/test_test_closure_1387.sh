#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
[ "$(cat VERSION)" = "1.3.87" ]
[ -x test.sh ]
[ -x devtrash/coverage/run_native_coverage.sh ]
! grep -RqsE 'native_coverage|WHEELCHAIR_COVERAGE|coverage-real' compiler runtime surface tools build.sh
[ "$(grep -c '^test_.*\.sh$' devtrash/release_tests/current.list)" -eq 18 ]
[ "$(sort devtrash/release_tests/current.list | uniq -d | wc -l)" -eq 0 ]
grep -q '^test_mathematical_physical_convergence_1381.sh$' devtrash/release_tests/current.list
grep -q '^test_coordinatefact_aging_1382.sh$' devtrash/release_tests/current.list
grep -q '^test_mutable_statefact_1383.sh$' devtrash/release_tests/current.list
grep -q '^test_silicon_domain_identity_1386.sh$' devtrash/release_tests/current.list
grep -q '^test_silicon_static_placement_1387.sh$' devtrash/release_tests/current.list
grep -q '^test_test_closure_1387.sh$' devtrash/release_tests/current.list
! grep -q '^test_test_closure_1386.sh$' devtrash/release_tests/current.list
! grep -q '^test_silicon_domain_graph_1385.sh$' devtrash/release_tests/current.list
! grep -q '^test_test_closure_1385.sh$' devtrash/release_tests/current.list
while IFS= read -r t; do [ -x "devtrash/release_tests/$t" ]; done < devtrash/release_tests/current.list
printf '%s\n' \
  'TEST_OBSERVER_PRODUCTION_BACKEDGE=0' \
  'CURRENT_RELEASE_TEST_AUTHORITY=PASS' \
  'WHEELCHAIR_TEST_CLOSURE_1_3_87=PASS'
