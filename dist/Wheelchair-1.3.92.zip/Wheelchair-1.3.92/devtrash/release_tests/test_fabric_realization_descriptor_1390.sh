#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "fabric realization descriptor 1.3.90: $*" >&2; exit 1; }

./build.sh >/dev/null

grep -q '^.equ SR_FABRIC_REALIZATION_DESCRIPTOR,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_REALIZATION_DESCRIPTOR_VERSION,2$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_ACTIVATION_ABI_PRESENT,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_COMPLETION_CALLBACK_ABI,1$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_NATIVE_FALLBACK,0$' compiler/silicon_reality.inc
grep -q '^.equ SR_FABRIC_UNBRIDGED_EXECUTION_ALLOWED,0$' compiler/silicon_reality.inc
grep -q '^.equ PR_FABRIC_REALIZATION_DESCRIPTOR_FROM_PHYSICAL_DAG,1$' compiler/physical_reality.inc
grep -q '^.equ PR_FABRIC_DESCRIPTOR_SECOND_IR,0$' compiler/physical_reality.inc
grep -q '^.equ PR_FABRIC_NATIVE_FALLBACK,0$' compiler/physical_reality.inc
grep -q '^g_emit_fabric_realization_descriptors:$' compiler/general_frontend_x86_64.S
grep -q '^gr_fabric_descriptor_for_node:$' runtime/general_parallel_release_x86_64.S
grep -q 'fabric_descriptor\[N:48\]' build/general_parallel_release_offsets.json

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY'
import json,sys
D=json.load(open(sys.argv[1]))
assert D['format']=='wheelchair.silicon-reality/9'
assert D['fabric_realization_descriptor'] is True
assert D['fabric_realization_descriptor_version']==2
assert D['fabric_activation_abi_present'] is True
assert D['fabric_activation_bridge_present'] is False
assert D['fabric_native_fallback'] is False
assert D['unbridged_fabric_execution_allowed'] is False
PY

# Production: no fabric target facts, so descriptors are real but all tags stay x86.
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/prod" >/dev/null
[ "$("$T/prod" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail production

# Proof-only target facts exercise the same current compiler closure. No bridge is
# injected: the resulting mixed image must refuse execution rather than fall back
# to its retained x86 diagnostic bodies.
as --64 \
  --defsym FABRIC_TARGET_PRESENT=1 \
  --defsym FABRIC_LOGIC_UNITS=100000 \
  --defsym FABRIC_REGISTER_UNITS=200000 \
  --defsym FABRIC_DSP_UNITS=1000 \
  --defsym FABRIC_LOCAL_STORAGE_BYTES=67108864 \
  --defsym FABRIC_ROUTING_DOMAINS=4 \
  --defsym FABRIC_CLOCK_REGIONS=4 \
  --defsym FABRIC_COMPUTE_TICKS_NUM=1 \
  --defsym FABRIC_COMPUTE_TICKS_DEN=4 \
  --defsym FABRIC_ACTIVATION_TICKS=100 \
  --defsym FABRIC_TRANSPORT_FIXED_TICKS=20 \
  --defsym FABRIC_TRANSPORT_TICKS_PER_BYTE=1 \
  compiler/fabric_target_facts_x86_64.S -o "$T/facts.o"
ld -nostdlib -static -z noexecstack \
  build/topologyc_core.o build/silicon_domain_probe.o "$T/facts.o" \
  build/outward_materialization_profile.o build/tensor_frontend.o build/general_frontend.o \
  build/runtime_blob.o build/general_runtime_blob.o build/general_parallel_release_blob.o \
  build/surface_lowerer.o build/human_shell_feedback.o -o "$T/topologyc-proof"
"$T/topologyc-proof" devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/mixed" >/dev/null

python3 - "$T/prod" "$T/mixed" compiler/general_runtime_offsets.inc build/general_parallel_release_offsets.json <<'PY'
import json,re,struct,sys
inc=open(sys.argv[3]).read(); o=json.load(open(sys.argv[4])); O=o['offsets']
def eq(name):
 m=re.search(r'^\.equ\s+'+re.escape(name)+r',\s*(0x[0-9a-fA-F]+|[0-9]+)$',inc,re.M); assert m,name; return int(m.group(1),0)
def read(path):
 b=open(path,'rb').read(); tr=struct.unpack_from('<Q',b,eq('GENERAL_PROGRAM_TRAILER_FILE_OFFSET_OFF'))[0]; cr=struct.unpack_from('<Q',b,eq('GENERAL_PROGRAM_CODE_REL_OFFSET_OFF'))[0]; base=tr+cr
 N=struct.unpack_from('<I',b,base+O['gr_node_count'])[0]; E=struct.unpack_from('<I',b,base+O['gr_edge_count'])[0]; F=struct.unpack_from('<I',b,base+O['gr_fabric_region_count'])[0]
 m=base+o['template_size']; tags_off=m+16*N+16*E; tags=struct.unpack_from('<'+'I'*N,b,tags_off); d0=tags_off+4*N
 desc=[struct.unpack_from('<IIQQQQQ',b,d0+48*i) for i in range(N)]
 return N,E,F,tags,desc
P=read(sys.argv[1]); M=read(sys.argv[2])
assert P[0:2]==M[0:2]
assert P[2]==0 and all(t==1 for t in P[3]),P
assert M[2]==3 and M[3]==(2,2,1,2,1),M
for expected_id,d in enumerate(M[4]):
 rid,tag,work,traffic,completion,edges,version=d
 assert rid==expected_id
 assert tag==M[3][expected_id]
 assert work>0
 assert traffic>0
 assert completion==O['gr_publish_completion_external']
 assert edges>0
 assert version==2
print('FABRIC_DESCRIPTOR_BURN=PASS')
print('MIXED_DESCRIPTOR_TAGS='+','.join(map(str,M[3])))
print('FABRIC_REGION_COUNT='+str(M[2]))
PY

set +e
"$T/mixed" 7 >"$T/mixed.out" 2>"$T/mixed.err"
rc=$?
set -e
[ "$rc" -ne 0 ] || fail 'unbridged mixed image executed'
[ ! -s "$T/mixed.out" ] || fail 'unbridged mixed image produced semantic output'

! grep -RqsE '(@fpga|fpga[ _-]*kernel|hls[ _-]*kernel|runtime[ _-]*device[ _-]*(selector|scheduler)|fixed[ _-]*(pe|tile)|fabric[ _-]*workload[ _-]*matcher|fabric[ _-]*native[ _-]*fallback)' surface compiler runtime tools
printf '%s\n' \
  'FABRIC_REALIZATION_DESCRIPTOR=PASS' \
  'FABRIC_ACTIVATION_ABI=PASS' \
  'SHARED_COMPLETION_ENTRY=PASS' \
  'FABRIC_NATIVE_FALLBACK=0' \
  'UNBRIDGED_FABRIC_EXECUTION=0' \
  'SECOND_FABRIC_IR=0' \
  'WHEELCHAIR_FABRIC_REALIZATION_DESCRIPTOR_1_3_90=PASS'
