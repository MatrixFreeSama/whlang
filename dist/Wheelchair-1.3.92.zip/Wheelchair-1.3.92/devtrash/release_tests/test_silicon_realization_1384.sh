#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
cd "$ROOT"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
fail(){ echo "silicon-realization 1.3.84: $*" >&2; exit 1; }

./build.sh >/dev/null
echo 'SILICON_REALITY_BUILD=PASS'

SR=compiler/silicon_reality.inc
PR=compiler/physical_reality.inc
GF=compiler/groupfact.inc

for law in \
  SR_PHYSICAL_DAG_IS_REALIZATION_AUTHORITY,1 \
  SR_CAUSAL_DEPTH_IS_TIME_AUTHORITY,1 \
  SR_TRAFFIC_REGION_IS_SPACE_AUTHORITY,1 \
  SR_FACT_LIFETIME_IS_STORAGE_AUTHORITY,1 \
  SR_GROUPFACT_IS_MULTIPLICITY_AUTHORITY,1 \
  SR_TARGET_FACTS_MAY_CHANGE_SEMANTICS,0 \
  SR_FIXED_PROCESSING_ELEMENT_COUNT,0 \
  SR_FIXED_TILE_SIZE,0 \
  SR_FIXED_PIPELINE_STAGE_COUNT,0 \
  SR_OCCUPANCY_IS_OBJECTIVE,0 \
  SR_THEORETICAL_WORK_CONVERGENCE_IS_OBJECTIVE,1 \
  SR_RUNTIME_SILICON_ALLOCATOR,0 \
  SR_RUNTIME_IDLE_RESOURCE_QUERY,0 \
  SR_RUNTIME_RECIPIENT_SELECTION,0 \
  SR_RUNTIME_WORK_STEALING,0 \
  SR_RUNTIME_READY_QUEUE,0 \
  SR_PARALLEL_DSL_ROUTE,0 \
  SR_HLS_KERNEL_AUTHORITY,0 \
  SR_TARGET_SECOND_SEMANTIC_IR,0 \
  SR_VON_NEUMANN_ORDER_IS_SEMANTIC_AUTHORITY,0 \
  SR_RELINEARIZE_BEFORE_SPATIAL_REALIZATION,0 \
  SR_SPATIAL_REALIZATION_ALLOWED,1 \
  SR_ARBITRARY_TRANSISTOR_ADDRESSING,0; do
  k=${law%,*}; v=${law#*,}
  grep -q "^.equ $k,$v$" "$SR"
done

grep -q '^.equ PR_SILICON_REALITY_SINGLE_AUTHORITY,1$' "$PR"
grep -q '^.equ PR_CAUSAL_DEPTH_OWNS_REALIZATION_TIME,1$' "$PR"
grep -q '^.equ PR_TRAFFIC_REGION_OWNS_REALIZATION_SPACE,1$' "$PR"
grep -q '^.equ PR_FACT_LIFETIME_OWNS_REALIZATION_STORAGE,1$' "$PR"
grep -q '^.equ PR_GROUPFACT_OWNS_REALIZATION_MULTIPLICITY,1$' "$PR"
grep -q '^.equ PR_ISA_IS_ONE_REALIZATION_NOT_SEMANTIC_CEILING,1$' "$PR"
grep -q '^.equ PR_SPATIAL_TARGET_REQUIRES_RELINEARIZATION,0$' "$PR"
grep -q '^.equ PR_SILICON_SECOND_IR,0$' "$PR"
grep -q '^.equ PR_SILICON_PARALLEL_DSL_ROUTE,0$' "$PR"
grep -q '^.equ GF_PHYSICAL_DEPTH_IS_FINAL_REALIZATION_TIME_AXIS,1$' "$GF"
grep -q '^.equ GF_SPATIAL_REALIZATION_USES_SAME_FACT,1$' "$GF"
! grep -q '^.equ GF_PHYSICAL_DEPTH_IS_FINAL_ISA_TIME_AXIS,' "$GF"
! grep -q '^.equ PR_PHYSICAL_DAG_ISA_SCHEDULE_BURN,' "$PR"
! grep -q '^.equ PR_DOMAIN_\(GPR\|XMM\|YMM\|ZMM\|MASK\),' "$PR"
echo 'ISA_SEMANTIC_CEILING_REMOVED=PASS'

bin/topologyc --silicon-contract > "$T/contract.json"
python3 - "$T/contract.json" <<'PY'
import json,sys
p=sys.argv[1]
d=json.load(open(p))
assert d["format"]=="wheelchair.silicon-reality/1"
assert d["target_kind"]=="x86_64-isa"
assert d["semantic_authority"]=="physical_dag"
assert d["time_authority"]=="causal_depth"
assert d["space_authority"]=="traffic_region"
assert d["storage_authority"]=="fact_lifetime"
assert d["multiplicity_authority"]=="groupfact_target_carriers"
for k in ("von_neumann_order_authority","relinearize_before_spatial_realization",
          "runtime_silicon_allocator","runtime_idle_resource_query","runtime_ready_queue",
          "runtime_work_stealing","parallel_dsl_route","hardware_kernel_language",
          "fixed_processing_element_count","fixed_tile_size","occupancy_is_objective",
          "arbitrary_transistor_addressing"):
    assert d[k] is False,(k,d[k])
assert d["theoretical_work_convergence_is_objective"] is True
assert d["target_exposed_primitives_are_boundary"] is True
assert d["allowed_execution_contexts"] >= 1
assert d["cache_line_bytes"] >= 1
print("SILICON_CONTRACT_JSON=PASS")
PY

# x86 remains a zero-flip realization of the same facts.
F=devtrash/tests/field_1216
bin/fieldc "$F/mixed.json" -o "$T/field" >/dev/null
cp "$F/out_3x5x7.whfld" "$T/out.whfld"
[ "$("$T/field" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/out.whfld")" = 'checksum_f32_bits=0x47126d00' ] || fail field
cmp "$T/out.whfld" "$F/expected_mixed_3x5x7.whfld"
bin/wheelchairc devtrash/tests/general_parallel_126/branch_probe.wh -o "$T/general" >/dev/null
[ "$("$T/general" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ] || fail general
echo 'X86_REALIZATION_ZERO_FLIP=PASS'

# No new production source surface may introduce a target-named program graph,
# worker/task scheduler or hardware-kernel entry language.
! grep -RqsE 'silicon_(worker|task|ready_queue|work_steal|kernel_dispatch)|fpga_(worker|task|scheduler)|asic_(worker|task|scheduler)' compiler runtime surface tools
! grep -RqsE 'source_kernel_(route|selector)|hardware_kernel_(route|selector)|processing_element_count[[:space:]]*=[[:space:]][1-9]' compiler runtime surface tools
echo 'SILICON_RUNTIME_SCHEDULER=0'
echo 'SILICON_TARGET_SECOND_IR=0'
echo 'SILICON_PARALLEL_DSL_ROUTE=0'
echo 'WHEELCHAIR_SILICON_REALIZATION_1_3_84=PASS'
