#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
MODE=${1:-release}
LOG="$ROOT/RELEASE_TEST_LOG_1_3_92.txt"
TMP=${TMPDIR:-/tmp}/wheelchair_test_1392_$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP"

record() {
  label=$1
  shift
  out="$TMP/out"
  printf '[%s]\n' "$label" >> "$LOG"
  if "$@" > "$out" 2>&1; then
    cat "$out" >> "$LOG"
  else
    cat "$out" >> "$LOG"
    cat "$out" >&2
    printf 'FAILED=%s\n' "$label" >&2
    exit 1
  fi
  printf '\n' >> "$LOG"
}

run_release() {
  : > "$LOG"
  record build ./build.sh
  sha256sum \
    bin/fieldc bin/fieldc-native256 \
    bin/topologyc bin/topologyc-derived bin/topologyc-derived-native256 bin/topologyc-native256 \
    bin/wheelchairc bin/whexc > PRODUCTION_BIN_SHA256_1_3_92.txt
  while IFS= read -r test; do
    [ -n "$test" ] || continue
    record "$test" "devtrash/release_tests/$test"
  done < devtrash/release_tests/current.list
  printf '%s\n' \
    'CURRENT_RELEASE_TESTS=23/23' \
    'CURRENT_RELEASE_TEST_FAILURES=0' \
    'MATHEMATICAL_PHYSICAL_CONVERGENCE_1_3_81=PASS' \
    'COORDINATEFACT_AGING_1_3_82=PASS' \
    'MUTABLE_STATEFACT_1_3_83=PASS' \
    'SILICON_REALIZATION_1_3_84=PASS' \
    'SILICON_DOMAIN_GRAPH_1_3_85=PASS' \
    'SILICON_DOMAIN_IDENTITY_1_3_86=PASS' \
    'SILICON_STATIC_PLACEMENT_1_3_87=PASS' \
    'HETEROGENEOUS_PHYSICAL_EDGE_1_3_88=PASS' \
    'FABRIC_TARGET_FACTS_1_3_89=PASS' \
    'FABRIC_REALIZATION_DESCRIPTOR_1_3_90=PASS' \
    'FABRIC_ACTIVATION_FIELD_DATAPATH_1_3_91=PASS' \
    'EXECUTION_ADMISSION_EXPANSION_1_3_92=PASS' \
    'WHEELCHAIR_TEST_1_3_92=PASS' | tee -a "$LOG"
}

run_coverage() {
  sh devtrash/coverage/run_native_coverage.sh
}

case "$MODE" in
  release) run_release ;;
  coverage) run_coverage ;;
  all) run_release; run_coverage ;;
  *) printf 'usage: %s [release|coverage|all]\n' "$0" >&2; exit 64 ;;
esac
