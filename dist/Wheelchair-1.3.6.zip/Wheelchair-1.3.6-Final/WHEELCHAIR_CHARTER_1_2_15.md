# Wheelchair 1.2.15 Charter

## Rank-N Neighborhood Semantics Completion

1. A local-neighborhood access is a coordinate transformation, not a hidden loop.
2. Rank-N tuple indexing is lowered into the existing product-domain dataflow; it must not create a scalar tuple walker or central address server.
3. Dynamic periodic coordinates should reuse existing vector ring arithmetic whenever the transformation can be proved structurally.
4. Static and dynamic coordinate transforms may compose in one local operator without changing the parallel execution contract.
5. Persistent root-coordinate state belongs only to the root Cartesian episode. A transformed indexed-map axis must never silently inherit root induction state.
6. Coordinate proofs use the physical product-domain extent; user argument validation continues to use the logical source extent.
7. Unsupported coordinate forms reject explicitly. They must not fall back to a scalar evaluator.
8. No solver, FEM, stencil size, benchmark name, or workload identity may select a code path.
9. No JIT, LLVM, C backend, runtime timing selector, work stealing, global ready queue, peer-load query, or resource recipient is introduced.
10. Completion of one semantic intersection must not erase an older technical spike. 1.2.14 dense caretaker and irregular sparse authorities remain regression gates.

## Resource rule

Completion of an episode still means blind release of the resources owned by that episode. The releasing computation neither asks which peer needs the resources nor knows where the resources go next. Resource destination is outside the language-level dependency graph.

## No-shell rule

A feature counts as native only when the Wheelchair compiler proves and lowers it directly. Translating a difficult Rank-N access to C/LLVM/Python, flattening a benchmark by hand, silently widening unsupported numeric types, or attaching a workload-specific helper does not count as implementation.
