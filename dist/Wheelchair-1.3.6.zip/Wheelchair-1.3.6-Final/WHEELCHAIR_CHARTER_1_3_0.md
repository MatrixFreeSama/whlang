# Wheelchair 1.3.0 Physical Realization Charter

Wheelchair 1.3.0 treats computation as structure until the last machine-specific realization step.

## Red lines

1. Parallel semantics may not be serialized for emitter convenience.
2. Every serialization edge must have a mathematical, semantic, physical, ABI, or target-ISA justification.
3. No global ready queue, work stealing, peer polling, destination-aware resource handoff, or post-completion work search may be introduced.
4. Recipient-blind causal release remains authoritative: a completed region publishes only its own true successor dependencies and exits.
5. C, GCC, LLVM, MLIR, JIT, Python, or a bytecode VM may not become a production backend layer.
6. Text assembly is an audit representation, not the semantic authority. The compiler selects and encodes target ISA operations directly.
7. A scheduler decision must either change or validate the realized machine episode. Decorative scheduling metadata is forbidden.
8. Strict numerical ordering remains strict. Performance work may not silently reassociate strict floating-point reductions.
9. Unsupported physical realization rejects instead of falling back to a scalar or serial semantic substitute.
10. The language-level amount of logical parallelism is not defined by the current implementation ceiling.

## Physical DAG

The compiler preserves semantic, Rank-N, field, tensor, and causal structure into a transient Physical DAG immediately before target realization. The Physical DAG records true dependencies and physical constraints rather than defining a conventional sequential instruction IR.

The Tensor backend uses a two-pass native realization. Pass 0 is disposable and exists only to expose the exact resource structure of the native episode. The silicon/resource scheduler runs on that structure before the canonical pass. Pass 1 restores the plan and is the only pass permitted to emit the final machine image.

The Field backend constructs a compile-time physical plan before final ISA emission. It validates register def-use dependencies, integer-coordinate carriers, stores/reductions, and memory barriers, and final codegen consumes the explicit planned order.

## Automatic Rank-N execution tensorization

Automatic tensorization is not defined as a matrix-multiply recognizer. Wheelchair may promote structurally homogeneous scalar, SIMD, affine, neighborhood, field, or other independent subgraphs into a Rank-N execution episode.

The current general Tensor episode is the whole fused Rank-N chunk. The episode owns its vector loop, address carriers, constants, boundary-specialized regions, reduction state, and target ISA realization as one compilation object. This is deliberately different from compiling one scalar operation at a time and trying to recover parallelism later.

Wheelchair does not invent a nonexistent universal x86 tensor instruction. When the target ISA has a directly suitable primitive, semantic ISA selection may cover the structure directly. Otherwise the whole episode is still planned together and encoded as the appropriate native instruction graph.

## Semantic ISA override

Wheelchair semantics outrank generic lowering convenience. If a generic lowering recipe cannot preserve a semantic operation or its parallel structure, the backend may select a target-specific ISA recipe directly. Existing examples include direct EVEX/FMA and synthesized semantic-equivalent vector recipes selected by capability, not by workload identity.

## Executor geometry

The 1.3.0 resident executor implementation ceiling is 256. This is not a language-semantic upper bound and does not mean that every invocation creates 256 OS tasks.

The requested executor count is clamped to the amount of reachable work before worker creation. The default executor geometry is derived from the process affinity set and capped at 256. General causal execution is additionally bounded by the number of materialized causal regions. Empty executor leaves are erased.

## Execution purity

Optimization targets non-essential machine work rather than source-code appearance. The backend should minimize avoidable loop control, branches, address regeneration, redundant memory traffic, synchronization, artificial dependency chains, and runtime coordination while retaining all necessary semantics.

Necessary serialization is allowed. Artificial serialization is a defect.
