# Wheelchair 1.3.6 Pure-Assembly Release Proof

Wheelchair 1.3.6 keeps the production compiler/runtime path in handwritten x86-64 assembly with shell build/release gates. User programs remain AOT direct-native.

New production logic is in assembly:

- `ff_build_global_physical_reality_136` and its fact intern/touch helpers;
- canonical AddressFact owner/mapping tables;
- per-field version and write-proof tables;
- generic exact-bit constant-to-pool mapping;
- AVX2/AVX-512 physical-window realization;
- EVEX high-register, AddressFact load, direct-memory FMA and direct-store encoders.

`compiler/physical_reality_136.inc` contains constants only and emits no runtime manager.

The release tree contains no Python source. `build.sh` does not invoke Python, GCC, Clang, LLVM or a JIT. Release tests disassemble generated AVX2/AVX-512 code, run strict/tolerant numerical oracles, test duplicate-address canonicalization, test mutable-version invalidation, exercise a four-output semantic supernode and run the complete historical 1.3.5 release authority.
