# Wheelchair 1.3.0 Pure Assembly / Direct Native Release Proof

The production build is still rooted in handwritten x86-64 assembly and shell-only native offset derivation.

`build.sh` invokes GNU `as`, `ld`, `objcopy`, `nm`, `awk`, and release shell tools. It does not invoke Python, C, C++, LLVM, MLIR, or a JIT compiler. The release tree contains no Python source files.

Generated Wheelchair executables are static native ELF images. Tensor and Field code is directly encoded into the emitted image by the handwritten backend. Text assembly is not generated as an intermediate user-program backend.

1.3.0 adds compiler-only Physical-DAG planning. Tensor scheduling occurs before the canonical machine image is emitted. Field codegen consumes a compiler-time physical plan. No new runtime scheduler, bytecode interpreter, or wrapper language was introduced.

The release gate also corrupts the Tensor `unroll` physical-plan field in a generated executable and requires launch rejection. This proves that the plan is consumed as part of the machine execution contract instead of existing only as metadata.
