# Wheelchair 1.2.16 Native Field ABI

`WHFLD216` is Wheelchair's native materialized-field binary interface. It is a storage/launch contract, not an object system and not a C pointer ABI.

All integers are little-endian. The fixed header is 256 bytes.

| Offset | Size | Meaning |
|---:|---:|---|
| 0 | 8 | ASCII magic `WHFLD216` |
| 8 | 4 | ABI version, currently `1` |
| 12 | 4 | element type, `1 = f32` |
| 16 | 4 | logical rank, `1..8` |
| 20 | 4 | flags, reserved |
| 24 | 8 | byte offset of first field datum |
| 32 | 64 | eight u64 logical extents |
| 96 | 64 | eight u64 physical byte strides |
| 160 | 8 | logical element count |
| 168 | 88 | reserved, zero in release fixtures |

The file may contain padding between logical elements. Extents describe logical shape; strides describe physical placement. All fields in one compiled invocation must have the same logical rank/extents, but their physical strides may differ.

Launch validation checks magic, version, type, rank, extents, logical count, mapped span and shape compatibility. Distinct field declarations must refer to distinct `(st_dev, st_ino)` objects. Read/write aliasing uses one `inout` declaration.

The descriptor is launch-time metadata. The SIMD hot path operates on collapsed base/extent/stride tables and does not perform per-element descriptor walking.
