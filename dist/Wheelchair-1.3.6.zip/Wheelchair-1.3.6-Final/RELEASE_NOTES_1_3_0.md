# Wheelchair 1.3.0 Release Notes

## Release theme

Wheelchair 1.3.0 moves structure preservation through the final compiler stages. Earlier releases protected WH/WHEX parallel and Rank-N semantics from being flattened by conventional external backends. 1.3.0 extends the same rule to Wheelchair's own physical lowering.

## Physical-DAG realization

Tensor compilation now has a pre-canonical physical planning pass. The first native lowering is disposable and is used only to derive exact resource counts and the physical capability plan. The silicon scheduler runs before the canonical machine image is emitted. A second lowering then produces the final direct-native ISA bytes under that plan.

The old post-codegen behavior that overwrote scheduler results with fixed `unroll=1` and claimed four independent reduction carriers has been removed. The current fused episode truthfully advertises one architectural reduction chain and one body instance. Runtime validates these plan fields before creating workers, making the plan an executable contract rather than decorative metadata.

Field compilation now builds a transient physical dependency plan before final ISA emission. Final codegen consumes an explicit physical order and validates floating-register and integer-coordinate def-use structure plus store/reduction barriers.

## Automatic Rank-N execution tensorization

The tensorization unit is no longer described as one isolated vector operation. A complete fused Rank-N chunk is treated as one execution tensor episode. The episode contains its SIMD body, affine induction carriers, boundary-specialized vector regions, constants, reduction residency, and native ISA realization.

This is a general execution concept rather than an ML-only matrix contraction feature. It applies to structural Rank-N work and does not require a universal hardware tensor instruction. Target-specific ISA primitives are used directly when they match the semantics.

## Semantic ISA override

Direct machine encoding remains authoritative. Semantic operations may select native or synthesized ISA recipes from target capabilities without passing through C, LLVM, MLIR, JIT, or a textual-assembly backend pipeline.

The production chain remains handwritten x86-64 assembly compiler/runtime code and static AOT ELF output.

## 256-executor geometry

The resident executor implementation ceiling has been raised from 4 to 256 in Tensor, Field, topology compilation, and the blind-release general runtime envelope.

The default executor count now follows the process affinity set, capped at 256. Requested executor counts are clamped to reachable chunks before worker creation, so a tiny problem compiled with `--executors 256` does not create 255 empty execution leaves.

The general blind-release runtime has 256 causal-node capacity. It still creates work from true causal regions only and does not introduce a global scheduler.

`--executors 0` and `--executors 257` are explicit errors.

## General causal dependency capacity

The general physicalizer now has 256 fragment slots and four 64-bit dependency bands, so dependency representation no longer silently wraps above the old two-band range. The blind-release runtime data layout and frozen offset proof were regenerated for the 256-node capacity.

## Preserved red lines

- no work stealing;
- no global ready queue;
- no central runtime scheduler;
- no post-completion peer query;
- no destination-aware resource handoff;
- no scalar fallback for protected Tensor/Field semantics;
- no C/LLVM/MLIR/JIT backend;
- no Python in the production build or release sources;
- strict floating-point ordering remains protected where required.

## Compatibility

The WH/WHEX human Field surface from 1.2.18 remains supported. The canonical field format stays `wheelchair.field/1` and the materialized-field ABI remains `WHFLD216`.

Historical machine-image SHA identities from 1.2.13 and 1.2.14 are intentionally not release invariants for 1.3.0 because the runtime layout and physical backend changed. Historical semantic and ABI regression gates remain authoritative.
