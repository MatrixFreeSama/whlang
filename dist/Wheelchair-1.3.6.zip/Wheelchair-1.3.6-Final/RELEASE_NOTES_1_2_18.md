# Wheelchair 1.2.18 Release Notes

## WH/WHEX Native Materialized-Field Surface Completion

Wheelchair 1.2.18 closes the human-source gap left by 1.2.16 and 1.2.17. The native materialized-field backend, `WHFLD216` storage ABI, 1.2.17 locality optimizer, AVX2/AVX-512 physicalizations and recipient-blind parallel runtime are unchanged. The new work is a compile-time surface bridge that lets normal WH/WHEX source express the same field semantics that previously required hand-written `wheelchair.field/1` canonical JSON.

### Added

- `input field`, `output field` and `inout field` in the native WH/WHEX surface.
- multiple independent runtime shape symbols and Rank-N logical axes;
- per-axis `periodic` boundary contracts and explicit `periodic(expr, extent)` spelling;
- WH structural `for` as a data-domain shell that erases before field code generation;
- WHEX `region ... effect pure parallel` field assignments;
- WHEX materialized-field `sum` reductions;
- UTF-8 field identifiers;
- compile-time `pure fn` expansion in materialized-field expressions;
- exact lexical scope for pure-function parameters, including one-character names, with local identity taking precedence over optional one-edit typo repair;
- human-facing rejection for unproved boundary access and unsupported surface contracts.

### Zero-cost surface authority

The release suite compiles equivalent canonical JSON, WHEX and WH sources and requires byte-for-byte identical native ELF output. The human surface is therefore not a wrapper runtime and does not insert a second field backend.

Validated equivalence includes:

- direct WHEX output expression;
- WHEX region form;
- WH fake-for form;
- explicit `periodic(...)` form;
- input/output/inout fields;
- materialized-field sum;
- multi-field neighborhood arithmetic;
- Rank-4 component fields;
- UTF-8 names;
- short-name and long-name pure-function parameters.

### Pure-function lexical-scope fix

Before release closure, a one-character pure-function parameter could be considered by the human-shell one-edit spelling repair before the function's lexical binding was established. 1.2.18 installs the parameter as a temporary compile-time lexical binding while parsing the function body. It is substituted away during pure-function expansion and never becomes a runtime object.

The following forms now produce byte-identical native code:

```text
pure fn twice(v: f32) -> f32 = v * 2.0
pure fn twice(value_param: f32) -> f32 = value_param * 2.0
out[...] = a[...] * 2.0
```

### Deliberate boundary: no fake static component contract

`WHFLD216` stores runtime rank/extents/strides but has no descriptor field that can prove a source axis such as `c in 3` must equal three at launch. 1.2.18 therefore does not pretend that numeric surface extent is a checked materialized-field contract. Human materialized fields use real runtime shape symbols such as `c in nc`. Numeric static component contracts remain rejected until a real ABI/semantic contract exists.

### Preserved

- `WHFLD216` binary layout;
- `wheelchair.field/1` canonical semantics and compatibility;
- 1.2.17 load-identity algebra, coordinate CSE, dynamic power-of-two strength reduction and reuse-weighted residency;
- strict floating-point order;
- arbitrary non-power-of-two dynamic shapes;
- padded/strided input gather and AVX-512 scatter;
- AVX2 explicit rejection of unsupported non-contiguous output;
- exact constant integer div/mod;
- noalias/inout contracts;
- 1.2.15 Rank-N neighborhood semantics;
- 1.2.14 native performance authorities;
- recipient-blind resource release with no work stealing or global ready queue.

### Production architecture

```text
WH / WHEX human source
        |
        v
compile-time Field surface lowering
        |
        v
wheelchair.field/1 canonical graph
        |
        v
1.2.17 structural locality optimizer
        |
        v
AVX2 / AVX-512 direct AOT machine code
```

The canonical graph remains accepted as a compatibility/debug input, but users no longer need to write it for the supported materialized-field surface.
