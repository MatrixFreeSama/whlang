# Wheelchair 1.2.16 Release Notes

## Native Field ABI and Numeric Rank-N Completion

1.2.16 extends the 1.2.15 Rank-N neighborhood model into real materialized f32 simulation data.

### Added

- `wheelchair.field/1` canonical semantics and sovereign `fieldc` AOT compiler.
- `fieldc-native256` true AVX2/YMM physicalization.
- `WHFLD216` native materialized-field ABI.
- Rank 1..8 runtime field descriptors with independent dynamic extents and arbitrary validated physical byte strides.
- Native f32 arithmetic without hidden f64 widening.
- 16-lane AVX-512 and 8-lane AVX2 f32 execution.
- Padded/strided input gather.
- AVX-512 non-contiguous output scatter.
- Explicit AVX2 rejection of non-contiguous output rather than scalar lane stores.
- Input/output/inout field modes and inode-backed noalias validation.
- Multi-field periodic local operators.
- Two u31 vector index carriers with constant add/sub/mul/div/mod and f32 conversion.
- Exact correction after SIMD quotient estimation for general constant integer div/mod.
- Structural `whexc` routing of canonical field semantics to `fieldc`.
- A full 8-node hexahedral linear-elasticity integration probe with three displacement components, lambda/mu material fields, 97 distinct neighborhood accesses and all three output components. Both 512- and 256-bit paths match strict-f32 pointwise oracle fields.

### Correctness fixes found during development

Two AOT expression-register ABI errors were found by a combined multi-field test and fixed before release: byte emission had overwritten the requested destination register, and logical `v0` originally collided with the helper return register. Logical f32 registers now occupy physical SIMD registers 1..3 while register 0 is helper scratch/return.

AVX-512 gather/scatter was also found to consume its writemask. The runtime now restores the sovereign active-lane mask before returning from these helpers, preventing a gather/store followed by reduction from silently reducing zero lanes.

### Preserved

The 1.2.15 f64 tensor physicalizers remain separate and continue through their historical paths. 1.2.14 dense/irregular, native256 and blind-release authorities remain mandatory release gates.

### Deliberate hardware boundary

AVX2 does not provide architectural scatter. A strided output in `fieldc-native256` therefore exits with the explicit unsupported-runtime code instead of executing a hidden scalar store loop. AVX-512 supports the same case through `vscatterdps`.
