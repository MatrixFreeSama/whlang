# Wheelchair 1.3.4 Physical Regularity Diagnostic

Host observed during this release audit: Intel Xeon Platinum 8272CL under KVM, 5 visible vCPUs, one NUMA node. The comparison below pins CPU0 and uses identical 1.3.3/1.3.4 process boundaries.

## 64^3 Rank-N neighborhood, tolerant, one executor

Nine interleaved measurements after two warmups per contestant:

- 1.3.3 median: 97.985496 ms
- 1.3.4 median: 65.420444 ms
- median ratio: 1.49778x

Generated native256 arithmetic audit:

```text
1.3.3: gather fallback sites 97, FMA 576, MUL 1152, ADD 580
1.3.4: regular direct-load sites 97, gather fallback sites 97,
       FMA 1152, MUL 576, ADD 4
```

The gather sites remaining in the 1.3.4 image belong to the general boundary/irregular fallback. The regular preload block is separately source-audited to contain no gather route.

The numbers are diagnostic for this host and corpus. They are not a claim of a universal 1.50x language-wide speedup.
