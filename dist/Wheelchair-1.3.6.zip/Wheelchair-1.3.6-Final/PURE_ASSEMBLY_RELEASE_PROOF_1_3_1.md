# Wheelchair 1.3.1 Direct-Native Release Proof

The 1.3.1 production build remains shell orchestration plus handwritten/native assembly sources. The release contains no Python source and the production build does not invoke Python, GCC, Clang, LLVM, MLIR or a JIT backend.

Release gates verify that compiler binaries, runtime templates and generated user images have no dynamic section. User Tensor/Field/General programs are emitted as static native ELF images.

The new Physical Realization gate additionally inspects generated raw machine payloads with disassembly and proves that tolerant Tensor images contain two genuine independent recurrence carriers while strict images do not fabricate the second recurrence. Fixed-Rank Field address routines are disassembled to verify the absence of the generic runtime axis counter.

The scheduler/execution contract is also destructive-tested: each of planned carriers, planned episode width, realized carriers and realized episode width is corrupted independently and the runtime must reject before worker creation.
