# Wheelchair 1.2.17 Pure Assembly Release Proof

Wheelchair 1.2.17 preserves the direct-native production closure of 1.2.16. The production compiler and runtime physicalizers are handwritten x86-64 assembly plus static data/templates. `build.sh` uses shell utilities and GNU binutils (`as`, `ld`, `nm`, `objdump`, `readelf`, `objcopy`, `cmp`, `grep`, `sha256sum`) and does not invoke Python, C, LLVM, MLIR, or a JIT.

The optimized field path remains:

```text
wheelchair.field/1
    -> fieldc handwritten assembly frontend
    -> compile-time field/coordinate identity analysis
    -> AOT locality compression
    -> direct AVX2/AVX-512 machine-code emission
    -> static ELF
```

1.2.17 adds no runtime bytecode interpreter, ready queue, central scheduler, work stealing, workload-name dispatch, or scalar recovery path. Load identity analysis, neighborhood-coordinate CSE, dynamic power-of-two shape proof, reuse-weighted residency, and field-version safety are AOT compiler responsibilities. The generated fast path performs direct native gathers after launch-time layout proof; heterogeneous layouts retain the existing general native field path rather than a scalar fallback.

The `WHFLD216` field ABI and `wheelchair.field/1` canonical source format remain unchanged. Existing 1.2.14, 1.2.15, and 1.2.16 authority gates are rerun by `test_release_native_1217.sh`.

The release machine-code autopsy for the full Hex8 locality pressure fixture proves the structural compression itself rather than relying on source-level markers:

```text
logical field loads            = 2304
unique immutable load identities = 97
unique neighborhood coordinates  = 27
fast-path direct gathers         = 97
```

The release is rejected if the optimized field compiler/runtime contains benchmark-specific dispatch, fixed-shape routing, hidden scalar field fallback, work stealing, or a C/LLVM/JIT production backend.
