#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair135_uniqueness_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

./build.sh > "$T/build.log" 2>&1
for m in \
 PHYSICAL_REALIZATION_UNIQUENESS=BUILT \
 PHYSICAL_FACT_IDENTITY=BUILT \
 PHYSICAL_FACT_REUSE_PROFITABILITY=BUILT \
 DEMAND_CAUSAL_MATERIALIZATION=BUILT \
 CROSS_CONSUMER_FACT_SHARING=BUILT \
 IMMUTABLE_CONSTANT_IDENTITY=BUILT \
 HOT_CONSTANT_REGISTER_RESIDENCY=native256 \
 DIRECT_MATERIAL_MEMORY_OPERAND=native256 \
 ADDRESS_FACT_UNIQUENESS=BUILT \
 AVX2_FULL_YMM_BANK=BUILT \
 STRICT_FP_REASSOCIATION=0 \
 MEMORY_PROFITABILITY_1_3_3_PRESERVED=PASS \
 PHYSICAL_REGULARITY_1_3_4_PRESERVED=PASS \
 RUNTIME_RESIDENCY_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 BENCHMARK_RESIDENCY_DISPATCH=0 \
 WORK_STEALING=0 \
 WHEELCHAIR_1_3_5_BUILD=PASS
do grep -q "$m" "$T/build.log"; done
echo 'PHYSICAL_REALIZATION_UNIQUENESS_BUILD_AUTHORITY=PASS'

J=tests/field_1216/fem_hex8_full_tolerant_133.json
JS=tests/field_1216/fem_hex8_full.json
F=tests/field_1216
E=tests/field_135

# Tolerant exact release oracle on both ISA paths. The oracle was independently
# bounded against the historical strict result before it entered the tree.
for C in fieldc-native256 fieldc; do
  build/$C "$J" -o "$T/$C-tol" --executors 1 >/dev/null
  for i in 0 1 2; do cp "$F/fem_out${i}_3x5x7.whfld" "$T/$C-o$i.whfld"; done
  "$T/$C-tol" \
    "$F/fem_lambda_3x5x7.whfld" "$F/fem_mu_3x5x7.whfld" \
    "$F/fem_p0_3x5x7.whfld" "$F/fem_p1_3x5x7.whfld" "$F/fem_p2_3x5x7.whfld" \
    "$T/$C-o0.whfld" "$T/$C-o1.whfld" "$T/$C-o2.whfld" >/dev/null
  for i in 0 1 2; do cmp "$T/$C-o$i.whfld" "$E/tolerant_expected_o${i}_3x5x7.whfld"; done
done
echo 'TOLERANT_PHYSICAL_FACT_NUMERICAL_ORACLE=PASS'
echo 'AVX512_CONSERVATIVE_AUTHORITY=PASS'

# Strict remains the exact historical arithmetic contract.
for C in fieldc-native256 fieldc; do
  build/$C "$JS" -o "$T/$C-strict" --executors 1 >/dev/null
  for i in 0 1 2; do cp "$F/fem_out${i}_3x5x7.whfld" "$T/$C-strict-o$i.whfld"; done
  "$T/$C-strict" \
    "$F/fem_lambda_3x5x7.whfld" "$F/fem_mu_3x5x7.whfld" \
    "$F/fem_p0_3x5x7.whfld" "$F/fem_p1_3x5x7.whfld" "$F/fem_p2_3x5x7.whfld" \
    "$T/$C-strict-o0.whfld" "$T/$C-strict-o1.whfld" "$T/$C-strict-o2.whfld" >/dev/null
  for i in 0 1 2; do cmp "$T/$C-strict-o$i.whfld" "$F/fem_expected_out${i}_3x5x7.whfld"; done
done
echo 'STRICT_FP_HISTORICAL_BITS=PASS'

# Generated native256 machine authority.
build/fieldc-native256 "$J" -o "$T/tol256" --executors 1 >/dev/null
build/fieldc-native256 "$JS" -o "$T/strict256" --executors 1 >/dev/null
dd if="$T/tol256" of="$T/tol256.bin" bs=1 skip=$((0x8000)) status=none
dd if="$T/strict256" of="$T/strict256.bin" bs=1 skip=$((0x8000)) status=none
objdump -D -b binary -m i386:x86-64 -Mintel "$T/tol256.bin" > "$T/tol256.S" 2>/dev/null
objdump -D -b binary -m i386:x86-64 -Mintel "$T/strict256.bin" > "$T/strict256.S" 2>/dev/null

if grep -qi 'zmm' "$T/tol256.S"; then echo 'NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1; fi
high=$(grep -Eci 'ymm(8|9|1[0-5])' "$T/tol256.S" || true)
memfma=$(grep -Eci 'vfmadd[^[:cntrl:]]*YMMWORD PTR \[rsp' "$T/tol256.S" || true)
tfma=$(grep -ci 'vfmadd' "$T/tol256.S" || true)
tmul=$(grep -ci 'vmulps' "$T/tol256.S" || true)
sfma=$(grep -ci 'vfmadd' "$T/strict256.S" || true)
[ "$high" -ge 100 ]
[ "$memfma" -ge 100 ]
[ "$tfma" -ge 1500 ]
[ "$tmul" -lt 400 ]
[ "$sfma" -eq 0 ]
echo "NATIVE256_HIGH_YMM_REFERENCES=$high"
echo "DIRECT_MATERIAL_MEMORY_FMA_SITES=$memfma"
echo "TOLERANT_FMA_SITES=$tfma"
echo "TOLERANT_MUL_SITES=$tmul"
echo 'AVX2_HIGH_REGISTER_ENCODING=PASS'
echo 'AVX2_FULL_YMM_BANK_AVAILABLE=PASS'
echo 'DIRECT_MATERIAL_MEMORY_OPERAND=PASS'
echo 'STRICT_FP_REASSOCIATION=0'
echo 'NATIVE256_ZMM=0'

# Source-structural authority. Exact coefficient identity is based only on
# ordered access IDs and exact f32 bit identities. First-consumer realization
# and the inherited NT policy guard must both physically exist.
grep -q '^ff_build_physical_facts_135:' compiler/field_frontend_common_x86_64.S
grep -q 'ff_wide_term_access' compiler/field_frontend_common_x86_64.S
grep -q 'ff_wide_term_const' compiler/field_frontend_common_x86_64.S
grep -q 'saved coefficient FMAs' compiler/field_frontend_common_x86_64.S
grep -q 'First causal consumer: realize once, consume immediately' compiler/field_frontend_common_x86_64.S
grep -q '^ff_emit_addr_pool_init:' compiler/field_frontend_common_x86_64.S
grep -q 'FIELD_RUNTIME_NT_ACTIVE_VA' compiler/field_frontend_common_x86_64.S
grep -q 'FIELD_RUNTIME_NT_ACTIVE_VA' tools/generate_field_runtime_offsets.sh
echo 'PHYSICAL_FACT_IDENTITY=PASS'
echo 'EXACT_CONSTANT_BIT_IDENTITY=PASS'
echo 'PHYSICAL_FACT_REUSE_PROFITABILITY=PASS'
echo 'DEMAND_CAUSAL_MATERIALIZATION=PASS'
echo 'ADDRESS_FACT_UNIQUENESS=PASS'
echo 'MEMORY_PROFITABILITY_NT_GUARD=PASS'

# Existing irregular/padded authority remains truthful.
build/fieldc-native256 tests/field_1216/mixed.json -o "$T/mixed" --executors 4 >/dev/null
cp tests/field_1216/out_3x5x7.whfld "$T/mixed-out.whfld"
[ "$("$T/mixed" tests/field_1216/a_3x5x7.whfld tests/field_1216/bpad_3x5x7.whfld "$T/mixed-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
cmp "$T/mixed-out.whfld" tests/field_1216/expected_mixed_3x5x7.whfld
echo 'IRREGULAR_GATHER_PRESERVED=PASS'

if grep -RniE 'Taichi|SPGrid|compute_Ap|elasticity|fem_hex8|benchmark[_ -]*mode' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
if grep -RniE 'runtime[ _-]*residency[ _-]*manager|runtime[ _-]*autotun|work[ _-]*steal|global[ _-]*ready[ _-]*queue' \
  compiler runtime | grep -v -E 'No |no |RUNTIME_|WORK_STEALING|runtime autotun|comment|Red line' >/dev/null 2>&1; then
  echo 'FORBIDDEN_RUNTIME_COORDINATION=FAIL' >&2; exit 1
fi
echo 'NO_BENCHMARK_RESIDENCY=PASS'
echo 'NO_RUNTIME_RESIDENCY_MANAGER=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'NO_REPEATED_PHYSICAL_REALIZATION_AUTHORITY=PASS'
echo 'WHEELCHAIR_PHYSICAL_REALIZATION_UNIQUENESS_1_3_5=PASS'
