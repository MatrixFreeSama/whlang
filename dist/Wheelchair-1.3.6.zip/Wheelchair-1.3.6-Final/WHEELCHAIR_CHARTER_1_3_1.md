# Wheelchair 1.3.1 Physical Realization Completion Charter

Wheelchair 1.3.1 completes the physical realization of the structure-preserving backend introduced in 1.3.0.

## Governing invariant

Every parallel relation preserved by the Physical DAG must, wherever mathematically, semantically, ABI-wise and physically legal, survive as independent machine-level dependency chains, register carriers, address episodes or ISA subgraphs. Emitter order, loop-template convenience and opportunistic register reuse are not valid reasons to invent serialization.

## Red lines

1. True data, memory-alias, strict floating-point, ISA, register-capacity and finite-resource dependencies are valid serialization reasons. Emitter order is not.
2. Tensorization is successful only when it changes the realized machine graph. Metadata-only tensorization is a failed realization.
3. SIMD lane parallelism, independent recurrence-carrier parallelism, Tensor-episode parallelism and executor parallelism are separate concepts.
4. Strict floating-point reductions may use a multi-body episode while retaining one recurrence carrier. Tolerant reductions may use multiple independent carriers and balanced merging when legal.
5. Runtime convenience may not introduce a work queue, work stealing, peer polling, a global ready queue or destination-aware resource handoff.
6. Fixed Rank known at AOT time must not pay a runtime axis-loop tax in the Field hot path.
7. A scheduler plan is an executable contract. Planned carrier count, planned episode width, realized carrier count and realized episode width are independent facts and must agree with the machine image.
8. Unsupported physical realization rejects or legally narrows; it does not fabricate parallelism or silently change strict numerical semantics.
9. Production remains AOT, direct-native and independent of C/GCC/LLVM/MLIR/JIT/Python backends.
10. The resident executor implementation ceiling remains 256. 1.3.1 improves physical width inside an executor rather than increasing that ceiling.

## Physical Tensor realization

The generic AVX-512 backend can realize a two-body Tensor episode with two independent tolerant reduction recurrences in YMM/ZMM12 and YMM/ZMM13. The native AVX2 backend can realize the corresponding pair in YMM12 and YMM11. The carriers merge only at the terminal reduction.

Strict reduction is physically distinct: it may still use a two-body episode for control compression while both bodies feed the single ordered recurrence carrier. This preserves bit identity instead of exchanging strict semantics for a benchmark number.

Carrier count and episode width are selected and validated independently. Register pressure may legally narrow carrier count when the second architectural recurrence register is not genuinely free.

## Field Physical DAG

Field final emission consumes a dependency-depth physical order built from actual RAW, WAR, WAW, memory-version and strict-reduction constraints. No emitter-order dependency is inserted merely because the old source list was sequential.

A hidden AVX2 reduction scratch clobber discovered by this reordering was removed by moving scratch ownership to an ABI-free register instead of forcing the Physical DAG to preserve the accidental old order.

For fixed Field Rank 1 through 8, the address realization is AOT-expanded. The generic runtime axis loop remains only for genuinely dynamic-rank ABI fallback.

## Execution purity

The hot remaining-count update no longer emits a redundant `CMP` followed by `SUB`. The `SUB` itself updates the remaining count and provides the completion condition for the following unsigned branch. This removes one non-problem instruction per vector advance without changing the mathematical work.

Execution purity is subordinate to correctness. A larger episode or carrier bank is not an improvement if it creates spills, breaks locality or changes strict numerical order.

## Machine fidelity audit

The 1.3.1 release gate reconstructs evidence directly from generated machine payloads. It requires real independent recurrence instructions, verifies that strict images do not contain the tolerant second recurrence, verifies fixed-Rank Field address code has no runtime axis counter, and corrupts each of the four plan/realization fields independently to ensure launch rejection.

The criterion is therefore not “the compiler says it tensorized.” The criterion is “the generated machine graph proves that it did.”
