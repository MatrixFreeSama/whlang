# Wheelchair 1.2.16 Charter

1. **General semantics before benchmark patches.** The field lane is defined by rank, type, shape, stride, neighborhood relation, arithmetic and ISA capability. Solver names and benchmark names are not code-generation inputs.
2. **Direct native authority.** Field programs compile AOT to machine code through handwritten assembly. C, LLVM, MLIR, JIT and Python are outside the production execution chain.
3. **No hidden serial parallelism.** Missing vector physicalization rejects. It must not be repaired with scalar lane loops, a central address server, a global ready queue or work stealing.
4. **Blind release remains sovereign.** Completion releases surplus execution resources without peer queries, recipient selection or post-completion work search.
5. **Logical shape is not physical layout.** Rank/extents define semantics; byte strides define storage. Layout may change without changing the logical operator.
6. **f32 means f32.** Native f32 uses packed f32 arithmetic and the ISA's actual f32 lane width. Silent f64 promotion is forbidden.
7. **Integer index algebra must be exact.** Approximate quotient generation is permitted only as an internal estimate followed by exact integer correction.
8. **Old peaks are protected.** New field abstractions must not force existing structural f64 programs through a generic descriptor path.
9. **Alias is a contract, not a guess.** Distinct fields are noalias; intentional same-storage mutation uses one inout field.
10. **Failure is preferable to fabricated support.** Unsupported physical behavior is an explicit rejection, never a disguised fallback.
