# Wheelchair 1.3.4 Release Notes

## Summary

1.3.4 introduces Physical Regularity Collapse. It addresses the two machine-level gaps exposed by the AVX2 structured-neighborhood rematch without adding any workload-specific route.

### 1. Regular neighborhood address collapse

- Each access delta is launch-normalized to both the historical positive periodic ring delta and a shortest signed periodic representative.
- The runtime derives one signed contiguous-row-major byte displacement per access.
- A kernel-wide minimum/maximum neighborhood envelope is derived once at launch.
- Once per vector episode, not once per load, the runtime proves whether every active lane is inside that envelope.
- Power-of-two shapes use shifts/masks for the proof; arbitrary shapes retain a scalar proof once per episode.
- If all immutable input fields are proven contiguous row-major and the episode is interior, generated native code loads each immutable identity as `base + q*4 + signed_delta` with an ordinary YMM/ZMM masked load.
- Boundary and non-contiguous cases keep the complete pre-1.3.4 gather path.

This means a regular neighborhood no longer pays one coordinate decomposition and gather per immutable load identity merely because its logical delta is nonzero.

### 2. Wider tolerant factor cover

The generic two-term shared-factor supernode remains workload-name blind. Its coefficient realization now uses one multiply and one FMA instead of two multiplies plus an add, followed by one accumulator FMA. The accumulator recurrence width therefore does not collapse.

On the canonical high-pressure tolerant AVX2 field graph the generated arithmetic changes approximately from:

```text
1.3.3:  576 FMA, 1152 MUL, 580 ADD
1.3.4: 1152 FMA,  576 MUL,   4 ADD
```

Strict FP still emits zero FMA for this graph and preserves the original recurrence.

## Same-host diagnostic

On the current Intel Xeon Platinum 8272CL KVM host, five visible vCPUs, one NUMA node, fixed CPU0, the 64^3 one-executor release-style tolerant FEM corpus was interleaved for nine measured runs after warm-up:

```text
Wheelchair 1.3.3 median: 97.985 ms
Wheelchair 1.3.4 median: 65.420 ms
speedup:                  1.498x
```

The comparison includes the same process boundary on both sides and is a host-specific diagnostic, not a universal language claim.

Large strict outputs from 1.3.3 and 1.3.4 were byte-identical. The existing padded/strided negative controls still take the general path and keep their historical checksums.

## Claim boundary

1.3.4 does not claim that every affine padded layout has already been collapsed to a direct stream, nor that every possible N-way symbolic factorization is globally optimal. The release implements the proven contiguous-row-major regular class, exact boundary fallback, mixed-layout safety and a wider generic factor cover. Unsupported regularity remains on the truthful general path rather than being guessed.
