# Wheelchair 1.3.2 Physical Memory Causality Charter

Wheelchair 1.3.2 extends the physical-causality invariant from machine execution into writable storage.

## Governing invariant

Execution domains without a real causal relationship must remain mutually blind not only in scheduling and ISA dependency chains, but also in writable physical ownership. Unrelated domains must not be coupled merely because an implementation packed their counters, temporaries, outputs or mailboxes into the same cache line or page.

A real dependency may communicate, but its communication must remain sparse, local and single-touch wherever the machine permits: register carry first, then executor-private storage, then a causal-edge mailbox, then NUMA-local owned memory, and only finally genuinely shared writable memory.

## Red lines

1. Packed-array convenience is not a valid reason for unrelated writers to share a writable cache line or page.
2. Mutable Field layouts must prove affine address injectivity before execution. An unprovable writable mapping rejects; it never becomes an implicit data race.
3. Read-only overlap is legal. Writable overlap requires an explicit semantic mechanism such as a future atomic/reduction contract; ordinary output/inout does not silently alias.
4. A multi-executor writable Field layout must additionally prove that the current logical partition has cache-line-exclusive physical ownership. Failure rejects rather than silently falling back to one executor.
5. General causal node state is node-owned physical memory. A node does not share its writable causal state page with unrelated nodes.
6. General transient writable values are page-isolated causal mailboxes/state pages rather than packed global writable slots. Legacy symbols may remain only as ABI names; they do not restore packed physical ownership.
7. A causal child writes its final return value into child-owned storage. The parent reads it only after causal completion; parent and child do not repeatedly write one shared result cache line while computing independently.
8. Root initialization may not first-touch every causal state page merely for implementation convenience. Causal arrival begins from zero-filled anonymous memory and advances only along true predecessor edges.
9. NUMA placement is ownership-directed and best effort. Placement failure must preserve correctness and causal isolation, never introduce a central memory scheduler.
10. Memory ISA override is legal only when the memory-causality contract supports it. Large contiguous pure outputs may use non-temporal stores; inout and tail paths retain cacheable semantics.
11. No central memory scheduler, global memory ready queue, work stealing, destination-aware resource handoff, hot-path general allocator coordinator or hidden q1 serialization may be introduced.
12. WH/WHEX semantics, strict floating-point semantics, direct-native AOT generation and the 1..256 resident-executor implementation range remain unchanged.

## Physical Memory DAG

The Physical Memory DAG records writable ownership, read-only sharing, producer/consumer handoff, cache-line geometry, page ownership and NUMA placement constraints. It is not a sequential memory IR. Its purpose is to prevent a correct Physical DAG from being re-coupled by an accidental shared-address layout.

The compute and memory realizations are therefore peers:

```
Semantic DAG
    |
Physical DAG
   / \
ISA  Physical Memory DAG
   \ /
Physical realization
```

## Single-touch causal transfer

For an inter-domain transient value, the preferred realizations are:

1. zero memory touches when producer and consumer can remain register-connected;
2. one final producer write plus one post-causal consumer read through an owned mailbox;
3. ownership handoff of a large region without copying when a shared physical backing is semantically required.

Intermediate copies, central transient tables and repeated ownership bouncing are not canonical realizations.

## Correctness before locality

Writable address injectivity is a correctness gate and precedes performance planning. Cache-line ownership and NUMA locality are subsequent physical-realization gates. No locality optimization may accept an address mapping that is not first proven race-free.

## Memory ISA authority

Wheelchair does not pretend that userspace directly programs DDR ACT/PRE/RD/WR commands. The lowest ordinary software authority remains target CPU memory ISA plus OS virtual-memory/NUMA controls. 1.3.2 therefore applies local memory-ISA override only where the causal memory plan proves it appropriate, while layout and ownership remain the primary optimization mechanism.
