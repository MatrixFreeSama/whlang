# Wheelchair 1.3.5 Pure-Assembly Release Proof

1.3.5 keeps the production compiler/runtime path in handwritten x86-64 assembly and shell build tooling. User programs remain AOT direct-native.

The new Physical Realization Uniqueness machinery lives in `compiler/field_frontend_common_x86_64.S` and is compile-time only:

- bounded wide-group construction;
- exact physical coefficient-fact identity;
- static reuse-profitability assignment;
- demand-causal fact materialization;
- immutable constant identity/frequency residency;
- direct AVX2 material-memory FMA forms;
- high YMM register encoding;
- persistent regular address facts;
- cross-consumer causal-X lifetime;
- inherited NT-store policy guard.

No C, C++, LLVM, MLIR, JIT, Python production source, external register allocator or runtime optimizer is introduced. `test_release_native_135.sh` rebuilds and checks static binaries, frozen native-image identity, historical gates and the 1.3.5 machine/source authority before release.
