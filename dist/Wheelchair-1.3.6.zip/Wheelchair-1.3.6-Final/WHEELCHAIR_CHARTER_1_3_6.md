# Wheelchair 1.3.6 Charter — Global Physical Reality Unification

## Prime rule

A program may describe the same reality more than once. The machine must not pay for the same still-valid physical fact more than once merely because the description, emitter path or consumer changed.

```text
semantic references may be many
physical authority is versioned and unique
new machine work requires a new fact, a changed version, or lower total physical cost
```

1.3.6 therefore treats value, constant, address, load and dependency state as compiler-time physical facts with explicit identity and lifetime. It does not create a runtime fact table.

## Compiler-wide contract

`compiler/physical_reality_136.inc` is shared by the Field, Tensor and General AOT frontends. It defines the common invalid-authority sentinel and the hard zero-runtime-management policy. Domain-specific frontends remain free to use different exact fact keys because their semantics differ.

The new full canonical versioned fact graph is implemented in the Field physicalizer, where 1.3.5 exposed the remaining repeated-realization debt. Tensor keeps its existing exact constant interning, generation-versioned pure-value caches and pre-codegen Physical-DAG. General keeps its direct-native structural lowerings. 1.3.6 does not replace those mature paths with a central optimizer merely to make the architecture look uniform.

## Versioned authority

A Field `LoadFact` is not identified by address alone. It includes the current field version. A store increments only the version of the field it mutates.

```text
store(field A)
    -> version(A)++
    -> old LoadFact(A) invalid
    -> facts for B, C, ... remain valid
```

There is no global cache flush. A non-input field may enter episode-local load reuse only when the whole post-optimization graph proves that field is never written.

## Address / load / value separation

1.3.6 distinguishes:

- `AddressFact`: where a value lives;
- `LoadFact`: the value observed from that address at a specific field version;
- `ValueFact`: a pure arithmetic/constant result.

Exact regular addresses are canonicalized by field identity plus the complete Rank-N delta. Two source access records with the same identity share one invocation-stable address slot. A changed memory version invalidates the load fact without destroying an unchanged address fact.

## Demand-causal realization and retain versus recompute

A fact is born because a real consumer requires it. Persistent authority is granted only when its proven future reuse beats the physical cost of storing/reloading or retaining register pressure.

Cheap facts may die and be recomputed. Expensive reusable facts may remain resident. "Cache everything" and "recompute everything" are both rejected as dogma.

## Semantic width versus physical window

A multi-output semantic supernode may span every independent output admitted by the Field ABI. It is no longer rejected because the implementation once reserved three accumulator registers.

The current AVX2/AVX-512 realization consumes that semantic graph in register-pressure windows of three independent SIMD accumulators. A four-output graph therefore becomes a physical `3 + 1` sequence while remaining one legal semantic supernode.

The number three is a physical carrier-bank choice, not a semantic upper bound.

## AVX2 and AVX-512 equality of principle

1.3.5 proved high-register residency and direct material-memory operands primarily on native256. 1.3.6 extends the same physical-fact rules to AVX-512 with EVEX encodings, ZMM high-register use, masked direct AddressFact loads, direct stack-memory FMA operands and direct output-carrier stores.

The ISA implementations are not forced into byte-identical strategies. Semantic legality is shared; physical realization remains ISA-specific.

## Dependency necessity

The existing Field Physical-DAG remains authoritative. It records true def-use, memory-version and strict-reduction requirements. Emitter order is not allowed to manufacture an extra dependency edge.

Strict FP keeps historical arithmetic order and zero FMA contraction/reassociation. Tolerant FP may use the already-authorized equivalent arithmetic supernodes.

## Recipient-blind release

When the final proven consumer of a temporary carrier completes, that carrier ceases to be live. The releasing computation does not select who receives the resource next, query peer load, search a queue or perform destination-aware handoff.

This is release-only resource return, not work acquisition.

## No-shell rules

1. No C, C++, LLVM, MLIR or JIT production backend.
2. No runtime fact manager, runtime residency manager or runtime autotuner.
3. No benchmark/workload-name dispatch or coefficient-value dispatch.
4. No global ready queue, peer work search or recipient selection.
5. No result lookup substitution.
6. No global invalidation after a local field store.
7. No fixed semantic `MAX_CROSS_OUTPUTS=3` wall.
8. 1.3.2 physical memory ownership, 1.3.3 physical profitability, 1.3.4 regularity collapse and 1.3.5 realization uniqueness remain authoritative.

## Claim boundary

1.3.6 does not claim globally optimal register allocation, zero spills, zero MOV instructions or a single monolithic fact optimizer replacing every mature frontend. It claims the compiler-wide Physical Reality contract plus a complete versioned/canonical fact implementation for the Field AOT Physical-DAG, including both AVX2 and AVX-512 regular realization, while preserving the established Tensor and General physicalizers.

## Silicon rule

```text
same identity + same version + still-live cheaper authority
    => no second physical realization

changed version or cheaper recomputation
    => a new realization is legal
```
