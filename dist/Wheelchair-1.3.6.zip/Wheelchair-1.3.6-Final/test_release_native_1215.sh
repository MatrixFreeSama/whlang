#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

[ "$(cat VERSION)" = '1.2.15' ]
./build.sh > .release_build_1215.log
grep -q 'WHEELCHAIR_1_2_15_BUILD=PASS' .release_build_1215.log
grep -q 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS' .release_build_1215.log
grep -q 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0' .release_build_1215.log

# Shipped root/bin launchers are the exact freshly built native images.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Historical authorities are not weakened by the semantic extension.
./test_release_native_1214.sh

# New 1.2.15 semantic intersection.
./test_neighborhood_semantics_1215.sh

echo 'WHEELCHAIR_1_2_15_RELEASE=PASS'
