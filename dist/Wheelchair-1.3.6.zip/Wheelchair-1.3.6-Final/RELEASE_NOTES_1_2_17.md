# Wheelchair 1.2.17 Release Notes

## Rank-N Locality Compression and Field Episode Fusion

1.2.17 keeps the 1.2.16 field language and `WHFLD216` ABI unchanged. The release is a compiler/runtime locality upgrade: the same source now performs substantially less physical work.

### Added

- **Load Identity Algebra.** Immutable input loads are canonicalized by field plus complete Rank-N delta. Duplicate access declarations and repeated source occurrences share one physical load per SIMD episode.
- **Neighborhood Coordinate CSE.** Accesses with equal Rank-N deltas share one coordinate identity independent of field base.
- **Launch-time input-layout equivalence proof.** If all immutable input fields have equal physical byte strides, a coordinate offset vector is computed once and reused across fields. Heterogeneous layouts automatically use the proven general path.
- **Dynamic power-of-two shape proof.** Runtime extents and logical strides are classified at launch. Proven power-of-two domains recover coordinates with shift/mask algebra instead of vector division; arbitrary non-power-of-two shapes retain the exact general div/mod path.
- **Reuse-weighted AVX-512 residency.** The hottest immutable load identities occupy only helper-safe long-lived ZMM registers. Integer-index DAGs automatically reserve their carrier bank.
- **Direct gather after coordinate CSE.** In the layout-equivalent fast path, field bases change while the proved coordinate offset is reused. No field-load helper is called for each logical load.
- **Field-version safety.** Only immutable input fields enter load residency. `inout` and output paths remain outside the cache so stores remain version barriers.
- **Machine-code structural gates.** The full integration fixture is disassembled from the emitted ELF to verify logical-load compression and the presence of a separate general-layout fallback.

### Structural compression on the full integration fixture

The strict-f32 integration source contains 6,921 canonical operations and 2,304 logical field loads. 1.2.17 proves:

```text
logical loads                 2304
unique field+coordinate loads   97
unique neighborhood coordinates 27
fast-path direct gathers         97
layout-fallback field helpers    97  (not executed when stride proof succeeds)
```

The three output sinks share the same cached input values; strict accumulation order remains unchanged.

### Caretaker optimizations deliberately rejected

Two candidate optimizations were implemented and measured during development, then removed:

- materializing the 13 repeated f32 constants into an episode stack cache increased runtime versus direct broadcasts;
- keeping one coordinate offset live while immediately gathering every field with that coordinate did not improve AVX-512 and regressed AVX2 compared with the smaller offset cache.

They are not shipped. This is the `NO_NEGATIVE_STRUCTURAL_COMPRESSION` rule applied to the field lane.

### Same-run 64^3 regression result

On the release host (AMD EPYC 9V74, one visible thread per core), the unchanged full strict-f32 Hex8 local operator was timed as an architecture regression probe:

| Version | Physicalization | Median wall time | Repetitions | Relative to 1.2.16 |
|---|---:|---:|---:|---:|
| 1.2.16 | AVX-512 | 2033.430 ms | 3 | 1.00x |
| 1.2.17 | AVX-512 | 30.146 ms | 9 | 67.45x |
| 1.2.16 | AVX2 | 4241.540 ms | 3 | 1.00x |
| 1.2.17 | AVX2 | 47.666 ms | 9 | 88.98x |

This benchmark is a regression probe, not a code-generation dispatch condition. No workload name, 64^3 condition or solver-specific coefficient appears in the field compiler/runtime.

### Correctness

The 64^3 optimized AVX-512 output was compared pointwise with the same C reference used by the prior field validation. Across the three output components, maximum absolute error remained below `9.54e-7`; relative L2 errors were below `4e-7`, consistent with strict-f32/FMA-order differences already accepted by the 1.2.16 authority.

### Preserved

- `WHFLD216` binary layout and launch contract;
- `wheelchair.field/1` source semantics;
- native AVX-512 and true AVX2 f32 paths;
- arbitrary non-power-of-two dynamic shapes;
- padded/strided input gather and AVX-512 output scatter;
- AVX2 explicit rejection of unsupported non-contiguous output instead of scalar stores;
- exact constant integer div/mod;
- input/output/inout and noalias rules;
- 1.2.15 Rank-N neighborhood semantics;
- 1.2.14 dense/irregular authorities;
- recipient-blind resource release.
