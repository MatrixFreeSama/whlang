# Wheelchair 1.2.15 Release Notes

## Theme

**Rank-N Neighborhood Semantics Completion**

1.2.14 already had two mature capabilities that did not meet in the middle:

- Rank-N product-domain execution;
- indexed / irregular access in the one-dimensional tensor path.

A Rank-N field could therefore read `x[i,j,k]`, while a structurally equivalent local-neighborhood read such as `x[periodic(i+1,n),j,k]` was rejected before native lowering. 1.2.15 closes that semantic gap without adding a FEM, stencil, solver, or benchmark-specific route.

## Added

### Rank-N coordinate algebra

Tuple loads are lowered as coordinate transformations over the existing product domain instead of requiring identity coordinates. The source surface can now lower transformed Rank-N accesses such as:

```text
x[periodic(i + 2, n), j, k]
x[periodic(i + n - 2, n), j, k]
x[i, (j + 1) % 2, k]
x[select(i + 1 == n, i, i + 1), j, k]
```

The transformed coordinates are folded into one flat physical address expression. No nested runtime tuple walker is emitted.

### Physical-ring periodic lowering

For the single dynamic Rank-N axis already supported by the 1.2.x product-domain ABI, fixed-radius periodic offsets are lowered directly in the physical product ring.

For static suffix product `S`:

```text
q = i*S + suffix
physical_n = logical_n*S
```

A positive periodic offset is represented structurally as:

```text
((q + C*S) mod physical_n) - suffix
```

and the negative form adds `physical_n` before subtracting `C*S`.

This reuses the existing vector reciprocal/modulo lowering. It does not introduce a scalar modulo helper, runtime neighbor loop, boundary oracle, or workload-specific dispatch. The radius is a compile-time literal and is not restricted to one cell.

### Physical-domain proof bounds

The native512 and native256 derived frontends now distinguish:

- logical input bounds, used to validate the user argument;
- physical product-domain bounds, used by coordinate, modulo, interior, and structural-key proofs.

This removes the old assumption that logical `n` and the vector root-domain extent are identical after Rank-N physicalization.

### Root-coordinate ownership correction

1.2.14 persistent dense-coordinate carriers are valid only for the root Cartesian episode. An indexed Rank-N map load temporarily replaces the current vector axis with a transformed neighborhood address. 1.2.15 prevents root induction carriers from being reused inside that transformed axis.

This is a semantic ownership correction exposed by the new neighborhood capability. It does not remove or weaken the 1.2.14 dense caretaker path.

## Proven genericity

The 1.2.15 release gates include:

- positive and negative dynamic periodic offsets with radius 2;
- the unsigned-source-friendly `i + n - C` periodic form;
- dataized clamped boundary transforms through `select`;
- strict floating-point Rank-N neighborhood reads;
- Rank-6 transformed neighborhood access;
- simultaneous transforms on several axes;
- a three-field local operator combining identity, dynamic-periodic and static-periodic reads;
- native512 and native256 numerical equivalence for the new generic cases.

No optimizer branch uses the names of these tests or a solver/workload identity.

## Preserved

The complete 1.2.14 release gate remains mandatory and passes unchanged, including:

- direct handwritten-assembly production compiler;
- no Python in the production compiler/runtime path;
- AOT only, no JIT;
- no C, LLVM, MLIR, or external code-generation backend;
- no hidden scalar fallback for Rank-N parallel semantics;
- blind resource release, with no work stealing, peer query, global ready queue, recipient selection, or runtime profitability selector;
- strict reduction-order preservation;
- 1.2.14 dense caretaker correctness;
- irregular sparse q1/q2/q4 machine-image hashes byte-identical to the historical 1.2.12/1.2.13 authority.

## Explicit non-claims

1.2.15 completes the **neighborhood semantic gap inside the existing Rank-N product-domain ABI**. It does not pretend that unrelated deeper frontiers are solved.

The following remain explicit compile-time rejections in this release:

- more than one independent runtime extent in the same Rank-N product domain;
- native Rank-N `f32` tensor arithmetic in the mature tensor backend;
- arbitrary non-power-of-two static axes in the current product-domain physicalizer.

Those require runtime-shape ABI and numeric-backend work. They are deliberately not implemented by widening to `f64`, flattening the source by hand, calling an external backend, or introducing a benchmark wrapper.

## Release gates

```sh
./test_release_native_1215.sh
```

The new semantic gate reports:

```text
RANKN_COORDINATE_ALGEBRA=PASS
NEIGHBORHOOD_WORKLOAD_DISPATCH=0
RANKN_DYNAMIC_PERIODIC_RADIUS=PASS
RANKN_DATAIZED_BOUNDARY_TRANSFORM=PASS
RANKN_NEIGHBORHOOD_STRICT_FP=PASS
RANK6_NEIGHBORHOOD_GENERICITY=PASS
MULTIFIELD_LOCAL_OPERATOR=PASS
NATIVE256_NEIGHBORHOOD_EQUIVALENCE=PASS
MULTI_DYNAMIC_EXTENT_FRONTIER=EXPLICIT_REJECT
F32_RANKN_FRONTIER=EXPLICIT_REJECT
RANKN_NEIGHBORHOOD_SEMANTICS_1_2_15=PASS
```
