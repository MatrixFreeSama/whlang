# Wheelchair 1.2.17 Charter

1. **Remove repeated work before adding resources.** The 1.2.17 field optimizer targets redundant address generation, redundant gathers and redundant reloads. More executors are not a substitute for fixing single-episode waste.
2. **Load identity is semantic.** An immutable field value is identified by field version plus normalized Rank-N coordinate, not by source occurrence or access number. Equal values may load once and fan out to all users.
3. **Coordinate identity is independent of field base.** When launch-time stride proof shows input layouts are equivalent, one neighborhood coordinate episode may serve multiple fields. If the proof fails, the general per-field path remains authoritative.
4. **No benchmark dispatch.** Field rank, mode, deltas, runtime extents/strides, reuse counts, FP contract and ISA capability are valid optimization inputs. Solver names, benchmark names, fixed shapes and magic workload constants are not.
5. **No hidden serial recovery.** Locality compression is AOT. It must not introduce a runtime ready queue, address server, neighbor loop, work stealing or scalar-lane fallback.
6. **Blind release remains sovereign.** A completed region releases surplus resources without peer queries, recipient selection or post-completion work search.
7. **Strict FP means order protection.** Load/address CSE and value reuse may remove redundant work, but strict accumulation order is not reassociated. Tolerant arithmetic may use broader algebraic fusion in future without creating a second compiler.
8. **Residency is reuse-weighted and ownership-aware.** Long-lived SIMD registers are assigned only when helpers and integer carriers do not own them. Register pressure is a physical constraint, not an invitation to spill everything.
9. **Negative optimization is rejected.** A structurally plausible optimization that increases measured work or pressure is not retained merely because it looks sophisticated. 1.2.17 explicitly rejected stack-materialized constant caching and over-fused coordinate fan-out after measurement.
10. **Existing ABI and peaks stay protected.** `WHFLD216`, the 1.2.16 field semantics, the 1.2.15 Rank-N neighborhood path, and older dense/irregular authorities remain compatible release gates.
11. **Matrix-free stays matrix-free.** Local contraction recognition must never materialize a global matrix or neighbor lookup table to obtain locality.
12. **Direct native authority.** The production path remains handwritten AOT assembly to native ELF. C, LLVM, MLIR, JIT, Python and bytecode interpretation remain outside the execution chain.
