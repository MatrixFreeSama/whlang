# Wheelchair 1.2.18 Charter

## Human Field Surface over the Sovereign Rank-N Backend

1.2.18 has one job: expose the already-proven materialized-field backend through ordinary WH/WHEX without weakening the existing machine architecture.

### Surface rule

Users describe logical data and mathematics:

```text
input field u[x in nx periodic, y in ny, z in nz]: f32
output field out[x in nx, y in ny, z in nz]: f32 = u[x+1,y,z]
```

Users do not describe descriptors, byte strides, flattening, SIMD widths, gathers, register banks, executor ownership or scheduler policy.

### WH / WHEX relation

- WH may use familiar structural `for` syntax as a human shell.
- WHEX exposes data-oriented `field`, `sum`, `region`, `select` and boundary semantics directly.
- Neither ordinary field `for` nor a WHEX region authorizes a hidden sequential runtime loop.
- True causal/stateful dependence remains a separate semantic category.

### Backend rule

Human materialized-field syntax must erase into the existing `wheelchair.field/1` graph. Equivalent human and canonical inputs are required to generate byte-identical native executables. A surface feature that needs a new runtime wrapper, interpreter or scalar fallback is not complete.

### Boundary rule

The default field boundary is strict. Neighbor access beyond a strict domain rejects unless the source supplies a real boundary contract such as `periodic` or an explicit proven normalization.

### Shape rule

Runtime shape truth comes from the actual `WHFLD216` descriptors. The human source may name runtime extents, but it must not claim a static extent that the ABI cannot verify. Pretty syntax is not allowed to outrank semantic truth.

### Abstraction rule

`pure fn` is compile-time semantic abstraction. It must disappear before field code generation. Lexical parameters, including one-character names, outrank optional spelling repair. No function-call overhead may be introduced merely to improve source readability.

### Parallel rule

1.2.18 does not modify the recipient-blind release architecture. No work stealing, global ready queue, central scheduler, peer query, destination-aware handoff or persistent idle-worker spin may enter through the human surface.

### Compatibility rule

1.2.18 must preserve:

- `WHFLD216`;
- `wheelchair.field/1`;
- 1.2.17 locality optimization;
- 1.2.16 f32 field authority;
- 1.2.15 Rank-N neighborhood authority;
- 1.2.14 native authorities.

### Release definition

1.2.18 is complete only when a freshly extracted release ZIP can rebuild itself, pass all historical and new surface gates, keep shipped native images identical to a fresh build, and remain byte-identical before and after the complete release test according to `SHA256SUMS`.
