#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
T=${TMPDIR:-/tmp}/wheelchair130_physical_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM

[ "$(cat VERSION)" = '1.3.0' ]
./build.sh > "$T/build.log" 2>&1
grep -q 'WHEELCHAIR_1_3_0_BUILD=PASS' "$T/build.log"
grep -q 'PHYSICAL_DAG_TENSOR_TWO_PASS=BUILT' "$T/build.log"
grep -q 'PHYSICAL_DAG_FIELD_PLAN=BUILT' "$T/build.log"
grep -q 'AUTOMATIC_RANKN_EXECUTION_TENSOR=BUILT' "$T/build.log"
grep -q 'SCHEDULER_BEFORE_CANONICAL_CODEGEN=PASS' "$T/build.log"
grep -q 'SCHEDULER_PLAN_RUNTIME_CLOSURE=PASS' "$T/build.log"
grep -q 'MAX_RESIDENT_EXECUTORS=256' "$T/build.log"

echo 'PHYSICAL_DAG_BUILD_AUTHORITY=PASS'

# Tensor canonical generation is two-pass: the first lowering is a disposable
# resource/shape probe, the second pass is the only ISA image that can be emitted.
for f in \
  frozen_native/tensor_frontend_profile_base.S \
  frozen_native/tensor_frontend_profile_wide.S \
  frozen_native/generated_derived/tensor_derived_frontend_x86_64.S \
  frozen_native/generated_native256/tensor_frontend_base_native256.S \
  frozen_native/generated_native256/tensor_frontend_wide_native256.S \
  frozen_native/generated_native256/tensor_frontend_derived_native256.S
do
  grep -q 'physical_plan_pass' "$f"
  grep -q '^\.physical_codegen_pass:' "$f"
  grep -q '^\.physical_plan_realize:' "$f"
  grep -q 'physical_plan_counts' "$f"
  grep -q 'physical_tensorized' "$f"
  ! grep -q 'mov dword ptr \[rip+schedule_carriers\],4' "$f"
done
cmp compiler/tensor_frontend_x86_64.S frozen_native/tensor_frontend_profile_base.S

echo 'TENSOR_PHYSICAL_DAG_TWO_PASS=PASS'
echo 'POST_CODEGEN_CARRIER_FICTION=0'

# The scheduler is capped before canonical codegen by capabilities supplied by
# the actual backend. Runtime consumes those fields as an execution contract.
grep -q 'schedule_carrier_cap' frozen_native/topologyc_multi_isa_x86_64.S
grep -q 'schedule_unroll_cap' frozen_native/topologyc_multi_isa_x86_64.S
for f in \
  runtime/tensor_runtime_template_x86_64.S \
  frozen_native/generated_derived/tensor_derived_runtime_template_x86_64.S \
  frozen_native/generated_native256/tensor_runtime_native256_template_x86_64.S \
  frozen_native/generated_native256/tensor_derived_runtime_native256_template_x86_64.S
do
  grep -q 'cmp dword ptr \[rip+reduction_carriers_patch\],1' "$f"
  grep -q 'cmp dword ptr \[rip+unroll_count_patch\],1' "$f"
done

echo 'SCHEDULER_EXECUTION_CLOSURE=PASS'

# Field also has a compiler-only physical planning stage, and final codegen
# consumes the explicit planned order rather than indexing ff_ops directly.
grep -q '^ff_build_physical_plan:' compiler/field_frontend_common_x86_64.S
grep -q 'ff_physical_edge_count' compiler/field_frontend_common_x86_64.S
grep -q 'ff_physical_memory_barriers' compiler/field_frontend_common_x86_64.S
grep -q 'ff_physical_tensor_lanes' compiler/field_frontend_common_x86_64.S
grep -q 'ff_physical_order' compiler/field_frontend_common_x86_64.S

echo 'FIELD_PHYSICAL_DAG=PASS'

# Automatic Rank-N execution tensorization is deliberately broader than a
# matrix-op recognizer. A complete fused chunk is the current tensor episode;
# scalar fallback remains forbidden.
grep -q 'generated kernel owns the complete chunk loop' frozen_native/tensor_frontend_profile_base.S
grep -q 'mov dword ptr \[rip+vec_fused_mode\],1' frozen_native/tensor_frontend_profile_base.S
grep -q 'mov dword ptr \[rip+physical_tensorized\],1' frozen_native/tensor_frontend_profile_base.S

echo 'RANKN_EXECUTION_TENSOR_EPISODE=PASS'

# Semantic ISA override/direct encoding: semantic contraction and generic
# integer-vector semantics can select a target recipe directly, without C/LLVM/JIT.
grep -q '^vec_vfnmadd231pd:' frozen_native/tensor_frontend_profile_base.S
grep -q 'call vec_vfnmadd231pd' frozen_native/tensor_frontend_profile_base.S
grep -q 'semantic operation is independent' frozen_native/tensor_frontend_profile_base.S
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null; then
  echo 'PRODUCTION_BUILD_PYTHON=FAIL' >&2; exit 1
fi
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi

echo 'SEMANTIC_ISA_OVERRIDE_DIRECT_NATIVE=PASS'

# 256 is an implementation ceiling, not a claim that 256 OS threads must be
# created. All hot runtimes erase executor leaves that own no work.
grep -q '^\.equ MAX_EXECUTORS, 256' runtime/tensor_runtime_template_x86_64.S
grep -q '^\.equ MAX_EXECUTORS,256' runtime/field_runtime_512_x86_64.S
grep -q '^\.equ MAX_EXECUTORS,256' runtime/field_runtime_256_x86_64.S
grep -q '^\.equ GR_MAX_CPUS, 256' runtime/general_parallel_release_x86_64.S
grep -q '^\.equ GR_MAX_NODES, 256' runtime/general_parallel_release_x86_64.S
grep -q '^\.equ GMAX_FRAGMENTS,256' compiler/general_frontend_x86_64.S
grep -q 'cmp eax,256' compiler/general_frontend_x86_64.S
grep -q 'allowed_cpu_count' frozen_native/topologyc_multi_isa_x86_64.S
grep -q '^field_default_executor_count:' compiler/fieldc_driver_x86_64.S

echo 'EXECUTOR_GEOMETRY_1_256=PASS'

# Explicit q256 Tensor compile and execution. n=100000 owns only two chunks, so
# this simultaneously proves empty-executor erasure on a host with <256 CPUs.
build/topologyc tests/whex/strength_probe.whex -o "$T/tensor256" --executors 256 >/dev/null
[ "$("$T/tensor256" 100000)" = 'checksum_bits=0x4186ef9500000000' ]
exec_off=$(awk '$2=="RUNTIME_EXECUTOR_OFF," {print $3;exit}' compiler/runtime_offsets.inc)
car_off=$(awk '$2=="RUNTIME_CARRIERS_OFF," {print $3;exit}' compiler/runtime_offsets.inc)
unr_off=$(awk '$2=="RUNTIME_UNROLL_OFF," {print $3;exit}' compiler/runtime_offsets.inc)
read_u32() { od -An -tu4 -j "$2" -N4 "$1" | tr -d '[:space:]'; }
[ "$(read_u32 "$T/tensor256" $((exec_off)))" = 256 ]
[ "$(read_u32 "$T/tensor256" $((car_off)))" = 1 ]
[ "$(read_u32 "$T/tensor256" $((unr_off)))" = 1 ]

# q256 with a one-element invocation must behave exactly like q1, not try to
# materialize 255 empty causal leaves.
build/topologyc tests/whex/strength_probe.whex -o "$T/tensor1" --executors 1 >/dev/null
[ "$("$T/tensor256" 1)" = "$("$T/tensor1" 1)" ]

echo 'TENSOR_Q256_EMPTY_LEAF_ERASURE=PASS'

# The pre-codegen plan fields are executable contracts, not decorative ELF
# metadata. Corrupting unroll from 1 to 2 must reject before worker creation.
cp "$T/tensor256" "$T/tensor_bad_plan"
printf '\002\000\000\000' | dd of="$T/tensor_bad_plan" bs=1 seek=$((unr_off)) conv=notrunc status=none
set +e
"$T/tensor_bad_plan" 100000 >/dev/null 2>&1
badplan=$?
set -e
[ "$badplan" -eq 2 ]
echo 'SCHEDULER_PLAN_CORRUPTION_REJECT=PASS'

# Default executor geometry comes from the allowed affinity set, capped at 256.
build/topologyc tests/whex/strength_probe.whex -o "$T/tensor_auto" >/dev/null
auto=$(read_u32 "$T/tensor_auto" $((exec_off)))
cpus=$(nproc)
if [ "$cpus" -gt 256 ]; then expected=256; else expected=$cpus; fi
[ "$auto" -eq "$expected" ]
echo 'DEFAULT_EXECUTOR_AFFINITY_AUTO=PASS'

# General blind-release path accepts the new ceiling without a global queue.
build/wheelchairc tests/general_parallel_126/branch_probe.wh -o "$T/general256" --executors 256 >/dev/null
[ "$("$T/general256" 7)" = "out00_bits=0x0000000000000029
out01_bits=0x0000000000000012
out02_bits=0x0000000000000017" ]
grep -q '"max_cpu_width": 256' frozen_native/general_parallel_release_offsets.json
grep -q '"max_nodes": 256' frozen_native/general_parallel_release_offsets.json

echo 'GENERAL_Q256_BLIND_RELEASE=PASS'

# Field q256: 105 logical points are deliberately much smaller than 256.
F=tests/field_1216
build/fieldc "$F/mixed.json" -o "$T/field256" --executors 256 >/dev/null
cp "$F/out_3x5x7.whfld" "$T/field-out.whfld"
[ "$("$T/field256" "$F/a_3x5x7.whfld" "$F/bpad_3x5x7.whfld" "$T/field-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
cmp "$T/field-out.whfld" "$F/expected_mixed_3x5x7.whfld"
echo 'FIELD_Q256_EMPTY_LEAF_ERASURE=PASS'

# Bounds are exact.
set +e
build/topologyc tests/whex/strength_probe.whex -o "$T/t257" --executors 257 >/dev/null 2>&1; t257=$?
build/topologyc tests/whex/strength_probe.whex -o "$T/t0" --executors 0 >/dev/null 2>&1; t0=$?
build/fieldc "$F/mixed.json" -o "$T/f257" --executors 257 >/dev/null 2>&1; f257=$?
build/fieldc "$F/mixed.json" -o "$T/f0" --executors 0 >/dev/null 2>&1; f0=$?
set -e
[ "$t257" -ne 0 ] && [ "$t0" -ne 0 ] && [ "$f257" -ne 0 ] && [ "$f0" -ne 0 ]
echo 'EXECUTOR_BOUNDARY_REJECTION=PASS'

# No runtime scheduler was introduced by the expansion.
grep -q 'GENERAL_PARALLEL_GLOBAL_READY_QUEUE=0' build.sh
grep -q 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS' build.sh
grep -q 'FIELD_LOCALITY_WORK_STEALING=0' build.sh

echo 'NO_GLOBAL_READY_QUEUE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'RECIPIENT_BLIND_RELEASE_PRESERVED=PASS'

# Static AOT closure.
for f in build/topologyc build/topologyc-native256 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'
echo 'WHEELCHAIR_PHYSICAL_DAG_1_3_0=PASS'
