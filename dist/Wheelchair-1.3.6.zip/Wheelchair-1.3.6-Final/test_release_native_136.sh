#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

[ "$(cat VERSION)" = '1.3.6' ]
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_136.log 2>&1
for marker in \
 WHEELCHAIR_1_3_5_BUILD=PASS \
 WHEELCHAIR_1_3_6_BUILD=PASS \
 GLOBAL_PHYSICAL_REALITY=BUILT \
 GLOBAL_PHYSICAL_FACT_GRAPH=BUILT \
 PHYSICAL_FACT_VERSION_AUTHORITY=per-field-no-global-flush \
 GLOBAL_ADDRESS_FACT_CANONICALIZATION=BUILT \
 GLOBAL_LOAD_FACT_IDENTITY=BUILT \
 GLOBAL_CONSTANT_FACT_POOL=BUILT \
 RETAIN_VS_RECOMPUTE=compile-time-lifetime+profitability \
 DEPENDENCY_NECESSITY_PROOF=physical-dag \
 CROSS_OUTPUT_SEMANTIC_WIDTH=field-abi \
 CROSS_OUTPUT_PHYSICAL_WINDOW=register-bank \
 AVX2_PHYSICAL_FACT_CONSUMPTION=BUILT \
 AVX512_PHYSICAL_FACT_CONSUMPTION=BUILT \
 AVX512_HIGH_REGISTER_RESIDENCY=BUILT \
 GLOBAL_FLUSH_ON_STORE=0 \
 RESOURCE_RECIPIENT_SELECTION=0 \
 RUNTIME_FACT_MANAGER=0 \
 RUNTIME_RESIDENCY_MANAGER=0 \
 RUNTIME_AUTOTUNE_LOOP=0 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 STRICT_FP_REASSOCIATION=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
do grep -q "^$marker$" .release_build_136.log; done
echo 'BUILD_1_3_6_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# The prior complete authority is part of the new release contract.
./test_release_native_135.sh
echo 'COMPLETE_1_3_5_RELEASE_AUTHORITY_PRESERVED=PASS'
./test_global_physical_reality_136.sh

# Compiler-wide policy vocabulary is common, but remains compile-time only.
for f in compiler/field_frontend_common_x86_64.S compiler/tensor_frontend_x86_64.S compiler/general_frontend_x86_64.S; do
  grep -q 'compiler/physical_reality_136.inc' "$f"
done
grep -q '^\.equ PR136_RUNTIME_FACT_MANAGER,0$' compiler/physical_reality_136.inc
grep -q '^\.equ PR136_GLOBAL_FLUSH_ON_STORE,0$' compiler/physical_reality_136.inc
grep -q '^\.equ PR136_RESOURCE_RECIPIENT_SELECTION,0$' compiler/physical_reality_136.inc
echo 'COMPILER_WIDE_PHYSICAL_REALITY_CONTRACT=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -RniE 'runtime[ _-]*fact[ _-]*manager|runtime[ _-]*residency[ _-]*manager|runtime[ _-]*autotun|work[ _-]*steal|global[ _-]*ready[ _-]*queue' \
  compiler runtime | grep -v -E 'No |no |RUNTIME_|WORK_STEALING|runtime autotun|comment|Red line' >/dev/null 2>&1; then
  echo 'FORBIDDEN_RUNTIME_PHYSICAL_MANAGER=FAIL' >&2; exit 1
fi
if grep -RniE 'Taichi|SPGrid|compute_Ap|elasticity|fem_hex8|benchmark[_ -]*mode' \
  compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'WORKLOAD_SPECIALIZATION_LEAK=FAIL' >&2; exit 1
fi
(cd frozen_native && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
echo 'FROZEN_NATIVE_AUTHORITY=PASS'

for f in \
 WHEELCHAIR_CHARTER_1_3_6.md \
 RELEASE_NOTES_1_3_6.md \
 PURE_ASSEMBLY_RELEASE_PROOF_1_3_6.md \
 RELEASE_GATES_1_3_6.txt \
 PERFORMANCE_1_3_6_GLOBAL_PHYSICAL_REALITY.md \
 test_global_physical_reality_136.sh
 do test -s "$f"; done

echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_RUNTIME_FACT_MANAGER=PASS'
echo 'NO_RUNTIME_AUTOTUNE=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'RESOURCE_RECIPIENT_SELECTION=0'
echo 'WHEELCHAIR_1_3_6_RELEASE=PASS'
