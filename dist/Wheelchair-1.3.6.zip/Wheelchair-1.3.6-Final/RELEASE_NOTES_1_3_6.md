# Wheelchair 1.3.6 Release Notes

## Summary

1.3.6 introduces **Global Physical Reality Unification**. The main change is architectural: PhysicalFact identity is no longer confined to the 1.3.5 coefficient supernode. The Field AOT physicalizer now builds a versioned fact graph covering exact constants, regular addresses, loads, pure arithmetic and integer/index conversion facts before final Physical-DAG scheduling.

The release remains handwritten x86-64 assembly, AOT direct-native, workload-name blind and free of runtime optimization managers.

## 1. Global versioned Field facts

`ff_build_global_physical_reality_136` runs after tolerant structural fusion and before the final Field Physical-DAG. It interns exact pure facts and tracks current logical-register authority.

A duplicate operation is erased or replaced by a move only when an identical fact is still resident in a valid logical carrier. The pass never creates a runtime lookup table.

Stores increment only the version of their own field. They do not flush unrelated facts.

## 2. AddressFact canonicalization

Regular address identity is now canonical over:

```text
field identity + complete Rank-N signed delta
```

`ff_access_address_fact` maps every syntax-level access to a canonical AddressFact, and `ff_address_fact_owner` provides one representative for prologue realization. The generated function allocates one persistent address slot per unique fact rather than per access declaration.

The release gate contains a two-access duplicate-address program and requires exactly one invariant address materialization in the generated native256 region.

## 3. LoadFact version safety

Load identity includes both canonical address identity and the current field version. An inout write followed by a load of the same address is therefore a new LoadFact and must observe the write.

The release gate freezes the expected result from 1.3.5 semantics and checks this write-then-read case on both AVX2 and AVX-512.

## 4. Global exact constant pool

The exact-bit constant pool now admits generic `OP_CONST` operations as well as cross-output coefficient constants. Repeated constants share a single persistent invocation-level construction when pool capacity permits. Pool overflow falls back to the historical local reconstruction path and is not a semantic failure.

## 5. Semantic supernode width is no longer three

The old three-output semantic ceiling is removed. `CROSS_OUTPUT_STORAGE` follows the Field ABI capacity (`MAX_FIELDS`). Physical realization is separately windowed by `CROSS_PHYSICAL_WINDOW`, currently three SIMD accumulators.

A release-gated four-output tolerant program executes as two physical windows (`3 + 1`) and matches the frozen expected output on native256 and AVX-512.

## 6. AVX-512 PhysicalFact realization

1.3.6 extends the regular cross-output fact path to AVX-512 instead of routing it through the conservative 1.3.4 authority.

The new EVEX emitter paths cover:

- ZMM0..ZMM15 source/destination extension bits required by the physical plan;
- high-use exact constant residency;
- masked direct loads from persistent AddressFacts;
- direct stack-memory FMA operands;
- direct output-carrier stores;
- the same coefficient-fact retain/recompute decisions used by native256.

On the canonical high-pressure tolerant release graph, current machine inspection reports:

```text
AVX512 high ZMM references:        809
AVX512 direct stack-memory FMAs:   648
AVX512 tolerant FMA sites:        2041
AVX2 high YMM references:         1029
strict AVX512 FMA contractions:   0
```

These are structural machine-code counts, not a universal performance claim.

## 7. Compiler-wide contract vocabulary

`compiler/physical_reality_136.inc` is included by Field, Tensor and General frontends. It defines common compile-time authority rules without inserting a shared runtime optimizer.

Tensor's existing exact constant interning, generation-versioned pure-map/index caches and pre-codegen Physical-DAG remain intact. General direct-native structural lowering remains intact. 1.3.6 deliberately avoids replacing proven specialized physicalizers with a central abstraction layer.

## 8. Historical authority preserved

The complete 1.3.5 release test passes on the 1.3.6 tree after rebuilding and synchronizing final native images. This includes historical Tensor causal gates, Rank-N neighborhood gates, Field surface/native/locality gates, 1.3.1 machine realization, 1.3.2 memory causality, 1.3.3 physical optimization, 1.3.4 regularity collapse and 1.3.5 realization uniqueness.

## Claim boundary

The new versioned global canonical fact pass is a Field Physical-DAG implementation, not a claim that every frontend has been rewritten around one monolithic optimizer. The compiler-wide rule is shared; domain physicalizers remain independent where that preserves stronger existing machinery.
