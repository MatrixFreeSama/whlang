# Wheelchair 1.3.6 Global Physical Reality Machine Diagnostic

1.3.6 is gated primarily by eliminated physical work and exact numerical preservation rather than by a single timing number. No universal speedup is claimed for this release.

## Canonical high-pressure generated-machine evidence

From the release-gated tolerant Rank-N Field graph:

```text
AVX512 high ZMM references:       809
AVX512 direct stack-memory FMAs:  648
AVX512 tolerant FMA sites:       2041
AVX2 high YMM references:        1029
strict AVX512 FMA sites:         0
```

The AVX-512 counts demonstrate that the 1.3.6 path is physically active rather than documentation-only.

## Duplicate-address diagnostic

A strict source declares two accesses with exactly the same field identity and Rank-N delta. 1.3.6 maps both to one AddressFact. Disassembly of the generated native256 region contains:

```text
canonical invariant-address materializations: 1
```

Both AVX2 and AVX-512 outputs are byte-identical to the frozen 1.3.5 semantic result.

## Four-output diagnostic

A tolerant graph with four independent output epochs and one shared ordered X set is admitted as one semantic cross-output supernode. The machine physicalizer consumes it in `3 + 1` register windows. All four outputs match the frozen tolerant reference on both ISA paths.

## Mutable-version diagnostic

An inout program performs:

```text
load A@v0
compute
store A -> v1
load A@v1
store
```

The second load observes the written value on both ISA paths. This proves that LoadFact reuse is versioned rather than address-only.

## Timing claim boundary

This release does not publish a new opponent leaderboard because the available checked-in release corpus is optimized for deterministic structural/numerical gates rather than stable large-host timing. Historical 1.3.5 timing data remains historical and is not relabeled as 1.3.6 performance.
