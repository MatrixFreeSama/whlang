#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
T=tests/field_1216
TMP=${TMPDIR:-/tmp}/wheelchair1216_field_$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

[ -x build/fieldc ]
[ -x build/fieldc-native256 ]
for f in build/fieldc build/fieldc-native256 build/field_runtime_512_template build/field_runtime_256_template; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

echo 'FIELD_STATIC_AOT_IMAGES=PASS'

# One canonical program must accept multiple unrelated runtime shapes without
# recompilation.  These are real descriptor-provided extents, not hand flattening.
build/fieldc "$T/sum.json" -o "$TMP/sum512" >/dev/null
build/fieldc-native256 "$T/sum.json" -o "$TMP/sum256" >/dev/null
[ "$("$TMP/sum512" "$T/a_3x5x7.whfld")" = 'checksum_f32_bits=0x45ade800' ]
[ "$("$TMP/sum256" "$T/a_3x5x7.whfld")" = 'checksum_f32_bits=0x45ade800' ]
[ "$("$TMP/sum512" "$T/prime_5x7x11.whfld")" = 'checksum_f32_bits=0x46be9400' ]
[ "$("$TMP/sum256" "$T/prime_5x7x11.whfld")" = 'checksum_f32_bits=0x46be9400' ]
# Padded/strided input must still be a native vector gather.
[ "$("$TMP/sum512" "$T/bpad_3x5x7.whfld")" = 'checksum_f32_bits=0x46796000' ]
[ "$("$TMP/sum256" "$T/bpad_3x5x7.whfld")" = 'checksum_f32_bits=0x46796000' ]
echo 'MULTI_DYNAMIC_EXTENTS_FIELD=PASS'
echo 'NATIVE_F32_GATHER_512_256=PASS'

# General multi-field local operator: padded input + periodic neighborhood +
# direct f32 arithmetic + output + reduction.  No benchmark-specific names.
for C in fieldc fieldc-native256; do
  build/$C "$T/mixed.json" -o "$TMP/$C-mixed" --executors 4 >/dev/null
  cp "$T/out_3x5x7.whfld" "$TMP/$C-out.whfld"
  [ "$("$TMP/$C-mixed" "$T/a_3x5x7.whfld" "$T/bpad_3x5x7.whfld" "$TMP/$C-out.whfld")" = 'checksum_f32_bits=0x47126d00' ]
  cmp "$TMP/$C-out.whfld" "$T/expected_mixed_3x5x7.whfld"
done
echo 'MULTIFIELD_PERIODIC_LOCAL_OPERATOR=PASS'
echo 'PARALLEL_FIELD_EXECUTORS_Q4=PASS'

# Arbitrary compile-time constant integer division/modulo.  The test uses two
# unrelated non-power-of-two divisors; compiler/runtime sources are separately
# scanned to ensure neither constant is special-cased.
for C in fieldc fieldc-native256; do
  build/$C "$T/integer_divmod.json" -o "$TMP/$C-int" >/dev/null
  [ "$("$TMP/$C-int" "$T/a_3x5x7.whfld")" = 'checksum_f32_bits=0x45c02800' ]
done
if grep -RniE 'Taichi|FEM|elasticity|\b97\b|\b89\b|64\^3|64x64' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'FIELD_WORKLOAD_OR_DIVISOR_SPECIAL_CASE=FAIL' >&2; exit 1
fi
echo 'GENERAL_CONST_INTEGER_DIVMOD=PASS'
echo 'FIELD_WORKLOAD_DISPATCH=0'
echo 'FIELD_DIVISOR_SPECIAL_CASE=0'

# High-pressure integration probe: the complete 8-node hexahedral linear
# elasticity local operator, three displacement components, lambda/mu fields,
# 97 distinct neighborhood access specifications and all three output fields.
# This is a validation workload only; no solver name or coefficient is visible
# to the compiler/runtime sources. Both physicalizations must write the exact
# per-point strict-f32 oracle fields.
for C in fieldc fieldc-native256; do
  build/$C "$T/fem_hex8_full.json" -o "$TMP/$C-hex8" >/dev/null
  for u in 0 1 2; do cp "$T/fem_out${u}_3x5x7.whfld" "$TMP/$C-hex8-out${u}.whfld"; done
  "$TMP/$C-hex8" \
    "$T/fem_lambda_3x5x7.whfld" "$T/fem_mu_3x5x7.whfld" \
    "$T/fem_p0_3x5x7.whfld" "$T/fem_p1_3x5x7.whfld" "$T/fem_p2_3x5x7.whfld" \
    "$TMP/$C-hex8-out0.whfld" "$TMP/$C-hex8-out1.whfld" "$TMP/$C-hex8-out2.whfld" >/dev/null
  for u in 0 1 2; do
    cmp "$TMP/$C-hex8-out${u}.whfld" "$T/fem_expected_out${u}_3x5x7.whfld"
  done
done
echo 'HEX8_FULL_F32_LOCAL_OPERATOR=PASS'
echo 'TAICHI_FEM_EXACT_ADMISSION=PASS'

# Inout is the sole intentional alias mechanism: one descriptor may be both
# read and written. Distinct declarations remain noalias by device+inode.
for C in fieldc fieldc-native256; do
  build/$C "$T/inout.json" -o "$TMP/$C-inout" >/dev/null
  cp "$T/inout_3x5x7.whfld" "$TMP/$C-inout.whfld"
  [ "$("$TMP/$C-inout" "$TMP/$C-inout.whfld")" = 'checksum_f32_bits=0x45b7c000' ]
  cmp "$TMP/$C-inout.whfld" "$T/expected_inout_3x5x7.whfld"
  build/$C "$T/alias.json" -o "$TMP/$C-alias" >/dev/null
  set +e
  "$TMP/$C-alias" "$T/a_3x5x7.whfld" "$T/a_3x5x7.whfld" >/dev/null 2>&1
  ar=$?
  set -e
  [ "$ar" -eq 2 ]
  # Same rank but distinct logical extents must reject at launch.
  set +e
  "$TMP/$C-alias" "$T/a_3x5x7.whfld" "$T/prime_5x7x11.whfld" >/dev/null 2>&1
  sr=$?
  set -e
  [ "$sr" -eq 2 ]
done
echo 'FIELD_INOUT=PASS'
echo 'FIELD_NOALIAS_CONTRACT=PASS'
echo 'FIELD_RUNTIME_SHAPE_VALIDATION=PASS'

# AVX-512 has architectural scatter and must write a padded output correctly.
build/fieldc "$T/copy.json" -o "$TMP/copy512" >/dev/null
cp "$T/outpad_3x5x7.whfld" "$TMP/outpad512.whfld"
[ "$("$TMP/copy512" "$T/a_3x5x7.whfld" "$TMP/outpad512.whfld")" = 'checksum_f32_bits=0x45ade800' ]
cmp "$TMP/outpad512.whfld" "$T/expected_copy_pad_3x5x7.whfld"
echo 'NATIVE512_STRIDED_OUTPUT_SCATTER=PASS'

# AVX2 has no scatter.  Reject instead of hiding eight scalar lane stores.
build/fieldc-native256 "$T/copy.json" -o "$TMP/copy256" >/dev/null
cp "$T/outpad_3x5x7.whfld" "$TMP/outpad256.whfld"
set +e
"$TMP/copy256" "$T/a_3x5x7.whfld" "$TMP/outpad256.whfld" >/dev/null 2>&1
r=$?
set -e
[ "$r" -eq 2 ]
if objdump -d build/field_runtime_256_template | grep -qi 'zmm'; then
  echo 'NATIVE256_ZMM_LEAK=FAIL' >&2; exit 1
fi
echo 'NATIVE256_STRIDED_OUTPUT_EXPLICIT_REJECT=PASS'
echo 'NATIVE256_TRUE_YMM=PASS'
echo 'FIELD_SCALAR_FALLBACK=0'

# The ordinary Wheelchair launcher structurally routes canonical field semantics
# to fieldc. This is semantic-format routing, never failure-driven retry.
build/whexc "$T/sum.json" -o "$TMP/via-whexc" >/dev/null
[ "$("$TMP/via-whexc" "$T/a_3x5x7.whfld")" = 'checksum_f32_bits=0x45ade800' ]
echo 'WHEXC_FIELD_SEMANTIC_ROUTE=PASS'

echo 'WHEELCHAIR_FIELD_1_2_16=PASS'
