#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

[ "$(cat VERSION)" = '1.3.2' ]
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_132.log 2>&1
for marker in \
 WHEELCHAIR_1_3_1_BUILD=PASS \
 WHEELCHAIR_1_3_2_BUILD=PASS \
 PHYSICAL_TENSOR_REALIZATION=BUILT \
 PHYSICAL_REALIZATION_MACHINE_FIDELITY=BUILT \
 PHYSICAL_MEMORY_DAG=BUILT \
 MUTABLE_LAYOUT_INJECTIVITY=BUILT \
 WRITABLE_CACHELINE_GEOMETRY_PROOF=BUILT \
 GENERAL_CAUSAL_NODE_PAGE_ISOLATION=4096 \
 GENERAL_CAUSAL_ARRIVAL_COUNT=BUILT \
 GENERAL_MUTABLE_MAILBOX_PAGE_ISOLATION=4096 \
 CHILD_RESULT_PRIVATE_OWNERSHIP=BUILT \
 NUMA_NODE_LOCALIZATION=best-effort-getcpu-mbind \
 MEMORY_ISA_OVERRIDE=non-temporal-pure-output \
 SINGLE_TOUCH_CAUSAL_TRANSFER=BUILT \
 CENTRAL_MEMORY_SCHEDULER=0 \
 MAX_RESIDENT_EXECUTORS=256 \
 GLOBAL_READY_QUEUE=0 \
 WORK_STEALING=0 \
 PRODUCTION_BUILD_PYTHON_INVOCATIONS=0
do grep -q "$marker" .release_build_132.log; done
echo 'BUILD_1_3_2_AUTHORITY=PASS'

for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

./test_execution_granularity_1212.sh
echo 'HISTORICAL_TENSOR_CAUSAL_GATES=PASS'
./test_neighborhood_semantics_1215.sh
echo 'HISTORICAL_NEIGHBORHOOD_GATES=PASS'
./test_field_native_1216.sh
echo 'HISTORICAL_FIELD_NATIVE_GATES=PASS'
./test_field_locality_1217.sh
echo 'HISTORICAL_FIELD_LOCALITY_GATES=PASS'
./test_field_surface_1218.sh
echo 'HISTORICAL_FIELD_SURFACE_GATES=PASS'
./test_physical_realization_131.sh
echo 'PHYSICAL_REALIZATION_1_3_1_PRESERVED=PASS'
./test_physical_memory_132.sh

T=${TMPDIR:-/tmp}/wheelchair132_release_$$
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT HUP INT TERM
build/wheelchairc tests/general_parallel_126/iterate_probe.wh -o "$T/iterate256" --executors 256 >/dev/null
[ "$("$T/iterate256" 2 5 3)" = "out00_bits=0x00000000000002f2
out01_bits=0x0000000000000043
out02_bits=0x00000000000002af" ]
echo 'GENERAL_ITERATE_Q256=PASS'

for f in \
 build/topologyc build/topologyc-wide build/topologyc-derived \
 build/topologyc-native256 build/topologyc-wide-native256 build/topologyc-derived-native256 \
 build/fieldc build/fieldc-native256 build/wheelchairc build/whexc \
 build/tensor_runtime_template build/tensor_derived_runtime_template \
 build/tensor_runtime_native256_template build/tensor_derived_runtime_native256_template \
 build/field_runtime_512_template build/field_runtime_256_template \
 build/general_parallel_release.elf
do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done
echo 'STATIC_AOT_DIRECT_NATIVE=PASS'

if grep -En '(^|[;&|[:space:]])(gcc|clang|llc|opt)([[:space:]]|$)' build.sh >/dev/null 2>&1; then
  echo 'C_LLVM_BACKEND_INVOCATION=FAIL' >&2; exit 1
fi
if grep -RniE 'work[ _-]*steal|global[ _-]*(ready|memory)[ _-]*queue|central[ _-]*memory[ _-]*scheduler' \
  runtime compiler \
  | grep -v -E 'There is no|no .*work|CENTRAL_MEMORY_SCHEDULER|comment|Red line' >/dev/null 2>&1; then
  echo 'FORBIDDEN_CENTRAL_MEMORY_COORDINATOR=FAIL' >&2; exit 1
fi
(cd frozen_native && sha256sum -c FROZEN_ASM_MANIFEST.sha256 >/dev/null)
echo 'FROZEN_NATIVE_AUTHORITY=PASS'

for f in WHEELCHAIR_CHARTER_1_3_2.md RELEASE_NOTES_1_3_2.md PURE_ASSEMBLY_RELEASE_PROOF_1_3_2.md RELEASE_GATES_1_3_2.txt; do test -s "$f"; done
echo 'NO_C_LLVM_JIT_BACKEND=PASS'
echo 'NO_PYTHON_RELEASE_SOURCE=PASS'
echo 'NO_CENTRAL_MEMORY_SCHEDULER=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'WHEELCHAIR_1_3_2_RELEASE=PASS'
