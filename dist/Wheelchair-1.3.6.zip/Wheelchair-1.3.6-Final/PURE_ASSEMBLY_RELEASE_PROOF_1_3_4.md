# Pure Assembly Release Proof — Wheelchair 1.3.4

Wheelchair 1.3.4 remains an AOT direct-native assembly compiler/runtime release.

## New physical proof points

- `field_regular_episode_ok` proves a vector episode lies inside the complete signed Rank-N neighborhood envelope.
- `g_spec_linear_delta_bytes` is derived at launch from canonical access deltas and logical strides.
- Generated regular loads use RIP-loaded immutable displacement plus `base + q*4`, then ordinary AVX2/AVX-512 masked loads.
- The regular preload source block contains no gather emitter call.
- The generated image retains a separate gather-capable fallback for boundary and irregular layouts.
- AVX2 tolerant high-pressure code contains YMM instructions only; ZMM count is zero.
- Strict FP never enters shared-factor reassociation.
- Tolerant factor pairs use a width-preserving two-FMA cover.

No C, LLVM, MLIR or JIT backend is introduced. No runtime timing trial, central optimizer, work-stealing queue or benchmark-name selector is introduced.
