# Wheelchair 1.3.1 Release Notes

Wheelchair 1.3.1 is the **Physical Realization Completion** release. It does not add a new language layer. It makes the 1.3.0 Physical DAG visible in the final machine dependency graph.

## Major changes

- Generic AVX-512 Tensor episodes can materialize two independent tolerant reduction carriers (`YMM/ZMM12 || YMM/ZMM13`).
- Generic/native AVX2 Tensor episodes can materialize two independent tolerant reduction carriers (`YMM12 || YMM11`).
- Strict and tolerant reduction realization are physically separated. Strict uses one ordered carrier even when the episode has two bodies; tolerant mode may use two carriers.
- Planned carriers, planned episode width, realized carriers and realized episode width are four independent runtime-validated facts.
- Tensor carrier allocation is pressure-aware: the second recurrence is only realized when the expression does not already require its architectural register.
- Field final code generation consumes a true dependency-depth Physical-DAG order instead of a canonical emitter list.
- The Field reordering audit exposed and removed an AVX2 hidden scratch clobber rather than hiding it behind a false dependency.
- Fixed Field Rank 1..8 uses AOT-expanded address episodes instead of a runtime axis-counter loop.
- Hot Tensor remaining-count control removes a redundant compare: `SUB` now serves as both count update and completion proof before the unsigned branch.
- The resident executor implementation ceiling remains 256; no work stealing or global ready queue was introduced.

## Numerical contracts

Strict floating-point authority remains bit exact in the regression suite, including awkward episode and tail sizes. Tolerant FSI reduction is allowed to reassociate and is checked against its declared tolerance rather than an obsolete bit-identity assumption. AVX-512 and AVX2 tolerant-tail probes remain within a two-ULP cross-ISA envelope in the release gate.

## Performance note

A pinned q1 comparison on the release KVM host does not show a universal speedup. In the final sample, Newton/Jv is essentially flat, Dense Rank-N improves by about 2.9%, and FSI is about 1.3% slower. The machine-graph transformation is therefore claimed as a structural realization improvement, not as a blanket performance multiplier. See `benchmarks/physical_realization_131/`.

## Compatibility

WH/WHEX semantics, the 1.2.18 human Field surface, `wheelchair.field/1`, `WHFLD216`, the recipient-blind causal release model and the 1..256 resident-executor implementation range remain compatible.
