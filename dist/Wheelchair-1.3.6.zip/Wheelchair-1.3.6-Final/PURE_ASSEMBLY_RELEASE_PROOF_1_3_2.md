# Wheelchair 1.3.2 Direct-Native Release Proof

Wheelchair 1.3.2 remains a direct-native AOT release. Production build orchestration is shell plus handwritten/native assembly sources. The release contains no Python source and the production build invokes no Python, GCC, Clang, LLVM, MLIR or JIT backend.

The Physical Memory Causality gate validates behavior dynamically and structure directly:

- non-injective mutable Field layouts reject on both AVX-512 and AVX2 native widths;
- the same overlapping layout is accepted read-only;
- a large contiguous output executes and remains byte-identical through both native widths while the runtime contains real `vmovntps` and `sfence` instructions;
- an injective but physically interleaving writable layout is legal at q1 and rejects at q4, proving that the runtime does not hide the conflict by silently serializing;
- General node state and mutable mailbox/state/output objects are page-isolated in native assembly;
- General causal readiness is zero-origin sparse arrival rather than root-initialized packed remaining counters;
- child result handoff uses child-owned stack storage in every Tensor/Field runtime authority;
- General parallel compiler patch addresses are derived from the built native ELF rather than handwritten layout constants;
- q256 causal execution remains exact and recipient-blind.

Release validation also verifies that compiler/runtime/generated native ELF authorities have no dynamic section and that the historical 1.3.1 machine-realization gates still pass.
