# Wheelchair 1.3.6

Wheelchair 1.3.6 is the **Global Physical Reality Unification** release. It promotes the 1.3.5 rule "do not recreate a still-valid physical fact" into a versioned AOT physical-fact system for the Field Physical-DAG and a common compile-time contract shared by the Field, Tensor and General frontends.

The Field physicalizer now separates AddressFact, LoadFact and ValueFact identity, invalidates loads by per-field version rather than global flush, canonicalizes duplicate regular addresses, admits generic exact-bit constants into one persistent pool, removes the old three-output semantic ceiling, and realizes the same direct-fact principles on both AVX2 and AVX-512. Runtime fact managers, runtime autotuning, work acquisition queues and recipient-aware resource handoff remain forbidden.

Strict FP keeps historical arithmetic order and zero FMA contraction. Irregular gather fallback, 1.3.2 physical memory ownership, 1.3.3 profitability, 1.3.4 regularity collapse and 1.3.5 realization uniqueness remain authoritative.

See `WHEELCHAIR_CHARTER_1_3_6.md`, `RELEASE_NOTES_1_3_6.md`, `PURE_ASSEMBLY_RELEASE_PROOF_1_3_6.md`, `PERFORMANCE_1_3_6_GLOBAL_PHYSICAL_REALITY.md` and `RELEASE_GATES_1_3_6.txt`.

## What changed in 1.3.6

### Global compiler-time physical facts

The Field AOT frontend now interns exact physical facts before final Physical-DAG scheduling. Equal pure facts can reuse a still-resident authority, while stores increment only the version of the field actually mutated. Address identity survives a memory-version change; LoadFact identity does not.

### Semantic width no longer equals register width

A legal cross-output supernode may use the full Field ABI output capacity. The current machine realization consumes it in three-accumulator physical windows, so a four-output graph becomes `3 + 1` instead of falling out of the optimized path.

### AVX-512 joins the direct fact path

AVX-512 now has high-ZMM constant residency, persistent AddressFact loads, direct stack-memory FMA operands and direct output-carrier stores. The release gate requires hundreds of high-register and direct-memory sites in the generated high-pressure graph and separately preserves strict-FP zero contraction.

### Release evidence

The 1.3.6 gate includes a four-output AVX2/AVX-512 oracle, a duplicate-address program that must generate exactly one invariant address birth, a write-then-read inout version test, machine-code inspection and the complete historical 1.3.5 release authority.

## What changed in 1.3.1

1.3.1 makes preserved parallel structure visible in the final machine dependency graph. Tolerant Tensor episodes now materialize true independent recurrence carriers on AVX-512 and AVX2; strict reductions keep one ordered carrier while still allowing a two-body physical episode. Carrier count and episode width are separate scheduler/runtime contracts.

Field final emission now consumes true dependency depth, fixed Rank 1..8 address episodes are AOT-expanded, and the old generic hot axis loop is kept only for dynamic-rank fallback. The hot Tensor advance also removes a redundant remaining-count compare by letting `SUB` provide both the update and completion condition.

The release gate disassembles generated machine payloads and fixed-Rank Field routines, so tensorization is accepted only when machine instructions prove it. The executor ceiling remains 256 and the recipient-blind no-stealing runtime model is unchanged.

See `WHEELCHAIR_CHARTER_1_3_1.md` and `RELEASE_NOTES_1_3_1.md`.

## What changed in 1.3.0

### 1. Physical DAG before final ISA emission

Tensor compilation is now two-pass:

```text
WH / WHEX
   -> semantic / Rank-N structure
   -> disposable native physical probe
   -> silicon/resource schedule
   -> canonical native realization
   -> static ELF
```

The first pass cannot reach the output ELF. It exists to expose the exact resource structure of the fused native episode. The scheduler therefore runs before the canonical machine image is emitted.

The old behavior that scheduled after code generation and then overwrote the result with a fixed `unroll=1` / four-carrier description is gone. The current fused backend truthfully realizes one architectural reduction chain and one body instance, and the pre-codegen capability plan says exactly that.

Field compilation now also constructs a transient physical dependency plan before final native emission. The plan validates floating virtual-register and integer coordinate-carrier def-use structure, store/reduction barriers, and provides the explicit operation order consumed by codegen.

### 2. Automatic Rank-N execution tensorization

Wheelchair tensorization is not limited to matrix multiplication or ML tensor cores.

A tensorization candidate is structural work with compatible independence, data flow, address relations, and lifetime. The current Tensor backend promotes the **whole fused Rank-N chunk** to one execution episode. That episode owns:

- its SIMD body;
- affine and coordinate induction carriers;
- boundary-specialized vector regions;
- constant residency;
- reduction residency;
- target ISA selection and direct encoding.

On x86 this does not pretend that a universal general-purpose tensor instruction exists. The batch is planned as one machine episode, and the backend selects the strongest legal ISA recipe for its parts.

### 3. Semantic ISA override

Wheelchair semantics outrank generic lowering convenience.

The backend already contains direct EVEX/FMA encoders and capability-dependent synthesized recipes. 1.3.0 makes this physical stage part of the formal architecture: when a generic recipe cannot preserve a semantic operation or its parallel structure, the target ISA recipe is authoritative.

Production user programs do not pass through C, GCC, LLVM, MLIR, a JIT, or a text-assembly compiler pipeline.

### 4. Resident executor ceiling: 256

The old `1..4` executor restriction is removed. 1.3.0 accepts:

```text
--executors 1..256
```

The number 256 is an implementation ceiling for this runtime generation, not a Wheelchair language-semantic upper bound.

The default executor geometry is derived from the process affinity set and capped at 256. At launch, Tensor and Field clamp requested executors to reachable chunks before any worker is created. General causal execution is similarly bounded by the number of materialized causal regions.

Therefore:

```text
--executors 256 + one reachable chunk
```

does **not** create 256 empty workers.

### 5. 256-node blind-release general fabric

The recipient-blind general runtime now has capacity for 256 causal nodes. The compiler physicalizer has 256 fragment slots and four 64-bit dependency bands, avoiding wraparound beyond the old two-band dependency representation.

This does not introduce a runtime scheduler. A causal region still:

```text
waits only for true predecessors
-> runs its own region
-> publishes only its true successor transitions
-> exits
```

It never searches for work or chooses a destination for released resources.

## Scheduler decisions are executable contracts

The Tensor runtime now consumes the pre-codegen carrier/unroll plan as a launch contract. If those fields disagree with the native episode actually implemented by the backend, execution rejects before workers are created.

The 1.3.0 release test deliberately corrupts a generated ELF from `unroll=1` to `unroll=2` and requires an explicit rejection. This prevents scheduling metadata from becoming decorative.

## Execution-purity rule

Wheelchair optimizes for useful machine work, not merely short source code.

Avoidable examples include:

- artificial dependency edges;
- unnecessary scalar loop control;
- redundant address regeneration;
- redundant loads/stores;
- unnecessary synchronization;
- empty executor leaves;
- runtime coordination that does not implement a true semantic dependency.

Necessary mathematical or semantic serialization remains valid. Strict floating-point ordering is not relaxed merely to make a graph appear more parallel.

## Parallel red lines

1. No work stealing.
2. No global ready queue.
3. No central runtime scheduler.
4. No post-completion peer query.
5. No destination-aware resource handoff.
6. No hidden scalar fallback for protected Tensor/Field semantics.
7. No C/LLVM/MLIR/JIT production backend.
8. No Python in the production build or release source tree.

The existing recipient-blind cascade remains the authority: a completed execution domain releases its own constraints and does not care where physical silicon capacity is used next.

## Field surface and ABI compatibility

The 1.2.18 human Field surface remains supported:

```text
program shift_z
strict

input nx: u64
input ny: u64
input nz: u64

input field a[
    x in nx periodic,
    y in ny periodic,
    z in nz periodic
]: f32

output field out[x in nx, y in ny, z in nz]: f32 =
    a[x,y,z+1]
```

The canonical format remains:

```text
wheelchair.field/1
```

and the storage ABI remains:

```text
WHFLD216
```

Pure functions, WH fake-for field syntax, WHEX pure-parallel regions, UTF-8 identifiers, periodic boundary semantics, multi-dynamic extents, strict-f32 behavior, AVX2 and AVX-512 native Field backends remain protected by the historical regression suites.

## Build

```sh
./build.sh
```

The production build is shell plus handwritten assembly tooling. It invokes no Python compiler generator.

## Compile

General WH/WHEX:

```sh
./whexc program.whex -o program
./wheelchairc program.wh -o program
```

Explicit tensor physicalization:

```sh
./topologyc program.whex -o program --executors 256
./topologyc-native256 program.whex -o program-avx2 --executors 256
```

Field:

```sh
./fieldc kernel.whex -o kernel --executors 256
./fieldc-native256 kernel.whex -o kernel-avx2 --executors 256
```

## Release validation

Run:

```sh
./test_release_native_130.sh
```

The dedicated 1.3.0 physical gate is:

```sh
./test_physical_dag_130.sh
```

Important terminal markers include:

```text
TENSOR_PHYSICAL_DAG_TWO_PASS=PASS
SCHEDULER_EXECUTION_CLOSURE=PASS
FIELD_PHYSICAL_DAG=PASS
RANKN_EXECUTION_TENSOR_EPISODE=PASS
SEMANTIC_ISA_OVERRIDE_DIRECT_NATIVE=PASS
EXECUTOR_GEOMETRY_1_256=PASS
TENSOR_Q256_EMPTY_LEAF_ERASURE=PASS
SCHEDULER_PLAN_CORRUPTION_REJECT=PASS
GENERAL_Q256_BLIND_RELEASE=PASS
FIELD_Q256_EMPTY_LEAF_ERASURE=PASS
NO_GLOBAL_READY_QUEUE=PASS
NO_WORK_STEALING=PASS
WHEELCHAIR_1_3_0_RELEASE=PASS
```

See `WHEELCHAIR_CHARTER_1_3_0.md`, `RELEASE_NOTES_1_3_0.md`, `RELEASE_GATES_1_3_0.txt`, and `PURE_ASSEMBLY_RELEASE_PROOF_1_3_0.md` for the exact boundary of this release.

# Wheelchair 1.3.3: Causal Physical Optimization

1.3.3 extends physical causality from ownership into optimization: once semantics, numerical contracts, machine dependencies and writable-memory ownership are correct, the compiler removes remaining avoidable arithmetic and access work.

The arithmetic side adds bounded tolerant-only shared-factor fusion with direct FMA realization while strict FP remains order-sovereign. The memory side replaces the old element-count non-temporal-store trigger with a documented CPUID cache-capacity model plus irregular-read pressure. Hot execution receives frozen physical facts only; there is no JIT, runtime autotuning, central optimizer, benchmark dispatch or work stealing.

The key rule is:

> Equivalent implementations may differ in source shape, but Wheelchair should not preserve extra machine work merely because that work appeared in the original spelling. Only semantic, numeric, causal and hardware necessity justify physical work.

See `WHEELCHAIR_CHARTER_1_3_3.md`, `RELEASE_NOTES_1_3_3.md`, `RELEASE_GATES_1_3_3.txt`, and `PURE_ASSEMBLY_RELEASE_PROOF_1_3_3.md`.

# Wheelchair 1.3.2: Physical Memory Causality

1.3.2 extends the structure-preservation rule into writable memory. Two execution domains that have no causal relationship must not become physically coupled merely because their mutable state was packed into one cache line, page or central transient array.

The current storage preference is:

```text
register carry
  -> executor-private storage
  -> causal-edge/page mailbox
  -> NUMA-local owned memory
  -> genuinely shared writable memory
```

Key 1.3.2 rules:

- mutable Field address maps must prove injectivity before execution;
- read-only overlapping views remain legal;
- multi-executor writable Field layouts must prove cache-line-exclusive physical partitioning or reject, never silently q1-fallback;
- each General causal node owns a private 4 KiB state page and receives sparse predecessor arrivals;
- General mutable binding/state/temp/output objects are page-isolated physical mailboxes/pages rather than packed writable slots;
- child causal results are written once into child-owned storage and read by the parent after join;
- node-local NUMA placement is attempted with `getcpu`/`mbind` without adding a central memory scheduler;
- large contiguous pure-output Field streams may use target memory ISA (`vmovntps` + `sfence`), while inout/tail paths remain cacheable;
- work stealing, global ready queues, central memory queues and hot-path general allocation remain forbidden.

Release validation:

```sh
./test_release_native_132.sh
```

The dedicated physical-memory authority is:

```sh
./test_physical_memory_132.sh
```

See `WHEELCHAIR_CHARTER_1_3_2.md`, `RELEASE_NOTES_1_3_2.md`, `RELEASE_GATES_1_3_2.txt`, and `PURE_ASSEMBLY_RELEASE_PROOF_1_3_2.md` for the exact release boundary.
