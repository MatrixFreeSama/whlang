# Wheelchair 1.3.3 Charter — Causal Physical Optimization

## Release thesis

Wheelchair 1.3.3 minimizes non-essential physical work after semantic, causal and memory ownership have already been preserved.

The release rule is:

> Within the exact freedom permitted by the language semantics, numerical contract, causal graph and documented target hardware, equivalent arithmetic and memory realizations must prefer the form with less physical work and shorter data motion. No workload name, benchmark identity, central runtime optimizer, JIT, work stealing or trial-run autotuning may substitute for structural proof.

## Arithmetic authority

1. Strict floating-point graphs remain order sovereign. Reassociation and contraction are forbidden unless bit preservation is proved.
2. Tolerant graphs may use bounded local algebraic equivalence when the rewrite is proven from def-use structure.
3. 1.3.3 adds generic two-term shared-factor fusion. The admitted structural form is two adjacent weighted products that share one immutable downstream factor and update the same accumulator. It is not tied to FEM, elasticity, Newton, any coefficient value or any field name.
4. The two independent coefficient products are formed before the accumulator update. Their sum is carried in a private scratch register and the shared factor is loaded once. One FMA performs the final accumulator update.
5. The optimization therefore reduces both operation count and recurrence count. A rejected prototype that merely replaced every multiply+add with an accumulator FMA was slower because it lengthened the true recurrence. That form is intentionally not release authority.
6. Existing load-identity and neighborhood-coordinate CSE remain active and are consumed by the fused physicalization.

## Memory access authority

1. 1.3.2 writable ownership, injectivity, cache-line isolation and page ownership remain mandatory.
2. The old `element_count >= CHUNK_SIZE` non-temporal-store heuristic is removed.
3. At cold launch, documented CPUID deterministic-cache geometry is used to derive the largest visible cache capacity. No timing trial is performed.
4. Pure contiguous output becomes an NT candidate only when its physical byte working set is at least twice the largest visible cache.
5. If any immutable input has non-contiguous physical layout, the threshold is doubled again. This represents random/gather read pressure and prevents small-output NT stores from competing with the dominant irregular-read path.
6. The hot loop receives one immutable `g_nt_active` fact. It never queries a central memory scheduler.
7. `sfence` is emitted dynamically only when the launch policy actually selected NT stores.
8. No speculative prefetch instruction is added without a proven latency-hiding case.

## Anti-wrapper red lines

- no C, LLVM, JIT or bytecode backend;
- no benchmark-name dispatch;
- no FEM-specific or solver-specific route;
- no runtime autotuning or trial-run selector;
- no central optimizer in the runtime;
- no work stealing or global ready queue;
- no hidden scalar fallback;
- no AVX-512 leakage into `native256`;
- no strict-FP reassociation for performance.

## Physical interpretation

1.3.0 preserved the parallel structure.

1.3.1 realized that structure in machine dependency chains.

1.3.2 realized it in writable physical-memory ownership.

1.3.3 removes remaining avoidable arithmetic and access work inside those already-correct physical structures.

The intended endpoint is not "more optimization passes". It is fewer unnecessary machine events.
