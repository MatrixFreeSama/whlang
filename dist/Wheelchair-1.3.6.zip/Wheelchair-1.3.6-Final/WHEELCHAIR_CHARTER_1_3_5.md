# Wheelchair 1.3.5 Charter — Physical Realization Uniqueness

## Prime rule

No repeated physical realization.

A semantic value, address fact, immutable constant, loaded value or causal result that already has a valid physical realization shall not be recomputed, rematerialized, rebroadcast, reloaded, copied, spilled or relocated merely for compiler or emitter convenience.

```text
already computed + still valid  -> consume it
already located  + still valid  -> address it directly
already resident + still valid  -> use that residency
new realization                 -> requires physical necessity or proven benefit
```

The target is not `MOV = 0`. Required loads, destructive-operand preservation, ABI saves, true pressure spills and version-changing reloads remain legal. The release rejects only work that recreates an unchanged fact without sufficient physical benefit.

## Physical-fact identity

1.3.5 extends the Physical DAG with compile-time physical facts. For the current bounded tolerant Field supernode, coefficient facts are identical only when all ordered material-access identities and all f32 constant bit patterns are exactly identical. Field names, physics names, rank names and benchmark identities do not participate.

A repeated fact earns persistent stack sovereignty only when its statically saved arithmetic exceeds its realization cost. Otherwise it remains demand-computed at its consumer. This prevents the opposite failure mode of replacing repeated computation with gratuitous caching.

## Demand-causal materialization

A profitable repeated fact is not precomputed merely because it may be needed later.

```text
first real consumer
    -> realize fact once
    -> consume immediately
    -> if later consumers are proven, preserve one authority copy
later proven consumers
    -> reuse that authority
last consumer
    -> fact lifetime ends
```

The producer does not create speculative process state for future convenience.

## Residency and direct operand cover

The native256 regular supernode jointly reasons about where a value already exists and which x86 operand form can consume it.

- high-use immutable constants may reside in YMM registers;
- material values retain one sovereign stack authority and can be consumed directly by FMA memory operands;
- one causal neighborhood X is born directly in a short-lived YMM carrier, fans out to the proven independent output consumers, then dies;
- regular address facts `field_base + fixed_delta` are realized once per function invocation and reused with the vector index;
- output accumulators remain independent physical carriers and are stored directly when the 1.3.3 memory-profitability authority has not selected non-temporal output.

If non-temporal output is active, the cross-output cached-store route is not authoritative; generated code falls back to the existing general store authority so 1.3.3 memory profitability remains intact.

## Numerical-contract invariant

Strict floating-point programs keep their historical recurrence. 1.3.5 residency, address reuse and direct operand decisions may remove non-arithmetic work, but strict arithmetic reassociation and FMA contraction remain forbidden.

Tolerant programs may use bounded equivalent arithmetic supernodes and physical-fact reuse. Numerical freedom comes only from the declared tolerant contract.

## ISA scope

The new full-bank residency/direct-operand realization is proven for native256 in this release. AVX2 high-register VEX3 encoding exposes YMM8..YMM15 rather than leaving half of the architectural vector register bank unusable due to emitter convenience.

AVX-512 keeps the correct sovereign 1.3.4/general arithmetic authority plus the generic wide arithmetic cover. 1.3.5 does not pretend that an unproven AVX2 residency ABI can simply be widened to ZMM. Both ISA paths remain release-gated for numerical correctness.

## No-shell rules

1. No FEM, elasticity, Taichi, SPGrid, benchmark-size, coefficient-value or variable-name dispatch.
2. No LLVM, MLIR, GCC/Clang backend, JIT, runtime autotuning, learned cost model or external register allocator.
3. No runtime residency manager. Physical-fact identity, lifetime and residency decisions are AOT compiler work.
4. No lookup-table result substitution. Immutable constant pools only prevent repeated construction of the same literal fact.
5. No work stealing, global ready queue or recipient-aware handoff.
6. 1.3.2 physical memory ownership, 1.3.3 memory profitability and 1.3.4 regularity collapse remain authoritative.

## Resource-release rule

Register and temporary-storage lifetimes follow the same recipient-blind principle as executor resources. At a fact's last proven consumer its residency may be released immediately. The releasing fact does not choose the next owner.

## Silicon rule

```text
same fact + same version + still valid
!= new machine work
```

A fact only has to become physical once per necessary lifetime.
