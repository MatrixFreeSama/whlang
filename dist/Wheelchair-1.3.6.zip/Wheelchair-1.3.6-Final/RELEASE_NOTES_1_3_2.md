# Wheelchair 1.3.2 Release Notes

Wheelchair 1.3.2 is the **Physical Memory Causality** release. It does not add a language layer or increase the 256-executor ceiling. It makes writable memory ownership obey the same causal structure that 1.3.1 already enforced in the machine dependency graph.

## Major changes

- Mutable Field output/inout descriptors now require a launch-time mathematical proof of affine address injectivity. A legal-span descriptor that maps distinct logical coordinates to one physical float is rejected instead of becoming a parallel write race.
- Read-only overlapping Field views remain legal.
- Multi-executor mutable Field execution additionally proves cache-line-exclusive physical partition geometry. Unprovable strided/transposed writable layouts reject instead of silently falling back to q1 or false-sharing.
- General causal node state is one 4 KiB page per node. Unrelated nodes no longer pack atomic arrival counters or completion state into one writable cache line.
- General causal readiness uses zero-origin arrival counts. Anonymous zero pages replace the old root sweep that initialized every remaining-counter page before parallel execution.
- Each General node best-effort localizes its own causal state page to the current NUMA node using `getcpu` + `mbind`; failure is non-fatal and does not change correctness.
- General mutable bindings, persistent state, transient state and outputs use one page per logical writable object. The old public symbol names remain ABI-compatible aliases to page-isolated mailboxes/pages, not packed writable arrays.
- Tensor and Field child return values are written to child-owned stack-slice storage and read by the parent only after join, removing computation-time parent/child write sharing on one cache line.
- Parallel-runtime patch offsets are generated from the actual native ELF symbol table. Memory-layout changes cannot silently leave stale handwritten compiler offsets.
- Large contiguous pure Field outputs use real non-temporal SIMD stores (`vmovntps`) with a worker-local `sfence`. Inout, small/tail and non-qualifying paths remain cacheable.
- AVX-512 and AVX2 large streaming-output paths are both dynamically file-identity tested.
- No central memory scheduler, global memory queue, hot-path allocator coordinator, work stealing or hidden q1 fallback was introduced.

## Compatibility

WH/WHEX semantics, strict/tolerant numerical contracts, `wheelchair.field/1`, `WHFLD216`, the 1.3.1 Physical Tensor realization, recipient-blind causal release and the 1..256 resident-executor implementation range are preserved.

A previously accepted writable descriptor may now reject if its affine address mapping aliases itself or if multi-executor physical cache-line ownership cannot be proven. This is an intentional correctness/physical-independence tightening, not a silent semantic fallback.

## Scope note

1.3.2 controls software-visible memory realization: register carry opportunities, writable cache-line/page ownership, NUMA placement and target CPU memory instructions. It does not claim direct userspace control over DRAM-controller JEDEC commands.
