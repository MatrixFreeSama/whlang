# Wheelchair 1.3.5 Release Notes

## Summary

1.3.5 introduces **Physical Realization Uniqueness**. It attacks the repeated physical work exposed after 1.3.4 removed most regular-neighborhood gather overhead: repeated operand relocation, constant rematerialization, address reconstruction, process-wide neighborhood materialization and recomputation of identical coefficient facts.

The release remains AOT, direct-native, workload-name blind and scheduler-free in the hot path.

## 1. Bounded Physical Fact Identity

Tolerant wide coefficient groups now receive an exact compile-time physical identity. Two groups are the same fact only when they have the same ordered material-access identities and exactly the same f32 constant bits.

On the canonical high-pressure graph used during development:

```text
243 X/output coefficient groups
128 exact coefficient facts
```

Repeated facts are not automatically cached. A fact receives a stack authority slot only when the arithmetic work saved by later consumers exceeds the store/reload cost. This is static profitability, not runtime autotuning.

## 2. Demand-Causal Materialization

Profitable repeated coefficient facts are realized at their first real consumer instead of being precomputed. The first consumer uses the just-computed value directly; one authority copy is kept only when future consumers are statically proven. Later consumers reuse it.

This removes the old pattern:

```text
precompute -> store -> first consumer reload
```

and replaces it with:

```text
first consumer computes -> consumes -> preserves only if future reuse exists
```

## 3. Cross-consumer neighborhood lifetime

For a proven native256 regular multi-output supernode, one downstream neighborhood value X is loaded directly into a short-lived causal carrier, consumed by all proven independent output accumulators and then released. It is not first materialized into an episode-wide stack cache.

The output accumulators remain independent machine carriers. Sharing one immutable X therefore does not create an artificial output recurrence.

## 4. Immutable constant residency and direct material operands

Unique immutable f32 vector constants are constructed once per generated-function invocation. The most frequently consumed constants may occupy the high AVX2 register bank. Material values retain one stack authority and hot-constant FMAs consume those material slots directly instead of first copying the material to a temporary YMM.

AVX2 VEX3 encoders now support the full YMM0..YMM15 bank for the required move/FMA forms, removing a historical emitter limitation that left high registers unavailable to the physical plan.

## 5. Address fact uniqueness

For a proven regular access, `field_base + fixed signed byte delta` is realized once per function invocation. Vector episodes reuse that address fact with the current q index rather than recreating base-plus-delta for every episode.

This extends the 1.3.4 rule from "do not rediscover a regular coordinate" to "do not rebuild the already-proven physical address fact".

## 6. Memory-profitability closure

The native256 cross-output path may directly store its output carriers only while the inherited 1.3.3 non-temporal policy is inactive. When `g_nt_active` is set, generated code branches to the historical generic store authority so large streaming output keeps its cache-bypass policy.

## Numerical boundary

Strict FP keeps zero contraction on the canonical strict high-pressure graph.

For the current AMD EPYC 9V74 KVM diagnostic, the 64^3 tolerant 1.3.5 development output was compared with frozen 1.3.4 output. Across the three output fields:

```text
max absolute difference: 7.15e-7 .. 2.86e-6
relative L2 difference:  2.50e-7 .. 4.14e-7
```

These differences arise from tolerant reassociation and remain outside the strict path.

## Same-host performance diagnostic

Current audit host: AMD EPYC 9V74 under KVM, 5 visible vCPUs, one NUMA node.

One same-process-boundary 17-run comparison of frozen 1.3.4 and the 1.3.5 release candidate on the 64^3 one-executor native256 corpus produced:

```text
1.3.4 median: 32.357 ms
1.3.5 median: 18.177 ms
ratio:        1.780x
```

A separate 51-round CPU0 rotating-order opponent diagnostic produced:

```text
Wheelchair 1.3.5 candidate: 18.812 ms
Clang -Ofast control:       16.835 ms
GCC -Ofast control:         12.298 ms
```

Therefore 1.3.5 is a major same-host improvement but does not claim to have defeated the strongest GCC/Clang controls. These are host/corpus diagnostics, not universal language-speed claims.

## Claim boundary

1.3.5 does not claim global optimal register allocation, zero MOV instructions, or a complete AVX-512 residency planner. Necessary copies, true spills, boundary/general fallback and mutable-version reloads remain legal. The release implements exact bounded fact identity, static reuse profitability, demand-causal materialization, native256 direct operand/residency covering and inherited safe fallbacks.
