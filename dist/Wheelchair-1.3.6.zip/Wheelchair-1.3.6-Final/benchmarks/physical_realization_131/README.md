# Wheelchair 1.3.1 physical-realization benchmark note

This is a same-host process-wall-time check against the frozen 1.3.0 release on the release container: 5 visible vCPUs, AMD EPYC 9V74, KVM, one executor, one pinned vCPU, 5 warmups and 31 measured invocations per row, median reported.

The result is intentionally not presented as a universal speedup claim. 1.3.1 primarily closes the machine-graph fidelity gap: real independent recurrence carriers, separate strict/tolerant physical contracts, dependency-based Field emission, fixed-Rank address episodes, and less scalar remaining-count control. On this virtual host Newton/Jv is effectively flat, Dense Rank-N improves by about 2.9%, and FSI is about 1.3% slower in this run. KVM scheduling noise is material at this scale.

The release authority is structural plus semantic, not this timing sample: strict numerical paths remain bit exact, tolerant paths remain inside their declared error contracts, and the generated machine payload is audited for the required independent dependency chains.
