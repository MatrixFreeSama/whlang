# Field Locality 1.2.17 Authority Probe

Host: AMD EPYC 9V74 80-Core Processor virtualized environment, 5 visible CPUs, one thread/core. GNU binutils 2.44. The benchmark uses one executor and the same 64^3 strict-f32 full Hex8 local operator and materialized fields used to expose the 1.2.16 locality failure.

This directory records a compiler-regression probe. The compiler does not inspect this benchmark name or its dimensions.

The principal result is structural rather than competitive: 2,304 logical loads are canonicalized to 97 immutable load identities, and equal coordinates across fields are reduced to 27 coordinate episodes when launch-time byte-stride proof succeeds.

See `authority_results.csv` for measured same-host timings. 1.2.17 AVX-512 improved 67.45x and AVX2 improved 88.98x over the final 1.2.16 binaries on the same data.
