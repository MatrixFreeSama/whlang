# Wheelchair 1.3.5 Physical Realization Uniqueness Diagnostic

Audit host: AMD EPYC 9V74 under KVM, 5 visible vCPUs, one socket, one NUMA node, 32 MiB visible L3.

## 64^3 regular Rank-N neighborhood, tolerant, native256, q1

Same-process-boundary diagnostic, 17 measurements per version:

```text
Wheelchair 1.3.4 median: 32.356850 ms
Wheelchair 1.3.5 RC:     18.176735 ms
median ratio:             1.7801x
```

The main structural changes between these paths are generic wide shared-X grouping, cross-output causal consumption, immutable constant uniqueness/residency, direct material memory operands, persistent regular address facts, direct output-carrier consumption and profitable repeated coefficient-fact reuse.

## External compiler controls

51 rotating-order runs, pinned CPU0:

```text
Wheelchair 1.3.5 RC median: 18.812468 ms
Clang -Ofast median:        16.835038 ms
GCC -Ofast median:          12.298340 ms
```

Ratios:

```text
Clang / Wheelchair time: 0.8949
Wheelchair / GCC time:   1.5297
```

The controls still lead this structured kernel. They are retained as machine-quality targets rather than hidden or weakened opponents.

## Numerical comparison against frozen 1.3.4

Three 64^3 output fields:

```text
out0: max abs 7.152557e-7, relative L2 4.14125e-7
out1: max abs 2.861023e-6, relative L2 2.49662e-7
out2: max abs 1.192093e-6, relative L2 2.70375e-7
```

The strict contract continues to prohibit FMA contraction/reassociation.

## AVX-512 regression control

After limiting the new native256 residency ABI to its proven ISA path, a nine-run same-host whole-process diagnostic gave:

```text
frozen 1.3.4 AVX-512 median: 24.883 ms
1.3.5 RC AVX-512 median:     20.838 ms
```

This is diagnostic only. It verifies that preserving the conservative AVX-512 authority did not require a performance rollback on this corpus.
