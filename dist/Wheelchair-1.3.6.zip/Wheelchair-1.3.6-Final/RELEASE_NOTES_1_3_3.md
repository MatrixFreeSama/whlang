# Wheelchair 1.3.3 Release Notes

## Summary

1.3.3 introduces Causal Physical Optimization across arithmetic and memory access while preserving the 1.3.2 ownership model and all historical semantic gates.

### Arithmetic

- Added tolerant-only, bounded shared-factor subgraph fusion.
- The compiler recognizes two adjacent weighted terms with the same immutable downstream factor and accumulator by pure def-use structure.
- Eleven transient source operations can collapse into one internal physical operation; the final ISA forms two independent coefficients, combines them, loads the shared factor once and performs one accumulator FMA.
- Strict FP never enters the rewrite.
- AVX2 and AVX-512 use the same structural proof; `native256` remains YMM-only.
- Existing load-identity and coordinate CSE are reused rather than replaced by a new optimizer layer.

### Memory

- Removed the 1.3.2 element-count NT-store trigger.
- Added cold launch-time CPUID cache-capacity discovery.
- Base NT threshold is `2 × largest visible cache`, with an 8 MiB floor.
- Non-contiguous immutable input raises the threshold to `4 × cache`, representing irregular-read pressure.
- Hot store helpers consume the frozen policy bit only.
- `sfence` is conditional on actual NT use.
- No prefetch ISA was added without a proven positive case.

## High-pressure machine-graph observation

On the existing Rank-N neighborhood hexahedral corpus, the strict AVX2 graph remains approximately `2304 vmulps`, `1156 vaddps`, `0 vfmadd` and preserves the historical exact oracle. Under the tolerant contract, the generic 1.3.3 factorization produces approximately `1152 vmulps`, `580 vaddps`, `576 vfmadd231ps`, with no ZMM instruction in the native256 image.

On the current 5-vCPU AMD EPYC 9V74 KVM host, a 64^3 one-executor release-style comparison observed a median around 49.44 ms for the 1.3.2 tolerant graph and 44.07 ms for the 1.3.3 shared-factor graph, about 10.9% lower wall time. This is a same-host diagnostic, not a universal language claim.

A 128 MiB contiguous pure-output q4 smoke comparison observed about 69.6 ms for 1.3.2 versus 65.9 ms for the new cache-capacity policy. The earlier ~1 MiB output / highly irregular backing-memory regression no longer has an element-count reason to select NT stores.

## Claim boundary

1.3.3 does not claim globally optimal symbolic algebra, exact undocumented CPU-port control, universal prefetch optimality or cross-machine benchmark dominance. The arithmetic search is deliberately bounded and local; memory policy uses documented cache geometry and structural pressure, not runtime timing trials.
