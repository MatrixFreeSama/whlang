# Wheelchair 1.3.3 Pure Assembly Release Proof

The production compiler and runtime remain handwritten x86-64 assembly and direct static ELF AOT.

## New 1.3.3 implementation locations

- `compiler/field_frontend_common_x86_64.S`
  - tolerant shared-factor structural recognizer;
  - internal physical factor operation;
  - direct AVX2/AVX-512 FMA encoding;
  - immutable access reuse from existing episode cache.
- `runtime/field_runtime_256_x86_64.S`
- `runtime/field_runtime_512_x86_64.S`
  - CPUID cache-capacity query;
  - immutable launch-time NT profitability fact;
  - random-read pressure adjustment;
  - conditional `sfence`.

## Negative proof

The release build invokes no Python generator, C compiler, LLVM toolchain, JIT or runtime benchmark selector. `native256` generated high-pressure code is audited for zero ZMM instructions. Compiler/runtime sources are scanned for benchmark-specific names and prohibited scheduling fabrics.

## Contract split

Strict Field programs preserve their prior machine arithmetic order and exact result files. Tolerant programs may enter the new bounded algebraic equivalence class. This is the only source of floating reassociation freedom introduced by 1.3.3.
