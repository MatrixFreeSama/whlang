# Wheelchair 1.2.18 Pure-Assembly Release Proof

The 1.2.18 human materialized-field surface is implemented in the handwritten x86-64 assembly compiler. It reuses the existing handwritten lexer/expression AST and lowers WH/WHEX field declarations at compile time into the unchanged `wheelchair.field/1` graph.

Production build requirements:

- `build.sh` contains no Python invocation;
- the release contains no `.py` source;
- `fieldc`, `fieldc-native256`, `whexc`, `wheelchairc`, topology compilers and field runtime templates are static ELF images;
- equivalent WH/WHEX/canonical field programs emit byte-identical native executables;
- no human-surface runtime object, interpreter, bytecode dispatcher, C backend, LLVM backend or JIT exists;
- 1.2.17 locality optimization remains downstream of the surface bridge and is not duplicated.

The release suite verifies these properties again after fresh ZIP extraction.
