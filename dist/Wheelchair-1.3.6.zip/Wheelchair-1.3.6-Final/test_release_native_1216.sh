#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

[ "$(cat VERSION)" = '1.2.16' ]
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1216.log 2>&1
grep -q 'WHEELCHAIR_1_2_16_BUILD=PASS' .release_build_1216.log
grep -q 'NATIVE_FIELD_ABI_1_2_16=BUILT' .release_build_1216.log
grep -q 'RANKN_F32_NATIVE512=BUILT' .release_build_1216.log
grep -q 'RANKN_F32_NATIVE256=BUILT' .release_build_1216.log
grep -q 'GENERAL_CONST_INTEGER_DIVMOD=BUILT' .release_build_1216.log
grep -q 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS' .release_build_1216.log
grep -q 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0' .release_build_1216.log

# Shipped compiler images must be the exact products of the production build.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Historical language/parallel/performance authorities stay active. 1.2.15's
# test is invoked directly because its historical release wrapper correctly
# requires VERSION=1.2.15; these semantic gates remain byte/behavior authority.
./test_release_native_1214.sh
./test_neighborhood_semantics_1215.sh

# 1.2.16 native materialized field/numeric completion.
./test_field_native_1216.sh

# Release-source closure: no workload/divisor names may control the new lane.
if grep -RniE 'Taichi|FEM|elasticity|\b97\b|\b89\b|64\^3|64x64' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'FIELD_SPECIAL_PURPOSE_ROUTE=FAIL' >&2; exit 1
fi

# New field compiler/runtime is direct native, static, and contains no dynamic
# dependency or hidden interpreter path.
for f in build/fieldc build/fieldc-native256 build/field_runtime_512_template build/field_runtime_256_template; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_DIVISOR_SPECIAL_CASE=PASS'
echo 'NO_HIDDEN_F64_PROMOTION=PASS'
echo 'NO_MANUAL_FLATTEN_REQUIREMENT=PASS'
echo 'NO_SCALAR_FALLBACK=PASS'
echo 'NO_C_LLVM_JIT=PASS'
echo 'BLIND_RELEASE_PRESERVED=PASS'
echo 'WHEELCHAIR_1_2_16_RELEASE=PASS'
