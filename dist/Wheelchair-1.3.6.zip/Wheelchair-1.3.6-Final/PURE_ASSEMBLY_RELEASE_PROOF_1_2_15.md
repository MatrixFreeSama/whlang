# Wheelchair 1.2.15 Pure-Assembly Release Proof

The 1.2.15 production path remains the 1.2.14 handwritten native path:

```text
WH / WHEX source
    -> handwritten x86-64 surface lowerer
    -> canonical tensor/general graph
    -> handwritten x86-64 native frontend
    -> standalone ELF64 image
```

The Rank-N neighborhood upgrade is implemented in `compiler/surface_lowerer_x86_64.S` plus the frozen native512/native256 derived tensor frontends. It does not invoke Python, C, C++, LLVM, MLIR, a JIT, or an external assembler/linker while compiling a user program.

`build.sh` uses the system assembler/linker only to build the compiler distribution itself. The resulting Wheelchair compiler emits user executables directly.

Release authority:

```sh
./test_release_native_1215.sh
```
