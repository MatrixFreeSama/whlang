# Wheelchair 1.3.4 Charter — Physical Regularity Collapse

## Prime rule

Known regularity must not survive as generic machine work.

If Rank-N geometry, field layout, numeric contract and causal ownership prove a neighborhood access or arithmetic relation, the final machine graph must realize that proof directly. Generic gather, repeated coordinate reconstruction, redundant loads and fragmented arithmetic are fallbacks for genuinely unproven structure, not defaults.

## Physical regularity invariant

For a contiguous row-major immutable field and a vector episode proven inside the kernel-wide neighborhood interior:

```text
logical neighborhood delta
    -> signed periodic canonical delta
    -> one launch-time byte displacement
    -> base + q*4 + displacement
    -> ordinary vector load
```

No per-load modulo, lane-index vector construction, gather or boundary check is permitted in that regular interior path. Boundary and irregular cases retain the complete historical gather authority.

## Numerical-contract invariant

Strict floating-point programs keep their source recurrence and receive address optimization only. Tolerant programs may additionally enter bounded equivalent arithmetic covers. 1.3.4 upgrades the existing shared-factor supernode from:

```text
P1*C1; P2*C2; add; FMA(X,acc)
```

to:

```text
q = P1*C1
q = FMA(P2,C2,q)
acc = FMA(q,X,acc)
```

The accumulator is still touched once per pair. Fewer operations are not allowed to create a longer hidden serial recurrence.

## No-shell rules

1. No FEM, elasticity, Taichi, SPGrid, benchmark-size or variable-name dispatch.
2. No LLVM, MLIR, JIT, runtime autotuning, learned cost model or external symbolic-algebra backend.
3. No layout materialization or transpose merely to manufacture a convenient vector path.
4. No deletion of truthful irregular gather capability.
5. No work stealing, global ready queue or recipient-aware resource handoff.
6. 1.3.2 physical memory ownership and 1.3.3 cache-profitability rules remain authoritative.

## Physical classes

The current release distinguishes:

- proven contiguous regular neighborhood interior: fixed-displacement vector loads;
- boundary episodes: existing periodic gather authority;
- non-contiguous / genuinely irregular fields: existing general gather/scatter rules;
- strict arithmetic: exact historical recurrence;
- tolerant shared-factor arithmetic: width-preserving FMA cover.

This is a generic structure distinction. Renaming fields, changing the simulated physical system or changing coefficients does not alter the decision.

## Silicon rule

A fact already proved before execution is not valid runtime work.

```text
known structure != runtime computation
known structure = machine-code structure
```
