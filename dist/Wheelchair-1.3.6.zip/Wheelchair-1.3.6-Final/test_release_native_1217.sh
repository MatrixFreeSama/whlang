#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"

[ "$(cat VERSION)" = '1.2.17' ]
if find . -type f -name '*.py' -print | grep -q .; then
  echo 'PYTHON_SOURCE_IN_RELEASE=FAIL' >&2; exit 1
fi
if grep -En '(^|[[:space:]])python(3)?([[:space:]]|$)' build.sh; then
  echo 'PRODUCTION_BUILD_PYTHON_INVOCATION=FAIL' >&2; exit 1
fi

./build.sh > .release_build_1217.log 2>&1
grep -q 'WHEELCHAIR_1_2_17_BUILD=PASS' .release_build_1217.log
grep -q 'FIELD_LOAD_IDENTITY_ALGEBRA_1_2_17=BUILT' .release_build_1217.log
grep -q 'NEIGHBORHOOD_COORDINATE_CSE_1_2_17=BUILT' .release_build_1217.log
grep -q 'DYNAMIC_POW2_ADDRESS_STRENGTH_REDUCTION_1_2_17=BUILT' .release_build_1217.log
grep -q 'REUSE_WEIGHTED_FIELD_RESIDENCY_1_2_17=BUILT' .release_build_1217.log
grep -q 'GENERAL_PARALLEL_BLIND_RESOURCE_RELEASE=PASS' .release_build_1217.log
grep -q 'PRODUCTION_BUILD_PYTHON_INVOCATIONS=0' .release_build_1217.log

# Shipped native images must equal a fresh production build.
for f in wheelchairc whexc topologyc topologyc-wide topologyc-derived topologyc-native256 topologyc-wide-native256 topologyc-derived-native256 fieldc fieldc-native256; do
  cmp "build/$f" "$f"
  cmp "build/$f" "bin/$f"
done
echo 'PREBUILT_NATIVE_IMAGE_IDENTITY=PASS'

# Historical semantic/performance authorities stay mandatory.
./test_release_native_1214.sh
./test_neighborhood_semantics_1215.sh
./test_field_native_1216.sh
./test_field_locality_1217.sh

# Direct-native closure.
for f in build/fieldc build/fieldc-native256 build/field_runtime_512_template build/field_runtime_256_template; do
  readelf -d "$f" 2>&1 | grep -q 'There is no dynamic section'
done

# Workload names, fixed shapes and scheduler substitutions may not enter the lane.
if grep -RniE 'Taichi|FEM|elasticity|Hex8|2304|64\^3|64x64' \
  compiler/field* runtime/field* tools/generate_field_runtime_offsets.sh >/dev/null 2>&1; then
  echo 'FIELD_LOCALITY_SPECIAL_PURPOSE_ROUTE=FAIL' >&2; exit 1
fi
if grep -RniE 'work[ _-]?steal|global[ _-]?ready[ _-]?queue|central[ _-]?scheduler' \
  compiler/field* runtime/field* >/dev/null 2>&1; then
  echo 'FIELD_LOCALITY_PARALLEL_RED_LINE=FAIL' >&2; exit 1
fi

# ABI stays 1.2.16-compatible by design; no new field magic/version is allowed.
grep -q '`WHFLD216`' FIELD_ABI_1_2_16.md
if grep -RIl 'WHFLD217' compiler runtime tests tools >/dev/null 2>&1; then
  echo 'FIELD_ABI_UNNECESSARY_BREAK=FAIL' >&2; exit 1
fi

echo 'FIELD_SOURCE_1_2_16_COMPATIBLE=PASS'
echo 'FIELD_ABI_1_2_16_COMPATIBLE=PASS'
echo 'NO_BENCHMARK_DISPATCH=PASS'
echo 'NO_FIXED_SHAPE_ROUTE=PASS'
echo 'NO_SCALAR_FALLBACK=PASS'
echo 'NO_C_LLVM_JIT=PASS'
echo 'NO_WORK_STEALING=PASS'
echo 'BLIND_RELEASE_PRESERVED=PASS'
echo 'NO_NEGATIVE_STRUCTURAL_COMPRESSION=PASS'
echo 'WHEELCHAIR_1_2_17_RELEASE=PASS'
