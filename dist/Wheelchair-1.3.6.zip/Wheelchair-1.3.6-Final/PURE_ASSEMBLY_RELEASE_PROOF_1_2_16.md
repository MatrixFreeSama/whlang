# Wheelchair 1.2.16 Pure Assembly Release Proof

The production compilers and runtime physicalizers introduced in 1.2.16 are handwritten x86-64 assembly plus static data/templates. `build.sh` uses shell utilities, GNU `as`, `ld`, `nm`, `objdump`, `readelf`, `objcopy`, `cmp`, `grep` and `sha256sum`; it does not invoke Python.

The field AOT chain is:

```text
wheelchair.field/1 -> fieldc assembly frontend -> direct SIMD bytes -> static ELF
```

Generated field executables contain no dynamic section and no bytecode interpreter. `fieldc-native256` is verified to contain no ZMM instructions in its runtime physicalization. Unsupported AVX2 non-contiguous output is rejected instead of scalarized.

The release suite also retains the historical pure-assembly and blind-release gates from 1.2.14/1.2.15.
