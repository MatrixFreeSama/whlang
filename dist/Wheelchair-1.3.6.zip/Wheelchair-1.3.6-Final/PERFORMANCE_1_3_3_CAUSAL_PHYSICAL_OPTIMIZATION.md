# Wheelchair 1.3.3 Causal Physical Optimization — Same-host diagnostics

Host observed during this release audit: AMD EPYC 9V74 under KVM, 5 visible vCPUs, one visible NUMA node. These are release diagnostics, not a universal language ranking.

## Arithmetic positive control

Workload: existing Rank-N neighborhood hexahedral high-pressure Field corpus, f32, one executor pinned to CPU 0. Both 1.3.2 and 1.3.3 use the tolerant contract; outputs are the same mathematical operator within the declared tolerant boundary. 21 alternating whole-process measurements after warm-up.

| implementation | median wall | relative |
|---|---:|---:|
| Wheelchair 1.3.2 tolerant | 54.108 ms | 1.000x |
| Wheelchair 1.3.3 shared-factor | **45.080 ms** | **1.200x throughput** |

Median wall time decreases about 16.7%. The generated native256 machine graph changes from the unfused two-term arithmetic to approximately 1152 `vmulps`, 580 `vaddps`, 576 `vfmadd231ps`; strict mode remains unfused and exact.

## Irregular-memory negative control

Workload: approximately 1 GiB sparse physical backing, about 1 MiB useful logical output, non-contiguous multi-direction gathers, q4. 15 alternating whole-process measurements after warm-up.

| implementation | median wall |
|---|---:|
| Wheelchair 1.3.2 | 13.534 ms |
| Wheelchair 1.3.3 | 13.643 ms |

The difference is about +0.8% time and is treated as flat/no demonstrated speedup. The important release result is that the previous element-count NT trigger is gone: this small-output irregular-read case no longer qualifies merely because its logical element count exceeds a chunk threshold.

## Streaming positive control

Workload: 128 MiB contiguous f32 copy/output, q4, 15 alternating whole-process measurements after warm-up.

| implementation | median wall | relative |
|---|---:|---:|
| Wheelchair 1.3.2 | 68.634 ms | 1.000x |
| Wheelchair 1.3.3 | **65.609 ms** | **1.046x throughput** |

The cache-capacity model therefore retains a positive large-streaming NT case while rejecting the old small-output element-count logic.

## Claim boundary

- No dual-socket NUMA performance claim is made on this host.
- No runtime timing/autotuning loop exists in the release.
- The arithmetic optimizer is bounded local causal algebra, not a global CAS.
- Strict floating-point execution is not reassociated for these gains.
